package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/15/12
 * Time: 9:19 PM
 */
public class ChemicalName {
    private long chemicalNameId;
    private String materialName;
    private String activeIngredient;
    private String materialClassification;
    private String formulatedAmount;
    private String formulatedAmountUnit;
    private String formulationDesignation;
    private boolean activeStatus;
    private String alias;
    private String chemicalNameCAS;
    private String chemicalNameIUPAC;
    private String cpNumber;
    private String encodedImage;
    private String imageName;
    private String molecularWeight;
    private String molecularFormula;
    private String elementalTheory;

    public ChemicalName() {
    }

    public ChemicalName(
            long chemicalNameId, String activeIngredient, boolean activeStatus, String alias,
            String chemNameCAS, String chemNameIUPAC, String cpNumber,
            String formulatedAmount, String formulatedAmountUnit, String formulationDesignation, String materialClass, String materialName) {

        this.chemicalNameId = chemicalNameId;
        setActiveIngredient(activeIngredient);
        setActiveStatus(activeStatus);
        setAlias(alias);
        setChemicalNameCAS(chemNameCAS);
        setChemicalNameIUPAC(chemNameIUPAC);
        setCpNumber(cpNumber);
        setFormulatedAmount(formulatedAmount);
        setFormulatedAmountUnit(formulatedAmountUnit);
        setFormulationDesignation(formulationDesignation);
        setMaterialClassification(materialClass);
        setMaterialName(materialName);
    }

    public final long getChemicalNameId() {
        return chemicalNameId;
    }

    public final boolean getActiveStatus() {
        return activeStatus;
    }

    public final void setActiveStatus(boolean activeStatus) {
        this.activeStatus = activeStatus;
    }


    public final String getAlias() {
        return alias;
    }

    public final void setAlias(String alias) {
        this.alias = alias;
    }

    public final String getChemicalNameCAS() {
        return chemicalNameCAS;
    }

    public final void setChemicalNameCAS(String chemicalNameCAS) {
        this.chemicalNameCAS = chemicalNameCAS;
    }

    public final String getChemicalNameIUPAC() {
        return chemicalNameIUPAC;
    }

    public final void setChemicalNameIUPAC(String chemicalNameIUPAC) {
        this.chemicalNameIUPAC = chemicalNameIUPAC;
    }

    public final String getCpNumber() {
        return cpNumber;
    }

    public final void setCpNumber(String cpNumber) {
        this.cpNumber = cpNumber;
    }

    public final String getMaterialName() {
        return materialName;
    }

    public final String getMaterialClassification() {
        return materialClassification;
    }

    public final String getActiveIngredient() {
        return activeIngredient;
    }

    public final void setMaterialName(String materialName) {
        this.materialName = materialName;
    }

    public final void setMaterialClassification(String materialClassification) {
        this.materialClassification = materialClassification;
    }

    public String getFormulatedAmount() {
        return formulatedAmount;
    }

    public void setFormulatedAmount(String formulatedAmount) {
        this.formulatedAmount = formulatedAmount;
    }

    public String getFormulatedAmountUnit() {
        return formulatedAmountUnit;
    }

    public void setFormulatedAmountUnit(String formulatedAmountUnit) {
        this.formulatedAmountUnit = formulatedAmountUnit;
    }

    public String getFormulationDesignation() {
        return formulationDesignation;
    }

    public void setFormulationDesignation(String formulationDesignation) {
        this.formulationDesignation = formulationDesignation;
    }

    public final void setActiveIngredient(String activeIngredient) {
        this.activeIngredient = activeIngredient;
    }

    public void setEncodedImage(String encodedImage) {
        this.encodedImage = encodedImage;
    }

    public String getEncodedImage() {
        return encodedImage;
    }

    public String getImageName() {
        return imageName;
    }

    public void setImageName(String imageName) {
        this.imageName = imageName;
    }

    public void setMolecularWeight(String molecularWeight) {
        this.molecularWeight = molecularWeight;
    }

    public String getMolecularWeight() {
        return molecularWeight;
    }

    public String getMolecularFormula() {
        return molecularFormula;
    }

    public void setMolecularFormula(String molecularFormula) {
        this.molecularFormula = molecularFormula;
    }

    public String getElementalTheory() {
        return elementalTheory;
    }

    public void setElementalTheory(String elementalTheory) {
        this.elementalTheory = elementalTheory;
    }
}
