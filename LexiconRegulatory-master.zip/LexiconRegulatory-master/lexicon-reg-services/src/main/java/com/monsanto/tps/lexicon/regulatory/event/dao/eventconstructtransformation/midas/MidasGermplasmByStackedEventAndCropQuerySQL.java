package com.monsanto.tps.lexicon.regulatory.event.dao.eventconstructtransformation.midas;

public interface MidasGermplasmByStackedEventAndCropQuerySQL {
    public static final String SELECT = "GermplasmIdByEventsAndGenusSpecies.Select";
    public static final String GERMPLASM_ID_ALIAS = "germplasmId";
}
