package com.monsanto.tps.lexicon.regulatory.event.strategy;

import com.monsanto.tps.lexicon.event.EventInfo;

/**
 * nbwald - Jan 30, 2009 11:45:14 AM
 */
public interface EventInfoByMonNumberStrategy
{
   EventInfo find(String monNumberValue);
}
