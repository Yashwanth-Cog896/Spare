/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.eventtraitservice.business;

import com.monsanto.tps.lexicon.eventtraitservice.transfer.GermplasmEventTrait;
import com.monsanto.tps.lexicon.eventtraitservice.transfer.GermplasmEventTraitResponse;
import com.monsanto.tps.lexicon.eventtraitservice.transfer.TraitStack;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitStack;
import com.monsanto.tps.lexicon.regulatory.commercialtrait.dao.CommercialTraitDao;
import org.apache.commons.lang.StringUtils;

import java.util.List;

/* vvkalu - 8/1/11 */
public class ComlTraitStackBuilder {
    private CommercialTraitDao commercialTraitDao;

    public GermplasmEventTraitResponse buildComlTraitStack(Long germplasmId, long comlTraitStackId, ComlTraitStack comlTraitStack,
                                                           GermplasmEventTraitResponse traitEventConstructs) {
        GermplasmEventTrait germplasmEventTrait = new GermplasmEventTrait();
        germplasmEventTrait.setGermplasmId(germplasmId);
        List<String> comTraitTypeDesc = commercialTraitDao.getComTraitTypeDescByComlTraitStackId(comlTraitStackId);
        buildCommercialTraitStack(comlTraitStack, comTraitTypeDesc, germplasmEventTrait);
        traitEventConstructs.getGermplasmEventTraits().add(germplasmEventTrait);
        return traitEventConstructs;
    }

    private void buildCommercialTraitStack(ComlTraitStack comlTraitStack,
                                           List<String> comTraitTypeDesc,
                                           GermplasmEventTrait germplasmEventTrait) {
        TraitStack traitStack = new TraitStack();
        traitStack.setComlTraitStackId(comlTraitStack.getComlTraitStackId());
        traitStack.setManfTraitCode(comlTraitStack.getManfTraitCode());
        traitStack.setReportingName(comlTraitStack.getReportingName());
        traitStack.setStackDesc(comlTraitStack.getStackDesc());
        traitStack.setTraitTypeDesc(buildTraitTypeDesc(comTraitTypeDesc));
        germplasmEventTrait.setTraitStack(traitStack);
    }

    private String buildTraitTypeDesc(List<String> comTraitTypeDesc) {
        if (comTraitTypeDesc != null && !comTraitTypeDesc.isEmpty()) {
            return StringUtils.join(comTraitTypeDesc, ", ");
        }
        return null;
    }

    public void setCommercialTraitDao(CommercialTraitDao commercialTraitDao) {
        this.commercialTraitDao = commercialTraitDao;
    }
}