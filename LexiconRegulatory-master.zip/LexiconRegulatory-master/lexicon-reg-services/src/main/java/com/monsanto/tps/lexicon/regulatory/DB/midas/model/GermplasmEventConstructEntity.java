/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.DB.midas.model;

/* vvkalu - 7/29/11 */
public class GermplasmEventConstructEntity {
    private long id;
    private EventConstructEntity eventConstruct;
    private GermplasmEntity germplasm;

    public GermplasmEntity getGermplasm() {
        return germplasm;
    }

    public void setGermplasm(GermplasmEntity germplasm) {
        this.germplasm = germplasm;
    }

    public EventConstructEntity getEventConstruct() {
        return eventConstruct;
    }

    public void setEventConstruct(EventConstructEntity eventConstruct) {
        this.eventConstruct = eventConstruct;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
}