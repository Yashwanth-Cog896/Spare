/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model;

import java.io.Serializable;

/* vvkalu - 7/25/11 */
public class LexiconProductStageEntity implements Serializable {
    private long productStageId;
    private String productStagePubkey;
    private String commercialName;
    private Double commercialMaturity;
    private boolean active;
    private boolean logicalDelete;
    private LexiconProductEntity preComlProduct;
    private Country country;
    private ComlTraitStack comlTraitStack;
    private LexiconStageEntity stage;
    private LexiconBrandEntity brand;

    public LexiconBrandEntity getBrand() {
        return brand;
    }

    public void setBrand(LexiconBrandEntity brand) {
        this.brand = brand;
    }

    public LexiconStageEntity getStage() {
        return stage;
    }

    public void setStage(LexiconStageEntity stage) {
        this.stage = stage;
    }

    public ComlTraitStack getComlTraitStack() {
        return comlTraitStack;
    }

    public void setComlTraitStack(ComlTraitStack comlTraitStack) {
        this.comlTraitStack = comlTraitStack;
    }

    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }

    public LexiconProductEntity getPreComlProduct() {
        return preComlProduct;
    }

    public void setPreComlProduct(LexiconProductEntity preComlProduct) {
        this.preComlProduct = preComlProduct;
    }

    public boolean getLogicalDelete() {
        return logicalDelete;
    }

    public void setLogicalDelete(boolean logicalDelete) {
        this.logicalDelete = logicalDelete;
    }

    public boolean getActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public Double getCommercialMaturity() {
        return commercialMaturity;
    }

    public void setCommercialMaturity(Double commercialMaturity) {
        this.commercialMaturity = commercialMaturity;
    }

    public String getCommercialName() {
        return commercialName;
    }

    public void setCommercialName(String commercialName) {
        this.commercialName = commercialName;
    }

    public String getProductStagePubkey() {
        return productStagePubkey;
    }

    public void setProductStagePubkey(String productStagePubkey) {
        this.productStagePubkey = productStagePubkey;
    }

    public long getProductStageId() {
        return productStageId;
    }

    public void setProductStageId(long productStageId) {
        this.productStageId = productStageId;
    }
}