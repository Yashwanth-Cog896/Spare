package com.monsanto.tps.lexicon.regulatory.event.query;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tcc.lexiconcommon.exception.RuntimeWrappingException;
import com.monsanto.tps.lexicon.regulatory.DB.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.tps.lexicon.regulatory.event.dao.eventconstructtransformation.midas.MidasRegulatoryEventConstructTransformationByEventNameAndCropQuerySQL;
import com.monsanto.tps.lexicon.regulatory.event.dao.eventconstructtransformation.midas.RegulatoryEventConstructTransformationWithoutTransformationBackgroundPSRowImpl;
import com.monsanto.tps.lexicon.regulatory.event.model.RegulatoryEventConstructTransformation;

import java.util.List;

/**
 * nbwald - Feb 17, 2009 3:25:46 PM
 */
public class MidasRegulatoryEventConstructTransformationsByEventAndCropQuery
   extends AbstractPersistentStoreMultiRowQuery
{
   private String eventName;
   private String cropGenusSpecies;

   public MidasRegulatoryEventConstructTransformationsByEventAndCropQuery(String eventName, String cropGenusSpecies) {
      this.eventName = eventName;
      this.cropGenusSpecies = cropGenusSpecies;
   }

   public RegulatoryEventConstructTransformation[] find() {
      try {
         List eventConstructTransformations = getList();
         return (RegulatoryEventConstructTransformation[]) eventConstructTransformations.toArray(new RegulatoryEventConstructTransformation[eventConstructTransformations.size()]);
      }
      catch (WrappingException e) {
         throw new RuntimeWrappingException(e);
      }
   }

   @Override
   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return new RegulatoryEventConstructTransformationWithoutTransformationBackgroundPSRowImpl(row);
   }

   @Override
   protected String getSQL()
      throws WrappingException
   {
      SQLPropFile sqlPropFile = new SQLPropFile(MidasRegulatoryEventConstructTransformationByEventNameAndCropQuerySQL.class);
      return sqlPropFile.getSQL(MidasRegulatoryEventConstructTransformationByEventNameAndCropQuerySQL.SELECT_ALL);
   }

   @Override
   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[]{eventName, cropGenusSpecies};
   }

   @Override
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MidasConnectionFactoryProperties();
   }
}
