package com.monsanto.tps.lexicon.regulatory.agency.service;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tps.aop.metric.DataPointHolder;
import com.monsanto.tps.aop.metric.PerformanceMetric;
import com.monsanto.tps.lexicon.agency.Agency;
import com.monsanto.tps.lexicon.agency.AgencySaveUpdateBatchRequest;
import com.monsanto.tps.lexicon.agency.AgencySaveUpdateResponse;
import com.monsanto.tps.lexicon.agency.AgencySearchCriteria;
import com.monsanto.tps.lexicon.agency.AgencyService;
import com.monsanto.tps.lexicon.regulatory.agency.dao.AgencyDao;
import com.monsanto.tps.lexicon.regulatory.agency.util.AgencyBeanUtil;
import com.monsanto.tps.lexicon.regulatory.agency.validation.AgencySearchCriteriaValidator;

import javax.jws.WebService;
import java.util.ArrayList;
import java.util.List;

/**
 * rrchak1 - Oct 10, 2008 10:37:21 AM
 */
@WebService(endpointInterface = "com.monsanto.tps.lexicon.agency.AgencyService")
public class AgencyServiceImpl
   implements AgencyService
{
   private AgencyDao agencyDao;
   private AgencyBeanUtil agencyBeanUtil;
   private AgencySearchCriteriaValidator validator;
   private DataPointHolder dataPointHolder;
   private AgencySaveUpdateProcessor saveUpdateProcessor;

   @PerformanceMetric(task = "Agency POS", comment = "Agency Search")
   public Agency[] findBySearchCriteria(AgencySearchCriteria agencySearchCriteria)
      throws WrappingException, IllegalArgumentException
   {
      validator.validate(agencySearchCriteria);
      Agency[] agencies = agencyBeanUtil.buildAgencies(agencyDao.findDepartmentsBySearchCriteria(agencySearchCriteria));
      dataPointHolder.add("Num Retrieved", agencies.length);
      return agencies;
   }

   public void setAgencyDao(AgencyDao agencyDao) {
      this.agencyDao = agencyDao;
   }

   public void setAgencyBeanUtil(AgencyBeanUtil agencyBeanUtil) {
      this.agencyBeanUtil = agencyBeanUtil;
   }

   public void setValidator(AgencySearchCriteriaValidator validator) {
      this.validator = validator;
   }

   public void setDataPointHolder(DataPointHolder dataPointHolder) {
      this.dataPointHolder = dataPointHolder;
   }

   public void setSaveUpdateProcessor(AgencySaveUpdateProcessor saveUpdateProcessor) {
      this.saveUpdateProcessor = saveUpdateProcessor;
   }

   public AgencySaveUpdateResponse[] saveOrValidate(AgencySaveUpdateBatchRequest batchRequest) {
      List<AgencySaveUpdateResponse> responseList = new ArrayList<AgencySaveUpdateResponse>();
      saveUpdateProcessor.save(batchRequest.getAgencySaveUpdateRequests(), agencyDao, agencyBeanUtil, responseList, batchRequest.isCommit());
      return responseList.toArray(new AgencySaveUpdateResponse[responseList.size()]);
   }

   public AgencySaveUpdateResponse[] updateOrValidate(AgencySaveUpdateBatchRequest batchRequest) {
      List<AgencySaveUpdateResponse> responseList = new ArrayList<AgencySaveUpdateResponse>();
      saveUpdateProcessor.update(batchRequest.getAgencySaveUpdateRequests(), agencyDao, agencyBeanUtil, responseList, batchRequest.isCommit());
      return responseList.toArray(new AgencySaveUpdateResponse[responseList.size()]);
   }
}
