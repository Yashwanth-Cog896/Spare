package com.monsanto.tps.lexicon.regulatory.proteinname.business;

import com.monsanto.tps.lexicon.proteinname.OrionProteinName;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName;
import com.monsanto.tps.lexicon.regulatory.proteinname.dao.ProteinNameDAO;
import com.monsanto.tps.lexicon.regulatory.util.WildcardUtil;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 3/1/12
 * Time: 2:14 PM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class ProteinNameBusiness {

    @Resource
    private ProteinNameDAO proteinNameDAO;

    public List<OrionProteinName> findProteinNames(final String proteinNameType) {
        final List<ProteinName> proteinNameTypeList = proteinNameDAO.findProteinNames(WildcardUtil.replaceAsteriskWildcardWithPercent(proteinNameType));
        final List<OrionProteinName> orionProteinNameList = new ArrayList<OrionProteinName>();

        for (ProteinName type : proteinNameTypeList) {
            orionProteinNameList.add(new OrionProteinName(type.getProteinName(), type.isActiveStatus()));
        }

        return orionProteinNameList;
    }
}

