package com.monsanto.tps.lexicon.regulatory.event.delegate;

import com.monsanto.tps.lexicon.event.Construct;
import com.monsanto.tps.lexicon.event.EventAgency;
import com.monsanto.tps.lexicon.event.EventComponent;
import com.monsanto.tps.lexicon.event.EventInfo;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;
import com.monsanto.tps.lexicon.regulatory.event.model.EventConstruct;
import com.monsanto.tps.lexicon.regulatory.event.model.RegulatoryEvent;

import java.util.ArrayList;
import java.util.List;

/**
 * nbwald - Jan 8, 2009 11:28:19 AM
 */
public class EventInfoBuilder
{
   public EventInfo build(List<RegulatoryEvent> regulatoryEvents, EventAgencyAlignment[] eventAgencyAlignments, String cropName) {
      EventInfo eventInfo = new EventInfo();
      //TODO group constructs, monNumbers & distinct events in a separate object
      eventInfo.setCrop(cropName);
      eventInfo.setEventComponents(buildEventComponents(regulatoryEvents));
      eventInfo.setEventAgencies(buildResponseEventAgencies(eventAgencyAlignments));
      return eventInfo;
   }

   private EventComponent[] buildEventComponents(List<RegulatoryEvent> regulatoryEvents) {
      List<EventComponent> eventComponentList = new ArrayList<EventComponent>();
      for (RegulatoryEvent regulatoryEvent : regulatoryEvents) {
         EventComponent eventComponent = new EventComponent();
         eventComponent.setEventName(regulatoryEvent.getEventName());
         eventComponent.setMonNumber(regulatoryEvent.getMonNumber());
         eventComponent.setConstructs(buildConstructs(regulatoryEvent.getEventConstructs()));
         eventComponentList.add(eventComponent);
      }
      return eventComponentList.toArray(new EventComponent[eventComponentList.size()]);
   }

   private Construct[] buildConstructs(EventConstruct[] eventConstructs) {
      List<Construct> constructs = new ArrayList<Construct>();
      for (EventConstruct eventConstruct : eventConstructs) {
         Construct construct = new Construct();
         construct.setPlasmidPMon(eventConstruct.getConstruct());
         construct.setPlasmidPVCode(renderTransCodes(eventConstruct.getTransCodes()));
         constructs.add(construct);
      }
      return constructs.toArray(new Construct[constructs.size()]);
   }

   private EventAgency[] buildResponseEventAgencies(EventAgencyAlignment[] eventAgencyAlignments) {
      EventAgencies eventAgencies = new EventAgencies(eventAgencyAlignments);
      return eventAgencies.getResponseEventAgencies();
   }

   private String renderTransCodes(String[] transCodeArray) {
      TransCodes transCodes = new TransCodes(transCodeArray);
      return transCodes.getDisplayText();
   }
}
