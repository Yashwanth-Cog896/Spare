package com.monsanto.tps.lexicon.regulatory.event.query;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tcc.lexiconcommon.exception.RuntimeWrappingException;
import com.monsanto.tps.lexicon.regulatory.DB.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.tps.lexicon.regulatory.event.dao.eventconstructtransformation.midas.MidasRegulatoryEventConstructTransformationByEventNameAndCropQuerySQL;
import com.monsanto.tps.lexicon.regulatory.event.dao.eventconstructtransformation.midas.RegulatoryEventConstructTransformationWithoutTransformationBackgroundPSRowImpl;
import com.monsanto.tps.lexicon.regulatory.event.model.RegulatoryEventConstructTransformation;

import java.util.List;

/**
 * rrchak1 - Jul 10, 2009 3:53:13 PM
 */
public class MidasEventConstructsByStackedEventGermplasmAndCropQuery
   extends AbstractPersistentStoreMultiRowQuery
{

   private String cropGenusSpecies;
   private long germplasmId;

   public MidasEventConstructsByStackedEventGermplasmAndCropQuery(long germplasmId, String cropGenusSpecies) {
      this.germplasmId = germplasmId;
      this.cropGenusSpecies = cropGenusSpecies;
   }

   @Override
   protected Object createObjectFromRow(PersistentStoreResultSetRow persistentStoreResultSetRow)
      throws WrappingException
   {
      return new RegulatoryEventConstructTransformationWithoutTransformationBackgroundPSRowImpl(persistentStoreResultSetRow);
   }

   @Override
   protected String getSQL()
      throws WrappingException
   {
      return mergeQueries();
   }

   private String mergeQueries()
      throws WrappingException
   {
      SQLPropFile sqlPropFile = new SQLPropFile(MidasRegulatoryEventConstructTransformationByEventNameAndCropQuerySQL.class);
      return sqlPropFile.getSQL(MidasRegulatoryEventConstructTransformationByEventNameAndCropQuerySQL.SELECT_EVENT_CONSTRUCTS_STACKED_EVENT_GERMPLASM);
   }

   @Override
   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[]{cropGenusSpecies, germplasmId};
   }

   @Override
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MidasConnectionFactoryProperties();
   }

   public RegulatoryEventConstructTransformation[] find() {
      try {
         List eventConstructTransformations = getList();
         return (RegulatoryEventConstructTransformation[]) eventConstructTransformations.toArray(new RegulatoryEventConstructTransformation[eventConstructTransformations.size()]);
      }
      catch (WrappingException e) {
         throw new RuntimeWrappingException(e);
      }
   }

}
