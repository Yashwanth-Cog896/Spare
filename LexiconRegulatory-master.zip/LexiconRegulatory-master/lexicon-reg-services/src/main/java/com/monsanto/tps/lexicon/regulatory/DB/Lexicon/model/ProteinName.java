package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model;

/**
 * Created by IntelliJ IDEA.
 * User: gdleon
 * Date: Apr 21, 2009
 * Time: 12:37:29 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProteinName {
    private long proteinNameId;
    private String proteinName;
    private boolean activeStatus;
    private String proteinNamePubkey;
    private String proteinDescription;
    private String origSourceOrganism;

    public ProteinName() {
    }

    public ProteinName(String proteinName, boolean activeStatus, String proteinNamePubkey, String proteinDescription, String origSourceOrganism) {
        this.proteinName = proteinName;
        this.activeStatus = activeStatus;
        this.proteinNamePubkey = proteinNamePubkey;
        this.proteinDescription = proteinDescription;
        this.origSourceOrganism = origSourceOrganism;
    }

    public long getProteinNameId() {
        return proteinNameId;
    }

    public void setProteinNameId(long proteinNameId) {
        this.proteinNameId = proteinNameId;
    }

    public String getProteinName() {
        return proteinName;
    }

    public void setProteinName(String proteinName) {
        this.proteinName = proteinName;
    }

    public boolean isActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(boolean activeStatus) {
        this.activeStatus = activeStatus;
    }

    public String getProteinNamePubkey() {
        return proteinNamePubkey;
    }

    public void setProteinNamePubkey(String proteinNamePubkey) {
        this.proteinNamePubkey = proteinNamePubkey;
    }

    public String getProteinDescription() {
        return proteinDescription;
    }

    public void setProteinDescription(String proteinDescription) {
        this.proteinDescription = proteinDescription;
    }

    public String getOrigSourceOrganism() {
        return origSourceOrganism;
    }

    public void setOrigSourceOrganism(String origSourceOrganism) {
        this.origSourceOrganism = origSourceOrganism;
    }
}
