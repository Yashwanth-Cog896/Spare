package com.monsanto.tps.lexicon.regulatory.event.dao.eventconstructtransformation.midas;

/**
 * User: pjberry
 * Date: Jul 26, 2007
 * Time: 11:00:04 AM
 */
public interface MidasRegulatoryEventConstructTransformationByEventNameAndCropQuerySQL
{
   String SELECT = "EventConstructTransformation.Select";
   String SELECT_ALL = "EventConstructTransformation.SelectAll";
   String SELECT_GERMPLASM_ID_BY_EVENT = "Germplasm.By.Event";
   String SELECT_EVENT_CONSTRUCTS_STACKED_EVENT_GERMPLASM = "EventConstruct.Select.EventConstructs.By.StackedEventGermplasm";
   String GERMPLASM_ID_ALIAS = "germplasmId";
}
