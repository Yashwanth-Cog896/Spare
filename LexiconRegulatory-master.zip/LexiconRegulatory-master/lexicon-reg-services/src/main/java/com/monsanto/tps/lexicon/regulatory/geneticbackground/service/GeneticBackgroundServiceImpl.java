package com.monsanto.tps.lexicon.regulatory.geneticbackground.service;

import com.monsanto.tps.lexicon.geneticbackground.GeneticBackgroundService;
import com.monsanto.tps.lexicon.geneticbackground.OrionGeneticBackground;
import com.monsanto.tps.lexicon.regulatory.geneticbackground.business.GeneticBackgroundBusiness;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 3/1/12
 * Time: 2:14 PM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class GeneticBackgroundServiceImpl implements GeneticBackgroundService {

    @Resource
    private GeneticBackgroundBusiness geneticBackgroundBusiness;

    @Override
    public List<OrionGeneticBackground> findGeneticBackgrounds(final String geneticBackground) {
        return geneticBackgroundBusiness.findGeneticBackgrounds(geneticBackground);
    }
}
