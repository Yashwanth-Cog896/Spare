package com.monsanto.tps.lexicon.regulatory.monnumber.dao;

import com.monsanto.tps.lexicon.monnumber.MonNumberInfo;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumberConstruct;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * nbwald - Jan 7, 2009 4:33:39 PM
 */
public class MonNumberDaoImpl
   implements MonNumberDao
{
   private SessionFactory sessionFactory;

   public MonNumber find(String monNumberValue) {
      Session session = sessionFactory.getCurrentSession();
      return (MonNumber) session.getNamedQuery("monNumber.byMonNumber").setString(0, StringUtils.upperCase(monNumberValue)).uniqueResult();
   }

   public MonNumber findByEventAndCrop(String eventName, String cropName) {
      Session session = sessionFactory.getCurrentSession();
      return (MonNumber) session.getNamedQuery("monNumber.byEventAndCrop")
         .setString(0, StringUtils.upperCase(eventName))
         .setString(1, StringUtils.upperCase(cropName))
         .uniqueResult();
   }

   public MonNumber[] findByCrop(String cropPubkey) {
      Session session = sessionFactory.getCurrentSession();
      List<MonNumber> monNumbers = session.getNamedQuery("monNumbers.byCropPubkeyAndStatus")
         .setString(0, StringUtils.upperCase(cropPubkey))
         .setBoolean(1, true)
         .list();
      return monNumbers.toArray(new MonNumber[monNumbers.size()]);
   }

   public MonNumber[] findByMonNumber(String monNumber) {
      Session session = sessionFactory.getCurrentSession();
      List<MonNumber> monNumbers = session.getNamedQuery("monNumbers.byMonNumberAndStatus")
         .setString(0, monNumber)
         .setBoolean(1, true)
         .list();
      return monNumbers.toArray(new MonNumber[monNumbers.size()]);
   }

   public MonNumber[] findByMonNumberAndCrop(String monNumber, String cropPubkey) {
      Session session = sessionFactory.getCurrentSession();
      List<MonNumber> monNumbers = session.getNamedQuery("monNumbers.byMonNumberCropPubkeyAndStatus")
         .setString(0, monNumber)
         .setString(1, cropPubkey)
         .setBoolean(2, true)
         .list();
      return monNumbers.toArray(new MonNumber[monNumbers.size()]);
   }

   public MonNumber[] findByConstruct(String[] constructs) {
      Session session = sessionFactory.getCurrentSession();
      Criteria criteria = session.createCriteria(MonNumberConstruct.class);
      Disjunction disjunction = Restrictions.disjunction();
      for (String queryParameter : constructs) {
         MonNumberConstruct construct = new MonNumberConstruct();
         construct.setConstructName(queryParameter);
         Example queryExample = Example.create(construct);
         queryExample.enableLike(MatchMode.ANYWHERE);
         disjunction.add(queryExample);
      }
      criteria.add(disjunction);

      List<MonNumberConstruct> possibleConstructs = criteria.list();
      List<String> constructsList = java.util.Arrays.asList(constructs);
      Set<MonNumber> matchingMonNumbers = new HashSet<MonNumber>();
      for (MonNumberConstruct constructCandidate : possibleConstructs) {
         String[] individualConstructs = constructCandidate.getConstructName().split(",");
         for (String specificConstruct : individualConstructs) {
            if ((Collections.frequency(constructsList, specificConstruct.trim()) > 0) &&
               (constructCandidate.getMonNumber().isActiveStatus())) {
               matchingMonNumbers.add(constructCandidate.getMonNumber());
               break;
            }
         }
      }

      return matchingMonNumbers.toArray(new MonNumber[matchingMonNumbers.size()]);
   }

   public MonNumber[] findByPvCode(String[] pvCodes) {
      Session session = sessionFactory.getCurrentSession();
      Criteria criteria = session.createCriteria(MonNumberConstruct.class);
      Disjunction disjunction = Restrictions.disjunction();
      for (String queryParameter : pvCodes) {
         MonNumberConstruct construct = new MonNumberConstruct();
         construct.setPvCode(queryParameter);
         Example queryExample = Example.create(construct);
         queryExample.enableLike(MatchMode.ANYWHERE);
         disjunction.add(queryExample);
      }
      criteria.add(disjunction);

      List<MonNumberConstruct> possibleConstructs = criteria.list();
      List<String> pvCodesList = java.util.Arrays.asList(pvCodes);
      Set<MonNumber> matchingMonNumbers = new HashSet<MonNumber>();
      for (MonNumberConstruct constructCandidate : possibleConstructs) {
         String[] individualPvCodes = constructCandidate.getPvCode().split(",");
         for (String specificPvCode : individualPvCodes) {
            if ((Collections.frequency(pvCodesList, specificPvCode.trim()) > 0) &&
               (constructCandidate.getMonNumber().isActiveStatus())) {
               matchingMonNumbers.add(constructCandidate.getMonNumber());
               break;
            }
         }
      }

      return matchingMonNumbers.toArray(new MonNumber[matchingMonNumbers.size()]);
   }

   public void setSessionFactory(SessionFactory sessionFactory) {
      this.sessionFactory = sessionFactory;
   }

   public MonNumber[] findAll() {
      Session session = sessionFactory.getCurrentSession();
      List<MonNumber> monNumbers = session.getNamedQuery("all.monNumbers").list();
      return monNumbers.toArray(new MonNumber[monNumbers.size()]);
   }

   public MonNumber save(MonNumber monNumber) {
      Session session = sessionFactory.getCurrentSession();
      session.save(monNumber);
      return monNumber;
   }

   public MonNumberConstruct saveMonNumberConstruct(MonNumberConstruct monNumberConstruct) {
      Session session = sessionFactory.getCurrentSession();
      session.save(monNumberConstruct);
      return monNumberConstruct;
   }

   @Override
   //TODO will be moved
   public ProteinName findProteinNameByPubkey(String proteinPubkey) {
      Session session = sessionFactory.getCurrentSession();
      return (ProteinName) session.createQuery("from ProteinName as proteinName where proteinName.proteinNamePubkey = ?").setString(0, proteinPubkey).uniqueResult();
   }

   public MonNumber findByEvent(String eventName) {
      Session session = sessionFactory.getCurrentSession();
      return (MonNumber) session.getNamedQuery("monNumber.byEvent").setString(0, StringUtils.upperCase(eventName)).uniqueResult();
   }

   public MonNumber findByOecdNumber(String oecdNumber) {
      Session session = sessionFactory.getCurrentSession();
      return (MonNumber) session.getNamedQuery("monNumber.byOecdNumber").setString(0, StringUtils.upperCase(oecdNumber)).uniqueResult();
   }

   public MonNumberConstruct[] findMonNumberConstructByName(String constructName) {
      Session session = sessionFactory.getCurrentSession();
      Query query = session.getNamedQuery("monNumberConstruct.byConstructName");
      List<MonNumberConstruct> monNumberConstructList = query.setString(0, StringUtils.upperCase(constructName)).list();
      return monNumberConstructList.toArray(new MonNumberConstruct[monNumberConstructList.size()]);
   }

   public List<MonNumberInfo> findByEventsAndCrop(String[] events, String cropName) {
      Session session = sessionFactory.getCurrentSession();
      Query query = session.getNamedQuery("monNumberInfo.byEventsAndCropName").
         setParameterList("events", toUpperCase(events)).
         setParameter("cropName", cropName.toUpperCase()).
         setResultTransformer(Transformers.aliasToBean(MonNumberInfo.class));
      return query.list();
   }

   public List<MonNumberInfo> findByMonNumbers(String[] monNumbers) {
      Session session = sessionFactory.getCurrentSession();
      Query query = session.getNamedQuery("monNumberInfo.byMonNumbers").
         setParameterList("monNumbers", toUpperCase(monNumbers)).
         setResultTransformer(Transformers.aliasToBean(MonNumberInfo.class));
      return query.list();

   }

    @Override
    public List<MonNumber> getMonNumbersByEventNames(long requestId) {
        Session session = sessionFactory.getCurrentSession();
        Query query = session.getNamedQuery("getMonNumbersByEventNames.byEventNames").
        setParameter("requestId", requestId);
        return (List<MonNumber>) query.list();
    }

    @Override
    public List<MonNumber> getMonNumbersByMonNumber(long requestId) {
        Session session = sessionFactory.getCurrentSession();
        Query query = session.getNamedQuery("getMonNumbersByMonNumber.byMonNumber").
          setParameter("requestId", requestId);
        return (List<MonNumber>) query.list();
    }

    private Collection<String> toUpperCase(String[] strings) {
      Collection<String> uppercasedStrings = new ArrayList<String>();
      for (String string : strings) {
         uppercasedStrings.add(com.monsanto.Util.StringUtils.toUpperCaseNull(string));
      }
      return uppercasedStrings;
   }
}
