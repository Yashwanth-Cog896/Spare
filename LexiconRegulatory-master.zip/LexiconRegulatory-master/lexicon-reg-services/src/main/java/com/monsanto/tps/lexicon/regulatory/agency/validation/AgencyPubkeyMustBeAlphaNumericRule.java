package com.monsanto.tps.lexicon.regulatory.agency.validation;

import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;
import org.apache.commons.lang.ArrayUtils;

/**
 * rrchak1 - Oct 21, 2008 3:38:21 PM
 */
public class AgencyPubkeyMustBeAlphaNumericRule
   implements Rule
{
   private String[] agencyPubkey;

   public AgencyPubkeyMustBeAlphaNumericRule(String[] agencyPubkey) {
      this.agencyPubkey = agencyPubkey;
   }

   public boolean violated() {
      if (!ArrayUtils.isEmpty(agencyPubkey)) {
         for (String pubkey : agencyPubkey) {
            if (!pubkey.matches("^[a-zA-Z0-9]+$")) {
               return true;
            }
         }
      }
      return false;
   }

   public Object getViolation() {
      return "Agency Pubkey must contain only AlphaNumeric characters.";
   }
}
