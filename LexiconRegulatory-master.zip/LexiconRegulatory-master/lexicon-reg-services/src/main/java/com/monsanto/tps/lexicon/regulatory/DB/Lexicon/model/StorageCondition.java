package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 3/6/12
 * Time: 12:06 PM
 * To change this template use File | Settings | File Templates.
 */
public class StorageCondition {

    private long storageConditionId;
    private String storageCondition;
    private boolean activeStatus;

    public long getStorageConditionId() {
        return storageConditionId;
    }

    public StorageCondition() {
    }

    public StorageCondition(String storageCondition, boolean activeStatus) {
        this.storageCondition = storageCondition;
        this.activeStatus = activeStatus;
    }

    public final String getStorageCondition() {
        return storageCondition;
    }

    public final void setStorageCondition(String storageCondition) {
        this.storageCondition = storageCondition;
    }

    public final boolean getActiveStatus() {
        return activeStatus;
    }

    public final void setActiveStatus(boolean activeStatus) {
        this.activeStatus = activeStatus;
    }

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
    }
}


