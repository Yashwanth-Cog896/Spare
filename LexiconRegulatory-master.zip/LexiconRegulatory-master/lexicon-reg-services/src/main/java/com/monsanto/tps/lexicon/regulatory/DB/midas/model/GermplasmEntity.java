/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.DB.midas.model;

import java.io.Serializable;
import java.util.Collection;

/* vvkalu - 7/22/11 */
public class GermplasmEntity implements Serializable {
    private long id;
    private LineTypeEntity lineType;
    private boolean deleted;
    private boolean finished;
    private String eventDisplay;
    private String origin;
    private String linecode;
    private MidasCropEntity crop;
    private String pedigree;
    private boolean transgenic;
    private ProgramEntity ownerProgram;
    private Collection<ProductGermplasmEntity> productGermplasms;

    public MidasCropEntity getCrop() {
        return crop;
    }

    public void setCrop(MidasCropEntity crop) {
        this.crop = crop;
    }

    public Collection<ProductGermplasmEntity> getProductGermplasms() {
        return productGermplasms;
    }

    public void setProductGermplasms(Collection<ProductGermplasmEntity> productGermplasms) {
        this.productGermplasms = productGermplasms;
    }

    public ProgramEntity getOwnerProgram() {
        return ownerProgram;
    }

    public void setOwnerProgram(ProgramEntity ownerProgram) {
        this.ownerProgram = ownerProgram;
    }

    public boolean isTransgenic() {
        return transgenic;
    }

    public void setTransgenic(boolean transgenic) {
        this.transgenic = transgenic;
    }

    public String getPedigree() {
        return pedigree;
    }

    public void setPedigree(String pedigree) {
        this.pedigree = pedigree;
    }

    public String getLinecode() {
        return linecode;
    }

    public void setLinecode(String linecode) {
        this.linecode = linecode;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getEventDisplay() {
        return eventDisplay;
    }

    public void setEventDisplay(String eventDisplay) {
        this.eventDisplay = eventDisplay;
    }

    public boolean isFinished() {
        return finished;
    }

    public void setFinished(boolean finished) {
        this.finished = finished;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    public LineTypeEntity getLineType() {
        return lineType;
    }

    public void setLineType(LineTypeEntity lineType) {
        this.lineType = lineType;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
}