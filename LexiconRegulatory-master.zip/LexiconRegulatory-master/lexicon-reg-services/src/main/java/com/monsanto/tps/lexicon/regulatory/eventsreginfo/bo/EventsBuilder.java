package com.monsanto.tps.lexicon.regulatory.eventsreginfo.bo;

import com.monsanto.tps.lexicon.eventsreginfo.transfer.EventRegInfo;
import com.monsanto.tps.lexicon.regulatory.eventsreginfo.domain.lexicon.LexiconRegEvent;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: VVKALU
 * Date: Oct 6, 2010
 * Time: 5:30:29 PM
 * To change this template use File | Settings | File Templates.
 */
public class EventsBuilder {

    public List<EventRegInfo> build(List<LexiconRegEvent> monNumbersList) {
        List<EventRegInfo> monAndNonMonEventRegInfos = new ArrayList<EventRegInfo>();
        if (monNumbersList != null) {
            for (LexiconRegEvent lexiconRegEvent : monNumbersList) {
                buildEventRegInfo(monAndNonMonEventRegInfos, lexiconRegEvent);
            }
        }
        return monAndNonMonEventRegInfos;
    }

    private void buildEventRegInfo(List<EventRegInfo> monAndNonMonEventRegInfos, LexiconRegEvent lexiconRegEvent) {
        EventRegInfo info = new EventRegInfo();
        info.setActiveStatus(lexiconRegEvent.getActiveStatus());
        info.setMonNumberId(lexiconRegEvent.getMonNumberId());
        info.setCrop(lexiconRegEvent.getCrop());
        info.setEvent(lexiconRegEvent.getEvent());
        info.setJvNumber(lexiconRegEvent.getJvNumber());
        info.setMaterialName(lexiconRegEvent.getMaterialName());
        info.setMonNumber(lexiconRegEvent.getMonNumber());
        info.setOecdNumber(lexiconRegEvent.getOecdNumber());
        info.setOecdNumberCommunicationDate(lexiconRegEvent.getOecdNumberCommunicationDate());
        info.setPlasmidPMON(lexiconRegEvent.getPlasmIdPmon());
        info.setPlasmidPVCode(lexiconRegEvent.getPlasmIdPvCode());
        info.setPreviousNames(lexiconRegEvent.getPreviousNames());
        info.setRegulatedStatus(lexiconRegEvent.getRegulatedStatus());
        info.setRegulatoryGenesPresent(lexiconRegEvent.getRegulatoryGenesPresent());
        info.setRegulatoryTraitDescription(lexiconRegEvent.getRegulatoryTraitDescription());
        info.setTransformationBackground(lexiconRegEvent.getTransformationBackground());
        monAndNonMonEventRegInfos.add(info);
    }
}
