package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 6/28/12
 * Time: 9:15 AM
 */
public class PlantProduct {
    private String name;
    private String crop;

    public PlantProduct() {}

    public PlantProduct(String name, String crop) {
        this.name = name;
        this.crop = crop;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCrop() {
        return crop;
    }

    public void setCrop(String crop) {
        this.crop = crop;
    }
}
