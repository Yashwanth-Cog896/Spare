package com.monsanto.tps.lexicon.regulatory.plantname.business;

import com.monsanto.tps.lexicon.plantname.OrionPlantProduct;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.PlantProduct;
import com.monsanto.tps.lexicon.regulatory.plantname.dao.RegulatorySeedMaterialDAO;
import com.monsanto.tps.lexicon.regulatory.util.WildcardUtil;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 6/19/12
 * Time: 10:06 PM
 */
@Component
public class RegulatorySeedMaterialBusiness {
    @Resource
    private RegulatorySeedMaterialDAO regulatorySeedMaterialDAO;

    public List<OrionPlantProduct> findPlantNames(String productName) {
        final List<PlantProduct> plantNameTypeList = regulatorySeedMaterialDAO.findMonsantoProductNames(WildcardUtil.replaceAsteriskWildcardWithPercent(productName));
        final List<PlantProduct> nonMonsantoPlantNames = regulatorySeedMaterialDAO.findCompetitorProductNames(WildcardUtil.replaceAsteriskWildcardWithPercent(productName));
        final List<OrionPlantProduct> orionPlantNameList = new ArrayList<OrionPlantProduct>();

        addProducts(plantNameTypeList, orionPlantNameList);
        addProducts(nonMonsantoPlantNames, orionPlantNameList);

        return orionPlantNameList;
    }

    private void addProducts(List<PlantProduct> plantNameTypeList, List<OrionPlantProduct> orionPlantNameList) {
        for (PlantProduct type : plantNameTypeList) {
            orionPlantNameList.add(new OrionPlantProduct(type.getName(), type.getCrop()));
        }
    }
}
