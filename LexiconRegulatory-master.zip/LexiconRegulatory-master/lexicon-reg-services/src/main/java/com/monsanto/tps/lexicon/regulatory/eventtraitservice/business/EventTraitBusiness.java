/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.eventtraitservice.business;

import com.monsanto.tps.lexicon.eventtraitservice.transfer.GermplasmEventTraitResponse;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitStack;
import com.monsanto.tps.lexicon.regulatory.commercialtrait.dao.CommercialTraitDao;
import com.monsanto.tps.lexicon.regulatory.eventtraitservice.dao.EventConstructTraitStackDao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/* vvkalu - 7/26/11 */
public class EventTraitBusiness {

    private ComlTraitStackBuilder comlTraitStackBuilder;
    private EventConstructTraitStackDao eventConstructTraitStackDao;
    private CommercialTraitDao commercialTraitDao;

    public List<Long> getComTraitStackIdByEventConstructs(long germplasmId) {
        List<Long> traitStackIds = new ArrayList<Long>();
        for (BigDecimal id : eventConstructTraitStackDao.getComTraitStackIdByEventConstructs(germplasmId)) {
            traitStackIds.add(id.longValue());
        }
        return traitStackIds;
    }

    public GermplasmEventTraitResponse getComlTraitForEvents(Long germplasmId, GermplasmEventTraitResponse traitEventConstructs) {
        List<BigDecimal> comlTraitStackIds = eventConstructTraitStackDao.getComTraitStackIdByEventConstructs(germplasmId);
        if (comlTraitStackIds != null && !comlTraitStackIds.isEmpty() && !(comlTraitStackIds.size() >= 2)) {
            long comlTraitStackId = comlTraitStackIds.get(0).longValue();
            ComlTraitStack comlTraitStack = commercialTraitDao.getComlTraitStackById(comlTraitStackId);
            return comlTraitStack != null ?
                    comlTraitStackBuilder.buildComlTraitStack(germplasmId, comlTraitStackId, comlTraitStack, traitEventConstructs) :
                    traitEventConstructs;
        }
        return traitEventConstructs;
    }

    public void setComlTraitStackBuilder(ComlTraitStackBuilder comlTraitStackBuilder) {
        this.comlTraitStackBuilder = comlTraitStackBuilder;
    }

    public void setEventConstructTraitStackDao(EventConstructTraitStackDao eventConstructTraitStackDao) {
        this.eventConstructTraitStackDao = eventConstructTraitStackDao;
    }

    public void setCommercialTraitDao(CommercialTraitDao commercialTraitDao) {
        this.commercialTraitDao = commercialTraitDao;
    }
}