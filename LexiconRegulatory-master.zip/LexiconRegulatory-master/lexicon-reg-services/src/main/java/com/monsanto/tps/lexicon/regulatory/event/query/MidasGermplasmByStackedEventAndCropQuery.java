package com.monsanto.tps.lexicon.regulatory.event.query;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.tcc.lexiconcommon.exception.RuntimeWrappingException;
import com.monsanto.tps.lexicon.regulatory.DB.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.tps.lexicon.regulatory.event.dao.eventconstructtransformation.midas.MidasGermplasmByStackedEventAndCropQuerySQL;
import com.monsanto.tps.lexicon.regulatory.event.dao.eventconstructtransformation.midas.MidasRegulatoryEventConstructTransformationByEventNameAndCropQuerySQL;

import java.util.List;

/**
 * rrchak1 - Jul 15, 2009 5:09:21 PM
 */
public class MidasGermplasmByStackedEventAndCropQuery
   extends AbstractPersistentStoreSingleResultQuery 

{

   private String stackedEvent;
   private String cropGenusSpecies;

   public MidasGermplasmByStackedEventAndCropQuery(String stackedEvent,String cropGenusSpecies) {
      this.stackedEvent = stackedEvent;
      this.cropGenusSpecies = cropGenusSpecies;
   }

   @Override
   protected Object createObjectFromRow(PersistentStoreResultSetRow persistentStoreResultSetRow)
      throws WrappingException
   {
      SQLPropFile sqlPropFile = new SQLPropFile(MidasRegulatoryEventConstructTransformationByEventNameAndCropQuerySQL.class);
      return persistentStoreResultSetRow.getLong(sqlPropFile.getAlias(MidasGermplasmByStackedEventAndCropQuerySQL.GERMPLASM_ID_ALIAS));
   }

   @Override
   protected String getSQL()
      throws WrappingException
   {
       SQLPropFile sqlPropFile = new SQLPropFile(MidasGermplasmByStackedEventAndCropQuerySQL.class);
        return sqlPropFile.getSQL(MidasGermplasmByStackedEventAndCropQuerySQL.SELECT);
   }

   @Override
   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[]{cropGenusSpecies, stackedEvent.toUpperCase()};
   }

   @Override
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MidasConnectionFactoryProperties();
   }


   public Long getSingleGermplasmId() {
      try {
          return(Long)execute();
      }
      catch (WrappingException e) {
         throw new RuntimeWrappingException(e);
      }
   }
}
