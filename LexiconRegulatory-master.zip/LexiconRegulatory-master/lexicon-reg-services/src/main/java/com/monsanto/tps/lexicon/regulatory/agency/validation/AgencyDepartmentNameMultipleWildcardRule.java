package com.monsanto.tps.lexicon.regulatory.agency.validation;

import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;
import org.apache.commons.lang.ArrayUtils;

/**
 * rrchak1 - Oct 21, 2008 4:39:28 PM
 */
public class AgencyDepartmentNameMultipleWildcardRule
   implements Rule<String>
{
   private String[] departmentNames;

   public AgencyDepartmentNameMultipleWildcardRule(String[] departmentNames) {
      this.departmentNames = departmentNames;
   }

   public boolean violated() {
      if (!ArrayUtils.isEmpty(departmentNames)) {
         int wildCardCount = 0;
         for (String dept : departmentNames) {
            if (dept.contains("*")) {
               ++wildCardCount;
            }
            if (wildCardCount > 1) {
               return true;
            }
         }
      }
      return false;
   }

   public String getViolation() {
      return "Agency Department must contain only Alpha characters, comma and space; is wildcardable for a single request.";
   }
}
