package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 3/5/12
 * Time: 2:19 PM
 * To change this template use File | Settings | File Templates.
 */
public class GeneticBackground {

    private long geneticBackgroundId;
    private String geneticBackground;
    private boolean activeStatus;

    public GeneticBackground() {}

    public GeneticBackground(String geneticBackground, boolean activeStatus) {
        this.geneticBackground = geneticBackground;
        this.activeStatus = activeStatus;
    }

    public long getGeneticBackgroundId() {
        return geneticBackgroundId;
    }

    public String getGeneticBackground() {
        return geneticBackground;
    }

    public void setGeneticBackground(String geneticBackground) {
        this.geneticBackground = geneticBackground;
    }

    public boolean getActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(boolean activeStatus) {
        this.activeStatus = activeStatus;
    }

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
    }
}