package com.monsanto.tps.lexicon.regulatory.event.queryset;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tps.compliance.referencedata.molecularinfo.ConstructIdentifier;
import com.monsanto.tps.compliance.referencedata.molecularinfo.ConstructPVCodeAssignment;
import com.monsanto.tps.lexicon.regulatory.event.model.RegulatoryEventConstructTransformation;

import java.io.IOException;
import java.util.List;

/**
 * User: pjberry
 * Date: Jul 27, 2007
 * Time: 3:34:20 PM
 */
public interface RegulatoryEventQuerySet
{
   RegulatoryEventConstructTransformation[] getEventConstructTransformations(String eventName, String cropAbbreviation)
      throws WrappingException, IOException;

/*   String[] getTransCodesForSinglePmonConstruct(TransCodeQueryParams transCodeQueryParams)
      throws WrappingException;

   String getTransCodeForMultiPmonConstruct(TransCodeQueryParams transCodeQueryParams)
      throws WrappingException;*/

   String getGenusSpecies(String requestedCrop)
      throws WrappingException;

   String[] findProductVectorsByCropIdAndConstructNameForCombinedConstructs(long cropPubkey, String[] constructNames);

   String[] findProductVectorsByCropIdAndConstructNameForSingleConstructs(long cropPubkey, String constructName);

   List<ConstructPVCodeAssignment> findProductVectorsByCropIdAndConstructs(long cropPubkey, List<ConstructIdentifier> constructIdentifiers);
}
