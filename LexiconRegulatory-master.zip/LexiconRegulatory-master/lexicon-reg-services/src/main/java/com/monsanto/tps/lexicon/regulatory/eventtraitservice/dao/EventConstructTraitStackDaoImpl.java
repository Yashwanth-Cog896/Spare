/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.eventtraitservice.dao;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;

import java.math.BigDecimal;
import java.util.List;

/* vvkalu - 7/29/11 */
public class EventConstructTraitStackDaoImpl implements EventConstructTraitStackDao {

    private SessionFactory sessionFactory;

    @Override
    public List<BigDecimal> getComTraitStackIdByEventConstructs(long germplasmId) {
        Session session = sessionFactory.getCurrentSession();
        Query query = session.getNamedQuery("eventConstructTraitStackDao.getComTraitStackIdByEventConstructs");
        query.setParameter("germplasmId", germplasmId);
        return (List<BigDecimal>) query.list();
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
}