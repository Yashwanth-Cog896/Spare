package com.monsanto.tps.lexicon.regulatory.eventsreginfo.dao;

import com.monsanto.tps.lexicon.regulatory.eventsreginfo.domain.lexicon.LexiconRegEvent;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: VVKALU
 * Date: Oct 5, 2010
 * Time: 2:15:22 PM
 * To change this template use File | Settings | File Templates.
 */
public interface LexiconRegEventDao {

    List<LexiconRegEvent> findMonNumbers(LexiconRegEvent info);

    List<LexiconRegEvent> findMonNumbersByCollectionCriteria();
}
