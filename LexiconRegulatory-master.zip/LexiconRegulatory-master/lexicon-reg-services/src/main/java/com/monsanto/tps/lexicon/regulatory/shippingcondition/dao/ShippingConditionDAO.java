package com.monsanto.tps.lexicon.regulatory.shippingcondition.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ShippingCondition;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 3/1/12
 * Time: 2:15 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ShippingConditionDAO {
    List<ShippingCondition> findShippingConditions(String shippingCondition);
}
