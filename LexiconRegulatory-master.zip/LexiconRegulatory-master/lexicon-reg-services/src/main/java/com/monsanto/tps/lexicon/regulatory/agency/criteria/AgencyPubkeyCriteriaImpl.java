package com.monsanto.tps.lexicon.regulatory.agency.criteria;

import org.apache.commons.lang.ArrayUtils;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

/**
 * rrchak1 - Oct 13, 2008 11:24:32 AM
 */
public class AgencyPubkeyCriteriaImpl
   implements QueryCriteria
{
   private String[] agencyPubkey;

   public AgencyPubkeyCriteriaImpl(String[] agencyPubkey) {
      this.agencyPubkey = agencyPubkey;
   }

   public Criterion getCriterion() {
      return Restrictions.in("agencyPubkey", agencyPubkey);
   }

   public boolean hasCriteria() {
      return !ArrayUtils.isEmpty(agencyPubkey);
   }
}
