package com.monsanto.tps.lexicon.regulatory.event.dao.crop;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.tps.lexicon.regulatory.DB.factories.midas.MidasConnectionFactoryProperties;

/**
 * User: pjberry
 * Date: Jul 30, 2007
 * Time: 10:58:33 AM
 */
public class MidasGenusSpeciesByCropNameQuery
   extends AbstractPersistentStoreSingleResultQuery
{
   private final String cropName;

   public MidasGenusSpeciesByCropNameQuery(String cropName) {
      this.cropName = cropName;
   }

   public String getGenusSpecies()
      throws WrappingException
   {
      return (String) execute();
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return row.getString(1);
   }

   protected String getSQL()
      throws WrappingException
   {
      return "SELECT C.genus_species FROM Midas.crop C WHERE UPPER(C.name) = UPPER(?) AND C.ref_active = 'T'";
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[]{cropName};
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MidasConnectionFactoryProperties();
   }
}
