package com.monsanto.tps.lexicon.regulatory.event.queryset;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.lexiconcommon.ArrayUtils;
import com.monsanto.tps.compliance.referencedata.molecularinfo.ConstructIdentifier;
import com.monsanto.tps.compliance.referencedata.molecularinfo.ConstructPVCodeAssignment;
import com.monsanto.tps.lexicon.eventtraitservice.transfer.PVCode;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Crop;
import com.monsanto.tps.lexicon.regulatory.crop.dao.CropDao;
import com.monsanto.tps.lexicon.regulatory.event.model.EventConstruct;
import com.monsanto.tps.lexicon.regulatory.event.model.EventConstructImpl;
import com.monsanto.tps.lexicon.regulatory.event.model.RegulatoryEventConstructTransformation;
import com.monsanto.tps.lexicon.regulatory.event.model.RegulatoryEventRequest;
import com.monsanto.tps.lexicon.regulatory.eventtraitservice.business.PVCodesTransformer;
import org.apache.commons.lang.StringUtils;

import java.io.IOException;
import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Dec 8, 2005
 * Time: 12:11:39 PM
 */
public class RegulatoryEventRequestProcessorImpl implements RegulatoryEventRequestProcessor {

    private final RegulatoryEventQuerySet regulatoryEventQuerySet;
    private final CropDao cropDao;
    private final PVCodesTransformer pvCodesTransformer;
    public static final String FORWARD_SLASH = "/";
    public static final String COMMA = ",";

    public RegulatoryEventRequestProcessorImpl(RegulatoryEventQuerySet regulatoryEventQuerySet, CropDao cropDao, PVCodesTransformer pvCodesTransformer) {
        this.regulatoryEventQuerySet = regulatoryEventQuerySet;
        this.cropDao = cropDao;
        this.pvCodesTransformer = pvCodesTransformer;
    }

    public List<RegulatoryEventResponse> getRegulatoryEvents(List<RegulatoryEventRequest> requests)
            throws WrappingException, IOException {
        List<RegulatoryEventResponse> responses = new ArrayList<RegulatoryEventResponse>();
        Map<String, List<RegulatoryEventResponse>> responsesByGenusSpecies = new HashMap<String, List<RegulatoryEventResponse>>();
        Map<String, Map<String, List<RegulatoryEventConstructTransformation[]>>> eCTsByEventAndSpecies = new HashMap<String, Map<String, List<RegulatoryEventConstructTransformation[]>>>();
        Map<String, List<Crop>> cropsByGenusSpecies = new HashMap<String, List<Crop>>();
        Map<String, Crop> cropByName = new HashMap<String, Crop>();
        for (RegulatoryEventRequest request : requests) {
            Crop crop = getCropByName(cropByName, request.getCrop());
            String cropGenusSpecies = crop.getAbbreviation();
            List<Crop> cropsInSpecies = getCropsInSpecies(cropsByGenusSpecies, cropGenusSpecies);
            RegulatoryEventConstructTransformation[] regulatoryECTs = regulatoryEventQuerySet.getEventConstructTransformations(request.getEvent(), cropGenusSpecies);
            addToECTsByEventAndSpecies(eCTsByEventAndSpecies, cropGenusSpecies, request.getEvent(), regulatoryECTs);
            EventConstruct[] eventConstructs = buildRegulatoryEvents(regulatoryECTs, request.getCrop(), cropsInSpecies);
            if (!ArrayUtils.isNullOrEmpty(eventConstructs)) {
                RegulatoryEventResponse response = new RegulatoryEventResponse();
                response.setEvent(request.getEvent());
                response.setEventConstructs(Arrays.asList(eventConstructs));
                responses.add(response);
                addToMapOfListsByKey(responsesByGenusSpecies, cropGenusSpecies, response);
            }
        }
        fetchPvCodes(responsesByGenusSpecies, eCTsByEventAndSpecies, cropsByGenusSpecies);
        return responses;
    }

    private List<Crop> getCropsInSpecies(Map<String, List<Crop>> cropsByGenusSpecies, String cropGenusSpecies) {
        List<Crop> cropsInSpecies = cropsByGenusSpecies.get(cropGenusSpecies);
        if (cropsInSpecies == null) {
            cropsInSpecies = cropDao.findByAbbreviation(cropGenusSpecies);
            cropsByGenusSpecies.put(cropGenusSpecies, cropsInSpecies);
        }
        return cropsInSpecies;
    }

    private Crop getCropByName(Map<String, Crop> cropByName, String cropName) {
        Crop crop = cropByName.get(cropName);
        if (crop == null) {
            crop = cropDao.findByName(cropName);
            cropByName.put(cropName, crop);
        }
        return crop;
    }

    private void fetchPvCodes(Map<String, List<RegulatoryEventResponse>> responsesByGenusSpecies, Map<String, Map<String, List<RegulatoryEventConstructTransformation[]>>> eCTsByEventAndSpecies, Map<String, List<Crop>> cropsByGenusSpecies) {
        for (Map.Entry<String, List<RegulatoryEventResponse>> responseEntry : responsesByGenusSpecies.entrySet()) {
            String genusSpecies = responseEntry.getKey();
            List<RegulatoryEventResponse> speciesResponses = responseEntry.getValue();
            Map<String, List<RegulatoryEventConstructTransformation[]>> ectsForEvents = eCTsByEventAndSpecies.get(genusSpecies);
            List<ConstructIdentifier> constructIdentifiers = buildConstructIdentifiers(speciesResponses, ectsForEvents);
            Map<String, List<ConstructIdentifier>> eventConstructsByEvent = buildEventConstructsByEvent(speciesResponses, ectsForEvents);
            Map<ConstructIdentifier, Set<PVCode>> pvCodesForConstructIdentifier = buildPvCodesForConstructIdentifiers(cropsByGenusSpecies, genusSpecies, constructIdentifiers);
            assignPvCodesToEventConstructs(speciesResponses, eventConstructsByEvent, pvCodesForConstructIdentifier);
        }
    }

    private void assignPvCodesToEventConstructs(List<RegulatoryEventResponse> speciesResponses, Map<String, List<ConstructIdentifier>> eventConstructsByEvent, Map<ConstructIdentifier, Set<PVCode>> pvCodesForConstructIdentifier) {
        for (RegulatoryEventResponse response : speciesResponses) {
            List<ConstructIdentifier> constructIdentifiersForEvent = eventConstructsByEvent.get(response.getEvent());
            Set<PVCode> pvCodes = new HashSet<PVCode>();
            if (constructIdentifiersForEvent != null) {
                for (ConstructIdentifier constructIdentifier : constructIdentifiersForEvent) {
                    Set<PVCode> constructIdentifiersPVCodes = pvCodesForConstructIdentifier.get(constructIdentifier);
                    if (constructIdentifiersPVCodes != null) {
                        pvCodes.addAll(constructIdentifiersPVCodes);
                    }
                }
            }
            for (EventConstruct eventConstruct : response.getEventConstructs()) {
                String[] transCodes = formTransCodesArray(pvCodes);
                eventConstruct.setTransCodes(transCodes);
            }
        }
    }

    private String[] formTransCodesArray(Set<PVCode> pvCodes) {
        if (pvCodes == null) {
            return null;
        }
        String[] transcodes = new String[pvCodes.size()];
        int count = 0;
        for (PVCode pvCode : pvCodes) {
            transcodes[count] = pvCode.getPvCode();
            count++;
        }
        return transcodes;
    }

    private Map<String, List<ConstructIdentifier>> buildEventConstructsByEvent(List<RegulatoryEventResponse> speciesResponses, Map<String, List<RegulatoryEventConstructTransformation[]>> ectsForEvents) {
        Map<String, List<ConstructIdentifier>> eventConstructsByEvent = new HashMap<String, List<ConstructIdentifier>>();
        for (RegulatoryEventResponse response : speciesResponses) {
            List<RegulatoryEventConstructTransformation[]> ectsMatchingEvent = ectsForEvents.get(response.getEvent());
            for (RegulatoryEventConstructTransformation[] constructECTs : ectsMatchingEvent) {
                ConstructIdentifier constructIdentifier = buildConstructIdentifier(constructECTs);
                addToMapOfListsByKey(eventConstructsByEvent, response.getEvent(), constructIdentifier);
            }
        }
        return eventConstructsByEvent;
    }

    private Map<ConstructIdentifier, Set<PVCode>> buildPvCodesForConstructIdentifiers(Map<String, List<Crop>> cropsByGenusSpecies, String genusSpecies, List<ConstructIdentifier> constructIdentifiers) {
        Map<ConstructIdentifier, Set<PVCode>> pvCodesForConstructIdentifier = new HashMap<ConstructIdentifier, Set<PVCode>>();
        List<Crop> crops = cropsByGenusSpecies.get(genusSpecies);
        for (Crop crop : crops) {
            List<ConstructPVCodeAssignment> constructPVCodeAssignmentsForCrop = regulatoryEventQuerySet.findProductVectorsByCropIdAndConstructs(new Long(crop.getCropPubkey()), constructIdentifiers);
            if (constructPVCodeAssignmentsForCrop != null) {
                for (ConstructPVCodeAssignment pvCodeAssigment : constructPVCodeAssignmentsForCrop) {
                    List<PVCode> pvCodeListString = pvCodesTransformer.formLexiconPVCodeList(pvCodeAssigment.getPVCodes());
                    addToMapOfSetsByKey(pvCodesForConstructIdentifier, pvCodeAssigment.getConstructIdentifier(), pvCodeListString);
                }
            }
        }
        return pvCodesForConstructIdentifier;
    }

    private List<ConstructIdentifier> buildConstructIdentifiers(List<RegulatoryEventResponse> speciesResponses, Map<String, List<RegulatoryEventConstructTransformation[]>> ectsForEvents) {
        List<ConstructIdentifier> eventConstructs = new ArrayList<ConstructIdentifier>();
        for (RegulatoryEventResponse response : speciesResponses) {
            List<RegulatoryEventConstructTransformation[]> ectsMatchingEvent = ectsForEvents.get(response.getEvent());
            for (RegulatoryEventConstructTransformation[] constructECTs : ectsMatchingEvent) {
                ConstructIdentifier constructIdentifier = buildConstructIdentifier(constructECTs);
                eventConstructs.add(constructIdentifier);
            }
        }
        return eventConstructs;
    }

    private ConstructIdentifier buildConstructIdentifier(RegulatoryEventConstructTransformation[] transformations) {
        ConstructIdentifier constructIdentifier = new ConstructIdentifier();
        String[] constructs = getCombinedConstructNames(transformations);
        constructIdentifier.setNames(Arrays.asList(constructs));
        return constructIdentifier;
    }

    private <T> void addToMapOfListsByKey(Map<String, List<T>> mapOfLists, String key, T value) {
        List<T> list = mapOfLists.get(key);
        if (list == null) {
            list = new ArrayList<T>();
            mapOfLists.put(key, list);
        }
        list.add(value);
    }

    private <S, T> void addToMapOfSetsByKey(Map<S, Set<T>> mapOfSets, S key, List<T> value) {
        Set<T> set = mapOfSets.get(key);
        if (set == null) {
            set = new LinkedHashSet();
            mapOfSets.put(key, set);
        }
        set.addAll(value);
    }

    private void addToECTsByEventAndSpecies(Map<String, Map<String, List<RegulatoryEventConstructTransformation[]>>> eCTsByEventAndSpecies, String genusSpecies, String event, RegulatoryEventConstructTransformation ects[]) {
        Map<String, List<RegulatoryEventConstructTransformation[]>> byEvents = eCTsByEventAndSpecies.get(genusSpecies);
        if (byEvents == null) {
            byEvents = new HashMap<String, List<RegulatoryEventConstructTransformation[]>>();
            eCTsByEventAndSpecies.put(genusSpecies, byEvents);
        }
        addToMapOfListsByKey(byEvents, event, ects);
    }

    private EventConstruct[] buildRegulatoryEvents(RegulatoryEventConstructTransformation[] regulatoryECTs, String crop, List<Crop> cropsInSpecies)
            throws WrappingException {
        //TODO refactor
        List<EventConstruct> eventConstructs = new ArrayList<EventConstruct>();
        if (1 == regulatoryECTs.length) {
            if (constructIsCombined(regulatoryECTs[0].getConstruct())) {
                eventConstructs.add(buildEventConstruct(null, crop, regulatoryECTs[0]));
            } else {
                eventConstructs.add(buildEventConstruct(null, crop, regulatoryECTs[0]));
            }
        } else if (regulatoryECTs.length > 1) {
            for (RegulatoryEventConstructTransformation regulatoryECT : regulatoryECTs) {
                eventConstructs.add(buildEventConstruct(null, crop, regulatoryECT));
            }
        }
        return eventConstructs.toArray(new EventConstruct[eventConstructs.size()]);
    }


    private EventConstructImpl buildEventConstruct(String[] pvCodes, String crop, RegulatoryEventConstructTransformation regulatoryECT) {
        return new EventConstructImpl(regulatoryECT, crop, pvCodes);
    }

    private boolean constructIsCombined(String construct) {
        return construct != null ? construct.contains(FORWARD_SLASH) || construct.contains(COMMA) : false;
    }


    private String[] getCombinedConstructNames(RegulatoryEventConstructTransformation[] regulatoryECTs) {
        List<String> constructNameList = new ArrayList<String>();
        for (RegulatoryEventConstructTransformation regulatoryECT : regulatoryECTs) {
            String constructName = regulatoryECT.getConstruct();
            if (constructName != null) {
                if (constructName.contains(FORWARD_SLASH) || constructName.contains(COMMA)) {
                    constructNameList.addAll(Arrays.asList(split(constructName)));
                } else {
                    constructNameList.add(constructName);
                }
            }
        }
        return constructNameList.toArray(new String[constructNameList.size()]);
    }

    private String[] split(String construct) {
        if (construct.contains(FORWARD_SLASH)) {
            return StringUtils.split(construct, FORWARD_SLASH);
        } else if (construct.contains(COMMA)) {
            return StringUtils.split(construct, COMMA);
        }
        return new String[]{construct};
    }

}
