package com.monsanto.tps.lexicon.regulatory.additionalmaterialinfo.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.AdditionalMaterial;
import com.monsanto.tps.lexicon.regulatory.util.WildcardUtil;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

@Component()
public class AdditionalMaterialDAOImpl implements AdditionalMaterialDAO {
    private static final String FIND_ADDITIONAL_MATERIALS_QUERY = "findAdditionalMaterialsIgnoreCase";

    @Resource
    private SessionFactory sessionFactory;

    @Override
    public List<AdditionalMaterial> findAdditionalMaterials(String materialName) {
        final Session session = sessionFactory.getCurrentSession();

        final Query query = session.getNamedQuery(FIND_ADDITIONAL_MATERIALS_QUERY);
        query.setParameter("materialName", WildcardUtil.replaceEmptyStringWithWildcard(materialName));

        return (List<AdditionalMaterial>) query.list();
    }
}
