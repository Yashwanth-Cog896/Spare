package com.monsanto.tps.lexicon.regulatory.eventsreginfo.service;

import com.monsanto.tps.lexicon.eventsreginfo.EventsRegInfoService;
import com.monsanto.tps.lexicon.eventsreginfo.transfer.EventRegInfo;
import com.monsanto.tps.lexicon.regulatory.eventsreginfo.bo.EventsRegInfoBusiness;

import javax.jws.WebParam;
import java.util.Collection;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: VVKALU
 * Date: Oct 5, 2010
 * Time: 3:27:59 PM
 * To change this template use File | Settings | File Templates.
 */
public class EventsRegInfoServiceImpl
    implements EventsRegInfoService {

    private EventsRegInfoBusiness business;

    @Override
    public List<EventRegInfo> findMonNumbersByCropAndMonNumber(@WebParam(name="monNumber") String monNumber, @WebParam(name="cropName") String cropName) {
        return business.findMonNumbersByCropAndMonNumber(monNumber, cropName);
    }

    @Override
    public List<EventRegInfo> findMonNumbers(@WebParam(name="monNumbers") List<String> monNumbers) {
        return business.findMonNumbersFromCollection(monNumbers);
    }

    @Override
    public List<EventRegInfo> findMonNumbersByEvent(@WebParam(name="event") String event) {
        return business.findMonNumbersByEvent(event);
    }

    @Override
    public List<EventRegInfo> findMonNumbersByPlasmidPmon(@WebParam(name="plasmidPmon") String plasmidPmon) {
        return business.findMonNumbersByPlasmidPmon(plasmidPmon);
    }

    @Override
    public List<EventRegInfo> findMonNumbersByPlasmidPvCode(@WebParam(name="plasmidPvCode") String plasmidPvCode) {
        return business.findMonNumbersByPlasmidPvCode(plasmidPvCode);
    }

    @Override
    public List<EventRegInfo> findMonNumbersByTransformationBackground(@WebParam(name="transformationBackground") String transformationBackground) {
        return business.findMonNumbersByTransformationBackground(transformationBackground);
    }

    @Override
    public List<EventRegInfo> findMonNumbersByRegulatoryTraitDescription(@WebParam(name="regulatoryTraitDescription") String regulatoryTraitDescription) {
        return business.findMonNumbersByRegulatoryTraitDescription(regulatoryTraitDescription);
    }

    @Override
    public List<EventRegInfo> findMonNumbersByRegulatoryGenesPresent(@WebParam(name="regulatoryGenesPresent") String regulatoryGenesPresent) {
        return business.findMonNumbersByRegulatoryGenesPresent(regulatoryGenesPresent);
    }

    @Override
    public List<EventRegInfo> findMonNumbersByRegulatedStatus(@WebParam(name="regulatedStatus") boolean regulatedStatus) {
        return business.findMonNumbersByRegulatedStatus(regulatedStatus);
    }

    @Override
    public List<EventRegInfo> findMonNumbersByJvNumber(@WebParam(name="jvNumber") String jvNumber) {
        return business.findMonNumbersByJvNumber(jvNumber);
    }

    @Override
    public List<EventRegInfo> findMonNumbersByOecdNumber(@WebParam(name="oecdNumber") String oecdNumber) {
        return business.findMonNumbersByOecdNumber(oecdNumber);
    }

    @Override
    public List<EventRegInfo> findMonNumbersByMaterialName(@WebParam(name="materialName") String materialName) {
        return business.findMonNumbersByMaterialName(materialName);
    }

    public void setBusiness(EventsRegInfoBusiness business) {
        this.business = business;
    }
}
