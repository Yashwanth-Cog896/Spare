package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model;

/**
 * rrchak1 - May 14, 2009 10:24:47 AM
 */
public class DataFilter
{
   private long dataFilterId;

   public long getDataFilterId() {
      return dataFilterId;
   }

   public void setDataFilterId(long dataFilterId) {
      this.dataFilterId = dataFilterId;
   }

   private String filterName;

   public String getFilterName() {
      return filterName;
   }

   public void setFilterName(String filterName) {
      this.filterName = filterName;
   }

   private boolean active;

   public boolean isActive() {
      return active;
   }

   public void setActive(boolean active) {
      this.active = active;
   }

   @Override
   public boolean equals(Object o) {
      if (this == o) {
         return true;
      }
      if (o == null || getClass() != o.getClass()) {
         return false;
      }

      DataFilter that = (DataFilter) o;

      if (dataFilterId != that.dataFilterId) {
         return false;
      }
      if (filterName != null ? !filterName.equals(that.filterName) : that.filterName != null) {
         return false;
      }

      return true;
   }

   @Override
   public int hashCode() {
      int result = (int) (dataFilterId ^ (dataFilterId >>> 32));
      result = 31 * result + (filterName != null ? filterName.hashCode() : 0);
      return result;
   }
}
