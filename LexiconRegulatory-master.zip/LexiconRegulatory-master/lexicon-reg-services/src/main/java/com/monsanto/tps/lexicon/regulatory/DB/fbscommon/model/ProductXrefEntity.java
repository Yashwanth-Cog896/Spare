/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.DB.fbscommon.model;

import com.monsanto.tps.lexicon.regulatory.DB.midas.model.MidasProductEntity;

import java.io.Serializable;

/* vvkalu - 7/25/11 */
public class ProductXrefEntity implements Serializable {
    private String lexiconProductPubkey;
    private MidasProductEntity product;

    public MidasProductEntity getProduct() {
        return product;
    }

    public void setProduct(MidasProductEntity product) {
        this.product = product;
    }

    public String getLexiconProductPubkey() {
        return lexiconProductPubkey;
    }

    public void setLexiconProductPubkey(String lexiconProductPubkey) {
        this.lexiconProductPubkey = lexiconProductPubkey;
    }
}