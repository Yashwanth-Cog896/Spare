package com.monsanto.tps.lexicon.regulatory.storagecondition.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.StorageCondition;
import com.monsanto.tps.lexicon.regulatory.util.WildcardUtil;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 3/1/12
 * Time: 2:16 PM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class StorageConditionDAOImpl implements StorageConditionDAO {

    @Resource
    private SessionFactory sessionFactory;

    @Override
    public List<StorageCondition> findStorageConditions(final String containerType) {

        final Session session = sessionFactory.getCurrentSession();

        final Query query = session.getNamedQuery("findActiveStorageConditionIgnoreCaseSort");
        query.setParameter("storageCondition", WildcardUtil.replaceEmptyStringWithWildcard(containerType));

        return (List<StorageCondition>) query.list();
    }


}
