package com.monsanto.tps.lexicon.regulatory.chemicalname.comparator;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.AdditionalMaterial;

import java.util.Comparator;

/**
 * Created by IntelliJ IDEA.
 * User: etherma
 * Date: Apr 27, 2006
 * Time: 2:41:53 PM
 * To change this template use File | Settings | File Templates.
 */
public class AdditionalMaterialComparator implements Comparator<AdditionalMaterial> {

    public final int compare(AdditionalMaterial info1, AdditionalMaterial info2) {

        int nameCompare = 0;
        int dateCompare = 0;

        if (info1 != null && info2 != null) {
            String name1 = info1.getMaterialName();
            String name2 = info2.getMaterialName();
            if (name1 != null && name2 != null) {
                nameCompare = name1.compareToIgnoreCase(name2);
            }
        }
        return nameCompare != 0 ? nameCompare : dateCompare;
    }

}
