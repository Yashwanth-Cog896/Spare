package com.monsanto.tps.lexicon.regulatory.nonmonevent.util;

import com.monsanto.dbdataservices.SQLUtil;
import com.monsanto.tps.lexicon.commercialtrait.ComlTraitName;
import com.monsanto.tps.lexicon.commercialtrait.ComlTraitType;
import com.monsanto.tps.lexicon.commercialtrait.Company;
import com.monsanto.tps.lexicon.monnumber.ProteinName;
import com.monsanto.tps.lexicon.nonmonevent.NonMonEvent;
import com.monsanto.tps.lexicon.nonmonevent.NonMonEventConstruct;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: gdleon
 * Date: May 6, 2009
 * Time: 1:36:55 PM
 */
public class NonMonEventBeanUtil
{
   private NonMonEventAttributeBuilder builder = new NonMonEventAttributeBuilder();

   public NonMonEvent[] buildNonMonEvents(com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent[] dbNonMonEvents) {
      List<NonMonEvent> nonMonEvents = new ArrayList<NonMonEvent>();
      for (com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent dbNonMonEvent : dbNonMonEvents) {
         nonMonEvents.add(buildNonMonEvent(dbNonMonEvent));
      }

      return nonMonEvents.toArray(new NonMonEvent[nonMonEvents.size()]);
   }

   public NonMonEvent buildNonMonEvent(com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent dbNonMonEvent) {
      NonMonEvent nonMonEvent = new NonMonEvent();
      nonMonEvent.setEventDescription(dbNonMonEvent.getEventDescription());
      nonMonEvent.setCropPubkey(dbNonMonEvent.getCropPubkey());
      nonMonEvent.setActive(dbNonMonEvent.isActiveStatus());
      nonMonEvent.setMaterialName(dbNonMonEvent.getMaterialName());

      nonMonEvent.setProteinNames(buildProteinNames(dbNonMonEvent.getProteinNames()));
      nonMonEvent.setComlTraitTypes(buildComlTraitTypes(dbNonMonEvent.getComlTraitTypes()));
      nonMonEvent.setComlTraitNames(buildComlTraitNames(dbNonMonEvent.getComlTraitNames()));
      nonMonEvent.setNonMonEventConstructs(buildNonMonEventConstructs(dbNonMonEvent.getNonMonEventConstructs()));
      return nonMonEvent;
   }

   private Collection<ProteinName> buildProteinNames(Collection<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName> dbProteinNames) {
      Set<ProteinName> proteinNames = new HashSet<ProteinName>();
      for (com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName dbProteinName : dbProteinNames) {
        proteinNames.add(builder.buildProteinName(dbProteinName));
      }
      return proteinNames;
   }

    public Collection<ComlTraitType> buildComlTraitTypes(
      Collection<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType> dbComlTraitTypes)
   {
      Set<ComlTraitType> comlTraitTypes = new HashSet<ComlTraitType>();
      for (com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType dbComlTraitType : dbComlTraitTypes) {
         comlTraitTypes.add(builder.buildComlTraitType(dbComlTraitType));
      }

      return comlTraitTypes;
   }

   public Collection<ComlTraitName> buildComlTraitNames(
      Collection<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName> dbComlTraitNames)
   {
      Set<ComlTraitName> comlTraitNames = new HashSet<ComlTraitName>();
      for (com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName dbComlTraitName : dbComlTraitNames) {
         comlTraitNames.add(builder.buildComlTraitName(dbComlTraitName));
      }
      return comlTraitNames;
   }

   

   private Collection<NonMonEventConstruct> buildNonMonEventConstructs(
      Collection<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEventConstruct> dbNonMonEventConstructs)
   {
      Set<NonMonEventConstruct> nonMonEventConstruct = new HashSet<NonMonEventConstruct>();
      for (com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEventConstruct dbNonMonEventConstruct : dbNonMonEventConstructs) {
         nonMonEventConstruct.add(builder.buildNonMonEventConstruct(dbNonMonEventConstruct));
      }
      return nonMonEventConstruct;
   }

    
}
