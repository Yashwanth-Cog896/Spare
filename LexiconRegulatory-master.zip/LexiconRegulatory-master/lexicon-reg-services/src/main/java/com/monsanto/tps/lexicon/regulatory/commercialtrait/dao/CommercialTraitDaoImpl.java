package com.monsanto.tps.lexicon.regulatory.commercialtrait.dao;

import com.monsanto.tps.lexicon.commercialtrait.RegulatoryTraitOption;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitStack;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.DataFilterEnum;
import org.hibernate.*;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;

import java.util.Collection;
import java.util.List;

/**
 * rrchak1 - May 4, 2009 5:36:20 PM
 */
public class CommercialTraitDaoImpl
   implements CommercialTraitDao
{
   private SessionFactory sessionFactory;

   @Override
   public Collection<RegulatoryTraitOption> getRegulatoryTraitTypeOptions() {
      Session session = sessionFactory.getCurrentSession();
      Query query = session.getNamedQuery("retrieveRegulatoryTraitandTraitTypes");
      SQLQuery sqlQuery = session.createSQLQuery(query.getQueryString());
      sqlQuery.setParameter(0, DataFilterEnum.REGULATORY.getValue());
      sqlQuery.setParameter(1, DataFilterEnum.REGULATORY.getValue());
      sqlQuery.addScalar("abbr", Hibernate.STRING);
      sqlQuery.addScalar("description", Hibernate.STRING);
      sqlQuery.addScalar("optionType", Hibernate.STRING);
      sqlQuery.setResultTransformer(Transformers.aliasToBean(RegulatoryTraitOption.class));
      return sqlQuery.list();
   }

   @Override
   public ComlTraitType findCommercialTraitTypeByAbbr(String traitTypeAbbreviation) {
      Session session = sessionFactory.getCurrentSession();
      return (ComlTraitType) session.getNamedQuery("comlTaitTypeByAbbr").setString(0, traitTypeAbbreviation).uniqueResult();
   }

   @Override
   public ComlTraitName findCommercialTraitByAbbr(String traitAbbr) {
      Session session = sessionFactory.getCurrentSession();
      return (ComlTraitName) session.getNamedQuery("comlTraitByAbbr").setString(0, traitAbbr).uniqueResult();

   }

    @Override
    public List<String> getComTraitTypeDescByComlTraitStackId(long comlTraitStackId) {
        Session session = sessionFactory.getCurrentSession();
        Query query = session.getNamedQuery("comlTraitStackDao.getDistinctComlTraitTypeDesc");
        query.setParameter("comlTraitStackId", comlTraitStackId);
        return query.list();
    }

    @Override
    public ComlTraitStack getComlTraitStackById(long comlTraitStackId) {
        Session session = sessionFactory.getCurrentSession();
        Criteria criteria = session.createCriteria(ComlTraitStack.class)
                                   .add(Restrictions.eq("comlTraitStackId", comlTraitStackId));
        return (ComlTraitStack) criteria.uniqueResult();
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
      this.sessionFactory = sessionFactory;
   }
}
