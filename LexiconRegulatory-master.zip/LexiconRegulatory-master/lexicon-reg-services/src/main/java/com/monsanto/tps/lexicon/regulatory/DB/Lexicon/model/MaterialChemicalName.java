package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model;

/**
 * Created by IntelliJ IDEA.
 * Date: 3/15/12
 * Time: 9:19 PM
 */
public class MaterialChemicalName {

    private long chemicalNameId;
    private long prodId;
    private String chemicalName;
    private String expertlInd;

    public long getChemicalNameId() {
        return chemicalNameId;
    }

    public void setChemicalNameId(long chemicalNameId) {
        this.chemicalNameId = chemicalNameId;
    }

    public long getProdId() {
        return prodId;
    }

    public void setProdId(long prodId) {
        this.prodId = prodId;
    }

    public String getChemicalName() {
        return chemicalName;
    }

    public void setChemicalName(String chemicalName) {
        this.chemicalName = chemicalName;
    }

    public String getExpertlInd() {
        return expertlInd;
    }

    public void setExpertlInd(String expertlInd) {
        this.expertlInd = expertlInd;
    }
}
