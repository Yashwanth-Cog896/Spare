package com.monsanto.tps.lexicon.regulatory.TPS.LineType;

/**
 * Created by IntelliJ IDEA.
 * User: mgkobe
 * Date: Apr 15, 2004
 * Time: 4:04:33 PM
 * To change this template use File | Settings | File Templates.
 */
public class LineTypeRef
{
   public static final String SEGPOP = "SEGPOP";
   public static final String HYBRID = "HYBRID";
   public static final String OP_VAR = "OP_VAR";
   public static final String CODED = "CODED";
   public static final String FINISHED = "FINISHED";

} // End of class LineTypeRef