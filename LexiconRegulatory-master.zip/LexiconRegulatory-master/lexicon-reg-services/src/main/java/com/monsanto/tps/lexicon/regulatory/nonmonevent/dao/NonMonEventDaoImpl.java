package com.monsanto.tps.lexicon.regulatory.nonmonevent.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: gdleon
 * Date: May 6, 2009
 * Time: 2:29:20 PM
 */
public class NonMonEventDaoImpl
   implements NonMonEventDao
{
   private SessionFactory sessionFactory;

   @Override
   public NonMonEvent[] findByCrop(String cropPubkey) {
      Session session = sessionFactory.getCurrentSession();
      List<NonMonEvent> nonMonEvents = session.getNamedQuery("nonMonEvents.byCropPubkeyAndStatus")
         .setString(0, cropPubkey)
         .setBoolean(1, true)
         .list();
      return nonMonEvents.toArray(new NonMonEvent[nonMonEvents.size()]);
   }

   @Override
   public NonMonEvent[] findByNonMonEvent(String nonMonEvent) {
      Session session = sessionFactory.getCurrentSession();
      List<NonMonEvent> nonMonEvents = session.getNamedQuery("nonMonEvents.byNonMonEventAndStatus")
         .setString(0, nonMonEvent)
         .setBoolean(1, true)
         .list();
      return nonMonEvents.toArray(new NonMonEvent[nonMonEvents.size()]);
   }

   @Override
   public NonMonEvent[] findByNonMonEventAndCrop(String nonMonEvent, String cropPubkey) {
      Session session = sessionFactory.getCurrentSession();
      List<NonMonEvent> nonMonEvents = session.getNamedQuery("nonMonEvents.byNonMonEventCropPubkeyAndStatus")
         .setString(0, nonMonEvent)
         .setString(1, cropPubkey)
         .setBoolean(2, true)
         .list();
      return nonMonEvents.toArray(new NonMonEvent[nonMonEvents.size()]);
   }

   public void setSessionFactory(SessionFactory sessionFactory) {
      this.sessionFactory = sessionFactory;
   }

   public NonMonEvent[] findAll() {
      Session session = sessionFactory.getCurrentSession();
      List<NonMonEvent> nonMonEvents = session.getNamedQuery("all.nonMonEvents").list();
      return nonMonEvents.toArray(new NonMonEvent[nonMonEvents.size()]);

   }

   public void save(NonMonEvent nonMonEvent) {
      Session session = sessionFactory.getCurrentSession();
      session.save(nonMonEvent);
   }

   public void update(NonMonEvent nonMonEvent) {
      Session session = sessionFactory.getCurrentSession();
      session.update(nonMonEvent);
      session.flush();
   }
}
