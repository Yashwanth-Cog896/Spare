package com.monsanto.tps.lexicon.regulatory.proteinname.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.GeneticBackground;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 3/1/12
 * Time: 2:15 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ProteinNameDAO {
    List<ProteinName> findProteinNames(String proteinName);
}
