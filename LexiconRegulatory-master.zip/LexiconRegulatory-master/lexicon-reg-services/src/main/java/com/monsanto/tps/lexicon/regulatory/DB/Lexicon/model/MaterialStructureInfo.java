package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model;

import org.apache.log4j.Logger;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.SQLException;

public class MaterialStructureInfo {

    private static final Logger LOG = Logger.getLogger(MaterialStructureInfo.class);

    private long imageId;
    private long materialId;
    private String imageName;
    private String molecularWeight;
    private String molecularFormula;
    private Blob imageBlob;
    private String elementalTheory;

    public MaterialStructureInfo() {
    }

    public MaterialStructureInfo(String molecularWeight, String molecularFormula) {
        this.molecularWeight = molecularWeight;
        this.molecularFormula = molecularFormula;
    }

    public long getImageId() {
        return imageId;
    }

    public void setImageId(long imageId) {
        this.imageId = imageId;
    }

    public String getImageName() {
        return imageName;
    }

    public void setImageName(String imageName) {
        this.imageName = imageName;
    }

    public Blob getImageBlob() {
        return imageBlob;
    }

    public void setImageBlob(Blob imageBlob) {
        this.imageBlob = imageBlob;
    }

    public byte[] getMolecularStructure() {
        return toByteArray(this.imageBlob);
    }

    public long getMaterialId() {
        return materialId;
    }

    public void setMaterialId(long materialId) {
        this.materialId = materialId;
    }

    public String getMolecularFormula() {
        return molecularFormula;
    }

    public void setMolecularFormula(String molecularFormula) {
        this.molecularFormula = molecularFormula;
    }

    public String getMolecularWeight() {
        return molecularWeight;
    }

    public void setMolecularWeight(String molecularWeight) {
        this.molecularWeight = molecularWeight;
    }

    public String getElementalTheory() {
        return elementalTheory;
    }

    public void setElementalTheory(String elementalTheory) {
        this.elementalTheory = elementalTheory;
    }

    private byte[] toByteArray(Blob fromBlob) {
        InputStream is;
        ByteArrayOutputStream byteArrayStream = new ByteArrayOutputStream();
        int readByte;
        try {
            if (structurePresent(fromBlob)) {
                is = fromBlob.getBinaryStream();
                while ((readByte = is.read()) != -1) {
                    byteArrayStream.write(readByte);
                }
            }
        } catch (SQLException e) {
            LOG.error("Error: " + e.getMessage(), e);
        } catch (IOException e) {
            LOG.error("Error: " + e.getMessage(), e);
        }
        return byteArrayStream.toByteArray();
    }

    private boolean structurePresent(Blob fromBlob) {
        return fromBlob != null;
    }
}
