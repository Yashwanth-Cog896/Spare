package com.monsanto.tps.lexicon.regulatory.event.delegate;

import com.monsanto.tps.lexicon.event.AgencyMaterialDeregulationStatus;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * rrchak1 - Jun 23, 2009 12:00:09 PM
 */
public class MaterialStatusBuilder {
    public List<AgencyMaterialDeregulationStatus> build(EventAgencyAlignment[] agencyAlignments, String cropName) {
        Map<String, List<EventAgencyAlignment>> alignments = buildMapByEvent(agencyAlignments);
        return buildEventDeregulationStatus(alignments, cropName);
    }

    private List<AgencyMaterialDeregulationStatus> buildEventDeregulationStatus(Map<String, List<EventAgencyAlignment>> alignments, String cropName) {
        List<AgencyMaterialDeregulationStatus> eventDeregulationStatusList = new ArrayList<AgencyMaterialDeregulationStatus>();
        for (String event : alignments.keySet()) {
            AgencyMaterialDeregulationStatus eventDeregulationStatus = new AgencyMaterialDeregulationStatus();
            eventDeregulationStatus.setEventName(event);
            eventDeregulationStatus.setCrop(cropName);
            List<EventAgencyAlignment> alignmentList = alignments.get(event);
            EventAgencyAlignment[] agencyAlignments = alignmentList.toArray(new EventAgencyAlignment[alignmentList.size()]);
            eventDeregulationStatus.setAgencyMaterials(new MaterialAgencies(agencyAlignments).getResponseEventAgencies());
            eventDeregulationStatusList.add(eventDeregulationStatus);
        }
        return eventDeregulationStatusList;
    }

    private Map<String, List<EventAgencyAlignment>> buildMapByEvent(EventAgencyAlignment[] agencyAlignments) {
        Map<String, List<EventAgencyAlignment>> alignments = new HashMap<String, List<EventAgencyAlignment>>();
        List<EventAgencyAlignment> alignmentList;
        for (EventAgencyAlignment agencyAlignment : agencyAlignments) {
            String materialName = getMaterialName(agencyAlignment);
            if (alignments.containsKey(materialName)) {
                alignmentList = alignments.get(materialName);
                alignments.remove(materialName);
            } else {
                alignmentList = new ArrayList<EventAgencyAlignment>();
            }
            alignmentList.add(agencyAlignment);
            alignments.put(materialName, alignmentList);
        }
        return alignments;
    }

    private String getMaterialName(EventAgencyAlignment agencyAlignment) {
        String materialName;
        if (null != agencyAlignment.getMaterialName()) {
            materialName = agencyAlignment.getMaterialName();
        } else {
            materialName = null != agencyAlignment.getMaterialChemicalName() ? agencyAlignment.getMaterialChemicalName().getChemicalName() : null;
        }
        return materialName;
    }
}