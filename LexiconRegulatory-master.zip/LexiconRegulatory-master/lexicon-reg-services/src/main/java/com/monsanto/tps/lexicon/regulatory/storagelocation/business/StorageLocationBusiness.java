package com.monsanto.tps.lexicon.regulatory.storagelocation.business;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.StorageLocation;
import com.monsanto.tps.lexicon.regulatory.eventsreginfo.util.dao.lexicon.TempSessionOcdDao;
import com.monsanto.tps.lexicon.regulatory.storagelocation.dao.StorageLocationDAO;
import com.monsanto.tps.lexicon.regulatory.util.OrionCriteria;
import com.monsanto.tps.lexicon.storagelocation.OrionStorageLocation;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: MMR
 * Date: 2/20/12
 * Time: 6:29 PM
 */
public class StorageLocationBusiness {

    private static final long REQUEST_ID = 20122002;
    private StorageLocationDAO storageLocationDAO;
    private OrionStorageLocationBuilder builder;
    private TempSessionOcdDao tempSessionOcdDao;

    public List<OrionStorageLocation> findStorageLocations(String storageLocation) {
        StorageLocation dbStorageLocation = createStorageLocation();
        dbStorageLocation.setStorageLocation(OrionCriteria.format(storageLocation));
        return builder.build(storageLocationDAO.findActiveStorageLocations(dbStorageLocation));
    }

    public List<OrionStorageLocation> findStorageLocationsByList(List<String> storageLocations) {
        List<OrionStorageLocation> orionStorageLocations = new ArrayList<OrionStorageLocation>();
        if (storageLocations != null && !storageLocations.isEmpty()) {
            tempSessionOcdDao.clearValues(REQUEST_ID);
            tempSessionOcdDao.insertText1Values(REQUEST_ID, storageLocations);
            orionStorageLocations.addAll(builder.build(storageLocationDAO.findStorageLocationsByList()));
        }
        return orionStorageLocations;
    }

    public List<OrionStorageLocation> findStorageLocationsByPhysicalLocation(String physicalLocation) {
        StorageLocation dbStorageLocation = createStorageLocation();
        dbStorageLocation.setPhysicalLocation(OrionCriteria.format(physicalLocation));
        return builder.build(storageLocationDAO.findActiveStorageLocations(dbStorageLocation));
    }

    public void setStorageLocationDAO(StorageLocationDAO storageLocationDAO) {
        this.storageLocationDAO = storageLocationDAO;
    }

    public void setBuilder(OrionStorageLocationBuilder builder) {
        this.builder = builder;
    }

    public void setTempSessionOcdDao(TempSessionOcdDao tempSessionOcdDao) {
        this.tempSessionOcdDao = tempSessionOcdDao;
    }

    protected StorageLocation createStorageLocation() {
        return new StorageLocation();
    }

}
