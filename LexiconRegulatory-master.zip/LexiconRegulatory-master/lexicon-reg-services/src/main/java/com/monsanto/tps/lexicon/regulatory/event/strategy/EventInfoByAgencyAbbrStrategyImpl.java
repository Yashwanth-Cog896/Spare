package com.monsanto.tps.lexicon.regulatory.event.strategy;

import com.monsanto.tcc.lexiconcommon.ArrayUtils;
import com.monsanto.tps.lexicon.event.EventInfo;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber;
import com.monsanto.tps.lexicon.regulatory.event.delegate.EventAgencyAlignments;
import com.monsanto.tps.lexicon.regulatory.event.queryset.EventCrop;
import com.monsanto.tps.lexicon.regulatory.event.delegate.EventInfoBuilder;
import com.monsanto.tps.lexicon.regulatory.event.model.EventConstruct;
import com.monsanto.tps.lexicon.regulatory.event.model.RegulatoryEvent;
import com.monsanto.tps.lexicon.regulatory.event.queryset.EventSearchServiceQuerySet;
import com.monsanto.tps.lexicon.regulatory.event.queryset.RegulatoryEventResponse;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * rrchak1 - Feb 17, 2009 12:38:02 PM
 */
public class EventInfoByAgencyAbbrStrategyImpl
   implements EventInfoByAgencyAbbrStrategy
{
   private EventSearchServiceQuerySet querySet;

   public EventInfoByAgencyAbbrStrategyImpl(EventSearchServiceQuerySet querySet) {
      this.querySet = querySet;
   }

   @Override
   public EventInfo[] find(String[] agencyAbbr) {
      EventAgencyAlignment[] eventAgencyAlignments = querySet.findByAgencyAbbr(agencyAbbr);
      List<EventInfo> eventInfoList = getEventInfos(eventAgencyAlignments);
      return eventInfoList.toArray(new EventInfo[eventInfoList.size()]);
   }

   protected List<EventInfo> getEventInfos(EventAgencyAlignment[] eventAgencyAlignments) {
      List<EventInfo> eventInfos = new ArrayList<EventInfo>();
      Map<EventCrop, List<EventAgencyAlignment>> alignmentsByEvent = getAlignmentsByEvent(eventAgencyAlignments);
      List<RegulatoryEventResponse> eventResponses = querySet.findRegulatoryEventByEventAndCrop(alignmentsByEvent.keySet());

      for(RegulatoryEventResponse response : eventResponses){
           EventCrop eventCrop = new EventCrop(response.getEvent(),response.getEventConstructs().get(0).getCrop());
           List<EventAgencyAlignment> alignments = alignmentsByEvent.get(eventCrop);
           EventAgencyAlignment[] alignmentsArray = alignments.toArray(new EventAgencyAlignment[alignments.size()]);
           EventInfo eventInfo = buildEventInfo(eventCrop.getEvent(), eventCrop.getCrop(), response.getEventConstructs(), alignmentsArray);
           eventInfos.add(eventInfo);
      }

      return eventInfos;
   }

    private List<EventConstruct> getEventConstructsForEventCrop(Map<String, Map<String, List<EventConstruct>>> cropEventConstructMap, EventCrop eventCrop) {
        Map<String,List<EventConstruct>> eventConstructsForCrop = cropEventConstructMap.get(eventCrop.getCrop());
        if(eventConstructsForCrop!=null){
           return  eventConstructsForCrop.get(eventCrop.getEvent());
        }
        else {
            return null;
        }
    }    
    private List<EventConstruct> getEventConstructsForEvent(Map<String, Map<String, List<EventConstruct>>> cropEventConstructMap, EventConstruct eventConstruct) {
        Map<String,List<EventConstruct>> eventConstructsForCrop = cropEventConstructMap.get(eventConstruct.getCrop());
        if(eventConstructsForCrop==null){
            eventConstructsForCrop = new HashMap<String, List<EventConstruct>>();
            cropEventConstructMap.put(eventConstruct.getCrop(),eventConstructsForCrop);
        }
        List<EventConstruct> eventConstructsForEvent = eventConstructsForCrop.get(eventConstruct.getEvent());
        if(eventConstructsForEvent==null){
            eventConstructsForEvent = new ArrayList<EventConstruct>();
            eventConstructsForCrop.put(eventConstruct.getEvent(),eventConstructsForEvent);
        }
        return eventConstructsForEvent;
    }

    private EventInfo buildEventInfo(String eventName, String cropName, List<EventConstruct> eventConstructs, EventAgencyAlignment[] alignmentsArray) {
      Map<String, List<EventConstruct>> distinctEvents = findDistinctEvents(eventConstructs);
      List<RegulatoryEvent> regulatoryEventList = new ArrayList<RegulatoryEvent>();
      for (String distinctEvent : distinctEvents.keySet()) {
         MonNumber monNumber = querySet.findMonNumberByEventAndCrop(eventName, cropName);
         String monNumberValue = monNumber == null ? null : monNumber.getMonNumber();
         List<EventConstruct> constructList = distinctEvents.get(distinctEvent);
         RegulatoryEvent regulatoryEvent = new RegulatoryEvent(constructList.toArray(new EventConstruct[constructList.size()]), monNumberValue, distinctEvent);
         regulatoryEventList.add(regulatoryEvent);
      }
      EventInfoBuilder builder = new EventInfoBuilder();
      return builder.build(regulatoryEventList, alignmentsArray, cropName);
   }

   private Map<EventCrop, List<EventAgencyAlignment>> getAlignmentsByEvent(EventAgencyAlignment[] eventAgencyAlignments) {
      EventAgencyAlignments delegate = new EventAgencyAlignments(eventAgencyAlignments);
      return delegate.getUniqueEventsAndAssociatedAlignments();
   }

   private Map<String, List<EventConstruct>> findDistinctEvents(List<EventConstruct> eventConstructs) {
      Map<String, List<EventConstruct>> eventMap = new HashMap<String, List<EventConstruct>>();
      List<EventConstruct> eventConstructList;
      for (EventConstruct eventConstruct : eventConstructs) {
         if (eventMap.containsKey(eventConstruct.getEvent())) {
            eventConstructList = eventMap.get(eventConstruct.getEvent());
         }
         else {
            eventConstructList = new ArrayList<EventConstruct>();
         }
         eventConstructList.add(eventConstruct);
         eventMap.put(eventConstruct.getEvent(), eventConstructList);
      }
      return eventMap;
   }
}

