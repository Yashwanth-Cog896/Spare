package com.monsanto.tps.lexicon.regulatory.eventsreginfo.bo;

import com.monsanto.tps.lexicon.eventsreginfo.transfer.EventRegInfo;
import com.monsanto.tps.lexicon.regulatory.eventsreginfo.dao.LexiconRegEventDao;
import com.monsanto.tps.lexicon.regulatory.eventsreginfo.domain.lexicon.LexiconRegEvent;
import com.monsanto.tps.lexicon.regulatory.eventsreginfo.util.dao.lexicon.TempSessionOcdDao;
import com.monsanto.tps.lexicon.regulatory.util.OrionCriteria;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: vvkalu
 * Date: Oct 10, 2010
 * Time: 5:09:13 PM
 * To change this template use File | Settings | File Templates.
 */
public class EventsRegInfoBusiness {
    private EventsBuilder builder;
    private LexiconRegEventDao lexiconRegEventDao;
    private TempSessionOcdDao tempSessionOcdDao;
    private static final Long REQUEST_ID = 2010113L;

    public List<EventRegInfo> findMonNumbersByCropAndMonNumber(String monNumber, String cropName) {
        LexiconRegEvent info = new LexiconRegEvent();
        info.setMonNumber(OrionCriteria.format(monNumber));
        info.setCrop(OrionCriteria.format(cropName));
        return builder.build(lexiconRegEventDao.findMonNumbers(info));
    }

    public List<EventRegInfo> findMonNumbersByEvent(String event) {
        LexiconRegEvent info = new LexiconRegEvent();
        info.setEvent(OrionCriteria.format(event));
        return builder.build(lexiconRegEventDao.findMonNumbers(info));
    }

    public List<EventRegInfo> findMonNumbersByPlasmidPmon(String plasmidPmon) {
        LexiconRegEvent info = new LexiconRegEvent();
        info.setPlasmIdPmon(OrionCriteria.format(plasmidPmon));
        return builder.build(lexiconRegEventDao.findMonNumbers(info));
    }

    public List<EventRegInfo> findMonNumbersByPlasmidPvCode(String plasmidPvCode) {
        LexiconRegEvent info = new LexiconRegEvent();
        info.setPlasmIdPvCode(OrionCriteria.format(plasmidPvCode));
        return builder.build(lexiconRegEventDao.findMonNumbers(info));
    }

    public List<EventRegInfo> findMonNumbersByTransformationBackground(String transformationBackground) {
        LexiconRegEvent info = new LexiconRegEvent();
        info.setTransformationBackground(OrionCriteria.format(transformationBackground));
        return builder.build(lexiconRegEventDao.findMonNumbers(info));
    }

    public List<EventRegInfo> findMonNumbersByRegulatoryTraitDescription(String regulatoryTraitDescription) {
        LexiconRegEvent info = new LexiconRegEvent();
        info.setRegulatoryTraitDescription(OrionCriteria.format(regulatoryTraitDescription));
        return builder.build(lexiconRegEventDao.findMonNumbers(info));
    }

    public List<EventRegInfo> findMonNumbersByRegulatoryGenesPresent(String regulatoryGenesPresent) {
        LexiconRegEvent info = new LexiconRegEvent();
        info.setRegulatoryGenesPresent(OrionCriteria.format(regulatoryGenesPresent));
        return builder.build(lexiconRegEventDao.findMonNumbers(info));
    }

    public List<EventRegInfo> findMonNumbersByRegulatedStatus(boolean regulatedStatus) {
        LexiconRegEvent info = new LexiconRegEvent();
        info.setRegulatedStatus(regulatedStatus);
        return builder.build(lexiconRegEventDao.findMonNumbers(info));
    }

    public List<EventRegInfo> findMonNumbersByJvNumber(String jvNumber) {
        LexiconRegEvent info = new LexiconRegEvent();
        info.setJvNumber(OrionCriteria.format(jvNumber));
        return builder.build(lexiconRegEventDao.findMonNumbers(info));
    }

    public List<EventRegInfo> findMonNumbersByOecdNumber(String oecdNumber) {
        LexiconRegEvent info = new LexiconRegEvent();
        info.setOecdNumber(OrionCriteria.format(oecdNumber));
        return builder.build(lexiconRegEventDao.findMonNumbers(info));
    }

    public List<EventRegInfo> findMonNumbersByMaterialName(String materialName) {
        LexiconRegEvent info = new LexiconRegEvent();
        info.setMaterialName(OrionCriteria.format(materialName));
        return builder.build(lexiconRegEventDao.findMonNumbers(info));
    }

    public List<EventRegInfo> findMonNumbersFromCollection(List<String> monNumbers) {
        List<EventRegInfo> monNumberList = new ArrayList<EventRegInfo>();
        if (monNumbers != null && !monNumbers.isEmpty()) {
            tempSessionOcdDao.insertText1Values(REQUEST_ID, monNumbers);
            monNumberList.addAll(builder.build(lexiconRegEventDao.findMonNumbersByCollectionCriteria()));
        }
        return monNumberList;
    }

    public void setBuilder(EventsBuilder builder) {
        this.builder = builder;
    }

    public void setLexiconRegEventDao(LexiconRegEventDao lexiconRegEventDao) {
        this.lexiconRegEventDao = lexiconRegEventDao;
    }

    public void setTempSessionOcdDao(TempSessionOcdDao tempSessionOcdDao) {
        this.tempSessionOcdDao = tempSessionOcdDao;
    }
}
