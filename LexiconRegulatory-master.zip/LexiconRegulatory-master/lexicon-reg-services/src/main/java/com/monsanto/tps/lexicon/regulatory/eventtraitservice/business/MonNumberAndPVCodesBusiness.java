/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.eventtraitservice.business;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import com.monsanto.tps.compliance.referencedata.molecularinfo.ConstructPVCodeAssignment;
import com.monsanto.tps.lexicon.commercialtrait.ComlTraitName;
import com.monsanto.tps.lexicon.commercialtrait.ComlTraitType;
import com.monsanto.tps.lexicon.eventtraitservice.transfer.EventMonNumber;
import com.monsanto.tps.lexicon.eventtraitservice.transfer.GermplasmEventTrait;
import com.monsanto.tps.lexicon.eventtraitservice.transfer.GermplasmEventTraitResponse;
import com.monsanto.tps.lexicon.eventtraitservice.transfer.MidasEventConstruct;
import com.monsanto.tps.lexicon.monnumber.MonNumberRegulatoryTraitDescription;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber;
import com.monsanto.tps.lexicon.regulatory.DB.midas.model.EventConstructEntity;
import com.monsanto.tps.lexicon.regulatory.DB.midas.model.GermplasmEventConstructEntity;
import com.monsanto.tps.lexicon.regulatory.eventsreginfo.util.dao.lexicon.TempSessionOcdDao;
import com.monsanto.tps.lexicon.regulatory.eventtraitservice.dao.GermplasmEventConstructDao;
import com.monsanto.tps.lexicon.regulatory.monnumber.dao.MonNumberDao;
import com.monsanto.tps.lexicon.regulatory.monnumber.util.MonNumberBeanUtil;
import org.apache.commons.lang.StringUtils;

import java.util.*;

/* vvkalu - 8/5/11 */
public class MonNumberAndPVCodesBusiness {

    private static final long REQUEST_ID = 20110808;
    public static final String FORWARD = "/";
    public static final String COMMA = ",";
    public static final String MON_NUMBER_PREFIX = "MON";
    private MonNumberDao monNumberDao;
    private GermplasmEventConstructDao germplasmEventConstructDao;
    private TempSessionOcdDao tempSessionOcdDao;
    private PVCodesBuilder pvCodesBuilder;
    private PVCodesTransformer pvCodesTransformer;
    private MonNumberBeanUtil monNumberBeanUtil;
    private MonNumberRegulatoryTraitDescription monNumberRegulatoryTraitDescription;

    public GermplasmEventTraitResponse findMonNumberAndPVCodes(Long germplasmId, GermplasmEventTraitResponse traitEventConstructs) {
        List<GermplasmEventConstructEntity> germplasmEventConstructs = germplasmEventConstructDao.findGermplasmEventConstructs(germplasmId);
        if (germplasmEventConstructs != null && !germplasmEventConstructs.isEmpty()) {
            Multimap<String, GermplasmEventConstructEntity> eventsToEventConstructsMap = getEventsToEventConstructsMap(germplasmEventConstructs);
            Multimap<String, MonNumber> eventToMonNumberMap = getEventToMonNumberMap(eventsToEventConstructsMap);
            Multimap<Long, ConstructPVCodeAssignment> constructIdToPVCodesMap = pvCodesBuilder.getConstructIdToPVCodesMap(eventsToEventConstructsMap,
                    eventToMonNumberMap);
            return buildGermplasmEventTraitResponse(eventsToEventConstructsMap, eventToMonNumberMap, constructIdToPVCodesMap, traitEventConstructs, germplasmId);
        }
        return traitEventConstructs;
    }

    private Multimap<String, GermplasmEventConstructEntity> getEventsToEventConstructsMap(
            List<GermplasmEventConstructEntity> germplasmEventConstructs) {
        Multimap<String, GermplasmEventConstructEntity> eventToEventConstructsMap = ArrayListMultimap.create();
        for (GermplasmEventConstructEntity eventConstruct : germplasmEventConstructs) {
            eventToEventConstructsMap.put(eventConstruct.getEventConstruct().getEventName(), eventConstruct);
        }
        return eventToEventConstructsMap;
    }

    private Multimap<String, MonNumber> getEventToMonNumberMap(Multimap<String, GermplasmEventConstructEntity> eventsToEventConstructsMap) {
        Multimap<String, MonNumber> eventToMonNumberMap = ArrayListMultimap.create();
        buildEventToMonNumberMapByEventName(eventsToEventConstructsMap, eventToMonNumberMap);
        buildEventToMonNumberMapByMonNumber(eventsToEventConstructsMap,eventToMonNumberMap);
        return eventToMonNumberMap;
    }

    private void buildEventToMonNumberMapByEventName(Multimap<String, GermplasmEventConstructEntity> eventsToEventConstructsMap, Multimap<String, MonNumber> eventToMonNumberMap) {
        Set<String> eventNames = eventsToEventConstructsMap.keySet();
      Set<String> individualEvenNames = retrieveIndividualEvenNames(eventNames);
        tempSessionOcdDao.clearValues(REQUEST_ID);
      tempSessionOcdDao.insertText1Values(REQUEST_ID, individualEvenNames);
        List<MonNumber> monNumbersByEventNames = monNumberDao.getMonNumbersByEventNames(REQUEST_ID);
        if (monNumbersByEventNames != null && !monNumbersByEventNames.isEmpty()) {
            for (String eventName : eventNames) {
                for (MonNumber monNumber : monNumbersByEventNames) {
                  if (split(eventName.toUpperCase(), FORWARD, COMMA).contains(monNumber.getEvent().toUpperCase())) {
                        eventToMonNumberMap.put(eventName, monNumber);
                    }
                }
            }
        }
    }

    private Set<String> retrieveIndividualEvenNames(Set<String> eventNames) {
      Set<String> individualEvenNames = new HashSet<String>();
      for (String eventName:eventNames){
        individualEvenNames.addAll(split(eventName,FORWARD, COMMA));
      }
      return individualEvenNames;
    }

    private void buildEventToMonNumberMapByMonNumber(Multimap<String, GermplasmEventConstructEntity> eventsToEventConstructsMap, Multimap<String, MonNumber> eventToMonNumberMap) {
      Set<String> eventNames = eventsToEventConstructsMap.keySet();
      Set<String> monNumbers = retrieveMonNumbers(eventNames);
      tempSessionOcdDao.clearValues(REQUEST_ID);
      tempSessionOcdDao.insertText1Values(REQUEST_ID, monNumbers);
      List<MonNumber> monNumbersByMonNumbers = monNumberDao.getMonNumbersByMonNumber(REQUEST_ID);
      if(monNumbersByMonNumbers != null && !monNumbersByMonNumbers.isEmpty()) {
          for (String eventName : eventNames) {
              for (MonNumber monNumber : monNumbersByMonNumbers) {
                  if (split(eventName.toUpperCase(),FORWARD,COMMA).contains(formatMonNumberToEvenName(monNumber.getMonNumber()))) {
                      eventToMonNumberMap.put(eventName, monNumber);
                  }
              }
          }
      }
    }

  private String formatMonNumberToEvenName(String monNumber) {
    if (StringUtils.isNotEmpty(monNumber) && monNumber.length()>4) {
      return monNumber.substring(0,MON_NUMBER_PREFIX.length()) + monNumber.substring(MON_NUMBER_PREFIX.length()+1).toUpperCase();
    }
    return monNumber;
  }

  private Set<String> retrieveMonNumbers(Set<String> eventNames) {
      Set<String> monNumbers = new HashSet<String>();
      Set<String> splitedEventNames = new HashSet<String>();
      for (String eventNameStr:eventNames){
        splitedEventNames.addAll(split(eventNameStr,FORWARD, COMMA));
      }
      for (String eventName:splitedEventNames){
        if (eventName.toUpperCase().startsWith(MON_NUMBER_PREFIX)){
          monNumbers.add(MON_NUMBER_PREFIX + " " + eventName.substring(MON_NUMBER_PREFIX.length()));
        }
      }
      return monNumbers;
    }


    private Set<String> split(String aString, String separatorChars1, String separatorChars2) {
      Set<String> resultSet = new HashSet<String>();
      if (StringUtils.isNotEmpty(aString))   {
         Set<String> workingStringSet = new HashSet<String>();
         workingStringSet.addAll(Arrays.asList(StringUtils.split(aString, separatorChars1))) ;
         for (String workingString:workingStringSet) {
            resultSet.addAll(Arrays.asList(StringUtils.split(workingString,separatorChars2)));
         }
      }
      return resultSet;
    }

    private GermplasmEventTraitResponse buildGermplasmEventTraitResponse(Multimap<String, GermplasmEventConstructEntity> eventsToEventConstructsMap,
                                                                         Multimap<String, MonNumber> eventToMonNumberMap,
                                                                         Multimap<Long, ConstructPVCodeAssignment> constructIdToPVCodesMap,
                                                                         GermplasmEventTraitResponse traitEventConstructs, Long germplasmId) {
        if (!eventToMonNumberMap.isEmpty() || !constructIdToPVCodesMap.isEmpty()) {
            GermplasmEventTrait germplasmEventTrait = new GermplasmEventTrait();
            germplasmEventTrait.setGermplasmId(germplasmId);
            List<MidasEventConstruct> midasEventConstructs = new ArrayList<MidasEventConstruct>();
            for (String eventName : eventsToEventConstructsMap.keySet()) {
                buildMidasEventConstruct(eventsToEventConstructsMap, eventToMonNumberMap, constructIdToPVCodesMap, midasEventConstructs, eventName);
            }
            germplasmEventTrait.setEventConstruct(midasEventConstructs);
            traitEventConstructs.getGermplasmEventTraits().add(germplasmEventTrait);
            return traitEventConstructs;
        }
        return traitEventConstructs;
    }

    private void buildMidasEventConstruct(Multimap<String, GermplasmEventConstructEntity> eventsToEventConstructsMap,
                                          Multimap<String, MonNumber> eventToMonNumberMap,
                                          Multimap<Long, ConstructPVCodeAssignment> constructIdToPVCodesMap,
                                          List<MidasEventConstruct> midasEventConstructs, String eventName) {
        MidasEventConstruct midasEventConstruct = new MidasEventConstruct();
        Collection<MonNumber> monNumbers = eventToMonNumberMap.get(eventName);
        if (monNumbers != null && !monNumbers.isEmpty()) {
            List<EventMonNumber> eventMonNumbers = new ArrayList<EventMonNumber>();
            for (MonNumber monNumber:monNumbers){
               EventMonNumber eventMonNumber = new EventMonNumber();
               eventMonNumber.setMonNumber(monNumber.getMonNumber());
               eventMonNumber.setMonNumberId(monNumber.getMonNumberId());
            String regulatoryTraitDescription = buildMonNumberRegulatoryTraitDescription(monNumber);
               eventMonNumber.setMonNumberRegTraitDesc(regulatoryTraitDescription);
               eventMonNumber.setEventName(monNumber.getEvent());
               eventMonNumbers.add(eventMonNumber);
        }
            midasEventConstruct.setEventMonNumbers(eventMonNumbers);
        }
        EventConstructEntity eventConstruct = eventsToEventConstructsMap.get(eventName).iterator().next().getEventConstruct();
        midasEventConstruct.setEventConstructId(eventConstruct.getId());
        midasEventConstruct.setEventName(eventConstruct.getEventName());
        midasEventConstruct.setConstructName(eventConstruct.getConstructName());
        setPVCodeValues(constructIdToPVCodesMap, midasEventConstruct, eventConstruct);
        midasEventConstructs.add(midasEventConstruct);
    }

    private String buildMonNumberRegulatoryTraitDescription(MonNumber monNumber) {
        Collection<ComlTraitName> comlTraitNameCollection = monNumberBeanUtil.buildComlTraitNames(monNumber.getComlTraitNames());
        Collection<ComlTraitType> comlTraitTypes = monNumberBeanUtil.buildComlTraitTypes(monNumber.getComlTraitTypes());
        return monNumberRegulatoryTraitDescription.gatherRegulatoryTraitDescription(comlTraitNameCollection, comlTraitTypes);
    }

    private void setPVCodeValues(Multimap<Long, ConstructPVCodeAssignment> constructIdToPVCodesMap, MidasEventConstruct midasEventConstruct,
                                 EventConstructEntity eventConstruct) {
        for (Long constructId : constructIdToPVCodesMap.keySet()) {
            if (eventConstruct.getId() == constructId) {
                Collection<ConstructPVCodeAssignment> constructPVCodeAssignments = constructIdToPVCodesMap.get(constructId);
                if (constructPVCodeAssignments != null && !constructPVCodeAssignments.isEmpty()) {
                    for (ConstructPVCodeAssignment pvCodeAssignment : constructPVCodeAssignments) {
                        midasEventConstruct.getPvCodes().addAll(pvCodesTransformer.formLexiconPVCodeList(pvCodeAssignment.getPVCodes()));
                    }
                }
            }
        }
    }

    public void setMonNumberDao(MonNumberDao monNumberDao) {
        this.monNumberDao = monNumberDao;
    }

    public void setGermplasmEventConstructDao(GermplasmEventConstructDao germplasmEventConstructDao) {
        this.germplasmEventConstructDao = germplasmEventConstructDao;
    }

    public void setTempSessionOcdDao(TempSessionOcdDao tempSessionOcdDao) {
        this.tempSessionOcdDao = tempSessionOcdDao;
    }

    public void setPvCodesBuilder(PVCodesBuilder pvCodesBuilder) {
        this.pvCodesBuilder = pvCodesBuilder;
    }

    public void setPvCodesTransformer(PVCodesTransformer pvCodesTransformer) {
        this.pvCodesTransformer = pvCodesTransformer;
    }

    public void setMonNumberBeanUtil(MonNumberBeanUtil monNumberBeanUtil) {
        this.monNumberBeanUtil = monNumberBeanUtil;
    }

    public void setMonNumberRegulatoryTraitDescription(MonNumberRegulatoryTraitDescription monNumberRegulatoryTraitDescription) {
        this.monNumberRegulatoryTraitDescription = monNumberRegulatoryTraitDescription;
    }
}