package com.monsanto.tps.lexicon.regulatory.event.query;

import com.monsanto.tps.lexicon.regulatory.event.model.RegulatoryEventConstructTransformation;

/**
 * rrchak1 - Jul 13, 2009 5:19:38 PM
 */
public class ExactMatchEventConstructTransformationsByEventAndCropQuery
   implements EventConstructTransformationsByEventAndCropQuery
{
   @Override
   public RegulatoryEventConstructTransformation[] find(String eventName, String cropGenusSpecies) {
      MidasRegulatoryEventConstructTransformationsByEventAndCropQuery query = new MidasRegulatoryEventConstructTransformationsByEventAndCropQuery(eventName, cropGenusSpecies);
      return query.find();
   }
}
