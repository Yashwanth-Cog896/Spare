package com.monsanto.tps.lexicon.regulatory.agency.service;

import com.monsanto.tps.lexicon.agency.AgencySaveUpdateRequest;
import com.monsanto.tps.lexicon.agency.AgencySaveUpdateResponse;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Agency;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.AgencyDepartment;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.AuditStaging;
import com.monsanto.tps.lexicon.regulatory.agency.dao.AgencyDao;
import com.monsanto.tps.lexicon.regulatory.agency.util.AgencyBeanUtil;
import com.monsanto.tps.lexicon.regulatory.agency.validation.AgencySaveUpdateValidator;
import com.monsanto.tps.lexicon.regulatory.audit.dao.AuditStagingDao;
import com.monsanto.tps.lexicon.regulatory.util.validationresults.ValidationResults;
import org.hibernate.SessionFactory;

import java.util.List;

/**
 * aagosw - Mar 5, 2009 6:58:21 AM
 */
public class AgencySaveUpdateProcessorImpl
   implements AgencySaveUpdateProcessor
{
   private AuditStagingDao auditStagingDao;

   private AgencySaveUpdateValidator validator;

   private SessionFactory sessionFactory;

   public void save(AgencySaveUpdateRequest[] agencySaveUpdateRequests, AgencyDao agencyDao, AgencyBeanUtil agencyBeanUtil, List<AgencySaveUpdateResponse> responseList, boolean commit) {
      for (int i = 0; i < agencySaveUpdateRequests.length; i++) {
         AgencySaveUpdateRequest request = agencySaveUpdateRequests[i];
         if (checkIfCanCommit(request, responseList, commit)) {
            AgencyDepartment department = agencyBeanUtil.buildAgencyDepartmentDBObject(request);
            processSave(agencyDao, responseList, request, department);
         }
      }
   }

   private void processSave(AgencyDao agencyDao, List<AgencySaveUpdateResponse> responseList, AgencySaveUpdateRequest request, AgencyDepartment department) {
      AuditStaging auditStaging = auditStagingDao.create("UNKNOWNCXFSERVICEUSER", "SAVE AGENCY", request.getAuditComment(), "LEXICON");
      try {
         Agency agency = saveOrGetAgency(agencyDao, department.getAgency());
         department.setAgency(agency);
         saveDepartmentIfNotExists(agencyDao, department);
         responseList.add(new AgencySaveUpdateResponseBuilderImpl().buildResponse(request, new ValidationResults(new String[0])));
      }
      catch (Exception e) {
         sessionFactory.getCurrentSession().clear();
         responseList.add(new AgencySaveUpdateResponseBuilderImpl().buildResponse(request, new ValidationResults(e)));
      }
      finally {
         auditStagingDao.delete(auditStaging);
      }
   }

   private boolean checkIfCanCommit(AgencySaveUpdateRequest request, List<AgencySaveUpdateResponse> responseList, boolean commit) {
      boolean canCommit = true;
      ValidationResults validationResults = validator.validate(request);
      if (!commit || validationResults.hasErrors()) {
         responseList.add(new AgencySaveUpdateResponseBuilderImpl().buildResponse(request, validationResults));
         canCommit = false;
      }
      return canCommit;
   }

   private void saveDepartmentIfNotExists(AgencyDao agencyDao, AgencyDepartment department) {
      AgencyDepartment actualAgencyDepartment = getAgencyDepartment(agencyDao, department);
      if (actualAgencyDepartment == null) {
         agencyDao.saveAgencyDepartment(department);
         actualAgencyDepartment = department;
      }
   }

   private AgencyDepartment getAgencyDepartment(AgencyDao agencyDao, AgencyDepartment department) {
      return agencyDao.getAgencyDepartmentByAgencyAndAbbr(department.getAgency(), department.getAgencyDeptAbbr());
   }

   private Agency saveOrGetAgency(AgencyDao agencyDao, Agency agency) {
      Agency actualAgency = getAgency(agencyDao, agency);
      if (actualAgency == null) {
         agencyDao.saveAgency(agency);
         actualAgency = agency;
      }
      return actualAgency;
   }

   private Agency getAgency(AgencyDao agencyDao, Agency agency) {
      return agencyDao.getAgencyByAbbvAndCountry(agency.getAgencyAbbr(), agency.getCountry());
   }

   public void update(AgencySaveUpdateRequest[] agencySaveUpdateRequests, AgencyDao agencyDao, AgencyBeanUtil agencyBeanUtil, List<AgencySaveUpdateResponse> responseList, boolean commit) {
      for (int i = 0; i < agencySaveUpdateRequests.length; i++) {
         AgencySaveUpdateRequest request = agencySaveUpdateRequests[i];
         if (checkIfCanCommit(request, responseList, commit)) {
            AgencyDepartment department = agencyBeanUtil.buildAgencyDepartmentDBObject(request);
            processUpdate(agencyDao, responseList, request, department);
         }
      }
   }

   private void processUpdate(AgencyDao agencyDao, List<AgencySaveUpdateResponse> responseList, AgencySaveUpdateRequest request, AgencyDepartment department) {
      AuditStaging auditStaging = auditStagingDao.create("UNKNOWNCXFSERVICEUSER", "UPATE AGENCY", request.getAuditComment(), "LEXICON");
      try {
         agencyDao.mergeAgency(department.getAgency(), getAgencyForUpdate(agencyDao, department.getAgency()));
         agencyDao.mergeAgencyDepartment(department, getAgencyDepartmentForUpdate(agencyDao, department));
         responseList.add(new AgencySaveUpdateResponseBuilderImpl().buildResponse(request, new ValidationResults(new String[0])));
      }
      catch (Exception e) {
         sessionFactory.getCurrentSession().clear();
         responseList.add(new AgencySaveUpdateResponseBuilderImpl().buildResponse(request, new ValidationResults(e)));
      }
      finally {
         auditStagingDao.delete(auditStaging);
      }
   }

   private Agency getAgencyForUpdate(AgencyDao agencyDao, Agency agency) {
      return agencyDao.getAgencyByPubkey(agency.getAgencyPubkey());
   }

   private AgencyDepartment getAgencyDepartmentForUpdate(AgencyDao agencyDao, AgencyDepartment agencyDepartment) {
      return agencyDao.getAgencyDepartmentByPubkey(agencyDepartment.getAgencyDeptPubkey());
   }

   public void setAuditStagingDao(AuditStagingDao auditStagingDao) {
      this.auditStagingDao = auditStagingDao;
   }

   public void setValidator(AgencySaveUpdateValidator validator) {
      this.validator = validator;
   }

   public void setSessionFactory(SessionFactory sessionFactory) {
      this.sessionFactory = sessionFactory;
   }
}
