package com.monsanto.tps.lexicon.regulatory.proteinname.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName;
import com.monsanto.tps.lexicon.regulatory.util.WildcardUtil;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 3/1/12
 * Time: 2:16 PM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class ProteinNameDAOImpl implements ProteinNameDAO {

    @Resource
    private SessionFactory sessionFactory;

    @Override
    public List<ProteinName> findProteinNames(final String proteinName) {

        final Session session = sessionFactory.getCurrentSession();

        final Query query = session.getNamedQuery("findActiveProteinNameIgnoreCaseSort");
        query.setParameter("proteinName", WildcardUtil.replaceEmptyStringWithWildcard(proteinName));

        return (List<ProteinName>) query.list();
    }
}
