package com.monsanto.tps.lexicon.regulatory.nonmonevent.dao;

import com.monsanto.tcc.lexiconcommon.ArrayUtils;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName;
import com.monsanto.tps.lexicon.regulatory.util.collection.Sets;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;

import java.util.Collection;
import java.util.List;

/**
 * nbwald - May 21, 2009 8:24:32 PM
 */
public class ProteinNameDao
{
   private final SessionFactory sessionFactory;

   public ProteinNameDao(SessionFactory sessionFactory) {
      this.sessionFactory = sessionFactory;
   }

   public Collection<ProteinName> findByPubkeys(String... proteinNamePubkeys) {
      if (ArrayUtils.isNullOrEmpty(proteinNamePubkeys)) {
         return Sets.asSet();
      }
      Session session = sessionFactory.getCurrentSession();
      List results = session.getNamedQuery("proteinNamesByPubkeys").setParameterList("proteinNamePubkeys", proteinNamePubkeys).list();
      return (Collection<ProteinName>) results;
   }
}
