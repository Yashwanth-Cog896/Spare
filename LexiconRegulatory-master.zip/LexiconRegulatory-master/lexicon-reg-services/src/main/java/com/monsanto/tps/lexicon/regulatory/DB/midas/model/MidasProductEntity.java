/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.DB.midas.model;

import com.monsanto.tps.lexicon.regulatory.DB.fbscommon.model.ProductXrefEntity;

import java.io.Serializable;
import java.util.List;

/* vvkalu - 7/22/11 */
public class MidasProductEntity implements Serializable {
    private long id;
    private ProductXrefEntity xref;
    private List<ProductGermplasmEntity> productGermplasms;
    private MidasCropEntity crop;
    private boolean refActive;

    public boolean isRefActive() {
        return refActive;
    }

    public void setRefActive(boolean refActive) {
        this.refActive = refActive;
    }

    public MidasCropEntity getCrop() {
        return crop;
    }

    public void setCrop(MidasCropEntity crop) {
        this.crop = crop;
    }

    public List<ProductGermplasmEntity> getProductGermplasms() {
        return productGermplasms;
    }

    public void setProductGermplasms(List<ProductGermplasmEntity> productGermplasms) {
        this.productGermplasms = productGermplasms;
    }

    public ProductXrefEntity getXref() {
        return xref;
    }

    public void setXref(ProductXrefEntity xref) {
        this.xref = xref;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
}