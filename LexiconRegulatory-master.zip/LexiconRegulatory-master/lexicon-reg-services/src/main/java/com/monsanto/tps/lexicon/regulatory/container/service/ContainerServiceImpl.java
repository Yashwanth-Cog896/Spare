package com.monsanto.tps.lexicon.regulatory.container.service;
import com.monsanto.tps.lexicon.container.*;
import com.monsanto.tps.lexicon.regulatory.container.business.ContainerBusiness;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 3/1/12
 * Time: 2:14 PM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class ContainerServiceImpl implements ContainerService {

    @Resource
    private ContainerBusiness containerBusiness;

    @Override
    public List<OrionContainer> findContainerTypes(final String containerType) {
        return containerBusiness.findContainerTypes(containerType);
    }
}
