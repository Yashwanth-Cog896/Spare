/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model;

import java.io.Serializable;
import java.util.Collection;

/* vvkalu - 7/26/11 */
public class LexiconStageEntity implements Serializable {
    private long id;
    private String stageAbbr;
    private String stageDesc;
    private boolean comlStage;
    private String stagePubkey;
    private Collection<LexiconProductStageEntity> productStages;
    private long orderByNum;

    public long getOrderByNum() {
        return orderByNum;
    }

    public void setOrderByNum(long orderByNum) {
        this.orderByNum = orderByNum;
    }

    public Collection<LexiconProductStageEntity> getProductStages() {
        return productStages;
    }

    public void setProductStages(Collection<LexiconProductStageEntity> productStages) {
        this.productStages = productStages;
    }

    public String getStagePubkey() {
        return stagePubkey;
    }

    public void setStagePubkey(String stagePubkey) {
        this.stagePubkey = stagePubkey;
    }

    public boolean getComlStage() {
        return comlStage;
    }

    public void setComlStage(boolean comlStage) {
        this.comlStage = comlStage;
    }

    public String getStageDesc() {
        return stageDesc;
    }

    public void setStageDesc(String stageDesc) {
        this.stageDesc = stageDesc;
    }

    public String getStageAbbr() {
        return stageAbbr;
    }

    public void setStageAbbr(String stageAbbr) {
        this.stageAbbr = stageAbbr;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
}