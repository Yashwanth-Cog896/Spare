package com.monsanto.tps.lexicon.regulatory.nonmonevent.validation;

import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;

/**
 * nbwald - May 21, 2009 6:15:38 PM
 */
public class EventHasSingleConstructRule
   implements Rule<String>
{
   private final String[] constructNames;

   public EventHasSingleConstructRule(String... constructNames) {
      this.constructNames = constructNames;
   }

   @Override
   public boolean violated() {
      return constructNames.length > 1;
   }

   @Override
   public String getViolation() {
      return "Event has multiple constructs.";
   }
}
