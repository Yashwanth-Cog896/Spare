package com.monsanto.tps.lexicon.regulatory.eventsreginfo.util.dao.lexicon;

import com.monsanto.tps.lexicon.regulatory.eventsreginfo.util.domain.lexicon.TempSessionOcd;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import java.util.Collection;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: vvkalu
 * Date: Oct 11, 2010
 * Time: 8:48:36 AM
 */
public class TempSessionOcdDaoImpl implements TempSessionOcdDao {

    private final SessionFactory sessionFactory;
    private static final long DEFAULT_NUMBER = 0L;
    private static final String DEFAULT_STRING = "I";

    TempSessionOcdDaoImpl(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    @Override
    public void insertText1Values(long requestId, Collection<String> ids) {
        Session session = sessionFactory.getCurrentSession();
        long sortOrder = 0;
        for (String id : ids) {
            TempSessionOcd tempSessionOcd = new TempSessionOcd();
            tempSessionOcd.setRequestId(requestId);
            tempSessionOcd.setSortOrder(sortOrder);
            tempSessionOcd.setText1(id);
            tempSessionOcd.setNumber1(DEFAULT_NUMBER);
            session.save(tempSessionOcd);
            sortOrder++;
        }
        session.flush();
    }

    @Override
    public void insertNumber1Values(long requestId, Collection<Long> values) {
        Session session = sessionFactory.getCurrentSession();
        long sortOrder = 0;
        for (Long value : values) {
            TempSessionOcd tempSessionOcd = new TempSessionOcd();
            tempSessionOcd.setRequestId(requestId);
            tempSessionOcd.setSortOrder(sortOrder);
            tempSessionOcd.setText1(DEFAULT_STRING);
            tempSessionOcd.setNumber1(value);
            session.save(tempSessionOcd);
            sortOrder++;
        }
        session.flush();
    }

    public void clearValues(long requestId) {
        Session session = sessionFactory.getCurrentSession();
        Query query = session.createQuery("from TempSessionOcd tempSessionOcd where tempSessionOcd.requestId = " + requestId);
        List<TempSessionOcd> list = (List<TempSessionOcd>)query.list();
        for (TempSessionOcd tempSessionOcd : list) {
            session.delete(tempSessionOcd);
        }
        session.flush();
    }
}
