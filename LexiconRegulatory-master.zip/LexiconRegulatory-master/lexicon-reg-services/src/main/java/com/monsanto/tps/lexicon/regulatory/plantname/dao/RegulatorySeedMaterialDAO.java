package com.monsanto.tps.lexicon.regulatory.plantname.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.PlantProduct;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 6/19/12
 * Time: 10:06 PM
 */
public interface RegulatorySeedMaterialDAO {
    List<PlantProduct> findMonsantoProductNames(String productName);
    List<PlantProduct> findCompetitorProductNames(String productName);
}
