package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model;

import java.util.Date;

/**
 * nbwald - Jan 9, 2009 2:17:36 PM
 */
public class EventAgencyAlignment {
    private long eventAgencyAlignmentId;
    private String eventAgencyAlignmentPubkey;
    private String materialName;
    private Agency agency;
    private String regulated;
    private Date deregulatedEffectiveDate;
    private Double maxQuantity;
    private Crop crop;
    private Boolean discoveryMaterial;
    private AgencyMaterialType agencyMaterialType;
    private MaterialChemicalName materialChemicalName;
    private Date createdDate;
    private String createdUserID;
    private Date modifiedDate;
    private String modifiedUserId;

    public Crop getCrop() {
        return crop;
    }

    public void setCrop(Crop crop) {
        this.crop = crop;
    }

    public Double getMaxQuantity() {
        return maxQuantity;
    }

    public void setMaxQuantity(Double maxQuantity) {
        this.maxQuantity = maxQuantity;
    }

    public Date getDeregulatedEffectiveDate() {
        return deregulatedEffectiveDate;
    }

    public void setDeregulatedEffectiveDate(Date deregulatedEffectiveDate) {
        this.deregulatedEffectiveDate = deregulatedEffectiveDate;
    }

    public String getRegulated() {
        return regulated;
    }

    public void setRegulated(String regulated) {
        this.regulated = regulated;
    }

    public Agency getAgency() {
        return agency;
    }

    public void setAgency(Agency agency) {
        this.agency = agency;
    }

    public String getMaterialName() {
        return materialName;
    }

    public void setMaterialName(String materialName) {
        this.materialName = materialName;
    }

    public String getEventAgencyAlignmentPubkey() {
        return eventAgencyAlignmentPubkey;
    }

    public void setEventAgencyAlignmentPubkey(String eventAgencyAlignmentPubkey) {
        this.eventAgencyAlignmentPubkey = eventAgencyAlignmentPubkey;
    }

    public long getEventAgencyAlignmentId() {
        return eventAgencyAlignmentId;
    }

    public void setEventAgencyAlignmentId(long eventAgencyAlignmentId) {
        this.eventAgencyAlignmentId = eventAgencyAlignmentId;
    }

    public Boolean getDiscoveryMaterial() {
        return discoveryMaterial;
    }

    public void setDiscoveryMaterial(Boolean discoveryMaterial) {
        this.discoveryMaterial = discoveryMaterial;
    }

    public AgencyMaterialType getAgencyMaterialType() {
        return agencyMaterialType;
    }

    public void setAgencyMaterialType(AgencyMaterialType agencyMaterialType) {
        this.agencyMaterialType = agencyMaterialType;
    }

    public MaterialChemicalName getMaterialChemicalName() {
        return materialChemicalName;
    }

    public void setMaterialChemicalName(MaterialChemicalName materialChemicalName) {
        this.materialChemicalName = materialChemicalName;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedUserID() {
        return createdUserID;
    }

    public void setCreatedUserID(String createdUserID) {
        this.createdUserID = createdUserID;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getModifiedUserId() {
        return modifiedUserId;
    }

    public void setModifiedUserId(String modifiedUserId) {
        this.modifiedUserId = modifiedUserId;
    }
}
