package com.monsanto.tps.lexicon.regulatory.storagecondition.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.StorageCondition;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 3/1/12
 * Time: 2:15 PM
 * To change this template use File | Settings | File Templates.
 */
public interface StorageConditionDAO {
    List<StorageCondition> findStorageConditions(String storageCondition);
}
