package com.monsanto.tps.lexicon.regulatory.event.strategy;

import com.monsanto.tcc.lexiconcommon.ArrayUtils;
import com.monsanto.tps.lexicon.event.EventInfo;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber;
import com.monsanto.tps.lexicon.regulatory.event.delegate.EventInfoBuilder;
import com.monsanto.tps.lexicon.regulatory.event.model.EventConstruct;
import com.monsanto.tps.lexicon.regulatory.event.model.RegulatoryEvent;
import com.monsanto.tps.lexicon.regulatory.event.queryset.EventCrop;
import com.monsanto.tps.lexicon.regulatory.event.queryset.EventSearchServiceQuerySet;
import com.monsanto.tps.lexicon.regulatory.event.queryset.RegulatoryEventResponse;

import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
/**
 * nbwald - Jan 30, 2009 11:29:24 AM
 */
public class EventInfoByMonNumberStrategyImpl
   implements EventInfoByMonNumberStrategy
{
   private EventSearchServiceQuerySet querySet;

   public EventInfoByMonNumberStrategyImpl(EventSearchServiceQuerySet querySet) {
      this.querySet = querySet;
   }

   public EventInfo find(String monNumberValue) {
      MonNumber monNumber = querySet.findMonNumber(monNumberValue);
      if (monNumber == null) {
         return null;
      }
      else {
         List<RegulatoryEventResponse> responses = querySet.findRegulatoryEventByEventAndCrop(Arrays.asList(new EventCrop(monNumber.getEvent(), monNumber.getCrop().getCropName())));
         if((responses!=null)&&(!responses.isEmpty())){
             List<EventConstruct> eventConstructs = responses.get(0).getEventConstructs();
             RegulatoryEvent event = new RegulatoryEvent(eventConstructs.toArray(new EventConstruct[eventConstructs.size()]), monNumber.getMonNumber(), monNumber.getEvent());
             return  buildEventInfo(Arrays.asList(event), monNumber.getCrop().getCropName(), monNumber.getEvent());
         }
          else {
             return null;
         }
      }
   }

   private EventInfo buildEventInfo(List<RegulatoryEvent> eventList, String cropName, String eventName) {
      EventAgencyAlignment[] eventAgencyAlignments = querySet.findEventAgencyAlignmentsByEventAndCrop(eventName, cropName);
      EventInfoBuilder builder = new EventInfoBuilder();
      return builder.build(eventList, eventAgencyAlignments, cropName);
   }
}
