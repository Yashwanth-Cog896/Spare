package com.monsanto.tps.lexicon.regulatory.event.query;

import com.monsanto.tps.lexicon.regulatory.event.model.RegulatoryEventConstructTransformation;
import org.apache.commons.lang.ArrayUtils;

/**
 * rrchak1 - Jul 13, 2009 5:02:09 PM
 */
public class CompositeEventConstructTransformationsByEventAndCropQuery
   implements EventConstructTransformationsByEventAndCropQuery
{
   private EventConstructTransformationsByEventAndCropQuery exactMatchQuery;
   private EventConstructTransformationsByEventAndCropQuery stackedEventQuery;

   public CompositeEventConstructTransformationsByEventAndCropQuery(EventConstructTransformationsByEventAndCropQuery exactMatchQuery, EventConstructTransformationsByEventAndCropQuery stackedEventQuery) {
      this.stackedEventQuery = stackedEventQuery;
      this.exactMatchQuery = exactMatchQuery;
   }

   @Override
   public RegulatoryEventConstructTransformation[] find(String eventName, String cropGenusSpecies) {
      RegulatoryEventConstructTransformation[] eventConstructTransformations = exactMatchQuery.find(eventName, cropGenusSpecies);
      if (stackedEvent(eventName) && ArrayUtils.isEmpty(eventConstructTransformations)) {
         eventConstructTransformations = stackedEventQuery.find(eventName, cropGenusSpecies);
      }
      return eventConstructTransformations;
   }

   private boolean stackedEvent(String eventName) {
      return eventName.indexOf(",") > 0 || eventName.indexOf("/") > 0;
   }
}
