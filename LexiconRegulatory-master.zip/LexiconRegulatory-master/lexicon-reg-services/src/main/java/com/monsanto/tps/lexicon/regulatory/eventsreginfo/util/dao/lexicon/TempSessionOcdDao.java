package com.monsanto.tps.lexicon.regulatory.eventsreginfo.util.dao.lexicon;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: vvkalu
 * Date: Oct 11, 2010
 * Time: 8:46:47 AM
 */
public interface TempSessionOcdDao {
    
    void insertText1Values(long requestId, Collection<String> ids);
    void insertNumber1Values(long requestId, Collection<Long> values);
    void clearValues(long requestId);
}
