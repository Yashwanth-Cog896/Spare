package com.monsanto.tps.lexicon.regulatory.event.dao.eventconstructtransformation;

/**
 * User: pjberry
 * Date: Jul 27, 2007
 * Time: 1:49:57 PM
 */
public interface RegulatoryEventConstructTransformationByEventNameAndCropQuerySQL
{
   String EVENT_ALIAS = "Event";
   String CONSTRUCT_ALIAS = "Construct";
   String TRANSFORMATION_BACKGROUND_ALIAS = "TransformationBackGround";
}
