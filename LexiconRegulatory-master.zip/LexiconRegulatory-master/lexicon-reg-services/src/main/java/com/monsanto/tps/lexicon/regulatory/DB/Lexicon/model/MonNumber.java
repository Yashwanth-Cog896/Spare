package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model;

import java.sql.Timestamp;
import java.util.Collection;
import java.util.HashSet;

/**
 * rrchak1 - Dec 18, 2008 2:42:19 PM
 */
public class MonNumber
{
   private long monNumberId;
   private String monNumber;
   private Crop crop;
   private String event;
   private String materialName;
   private boolean activeStatus;
   private String previousNames;
   private boolean locked;
   private String transformationBackground;
   private String regulatoryGenesPresent;
   private String regulatoryParentalLine;
   private String oecdNumber;
   private boolean regulatedStatus;
   private String jvNumber;
   private Timestamp oecdNumberCommunicationDate;
   private Collection<MonNumberConstruct> monNumberConstructs = new HashSet<MonNumberConstruct>();
   private Collection<ComlTraitName> comlTraitNames = new HashSet<ComlTraitName>();
   private Collection<ComlTraitType> comlTraitTypes = new HashSet<ComlTraitType>();
   private Collection<ProteinName> proteinNames = new HashSet<ProteinName>();

   public MonNumber() {
   }

   public MonNumber(boolean activeStatus, Crop crop, String event, String jvNumber, boolean locked, String materialName,
                    String monNumber, String oecdNumber, Timestamp oecdCommunicationDate, boolean regulatedStatus, String regulatoryGenesPresent,
                    String transformationBackground, String regulatoryParentalLine)
   {
      this.activeStatus = activeStatus;
      this.crop = crop;
      this.event = event;
      this.jvNumber = jvNumber;
      this.locked = locked;
      this.materialName = materialName;
      this.monNumber = monNumber;
      this.oecdNumber = oecdNumber;
      this.oecdNumberCommunicationDate = oecdCommunicationDate;
      this.regulatedStatus = regulatedStatus;
      this.regulatoryGenesPresent = regulatoryGenesPresent;
      this.transformationBackground = transformationBackground;
      this.regulatoryParentalLine = regulatoryParentalLine;
   }

   public long getMonNumberId() {
      return monNumberId;
   }

   public void setMonNumberId(long monNumberId) {
      this.monNumberId = monNumberId;
   }

   public String getMonNumber() {
      return monNumber;
   }

   public void setMonNumber(String monNumber) {
      this.monNumber = monNumber;
   }


   public Crop getCrop() {
      return crop;
   }

   public void setCrop(Crop crop) {
      this.crop = crop;
   }


   public String getEvent() {
      return event;
   }

   public void setEvent(String event) {
      this.event = event;
   }


   public String getMaterialName() {
      return materialName;
   }

   public void setMaterialName(String materialName) {
      this.materialName = materialName;
   }


   public String getPreviousNames() {
      return previousNames;
   }

   public void setPreviousNames(String previousNames) {
      this.previousNames = previousNames;
   }


   public String getTransformationBackground() {
      return transformationBackground;
   }

   public void setTransformationBackground(String transformationBackground) {
      this.transformationBackground = transformationBackground;
   }

   public String getRegulatoryGenesPresent() {
      return regulatoryGenesPresent;
   }

   public void setRegulatoryGenesPresent(String regulatoryGenesPresent) {
      this.regulatoryGenesPresent = regulatoryGenesPresent;
   }

   public String getOecdNumber() {
      return oecdNumber;
   }

   public void setOecdNumber(String oecdNumber) {
      this.oecdNumber = oecdNumber;
   }

   public Timestamp getOecdNumberCommunicationDate() {
      return oecdNumberCommunicationDate;
   }

   public void setOecdNumberCommunicationDate(Timestamp oecdNumberCommunicationDate) {
      this.oecdNumberCommunicationDate = oecdNumberCommunicationDate;
   }

   public boolean isRegulatedStatus() {
      return regulatedStatus;
   }

   public void setRegulatedStatus(boolean regulatedStatus) {
      this.regulatedStatus = regulatedStatus;
   }

   public String getJvNumber() {
      return jvNumber;
   }

   public void setJvNumber(String jvNumber) {
      this.jvNumber = jvNumber;
   }

   public boolean isLocked() {
      return locked;
   }

   public void setLocked(boolean locked) {
      this.locked = locked;
   }

   public boolean isActiveStatus() {
      return activeStatus;
   }


   public void setActiveStatus(boolean activeStatus) {
      this.activeStatus = activeStatus;
   }

   public Collection<ComlTraitType> getComlTraitTypes() {
      return comlTraitTypes;
   }

   public void setComlTraitTypes(Collection<ComlTraitType> comlTraitTypes) {
      this.comlTraitTypes = comlTraitTypes;
   }

   public Collection<ProteinName> getProteinNames() {
      return proteinNames;
   }

   public void setProteinNames(Collection<ProteinName> proteinNames) {
      this.proteinNames = proteinNames;
   }

   public Collection<MonNumberConstruct> getMonNumberConstructs() {
      return monNumberConstructs;
   }

   public void setMonNumberConstructs(Collection<MonNumberConstruct> monNumberConstructs) {
      this.monNumberConstructs = monNumberConstructs;
   }

   public Collection<ComlTraitName> getComlTraitNames() {
      return comlTraitNames;
   }

   public void setComlTraitNames(Collection<ComlTraitName> comlTraitNames) {
      this.comlTraitNames = comlTraitNames;
   }

   public String getRegulatoryParentalLine() {
      return regulatoryParentalLine;
   }

   public void setRegulatoryParentalLine(String regulatoryParentalLine) {
      this.regulatoryParentalLine = regulatoryParentalLine;
   }
}
