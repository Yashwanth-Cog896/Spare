package com.monsanto.tps.lexicon.regulatory.event.service;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tps.lexicon.event.EventAgencyAlignmentRequest;
import com.monsanto.tps.lexicon.event.EventAgencyAlignmentRequestInfo;
import com.monsanto.tps.lexicon.event.EventAgencyAlignmentResponse;
import com.monsanto.tps.lexicon.event.EventAgencyAlignmentService;
import com.monsanto.tps.lexicon.event.EventAgencyAlignmentUpdateInfo;
import com.monsanto.tps.lexicon.event.EventAgencyAlignmentUpdateRequest;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;
import com.monsanto.tps.lexicon.regulatory.event.dao.EventAgencyAlignmentDao;
import com.monsanto.tps.lexicon.regulatory.event.delegate.EventAgencyAlignmentRequestParser;
import com.monsanto.tps.lexicon.regulatory.event.validation.EventAgencyAlignmentValidator;
import com.monsanto.tps.lexicon.regulatory.helpers.AuditStage;
import com.monsanto.tps.aop.metric.PerformanceMetric;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * rrchak1 - Feb 3, 2009 2:33:32 PM
 */
public class EventAgencyAlignmentServiceImpl
   implements EventAgencyAlignmentService
{
   private EventAgencyAlignmentDao eventAgencyAlignmentDao;
   private EventAgencyAlignmentRequestParser eventAgencyAlignmentRequestParser;
   private EventAgencyAlignmentValidator eventAgencyAlignmentValidator;

   @PerformanceMetric(task = "EventAgencyAlignment-Save", comment = "Save event agency alignments")
   @AuditStage(processName = "SAVE EVENTAGENCYALIGNMENT", auditComment = "AUDIT RECORD FOR SAVE EVENTAGENCYALIGNMENT", auditRequestor = "LEXICON")
   public EventAgencyAlignmentResponse[] save(EventAgencyAlignmentRequest eventAgencyAlignmentRequest) {
      if (!ArrayUtils.isEmpty(eventAgencyAlignmentRequest.getEventAgencyAlignments())) {
         List<EventAgencyAlignmentResponse> responseList = processSave(eventAgencyAlignmentRequest);
         return responseList.toArray(new EventAgencyAlignmentResponse[responseList.size()]);
      }
      return new EventAgencyAlignmentResponse[0];
   }

   private List<EventAgencyAlignmentResponse> processSave(EventAgencyAlignmentRequest eventAgencyAlignmentRequest) {
      eventAgencyAlignmentRequest.setEvent(updateEventIfStacked(eventAgencyAlignmentRequest.getEvent()));
      List<EventAgencyAlignmentResponse> responseList = new ArrayList<EventAgencyAlignmentResponse>();
      for (EventAgencyAlignmentRequestInfo eventAgencyAlignmentRequestInfo : eventAgencyAlignmentRequest.getEventAgencyAlignments()) {
         EventAgencyAlignmentResponse eventAgencyAlignmentResponse = new EventAgencyAlignmentResponse();
         try {
            eventAgencyAlignmentValidator.valiateAgencyAlignedToEventAndCrop(eventAgencyAlignmentRequestInfo.getAgencyPubkey(), eventAgencyAlignmentRequest);
            EventAgencyAlignment eventAgencyAlignment = eventAgencyAlignmentRequestParser.buildEventAgencyAlignmentFromRequest(eventAgencyAlignmentRequestInfo, eventAgencyAlignmentRequest);
            if (!eventAgencyAlignmentRequest.isValidateOnly()) {
               doSave(eventAgencyAlignmentResponse, eventAgencyAlignment);
            }
            eventAgencyAlignmentResponse.setSuccess(true);
         }
         catch (WrappingException e) {
            eventAgencyAlignmentResponse.setMessage(e.getMessage());
         }
         responseList.add(eventAgencyAlignmentResponse);
      }
      return responseList;
   }

   private String updateEventIfStacked(String eventName) {
      if (StringUtils.contains(eventName, ",") || StringUtils.contains(eventName, "/")) {
         return changeOrderOfStackedEvents(eventName);
      }
      return eventName;
   }

   private String changeOrderOfStackedEvents(String eventName) {
      String modifiedEventName = eventName;
      String[] eventArray = new String[]{};
      if (StringUtils.contains(eventName, ",")) {
         eventArray = StringUtils.split(eventName, ",");
      }
      else if (StringUtils.contains(eventName, "/")) {
         eventArray = StringUtils.split(eventName, "/");
      }
      if (com.monsanto.tcc.lexiconcommon.ArrayUtils.hasItems(eventArray)) {
         List<String> stringList = Arrays.asList(eventArray);
         Collections.sort(stringList);
         eventArray = stringList.toArray(new String[stringList.size()]);
         modifiedEventName = StringUtils.join(eventArray, ",");
      }

      return modifiedEventName;
   }

   private void doSave(EventAgencyAlignmentResponse eventAgencyAlignmentResponse, EventAgencyAlignment alignment)
      throws WrappingException
   {
      EventAgencyAlignment eventAgencyAlignment = eventAgencyAlignmentDao.save(alignment);
      eventAgencyAlignmentResponse.setEventAgencyAlignmentPubkey(eventAgencyAlignment.getEventAgencyAlignmentPubkey());
   }

   public void setEventAgencyAlignmentDao(EventAgencyAlignmentDao eventAgencyAlignmentDao) {
      this.eventAgencyAlignmentDao = eventAgencyAlignmentDao;
   }

   public void setEventAgencyAlignmentRequestParser(EventAgencyAlignmentRequestParser eventAgencyAlignmentRequestParser) {
      this.eventAgencyAlignmentRequestParser = eventAgencyAlignmentRequestParser;
   }

   public void setEventAgencyAlignmentValidator(EventAgencyAlignmentValidator eventAgencyAlignmentValidator) {
      this.eventAgencyAlignmentValidator = eventAgencyAlignmentValidator;
   }


   @PerformanceMetric(task = "EventAgencyAlignment-Update", comment = "Save event agency alignments")
   @AuditStage(processName = "UPDATE EVENTAGENCYALIGNMENT", auditComment = "AUDIT RECORD FOR UPDATE EVENTAGENCYALIGNMENT", auditRequestor = "LEXICON")
   public EventAgencyAlignmentResponse[] update(EventAgencyAlignmentUpdateRequest updateRequest) {
      List<EventAgencyAlignmentResponse> responseList = new ArrayList<EventAgencyAlignmentResponse>();
      EventAgencyAlignmentUpdateInfo[] agencyAlignmentUpdates = updateRequest.getEventAgencyAlignmentUpdates();
      if (!ArrayUtils.isEmpty(agencyAlignmentUpdates)) {
         for (EventAgencyAlignmentUpdateInfo alignmentUpdateInfo : agencyAlignmentUpdates) {
            EventAgencyAlignmentResponse eventAgencyAlignmentResponse = new EventAgencyAlignmentResponse();
            eventAgencyAlignmentResponse.setEventAgencyAlignmentPubkey(alignmentUpdateInfo.getEventAgencyAlignmentPubkey());
            try {
               EventAgencyAlignment eventAgencyAlignment = eventAgencyAlignmentValidator.validateAlignmentExists(alignmentUpdateInfo.getEventAgencyAlignmentPubkey());
               eventAgencyAlignmentRequestParser.copyProperties(eventAgencyAlignment, alignmentUpdateInfo);
               if (!updateRequest.isValidateOnly()) {
                  eventAgencyAlignmentDao.update(eventAgencyAlignment);
               }
               eventAgencyAlignmentResponse.setSuccess(true);
            }
            catch (WrappingException e) {
               eventAgencyAlignmentResponse.setMessage(e.getMessage());
            }
            responseList.add(eventAgencyAlignmentResponse);
         }
      }
      return responseList.toArray(new EventAgencyAlignmentResponse[responseList.size()]);
   }
}
