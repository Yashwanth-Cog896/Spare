package com.monsanto.tps.lexicon.regulatory.chemicalname.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ChemicalName;
import org.hibernate.transform.ResultTransformer;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 7/18/12
 * Time: 9:01 PM
 */
public class ChemicalNameTransformer implements ResultTransformer {
    @Override
    public Object transformTuple(Object[] tuple, String[] aliases) {

        return new ChemicalName((Long)(tuple[0]), (String)tuple[2], "Y".equals(tuple[4]), null, null, null, null,
                (String)tuple[5], (String)tuple[6], (String)tuple[7], (String)tuple[3], (String)tuple[1]);
    }

    @Override
    public List transformList(List collection) {
        return collection;
    }
}
