package com.monsanto.tps.lexicon.regulatory.monnumber.service;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.lexiconcommon.exception.RuntimeWrappingException;
import com.monsanto.tps.lexicon.event.Construct;
import com.monsanto.tps.lexicon.monnumber.MonNumberSaveRequest;
import com.monsanto.tps.lexicon.monnumber.MonNumberSaveResponse;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Crop;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumberConstruct;
import com.monsanto.tps.lexicon.regulatory.crop.dao.CropDao;
import com.monsanto.tps.lexicon.regulatory.event.model.EventConstruct;
import com.monsanto.tps.lexicon.regulatory.event.model.RegulatoryEventRequest;
import com.monsanto.tps.lexicon.regulatory.event.queryset.RegulatoryEventRequestProcessor;
import com.monsanto.tps.lexicon.regulatory.event.queryset.RegulatoryEventResponse;
import org.apache.commons.lang.ArrayUtils;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Arrays;
public class EventConstructProcessor
{
   private RegulatoryEventRequestProcessor eventRequestProcessor;
   private CropDao cropDao;

   public MonNumberSaveResponse processSaveEvent(MonNumberSaveResponse response,
                                                 BindException errors,
                                                 String objectName,
                                                 MonNumberSaveRequest monNumberSaveRequest)
   {
      if (hasEventAndCrop(monNumberSaveRequest)) {
         processEvent(response, errors, objectName, monNumberSaveRequest);
      }
      return response;
   }

   public MonNumberSaveResponse processUpdateEvent(MonNumberSaveResponse response,
                                                   BindException errors,
                                                   String objectName,
                                                   MonNumber monNumber, MonNumberSaveRequest monNumberSaveRequest)
   {
      if (!eventRemoved(monNumber, monNumberSaveRequest) && eventInfoChanged(monNumber, monNumberSaveRequest)) {
         processEvent(response, errors, objectName, monNumberSaveRequest);
      }
      return response;
   }

   private void processEvent(MonNumberSaveResponse response, BindException errors, String objectName, MonNumberSaveRequest monNumberSaveRequest) {
      SelectConstruct selectConstruct = new SelectConstruct(lookupEventConstruct(monNumberSaveRequest));
      if (selectConstruct.hasEventConstructs()) {
         EventConstruct[] eventConstructs = selectConstruct.getEventConstructs(errors, objectName, monNumberSaveRequest.getConstruct());
         response.setEventConstructs(buildConstructsFromEventConstructs(eventConstructs));
         response.setTransformationBackground(eventConstructs[0].getTransformationBackground());
      }
      else {
         errors.addError(new FieldError(objectName, "event", "Invalid Event for Selected Crop."));
      }
   }

   public boolean hasEventAndCrop(MonNumberSaveRequest monNumberSaveRequest) {
      return StringUtils.hasText(monNumberSaveRequest.getEvent()) && StringUtils.hasText(monNumberSaveRequest.getCropPubkey());
   }

   private EventConstruct[] lookupEventConstruct(MonNumberSaveRequest monNumberSaveRequest) {

      try {
          List<RegulatoryEventResponse> responses = eventRequestProcessor.getRegulatoryEvents(
          Arrays.asList(buildRegulatoryEventRequest(monNumberSaveRequest)));
          if(!responses.isEmpty()){
             List<EventConstruct> eventConstructs=responses.get(0).getEventConstructs();
             return eventConstructs.toArray(new EventConstruct[eventConstructs.size()]);
          }
      }
      catch (WrappingException e) {
         throw new RuntimeWrappingException(e);
      }
      catch (IOException e) {
         throw new RuntimeWrappingException(e);
      }
      return null;
   }

   private RegulatoryEventRequest buildRegulatoryEventRequest(MonNumberSaveRequest monNumberSaveRequest) {
      return new RegulatoryEventRequest(monNumberSaveRequest.getEvent(),
         getCropByCropPubkey(monNumberSaveRequest.getCropPubkey()).getCropName());
   }


   private Crop getCropByCropPubkey(String cropPubkey) {
      return cropDao.findByPubkey(cropPubkey);
   }

   public void setEventRequestProcessor(RegulatoryEventRequestProcessor eventRequestProcessor) {
      this.eventRequestProcessor = eventRequestProcessor;
   }

   public void setCropDao(CropDao cropDao) {
      this.cropDao = cropDao;
   }

   private Construct[] buildConstructsFromEventConstructs(EventConstruct[] eventConstructs) {
      List<Construct> constructList = new ArrayList<Construct>();
      for (EventConstruct eventConstruct : eventConstructs) {
         Construct construct = new Construct();
         construct.setPlasmidPMon(eventConstruct.getConstruct());
         construct.setPlasmidPVCode(StringUtils.arrayToCommaDelimitedString(eventConstruct.getTransCodes()));
         constructList.add(construct);
      }
      return constructList.toArray(new Construct[constructList.size()]);
   }

   public boolean eventInfoChanged(MonNumber monNumber, MonNumberSaveRequest monNumberSaveRequest) {
      if (hasEventAndCrop(monNumberSaveRequest)) {
         if (!monNumberSaveRequest.getEvent().toUpperCase().equals(monNumber.getEvent().toUpperCase())
            ||
            !monNumberSaveRequest.getCropPubkey().equals(monNumber.getCrop().getCropPubkey())) {
            return true;
         }
      }
      return false;
   }

   public boolean eventRemoved(MonNumber monNumber, MonNumberSaveRequest monNumberSaveRequest) {
      if (StringUtils.hasText(monNumber.getEvent()) && !StringUtils.hasText(monNumberSaveRequest.getEvent())) {
         return true;
      }
      return false;
   }

   public void addMonNumberConstructs(MonNumber monNumber, MonNumberSaveRequest monNumberSaveRequest,
                                      Construct[] newConstructs, Collection<MonNumberConstruct> monNumberConstructs)
   {
      Collection<MonNumberConstruct> existingConstructs = new HashSet<MonNumberConstruct>();
      existingConstructs.addAll(monNumber.getMonNumberConstructs());
      monNumber.getMonNumberConstructs().clear();
      if (eventInfoChanged(monNumber, monNumberSaveRequest) && !ArrayUtils.isEmpty(newConstructs)) {
         monNumber.getMonNumberConstructs().addAll(monNumberConstructs);
      }
      else {
         if (!eventRemoved(monNumber, monNumberSaveRequest)) {
            monNumber.getMonNumberConstructs().addAll(existingConstructs);
         }
      }
   }
}