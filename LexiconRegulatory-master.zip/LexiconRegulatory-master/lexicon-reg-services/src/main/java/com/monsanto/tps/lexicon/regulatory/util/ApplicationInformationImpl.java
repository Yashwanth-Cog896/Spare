package com.monsanto.tps.lexicon.regulatory.util;

import com.monsanto.tps.aop.metric.ApplicationInformation;

/**
 * rrchak1 - Oct 22, 2008 4:05:28 PM
 */
public class ApplicationInformationImpl
   implements ApplicationInformation
{
   public String getName() {
      return "Lexicon";
   }

   public String getVersion() {
      return POSVersion.VERSION_SHORT_TEXT;
   }
}
