package com.monsanto.tps.lexicon.regulatory.nonmonevent.validation;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;

/**
 * nbwald - May 21, 2009 5:45:18 PM
 */
public class AuditRequestorExistsRule
   implements Rule<String>
{
   private final String auditRequestor;

   public AuditRequestorExistsRule(String auditRequestor) {
      this.auditRequestor = auditRequestor;
   }

   @Override
   public boolean violated() {
      return StringUtils.isNullOrEmpty(auditRequestor);
   }

   @Override
   public String getViolation() {
      return "Audit requestor is required.";
   }
}