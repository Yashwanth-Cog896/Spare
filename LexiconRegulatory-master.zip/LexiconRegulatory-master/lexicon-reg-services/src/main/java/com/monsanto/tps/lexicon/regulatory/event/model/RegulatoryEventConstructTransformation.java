package com.monsanto.tps.lexicon.regulatory.event.model;

/**
 * User: pjberry
 * Date: Jul 25, 2007
 * Time: 11:27:58 AM
 */
public interface RegulatoryEventConstructTransformation
{
   String getEvent();

   String getConstruct();

   String getTransformationBackground();
}
