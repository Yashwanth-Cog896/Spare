package com.monsanto.tps.lexicon.regulatory.sample.business;

import com.monsanto.tps.lexicon.sample.OrionSample;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.SampleType;
import com.monsanto.tps.lexicon.regulatory.sample.dao.SampleDAO;
import com.monsanto.tps.lexicon.regulatory.util.WildcardUtil;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 3/1/12
 * Time: 2:14 PM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class SampleBusiness {

    @Resource
    private SampleDAO sampleDAO;

    public List<OrionSample> findSampleTypes(final String sampleType) {
        final List<SampleType> sampleTypeList = sampleDAO.findSampleTypes(WildcardUtil.replaceAsteriskWildcardWithPercent(sampleType));
        final List<OrionSample> orionSampleList = new ArrayList<OrionSample>();

        for (SampleType type : sampleTypeList) {
            orionSampleList.add(new OrionSample(type.getSampleType(), type.getContainerType(), type.getStorageCondition(),
                    type.getSampleTypeDescription(), type.getActiveStatus()));
        }

        return orionSampleList;
    }
}

