package com.monsanto.tps.lexicon.regulatory.monnumber.service;

import com.monsanto.tps.lexicon.event.Construct;
import com.monsanto.tps.lexicon.monnumber.MonNumberSaveRequest;
import com.monsanto.tps.lexicon.monnumber.MonNumberSaveResponse;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Crop;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumberConstruct;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName;
import com.monsanto.tps.lexicon.regulatory.commercialtrait.dao.CommercialTraitDao;
import com.monsanto.tps.lexicon.regulatory.crop.dao.CropDao;
import com.monsanto.tps.lexicon.regulatory.helpers.AuditStage;
import com.monsanto.tps.lexicon.regulatory.monnumber.dao.MonNumberDao;
import org.apache.commons.lang.ArrayUtils;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.validation.Validator;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;

/**
 * rrchak1 - May 22, 2009 2:39:06 PM
 */
public class MonNumberPersistProcessor
{
   private Validator monNumberSaveRequestValidator;
   private CommercialTraitDao commercialTraitDao;
   private MonNumberDao monNumberDao;
   String saveRequest = "MonNumberSaveRequest";
   private Validator monNumberUpdateRequestValidator;
   private CropDao cropDao;
   private EventConstructProcessor eventConstructProcessor;

   @AuditStage(processName = "CREATE MONNUMBER")
   public MonNumberSaveResponse processSave(boolean validateOnly, MonNumberSaveRequest monNumberSaveRequest) {
      MonNumberSaveResponse response = new MonNumberSaveResponse();
      BindException errors = new BindException(monNumberSaveRequest, saveRequest);
      monNumberSaveRequestValidator.validate(monNumberSaveRequest, errors);
      response = eventConstructProcessor.processSaveEvent(response, errors, saveRequest, monNumberSaveRequest);
      response.setMessages(getErrorMessages(errors));
      if (!errors.hasFieldErrors()) {
         response.setSuccess(true);
         if (!validateOnly) {
            MonNumber
               monNumber = monNumberDao.save(buildMonNumber(monNumberSaveRequest, response.getTransformationBackground()));
            if (!ArrayUtils.isEmpty(response.getEventConstructs())) {
               monNumber.getMonNumberConstructs().addAll(saveMonNumberConstructs(response.getEventConstructs(), monNumber));
            }
            monNumber.getProteinNames().addAll(saveProteins(monNumberSaveRequest.getProteinNamePubkeys()));
            monNumber.getComlTraitNames().addAll(saveComlTraitNames(monNumberSaveRequest.getTraitNameAbbreviations()));
            monNumber.getComlTraitTypes().addAll(saveComlTraitTypes(monNumberSaveRequest.getTraitTypeAbbreviations()));
         }
      }
      return response;
   }

   private MonNumber buildMonNumber(MonNumberSaveRequest monNumberSaveRequest, String transformationBackground) {
      return new MonNumber(monNumberSaveRequest.isActiveStatus(),
         getCropByCropPubkey(monNumberSaveRequest.getCropPubkey()),
         monNumberSaveRequest.getEvent(),
         monNumberSaveRequest.getJvNumber(),
         monNumberSaveRequest.isLocked(),
         monNumberSaveRequest.getMaterialName(),
         monNumberSaveRequest.getMonNumber(),
         monNumberSaveRequest.getOecdNumber(),
         monNumberSaveRequest.getOecdNumberCommunicationDate() != null
            ? new Timestamp(monNumberSaveRequest.getOecdNumberCommunicationDate().getTime())
            : null,
         monNumberSaveRequest.isRegulatedStatus(),
         monNumberSaveRequest.getRegulatoryGenesPresent(),
         transformationBackground,
         monNumberSaveRequest.getRegulatoryParentalLine());
   }

   @AuditStage(processName = "UPDATE MONNUMBER")
   public MonNumberSaveResponse processUpdate(boolean validateOnly, MonNumberSaveRequest monNumberSaveRequest) {
      MonNumberSaveResponse response = new MonNumberSaveResponse();
      BindException errors = new BindException(monNumberSaveRequest, saveRequest);
      monNumberUpdateRequestValidator.validate(monNumberSaveRequest, errors);
      MonNumber monNumber = null;
      if (!errors.hasFieldErrors("monNumber")) {
         monNumber = monNumberDao.find(monNumberSaveRequest.getMonNumber());
         response = eventConstructProcessor.processUpdateEvent(response, errors, saveRequest, monNumber, monNumberSaveRequest);
      }
      if (!errors.hasFieldErrors()) {
         response.setSuccess(true);
         if (!validateOnly) {
            monNumber = updateMonNumber(monNumber, monNumberSaveRequest, response.getTransformationBackground());
            eventConstructProcessor.addMonNumberConstructs(monNumber,
               monNumberSaveRequest,
               response.getEventConstructs(),
               saveMonNumberConstructs(response.getEventConstructs(), monNumber)
            );
            updateCollection(monNumber.getProteinNames(), saveProteins(monNumberSaveRequest.getProteinNamePubkeys()));
            updateCollection(monNumber.getComlTraitTypes(), saveComlTraitTypes(monNumberSaveRequest.getTraitTypeAbbreviations()));
            updateCollection(monNumber.getComlTraitNames(), saveComlTraitNames(monNumberSaveRequest.getTraitNameAbbreviations()));
            //no need to call update, transaction commit will flush
         }
      }
      response.setMessages(getErrorMessages(errors));
      return response;
   }

   private <T> void updateCollection(Collection<T> oldCollection, Collection<T> newCollection) {
      oldCollection.clear();
      oldCollection.addAll(newCollection);
   }

   private MonNumber updateMonNumber(MonNumber monNumber, MonNumberSaveRequest monNumberSaveRequest, String transformationBackground) {
      monNumber.setActiveStatus(monNumberSaveRequest.isActiveStatus());
      monNumber.setJvNumber(monNumberSaveRequest.getJvNumber());
      monNumber.setLocked(monNumberSaveRequest.isLocked());
      monNumber.setMaterialName(monNumberSaveRequest.getMaterialName());
      monNumber.setOecdNumber(monNumberSaveRequest.getOecdNumber());
      monNumber.setOecdNumberCommunicationDate(monNumberSaveRequest.getOecdNumberCommunicationDate() != null
         ? new Timestamp(monNumberSaveRequest.getOecdNumberCommunicationDate().getTime())
         : null);
      //monNumber.setPreviousNames(monNumberSaveRequest.getPreviousNames());
      monNumber.setCrop(getCropByCropPubkey(monNumberSaveRequest.getCropPubkey()));
      monNumber.setRegulatedStatus(monNumberSaveRequest.isRegulatedStatus());
      monNumber.setRegulatoryGenesPresent(monNumberSaveRequest.getRegulatoryGenesPresent());
      monNumber.setTransformationBackground(transformationBackground != null ? transformationBackground : monNumber.getTransformationBackground());
      monNumber.setRegulatoryParentalLine(monNumberSaveRequest.getRegulatoryParentalLine());
      return monNumber;
   }

   private Collection<MonNumberConstruct> saveMonNumberConstructs(Construct[] eventConstructs, MonNumber monNumber) {
      Collection<MonNumberConstruct> monNumberConstructs = buildMonNumberConstructs(eventConstructs, monNumber);
      for (MonNumberConstruct monNumberConstruct : monNumberConstructs) {
         monNumberDao.saveMonNumberConstruct(monNumberConstruct);
      }
      return monNumberConstructs;
   }

   private Collection<ComlTraitType> saveComlTraitTypes(String[] traitTypeAbbreviations) {
      Collection<ComlTraitType> comlTraitTypes = new HashSet<ComlTraitType>();
      if (!ArrayUtils.isEmpty(traitTypeAbbreviations)) {
         for (String traitTypeAbbreviation : traitTypeAbbreviations) {
            comlTraitTypes.add(commercialTraitDao.findCommercialTraitTypeByAbbr(traitTypeAbbreviation));
         }
      }
      return comlTraitTypes;
   }

   private Collection<ComlTraitName> saveComlTraitNames(String[] traitNameAbbreviations) {
      Collection<ComlTraitName> comlTraitNames = new HashSet<ComlTraitName>();
      if (!ArrayUtils.isEmpty(traitNameAbbreviations)) {
         for (String traitNameAbbreviation : traitNameAbbreviations) {
            comlTraitNames.add(commercialTraitDao.findCommercialTraitByAbbr(traitNameAbbreviation));
         }
      }
      return comlTraitNames;
   }

   private Collection<ProteinName> saveProteins(String[] proteinNamePubkeys) {
      Collection<ProteinName> proteinNames = new HashSet<ProteinName>();
      if (!ArrayUtils.isEmpty(proteinNamePubkeys)) {
         for (String proteinPubkey : proteinNamePubkeys) {
            proteinNames.add(monNumberDao.findProteinNameByPubkey(proteinPubkey));
         }
      }
      return proteinNames;
   }

   private Collection<MonNumberConstruct> buildMonNumberConstructs(Construct[] constructs,
                                                                   MonNumber monNumber)
   {
      Collection<MonNumberConstruct> monNumberConstructList = new HashSet<MonNumberConstruct>();
      if (!ArrayUtils.isEmpty(constructs)) {
         Construct construct = constructs[0];
         String[] transCodes = StringUtils.commaDelimitedListToStringArray(construct.getPlasmidPVCode());

         if (ArrayUtils.isEmpty(transCodes)) {
            MonNumberConstruct monNumberConstruct = buildMonNumberConstruct(monNumber, null, construct.getPlasmidPMon());
            monNumberConstructList.add(monNumberConstruct);
         }
         else {
            if (transCodes.length > 1) {
               for (String transCode : transCodes) {
                  MonNumberConstruct monNumberConstruct = buildMonNumberConstruct(monNumber, transCode, construct.getPlasmidPMon());
                  monNumberConstructList.add(monNumberConstruct);
               }
            }
            else {
               MonNumberConstruct monNumberConstruct = buildMonNumberConstruct(monNumber, transCodes[0], construct.getPlasmidPMon());
               monNumberConstructList.add(monNumberConstruct);
            }
         }
      }
      return monNumberConstructList;
   }

   private MonNumberConstruct buildMonNumberConstruct(MonNumber monNumber, String transCode, String construct) {
      MonNumberConstruct monNumberConstruct = new MonNumberConstruct();
      monNumberConstruct.setConstructName(construct);
      monNumberConstruct.setPvCode(transCode);
      monNumberConstruct.setMonNumber(monNumber);
      return monNumberConstruct;
   }


   private String[] getErrorMessages(BindException errors) {
      List<FieldError> fieldErrors = errors.getFieldErrors();
      List<String> messages = new ArrayList<String>();
      for (FieldError fieldError : fieldErrors) {
         messages.add(fieldError.getDefaultMessage());
      }
      return messages.toArray(new String[messages.size()]);
   }

   public void setMonNumberUpdateRequestValidator(Validator monNumberUpdateRequestValidator) {
      this.monNumberUpdateRequestValidator = monNumberUpdateRequestValidator;
   }

   public void setCropDao(CropDao cropDao) {
      this.cropDao = cropDao;
   }

   public void setCommercialTraitDao(CommercialTraitDao commercialTraitDao) {
      this.commercialTraitDao = commercialTraitDao;
   }

   public void setMonNumberDao(MonNumberDao monNumberDao) {
      this.monNumberDao = monNumberDao;
   }

   public void setMonNumberSaveRequestValidator(Validator monNumberSaveRequestValidator) {
      this.monNumberSaveRequestValidator = monNumberSaveRequestValidator;
   }

   private Crop getCropByCropPubkey(String cropPubkey) {
      return cropDao.findByPubkey(cropPubkey);
   }

   public void setEventConstructProcessor(EventConstructProcessor eventConstructProcessor) {
      this.eventConstructProcessor = eventConstructProcessor;
   }
}
