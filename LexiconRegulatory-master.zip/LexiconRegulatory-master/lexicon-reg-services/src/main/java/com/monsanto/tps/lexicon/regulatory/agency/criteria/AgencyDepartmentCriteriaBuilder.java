package com.monsanto.tps.lexicon.regulatory.agency.criteria;

import com.monsanto.tps.lexicon.agency.AgencySearchCriteria;
import org.hibernate.Criteria;

import java.util.ArrayList;
import java.util.List;

/**
 * rrchak1 - Oct 15, 2008 3:49:01 PM
 */
public class AgencyDepartmentCriteriaBuilder
{
   public void addCriteria(Criteria agencyDepartmentCriteria, AgencySearchCriteria agencySearchCriteria) {
      List<QueryCriteria> criteria = getCriteriaList(agencySearchCriteria);
      for (QueryCriteria queryCriteria : criteria) {
         if (queryCriteria.hasCriteria()) {
            agencyDepartmentCriteria.add(queryCriteria.getCriterion());
         }
      }

   }

   private List<QueryCriteria> getCriteriaList(AgencySearchCriteria agencySearchCriteria) {
      List<QueryCriteria> criteriaList = new ArrayList<QueryCriteria>();
      criteriaList.add(new AgencyDepartmentStatusCriteriaImpl(agencySearchCriteria.isIncludeInactive()));
      return criteriaList;
   }

   public void addIdCriteria(Criteria agencyDepartmentCriteria, long[] ids) {
      QueryCriteria criteria = new AgencyDepartmentIdCriteriaImpl(ids);
      if (criteria.hasCriteria()) {
         agencyDepartmentCriteria.add(criteria.getCriterion());
      }
   }
}
