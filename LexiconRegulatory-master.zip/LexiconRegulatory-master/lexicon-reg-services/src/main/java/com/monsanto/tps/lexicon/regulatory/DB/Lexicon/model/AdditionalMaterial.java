package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model;

public class AdditionalMaterial {

    private long additionalMaterialInfoId;

    private String materialName;
    private String alias;
    private String chemicalNameCAS;
    private String chemicalNameIUPAC;
    private String cpNumber;
    private boolean activeStatus;
    private MaterialStructureInfo structureInfo;
    public AdditionalMaterial() {
    }

    public AdditionalMaterial(String materialName, String alias, String chemicalNameCAS, String chemicalNameIUPAC, String cpNumber, boolean activeStatus) {
        this.materialName = materialName;
        this.alias = alias;
        this.chemicalNameCAS = chemicalNameCAS;
        this.chemicalNameIUPAC = chemicalNameIUPAC;
        this.cpNumber = cpNumber;
        this.activeStatus = activeStatus;
    }

    public long getAdditionalMaterialInfoId() {
        return additionalMaterialInfoId;
    }

    public void setAdditionalMaterialInfoId(long additionalMaterialInfoId) {
        this.additionalMaterialInfoId = additionalMaterialInfoId;
    }

    public AdditionalMaterial(String materialName, String alias, String chemicalNameCAS, String chemicalNameIUPAC, String cpNumber,
                              boolean activeStatus, MaterialStructureInfo structureInfo) {
        this.materialName = materialName;
        this.alias = alias;
        this.chemicalNameCAS = chemicalNameCAS;
        this.chemicalNameIUPAC = chemicalNameIUPAC;
        this.cpNumber = cpNumber;
        this.activeStatus = activeStatus;
        this.structureInfo = structureInfo;
    }

    public String getMaterialName() {
        return materialName;
    }

    public void setMaterialName(String materialName) {
        this.materialName = materialName;
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public String getChemicalNameCAS() {
        return chemicalNameCAS;
    }

    public void setChemicalNameCAS(String chemicalNameCAS) {
        this.chemicalNameCAS = chemicalNameCAS;
    }

    public String getChemicalNameIUPAC() {
        return chemicalNameIUPAC;
    }

    public void setChemicalNameIUPAC(String chemicalNameIUPAC) {
        this.chemicalNameIUPAC = chemicalNameIUPAC;
    }

    public String getCpNumber() {
        return cpNumber;
    }

    public void setCpNumber(String cpNumber) {
        this.cpNumber = cpNumber;
    }

    public boolean getActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(boolean activeStatus) {
        this.activeStatus = activeStatus;
    }

    public MaterialStructureInfo getStructureInfo() {
        return structureInfo;
    }

    public void setStructureInfo(MaterialStructureInfo structureInfo) {
        this.structureInfo = structureInfo;
    }
}
