/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.DB.geneticentity.model;

import java.io.Serializable;

/* vvkalu - 7/25/11 */
public class EventConstructTraitStackEntity implements Serializable {
    private long comlTraitStackId;
    private long eventConstructId;
    private long id;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getEventConstructId() {
        return eventConstructId;
    }

    public void setEventConstructId(long eventConstructId) {
        this.eventConstructId = eventConstructId;
    }

    public long getComlTraitStackId() {
        return comlTraitStackId;
    }

    public void setComlTraitStackId(long comlTraitStackId) {
        this.comlTraitStackId = comlTraitStackId;
    }
}