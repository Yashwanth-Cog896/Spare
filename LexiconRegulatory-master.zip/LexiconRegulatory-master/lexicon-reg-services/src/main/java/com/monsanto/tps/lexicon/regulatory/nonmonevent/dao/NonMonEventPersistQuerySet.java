package com.monsanto.tps.lexicon.regulatory.nonmonevent.dao;

import com.monsanto.tcc.lexiconcommon.ArrayUtils;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Crop;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName;
import com.monsanto.tps.lexicon.regulatory.crop.dao.CropDao;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.delegate.ConstructsByEventAndCropQuery;

import java.util.Arrays;
import java.util.Collection;

/**
 * nbwald - May 21, 2009 7:32:13 PM
 */
public class NonMonEventPersistQuerySet
{
   private final CropDao cropDao;
   private final ProteinNameDao proteinNameDao;
   private final ComlTraitNameDao comlTraitNameDao;
   private final ComlTraitTypeDao comlTraitTypeDao;
   private final NonMonEventDao nonMonEventDao;

   public NonMonEventPersistQuerySet(CropDao cropDao, ProteinNameDao proteinNameDao, ComlTraitNameDao comlTraitNameDao, ComlTraitTypeDao comlTraitTypeDao, NonMonEventDao nonMonEventDao) {
      this.cropDao = cropDao;
      this.proteinNameDao = proteinNameDao;
      this.comlTraitNameDao = comlTraitNameDao;
      this.comlTraitTypeDao = comlTraitTypeDao;
      this.nonMonEventDao = nonMonEventDao;
   }

   public String[] findConstructsByEventAndCrop(String eventName, String cropName) {
      return new ConstructsByEventAndCropQuery(eventName, cropName).find();
   }

   public Crop findCropByPubkey(String cropPubkey) {
      return cropDao.findByPubkey(cropPubkey);
   }

   public Collection<ProteinName> findProteinNamesByPubkeys(String[] proteinNamePubkeys) {
      return proteinNameDao.findByPubkeys(proteinNamePubkeys);
   }

   public Collection<ComlTraitName> findRegulatoryTraitNamesByAbbrs(String[] traitNameAbbrevations) {
      return comlTraitNameDao.findByAbbrs(traitNameAbbrevations);
   }

   public Collection<ComlTraitType> findRegulatoryTraitTypesByAbbrs(String[] traitTypeAbbrevations) {
      return comlTraitTypeDao.findByAbbrs(traitTypeAbbrevations);
   }

   public NonMonEvent findNonMonEventByEventAndCrop(String eventName, String cropPubkey) {
      // nstub TODO this dao method should only return a single non-mon event
      NonMonEvent[] nonMonEvents = nonMonEventDao.findByNonMonEventAndCrop(eventName, cropPubkey);
      return ArrayUtils.isNullOrEmpty(nonMonEvents) ? null : Arrays.asList(nonMonEvents).get(0);
   }
}
