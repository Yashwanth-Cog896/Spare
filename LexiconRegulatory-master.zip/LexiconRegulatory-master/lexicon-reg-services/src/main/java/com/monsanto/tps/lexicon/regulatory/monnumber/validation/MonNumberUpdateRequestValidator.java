package com.monsanto.tps.lexicon.regulatory.monnumber.validation;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber;
import org.springframework.validation.Errors;

/**
 * rrchak1 - May 11, 2009 10:42:48 AM
 */
public class MonNumberUpdateRequestValidator
   extends MonNumberSaveRequestValidator
{
   @Override
   public void validate(Object target, Errors errors) {
      super.validate(target, errors);
   }

   @Override
   protected void validateMonNumberExists(String monNumber, Errors errors) {
      if (null == monNumberDao.find(monNumber)) {
         errors.rejectValue("monNumber", "monNumber.doesnot.exist", "Mon Number does not exist.");
      }
   }

   @Override
   protected void validateEventExists(String event, String monNumber, Errors errors) {
      MonNumber monNumberObj = monNumberDao.findByEvent(event);
      if (null != monNumberObj) {
         if (!monNumber.equalsIgnoreCase(monNumberObj.getMonNumber())) {
            errors.rejectValue("event", "event.exists", "Duplicate Event; " + event + " is already defined.");
         }
      }
   }

   @Override
   protected void validateOecdNumberExists(String oecdNumber, String monNumber, Errors errors) {
      MonNumber monNumberObj = monNumberDao.findByOecdNumber(oecdNumber);
      if (null != monNumberObj) {
         if (!monNumber.equalsIgnoreCase(monNumberObj.getMonNumber())) {
            errors.rejectValue("oecdNumber", "oecdNumber.exists", "OECD Number is already defined.");
         }
      }
   }
}
