package com.monsanto.tps.lexicon.regulatory.storagecondition.business;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.StorageCondition;
import com.monsanto.tps.lexicon.regulatory.storagecondition.dao.StorageConditionDAO;
import com.monsanto.tps.lexicon.regulatory.util.WildcardUtil;
import com.monsanto.tps.lexicon.storagecondition.OrionStorageCondition;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 3/1/12
 * Time: 2:14 PM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class StorageConditionBusiness {

    @Resource
    private StorageConditionDAO storageConditionDAO;

    public List<OrionStorageCondition> findStorageConditions(final String storageConditionType) {
        final List<StorageCondition> storageConditionTypeList = storageConditionDAO.findStorageConditions(WildcardUtil.replaceAsteriskWildcardWithPercent(storageConditionType));
        final List<OrionStorageCondition> orionStorageConditionList = new ArrayList<OrionStorageCondition>();

        for (StorageCondition type : storageConditionTypeList) {
            orionStorageConditionList.add(new OrionStorageCondition(type.getStorageCondition(), type.getActiveStatus()));
        }

        return orionStorageConditionList;
    }


}

