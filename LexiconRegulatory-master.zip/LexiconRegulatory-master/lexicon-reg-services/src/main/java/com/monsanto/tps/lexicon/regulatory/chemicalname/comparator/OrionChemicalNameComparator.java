package com.monsanto.tps.lexicon.regulatory.chemicalname.comparator;

import com.monsanto.tps.lexicon.chemicalname.OrionChemicalName;

import java.lang.String;import java.util.Comparator;

/**
 * Created by IntelliJ IDEA.
 * User: etherma
 * Date: Apr 27, 2006
 * Time: 2:41:53 PM
 * To change this template use File | Settings | File Templates.
 */
public class OrionChemicalNameComparator implements Comparator<OrionChemicalName> {

    public final int compare(OrionChemicalName cn1, OrionChemicalName cn2) {

        int nameCompare = 0;

        if (cn1 != null && cn2 != null) {
            String name1 = cn1.getMaterialName();
            String name2 = cn2.getMaterialName();
            if (name1 != null && name2 != null) {
                nameCompare = name1.compareToIgnoreCase(name2);
            }
        }
        return nameCompare;
    }

}
