package com.monsanto.tps.lexicon.regulatory.storagelocation.service;

import com.monsanto.tps.lexicon.regulatory.storagelocation.business.StorageLocationBusiness;
import com.monsanto.tps.lexicon.storagelocation.OrionStorageLocation;
import com.monsanto.tps.lexicon.storagelocation.StorageLocationService;

import javax.jws.WebParam;
import javax.jws.WebService;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: MMR
 * Date: 2/16/12
 * Time: 3:24 PM
 */

@WebService(endpointInterface = "com.monsanto.tps.lexicon.storagelocation.StorageLocationService")
public class StorageLocationServiceImpl implements StorageLocationService {
    private StorageLocationBusiness storageLocationBusiness;

    @Override
    public List<OrionStorageLocation> findStorageLocations(@WebParam(name = "storageLocation") String storageLocation) {
        return storageLocationBusiness.findStorageLocations(storageLocation);
    }

    @Override
    public List<OrionStorageLocation> findStorageLocationsByList(@WebParam(name = "storageLocations") List<String> storageLocations) {
        return storageLocationBusiness.findStorageLocationsByList(storageLocations);
    }

    @Override
    public List<OrionStorageLocation> findStorageLocationsByPhysicalLocation(@WebParam(name = "physicalLocation") String physicalLocation) {
        return storageLocationBusiness.findStorageLocationsByPhysicalLocation(physicalLocation);
    }

    public void setStorageLocationBusiness(StorageLocationBusiness storageLocationBusiness) {
        this.storageLocationBusiness = storageLocationBusiness;
    }
}
