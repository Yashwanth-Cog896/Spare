package com.monsanto.tps.lexicon.regulatory.event.strategy;

import com.monsanto.tps.lexicon.event.EventInfo;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;
import com.monsanto.tps.lexicon.regulatory.event.queryset.EventSearchServiceQuerySet;

import java.util.List;

/**
 * rrchak1 - Feb 11, 2009 3:15:18 PM
 */
public class EventInfoByAlignmentPubkeyStrategyImpl
   implements EventInfoByAlignmentPubkeyStrategy
{
   private EventSearchServiceQuerySet querySet;

   public EventInfoByAlignmentPubkeyStrategyImpl(EventSearchServiceQuerySet querySet) {
      this.querySet = querySet;
   }

   @Override
   public EventInfo[] find(String[] eventAgencyAlignmentPubkey) {
      EventAgencyAlignment[] eventAgencyAlignments = querySet.findEventAgencyAlignmentByPubkey(eventAgencyAlignmentPubkey);
      List<EventInfo> eventInfoList = new EventInfoByAgencyAbbrStrategyImpl(querySet).getEventInfos(eventAgencyAlignments);
      return eventInfoList.toArray(new EventInfo[eventInfoList.size()]);
   }
}
