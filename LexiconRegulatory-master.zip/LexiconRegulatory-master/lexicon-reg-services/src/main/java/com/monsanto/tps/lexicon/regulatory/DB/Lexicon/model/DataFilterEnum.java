package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model;

/**
 * rrchak1 - May 14, 2009 11:21:17 AM
 */
public enum DataFilterEnum
{
   REGULATORY("REGULATORY");
   private String value;

   DataFilterEnum(String value) {
      this.value = value;
   }

   public String getValue() {
      return value;
   }
}
