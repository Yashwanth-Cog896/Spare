package com.monsanto.tps.lexicon.regulatory.additionalmaterialinfo.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.AdditionalMaterial;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: GSUGA
 * Date: 14/05/12
 * Time: 12:30
 * To change this template use File | Settings | File Templates.
 */
public interface AdditionalMaterialDAO {
    public List<AdditionalMaterial> findAdditionalMaterials(String materialName);
}
