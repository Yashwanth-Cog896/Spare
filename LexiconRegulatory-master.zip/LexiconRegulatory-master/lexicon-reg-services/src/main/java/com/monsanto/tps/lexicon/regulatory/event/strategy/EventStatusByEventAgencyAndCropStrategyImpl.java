package com.monsanto.tps.lexicon.regulatory.event.strategy;

import com.monsanto.tps.lexicon.event.EventDeregulationStatus;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;
import com.monsanto.tps.lexicon.regulatory.event.dao.EventAgencyAlignmentDao;
import com.monsanto.tps.lexicon.regulatory.event.delegate.EventSplitter;
import com.monsanto.tps.lexicon.regulatory.event.delegate.EventStatusBuilder;

import java.util.ArrayList;
import java.util.List;

/**
 * rrchak1 - Jun 23, 2009 11:23:09 AM
 */
public class EventStatusByEventAgencyAndCropStrategyImpl
   implements EventStatusByEventAgencyAndCropStrategy
{
   private final EventAgencyAlignmentDao eventAgencyAlignmentDao;
   private final EventStatusBuilder eventStatusBuilder;
   private final EventSplitter eventSplitter;

   public EventStatusByEventAgencyAndCropStrategyImpl(EventAgencyAlignmentDao eventAgencyAlignmentDao, EventStatusBuilder eventStatusBuilder, EventSplitter eventSplitter) {
      this.eventAgencyAlignmentDao = eventAgencyAlignmentDao;
      this.eventStatusBuilder = eventStatusBuilder;
      this.eventSplitter = eventSplitter;
   }

   @Override
   public EventDeregulationStatus[] find(String[] events, String cropName, String[] agencyAbbrs) {
      List<String[]> eventList = eventSplitter.splitEvents(events);
      List<EventDeregulationStatus> eventDeregulationStatusList = new ArrayList<EventDeregulationStatus>();
      for (String[] eventItems : eventList) {
         EventAgencyAlignment[] eventAgencyAlignments =
            eventAgencyAlignmentDao.findByEventsCropAndAgencyAbbrs(eventItems, cropName, agencyAbbrs);
         eventDeregulationStatusList.addAll(eventStatusBuilder.build(eventAgencyAlignments, cropName));
      }
      return eventDeregulationStatusList.toArray(new EventDeregulationStatus[eventDeregulationStatusList.size()]);
   }
}
