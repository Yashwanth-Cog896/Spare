/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.eventtraitservice.dao;

import java.math.BigDecimal;
import java.util.List;

/* vvkalu - 7/29/11 */
public interface EventConstructTraitStackDao {

    List<BigDecimal> getComTraitStackIdByEventConstructs(long germplasmId);
}