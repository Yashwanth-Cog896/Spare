package com.monsanto.tps.lexicon.regulatory.nonmonevent.delegate;

import com.monsanto.tps.lexicon.nonmonevent.NonMonEventPersistRequest;
import com.monsanto.tps.lexicon.nonmonevent.NonMonEventPersistResponse;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEventConstruct;
import com.monsanto.tps.lexicon.regulatory.helpers.AuditStage;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.dao.NonMonEventDao;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.dao.NonMonEventPersistQuerySet;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.model.NonMonEventPersistRichRequest;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.validation.NonMonEventUpdateValidation;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.validation.ValidationResults;
import com.monsanto.tps.lexicon.regulatory.util.collection.Sets;

import java.util.Collection;

/**
 * nbwald - May 25, 2009 2:53:14 PM
 */
public class NonMonEventUpdate
{
   private NonMonEventDao dao;
   private NonMonEventPersistQuerySet querySet;
   private NonMonEventUpdateValidation validation;

   @AuditStage(processName = "Update Non-Monsanto Event")
   public NonMonEventPersistResponse update(NonMonEventPersistRequest request, boolean validateOnly) {
      NonMonEventPersistRichRequest richRequest = new NonMonEventPersistRichRequest(querySet);
      richRequest.load(request);
      ValidationResults validationResults = validation.validate(richRequest);
      if (shouldCommit(validateOnly, validationResults)) {
         NonMonEvent nonMonEvent = richRequest.getExistingNonMonEvent();
         nonMonEvent.setEventDescription(request.getEventName());
         nonMonEvent.setCropPubkey(request.getCropPubkey());
         nonMonEvent.setActiveStatus(request.isActive());
         nonMonEvent.setMaterialName(request.getMaterialName()); 
         nonMonEvent.setProteinNames(richRequest.getProteinNames());
         updateCollection(nonMonEvent.getComlTraitNames(), richRequest.getComlTraitNames());
         updateCollection(nonMonEvent.getComlTraitTypes(), richRequest.getComlTraitTypes());
         saveSingleConstruct(nonMonEvent, richRequest.getConstructs());
         dao.update(nonMonEvent);
      }
      return buildResponse(validationResults, richRequest);
   }

   private <T> void updateCollection(Collection<T> original, Collection<T> newer) {
      original.clear();
      original.addAll(newer);
   }

   private boolean shouldCommit(boolean validateOnly, ValidationResults validationResults) {
      return !validateOnly && validationResults.isSuccess();
   }

   private void saveSingleConstruct(NonMonEvent nonMonEvent, String[] constructNames) {
      if (constructNames.length == 1) {
         updateCollection(nonMonEvent.getNonMonEventConstructs(), Sets.asSet(createNonMonEventConstruct(nonMonEvent, constructNames[0])));
      }
   }

   private NonMonEventConstruct createNonMonEventConstruct(NonMonEvent nonMonEvent, String constructName) {
      NonMonEventConstruct construct = new NonMonEventConstruct();
      construct.setConstructName(constructName);
      construct.setNonMonEvent(nonMonEvent);
      return construct;
   }

   private NonMonEventPersistResponse buildResponse(ValidationResults validationResults, NonMonEventPersistRichRequest richRequest) {
      NonMonEventPersistResponse response = new NonMonEventPersistResponse();
      response.setSuccess(validationResults.isSuccess());
      response.setMessages(validationResults.getMessages());
      response.setConstructs(richRequest.getConstructs());
      return response;
   }

   public void setDao(NonMonEventDao dao) {
      this.dao = dao;
   }

   public void setQuerySet(NonMonEventPersistQuerySet querySet) {
      this.querySet = querySet;
   }

   public void setValidation(NonMonEventUpdateValidation validation) {
      this.validation = validation;
   }
}
