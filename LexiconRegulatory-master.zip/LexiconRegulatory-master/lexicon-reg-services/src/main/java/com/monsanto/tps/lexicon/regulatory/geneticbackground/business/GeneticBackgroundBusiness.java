package com.monsanto.tps.lexicon.regulatory.geneticbackground.business;

import com.monsanto.tps.lexicon.geneticbackground.OrionGeneticBackground;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.GeneticBackground;
import com.monsanto.tps.lexicon.regulatory.geneticbackground.dao.GeneticBackgroundDAO;
import com.monsanto.tps.lexicon.regulatory.util.WildcardUtil;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 3/1/12
 * Time: 2:14 PM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class GeneticBackgroundBusiness {

    @Resource
    private GeneticBackgroundDAO geneticBackgroundDAO;

    public List<OrionGeneticBackground> findGeneticBackgrounds(final String geneticBackground) {
        final List<GeneticBackground> geneticBackgroundTypeList = geneticBackgroundDAO.findGeneticBackgrounds(WildcardUtil.replaceAsteriskWildcardWithPercent(geneticBackground));
        final List<OrionGeneticBackground> orionGeneticBackgroundList = new ArrayList<OrionGeneticBackground>();

        for (GeneticBackground type : geneticBackgroundTypeList) {
            orionGeneticBackgroundList.add(new OrionGeneticBackground(type.getGeneticBackground(), type.getActiveStatus()));
        }

        return orionGeneticBackgroundList;
    }


}

