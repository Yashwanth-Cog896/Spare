package com.monsanto.tps.lexicon.regulatory.agency.validation;

import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;
import org.apache.commons.lang.ArrayUtils;

/**
 * rrchak1 - Oct 21, 2008 3:50:21 PM
 */
public class AgencyCountryIsoCodeMustBeTwoLetterAlphabetsRule
   implements Rule
{
   private String[] agencyCountryIsoCode;

   public AgencyCountryIsoCodeMustBeTwoLetterAlphabetsRule(String[] agencyCountryIsoCode) {
      this.agencyCountryIsoCode = agencyCountryIsoCode;
   }

   public boolean violated() {
      if (!ArrayUtils.isEmpty(agencyCountryIsoCode)) {
         for (String isoCode : agencyCountryIsoCode) {
            if (!isoCode.matches("^[a-zA-Z]{2}+$")) {
               return true;
            }
         }
      }
      return false;
   }

   public Object getViolation() {
      return "Country ISO Code must contain only two alphabetic characters.";
   }
}
