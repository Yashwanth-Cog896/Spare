package com.monsanto.tps.lexicon.regulatory.sample.service;

import com.monsanto.tps.lexicon.sample.OrionSample;
import com.monsanto.tps.lexicon.regulatory.sample.business.SampleBusiness;
import com.monsanto.tps.lexicon.sample.SampleService;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 3/1/12
 * Time: 2:14 PM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class SampleServiceImpl implements SampleService {

    @Resource
    private SampleBusiness sampleBusiness;

    @Override
    public List<OrionSample> findSampleTypes(final String sampleType) {
        return sampleBusiness.findSampleTypes(sampleType);
    }
}
