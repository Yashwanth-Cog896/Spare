package com.monsanto.tps.lexicon.regulatory.storagelocation.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.StorageLocation;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: MMR
 * Date: 2/20/12
 * Time: 6:21 PM
 */
public interface StorageLocationDAO {

    public List<StorageLocation> findActiveStorageLocations(StorageLocation storageLocation);

    public List<StorageLocation> findStorageLocationsByList();

}
