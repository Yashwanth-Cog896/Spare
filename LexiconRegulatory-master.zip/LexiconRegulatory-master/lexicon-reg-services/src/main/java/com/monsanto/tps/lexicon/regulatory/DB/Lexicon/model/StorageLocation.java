package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model;

/**
 * Created by IntelliJ IDEA.
 * User: MMR
 * Date: 2/20/12
 * Time: 7:21 PM
 */
public class StorageLocation {
    private String storageLocation;
    private String physicalLocation;
    private String storageCondition;
    private Long storageLocationID;
    private Boolean activeStatus;
    private String commonName;
    private String commonDescription;
    private String equipmentID;


    public Long getStorageLocationID() {
        return storageLocationID;
    }

    public void setStorageLocationID(Long storageLocationID) {
        this.storageLocationID = storageLocationID;
    }

    public Boolean getActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(Boolean activeStatus) {
        this.activeStatus = activeStatus;
    }

    public String getStorageLocation() {
        return storageLocation;
    }

    public void setStorageLocation(String storageLocation) {
        this.storageLocation = storageLocation;
    }

    public String getPhysicalLocation() {
        return physicalLocation;
    }

    public void setPhysicalLocation(String physicalLocation) {
        this.physicalLocation = physicalLocation;
    }

    public String getStorageCondition() {
        return storageCondition;
    }

    public void setStorageCondition(String storageCondition) {
        this.storageCondition = storageCondition;
    }

    public String getEquipmentID() {
        return equipmentID;
    }

    public void setEquipmentID(String equipmentID) {
        this.equipmentID = equipmentID;
    }

    public String getCommonDescription() {
        return commonDescription;
    }

    public void setCommonDescription(String commonDescription) {
        this.commonDescription = commonDescription;
    }

    public String getCommonName() {
        return commonName;
    }

    public void setCommonName(String commonName) {
        this.commonName = commonName;
    }

}
