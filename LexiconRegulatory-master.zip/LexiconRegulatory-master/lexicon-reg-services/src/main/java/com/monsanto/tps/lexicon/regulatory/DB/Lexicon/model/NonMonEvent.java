package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model;

import java.util.Collection;
import java.util.HashSet;

/**
 * Created by IntelliJ IDEA.
 * User: gdleon
 * Date: May 6, 2009
 * Time: 2:28:20 PM
 */
public class NonMonEvent
{
   private long nonMonEventId;
   private String eventDescription;
   private String cropPubkey;
   private boolean activeStatus;
   private String materialName;
   private Collection<ComlTraitType> comlTraitTypes = new HashSet<ComlTraitType>();
   private Collection<ComlTraitName> comlTraitNames = new HashSet<ComlTraitName>();
   private Collection<NonMonEventConstruct> nonMonEventConstructs = new HashSet<NonMonEventConstruct>();
   private Collection<ProteinName> proteinNames = new HashSet<ProteinName>();

   public long getNonMonEventId() {
      return nonMonEventId;
   }

   public void setNonMonEventId(long nonMonEventId) {
      this.nonMonEventId = nonMonEventId;
   }

   public String getEventDescription() {
      return eventDescription;
   }

   public void setEventDescription(String eventDescription) {
      this.eventDescription = eventDescription;
   }

   public String getCropPubkey() {
      return cropPubkey;
   }

   public void setCropPubkey(String cropPubkey) {
      this.cropPubkey = cropPubkey;
   }

   public boolean isActiveStatus() {
      return activeStatus;
   }

    public String getMaterialName() {
        return materialName;
    }

    public void setMaterialName(String materialName) {
        this.materialName = materialName;
    }

    public void setActiveStatus(boolean activeStatus) {
      this.activeStatus = activeStatus;
   }

   public Collection<ComlTraitType> getComlTraitTypes() {
      return comlTraitTypes;
   }

   public void setComlTraitTypes(Collection<ComlTraitType> comlTraitTypes) {
      this.comlTraitTypes = comlTraitTypes;
   }

   public Collection<ComlTraitName> getComlTraitNames() {
      return comlTraitNames;
   }

   public void setComlTraitNames(Collection<ComlTraitName> comlTraitNames) {
      this.comlTraitNames = comlTraitNames;
   }

   public Collection<ProteinName> getProteinNames() {
      return proteinNames;
   }

   public void setProteinNames(Collection<ProteinName> proteinNames) {
      this.proteinNames = proteinNames;
   }

   public Collection<NonMonEventConstruct> getNonMonEventConstructs() {
      return nonMonEventConstructs;
   }

   public void setNonMonEventConstructs(Collection<NonMonEventConstruct> nonMonEventConstructs) {
      this.nonMonEventConstructs = nonMonEventConstructs;
   }
}
