package com.monsanto.tps.lexicon.regulatory.util.collection;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * nbwald - Sep 4, 2008 2:14:45 PM
 */
public class Sets
{
   public static <T> Set<T> asSet(T... objects) {
      return new HashSet<T>(Arrays.asList(objects));
   }
}
