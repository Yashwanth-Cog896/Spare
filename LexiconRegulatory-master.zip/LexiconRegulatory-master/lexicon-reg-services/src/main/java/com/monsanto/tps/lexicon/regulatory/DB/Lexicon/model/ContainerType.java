package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 3/1/12
 * Time: 2:28 PM
 * To change this template use File | Settings | File Templates.
 */
public class ContainerType {

    private long containerTypeId;
    private String containerType;
    private String storageCondition;
    private boolean activeStatus;
    public ContainerType() {}

    public ContainerType(String containerType, String storageCondition, boolean activeStatus) {
        this.containerType = containerType;
        this.storageCondition = storageCondition;
        this.activeStatus = activeStatus;
    }

    public long getContainerTypeId() {
        return containerTypeId;
    }

    public String getContainerType() {
        return containerType;
    }

    public void setContainerType(String containerType) {
        this.containerType = containerType;
    }

    public String getStorageCondition() {
        return storageCondition;
    }

    public void setStorageCondition(String storageCondition) {
        this.storageCondition = storageCondition;
    }

    public boolean getActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(boolean activeStatus) {
        this.activeStatus = activeStatus;
    }

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
    }
}
