package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model;

/**
 * Created by IntelliJ IDEA.
 * User: gdleon
 * Date: Apr 21, 2009
 * Time: 12:51:03 PM
 * To change this template use File | Settings | File Templates.
 */
public class MonNumberConstruct
{
   private long monNumberConstructId;
   private String constructName;
   private String pvCode;
   private MonNumber monNumber;

   public long getMonNumberConstructId() {
      return monNumberConstructId;
   }

   public void setMonNumberConstructId(long monNumberConstructId) {
      this.monNumberConstructId = monNumberConstructId;
   }

   public String getConstructName() {
      return constructName;
   }

   public void setConstructName(String constructName) {
      this.constructName = constructName;
   }

   public String getPvCode() {
      return pvCode;
   }

   public void setPvCode(String pvCode) {
      this.pvCode = pvCode;
   }

   public MonNumber getMonNumber() {
      return monNumber;
   }

   public void setMonNumber(MonNumber monNumber) {
      this.monNumber = monNumber;
   }
}
