package com.monsanto.tps.lexicon.regulatory.chemicalname.service;

import com.monsanto.tps.lexicon.chemicalname.ChemicalNameService;
import com.monsanto.tps.lexicon.chemicalname.OrionChemicalName;
import com.monsanto.tps.lexicon.regulatory.chemicalname.business.ChemicalNameBusiness;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/15/12
 * Time: 9:44 PM
 */
@Component
public class ChemicalNameServiceImpl implements ChemicalNameService {

    @Resource
    private ChemicalNameBusiness chemicalNameBusiness;

    @Override
    public List<OrionChemicalName> findChemicalNames(String materialName) {
        return chemicalNameBusiness.findChemicalNames(materialName);
    }
    @Override
    public List<OrionChemicalName> findChemicalMaterials(String materialName) {
        return chemicalNameBusiness.findChemicalMaterials(materialName);
    }
}
