package com.monsanto.tps.lexicon.regulatory.plantname.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.PlantName;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/15/12
 * Time: 9:42 PM
 */
public interface PlantNameDAO {
    List<PlantName> findPlantNames(String productName);
}
