package com.monsanto.tps.lexicon.regulatory.event.strategy;

import com.monsanto.tps.lexicon.event.AgencyMaterialDeregulationStatus;
import com.monsanto.tps.lexicon.event.EventDeregulationStatus;

/**
 * rrchak1 - Jun 23, 2009 11:00:24 AM
 */
public interface EventStatusByCropStrategy {
    public EventDeregulationStatus[] find(String[] events, String cropName);

    public AgencyMaterialDeregulationStatus[] findByMaterialName(String[] materialName, String cropName);
}
