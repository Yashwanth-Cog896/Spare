package com.monsanto.tps.lexicon.regulatory.event.dao;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.AgencyMaterialType;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;

/**
 * nbwald - Jan 7, 2009 3:29:47 PM
 */
public interface EventAgencyAlignmentDao {
    EventAgencyAlignment[] findByEventAndCrop(String eventName, String crop);

    public EventAgencyAlignment save(EventAgencyAlignment eventAgencyAlignment)
            throws WrappingException;

    public void update(EventAgencyAlignment eventAgencyAlignment)
            throws WrappingException;

    EventAgencyAlignment findByEventCropAndAgencyPubkey(String eventName, String cropName, String agencyPubkey);

    EventAgencyAlignment[] findByPubkey(String[] eventAgencyAlignmentPubkey);

    EventAgencyAlignment[] findByAgencyAbbr(String[] agencyAbbreviation);

    EventAgencyAlignment[] findByEventsCropAndAgencyAbbrs(String[] events, String cropName, String[] agencyAbbrs);

    public EventAgencyAlignment[] findByEventsCrop(String[] events, String cropName);

    public EventAgencyAlignment[] findByMaterialCrop(String[] materials, String cropName);

    AgencyMaterialType getAgencyMaterialTypeIdByName(String agencyMaterialTypeDesc);
}
