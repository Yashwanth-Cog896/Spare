/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.DB.midas.model;

import java.io.Serializable;

/* vvkalu - 7/22/11 */
public class ProgramEntity implements Serializable {
    private long id;
    private String refId;
    private boolean refActive;
    private boolean midasProgram;
    private MidasCropEntity crop;
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public MidasCropEntity getCrop() {
        return crop;
    }

    public void setCrop(MidasCropEntity crop) {
        this.crop = crop;
    }

    public boolean isMidasProgram() {
        return midasProgram;
    }

    public void setMidasProgram(boolean midasProgram) {
        this.midasProgram = midasProgram;
    }

    public boolean isRefActive() {
        return refActive;
    }

    public void setRefActive(boolean refActive) {
        this.refActive = refActive;
    }

    public String getRefId() {
        return refId;
    }

    public void setRefId(String refId) {
        this.refId = refId;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
}