package com.monsanto.tps.lexicon.regulatory.sample.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.SampleType;
import com.monsanto.tps.lexicon.regulatory.util.WildcardUtil;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 3/1/12
 * Time: 2:16 PM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class SampleDAOImpl implements SampleDAO {

    @Resource
    private SessionFactory sessionFactory;

    @Override
    public List<SampleType> findSampleTypes(final String sampleType) {

        final Session session = sessionFactory.getCurrentSession();

        final Query query = session.getNamedQuery("findActiveSampleIgnoreCaseSort");
        query.setParameter("sampleType", WildcardUtil.replaceEmptyStringWithWildcard(sampleType));

        return (List<SampleType>) query.list();
    }
}
