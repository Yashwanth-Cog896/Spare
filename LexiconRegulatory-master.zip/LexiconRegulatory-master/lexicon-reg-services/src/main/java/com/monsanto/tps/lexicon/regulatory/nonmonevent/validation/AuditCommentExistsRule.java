package com.monsanto.tps.lexicon.regulatory.nonmonevent.validation;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;

/**
 * nbwald - May 21, 2009 5:45:18 PM
 */
public class AuditCommentExistsRule
   implements Rule<String>
{
   private final String auditComment;

   public AuditCommentExistsRule(String auditComment) {
      this.auditComment = auditComment;
   }

   @Override
   public boolean violated() {
      return StringUtils.isNullOrEmpty(auditComment);
   }

   @Override
   public String getViolation() {
      return "Audit comment is required.";
   }
}
