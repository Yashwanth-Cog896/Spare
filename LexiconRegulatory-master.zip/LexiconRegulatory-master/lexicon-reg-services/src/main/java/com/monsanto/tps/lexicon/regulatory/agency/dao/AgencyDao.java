package com.monsanto.tps.lexicon.regulatory.agency.dao;

import com.monsanto.tps.lexicon.agency.AgencySearchCriteria;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Agency;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.AgencyDepartment;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Country;

/**
 * rrchak1 - Oct 13, 2008 10:15:38 AM
 */
public interface AgencyDao
{
   AgencyDepartment[] findDepartmentsBySearchCriteria(AgencySearchCriteria agencySearchCriteria);

   Agency getAgencyByAbbvAndCountry(String agencyAbbr, Country country);

   void saveAgency(Agency agency);

   void saveAgencyDepartment(AgencyDepartment department);

   AgencyDepartment getAgencyDepartmentByAgencyAndAbbr(Agency agency, String agencyDeptAbbr);

   AgencyDepartment getAgencyDepartmentByPubkey(String pubkey);

   Agency getAgencyByPubkey(String pubkey);

   void mergeAgency(Agency agency, Agency dbAgency);

   void mergeAgencyDepartment(AgencyDepartment agencyDepartment, AgencyDepartment dbAgencyDepartment);
}
