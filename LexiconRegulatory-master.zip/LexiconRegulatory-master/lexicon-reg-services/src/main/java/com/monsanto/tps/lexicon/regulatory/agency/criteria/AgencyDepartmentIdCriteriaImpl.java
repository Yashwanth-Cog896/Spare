package com.monsanto.tps.lexicon.regulatory.agency.criteria;

import org.apache.commons.lang.ArrayUtils;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

/**
 * rrchak1 - Oct 20, 2008 1:07:17 PM
 */
public class AgencyDepartmentIdCriteriaImpl
   implements QueryCriteria
{
   private long[] ids;

   public AgencyDepartmentIdCriteriaImpl(long[] ids) {
      this.ids = ids;
   }

   public Criterion getCriterion() {
      return Restrictions.in("agencyDeptId", ArrayUtils.toObject(ids));
   }

   public boolean hasCriteria() {
      return !ArrayUtils.isEmpty(ids);
   }
}
