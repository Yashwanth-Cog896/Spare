package com.monsanto.tps.lexicon.regulatory.container.business;

import com.monsanto.tps.lexicon.container.OrionContainer;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ContainerType;
import com.monsanto.tps.lexicon.regulatory.container.dao.ContainerDAO;
import com.monsanto.tps.lexicon.regulatory.util.WildcardUtil;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 3/1/12
 * Time: 2:14 PM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class ContainerBusiness {

    @Resource
    private ContainerDAO containerDAO;

    public List<OrionContainer> findContainerTypes(final String containerType) {
        final List<ContainerType> containerTypeList = containerDAO.findContainerTypes(WildcardUtil.replaceAsteriskWildcardWithPercent(containerType));
        final List<OrionContainer> orionContainerList = new ArrayList<OrionContainer>();

        for (ContainerType type : containerTypeList) {
            orionContainerList.add(new OrionContainer(type.getContainerType(), type.getStorageCondition(), type.getActiveStatus()));
        }

        return orionContainerList;
    }
}

