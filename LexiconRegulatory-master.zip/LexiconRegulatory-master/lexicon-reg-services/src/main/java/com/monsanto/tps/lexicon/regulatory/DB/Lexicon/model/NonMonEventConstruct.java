package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model;

/**
 * Created by IntelliJ IDEA.
 * User: gdleon
 * Date: May 7, 2009
 * Time: 9:23:58 AM
 */
public class NonMonEventConstruct
{
   private long nonMonEventConstructId;
   private NonMonEvent nonMonEvent;
   private String constructName;

   public long getNonMonEventConstructId() {
      return nonMonEventConstructId;
   }

   public void setNonMonEventConstructId(long nonMonEventConstructId) {
      this.nonMonEventConstructId = nonMonEventConstructId;
   }

   public NonMonEvent getNonMonEvent() {
      return nonMonEvent;
   }

   public void setNonMonEvent(NonMonEvent nonMonEvent) {
      this.nonMonEvent = nonMonEvent;
   }

   public String getConstructName() {
      return constructName;
   }

   public void setConstructName(String constructName) {
      this.constructName = constructName;
   }
}
