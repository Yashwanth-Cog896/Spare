package com.monsanto.tps.lexicon.regulatory.event.queryset;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tps.compliance.referencedata.molecularinfo.ConstructIdentifier;
import com.monsanto.tps.compliance.referencedata.molecularinfo.ConstructPVCodeAssignment;
import com.monsanto.tps.lexicon.regulatory.event.model.RegulatoryEventConstructTransformation;
import com.monsanto.tps.lexicon.regulatory.event.query.CompositeEventConstructTransformationsByEventAndCropQuery;
import com.monsanto.tps.lexicon.regulatory.event.query.EventConstructTransformationsByEventAndCropQuery;
import com.monsanto.tps.lexicon.regulatory.event.query.EventConstructTransformationsByStackedEventAndCropQuery;
import com.monsanto.tps.lexicon.regulatory.event.query.ExactMatchEventConstructTransformationsByEventAndCropQuery;

import java.io.IOException;
import java.util.List;

/**
 * nbwald - Feb 17, 2009 6:56:43 PM
 */
public class MidasOnlyAllRegulatoryEventQuerySet
   implements RegulatoryEventQuerySet
{
   private RegulatoryEventQuerySet delegate;

   @Override
   public RegulatoryEventConstructTransformation[] getEventConstructTransformations(String eventName, String cropGenusSpecies)
      throws WrappingException, IOException
   {
      EventConstructTransformationsByEventAndCropQuery query =
         new CompositeEventConstructTransformationsByEventAndCropQuery(
            new ExactMatchEventConstructTransformationsByEventAndCropQuery(),
            new EventConstructTransformationsByStackedEventAndCropQuery());
      return query.find(eventName, cropGenusSpecies
      );
   }

/*   @Override
   public String[] getTransCodesForSinglePmonConstruct(TransCodeQueryParams transCodeQueryParams)
      throws WrappingException
   {
      return delegate.getTransCodesForSinglePmonConstruct(transCodeQueryParams);
   }

   @Override
   public String getTransCodeForMultiPmonConstruct(TransCodeQueryParams transCodeQueryParams)
      throws WrappingException
   {
      return delegate.getTransCodeForMultiPmonConstruct(transCodeQueryParams);
   }*/

   @Override
   public String getGenusSpecies(String requestedCrop)
      throws WrappingException
   {
      return delegate.getGenusSpecies(requestedCrop);
   }

   @Override
   public String[] findProductVectorsByCropIdAndConstructNameForCombinedConstructs(long cropPubkey, String[] constructNames) {
      return delegate.findProductVectorsByCropIdAndConstructNameForCombinedConstructs(cropPubkey, constructNames);
   }

   @Override
   public String[] findProductVectorsByCropIdAndConstructNameForSingleConstructs(long cropPubkey, String constructName) {
      return delegate.findProductVectorsByCropIdAndConstructNameForSingleConstructs(cropPubkey, constructName);
   }

    @Override
    public List<ConstructPVCodeAssignment> findProductVectorsByCropIdAndConstructs(long cropPubkey, List<ConstructIdentifier> constructIdentifiers) {
        return delegate.findProductVectorsByCropIdAndConstructs(cropPubkey,constructIdentifiers); 
    }

    public void setDelegate(RegulatoryEventQuerySet delegate) {
      this.delegate = delegate;
   }
}
