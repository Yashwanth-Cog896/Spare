package com.monsanto.tps.lexicon.regulatory.event.model;

/**
 * User: pjberry
 * Date: Jul 30, 2007
 * Time: 4:43:34 PM
 */
public interface EventConstruct
{
   String getEvent();

   String getCrop();

   String getConstruct();

   String[] getTransCodes();
   void setTransCodes(String [] transCodes);

   String getTransformationBackground();
}
