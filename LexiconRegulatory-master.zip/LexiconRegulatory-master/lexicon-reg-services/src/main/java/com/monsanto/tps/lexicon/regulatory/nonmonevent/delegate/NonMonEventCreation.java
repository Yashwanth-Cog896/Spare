package com.monsanto.tps.lexicon.regulatory.nonmonevent.delegate;

import com.monsanto.tps.lexicon.nonmonevent.NonMonEventPersistRequest;
import com.monsanto.tps.lexicon.nonmonevent.NonMonEventPersistResponse;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEventConstruct;
import com.monsanto.tps.lexicon.regulatory.helpers.AuditStage;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.dao.NonMonEventDao;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.dao.NonMonEventPersistQuerySet;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.model.NonMonEventPersistRichRequest;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.validation.NonMonEventSaveValidation;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.validation.ValidationResults;
import com.monsanto.tps.lexicon.regulatory.util.collection.Sets;

/**
 * nbwald - May 20, 2009 12:57:42 PM
 */
public class NonMonEventCreation
{
   private NonMonEventDao dao;
   private NonMonEventSaveValidation validation;
   private NonMonEventPersistQuerySet querySet;

   @AuditStage(processName = "Create Non-Monsanto Event")
   public NonMonEventPersistResponse create(NonMonEventPersistRequest request, boolean validateOnly) {
      NonMonEventPersistRichRequest richRequest = new NonMonEventPersistRichRequest(querySet);
      richRequest.load(request);
      ValidationResults validationResults = validation.validate(richRequest);
      if (shouldCommit(validateOnly, validationResults)) {
         NonMonEvent nonMonEvent = new NonMonEvent();
         nonMonEvent.setEventDescription(request.getEventName());
         nonMonEvent.setMaterialName(request.getMaterialName()); 
         nonMonEvent.setCropPubkey(request.getCropPubkey());
         nonMonEvent.setActiveStatus(request.isActive());
         nonMonEvent.setProteinNames(richRequest.getProteinNames());
         nonMonEvent.setComlTraitNames(richRequest.getComlTraitNames());
         nonMonEvent.setComlTraitTypes(richRequest.getComlTraitTypes());
         dao.save(nonMonEvent);
         saveSingleConstruct(nonMonEvent, richRequest.getConstructs());
      }
      return buildResponse(validationResults, richRequest);
   }

   private boolean shouldCommit(boolean validateOnly, ValidationResults validationResults) {
      return !validateOnly && validationResults.isSuccess();
   }

   private void saveSingleConstruct(NonMonEvent nonMonEvent, String[] constructNames) {
      if (constructNames.length == 1) {
         nonMonEvent.setNonMonEventConstructs(Sets.asSet(createNonMonEventConstruct(nonMonEvent, constructNames[0])));
      }
   }

   private NonMonEventConstruct createNonMonEventConstruct(NonMonEvent nonMonEvent, String constructName) {
      NonMonEventConstruct construct = new NonMonEventConstruct();
      construct.setConstructName(constructName);
      construct.setNonMonEvent(nonMonEvent);
      return construct;
   }

   private NonMonEventPersistResponse buildResponse(ValidationResults validationResults, NonMonEventPersistRichRequest richRequest) {
      NonMonEventPersistResponse response = new NonMonEventPersistResponse();
      response.setSuccess(validationResults.isSuccess());
      response.setMessages(validationResults.getMessages());
      response.setConstructs(richRequest.getConstructs());
      return response;
   }

   public void setDao(NonMonEventDao dao) {
      this.dao = dao;
   }

   public void setQuerySet(NonMonEventPersistQuerySet querySet) {
      this.querySet = querySet;
   }

   public void setValidation(NonMonEventSaveValidation validation) {
      this.validation = validation;
   }
}
