package com.monsanto.tps.lexicon.regulatory.audit.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.AuditStaging;
import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import java.math.BigDecimal;
import java.util.Date;

/**
 * rrchak1 - Aug 19, 2008 4:33:01 PM
 */
public class AuditStagingDaoImpl
   implements AuditStagingDao
{
   private SessionFactory sessionFactory;

   public AuditStaging create(String userLoginId, String processName, String auditComment, String auditRequestor) {
      AuditStaging auditStaging = new AuditStaging();
      auditStaging.setProcessName(processName);
      auditStaging.setAuditComment(auditComment);
      auditStaging.setAuditRequestor(auditRequestor);
      auditStaging.setUserLoginId(userLoginId);
      auditStaging.setCreationTimestamp(getCurrentDatabaseTime());
      auditStaging.setMachine(getSessionMachine());
      auditStaging.setOracleSid(getSessionId());
      auditStaging.setOsuser(getSessionOsUser());
      save(auditStaging);
      return auditStaging;
   }

   private Date getCurrentDatabaseTime() {
      Session session = sessionFactory.getCurrentSession();
      return (Date) session.
         createSQLQuery("select systimestamp from dual").
         addScalar("systimestamp", Hibernate.TIMESTAMP).
         uniqueResult();
   }

   public void delete(AuditStaging auditStagingObj) {
      Session session = sessionFactory.getCurrentSession();
      session.delete(auditStagingObj);
   }

   private String getSessionMachine() {
      Session session = sessionFactory.getCurrentSession();
      return (String) session.getNamedQuery("selectSessionMachine").uniqueResult();
   }

   private String getSessionOsUser() {
//      Session session = sessionFactory.getCurrentSession();
//      return (String) session.getNamedQuery("selectSessionOsUser").uniqueResult();
      // TODO Fix: the thin driver (?) doesn't seem to be sending OSUSER which is mandatory in test.
      return "? - See AuditStagingDaoImpl";
   }

   private long getSessionId() {
      Session session = sessionFactory.getCurrentSession();
      BigDecimal bdSessionId = (BigDecimal) session.getNamedQuery("selectSessionId").uniqueResult();
      return bdSessionId.longValueExact();
   }

   private void save(AuditStaging auditStaging) {
      Session session = sessionFactory.getCurrentSession();
      session.save(auditStaging);
   }

   public void setSessionFactory(SessionFactory sessionFactory) {
      this.sessionFactory = sessionFactory;
   }
}
