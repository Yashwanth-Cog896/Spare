package com.monsanto.tps.lexicon.regulatory.nonmonevent.dao;

import com.monsanto.tcc.lexiconcommon.ArrayUtils;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType;
import com.monsanto.tps.lexicon.regulatory.util.collection.Sets;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;

import java.util.Collection;
import java.util.List;

/**
 * nbwald - May 21, 2009 8:31:10 PM
 */
public class ComlTraitTypeDao
{
   private final SessionFactory sessionFactory;

   public ComlTraitTypeDao(SessionFactory sessionFactory) {
      this.sessionFactory = sessionFactory;
   }

   public Collection<ComlTraitType> findByAbbrs(String... comlTraitTypeAbbrs) {
      if (ArrayUtils.isNullOrEmpty(comlTraitTypeAbbrs)) {
         return Sets.asSet();
      }
      Session session = sessionFactory.getCurrentSession();
      List results = session.getNamedQuery("comlTaitTypesByAbbrs").setParameterList("traitTypeAbbreviations", comlTraitTypeAbbrs).list();
      return (Collection<ComlTraitType>) results;
   }
}
