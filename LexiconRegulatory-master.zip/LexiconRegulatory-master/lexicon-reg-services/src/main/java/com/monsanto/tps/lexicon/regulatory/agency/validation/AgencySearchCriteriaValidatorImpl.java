package com.monsanto.tps.lexicon.regulatory.agency.validation;

import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;
import com.monsanto.tcc.lexiconcommon.validation.validator.SingleResultValidator;
import com.monsanto.tps.lexicon.agency.AgencySearchCriteria;

import java.util.ArrayList;
import java.util.List;

/**
 * rrchak1 - Oct 21, 2008 1:15:06 PM
 */
public class AgencySearchCriteriaValidatorImpl
   implements AgencySearchCriteriaValidator
{
   public void validate(AgencySearchCriteria agencySearchCriteria)
      throws IllegalArgumentException
   {
      SingleResultValidator<String> validator = new SingleResultValidator<String>(getRules(agencySearchCriteria), null);
      String violation = validator.validate();
      if (violation != null) {
         throw new IllegalArgumentException(violation);
      }
   }

   private List<? extends Rule<String>> getRules(AgencySearchCriteria agencySearchCriteria) {
      List<Rule<String>> rules = new ArrayList<Rule<String>>();
      rules.add(new AgencyCountryIsoCodeMustBeTwoLetterAlphabetsRule(agencySearchCriteria.getAgencyCountryIsoCode()));
      rules.add(new AgencyAbbrMustBeAlphaNumericRule(agencySearchCriteria.getAgencyAbbr()));
      rules.add(new AgencyAbbrMultipleWildcardRule(agencySearchCriteria.getAgencyAbbr()));
      rules.add(new AgencyPubkeyMustBeAlphaNumericRule(agencySearchCriteria.getAgencyPubkey()));
      rules.add(new AgencyDepartmentNameMustBeAlphaRule(agencySearchCriteria.getDepartmentNames()));
      rules.add(new AgencyDepartmentNameMultipleWildcardRule(agencySearchCriteria.getDepartmentNames()));
      return rules;
   }
}
