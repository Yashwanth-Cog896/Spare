package com.monsanto.tps.lexicon.regulatory.event.dao.productvector;

import com.monsanto.tps.compliance.referencedata.molecularinfo.ConstructIdentifier;
import com.monsanto.tps.compliance.referencedata.molecularinfo.ConstructPVCodeAssignment;
import com.monsanto.tps.compliance.referencedata.services.ProductVectorLookupService;
import java.util.List;
/**
 * rrchak1 - Apr 24, 2009 11:09:45 AM
 */
public class ProductVectorDaoImpl
   implements ProductVectorDao
{
   private ProductVectorLookupService productVectorLookupService;

   @Override
   public String[] findProductVectorsByCropIdAndConstructNameForCombinedConstructs(long cropPubkey, String[] constructNames) {
      return productVectorLookupService.findProductVectorsByCropIdAndConstructNameForCombinedConstructs(
         cropPubkey, constructNames
      );
   }


   @Override
   public String[] findProductVectorsByCropIdAndConstructNameForSingleConstructs(long cropPubkey, String constructName) {
      return productVectorLookupService.findProductVectorsByCropIdAndConstructNameForSingleConstructs(
         cropPubkey, constructName
      );
   }

   public List<ConstructPVCodeAssignment> findProductVectorsByCropIdAndConstructs(long cropPubkey, List<ConstructIdentifier> constructIdentifiers){
       return productVectorLookupService.findProductVectorsByCropIdAndConstructs(cropPubkey,constructIdentifiers);
   }
   public void setProductVectorLookupService(ProductVectorLookupService productVectorLookupService) {
      this.productVectorLookupService = productVectorLookupService;
   }
}
