/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.eventtraitservice.business;

import com.monsanto.tps.lexicon.eventtraitservice.transfer.*;

import java.util.List;

/* vvkalu - 7/27/11 */
public class EventTraitServiceBusiness {
    private static final String ERROR_STRING = "No Commercial Trait Stack, MonNumbers or PVCodes found for the germplasm";
    private ComlTraitBusiness comlTraitBusiness;
    private EventTraitBusiness eventTraitBusiness;
    private MonNumberAndPVCodesBusiness monNumberAndPVCodesBusiness;

    public GermplasmEventTraitResponse getGermplasmTraitEventConstructs(GermplasmEventTraitRequest request) {
        GermplasmEventTraitResponse germplasmEventTraitResponse = new GermplasmEventTraitResponse();
        if (request != null && request.getGermplasmIds() != null) {
            for (Long germplasmId : request.getGermplasmIds()) {
                lexiconProductComlTrait(germplasmId, germplasmEventTraitResponse);
                eventConstructComTrait(germplasmId, germplasmEventTraitResponse);
                eventConstructMonNumberAndPVCodes(germplasmId, germplasmEventTraitResponse);
                checkForEmptyResponse(germplasmEventTraitResponse, germplasmId);
            }
        }
        return germplasmEventTraitResponse;
    }

    private GermplasmEventTraitResponse lexiconProductComlTrait(Long germplasmId, GermplasmEventTraitResponse germplasmEventTraitResponse) {
        return comlTraitBusiness.getComlTraitForProduct(germplasmId, germplasmEventTraitResponse);
    }

    private GermplasmEventTraitResponse eventConstructComTrait(Long germplasmId, GermplasmEventTraitResponse germplasmEventTraitResponse) {
        if (checkIfAlreadyProcessed(germplasmId, germplasmEventTraitResponse)) {
            germplasmEventTraitResponse = eventTraitBusiness.getComlTraitForEvents(germplasmId, germplasmEventTraitResponse);
        }
        return germplasmEventTraitResponse;
    }

    private GermplasmEventTraitResponse eventConstructMonNumberAndPVCodes(Long germplasmId, GermplasmEventTraitResponse germplasmEventTraitResponse) {
        if (checkIfAlreadyProcessed(germplasmId, germplasmEventTraitResponse)) {
            germplasmEventTraitResponse = monNumberAndPVCodesBusiness.findMonNumberAndPVCodes(germplasmId, germplasmEventTraitResponse);
        }
        return germplasmEventTraitResponse;
    }

    private boolean checkIfAlreadyProcessed(Long germplasmId, GermplasmEventTraitResponse germplasmEventTraitResponse) {
        boolean notProcessed = true;
        if (germplasmEventTraitResponse.getGermplasmEventTraits() != null && !germplasmEventTraitResponse.getGermplasmEventTraits().isEmpty()) {
            for (GermplasmEventTrait germplasmEventTrait : germplasmEventTraitResponse.getGermplasmEventTraits()) {
                if (germplasmEventTrait.getGermplasmId() == germplasmId) {
                    notProcessed = false;
                }
            }
        } else {
            notProcessed = true;
        }
        return notProcessed;
    }

    private void checkForEmptyResponse(GermplasmEventTraitResponse traitEventConstructs, Long germplasmId) {
        List<GermplasmEventTrait> germplasmEventTraits = traitEventConstructs.getGermplasmEventTraits();
        if (!checkIfAlreadyProcessed(germplasmId, traitEventConstructs)) {
            setResponseMessageForProcessed(germplasmId, germplasmEventTraits);
        } else {
            setErrorResponseMessage(traitEventConstructs, germplasmId);
        }
    }

    private void setErrorResponseMessage(GermplasmEventTraitResponse traitEventConstructs, Long germplasmId) {
        GermplasmEventTrait germplasmEventTrait = new GermplasmEventTrait();
        germplasmEventTrait.setGermplasmId(germplasmId);
        ResponseMessage responseMessage = new ResponseMessage(ResponseMessageType.ERROR, ERROR_STRING);
        germplasmEventTrait.setResponseMessage(responseMessage);
        traitEventConstructs.getGermplasmEventTraits().add(germplasmEventTrait);
    }

    private void setResponseMessageForProcessed(Long germplasmId, List<GermplasmEventTrait> germplasmEventTraits) {
        for (GermplasmEventTrait germplasmEventTrait : germplasmEventTraits) {
            if (germplasmEventTrait.getGermplasmId() == germplasmId) {
                if (checkForEmptyComlTraitStackAndEventConstructs(germplasmId, germplasmEventTrait)) {
                    ResponseMessage responseMessage = new ResponseMessage(ResponseMessageType.ERROR, ERROR_STRING);
                    germplasmEventTrait.setResponseMessage(responseMessage);
                } else {
                    germplasmEventTrait.setResponseMessage(new ResponseMessage());
                }
            }
        }
    }

    private boolean checkForEmptyComlTraitStackAndEventConstructs(Long germplasmId, GermplasmEventTrait germplasmEventTrait) {
        return germplasmEventTrait.getTraitStack() == null &&
                germplasmEventTrait.getEventConstruct() == null;
    }

    public void setComlTraitBusiness(ComlTraitBusiness comlTraitBusiness) {
        this.comlTraitBusiness = comlTraitBusiness;
    }

    public void setEventTraitBusiness(EventTraitBusiness eventTraitBusiness) {
        this.eventTraitBusiness = eventTraitBusiness;
    }

    public void setMonNumberAndPVCodesBusiness(MonNumberAndPVCodesBusiness monNumberAndPVCodesBusiness) {
        this.monNumberAndPVCodesBusiness = monNumberAndPVCodesBusiness;
    }
}