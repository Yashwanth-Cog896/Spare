/*
 ValidationResults was created on Jun 28, 2007 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexicon.regulatory.util.validationresults;

import com.monsanto.tcc.lexiconcommon.validation.UnexpectedCondition;
import com.monsanto.tcc.lexiconcommon.validation.ValidationCondition;
import com.monsanto.tcc.lexiconcommon.validation.ValidationConditionSeverity;
import com.monsanto.tcc.lexiconcommon.validation.ValidationStatus;
import com.monsanto.tcc.lexiconcommon.validation.ValidationStatusImpl;

import java.util.ArrayList;
import java.util.List;

/**
 * nbwald Jun 28, 2007 11:10:22 AM
 */
public class ValidationResults
{
   private final ValidationStatus validationStatus;

   public ValidationResults(ValidationStatus validationStatus) {
      this.validationStatus = validationStatus;
   }

   public ValidationResults(String[] errors) {
      this.validationStatus = new ValidationStatusImpl();
      for (String error : errors) {
         validationStatus.addCondition(new SimpleValidationCondition(error), ValidationConditionSeverity.ERROR);
      }
   }

   public ValidationResults(Exception e) {
      this.validationStatus = new ValidationStatusImpl();
      validationStatus.addCondition(new UnexpectedCondition(e), ValidationConditionSeverity.ERROR);
   }

   public String[] getErrors() {
      List<String> errors = getMessagesForSeverity(ValidationConditionSeverity.ERROR, false);
      return errors.toArray(new String[errors.size()]);
   }

   public boolean hasErrors() {
      return validationStatus.hasSeverity(ValidationConditionSeverity.ERROR);
   }

   public String[] getMessages() {
      List<String> messages = new ArrayList<String>();
      messages.addAll(getMessagesForSeverity(ValidationConditionSeverity.ERROR, true));
      messages.addAll(getMessagesForSeverity(ValidationConditionSeverity.INFO, true));
      return messages.toArray(new String[messages.size()]);
   }

   protected List<String> getMessagesForSeverity(ValidationConditionSeverity severity, boolean prefixSeverity) {
      ValidationCondition[] conditions = validationStatus.getConditions(severity);
      List<String> messages = new ArrayList<String>();
      for (ValidationCondition condition : conditions) {
         messages.add(buildMessage(condition, severity, prefixSeverity));
      }
      return messages;
   }

   private String buildMessage(ValidationCondition condition, ValidationConditionSeverity severity, boolean prefixSeverity) {
      return prefixSeverity ? severity.getName() + ": " + condition.getError() : condition.getError();
   }
}