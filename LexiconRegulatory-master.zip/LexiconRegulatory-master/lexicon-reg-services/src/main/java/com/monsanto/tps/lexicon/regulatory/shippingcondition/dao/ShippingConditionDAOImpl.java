package com.monsanto.tps.lexicon.regulatory.shippingcondition.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ShippingCondition;
import com.monsanto.tps.lexicon.regulatory.util.WildcardUtil;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 3/1/12
 * Time: 2:16 PM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class ShippingConditionDAOImpl implements ShippingConditionDAO {

    @Resource
    private SessionFactory sessionFactory;

    @Override
    public List<ShippingCondition> findShippingConditions(final String containerType) {

        final Session session = sessionFactory.getCurrentSession();

        final Query query = session.getNamedQuery("findActiveShippingConditionIgnoreCaseSort");
        query.setParameter("shippingCondition", WildcardUtil.replaceEmptyStringWithWildcard(containerType));

        return (List<ShippingCondition>) query.list();
    }


}
