package com.monsanto.tps.lexicon.regulatory.event.model;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Dec 8, 2005
 * Time: 10:24:31 AM
 */
public class RegulatoryEventRequest
{
   private final String event;
   private final String crop;

   public RegulatoryEventRequest(String event, String crop) {
      this.event = event;
      this.crop = crop;
   }

   public String getEvent() {
      return event;
   }

   public String getCrop() {
      return crop;
   }
}
