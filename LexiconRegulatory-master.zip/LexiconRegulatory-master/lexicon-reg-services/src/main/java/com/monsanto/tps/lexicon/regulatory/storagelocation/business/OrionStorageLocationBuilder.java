package com.monsanto.tps.lexicon.regulatory.storagelocation.business;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.StorageLocation;
import com.monsanto.tps.lexicon.storagelocation.OrionStorageLocation;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: MMR
 * Date: 2/20/12
 * Time: 7:49 PM
 */

public class OrionStorageLocationBuilder {

    public List<OrionStorageLocation> build(List<StorageLocation> storageLocations) {
        List<OrionStorageLocation> orionStorageLocations = new ArrayList<OrionStorageLocation>();
        if (storageLocations != null) {
            for (StorageLocation storageLocation : storageLocations) {
                build(storageLocation, orionStorageLocations);
            }
        }
        return orionStorageLocations;
    }

    private void build(StorageLocation storageLocation, List<OrionStorageLocation> orionStorageLocations) {
        OrionStorageLocation orionStorageLocation = new OrionStorageLocation();
        orionStorageLocation.setStorageLocation(storageLocation.getStorageLocation());
        orionStorageLocation.setPhysicalLocation(storageLocation.getPhysicalLocation());
        orionStorageLocation.setDefaultStorageCondition(storageLocation.getStorageCondition());
        orionStorageLocations.add(orionStorageLocation);
    }
}
