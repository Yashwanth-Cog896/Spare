package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model;

import java.util.Date;


public class AgencyMaterialType {

    private long materialTypeId;
    private String materialTypeDesc;
    private Date inactiveDate;
    private Date createdDate;
    private String createdUserID;
    private Date modifiedDate;
    private String modifiedUserId;

    public long getMaterialTypeId() {
        return materialTypeId;
    }

    public void setMaterialTypeId(long materialTypeId) {
        this.materialTypeId = materialTypeId;
    }

    public String getMaterialTypeDesc() {
        return materialTypeDesc;
    }

    public void setMaterialTypeDesc(String materialTypeDesc) {
        this.materialTypeDesc = materialTypeDesc;
    }

    public Date getInactiveDate() {
        return inactiveDate;
    }

    public void setInactiveDate(Date inactiveDate) {
        this.inactiveDate = inactiveDate;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedUserID() {
        return createdUserID;
    }

    public void setCreatedUserID(String createdUserID) {
        this.createdUserID = createdUserID;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getModifiedUserId() {
        return modifiedUserId;
    }

    public void setModifiedUserId(String modifiedUserId) {
        this.modifiedUserId = modifiedUserId;
    }
}
