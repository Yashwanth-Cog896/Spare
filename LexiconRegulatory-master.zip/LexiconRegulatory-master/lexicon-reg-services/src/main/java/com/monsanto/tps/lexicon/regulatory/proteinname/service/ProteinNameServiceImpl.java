package com.monsanto.tps.lexicon.regulatory.proteinname.service;

import com.monsanto.tps.lexicon.geneticbackground.GeneticBackgroundService;
import com.monsanto.tps.lexicon.geneticbackground.OrionGeneticBackground;
import com.monsanto.tps.lexicon.proteinname.OrionProteinName;
import com.monsanto.tps.lexicon.proteinname.ProteinNameService;
import com.monsanto.tps.lexicon.regulatory.proteinname.business.ProteinNameBusiness;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 3/1/12
 * Time: 2:14 PM
 * To change this template use File | Settings | File Templates.
 */
@Component
public class ProteinNameServiceImpl implements ProteinNameService {

    @Resource
    private ProteinNameBusiness proteinNameBusiness;

    @Override
    public List<OrionProteinName> findProteinNames(final String geneticBackgroundType) {
        return proteinNameBusiness.findProteinNames(geneticBackgroundType);
    }
}
