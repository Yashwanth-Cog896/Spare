<%@ page import="java.io.InputStream" %>
<%@ page import="java.net.URL" %>
<%@ page import="java.util.jar.Attributes" %>
<%@ page import="java.util.jar.Manifest" %>
<%--
  Created by IntelliJ IDEA.
  User: tbmckay
  Date: Feb 29, 2008
  Time: 7:05:31 AM
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
   <HEAD>
      <TITLE> Lexicon Regulatory </TITLE>
   </HEAD>
   <body>
      <%
         String version = "";
         String buildDate = "";
         String builtBy = "";
         URL url = application.getResource("/META-INF/MANIFEST.MF");
         if (url != null) {
            InputStream in = url.openStream();
            try {
               Manifest mf = new Manifest(in);
               Attributes attrs = mf.getMainAttributes();
               version = attrs.getValue("Version");
               buildDate = attrs.getValue("Build-Timestamp");
               builtBy = attrs.getValue("Built-By");
            }
            finally {
               in.close();
            }
         }
      %>

      <table>
         <tr>
            <td>Current Version:</td>
            <td><%out.print(version);%></td>
         </tr>
         <tr>
            <td>Build Date:</td>
            <td><%out.print(buildDate);%></td>
         </tr>
         <tr>
            <td>Built By:</td>
            <td><%out.print(builtBy);%></td>
         </tr>
      </table>
   </body>
</html>