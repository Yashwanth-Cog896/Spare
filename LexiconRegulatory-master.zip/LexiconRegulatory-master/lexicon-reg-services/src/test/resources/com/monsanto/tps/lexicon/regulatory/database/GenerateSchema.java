package com.monsanto.tps.lexicon.regulatory.database;

import org.dbunit.database.DatabaseConnection;
import org.dbunit.database.QueryDataSet;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.xml.FlatXmlDataSet;

import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import static com.google.common.collect.Lists.newArrayList;
import static java.sql.DriverManager.getConnection;
import static org.dbunit.database.search.TablesDependencyHelper.getAllDependentTables;

/**
 * Created by IntelliJ IDEA.
 * User: GSUGA
 * Date: 16/04/12
 * Time: 13:11
 * To change this template use File | Settings | File Templates.
 */
public class GenerateSchema {

    private static final String URL = "jdbc:oracle:thin:@//dsbreed-dev.monsanto.com:1521/dsbreeddsvc.monsanto.com";
    private static final String SCHEMA_NAME = "LEXICON";
    private static final String USER = "LEXICON_USER";
    private static final String PWD = "Y3O4I_1T9J6I5";


    private static final String TABLES_WITHOUT_ID_SEQ_SYS = "select table_name from cat  " +
            "where (" +
            "table_name not like '%_ID_%' and " +
            "table_name not like '%_SEQ%' and " +
            "table_name not like 'SYS_%') " +
            "order by table_name";


    public static void main(String[] args) throws Exception {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        Connection jdbcConnection = getConnection(URL, USER, PWD);
        DatabaseConnection dbConn = new DatabaseConnection(jdbcConnection, SCHEMA_NAME);

        List<String> tableNames = executeSQL(jdbcConnection, TABLES_WITHOUT_ID_SEQ_SYS);
        List<String> validTableNames = trimListToValidTableNames(dbConn, tableNames);

        loadDependencies(dbConn, validTableNames);

        if (null != jdbcConnection) jdbcConnection.close();
    }

    private static List<String> executeSQL(Connection jdbcConnection, String tablesWithoutIdSeqSys) {
        List<String> tables = newArrayList();
        try {
            tables = transform(jdbcConnection.createStatement().executeQuery(tablesWithoutIdSeqSys));
        } catch (SQLException e) {
            System.out.println("SQL Exception occured " + e);
        }
        return tables;
    }

    private static void loadDependencies(DatabaseConnection dbConn, List<String> validTableNames) {

        for (String tableName : validTableNames) {
            try {
                FlatXmlDataSet.write(dbConn.createDataSet(getAllDependentTables(dbConn, tableName)), new FileOutputStream(tableName + "_DEPENDENCIES.xml"));
                System.out.println("DEPENDENCIES OF TABLE=" + tableName + " NOW LOADED");
            } catch (Exception e) {
                System.out.println("DEPENDENCIES OF TABLE NOT LOADED=" + tableName);
            }
        }
    }

    private static List<String> trimListToValidTableNames(DatabaseConnection jdbcConnection, List<String> tableNames) {
        List<String> validTableNames = newArrayList(tableNames);
        QueryDataSet partialDataSet;
        for (String tableName : tableNames) {
            try {
                partialDataSet = new QueryDataSet(new DatabaseConnection((Connection) jdbcConnection, SCHEMA_NAME));
                partialDataSet.addTable(tableName, limit25(tableName));

                FlatXmlDataSet.write(partialDataSet, new FileOutputStream(tableName + ".xml"));
                System.out.println("DATASET CREATED FOR TABLE=" + tableName);
            } catch (Exception e) {
                validTableNames.remove(tableName);
            }
        }
        return validTableNames;
    }

    private static String limit25(String tableName) {
        return "select * from " + SCHEMA_NAME + "." + tableName + " where (ROWNUM < 26)";
    }

    //be careful using this, will return ALL DATA!!!
    private static String returnAll(String tableName) {
        return "select * from " + SCHEMA_NAME + "." + tableName;
    }

    private static List<String> transform(ResultSet rs) {
        List<String> tableNames = newArrayList();
        try {
            while (rs.next()) {
                tableNames.add(rs.getString("TABLE_NAME"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return tableNames;
    }
}

