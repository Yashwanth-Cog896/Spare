package com.monsanto.tps.lexicon.regulatory.chemicalname.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.DBUnitTest;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.AdditionalMaterial;
import com.monsanto.tps.lexicon.regulatory.additionalmaterialinfo.dao.AdditionalMaterialDAO;
import com.monsanto.tps.springframework.test.listener.dbunit.DataSet;
import com.monsanto.tps.springframework.test.listener.dbunit.DatasetOperation;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Comparator;
import java.util.List;

import static com.google.common.collect.Ordering.from;
import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/1/12
 * Time: 7:47 PM
 * To change this template use File | Settings | File Templates.
 */
@DataSet(
        schema = "LEXICON", dataSourceKey = "dataSource", setupOperation = DatasetOperation.CLEAN_INSERT, teardownOperation = DatasetOperation.NONE,
        value = {"/com/monsanto/tps/lexicon/regulatory/additionalmaterial/dao/additional_material.xml"}
)
public class AdditionalMaterialDAOImpl_DUT extends DBUnitTest {

    @Autowired
    private AdditionalMaterialDAO additionalMaterialDAO;

    @Test
    public void findMaterialName_results_wildcard() throws Exception {
        final List<AdditionalMaterial> materialNames = additionalMaterialDAO.findAdditionalMaterials("tri%");
        assertNotNull(materialNames);
        assertFalse(materialNames.isEmpty());
    }

    @Test
    public void findMaterialName_results_exactMatch() throws Exception {
        final List<AdditionalMaterial> materialNames = additionalMaterialDAO.findAdditionalMaterials("triasulfuron");
        assertNotNull(materialNames);
        assertFalse(materialNames.isEmpty());
    }

    @Test
    public void findMaterialName_noResults() throws Exception {
        final List<AdditionalMaterial> materialNames = additionalMaterialDAO.findAdditionalMaterials("asdf");
        assertNotNull(materialNames);
        assertTrue(materialNames.isEmpty());
    }

    @Test
    public void findMaterialName_results_active() throws Exception {
        final List<AdditionalMaterial> materialNames = additionalMaterialDAO.findAdditionalMaterials("");
        assertNotNull(materialNames);
        assertFalse(materialNames.isEmpty());

        for (AdditionalMaterial materialName : materialNames) {
            assertTrue(materialName.getActiveStatus());
        }
    }

    @Test
    public void findMaterialName_sorted() throws Exception {
        final List<AdditionalMaterial> materialNames = additionalMaterialDAO.findAdditionalMaterials("%");
        assertNotNull(materialNames);

        assertTrue(from(new MaterialNameComparator()).isOrdered(materialNames));
    }

    private class MaterialNameComparator implements Comparator<AdditionalMaterial> {

        public final int compare(AdditionalMaterial c1, AdditionalMaterial c2) {

            int ctCompare = 0;

            if (c1 != null && c2 != null) {
                String ct1 = c1.getMaterialName();
                String ct2 = c2.getMaterialName();
                if (ct1 != null && ct2 != null) {
                    ctCompare = ct1.compareToIgnoreCase(ct2);
                }
            }

            return ctCompare;
        }
    }
}

