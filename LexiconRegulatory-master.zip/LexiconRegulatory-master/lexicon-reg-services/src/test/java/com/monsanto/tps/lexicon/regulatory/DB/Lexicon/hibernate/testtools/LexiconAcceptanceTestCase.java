package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools;

import com.monsanto.tcc.lexiconcommon.db.test.LexiconTestTools;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.AuditStaging;
import com.monsanto.tps.lexicon.regulatory.audit.dao.AuditStagingDao;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.junit.Before;

import javax.annotation.Resource;

/**
 * nbwald - Sep 11, 2008 3:46:16 PM
 */
public abstract class LexiconAcceptanceTestCase
   extends LexiconSpringContextTests
{
   @Resource
   private AuditStagingDao auditStagingDao;

   @Resource(name = "sessionFactory")
   public SessionFactory lexiconSessionFactory ;

   public Session currentSession;

   @Before
   public void onSetUpInTransaction()
      throws Exception
   {
      TestSessions.setLexiconSessionFactory(lexiconSessionFactory);
      currentSession = lexiconSessionFactory.getCurrentSession();
   }

   protected <T> T insert(AcceptanceTestData<T> data) {
      AuditStaging testStaging = auditStagingDao.create(
         LexiconTestTools.UNIT_TEST_USER_LOGIN_ID,
         LexiconTestTools.UNIT_TEST_PROCESS_NAME,
         LexiconTestTools.UNIT_TEST_AUDIT_COMMENT,
         LexiconTestTools.UNIT_TEST_AUDIT_REQUESTOR);
      T t = data.dataToInsert();
      TestSessions.getLexiconSession().flush();
      auditStagingDao.delete(testStaging);
      TestSessions.getLexiconSession().flush();
      return t;

   }

   protected interface AcceptanceTestData<T>
   {
      T dataToInsert();
   }
}
