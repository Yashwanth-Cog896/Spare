package com.monsanto.tps.lexicon.regulatory.plantname.business;

import com.monsanto.tps.lexicon.plantname.OrionPlantProduct;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.PlantProduct;
import com.monsanto.tps.lexicon.regulatory.plantname.dao.RegulatorySeedMaterialDAO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 6/22/12
 * Time: 12:12 PM
 */
@RunWith(MockitoJUnitRunner.class)
public class RegulatorySeedMaterialBusiness_UT {

        @Mock
        private RegulatorySeedMaterialDAO regulatorySeedMaterialDAO;

        @InjectMocks
        private RegulatorySeedMaterialBusiness regulatorySeedMaterialBusiness = new RegulatorySeedMaterialBusiness();

        private final List<PlantProduct> singlePlantNameListFromDAO;
        private final List<PlantProduct> multiPlantNameListFromDAO;
        private static final List<PlantProduct> emptyListFromDAO = new ArrayList<PlantProduct>();

        private final List<OrionPlantProduct> singlePlantNameListFromBusiness;
        private final List<OrionPlantProduct> multiPlantNameListFromBusiness;
        private static final List<OrionPlantProduct> emptyListFromBusiness = new ArrayList<OrionPlantProduct>();

        public RegulatorySeedMaterialBusiness_UT() {
            singlePlantNameListFromDAO = new ArrayList<PlantProduct>();
            singlePlantNameListFromDAO.add(new PlantProduct("name", "crop"));

            multiPlantNameListFromDAO = new ArrayList<PlantProduct>();
            multiPlantNameListFromDAO.add(new PlantProduct("name1", "crop1"));
            multiPlantNameListFromDAO.add(new PlantProduct("name2", "crop2"));

            singlePlantNameListFromBusiness = new ArrayList<OrionPlantProduct>();
            singlePlantNameListFromBusiness.add(new OrionPlantProduct("name", "crop"));

            multiPlantNameListFromBusiness = new ArrayList<OrionPlantProduct>();
            multiPlantNameListFromBusiness.add(new OrionPlantProduct("name1", "crop1"));
            multiPlantNameListFromBusiness.add(new OrionPlantProduct("name2", "crop2"));
        }

        @Test
        public void findPlantName_findNone() throws Exception {

            when(regulatorySeedMaterialDAO.findMonsantoProductNames("asdf")).thenReturn(emptyListFromDAO);
            when(regulatorySeedMaterialDAO.findCompetitorProductNames("asdf")).thenReturn(emptyListFromDAO);

            final List<OrionPlantProduct> actualPlantNames = regulatorySeedMaterialBusiness.findPlantNames("asdf");

            checkPlantNameLists(actualPlantNames, emptyListFromBusiness,  emptyListFromBusiness);
        }

        @Test
        public void findPlantName_findSingle() throws Exception {

            when(regulatorySeedMaterialDAO.findMonsantoProductNames("BollGard Cotton")).thenReturn(singlePlantNameListFromDAO);
            when(regulatorySeedMaterialDAO.findCompetitorProductNames("asdf")).thenReturn(emptyListFromDAO);

            final List<OrionPlantProduct> actualPlantNames = regulatorySeedMaterialBusiness.findPlantNames("BollGard Cotton");

            checkPlantNameLists(actualPlantNames, emptyListFromBusiness, singlePlantNameListFromBusiness);
        }

        @Test
        public void findPlantName_findByWildcard() throws Exception {

            when(regulatorySeedMaterialDAO.findMonsantoProductNames("Round%")).thenReturn(multiPlantNameListFromDAO);
            when(regulatorySeedMaterialDAO.findCompetitorProductNames("Round%")).thenReturn(singlePlantNameListFromDAO);

            final List<OrionPlantProduct> actualPlantNames = regulatorySeedMaterialBusiness.findPlantNames("Round*");

            checkPlantNameLists(actualPlantNames, singlePlantNameListFromBusiness, multiPlantNameListFromBusiness);
        }

        @Test
        public void findPlantName_findAll() throws Exception {

            when(regulatorySeedMaterialDAO.findMonsantoProductNames("%")).thenReturn(multiPlantNameListFromDAO);
            when(regulatorySeedMaterialDAO.findCompetitorProductNames("%")).thenReturn(singlePlantNameListFromDAO);

            final List<OrionPlantProduct> actualPlantNames = regulatorySeedMaterialBusiness.findPlantNames("");

            checkPlantNameLists(actualPlantNames, singlePlantNameListFromBusiness, multiPlantNameListFromBusiness);
        }

        private void checkPlantNameLists(final List<OrionPlantProduct> actualPlantNames,
            final List<OrionPlantProduct> expectedCompetitorPlantNamesFromBusiness, final List<OrionPlantProduct> expectedMonsantoPlantNamesFromBusiness) {

            assertNotNull(actualPlantNames);

            for(OrionPlantProduct product : expectedMonsantoPlantNamesFromBusiness) {
                assertContains(actualPlantNames, product);
            }
            for(OrionPlantProduct product : expectedCompetitorPlantNamesFromBusiness) {
                assertContains(actualPlantNames, product);
            }
        }

    private void assertContains(List<OrionPlantProduct> actualPlantNames, OrionPlantProduct product) {
        boolean found=false;
        for(OrionPlantProduct plantName : actualPlantNames) {
            if((plantName.getName() == product.getName()) && (plantName.getCrop() == plantName.getCrop())) {
                found = true;
            }
        }
        assertTrue(found);
    }
}
