package com.monsanto.tps.lexicon.regulatory.DB.Tests;

import com.monsanto.tcc.lexiconcommon.db.monitor.test.TestFixtureTransactionMonitorManager;
import com.monsanto.tcc.lexiconcommon.file.commonpath.CommonFileLocation;
import com.monsanto.tcc.lexiconcommon.service.regulatoryevent.RegulatoryEventSchemaConstants;
import org.custommonkey.xmlunit.SimpleXpathEngine;

import java.io.File;
import java.io.FileWriter;
import java.util.Calendar;
import java.util.Date;

public class LexiconDataServiceATTestCase
   extends DataServiceATTestCase
{

   private Date EFFECTIVE_DATE;
   private Date EXPIRATION_DATE;

   @Override
   public void setUp()
      throws Exception
   {
      super.setUp();
      SimpleXpathEngine.registerNamespace("ns", RegulatoryEventSchemaConstants.NAMESPACE);

      EFFECTIVE_DATE = buildDate(1999, 2, 26);
      EXPIRATION_DATE = buildDate(2000, 2, 26);
   }

   @Override
   public void tearDown()
      throws Exception
   {
      super.tearDown();
   }

   private Date buildDate(int year, int month, int day) {
      Calendar effectiveCal = Calendar.getInstance();
      effectiveCal.clear();
      effectiveCal.set(year, month, day);
      return effectiveCal.getTime();
   }

   public Date getExpirationDate() {
      return EXPIRATION_DATE;
   }

   public Date getEffectiveDate() {
      return EFFECTIVE_DATE;
   }

   public TestFixtureTransactionMonitorManager getTestManager() {
      return super.getTestManager();
   }

}