package com.monsanto.tps.lexicon.regulatory.nonmonevent.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.LexiconDataUnitTestCase;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.ProteinNameBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName;
import org.junit.Test;

import javax.annotation.Resource;
import java.util.Collection;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
/**
 * nbwald - May 22, 2009 11:25:59 AM
 */
public class ProteinNameDao_DUT
   extends LexiconDataUnitTestCase
{
   @Resource
   private ProteinNameDao proteinNameDao;

   @Test
 public void testFindByPubkeys_NoResults()
      throws Exception
   {
      Collection<ProteinName> proteinNames = proteinNameDao.findByPubkeys("this pubkey is not found", "nor is this one");

      assertThat(proteinNames.isEmpty(), is(true));
   }

   @Test
 public void testFindByPubkeys_NoPubkeys_NoResults()
      throws Exception
   {
      Collection<ProteinName> proteinNames = proteinNameDao.findByPubkeys();

      assertThat(proteinNames.isEmpty(), is(true));
   }

   @Test
 public void testFindByPubkeys_MultipleResults()
      throws Exception
   {
      ProteinName proteinNameA = new ProteinNameBuilder().create();
      ProteinName proteinNameB = new ProteinNameBuilder().create();

      Collection<ProteinName> proteinNames = proteinNameDao.findByPubkeys(proteinNameA.getProteinNamePubkey(), proteinNameB.getProteinNamePubkey());

      assertThat(proteinNames.size(), is(2));
      assertThat(hasProteinName(proteinNames, proteinNameA), is(true));
      assertThat(hasProteinName(proteinNames, proteinNameB), is(true));
   }

   private boolean hasProteinName(Collection<ProteinName> proteinNames, ProteinName targetProteinName) {
      for (ProteinName proteinName : proteinNames) {
         if (targetProteinName.getProteinNameId() == proteinName.getProteinNameId() &&
            targetProteinName.getProteinNamePubkey().equals(proteinName.getProteinNamePubkey()) &&
            targetProteinName.getProteinName().equals(proteinName.getProteinName()) &&
            targetProteinName.getProteinDescription().equals(proteinName.getProteinDescription()) &&
            targetProteinName.getOrigSourceOrganism().equals(proteinName.getOrigSourceOrganism()) &&
            targetProteinName.isActiveStatus() == proteinName.isActiveStatus()) {
            return true;
         }
      }
      return false;
   }
}
