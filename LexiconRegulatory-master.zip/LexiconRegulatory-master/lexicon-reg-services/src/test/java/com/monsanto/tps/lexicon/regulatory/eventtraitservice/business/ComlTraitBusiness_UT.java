/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.eventtraitservice.business;

import com.monsanto.tps.lexicon.eventtraitservice.transfer.GermplasmEventTrait;
import com.monsanto.tps.lexicon.eventtraitservice.transfer.GermplasmEventTraitResponse;
import com.monsanto.tps.lexicon.eventtraitservice.transfer.TraitStack;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitStack;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Crop;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.LexiconProductStageEntity;
import com.monsanto.tps.lexicon.regulatory.eventtraitservice.dao.ProductStageDao;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Arrays;

import static junit.framework.Assert.*;
import static org.mockito.Mockito.*;

/* vvkalu - 7/27/11 */
@RunWith(value = MockitoJUnitRunner.class)
public class ComlTraitBusiness_UT {


    private static final Long GERMPLASM_ID = 458L;
    @Mock
    private ProductStageDao productStageDao;
    @Mock
    private ComlTraitStackBuilder comlTraitStackBuilder;
    @InjectMocks
    private ComlTraitBusiness comlTraitBusiness = new ComlTraitBusiness();

    @Test
    public void test_No_Matching_ProductStageForGermplasm() throws Exception {
        when(productStageDao.getFirstProductStageByGermplasmId(GERMPLASM_ID)).thenReturn(null);
        GermplasmEventTraitResponse eventTraitResponse = new GermplasmEventTraitResponse();
        GermplasmEventTraitResponse comlTraitForProduct = comlTraitBusiness.getComlTraitForProduct(GERMPLASM_ID, eventTraitResponse);
        assertNotNull(comlTraitForProduct);
        assertTrue(comlTraitForProduct.getGermplasmEventTraits().isEmpty());
        verifyZeroInteractions(comlTraitStackBuilder);
    }

    @Test
    public void test_CommercialTraitStack_Null() throws Exception {
        when(productStageDao.getFirstProductStageByGermplasmId(eq(GERMPLASM_ID))).thenReturn(new LexiconProductStageEntity());
        GermplasmEventTraitResponse eventTraitResponse = new GermplasmEventTraitResponse();
        GermplasmEventTraitResponse comlTraitForProduct = comlTraitBusiness.getComlTraitForProduct(GERMPLASM_ID, eventTraitResponse);
        assertNotNull(comlTraitForProduct);
        assertTrue(comlTraitForProduct.getGermplasmEventTraits().isEmpty());
        verifyZeroInteractions(comlTraitStackBuilder);
    }

    @Test
    public void test_With_TraitStack() throws Exception {
        LexiconProductStageEntity productStageEntity = new LexiconProductStageEntity();
        ComlTraitStack comlTraitStack = new ComlTraitStack();
        comlTraitStack.setCrop(new Crop());
        comlTraitStack.setComlTraitStackId(67);
        productStageEntity.setComlTraitStack(comlTraitStack);
        when(productStageDao.getFirstProductStageByGermplasmId(GERMPLASM_ID)).thenReturn(productStageEntity);
        GermplasmEventTraitResponse traitEventConstructs = new GermplasmEventTraitResponse();
        GermplasmEventTrait germplasmEventTrait = new GermplasmEventTrait();
        germplasmEventTrait.setGermplasmId(GERMPLASM_ID);
        TraitStack traitStack = new TraitStack();
        traitStack.setComlTraitStackId(67);
        germplasmEventTrait.setTraitStack(traitStack);
        traitEventConstructs.setGermplasmEventTraits(Arrays.asList(germplasmEventTrait));
        when(comlTraitStackBuilder.buildComlTraitStack(GERMPLASM_ID, 67, comlTraitStack, traitEventConstructs)).thenReturn(traitEventConstructs);
        GermplasmEventTraitResponse comlTraitForProduct = comlTraitBusiness.getComlTraitForProduct(GERMPLASM_ID, traitEventConstructs);
        assertNotNull(comlTraitForProduct);
        assertEquals(1, comlTraitForProduct.getGermplasmEventTraits().size());
        assertNotNull(comlTraitForProduct.getGermplasmEventTraits().get(0));
        assertEquals(67, comlTraitForProduct.getGermplasmEventTraits().get(0).getTraitStack().getComlTraitStackId());
    }
}