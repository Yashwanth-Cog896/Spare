package com.monsanto.tps.lexicon.regulatory.event.query;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.lexiconcommon.db.test.MidasTestTools;
import com.monsanto.tps.lexicon.regulatory.DB.Midas.Tests.MidasDataTestCase;
import com.monsanto.tps.lexicon.regulatory.DB.TestUtil.TPSTestConstants;
import com.monsanto.tps.lexicon.regulatory.DB.midas.MidasBoolean;
import com.monsanto.tps.lexicon.regulatory.TPS.LineType.LineTypeRef;
import com.monsanto.tps.lexicon.regulatory.event.model.RegulatoryEventConstructTransformation;

import java.util.Random;

/**
 * rrchak1 - Jul 10, 2009 3:45:33 PM
 */
public class MidasEventConstructsByStackedEventGermplasmAndCropQuery_DUT
        extends MidasDataTestCase {

    private final String eventOne = "TEST_EV1";
    private final String eventTwo = "TEST_EV2";
    private final String cropGenusSpecies = "ZM";


    public void testFind_NoResults()
            throws Exception {
        long germplasmId = -new Random().nextLong();
        MidasEventConstructsByStackedEventGermplasmAndCropQuery query =
                new MidasEventConstructsByStackedEventGermplasmAndCropQuery(germplasmId, cropGenusSpecies);
        RegulatoryEventConstructTransformation[] eventConstructs = query.find();

        assertNotNull(eventConstructs);
        assertEquals(0, eventConstructs.length);
    }


    public void testFind_EventsBelongSameGermplasm_ReturnsEventConstructs()
            throws Exception {
        long germplasmId = -new Random().nextLong();
        MidasTestTools.insertFakeGermplasm(getMidasConn(), germplasmId, "pedigree", LineTypeRef.HYBRID, "transformationGT", TPSTestConstants.MIDAS_CORN_ID, false, true, false);
        long eventOneEventConstructId = insertEvent(eventOne, TPSTestConstants.MIDAS_CORN_ID, "pMON_ABC");
        long eventTwoEventconstructId = insertEvent(eventTwo, TPSTestConstants.MIDAS_CORN_ID, "pMON_DEF");
        MidasTestTools.insertFakeGermplasmEventConstruct(getMidasConn(), -new Random().nextLong(), eventOneEventConstructId, germplasmId);
        MidasTestTools.insertFakeGermplasmEventConstruct(getMidasConn(), -new Random().nextLong(), eventTwoEventconstructId, germplasmId);

        MidasEventConstructsByStackedEventGermplasmAndCropQuery query =
                new MidasEventConstructsByStackedEventGermplasmAndCropQuery(germplasmId, cropGenusSpecies);
        RegulatoryEventConstructTransformation[] eventConstructs = query.find();

        assertNotNull(eventConstructs);
        assertEquals(2, eventConstructs.length);
        assertTrue(contains(eventConstructs, eventOne, "pMON_ABC", null));
        assertTrue(contains(eventConstructs, eventTwo, "pMON_DEF", null));
    }


    public void testFind_EventDoesNotBelongtoGermplasm_DoesNotReturnEventConstructs()
            throws Exception {
        long germplasmIdOne = -new Random().nextLong();
        long germPlasmIdTwo = -new Random().nextLong();
        MidasTestTools.insertFakeGermplasm(getMidasConn(), germplasmIdOne, "pedigree", LineTypeRef.HYBRID, "transformationGT", TPSTestConstants.MIDAS_CORN_ID, false, true, false);
        MidasTestTools.insertFakeGermplasm(getMidasConn(), germPlasmIdTwo, "pedigree", LineTypeRef.HYBRID, "transformationGT", TPSTestConstants.MIDAS_CORN_ID, false, true, false);
        long eventOneEventConstructId = insertEvent(eventOne, TPSTestConstants.MIDAS_CORN_ID, "pMON_ABC");
        long eventTwoEventconstructId = insertEvent(eventTwo, TPSTestConstants.MIDAS_CORN_ID, "pMON_DEF");
        MidasTestTools.insertFakeGermplasmEventConstruct(getMidasConn(), -new Random().nextLong(), eventOneEventConstructId, germPlasmIdTwo);
        MidasTestTools.insertFakeGermplasmEventConstruct(getMidasConn(), -new Random().nextLong(), eventTwoEventconstructId, germPlasmIdTwo);

        MidasEventConstructsByStackedEventGermplasmAndCropQuery query =
                new MidasEventConstructsByStackedEventGermplasmAndCropQuery(germplasmIdOne, cropGenusSpecies);
        RegulatoryEventConstructTransformation[] eventConstructs = query.find();

        assertNotNull(eventConstructs);
        assertEquals(0, eventConstructs.length);
    }

    private boolean contains(RegulatoryEventConstructTransformation[] eventConstructs, String eventName, String construct, String transformationBackground) {
        for (RegulatoryEventConstructTransformation eventConstruct : eventConstructs) {
            if (StringUtils.areEqual(eventName, eventConstruct.getEvent())
                    && StringUtils.areEqual(construct, eventConstruct.getConstruct())
                    && StringUtils.areEqual(transformationBackground, eventConstruct.getTransformationBackground())) {
                return true;
            }
        }
        return false;
    }

    private long insertEvent(String eventName, long midasCropId, String construct)
            throws WrappingException {
        return insertEvent(eventName, midasCropId, construct, true);
    }

    private long insertEvent(String eventName, long midasCropId, String construct, boolean refActive)
            throws WrappingException {
        long eventConstructId = -new Random().nextLong();
        MidasTestTools.insertFakeEventConstruct(getMidasConn(), eventConstructId, eventName, construct, midasCropId, new MidasBoolean(refActive).getDatabaseRepresentation());
        return eventConstructId;
    }
}
