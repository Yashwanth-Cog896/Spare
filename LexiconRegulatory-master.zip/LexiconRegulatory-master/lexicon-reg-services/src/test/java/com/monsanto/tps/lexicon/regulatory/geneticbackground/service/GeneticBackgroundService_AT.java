package com.monsanto.tps.lexicon.regulatory.geneticbackground.service;

import com.monsanto.tps.lexicon.geneticbackground.GeneticBackgroundService;
import com.monsanto.tps.lexicon.geneticbackground.OrionGeneticBackground;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/2/12
 * Time: 7:40 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:/com/monsanto/tps/lexicon/regulatory/contexts/lexicon-test-service-at-context.xml"})
@Transactional
public class GeneticBackgroundService_AT {

    @Resource
    GeneticBackgroundService geneticBackgroundServiceImpl;

    @Test
    public void findGeneticBackground_results_wildcard() throws Exception {
        final List<OrionGeneticBackground> GeneticBackgrounds = geneticBackgroundServiceImpl.findGeneticBackgrounds("Alf*");
        assertNotNull(GeneticBackgrounds);
        assertFalse(GeneticBackgrounds.isEmpty());
    }

    @Test
    public void findGeneticBackground_results_exactMatch() throws Exception {
        final List<OrionGeneticBackground> GeneticBackgrounds = geneticBackgroundServiceImpl.findGeneticBackgrounds("Amidon");
        assertNotNull(GeneticBackgrounds);
        assertFalse(GeneticBackgrounds.isEmpty());
    }

    @Test
    public void findGeneticBackground_noResults() throws Exception {
        final List<OrionGeneticBackground> GeneticBackgrounds = geneticBackgroundServiceImpl.findGeneticBackgrounds("asdf");
        assertNotNull(GeneticBackgrounds);
        assertTrue(GeneticBackgrounds.isEmpty());
    }
}
