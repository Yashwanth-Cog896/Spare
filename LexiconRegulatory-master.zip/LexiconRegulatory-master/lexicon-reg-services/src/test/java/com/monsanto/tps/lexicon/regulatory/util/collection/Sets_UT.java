package com.monsanto.tps.lexicon.regulatory.util.collection;

import junit.framework.TestCase;

import java.util.Set;

/**
 * nbwald - Sep 4, 2008 2:13:34 PM
 */
public class Sets_UT
   extends TestCase
{
   public void testAsSet()
      throws Exception
   {
      Set<String> set = Sets.asSet("A", "B", "C", "A");

      assertEquals(3, set.size());
      assertTrue(set.contains("A"));
      assertTrue(set.contains("B"));
      assertTrue(set.contains("C"));
   }

   public void testAsSet_Empty()
      throws Exception
   {
      Set<String> set = Sets.asSet();

      assertTrue(set.isEmpty());
   }
}
