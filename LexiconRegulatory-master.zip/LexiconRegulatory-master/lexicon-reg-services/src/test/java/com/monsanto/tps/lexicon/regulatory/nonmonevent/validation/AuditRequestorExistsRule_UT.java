package com.monsanto.tps.lexicon.regulatory.nonmonevent.validation;

import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import org.junit.Test;

/**
 * nbwald - May 21, 2009 5:44:34 PM
 */
public class AuditRequestorExistsRule_UT
{
   @Test
   public void testViolated_False()
      throws Exception
   {
      String auditRequestor = "NEUMANN, THOMAS E";
      Rule<String> rule = new AuditRequestorExistsRule(auditRequestor);

      assertThat(rule.violated(), is(false));
   }

   @Test
   public void testViolated_Null_True()
      throws Exception
   {
      String auditRequestor = null;
      Rule<String> rule = new AuditRequestorExistsRule(auditRequestor);

      assertThat(rule.violated(), is(true));
   }

   @Test
   public void testViolated_Empty_True()
      throws Exception
   {
      String auditRequestor = "";
      Rule<String> rule = new AuditRequestorExistsRule(auditRequestor);

      assertThat(rule.violated(), is(true));
   }

   @Test
   public void testGetViolation()
      throws Exception
   {
      assertThat(new AuditRequestorExistsRule(null).getViolation(), is("Audit requestor is required."));
   }

}