package com.monsanto.tps.lexicon.regulatory.nonmonevent.validation;

import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collection;

/**
 * nbwald - May 21, 2009 5:26:24 PM
 */
public class HasRegulatoryTraitOptionRule_UT
{
   @Test
   public void testViolated_HasName_HasType_NotViolated()
      throws Exception
   {
      Collection<ComlTraitName> traitNames = Arrays.asList(new ComlTraitName());
      Collection<ComlTraitType> traitTypes = Arrays.asList(new ComlTraitType());
      Rule<String> rule = new HasRegulatoryTraitOptionRule(traitNames, traitTypes);

      assertThat(rule.violated(), is(false));
   }

   @Test
   public void testViolated_HasName_DoesNotHaveType_NotViolated()
      throws Exception
   {
      Collection<ComlTraitName> traitNames = Arrays.asList(new ComlTraitName());
      Collection<ComlTraitType> traitTypes = Arrays.asList();
      Rule<String> rule = new HasRegulatoryTraitOptionRule(traitNames, traitTypes);

      assertThat(rule.violated(), is(false));
   }

   @Test
   public void testViolated_DoesNotHaveName_HasType_NotViolated()
      throws Exception
   {
      Collection<ComlTraitName> traitNames = Arrays.asList();
      Collection<ComlTraitType> traitTypes = Arrays.asList(new ComlTraitType());
      Rule<String> rule = new HasRegulatoryTraitOptionRule(traitNames, traitTypes);

      assertThat(rule.violated(), is(false));
   }

   @Test
   public void testViolated_DoesNotHaveName_DoesNotHaveType_Violated()
      throws Exception
   {
      Collection<ComlTraitName> traitNames = Arrays.asList();
      Collection<ComlTraitType> traitTypes = Arrays.asList();
      Rule<String> rule = new HasRegulatoryTraitOptionRule(traitNames, traitTypes);

      assertThat(rule.violated(), is(true));
   }

   @Test
   public void testGetViolation()
      throws Exception
   {
      Rule<String> rule = new HasRegulatoryTraitOptionRule(null, null);

      assertThat(rule.getViolation(), is("At least one regulatory trait description is required."));
   }
}
