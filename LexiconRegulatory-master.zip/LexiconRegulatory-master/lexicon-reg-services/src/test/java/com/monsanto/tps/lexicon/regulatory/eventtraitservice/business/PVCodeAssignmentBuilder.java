package com.monsanto.tps.lexicon.regulatory.eventtraitservice.business;

import com.monsanto.tps.compliance.referencedata.molecularinfo.PvCode;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: ATHANGA
 * Date: 9/29/11
 * Time: 10:05 AM
 */
public class PVCodeAssignmentBuilder {

    public static List<PvCode> formPVCodes(List<String> pvCodeStringList){
        if (pvCodeStringList == null){
            return null;
        }
        List<PvCode> pvCodeList = new ArrayList<PvCode>();
        for (String pvCodeString : pvCodeStringList) {
            pvCodeList.add(new PvCode(pvCodeString, null, null, null));
        }
        return pvCodeList;
    }
}
