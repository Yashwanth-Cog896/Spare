package com.monsanto.tps.lexicon.regulatory.event.query;

import com.monsanto.Util.StringUtils;
import com.monsanto.tps.lexicon.regulatory.DB.Midas.Tests.MidasDataTestCase;
import com.monsanto.tps.lexicon.regulatory.event.model.RegulatoryEventConstructTransformation;

/**
 * rrchak1 - Jul 15, 2009 4:50:54 PM
 */
public class EventConstructTransformationsByStackedEventAndCropQuery_DUT
        extends MidasDataTestCase {
    private static final String eventOne = "101-5-1";
    private static final String eventTwo = "ZM_M2598";
    private static final String stackedEvent = "101-5-1,ZM_M2598";
    private static final String stackedEventMixedCase = "101-5-1,zM_m2598";
    private static final String cropGenusSpecies = "ZM";
    private static final String threeStackEvent = "D59122-7,HAM027,MON88017";
    private static final String fourStackEvent = "D59122-7,HAM027,MON88017,ZM_M38835";
    private static final String fourStackEventEvent1 = "D59122-7";
    private static final String fourStackEventEvent2 = "HAM027";
    private static final String fourStackEventEvent3 = "MON88017";
    private static final String fourStackEventEvent4 = "ZM_M38835";
    private static final String partialStack = "D59122-7,HAM027";
    private static final String P_MON36190 = "pMON36190";
    private static final String P_HP17662 = "pHP17662";
    private static final String P_MON58401 = "pMON58401";
    private static final String P_MON53616 = "pMON53616";
    private static final String P_MON73608 = "pMON73608";
    public static String EVENT_ONLY_ONE_BELONGS_TO_GERMPLASM = "101-5-1,MON88017";


    public void testFind_NoResults()
            throws Exception {
        EventConstructTransformationsByStackedEventAndCropQuery query =
                new EventConstructTransformationsByStackedEventAndCropQuery();
        RegulatoryEventConstructTransformation[] eventConstructs = query.find(stackedEvent, "MZ");

        assertNotNull(eventConstructs);
        assertEquals(0, eventConstructs.length);
    }


    public void testFind_EventsBelongToSameGermplasmAndGermplasmHasOnlyTheseEvents_ReturnsEventConstructs()
            throws Exception {
        EventConstructTransformationsByStackedEventAndCropQuery query =
                new EventConstructTransformationsByStackedEventAndCropQuery();
        RegulatoryEventConstructTransformation[] eventConstructs = query.find(stackedEvent, cropGenusSpecies);

        assertNotNull(eventConstructs);
        assertEquals(2, eventConstructs.length);
        assertTrue(contains(eventConstructs, eventOne, P_MON36190, null));
        assertTrue(contains(eventConstructs, eventTwo, P_MON36190, null));
    }


    public void testFind_EventsBelongToSameGermplasmAndGermplasmHasOnlyTheseEvents_ReturnsEventConstructs_ForMixedCaseSearch()
            throws Exception {
        EventConstructTransformationsByStackedEventAndCropQuery query =
                new EventConstructTransformationsByStackedEventAndCropQuery();
        RegulatoryEventConstructTransformation[] eventConstructs = query.find(stackedEventMixedCase, cropGenusSpecies);

        assertNotNull(eventConstructs);
        assertEquals(2, eventConstructs.length);
        assertTrue(contains(eventConstructs, eventOne, P_MON36190, null));
        assertTrue(contains(eventConstructs, eventTwo, P_MON36190, null));
    }


    public void testFind_EventsBelongToSameGermplasmAndGermplasmHasMoreThanTheseEvents_DoesNotReturnEventConstructs()
            throws Exception {


        EventConstructTransformationsByStackedEventAndCropQuery query =
                new EventConstructTransformationsByStackedEventAndCropQuery();
        RegulatoryEventConstructTransformation[] eventConstructs = query.find(partialStack, cropGenusSpecies);

        assertNotNull(eventConstructs);
        assertEquals(0, eventConstructs.length);
    }


    public void testFind_OnlyOneEventBelongstoGermplasm_DoesNotReturnEventConstructs()
            throws Exception {
        EventConstructTransformationsByStackedEventAndCropQuery query =
                new EventConstructTransformationsByStackedEventAndCropQuery();

        RegulatoryEventConstructTransformation[] eventConstructs = query.find(EVENT_ONLY_ONE_BELONGS_TO_GERMPLASM, cropGenusSpecies);

        assertNotNull(eventConstructs);
        assertEquals(0, eventConstructs.length);
    }


    public void testFind_EventStackBelongToMoreThanOneGermplasmAndGermplasmHasOnlyTheseEvents_ReturnsEventConstructs()
            throws Exception {
        EventConstructTransformationsByStackedEventAndCropQuery query =
                new EventConstructTransformationsByStackedEventAndCropQuery();
        RegulatoryEventConstructTransformation[] eventConstructs = query.find(fourStackEvent, cropGenusSpecies);
        assertNotNull(eventConstructs);
        assertEquals(4, eventConstructs.length);
        assertTrue(contains(eventConstructs, fourStackEventEvent1, P_HP17662, null));
        assertTrue(contains(eventConstructs, fourStackEventEvent2, P_MON58401, null));
        assertTrue(contains(eventConstructs, fourStackEventEvent3, P_MON53616, null));
        assertTrue(contains(eventConstructs, fourStackEventEvent4, P_MON73608, null));

        query =
                new EventConstructTransformationsByStackedEventAndCropQuery();
        eventConstructs = query.find(threeStackEvent, cropGenusSpecies);

        assertNotNull(eventConstructs);
        assertEquals(3, eventConstructs.length);
        assertTrue(contains(eventConstructs, fourStackEventEvent1, P_HP17662, null));
        assertTrue(contains(eventConstructs, fourStackEventEvent2, P_MON58401, null));
        assertTrue(contains(eventConstructs, fourStackEventEvent3, P_MON53616, null));
    }

    private boolean contains(RegulatoryEventConstructTransformation[] eventConstructs, String eventName, String construct, String transformationBackground) {
        for (RegulatoryEventConstructTransformation eventConstruct : eventConstructs) {
            if (StringUtils.areEqual(eventName, eventConstruct.getEvent())
                    && StringUtils.areEqual(construct, eventConstruct.getConstruct())
                    && StringUtils.areEqual(transformationBackground, eventConstruct.getTransformationBackground())) {
                return true;
            }
        }
        return false;
    }
}
