package com.monsanto.tps.lexicon.regulatory.storagecondition.business;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.StorageCondition;
import com.monsanto.tps.lexicon.regulatory.storagecondition.business.StorageConditionBusiness;
import com.monsanto.tps.lexicon.regulatory.storagecondition.dao.StorageConditionDAO;
import com.monsanto.tps.lexicon.storagecondition.OrionStorageCondition;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/1/12
 * Time: 7:47 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class StorageConditionBusiness_UT {

    @Mock
    private StorageConditionDAO storageConditionDAO;

    @InjectMocks
    private StorageConditionBusiness storageConditionBusiness = new StorageConditionBusiness();

    private final List<StorageCondition> singleStorageConditionListFromDAO;
    private final List<StorageCondition> multiStorageConditionListFromDAO;
    private static final List<StorageCondition> emptyListFromDAO = new ArrayList<StorageCondition>();

    private final List<OrionStorageCondition> singleStorageConditionListFromBusiness;
    private final List<OrionStorageCondition> multiStorageConditionListFromBusiness;
    private static final List<OrionStorageCondition> emptyListFromBusiness = new ArrayList<OrionStorageCondition>();

    public StorageConditionBusiness_UT() {
        singleStorageConditionListFromDAO = new ArrayList<StorageCondition>();
        singleStorageConditionListFromDAO.add(new StorageCondition("type", true));

        multiStorageConditionListFromDAO = new ArrayList<StorageCondition>();
        multiStorageConditionListFromDAO.add(new StorageCondition("type1", true));
        multiStorageConditionListFromDAO.add(new StorageCondition("type2", false));

        singleStorageConditionListFromBusiness = new ArrayList<OrionStorageCondition>();
        singleStorageConditionListFromBusiness.add(new OrionStorageCondition("type", true));

        multiStorageConditionListFromBusiness = new ArrayList<OrionStorageCondition>();
        multiStorageConditionListFromBusiness.add(new OrionStorageCondition("type1", true));
        multiStorageConditionListFromBusiness.add(new OrionStorageCondition("type2", false));
    }

    @Test
    public void findStorageCondition_findNone() throws Exception {

        when(storageConditionDAO.findStorageConditions("asdf")).thenReturn(emptyListFromDAO);

        final List<OrionStorageCondition> actualStorageConditions = storageConditionBusiness.findStorageConditions("asdf");

        checkStorageConditionLists(actualStorageConditions, emptyListFromBusiness);
    }

    @Test
    public void findStorageCondition_findSingle() throws Exception {

        when(storageConditionDAO.findStorageConditions("Cool on Ice")).thenReturn(singleStorageConditionListFromDAO);

        final List<OrionStorageCondition> actualStorageConditions = storageConditionBusiness.findStorageConditions("Cool on Ice");

        checkStorageConditionLists(actualStorageConditions, singleStorageConditionListFromBusiness);
    }

    @Test
    public void findStorageCondition_findByWildcard() throws Exception {

        when(storageConditionDAO.findStorageConditions("F%")).thenReturn(multiStorageConditionListFromDAO);

        final List<OrionStorageCondition> actualStorageConditions = storageConditionBusiness.findStorageConditions("F*");

        checkStorageConditionLists(actualStorageConditions, multiStorageConditionListFromBusiness);
    }

    @Test
    public void findStorageCondition_findAll() throws Exception {

        when(storageConditionDAO.findStorageConditions("%")).thenReturn(multiStorageConditionListFromDAO);

        final List<OrionStorageCondition> actualStorageConditions = storageConditionBusiness.findStorageConditions("");

        checkStorageConditionLists(actualStorageConditions, multiStorageConditionListFromBusiness);
    }

    private void checkStorageConditionLists(final List<OrionStorageCondition> actualStorageConditions, final List<OrionStorageCondition> singleStorageConditionListFromBusiness) {
        assertNotNull(actualStorageConditions);

        for(int i=0; i<singleStorageConditionListFromBusiness.size(); i++) {
            final OrionStorageCondition storageCondition = actualStorageConditions.get(i);
            assertEquals(storageCondition.getStorageCondition(), singleStorageConditionListFromBusiness.get(i).getStorageCondition());
            assertEquals(storageCondition.getActiveStatus(), singleStorageConditionListFromBusiness.get(i).getActiveStatus());
        }
    }
}
