package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.DataFilter;
import org.hibernate.Session;

/**
 * Created by IntelliJ IDEA.
 * User: gdleon
 * Date: Apr 21, 2009
 * Time: 2:17:12 PM
 */
public class ComlTraitTypeBuilder
{
   private ComlTraitType comlTraitType;

   public ComlTraitTypeBuilder() {
      BuilderID builderID = new BuilderID();
      comlTraitType = new ComlTraitType();
      comlTraitType.setComlTraitTypeId(builderID.id());
      comlTraitType.setComlTraitTypeAbbr(builderID.sid(8));
      comlTraitType.setComlTraitTypeDesc(builderID.sid(50));
   }

   public ComlTraitTypeBuilder withTraitTypeAbbr(String traitTypeAbbr) {
      this.comlTraitType.setComlTraitTypeAbbr(traitTypeAbbr);
      return this;
   }

   public ComlTraitTypeBuilder withTraitTypeDesc(String traitTypeDesc) {
      this.comlTraitType.setComlTraitTypeDesc(traitTypeDesc);
      return this;
   }

   public ComlTraitType createObj() {
      return comlTraitType;
   }

   public ComlTraitType create() {
      Session session = TestSessions.getLexiconSession();
      session.save(comlTraitType);
      return comlTraitType;
   }

   public ComlTraitTypeBuilder withDataFilter(DataFilter dataFilter) {
      this.comlTraitType.getDataFilters().add(dataFilter);
      return this;
   }
}
