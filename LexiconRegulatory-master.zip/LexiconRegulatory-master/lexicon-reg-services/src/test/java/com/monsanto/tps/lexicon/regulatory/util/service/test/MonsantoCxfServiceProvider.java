package com.monsanto.tps.lexicon.regulatory.util.service.test;

import com.monsanto.tcc.lexiconcommon.exception.RuntimeWrappingException;
import com.monsanto.tps.ws.client.WsClientProxyFactoryBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * nbwald - May 20, 2009 1:49:21 PM
 */
public class MonsantoCxfServiceProvider
{
   public static <T> T getService(String serviceName, Class<T> serviceClass) {
      WsClientProxyFactoryBean factoryBean = new WsClientProxyFactoryBean();
      factoryBean.setApplicationContext(getMonsantoCxfContext());
      factoryBean.setServiceName(serviceName);
      factoryBean.setServiceClass(serviceClass);
      try {
         return (T) factoryBean.getObject();
      }
      catch (Exception e) {
         throw new RuntimeWrappingException(e);
      }
   }

   public <T> T buildService(String serviceName, Class<T> serviceClass) {
      return MonsantoCxfServiceProvider.getService(serviceName, serviceClass);
   }

   private static ApplicationContext getMonsantoCxfContext() {
      String monsantoCxfConfigLocation = "classpath:/com/monsanto/tps/ws/client/ws-client-context.xml";
      return new ClassPathXmlApplicationContext(monsantoCxfConfigLocation);
   }
}
