package com.monsanto.tps.lexicon.regulatory.container.service;

import com.monsanto.tps.lexicon.container.ContainerService;
import com.monsanto.tps.lexicon.container.OrionContainer;
import com.monsanto.tps.lexicon.monnumber.MonNumber;
import com.monsanto.tps.lexicon.monnumber.MonNumberService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.junit.Assert.*;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/2/12
 * Time: 7:40 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:/com/monsanto/tps/lexicon/regulatory/contexts/lexicon-test-service-at-context.xml"})
@Transactional
public class ContainerService_AT {

    @Autowired
    ContainerService containerService;

    @Test
    public void findContainerTypes_results_wildcard() throws Exception {
        final List<OrionContainer> containers = containerService.findContainerTypes("Glass*");
        assertNotNull(containers);
        assertFalse(containers.isEmpty());
    }

    @Test
    public void findContainerTypes_results_exactMatch() throws Exception {
        final List<OrionContainer> containers = containerService.findContainerTypes("Jar");
        assertNotNull(containers);
        assertFalse(containers.isEmpty());
    }

    @Test
    public void findContainerTypes_noResults() throws Exception {
        final List<OrionContainer> containers = containerService.findContainerTypes("asdf");
        assertNotNull(containers);
        assertTrue(containers.isEmpty());
    }
}
