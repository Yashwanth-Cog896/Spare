package com.monsanto.tps.lexicon.regulatory.DB.Midas.Tests;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.tcc.lexiconcommon.db.monitor.MonitoredConnectionFactory;
import com.monsanto.tcc.lexiconcommon.db.test.DataUTTestCase;
import com.monsanto.tps.lexicon.regulatory.DB.factories.midas.MidasConnectionFactoryProperties;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Sep 13, 2006
 * Time: 3:23:49 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class MidasDataTestCase
        extends DataUTTestCase {
    protected PersistentStoreConnection getMidasConn()
            throws WrappingException {
        MonitoredConnectionFactory factory = new MonitoredConnectionFactory(new MidasConnectionFactoryProperties());
        return factory.getConnection();
    }
}