package com.monsanto.tps.lexicon.regulatory.geneticbackground.service;

import com.monsanto.tps.lexicon.geneticbackground.GeneticBackgroundService;
import com.monsanto.tps.lexicon.geneticbackground.OrionGeneticBackground;
import com.monsanto.tps.lexicon.regulatory.geneticbackground.business.GeneticBackgroundBusiness;
import com.monsanto.tps.lexicon.regulatory.geneticbackground.service.GeneticBackgroundServiceImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/1/12
 * Time: 7:47 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class GeneticBackgroundServiceImpl_UT {

    @Mock
    private GeneticBackgroundBusiness geneticBackgroundBusiness;

    @InjectMocks
    private GeneticBackgroundService geneticBackgroundService = new GeneticBackgroundServiceImpl();

    private static final List<OrionGeneticBackground> geneticBackgroundList = new ArrayList<OrionGeneticBackground>();

    @Test
    public void findGeneticBackground_success() throws Exception {
        when(geneticBackgroundBusiness.findGeneticBackgrounds("Jar")).thenReturn(geneticBackgroundList);

        final List<OrionGeneticBackground> actualGeneticBackgrounds = geneticBackgroundBusiness.findGeneticBackgrounds("Jar");

        assertEquals(actualGeneticBackgrounds, geneticBackgroundList);
    }
}
