package com.monsanto.tps.lexicon.regulatory.sample.service;

import com.monsanto.tps.lexicon.sample.SampleService;
import com.monsanto.tps.lexicon.sample.OrionSample;
import com.monsanto.tps.lexicon.regulatory.sample.business.SampleBusiness;
import com.monsanto.tps.lexicon.regulatory.sample.service.SampleServiceImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/1/12
 * Time: 7:47 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class SampleServiceImpl_UT {

    @Mock
    private SampleBusiness sampleBusiness;

    @InjectMocks
    private SampleService sampleService = new SampleServiceImpl();

    private static final List<OrionSample> sampleList = new ArrayList<OrionSample>();

    @Test
    public void findSampleTypes_success() throws Exception {
        when(sampleBusiness.findSampleTypes("Bloom")).thenReturn(sampleList);

        final List<OrionSample> actualSamples = sampleBusiness.findSampleTypes("Bloom");

        assertEquals(actualSamples, sampleList);
    }
}
