package com.monsanto.tps.lexicon.regulatory.storagelocation.business;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.StorageLocation;
import com.monsanto.tps.lexicon.storagelocation.OrionStorageLocation;
import org.junit.Test;

import java.util.Collections;
import java.util.List;

import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: MMR
 * Date: 2/23/12
 * Time: 3:05 PM
 */
public class OrionStorageLocationBuilder_UT {

    @Test
    public void passingNullReturnsEmptyOrionStorageLocations() throws Exception {
        OrionStorageLocationBuilder builder = new OrionStorageLocationBuilder();
        assertTrue(builder.build(null).isEmpty());
    }

    @Test
    public void passingStorageLocationsListReturnsValidOrionStorageLocations() throws Exception {
        StorageLocation storageLocation = new StorageLocation();
        storageLocation.setStorageLocation("Stor Loc");
        storageLocation.setPhysicalLocation("Phys loc");
        storageLocation.setStorageCondition("store cond");
        storageLocation.setActiveStatus(true);
        storageLocation.setStorageLocationID(20120225l);
        OrionStorageLocationBuilder builder = new OrionStorageLocationBuilder();
        List<OrionStorageLocation> orionStorageLocations = builder.build(Collections.singletonList(storageLocation));

        assertFalse(orionStorageLocations.isEmpty());

        OrionStorageLocation orionStorageLocation = orionStorageLocations.get(0);

        assertEquals("Stor Loc", orionStorageLocation.getStorageLocation());
        assertEquals("Phys loc", orionStorageLocation.getPhysicalLocation());
        assertEquals("store cond", orionStorageLocation.getDefaultStorageCondition());
    }
}
