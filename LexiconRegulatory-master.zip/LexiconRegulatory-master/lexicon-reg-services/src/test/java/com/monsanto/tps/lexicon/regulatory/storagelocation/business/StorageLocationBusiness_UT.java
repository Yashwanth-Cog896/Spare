package com.monsanto.tps.lexicon.regulatory.storagelocation.business;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.StorageLocation;
import com.monsanto.tps.lexicon.regulatory.eventsreginfo.util.dao.lexicon.TempSessionOcdDao;
import com.monsanto.tps.lexicon.regulatory.storagelocation.dao.StorageLocationDAO;
import com.monsanto.tps.lexicon.storagelocation.OrionStorageLocation;
import org.junit.Before;
import org.junit.Test;

import java.util.Collections;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: MMR
 * Date: 2/22/12
 * Time: 3:08 PM
 */
public class StorageLocationBusiness_UT {

    StorageLocationBusiness business;
    StorageLocationDAO storageLocationDAO;
    TempSessionOcdDao tempSessionOcdDao;
    OrionStorageLocationBuilder builder;
    StorageLocation dbStorageLocation;

    @Before
    public void setup() {
        storageLocationDAO = mock(StorageLocationDAO.class);
        tempSessionOcdDao = mock(TempSessionOcdDao.class);
        builder = mock(OrionStorageLocationBuilder.class);
        business = new MockStorageLocationBusiness();
        business.setStorageLocationDAO(storageLocationDAO);
        business.setTempSessionOcdDao(tempSessionOcdDao);
        business.setBuilder(builder);
    }

    @Test
    public void findStorageLocationsByStorageLocationIsSuccessful() throws Exception {
        List<StorageLocation> expectedStorageLocations = Collections.singletonList(new StorageLocation());
        List<OrionStorageLocation> expectedResults = Collections.singletonList(new OrionStorageLocation());
        dbStorageLocation = new StorageLocation();
        dbStorageLocation.setStorageLocation("Storage Location");

        when(storageLocationDAO.findActiveStorageLocations(dbStorageLocation)).thenReturn(expectedStorageLocations);
        when(builder.build(expectedStorageLocations)).thenReturn(expectedResults);

        List<OrionStorageLocation> actualResults = business.findStorageLocations("Storage Location");

        assertThat(actualResults, is(expectedResults));
    }

    @Test
    public void findStorageLocationsByPhysicalLocationIsSuccessful() throws Exception {
        List<StorageLocation> expectedStorageLocations = Collections.singletonList(new StorageLocation());
        List<OrionStorageLocation> expectedResults = Collections.singletonList(new OrionStorageLocation());
        dbStorageLocation = new StorageLocation();
        dbStorageLocation.setPhysicalLocation("Physical Location");
        when(storageLocationDAO.findActiveStorageLocations(dbStorageLocation)).thenReturn(expectedStorageLocations);
        when(builder.build(expectedStorageLocations)).thenReturn(expectedResults);

        List<OrionStorageLocation> actualResults = business.findStorageLocationsByPhysicalLocation("Physical Location");

        assertThat(actualResults, is(expectedResults));
    }

    @Test
    public void findStorageLocationsByListIsSuccessful() throws Exception {
        List<StorageLocation> expectedStorageLocations = Collections.singletonList(new StorageLocation());
        List<OrionStorageLocation> expectedResults = Collections.singletonList(new OrionStorageLocation());
        when(storageLocationDAO.findStorageLocationsByList()).thenReturn(expectedStorageLocations);
        when(builder.build(expectedStorageLocations)).thenReturn(expectedResults);

        List<OrionStorageLocation> actualResults = business.findStorageLocationsByList(Collections.singletonList("Storage Location"));

        assertThat(actualResults, is(expectedResults));
    }

    @Test
    public void nullAsListReturnsEmptyList() throws Exception {
        List<OrionStorageLocation> actualResults = business.findStorageLocationsByList(null);
        assertThat(actualResults.size(), is(0));
    }

    private class MockStorageLocationBusiness extends StorageLocationBusiness {
        @Override
        protected StorageLocation createStorageLocation() {
            return dbStorageLocation;
        }

    }
}
