/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.chemicalname.business;

import com.monsanto.tps.lexicon.chemicalname.OrionChemicalName;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.AdditionalMaterial;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MaterialStructureInfo;
import com.monsanto.tps.lexicon.regulatory.additionalmaterialinfo.dao.AdditionalMaterialDAO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static junit.framework.Assert.assertEquals;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

/* NBWALD - 5/10/12 */
@RunWith(MockitoJUnitRunner.class)
public class OrionChemicalNameBusiness_UT {
    @Mock
    private ChemicalNameBusiness chemicalNameBusiness;
    @Mock
    private AdditionalMaterialDAO additionalMaterialDAO;

    @InjectMocks
    private OrionChemicalNameBusiness orionChemicalNameBusiness = new OrionChemicalNameBusiness();

    @Before
    public final void setUp()
            throws Exception {

        List<OrionChemicalName> chemicalNameResultList = new ArrayList<OrionChemicalName>();
        chemicalNameResultList.add(new OrionChemicalName("ai", true, null, null, null, null, null, null, null, "class", "nameA"));
        chemicalNameResultList.add(new OrionChemicalName("ai", true, null, null, null, null, null, null, null, "class", "nameA"));
        chemicalNameResultList.add(new OrionChemicalName("ai", true, null, null, null, null, null, null, null, "class", "This is a name longer than forty characters"));

        List<AdditionalMaterial> additionalMaterialResultListResultList = new ArrayList<AdditionalMaterial>();
        additionalMaterialResultListResultList.add(buildAdditionalMaterial("nameA", "aliasA", "casA", "iupacA", "cpA", true, null, null));
        additionalMaterialResultListResultList.add(buildAdditionalMaterial("nameB", "aliasB", "casB", "iupacB", "cpB", true, null, null));
        additionalMaterialResultListResultList.add(buildAdditionalMaterial("nameC", "aliasC", "casC", "iupacC", "cpC", true, null, null));
        additionalMaterialResultListResultList.add(buildAdditionalMaterial("nameD", "aliasD", "casD", "iupacD", "cpD", true, "weight", "formula"));

        List<OrionChemicalName> chemicalMaterialResultList = new ArrayList<OrionChemicalName>();
        chemicalMaterialResultList.add(new OrionChemicalName("ai", true, null, null, null, null, "fa1", "fa2", "fa3", "class", "nameB"));
        chemicalMaterialResultList.add(new OrionChemicalName("ai", true, null, null, null, null, "fa1", "fa2", "fa3", "class", "nameC"));
        chemicalMaterialResultList.add(new OrionChemicalName("ai", true, null, null, null, null, "fa1", "fa2", "fa3", "class", "nameD"));

        when(chemicalNameBusiness.findChemicalNames("*")).thenReturn(chemicalNameResultList);
        when(additionalMaterialDAO.findAdditionalMaterials("%")).thenReturn(additionalMaterialResultListResultList);
        when(chemicalNameBusiness.findChemicalMaterials("*")).thenReturn(chemicalMaterialResultList);
    }

    @Test
    public final void testChemicalNameService()
            throws Exception {
        List<OrionChemicalName> combinedResults = orionChemicalNameBusiness.findChemicalNames("*");

        List<OrionChemicalName> chemicalNameResults = chemicalNameBusiness.findChemicalNames("*");
        List<OrionChemicalName> lexiconCommercialResults = chemicalNameBusiness.findChemicalMaterials("*");
        //one name is too long and gets filtered out
        int expectedResultSize = chemicalNameResults.size() - 1 + lexiconCommercialResults.size();

        assertEquals("Expected different number of results", expectedResultSize, combinedResults.size());

        assertEquals("Results were not sorted correctly", "nameA", combinedResults.get(0).getMaterialName());
        assertEquals("Additional data was not inserted correctly", "aliasA", combinedResults.get(0).getAlias());
        assertEquals("Results were not sorted correctly", "nameA", combinedResults.get(1).getMaterialName());
        assertEquals("Additional data was not inserted correctly", "aliasA", combinedResults.get(1).getAlias());
        assertEquals("Results were not sorted correctly", "nameB", combinedResults.get(2).getMaterialName());
        assertEquals("Additional data was not inserted correctly", "aliasB", combinedResults.get(2).getAlias());
        assertEquals("Results were not sorted correctly", "nameC", combinedResults.get(3).getMaterialName());
        assertEquals("Additional data was not inserted correctly", "aliasC", combinedResults.get(3).getAlias());
        assertEquals("Results were not sorted correctly", "nameD", combinedResults.get(4).getMaterialName());
        assertEquals("Additional data was not inserted correctly", "aliasD", combinedResults.get(4).getAlias());
    }

    @Test
    public final void testMerge()
            throws Exception {
        List<OrionChemicalName> argotResults = orionChemicalNameBusiness.findChemicalNames("*");

        assertEquals("Additional data was not inserted correctly", "aliasD", (argotResults.get(4)).getAlias());
        assertEquals("Additional data was not inserted correctly", "formula", (argotResults.get(4)).getMolecularFormula());
        assertEquals("Additional data was not inserted correctly", "weight", (argotResults.get(4)).getMolecularWeight());
    }

    @Test
    public void testFindChemicalNames_AdditionalMaterialServiceReturnsNull()
            throws Exception {
        when(additionalMaterialDAO.findAdditionalMaterials("*")).thenReturn(null);

        List<OrionChemicalName> combinedResults = orionChemicalNameBusiness.findChemicalNames("*");

        assertThat(combinedResults.isEmpty(), is(false));
    }

    @Test
    public void testFindChemicalNames_ChemicalNameServiceReturnsNull()
            throws Exception {
        when(chemicalNameBusiness.findChemicalNames("*")).thenReturn(null);

        List<OrionChemicalName> combinedResults = orionChemicalNameBusiness.findChemicalNames("*");

        assertThat(combinedResults.isEmpty(), is(false));
    }

    private AdditionalMaterial buildAdditionalMaterial(String materialName, String alias, String chemicalNameCAS,
                                                       String chemicalNameIUPAC, String cpNumber, boolean activeStatus,
                                                       String weight, String formula) {

        MaterialStructureInfo structure = new MaterialStructureInfo();
        structure.setMolecularWeight(weight);
        structure.setMolecularFormula(formula);

        AdditionalMaterial material = new AdditionalMaterial();
        material.setMaterialName(materialName);
        material.setAlias(alias);
        material.setChemicalNameCAS(chemicalNameCAS);
        material.setChemicalNameIUPAC(chemicalNameIUPAC);
        material.setCpNumber(cpNumber);
        material.setActiveStatus(activeStatus);
        material.setStructureInfo(structure);

        return material;
    }
}