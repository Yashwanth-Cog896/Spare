package com.monsanto.tps.lexicon.regulatory.formulation.service;

import com.monsanto.tps.lexicon.formulation.FormulationService;
import com.monsanto.tps.lexicon.formulation.OrionFormulation;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 3/5/12
 * Time: 1:52 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:/com/monsanto/tps/lexicon/regulatory/contexts/lexicon-test-service-at-context.xml"})
@Transactional
public class FormulationService_AT {

    @Autowired
    FormulationService formulationService;

    @Test
    public void findFormulationTypes_results_wildcard() throws Exception {
        final List<OrionFormulation> formulations = formulationService.findFormulationTypes("S*");
        assertNotNull(formulations);
        assertFalse(formulations.isEmpty());
    }

    @Test
    public void findFormulationTypes_results_exactMatch() throws Exception {
        final List<OrionFormulation> formulations = formulationService.findFormulationTypes("TB");
        assertNotNull(formulations);
        assertFalse(formulations.isEmpty());
    }

    @Test
    public void findFormulationTypes_noResults() throws Exception {
        final List<OrionFormulation> formulations = formulationService.findFormulationTypes("asdf");
        assertNotNull(formulations);
        assertTrue(formulations.isEmpty());
    }
}
