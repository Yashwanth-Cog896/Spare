package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEventConstruct;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName;
import org.hibernate.Session;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: gdleon
 * Date: May 7, 2009
 * Time: 9:18:52 AM
 */
public class NonMonEventBuilder
{
   private final NonMonEvent nonMonEvent;
   private final List<NonMonEventConstructBuilder> nonMonEventConstructBuilders = new ArrayList<NonMonEventConstructBuilder>();
   private final List<ComlTraitTypeBuilder> comlTraitTypeBuilders = new ArrayList<ComlTraitTypeBuilder>();
   private final List<ComlTraitNameBuilder> comlTraitNameBuilders = new ArrayList<ComlTraitNameBuilder>();
   private final List<ProteinName> proteinNames = new ArrayList<ProteinName>();

   public NonMonEventBuilder() {
      nonMonEvent = new NonMonEvent();
      nonMonEvent.setEventDescription("NME DESC");
      nonMonEvent.setCropPubkey("1015");
      nonMonEvent.setActiveStatus(true);
      nonMonEvent.setMaterialName("MATERIAL NAME");

      nonMonEvent.setNonMonEventConstructs(new HashSet<NonMonEventConstruct>());
      nonMonEvent.setComlTraitTypes(new HashSet<ComlTraitType>());
      nonMonEvent.setComlTraitNames(new HashSet<ComlTraitName>());
      nonMonEvent.setProteinNames(new HashSet<ProteinName>());
   }

   public NonMonEventBuilder withEventDescription(String eventDescription) {
      this.nonMonEvent.setEventDescription(eventDescription);
      return this;
   }

   public NonMonEventBuilder withCropPubkey(String cropPubkey) {
      this.nonMonEvent.setCropPubkey(cropPubkey);
      return this;
   }

   public NonMonEventBuilder withMaterialName(String materialName) {
       this.nonMonEvent.setMaterialName(materialName);
       return this;
   }

   public NonMonEventBuilder withActiveStatus(boolean activeStatus) {
      this.nonMonEvent.setActiveStatus(activeStatus);
      return this;
   }

   public NonMonEventBuilder withNonMonEventConstruct(NonMonEventConstructBuilder nonMonEventConstructBuilder) {
      nonMonEventConstructBuilders.add(nonMonEventConstructBuilder);
      return this;
   }

   public NonMonEventBuilder withComlTraitType(ComlTraitTypeBuilder comlTraitTypeBuilder) {
      comlTraitTypeBuilders.add(comlTraitTypeBuilder);
      return this;
   }

   public NonMonEventBuilder withComlTraitName(ComlTraitNameBuilder comlTraitNameBuilder) {
      comlTraitNameBuilders.add(comlTraitNameBuilder);
      return this;
   }

   public NonMonEventBuilder withProteinName(ProteinName proteinName) {
      proteinNames.add(proteinName);
      return this;
   }

   public NonMonEvent createObj() {
      return this.nonMonEvent;
   }

   public NonMonEvent create() {
      Session session = TestSessions.getLexiconSession();
      setDependencies();
      session.save(nonMonEvent);
      addChildren();
      return this.nonMonEvent;
   }

   private void setDependencies() {
      nonMonEvent.setProteinNames(proteinNames);
   }

   private void addChildren() {
      nonMonEvent.setNonMonEventConstructs(createNonMonEventConstructs());
      nonMonEvent.setComlTraitTypes(createComlTraitTypes());
      nonMonEvent.setComlTraitNames(createComlTraitNames());
   }

   private Set<NonMonEventConstruct> createNonMonEventConstructs() {
      Set<NonMonEventConstruct> constructs = new HashSet<NonMonEventConstruct>();
      for (NonMonEventConstructBuilder constructBuilder : nonMonEventConstructBuilders) {
         constructs.add(constructBuilder.create(nonMonEvent));
      }

      return constructs;
   }

   private Set<ComlTraitType> createComlTraitTypes() {
      Set<ComlTraitType> comlTraitTypes = new HashSet<ComlTraitType>();
      for (ComlTraitTypeBuilder traitTypeBuilder : comlTraitTypeBuilders) {
         comlTraitTypes.add(traitTypeBuilder.create());
      }

      return comlTraitTypes;
   }

   private Set<ComlTraitName> createComlTraitNames() {
      Set<ComlTraitName> comlTraitNames = new HashSet<ComlTraitName>();
      for (ComlTraitNameBuilder traitNameBuilder : comlTraitNameBuilders) {
         comlTraitNames.add(traitNameBuilder.create());
      }

      return comlTraitNames;
   }
}
