package com.monsanto.tps.lexicon.regulatory.event.strategy;

import com.monsanto.tps.lexicon.event.EventInfo;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Crop;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber;
import com.monsanto.tps.lexicon.regulatory.event.model.EventConstruct;
import com.monsanto.tps.lexicon.regulatory.event.model.MockEventConstruct;
import com.monsanto.tps.lexicon.regulatory.event.queryset.EventCrop;
import com.monsanto.tps.lexicon.regulatory.event.queryset.EventSearchServiceQuerySet;
import com.monsanto.tps.lexicon.regulatory.event.queryset.RegulatoryEventResponse;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.HashSet;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * rrchak1 - Feb 11, 2009 3:12:18 PM
 */
public class EventInfoByAlignmentPubkeyStrategyImpl_UT {
    private EventSearchServiceQuerySet querySet;
    private EventInfoByAlignmentPubkeyStrategy strategy;

    @Before
    public void before() {
        querySet = mock(EventSearchServiceQuerySet.class);
        strategy = new EventInfoByAlignmentPubkeyStrategyImpl(querySet);
    }

    @Test
    public void testFindByPubkey_FindsEventAgencyAlignment_RegulatoryEvent_MonNumber()
            throws Exception {
        String eventName = "ZM_1111";
        EventAgencyAlignment eventAgencyAlignment = new EventAgencyAlignment();
        eventAgencyAlignment.setMaterialName(eventName);
        Crop crop = new Crop();
        crop.setCropName("CORN");
        eventAgencyAlignment.setCrop(crop);
        String[] eventAgencyAlignmentPubkey = new String[]{"1111"};
        when(querySet.findEventAgencyAlignmentByPubkey(eventAgencyAlignmentPubkey)).thenReturn(new EventAgencyAlignment[]{eventAgencyAlignment});
        RegulatoryEventResponse response = new RegulatoryEventResponse();
        response.setEventConstructs(Arrays.asList((EventConstruct) new MockEventConstruct(eventName, crop.getCropName())));
        response.setEvent(eventName);
        when(querySet.findRegulatoryEventByEventAndCrop(eq(new HashSet(Arrays.asList(new EventCrop(eventName, crop.getCropName())))))).thenReturn(Arrays.asList(response));
        when(querySet.findMonNumberByEventAndCrop(eventName, crop.getCropName())).thenReturn(new MonNumber());


        EventInfo[] eventInfo = strategy.find(eventAgencyAlignmentPubkey);


        assertThat(eventInfo, is(not(nullValue())));
    }

}
