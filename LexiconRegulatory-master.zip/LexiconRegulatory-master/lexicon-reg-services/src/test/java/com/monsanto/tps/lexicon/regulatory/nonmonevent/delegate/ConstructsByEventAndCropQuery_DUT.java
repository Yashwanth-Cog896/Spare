package com.monsanto.tps.lexicon.regulatory.nonmonevent.delegate;

import com.monsanto.tps.lexicon.regulatory.DB.Midas.Tests.MidasDataTestCase;
import com.monsanto.tps.lexicon.regulatory.DB.TestUtil.TPSTestConstants;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.service.EventConstructBuilder;

import java.util.Arrays;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

/**
 * nbwald - May 21, 2009 4:44:38 PM
 */
public class ConstructsByEventAndCropQuery_DUT
        extends MidasDataTestCase {

    public void testFind_DoesNotExist()
            throws Exception {
        ConstructsByEventAndCropQuery query = new ConstructsByEventAndCropQuery("SOMEEVENT", "CORN");
        String[] constructs = query.find();

        assertThat(constructs.length, is(0));
    }


    public void testFind_FindsMany()
            throws Exception {
        new EventConstructBuilder().
                withEventName("SOMEEVENT").
                withConstructName("SOMECONSTRUCTA").
                withCrop(TPSTestConstants.MIDAS_CORN_ID).
                create(getMidasConn());
        new EventConstructBuilder().
                withEventName("SOMEEVENT").
                withConstructName("SOMECONSTRUCTB").
                withCrop(TPSTestConstants.MIDAS_CORN_ID).
                create(getMidasConn());

        ConstructsByEventAndCropQuery query = new ConstructsByEventAndCropQuery("SOMEEVENT", "CORN");
        String[] constructs = query.find();

        assertThat(constructs.length, is(2));
        assertThat(Arrays.asList(constructs).contains("SOMECONSTRUCTA"), is(true));
        assertThat(Arrays.asList(constructs).contains("SOMECONSTRUCTB"), is(true));
    }


    public void testFind_CropNameIsCaseInsensitive()
            throws Exception {
        new EventConstructBuilder().
                withEventName("SOMEEVENT").
                withConstructName("SOMECONSTRUCT").
                withCrop(TPSTestConstants.MIDAS_CORN_ID).
                create(getMidasConn());

        ConstructsByEventAndCropQuery query = new ConstructsByEventAndCropQuery("SOMEEVENT", "cOrN");
        String[] constructs = query.find();

        assertThat(constructs.length, is(1));
        assertThat(constructs[0], is("SOMECONSTRUCT"));
    }


    public void testFind_EventNameIsCaseInsensitive()
            throws Exception {
        new EventConstructBuilder().
                withEventName("SOMEEVENT").
                withConstructName("SOMECONSTRUCT").
                withCrop(TPSTestConstants.MIDAS_CORN_ID).
                create(getMidasConn());

        ConstructsByEventAndCropQuery query = new ConstructsByEventAndCropQuery("SOMEEVENT", "CORN");
        String[] constructs = query.find();

        assertThat(constructs.length, is(1));
        assertThat(constructs[0], is("SOMECONSTRUCT"));
    }


    public void testFind_DoesNotFindInactiveEvents()
            throws Exception {
        new EventConstructBuilder().
                withEventName("SOMEEVENT").
                withConstructName("SOMECONSTRUCT").
                withCrop(TPSTestConstants.MIDAS_CORN_ID).
                inactive().
                create(getMidasConn());

        ConstructsByEventAndCropQuery query = new ConstructsByEventAndCropQuery("SOMEEVENT", "CORN");
        String[] constructs = query.find();

        assertThat(constructs.length, is(0));
    }
}
