package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.Tests.fluentmodel.TestIDGenerator;

/**
 * nbwald - Aug 27, 2008 3:05:13 PM
 */
public class BuilderID
{
   private final long id;

   public BuilderID() {
      id = new TestIDGenerator().generateId();
   }

   public long id() {
      return id;
   }

   public String sid() {
      return String.valueOf(id());
   }

   public String sid(int maxLength) {
      String sid = sid();
      int endIndex = Math.min(sid.length(), maxLength);
      return sid.substring(sid.length()-endIndex, sid.length());
   }
}
