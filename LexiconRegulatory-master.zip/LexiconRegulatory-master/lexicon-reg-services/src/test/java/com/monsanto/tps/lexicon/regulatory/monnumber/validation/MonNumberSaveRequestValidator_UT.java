package com.monsanto.tps.lexicon.regulatory.monnumber.validation;

import com.monsanto.tps.lexicon.monnumber.MonNumberSaveRequest;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber;
import com.monsanto.tps.lexicon.regulatory.monnumber.dao.MonNumberDao;
import org.easymock.EasyMock;
import static org.easymock.EasyMock.*;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;

/**
 * rrchak1 - May 7, 2009 9:38:34 AM
 */
public class MonNumberSaveRequestValidator_UT
{
   private MonNumberDao monNumberDao;
   private String validMonNumberValue = "MON 99999";
   MonNumberSaveRequestValidator validator;
   private String oecdNumber = "12";

   @Before
   public void before() {
      monNumberDao = EasyMock.createMock(MonNumberDao.class);
      validator = new MonNumberSaveRequestValidator();
      validator.setMonNumberDao(monNumberDao);
   }

   @Test
   public void testMonNumberValidatorSupportsMonNumberSaveRequest() {
      assertTrue(validator.supports(MonNumberSaveRequest.class));
   }

   @Test
   public void testValidateMonNumber_ThrowsErrorFor_No_MonNumber() {
      MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
      BindException errors = new BindException(monNumberSaveRequest, "MonNumberSaveRequest");
      validator.validate(monNumberSaveRequest, errors);
      assertTrue(errors.hasErrors());
      FieldError fieldError = errors.getFieldError("monNumber");
      assertEquals("Mon Number format must be MON 99999(-).", fieldError.getDefaultMessage());
   }

   @Test
   public void testValidateMonNumber_ThrowsErrorFor_Invalid_MonNumber() {
      MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
      monNumberSaveRequest.setMonNumber("MON1");
      BindException errors = new BindException(monNumberSaveRequest, "MonNumberSaveRequest");
      validator.validate(monNumberSaveRequest, errors);
      assertTrue(errors.hasErrors());
      FieldError fieldError = errors.getFieldError("monNumber");
      assertEquals("Mon Number format must be MON 99999(-).", fieldError.getDefaultMessage());
   }

   @Test
   public void testValidateMonNumber_ThrowsErrorFor_No_CropPubkey() {
      MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
      BindException errors = new BindException(monNumberSaveRequest, "MonNumberSaveRequest");
      validator.validate(monNumberSaveRequest, errors);
      assertTrue(errors.hasErrors());
      FieldError fieldError = errors.getFieldError("cropPubkey");
      assertNotNull(fieldError);
      assertEquals("Crop Pubkey may not be empty.", fieldError.getDefaultMessage());
   }

   @Test
   public void testValidateOECDNumber_ThrowsErrors_For_InvalidOECDNumber() {
      MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
      monNumberSaveRequest.setMonNumber(validMonNumberValue);
      monNumberSaveRequest.setOecdNumber("1 2");
      BindException errors = new BindException(monNumberSaveRequest, "MonNumberSaveRequest");
      expect(monNumberDao.find(validMonNumberValue)).andReturn(null);
      expect(monNumberDao.findByEvent(null)).andReturn(null);
      replay(monNumberDao);
      validator.validate(monNumberSaveRequest, errors);
      assertTrue(errors.hasErrors());
      FieldError fieldError = errors.getFieldError("oecdNumber");
      assertEquals("OECD Number cannot have space.", fieldError.getDefaultMessage());
   }

   @Test
   public void testValidateMonNumberRequest_ThrowsNoErrors_For_PopulatedRequiredFields() {
      MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
      monNumberSaveRequest.setMonNumber(validMonNumberValue);
      monNumberSaveRequest.setTraitTypeAbbreviations(new String[]{"abbr"});
      monNumberSaveRequest.setRegulatoryGenesPresent("genes");
      monNumberSaveRequest.setRegulatoryParentalLine("rpl");
      monNumberSaveRequest.setAuditComment("audit comment");
      monNumberSaveRequest.setAuditRequestor("audit Requestor");
      monNumberSaveRequest.setCropPubkey("1015");
      BindException errors = new BindException(monNumberSaveRequest, "MonNumberSaveRequest");
      expect(monNumberDao.find(validMonNumberValue)).andReturn(null);
      expect(monNumberDao.findByEvent(null)).andReturn(null);
      expect(monNumberDao.findByOecdNumber(null)).andReturn(null);
      replay(monNumberDao);
      validator.validate(monNumberSaveRequest, errors);
      assertFalse(errors.hasErrors());
   }

   @Test
   public void testValidateMonNumberSaveRequest_NoErrors_For_ValidRequest() {
      MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
      monNumberSaveRequest.setMonNumber(validMonNumberValue);
      monNumberSaveRequest.setOecdNumber(oecdNumber);
      monNumberSaveRequest.setTraitTypeAbbreviations(new String[]{"abbr"});
      monNumberSaveRequest.setTraitNameAbbreviations(new String[]{"abbr"});
      monNumberSaveRequest.setRegulatoryGenesPresent("genes");
      monNumberSaveRequest.setRegulatoryParentalLine("rpl");
      monNumberSaveRequest.setAuditComment("audit comment");
      monNumberSaveRequest.setAuditRequestor("audit Requestor");
      monNumberSaveRequest.setCropPubkey("1015");
      BindException errors = new BindException(monNumberSaveRequest, "MonNumberSaveRequest");
      expect(monNumberDao.find(validMonNumberValue)).andReturn(null);
      expect(monNumberDao.findByEvent(null)).andReturn(null);
      expect(monNumberDao.findByOecdNumber(oecdNumber)).andReturn(null);
      replay(monNumberDao);
      validator.validate(monNumberSaveRequest, errors);
      assertFalse(errors.hasErrors());
   }

   @Test
   public void testValidateTraitTypeAndTraitNameAbbreviations_ThrowsErrors_For_NoValue() {
      MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
      BindException errors = new BindException(monNumberSaveRequest, "MonNumberSaveRequest");
      expect(monNumberDao.findByEvent(null)).andReturn(null);
      replay(monNumberDao);
      validator.validate(monNumberSaveRequest, errors);
      assertTrue(errors.hasErrors());
      FieldError fieldError = errors.getFieldError("traitTypeAbbreviations");
      assertEquals("Regulatory Trait Description may not be empty.", fieldError.getDefaultMessage());
   }

   @Test
   public void testValidateTraitTypeAndTraitNameAbbreviations_NoErrors_For_TraitNameExist() {
      MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
      monNumberSaveRequest.setTraitNameAbbreviations(new String[]{"abbr"});
      BindException errors = new BindException(monNumberSaveRequest, "MonNumberSaveRequest");
      expect(monNumberDao.findByEvent(null)).andReturn(null);
      replay(monNumberDao);
      validator.validate(monNumberSaveRequest, errors);
      assertTrue(errors.hasErrors());
      FieldError fieldError = errors.getFieldError("traitTypeAbbreviations");
      assertNull(fieldError);
   }

   @Test
   public void testValidateTraitTypeAndTraitNameAbbreviations_NoErrors_For_TraitTypeExist() {
      MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
      monNumberSaveRequest.setTraitTypeAbbreviations(new String[]{"abbr"});
      BindException errors = new BindException(monNumberSaveRequest, "MonNumberSaveRequest");
      expect(monNumberDao.findByEvent(null)).andReturn(null);
      replay(monNumberDao);
      validator.validate(monNumberSaveRequest, errors);
      assertTrue(errors.hasErrors());
      FieldError fieldError = errors.getFieldError("traitTypeAbbreviations");
      assertNull(fieldError);
   }

   @Test
   public void testValidateRegulatoryGenesPresent_ThrowsErrors_For_NoValue() {
      MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
      BindException errors = new BindException(monNumberSaveRequest, "MonNumberSaveRequest");
      expect(monNumberDao.findByEvent(null)).andReturn(null);
      replay(monNumberDao);
      validator.validate(monNumberSaveRequest, errors);
      assertTrue(errors.hasErrors());
      FieldError fieldError = errors.getFieldError("regulatoryGenesPresent");
      assertEquals("Regulatory Genes Present may not be empty.", fieldError.getDefaultMessage());
   }

   @Test
   public void testValidateRegulatoryGenesPresent_ThrowsErrors_For_WhiteSpaceValue() {
      MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
      monNumberSaveRequest.setRegulatoryGenesPresent(" ");
      BindException errors = new BindException(monNumberSaveRequest, "MonNumberSaveRequest");
      expect(monNumberDao.findByEvent(null)).andReturn(null);
      replay(monNumberDao);
      validator.validate(monNumberSaveRequest, errors);
      assertTrue(errors.hasErrors());
      FieldError fieldError = errors.getFieldError("regulatoryGenesPresent");
      assertEquals("Regulatory Genes Present may not be empty.", fieldError.getDefaultMessage());
   }

   @Test
   public void testValidateAuditComment_ThrowsErrors_For_NoAuditComment() {
      MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
      BindException errors = new BindException(monNumberSaveRequest, "MonNumberSaveRequest");
      expect(monNumberDao.findByEvent(null)).andReturn(null);
      replay(monNumberDao);
      validator.validate(monNumberSaveRequest, errors);
      assertTrue(errors.hasErrors());
      FieldError fieldError = errors.getFieldError("auditComment");
      assertEquals("Audit Comment field must not be blank.", fieldError.getDefaultMessage());
   }

   @Test
   public void testValidateMonNumberExists_ThrowsErrors_For_AlreadyExistingMonNumber() {
      MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
      monNumberSaveRequest.setMonNumber(validMonNumberValue);
      MonNumber monNumber = new MonNumber();
      expect(monNumberDao.find(validMonNumberValue)).andReturn(monNumber);
      expect(monNumberDao.findByEvent(null)).andReturn(null);
      replay(monNumberDao);
      BindException errors = new BindException(monNumberSaveRequest, "MonNumberSaveRequest");
      validator.validate(monNumberSaveRequest, errors);
      verify(monNumberDao);
      assertTrue(errors.hasErrors());
      FieldError fieldError = errors.getFieldError("monNumber");
      assertEquals("Mon Number is already defined.", fieldError.getDefaultMessage());
   }

   @Test
   public void testValidateMonNumberExists_ThrowsErrors_For_AlreadyExistingEvent() {
      MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
      monNumberSaveRequest.setEvent("UT_EVENT");
      expect(monNumberDao.findByEvent("UT_EVENT")).andReturn(new MonNumber());
      replay(monNumberDao);
      BindException errors = new BindException(monNumberSaveRequest, "MonNumberSaveRequest");
      validator.validate(monNumberSaveRequest, errors);
      verify(monNumberDao);
      assertTrue(errors.hasErrors());
      FieldError fieldError = errors.getFieldError("event");
      assertEquals("Duplicate Event; UT_EVENT is already defined.", fieldError.getDefaultMessage());
   }

   @Test
   public void testValidateOecdNumberNumberExists_ThrowsErrors_For_AlreadyExistingOecdNumber() {
      MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
      monNumberSaveRequest.setOecdNumber(oecdNumber);
      expect(monNumberDao.findByEvent(null)).andReturn(null);
      expect(monNumberDao.findByOecdNumber(oecdNumber)).andReturn(new MonNumber());
      replay(monNumberDao);
      BindException errors = new BindException(monNumberSaveRequest, "MonNumberSaveRequest");
      validator.validate(monNumberSaveRequest, errors);
      verify(monNumberDao);
      assertTrue(errors.hasErrors());
      FieldError fieldError = errors.getFieldError("oecdNumber");
      assertEquals("OECD Number is already defined.", fieldError.getDefaultMessage());
   }

   @Test
   public void testValidateAuditComment_ThrowsErrors_For_NoAuditRequestor() {
      MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
      BindException errors = new BindException(monNumberSaveRequest, "MonNumberSaveRequest");
      expect(monNumberDao.findByEvent(null)).andReturn(null);
      replay(monNumberDao);
      validator.validate(monNumberSaveRequest, errors);
      assertTrue(errors.hasErrors());
      FieldError fieldError = errors.getFieldError("auditRequestor");
      assertEquals("Audit Requestor must not be blank.", fieldError.getDefaultMessage());
   }

   @Test
   public void testValidateRegulatoryParentalLine_ThrowsErrors_For_NoRegulatoryParentalLine() {
      MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
      BindException errors = new BindException(monNumberSaveRequest, "MonNumberSaveRequest");
      expect(monNumberDao.findByEvent(null)).andReturn(null);
      replay(monNumberDao);
      validator.validate(monNumberSaveRequest, errors);
      assertTrue(errors.hasErrors());
      FieldError fieldError = errors.getFieldError("regulatoryParentalLine");
      assertNotNull(fieldError);
      assertEquals("Regulatory Parental Line may not be empty.", fieldError.getDefaultMessage());
   }

}
