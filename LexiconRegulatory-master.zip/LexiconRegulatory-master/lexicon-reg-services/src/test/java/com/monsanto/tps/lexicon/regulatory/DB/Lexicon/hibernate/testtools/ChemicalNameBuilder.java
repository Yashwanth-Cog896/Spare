package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MaterialChemicalName;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;


public class ChemicalNameBuilder {


    public static MaterialChemicalName findMaterialName() {
        Criteria chemicalNameCriteria = TestSessions.getLexiconSession().createCriteria(MaterialChemicalName.class).
                add(Restrictions.eq("expertlInd", "F"));
        return (MaterialChemicalName) chemicalNameCriteria.list().get(0);
    }


}
