package com.monsanto.tps.lexicon.regulatory.shippingcondition.service;

import com.monsanto.tps.lexicon.shippingcondition.OrionShippingCondition;
import com.monsanto.tps.lexicon.shippingcondition.ShippingConditionService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/2/12
 * Time: 7:40 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:/com/monsanto/tps/lexicon/regulatory/contexts/lexicon-test-service-at-context.xml"})
@Transactional
public class ShippingConditionService_AT {

    @Resource
    ShippingConditionService shippingConditionServiceImpl;

    @Test
    public void findShippingCondition_results_wildcard() throws Exception {
        final List<OrionShippingCondition> ShippingConditions = shippingConditionServiceImpl.findShippingConditions("F*");
        assertNotNull(ShippingConditions);
        assertFalse(ShippingConditions.isEmpty());
    }

    @Test
    public void findShippingCondition_results_exactMatch() throws Exception {
        final List<OrionShippingCondition> ShippingConditions = shippingConditionServiceImpl.findShippingConditions("Cool on Ice");
        assertNotNull(ShippingConditions);
        assertFalse(ShippingConditions.isEmpty());
    }

    @Test
    public void findShippingCondition_noResults() throws Exception {
        final List<OrionShippingCondition> ShippingConditions = shippingConditionServiceImpl.findShippingConditions("asdf");
        assertNotNull(ShippingConditions);
        assertTrue(ShippingConditions.isEmpty());
    }
}
