package com.monsanto.tps.lexicon.regulatory.monnumber.service;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.lexiconcommon.ArrayUtils;
import com.monsanto.tps.aop.metric.DataPointHolder;
import com.monsanto.tps.lexicon.event.Construct;
import com.monsanto.tps.lexicon.monnumber.MonNumberSaveBatchRequest;
import com.monsanto.tps.lexicon.monnumber.MonNumberSaveRequest;
import com.monsanto.tps.lexicon.monnumber.MonNumberSaveResponse;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.AuditStaging;
import com.monsanto.tps.lexicon.regulatory.commercialtrait.dao.CommercialTraitDao;
import com.monsanto.tps.lexicon.regulatory.crop.dao.CropDao;
import com.monsanto.tps.lexicon.regulatory.event.queryset.RegulatoryEventRequestProcessor;
import com.monsanto.tps.lexicon.regulatory.monnumber.dao.MonNumberDao;
import com.monsanto.tps.lexicon.regulatory.monnumber.util.MonNumberBeanUtil;
import org.easymock.classextension.EasyMock;
import static org.easymock.classextension.EasyMock.*;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.springframework.validation.Validator;

import java.io.IOException;

/**
 * rrchak1 - May 6, 2009 4:12:54 PM
 */
public class MonNumberServiceImpl_UT
{
   MonNumberServiceImpl monNumberService;
   MonNumberDao monNumberDao;
   MonNumberBeanUtil monNumberBeanUtil;
   RegulatoryEventRequestProcessor eventRequestProcessor;
   CropDao cropDao;
   CommercialTraitDao commercialTraitDao;
   Validator monNumberSaveRequestValidator;
   Validator monNumberUpdateRequestValidator;
   private String cropPubkey = "1015";
   private String event = "UT_EVENT";
   private String proteinNamePubkey = "1234";
   private String traitAbbr = "traitAbbr";
   private String traitTypeAbbr = "traitTypeAbbr";
   private String auditComment = "auditComment";
   private String auditRequestor = "requestor";
   private String monNumberVal = "MON 99999";
   private String genes = "genes";
   private String construct = "UT_CONS";
   private String transformationBk = "trans_bk";
   private String pvCode = "pvCode";
   private DataPointHolder dataPointHolder;
   private MonNumberPersistProcessor monNumberPersistProcessor;
   private String regulatoryparentalLine = "rpl";

   @Before
   public void before() {
      monNumberService = new MonNumberServiceImpl();
      monNumberSaveRequestValidator = EasyMock.createMock(Validator.class);
      monNumberUpdateRequestValidator = EasyMock.createMock(Validator.class);
      monNumberDao = EasyMock.createMock(MonNumberDao.class);
      eventRequestProcessor = EasyMock.createMock(RegulatoryEventRequestProcessor.class);
      monNumberPersistProcessor = EasyMock.createMock(MonNumberPersistProcessor.class);
      cropDao = EasyMock.createMock(CropDao.class);
      commercialTraitDao = EasyMock.createMock(CommercialTraitDao.class);
      dataPointHolder = EasyMock.createMock(DataPointHolder.class);
      monNumberService.setMonNumberPersistProcessor(monNumberPersistProcessor);
      monNumberService.setDataPointHolder(dataPointHolder);
      monNumberService.setMonNumberDao(monNumberDao);

   }

   @Test
   public void monNumberService_save_sendsEmptyResponseForEmptyBatchRequest() {
      MonNumberSaveBatchRequest monNumberSaveBatchRequest = new MonNumberSaveBatchRequest();
      MonNumberSaveResponse[] monNumberSaveResponses = monNumberService.save(
         monNumberSaveBatchRequest);
      assertTrue(ArrayUtils.isNullOrEmpty(monNumberSaveResponses));
   }

   @Test
   public void monNumberService_save_callsDependencies_SavesAndReturnsFullResponse()
      throws IOException, WrappingException
   {
      MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
      monNumberSaveRequest.setCropPubkey(cropPubkey);
      monNumberSaveRequest.setEvent(event);
      monNumberSaveRequest.setProteinNamePubkeys(new String[]{proteinNamePubkey});
      monNumberSaveRequest.setTraitTypeAbbreviations(new String[]{traitTypeAbbr});
      monNumberSaveRequest.setTraitNameAbbreviations(new String[]{traitAbbr});
      monNumberSaveRequest.setAuditComment(auditComment);
      monNumberSaveRequest.setAuditRequestor(auditRequestor);
      monNumberSaveRequest.setMonNumber(monNumberVal);
      monNumberSaveRequest.setRegulatoryGenesPresent(genes);
      monNumberSaveRequest.setRegulatoryParentalLine(regulatoryparentalLine);
      MonNumberSaveBatchRequest monNumberSaveBatchRequest = new MonNumberSaveBatchRequest();
      monNumberSaveBatchRequest.setMonNumberSaveRequests(new MonNumberSaveRequest[]{monNumberSaveRequest});
      AuditStaging auditStaging = new AuditStaging();
      MonNumberSaveResponse response = new MonNumberSaveResponse();
      response.setSuccess(true);
      Construct constructObj = new Construct();
      constructObj.setPlasmidPMon(construct);
      constructObj.setPlasmidPVCode(pvCode);
      response.setEventConstructs(new Construct[]{constructObj});
      response.setTransformationBackground(transformationBk);
      expect(monNumberPersistProcessor.processSave(false, monNumberSaveRequest)).andReturn(response);
      replay(eventRequestProcessor);
      replay(cropDao);
      replay(monNumberSaveRequestValidator);
      replay(monNumberDao);
      replay(commercialTraitDao);
      replay(monNumberPersistProcessor);
      MonNumberSaveResponse[] responses = monNumberService.save(monNumberSaveBatchRequest);
      verify(eventRequestProcessor);
      verify(cropDao);
      verify(monNumberSaveRequestValidator);
      verify(monNumberDao);
      verify(commercialTraitDao);
      verify(monNumberPersistProcessor);
      assertTrue(ArrayUtils.hasItems(responses));
      assertEquals(1, responses.length);
      MonNumberSaveResponse monNumberSaveResponse = responses[0];
      assertTrue(monNumberSaveResponse.isSuccess());
      assertFalse(ArrayUtils.hasItems(monNumberSaveResponse.getMessages()));
      assertFalse(ArrayUtils.isNullOrEmpty(monNumberSaveResponse.getEventConstructs()));
      Construct[] constructs = monNumberSaveResponse.getEventConstructs();
      assertTrue(containsConstruct(construct, constructs));
      assertTrue(containsPvCode(pvCode, constructs));
      assertEquals(transformationBk, monNumberSaveResponse.getTransformationBackground());
   }

   @Test
   public void monNumberService_save_ReturnsErrorMessagesForValidationErrors_WillNotCallSave()
      throws IOException, WrappingException
   {
      MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
      MonNumberSaveBatchRequest monNumberSaveBatchRequest = new MonNumberSaveBatchRequest();
      monNumberSaveBatchRequest.setMonNumberSaveRequests(new MonNumberSaveRequest[]{monNumberSaveRequest});
      MonNumberSaveResponse response = new MonNumberSaveResponse();
      response.setSuccess(false);
      response.setMessages(new String[]{"error Message"});
      expect(monNumberPersistProcessor.processSave(false, monNumberSaveRequest)).andReturn(response);
      replay(monNumberPersistProcessor);
      replay(monNumberSaveRequestValidator);
      replay(monNumberDao);
      MonNumberSaveResponse[] responses = monNumberService.save(monNumberSaveBatchRequest);
      verify(monNumberPersistProcessor);
      verify(monNumberSaveRequestValidator);
      verify(monNumberDao);
      assertTrue(ArrayUtils.hasItems(responses));
      assertEquals(1, responses.length);
      MonNumberSaveResponse monNumberSaveResponse = responses[0];
      assertFalse(monNumberSaveResponse.isSuccess());
      assertTrue(ArrayUtils.hasItems(monNumberSaveResponse.getMessages()));
   }

   @Test
   public void monNumberService_update_callsDependencies_UpdatesAndReturnsFullResponse()
      throws IOException, WrappingException
   {
      MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
      monNumberSaveRequest.setCropPubkey(cropPubkey);
      monNumberSaveRequest.setEvent(event);
      monNumberSaveRequest.setProteinNamePubkeys(new String[]{proteinNamePubkey});
      monNumberSaveRequest.setTraitTypeAbbreviations(new String[]{traitTypeAbbr});
      monNumberSaveRequest.setTraitNameAbbreviations(new String[]{traitAbbr});
      monNumberSaveRequest.setAuditComment(auditComment);
      monNumberSaveRequest.setAuditRequestor(auditRequestor);
      monNumberSaveRequest.setMonNumber(monNumberVal);
      monNumberSaveRequest.setRegulatoryGenesPresent(genes);
      monNumberSaveRequest.setRegulatoryParentalLine(regulatoryparentalLine);
      MonNumberSaveBatchRequest monNumberSaveBatchRequest = new MonNumberSaveBatchRequest();
      monNumberSaveBatchRequest.setMonNumberSaveRequests(new MonNumberSaveRequest[]{monNumberSaveRequest});
      AuditStaging auditStaging = new AuditStaging();
      MonNumberSaveResponse response = new MonNumberSaveResponse();
      response.setSuccess(true);
      Construct constructObj = new Construct();
      constructObj.setPlasmidPMon(construct);
      constructObj.setPlasmidPVCode(pvCode);
      response.setEventConstructs(new Construct[]{constructObj});
      response.setTransformationBackground(transformationBk);
      expect(monNumberPersistProcessor.processUpdate(false, monNumberSaveRequest)).andReturn(response);
      replay(monNumberPersistProcessor);
      replay(eventRequestProcessor);
      replay(cropDao);
      replay(monNumberSaveRequestValidator);
      replay(monNumberDao);
      replay(commercialTraitDao);
      MonNumberSaveResponse[] responses = monNumberService.update(monNumberSaveBatchRequest);
      verify(monNumberPersistProcessor);
      verify(eventRequestProcessor);
      verify(cropDao);
      verify(monNumberSaveRequestValidator);
      verify(monNumberDao);
      verify(commercialTraitDao);
      assertTrue(ArrayUtils.hasItems(responses));
      assertEquals(1, responses.length);
      MonNumberSaveResponse monNumberSaveResponse = responses[0];
      assertTrue(monNumberSaveResponse.isSuccess());
      assertFalse(ArrayUtils.hasItems(monNumberSaveResponse.getMessages()));
      assertFalse(ArrayUtils.isNullOrEmpty(monNumberSaveResponse.getEventConstructs()));
      Construct[] constructs = monNumberSaveResponse.getEventConstructs();
      assertTrue(containsConstruct(construct, constructs));
      assertTrue(containsPvCode(pvCode, constructs));
      assertEquals(transformationBk, monNumberSaveResponse.getTransformationBackground());
   }


   @Test
   public void monNumberService_update_ReturnsErrorMessagesForValidationErrors_WillNotUpdate()
      throws IOException, WrappingException
   {
      MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
      MonNumberSaveBatchRequest monNumberSaveBatchRequest = new MonNumberSaveBatchRequest();
      monNumberSaveBatchRequest.setMonNumberSaveRequests(new MonNumberSaveRequest[]{monNumberSaveRequest});
      MonNumberSaveResponse response = new MonNumberSaveResponse();
      response.setSuccess(false);
      response.setMessages(new String[]{"error Message"});
      expect(monNumberPersistProcessor.processUpdate(false, monNumberSaveRequest)).andReturn(response);
      replay(monNumberPersistProcessor);
      replay(monNumberUpdateRequestValidator);
      replay(monNumberDao);
      replay(commercialTraitDao);
      MonNumberSaveResponse[] responses = monNumberService.update(monNumberSaveBatchRequest);
      verify(monNumberPersistProcessor);
      verify(monNumberUpdateRequestValidator);
      verify(monNumberDao);
      verify(commercialTraitDao);
      assertTrue(ArrayUtils.hasItems(responses));
      assertEquals(1, responses.length);
      MonNumberSaveResponse monNumberSaveResponse = responses[0];
      assertFalse(monNumberSaveResponse.isSuccess());
      assertTrue(ArrayUtils.hasItems(monNumberSaveResponse.getMessages()));
   }

   private boolean containsConstruct(String constructName, Construct[] constructs) {
      for (Construct construct : constructs) {
         if (constructName.equalsIgnoreCase(construct.getPlasmidPMon())) {
            return true;
         }
      }
      return false;
   }


   private boolean containsPvCode(String pvCode, Construct[] constructs) {
      for (Construct construct : constructs) {
         if (pvCode.equalsIgnoreCase(construct.getPlasmidPVCode())) {
            return true;
         }
      }
      return false;
   }

}




