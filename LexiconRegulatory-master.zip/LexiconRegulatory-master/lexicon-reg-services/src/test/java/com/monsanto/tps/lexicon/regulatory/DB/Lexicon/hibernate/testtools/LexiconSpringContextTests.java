package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools;

import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

/**
 * rrchak1 - Oct 8, 2008 11:51:16 AM
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
         "/com/monsanto/tps/lexicon/regulatory/contexts/services-context.xml",
         "/com/monsanto/tps/lexicon/regulatory/contexts/hibernate-context.xml",
         "/com/monsanto/tps/lexicon/regulatory/contexts/aop-context.xml",
         "/com/monsanto/tps/lexicon/regulatory/contexts/test-datasource-context.xml",
         "/com/monsanto/tps/lexicon/regulatory/contexts/lexicon-test-context.xml"
})
@Transactional
public class LexiconSpringContextTests{

}
