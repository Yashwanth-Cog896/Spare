package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Crop;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumberConstruct;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName;
import org.hibernate.Session;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * rrchak1 - Dec 18, 2008 3:18:02 PM
 */
public class MonNumberBuilder
{
   private MonNumber monNumber;
   private final List<MonNumberConstructBuilder> monNumberConstructBuilders = new ArrayList<MonNumberConstructBuilder>();
   private final List<ComlTraitTypeBuilder> comlTraitTypeBuilders = new ArrayList<ComlTraitTypeBuilder>();
   private final List<ProteinNameBuilder> proteinNameBuilders = new ArrayList<ProteinNameBuilder>();
   private final BuilderID builderID = new BuilderID();
   private final List<ComlTraitNameBuilder> comlTraitNameBuilders = new ArrayList<ComlTraitNameBuilder>();

   public MonNumberBuilder() {
      monNumber = new MonNumber();
      monNumber.setMonNumberId(builderID.id());
      monNumber.setMonNumber("MON_1234");
      monNumber.setCrop(CropBuilder.corn());
      monNumber.setOecdNumber("OECD1234");
      monNumber.setOecdNumberCommunicationDate(new Timestamp(System.currentTimeMillis()));
      monNumber.setRegulatoryGenesPresent("y");
      monNumber.setActiveStatus(true);
      monNumber.setLocked(false);
      monNumber.setRegulatedStatus(false);
      monNumber.setJvNumber("JV123");
      monNumber.setTransformationBackground("TB123");
      monNumber.setRegulatoryParentalLine("RPL");

      monNumber.setProteinNames(new HashSet<ProteinName>());
      monNumber.setComlTraitTypes(new HashSet<ComlTraitType>());
      monNumber.setMonNumberConstructs(new HashSet<MonNumberConstruct>());
      monNumber.setComlTraitNames(new HashSet<ComlTraitName>());
   }

   public MonNumberBuilder withMonNumber(String monNumber) {
      this.monNumber.setMonNumber(monNumber);
      return this;
   }

   public MonNumberBuilder withEventName(String eventName) {
      this.monNumber.setEvent(eventName);
      return this;
   }

   public MonNumberBuilder withOecdNumber(String oecdNumber) {
      this.monNumber.setOecdNumber(oecdNumber);
      return this;
   }

   public MonNumberBuilder withActiveStatus(boolean activeStatus) {
      this.monNumber.setActiveStatus(activeStatus);
      return this;
   }

   public MonNumberBuilder withMonNumberConstruct(MonNumberConstructBuilder monNumberConstructBuilder) {
      monNumberConstructBuilders.add(monNumberConstructBuilder);
      return this;
   }

   public MonNumberBuilder withComlTraitType(ComlTraitTypeBuilder comlTraitTypeBuilder) {
      comlTraitTypeBuilders.add(comlTraitTypeBuilder);
      return this;
   }

   public MonNumberBuilder withProteinName(ProteinNameBuilder proteinNameBuilder) {
      proteinNameBuilders.add(proteinNameBuilder);
      return this;
   }

   public MonNumberBuilder withComlTraitName(ComlTraitNameBuilder comlTraitNameBuilder) {
      comlTraitNameBuilders.add(comlTraitNameBuilder);
      return this;
   }

   public MonNumber create() {
      return this.monNumber;
   }

   public MonNumber createInDb() {
      Session session = TestSessions.getLexiconSession();
      monNumber.getComlTraitTypes().addAll(createComlTraitTypes());
      monNumber.getProteinNames().addAll(createProteinNames());
      monNumber.getComlTraitNames().addAll(createComlTraitNames());
      session.save(monNumber);
      addChildren();
      return this.monNumber;
   }

   public MonNumberBuilder withCrop(Crop crop) {
      monNumber.setCrop(crop);
      return this;
   }

   private void addChildren() {
      monNumber.getMonNumberConstructs().addAll(createMonNumberConstructs());
   }

   private Set<MonNumberConstruct> createMonNumberConstructs() {
      Set<MonNumberConstruct> constructs = new HashSet<MonNumberConstruct>();
      for (MonNumberConstructBuilder constructBuilder : monNumberConstructBuilders) {
         constructs.add(constructBuilder.create(monNumber));
      }

      return constructs;
   }

   private Set<ComlTraitType> createComlTraitTypes() {
      Set<ComlTraitType> comlTraitTypes = new HashSet<ComlTraitType>();
      for (ComlTraitTypeBuilder traitBuilder : comlTraitTypeBuilders) {
         comlTraitTypes.add(traitBuilder.create());
      }

      return comlTraitTypes;
   }

   private Set<ComlTraitName> createComlTraitNames() {
      Set<ComlTraitName> comlTraitNames = new HashSet<ComlTraitName>();
      for (ComlTraitNameBuilder traitNameBuilder : comlTraitNameBuilders) {
         comlTraitNames.add(traitNameBuilder.create());
      }

      return comlTraitNames;
   }

   private Set<ProteinName> createProteinNames() {
      Set<ProteinName> proteinNames = new HashSet<ProteinName>();
      for (ProteinNameBuilder proteinNameBuilder : proteinNameBuilders) {
         proteinNames.add(proteinNameBuilder.create());
      }

      return proteinNames;
   }
}
