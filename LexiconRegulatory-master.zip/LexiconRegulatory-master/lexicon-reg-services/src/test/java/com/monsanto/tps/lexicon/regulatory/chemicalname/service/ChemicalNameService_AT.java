package com.monsanto.tps.lexicon.regulatory.chemicalname.service;

import com.monsanto.tps.lexicon.chemicalname.ChemicalNameService;
import com.monsanto.tps.lexicon.chemicalname.OrionChemicalName;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/2/12
 * Time: 7:40 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:/com/monsanto/tps/lexicon/regulatory/contexts/lexicon-test-service-at-context.xml"})
@Transactional
public class ChemicalNameService_AT {

    @Resource
    ChemicalNameService chemicalNameServiceImpl;

    @Test
    public void findChemicalName_results_wildcard() throws Exception {
        final List<OrionChemicalName> chemicalNames = chemicalNameServiceImpl.findChemicalNames("Try*");
        assertNotNull(chemicalNames);
        assertFalse(chemicalNames.isEmpty());
    }

    @Test
    public void findChemicalName_results_exactMatch() throws Exception {
        final List<OrionChemicalName> chemicalNames = chemicalNameServiceImpl.findChemicalNames("tryptophan");
        assertNotNull(chemicalNames);
        assertFalse(chemicalNames.isEmpty());
    }

    @Test
    public void findChemicalName_noResults() throws Exception {
        final List<OrionChemicalName> chemicalNames = chemicalNameServiceImpl.findChemicalNames("asdf");
        assertNotNull(chemicalNames);
        assertTrue(chemicalNames.isEmpty());
    }

    @Test
    public void findChemicalMaterial_results_wildcard() throws Exception {
        final List<OrionChemicalName> chemicalNames = chemicalNameServiceImpl.findChemicalMaterials("a*");
        assertNotNull(chemicalNames);
        assertFalse(chemicalNames.isEmpty());
    }

    @Test
    public void findChemicalMaterial_results_exactMatch() throws Exception {
        final List<OrionChemicalName> chemicalNames = chemicalNameServiceImpl.findChemicalMaterials("A-20");
        assertNotNull(chemicalNames);
        assertFalse(chemicalNames.isEmpty());
    }

    @Test
    public void findChemicalMaterial_noResults() throws Exception {
        final List<OrionChemicalName> chemicalNames = chemicalNameServiceImpl.findChemicalMaterials("asdf");
        assertNotNull(chemicalNames);
        assertTrue(chemicalNames.isEmpty());
    }
}
