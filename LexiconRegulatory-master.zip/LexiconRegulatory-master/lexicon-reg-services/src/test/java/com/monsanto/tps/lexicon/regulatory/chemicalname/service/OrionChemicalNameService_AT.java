package com.monsanto.tps.lexicon.regulatory.chemicalname.service;

import com.monsanto.tps.lexicon.chemicalname.OrionChemicalName;
import com.monsanto.tps.lexicon.chemicalname.OrionChemicalNameService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/2/12
 * Time: 7:40 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:/com/monsanto/tps/lexicon/regulatory/contexts/lexicon-test-service-at-context.xml"})
@Transactional
public class OrionChemicalNameService_AT {

    @Resource
    OrionChemicalNameService orionChemicalNameServiceImpl;

    @Test
    public void findChemicalName_results_wildcard() throws Exception {
        final List<OrionChemicalName> chemicalNames = orionChemicalNameServiceImpl.findChemicalNames("ab*");
        assertNotNull(chemicalNames);
        assertFalse(chemicalNames.isEmpty());
    }

    @Test
    public void findChemicalName_results_exactMatch() throws Exception {
        final List<OrionChemicalName> ChemicalNames = orionChemicalNameServiceImpl.findChemicalNames("tryptophan");
        assertNotNull(ChemicalNames);
        assertFalse(ChemicalNames.isEmpty());
    }

    @Test
    public void findChemicalName_noResults() throws Exception {
        final List<OrionChemicalName> ChemicalNames = orionChemicalNameServiceImpl.findChemicalNames("asdf");
        assertNotNull(ChemicalNames);
        assertTrue(ChemicalNames.isEmpty());
    }
}
