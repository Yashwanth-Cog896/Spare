package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools;

import com.monsanto.dbdataservices.SQLUtil;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Agency;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.AgencyDepartment;
import org.hibernate.Session;

/**
 * rrchak1 - Oct 15, 2008 12:53:33 PM
 */
public class AgencyDepartmentBuilder
{
   private AgencyDepartment agencyDepartment;
   private final BuilderID builderID = new BuilderID();

   public AgencyDepartmentBuilder() {
      agencyDepartment = new AgencyDepartment();
      agencyDepartment.setAgencyDeptPubkey(builderID.sid());
      agencyDepartment.setAgencyDeptAbbr("USEPA");
      agencyDepartment.setAgencyDeptName("USEPA EAST");
      agencyDepartment.setAddress1("800 N Lindburg");
      agencyDepartment.setCity("ST. Louis");
      agencyDepartment.setPostalCode("63017");
      agencyDepartment.setSubCountryAbbr("MO");
      agencyDepartment.setActive(SQLUtil.booleanToString(true));
   }

   public AgencyDepartmentBuilder withPubkey(String pubkey) {
      agencyDepartment.setAgencyDeptPubkey(pubkey);
      return this;
   }

   public AgencyDepartment create(Agency agency) {
      agencyDepartment.setAgency(agency);
      Session session = TestSessions.getLexiconSession();
      session.save(agencyDepartment);
      return agencyDepartment;
   }

   public AgencyDepartmentBuilder withName(String deptName) {
      agencyDepartment.setAgencyDeptName(deptName);
      return this;
   }

   public AgencyDepartmentBuilder withActiveStatus(boolean activeStatus) {
      agencyDepartment.setActive(SQLUtil.booleanToString(activeStatus));
      return this;
   }

   public AgencyDepartmentBuilder withAgencyDepartmentAbbr(String departmentAbbr) {
      agencyDepartment.setAgencyDeptAbbr(departmentAbbr);
      return this;
   }
}
