package com.monsanto.tps.lexicon.regulatory.eventtraitservice.service;

import com.monsanto.tps.lexicon.eventtraitservice.transfer.*;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.LexiconAcceptanceTestCase;
import com.monsanto.tps.lexicon.regulatory.eventtraitservice.business.EventTraitServiceBusiness;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: athanga
 * Date: 8/29/11
 * Time: 1:41 PM
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
         "/com/monsanto/tps/lexicon/regulatory/contexts/test-external-services-context.xml"})
public class EventTraitService_XT extends LexiconAcceptanceTestCase {

    @Resource
    private EventTraitServiceBusiness eventTraitServiceBusiness;

    @Test
    public void test_EventBusinessServiceBusiness() {
        List<Long> germplasmIds = new ArrayList<Long>();
        germplasmIds.add(1387369463808L);
        //germplasmIds.add(639127847062L);
        GermplasmEventTraitRequest germplasmEventTraitRequest = new GermplasmEventTraitRequest();
        germplasmEventTraitRequest.setGermplasmIds(germplasmIds);
        GermplasmEventTraitResponse germplasmTraitEventConstructs = eventTraitServiceBusiness.getGermplasmTraitEventConstructs(germplasmEventTraitRequest);

        List<GermplasmEventTrait> germplasmEventTraits = germplasmTraitEventConstructs.getGermplasmEventTraits();
        for (GermplasmEventTrait germplasmEventTrait : germplasmEventTraits) {
            List<MidasEventConstruct> midasEventConstructs = germplasmEventTrait.getEventConstruct();
            for (MidasEventConstruct midasEventConstruct : midasEventConstructs) {
                System.out.println("midasEventConstruct.getEventConstructId() = " + midasEventConstruct.getEventConstructId());
                for (EventMonNumber eventMonNumber:midasEventConstruct.getEventMonNumbers()){
                  System.out.println("midasEventConstruct.getEventMonNumber() = " + eventMonNumber.getMonNumber());
                }
                List<PVCode> pvCodes = midasEventConstruct.getPvCodes();
                for (PVCode pvCode : pvCodes) {
                    System.out.println("pvCode = " + pvCode.getPvCode());
                    System.out.println("pvCode = " + pvCode.getPhenotypeCategoryCode());
                    System.out.println("pvCode = " + pvCode.getPhenotypeCategoryDescription());
                }
            }
        }
    }
}
