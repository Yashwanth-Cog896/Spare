package com.monsanto.tps.lexicon.regulatory.nonmonevent.service;

import com.monsanto.tps.lexicon.commercialtrait.ComlTraitName;
import com.monsanto.tps.lexicon.commercialtrait.ComlTraitType;
import com.monsanto.tps.lexicon.monnumber.ProteinName;
import com.monsanto.tps.lexicon.nonmonevent.NonMonEventConstruct;
import com.monsanto.tps.lexicon.nonmonevent.NonMonEventService;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.ComlTraitNameBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.ComlTraitTypeBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.CropBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.LexiconAcceptanceTestCase;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.NonMonEventBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.NonMonEventConstructBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.ProteinNameBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent;
import org.junit.Test;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: gdleon
 * Date: May 6, 2009
 * Time: 1:34:35 PM
 */
@Transactional
public class NonMonEventServiceImpl_AT
   extends LexiconAcceptanceTestCase
{
   @Resource
   private NonMonEventService nonMonEventService;

   @Test 
 public void testReturnsMatchingNonMonEventWithSingleChildDataForValidCrop() {
      insert(new AcceptanceTestData<NonMonEvent>()
      {
         public NonMonEvent dataToInsert() {
            return new NonMonEventBuilder().
               withEventDescription("ZM_1111").
               withMaterialName("MAT NAME").
               withCropPubkey(CropBuilder.soybeans().getCropPubkey()).
               withNonMonEventConstruct(new NonMonEventConstructBuilder().
                  withConstructName("CON_111")).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("TRTABBR").
                  withTraitTypeDesc("TRT TYPE DESC")).
               withComlTraitName(new ComlTraitNameBuilder().
                  withTraitAbbr("TNABBR").
                  withTraitDesc("TRT NAME DESC")).
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROT NAME").
                  withProteinNamePubkey("1234").
                  withProteinDescription("PROT DESC").
                  withOrigSourceOrganism("ORIG SOURCE ORG").create()).
               create();
         }
      });

      com.monsanto.tps.lexicon.nonmonevent.NonMonEvent[] nonMonEvents = nonMonEventService.findByCrop("1115");

      assertTrue(containsNonMonEvent("ZM_1111", nonMonEvents));
      for (com.monsanto.tps.lexicon.nonmonevent.NonMonEvent nonMonEvent : nonMonEvents) {
         assertEquals("1115", nonMonEvent.getCropPubkey());
         assertEquals(true, nonMonEvent.isActive());
         if (nonMonEvent.getEventDescription().equals("ZM_1111")) {
            assertEquals("MAT NAME", nonMonEvent.getMaterialName());
            assertEquals(1, nonMonEvent.getProteinNames().size());
            ProteinName proteinName = nonMonEvent.getProteinNames().iterator().next();
            assertEquals("PROT NAME", proteinName.getProteinName());
            assertEquals("1234", proteinName.getProteinNamePubkey());

            assertEquals(1, nonMonEvent.getComlTraitTypes().size());
            ComlTraitType comlTraitType = nonMonEvent.getComlTraitTypes().iterator().next();
            assertEquals("TRTABBR", comlTraitType.getComlTraitTypeAbbr());
            assertEquals("TRT TYPE DESC", comlTraitType.getComlTraitTypeDesc());

            assertEquals(1, nonMonEvent.getComlTraitNames().size());
            ComlTraitName comlTraitName = nonMonEvent.getComlTraitNames().iterator().next();
            assertEquals("TNABBR", comlTraitName.getTraitAbbr());
            assertEquals("TRT NAME DESC", comlTraitName.getTraitDesc());
            assertTrue(comlTraitName.isActive());

            assertEquals(1, nonMonEvent.getNonMonEventConstructs().size());
            NonMonEventConstruct construct = nonMonEvent.getNonMonEventConstructs().iterator().next();
            assertEquals("CON_111", construct.getConstructName());
         }
      }
   }

   @Test 
 public void testReturnsMultipleMatchingNonMonEventsWithSameChildDataForValidCrop() {
      final ComlTraitTypeBuilder comlTraitTypeBuilder =
         new ComlTraitTypeBuilder().withTraitTypeAbbr("TRTABBR").withTraitTypeDesc("TRT TYPE DESC");
      final ComlTraitNameBuilder comlTraitNameBuilder =
         new ComlTraitNameBuilder().withTraitAbbr("TNABBR").withTraitDesc("TRT NAME DESC");

      insert(new AcceptanceTestData<NonMonEvent>()
      {
         public NonMonEvent dataToInsert() {
            return new NonMonEventBuilder().
               withEventDescription("ZM_1111").
               withMaterialName("MAT NAME").
               withCropPubkey(CropBuilder.soybeans().getCropPubkey()).
               withNonMonEventConstruct(new NonMonEventConstructBuilder().
                  withConstructName("CON_111")).
               withComlTraitType(comlTraitTypeBuilder).
               withComlTraitName(comlTraitNameBuilder).
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROT NAME").
                  withProteinNamePubkey("1234").
                  withProteinDescription("PROT DESC").
                  withOrigSourceOrganism("ORIG SOURCE ORG").
                  create()).
               create();
         }
      });

      insert(new AcceptanceTestData<NonMonEvent>()
      {
         public NonMonEvent dataToInsert() {
            return new NonMonEventBuilder().
               withEventDescription("ZM_2222").
               withMaterialName("MAT NAME").
               withCropPubkey(CropBuilder.soybeans().getCropPubkey()).
               withNonMonEventConstruct(new NonMonEventConstructBuilder().
                  withConstructName("CON_111")).
               withComlTraitType(comlTraitTypeBuilder).
               withComlTraitName(comlTraitNameBuilder).
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROT NAME").
                  withProteinNamePubkey("1234").
                  withProteinDescription("PROT DESC").
                  withOrigSourceOrganism("ORIG SOURCE ORG").
                  createObj()).  /* nstub todo should this really be createObj? shouldn't it be create? */
               create();
         }
      });

      com.monsanto.tps.lexicon.nonmonevent.NonMonEvent[] nonMonEvents = nonMonEventService.findByCrop("1115");

      assertTrue(containsNonMonEvent("ZM_1111", nonMonEvents));
      assertTrue(containsNonMonEvent("ZM_2222", nonMonEvents));
      for (com.monsanto.tps.lexicon.nonmonevent.NonMonEvent nonMonEvent : nonMonEvents) {
         assertEquals("1115", nonMonEvent.getCropPubkey());
         assertEquals(true, nonMonEvent.isActive());
         if (nonMonEvent.getEventDescription().equals("ZM_1111") ||
            nonMonEvent.getEventDescription().equals("ZM_2222")) {
            assertEquals("MAT NAME", nonMonEvent.getMaterialName());
            assertEquals(1, nonMonEvent.getProteinNames().size());
            ProteinName proteinName = nonMonEvent.getProteinNames().iterator().next();
            assertEquals("PROT NAME", proteinName.getProteinName());
            assertEquals("1234", proteinName.getProteinNamePubkey());

            assertEquals(1, nonMonEvent.getComlTraitTypes().size());
            ComlTraitType comlTraitType =
               nonMonEvent.getComlTraitTypes().iterator().next();
            assertEquals("TRTABBR", comlTraitType.getComlTraitTypeAbbr());
            assertEquals("TRT TYPE DESC", comlTraitType.getComlTraitTypeDesc());

            assertEquals(1, nonMonEvent.getComlTraitNames().size());
            ComlTraitName comlTraitName =
               nonMonEvent.getComlTraitNames().iterator().next();
            assertEquals("TNABBR", comlTraitName.getTraitAbbr());
            assertEquals("TRT NAME DESC", comlTraitName.getTraitDesc());
            assertTrue(comlTraitName.isActive());

            assertEquals(1, nonMonEvent.getNonMonEventConstructs().size());
            NonMonEventConstruct construct = nonMonEvent.getNonMonEventConstructs().iterator().next();
            assertEquals("CON_111", construct.getConstructName());
         }
      }
   }

   @Test 
 public void testReturnsMultipleMatchingNonMonEventsWithDifferentChildDataForValidCrop() {
      insert(new AcceptanceTestData<NonMonEvent>()
      {
         public NonMonEvent dataToInsert() {
            return new NonMonEventBuilder().
               withEventDescription("ZM_1111").
               withCropPubkey(CropBuilder.soybeans().getCropPubkey()).
               withNonMonEventConstruct(new NonMonEventConstructBuilder().
                  withConstructName("CON_111")).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("TRTABBR1").
                  withTraitTypeDesc("TRT TYPE DESC 1")).
               withComlTraitName(new ComlTraitNameBuilder().
                  withTraitAbbr("TNABBR1").
                  withTraitDesc("TRT NAME DESC 1")).
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROT NAME 1").
                  withProteinNamePubkey("12341").
                  withProteinDescription("PROT DESC 1").
                  withOrigSourceOrganism("ORIG SOURCE ORG 1").create()).
               create();
         }
      });

      insert(new AcceptanceTestData<NonMonEvent>()
      {
         public NonMonEvent dataToInsert() {
            return new NonMonEventBuilder().
               withEventDescription("ZM_2222").
               withCropPubkey(CropBuilder.soybeans().getCropPubkey()).
               withNonMonEventConstruct(new NonMonEventConstructBuilder().
                  withConstructName("CON_222")).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("TRTABBR2").
                  withTraitTypeDesc("TRT TYPE DESC 2")).
               withComlTraitName(new ComlTraitNameBuilder().
                  withTraitAbbr("TNABBR2").
                  withTraitDesc("TRT NAME DESC 2")).
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROT NAME 2").
                  withProteinNamePubkey("12342").
                  withProteinDescription("PROT DESC 2").
                  withOrigSourceOrganism("ORIG SOURCE ORG 2").create()).
               create();
         }
      });

      com.monsanto.tps.lexicon.nonmonevent.NonMonEvent[] nonMonEvents = nonMonEventService.findByCrop("1115");

      assertTrue(containsNonMonEvent("ZM_1111", nonMonEvents));
      assertTrue(containsNonMonEvent("ZM_2222", nonMonEvents));
      for (com.monsanto.tps.lexicon.nonmonevent.NonMonEvent nonMonEvent : nonMonEvents) {
         assertEquals("1115", nonMonEvent.getCropPubkey());
         assertEquals(true, nonMonEvent.isActive());
         if (nonMonEvent.getEventDescription().equals("ZM_1111")) {
            assertEquals(1, nonMonEvent.getProteinNames().size());
            ProteinName proteinName = nonMonEvent.getProteinNames().iterator().next();
            assertEquals("PROT NAME 1", proteinName.getProteinName());
            assertEquals("12341", proteinName.getProteinNamePubkey());

            assertEquals(1, nonMonEvent.getComlTraitTypes().size());
            ComlTraitType comlTraitType = nonMonEvent.getComlTraitTypes().iterator().next();
            assertEquals("TRTABBR1", comlTraitType.getComlTraitTypeAbbr());
            assertEquals("TRT TYPE DESC 1", comlTraitType.getComlTraitTypeDesc());

            assertEquals(1, nonMonEvent.getComlTraitNames().size());
            ComlTraitName comlTraitName =
               nonMonEvent.getComlTraitNames().iterator().next();
            assertEquals("TNABBR1", comlTraitName.getTraitAbbr());
            assertEquals("TRT NAME DESC 1", comlTraitName.getTraitDesc());
            assertTrue(comlTraitName.isActive());

            assertEquals(1, nonMonEvent.getNonMonEventConstructs().size());
            NonMonEventConstruct construct = nonMonEvent.getNonMonEventConstructs().iterator().next();
            assertEquals("CON_111", construct.getConstructName());
         }
         else if (nonMonEvent.getEventDescription().equals("ZM_2222")) {
            assertEquals(1, nonMonEvent.getProteinNames().size());
            ProteinName proteinName = nonMonEvent.getProteinNames().iterator().next();
            assertEquals("PROT NAME 2", proteinName.getProteinName());
            assertEquals("12342", proteinName.getProteinNamePubkey());

            assertEquals(1, nonMonEvent.getComlTraitTypes().size());
            ComlTraitType comlTraitType =
               nonMonEvent.getComlTraitTypes().iterator().next();
            assertEquals("TRTABBR2", comlTraitType.getComlTraitTypeAbbr());
            assertEquals("TRT TYPE DESC 2", comlTraitType.getComlTraitTypeDesc());

            assertEquals(1, nonMonEvent.getComlTraitNames().size());
            ComlTraitName comlTraitName =
               nonMonEvent.getComlTraitNames().iterator().next();
            assertEquals("TNABBR2", comlTraitName.getTraitAbbr());
            assertEquals("TRT NAME DESC 2", comlTraitName.getTraitDesc());
            assertTrue(comlTraitName.isActive());

            assertEquals(1, nonMonEvent.getNonMonEventConstructs().size());
            NonMonEventConstruct construct = nonMonEvent.getNonMonEventConstructs().iterator().next();
            assertEquals("CON_222", construct.getConstructName());
         }
      }
   }

   @Test 
 public void testReturnsNoDataForNonActiveNonMonEventByCrop() {
      insert(new AcceptanceTestData<NonMonEvent>()
      {
         public NonMonEvent dataToInsert() {
            return new NonMonEventBuilder().
               withEventDescription("ZM_1111").
               withCropPubkey(CropBuilder.soybeans().getCropPubkey()).
               withActiveStatus(false).
               withNonMonEventConstruct(new NonMonEventConstructBuilder().
                  withConstructName("CON_111")).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("TRTABBR").
                  withTraitTypeDesc("TRT TYPE DESC")).
               withComlTraitName(new ComlTraitNameBuilder().
                  withTraitAbbr("TNABBR").
                  withTraitDesc("TRT NAME DESC")).
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROT NAME").
                  withProteinNamePubkey("1234").
                  withProteinDescription("PROT DESC").
                  withOrigSourceOrganism("ORIG SOURCE ORG").create()).
               create();
         }
      });

      com.monsanto.tps.lexicon.nonmonevent.NonMonEvent[] nonMonEvents = nonMonEventService.findByCrop("1115");

      assertFalse(containsNonMonEvent("ZM_1111", nonMonEvents));
   }

   @Test 
 public void testReturnsNoDataForInvalidCrop() {
      com.monsanto.tps.lexicon.nonmonevent.NonMonEvent[] nonMonEvents = nonMonEventService.findByCrop("InvalidCropPubkey");

      assertEquals(0, nonMonEvents.length);
   }

   @Test 
 public void testReturnsMatchingNonMonEventWithSingleChildDataForValidNonMonEvent() {
      insert(new AcceptanceTestData<NonMonEvent>()
      {
         public NonMonEvent dataToInsert() {
            return new NonMonEventBuilder().
               withEventDescription("ZM_1111").
               withCropPubkey(CropBuilder.soybeans().getCropPubkey()).
               withNonMonEventConstruct(new NonMonEventConstructBuilder().
                  withConstructName("CON_111")).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("TRTABBR").
                  withTraitTypeDesc("TRT TYPE DESC")).
               withComlTraitName(new ComlTraitNameBuilder().
                  withTraitAbbr("TNABBR").
                  withTraitDesc("TRT NAME DESC")).
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROT NAME").
                  withProteinNamePubkey("1234").
                  withProteinDescription("PROT DESC").
                  withOrigSourceOrganism("ORIG SOURCE ORG").create()).
               create();
         }
      });

      com.monsanto.tps.lexicon.nonmonevent.NonMonEvent[] nonMonEvents = nonMonEventService.findByNonMonEvent("ZM_1111");

      assertTrue(containsNonMonEvent("ZM_1111", nonMonEvents));
      for (com.monsanto.tps.lexicon.nonmonevent.NonMonEvent nonMonEvent : nonMonEvents) {
         assertEquals("1115", nonMonEvent.getCropPubkey());
         assertEquals(true, nonMonEvent.isActive());
         if (nonMonEvent.getEventDescription().equals("ZM_1111")) {
            assertEquals(1, nonMonEvent.getProteinNames().size());
            ProteinName proteinName = nonMonEvent.getProteinNames().iterator().next();
            assertEquals("PROT NAME", proteinName.getProteinName());
            assertEquals("1234", proteinName.getProteinNamePubkey());

            assertEquals(1, nonMonEvent.getComlTraitTypes().size());
            ComlTraitType comlTraitType = nonMonEvent.getComlTraitTypes().iterator().next();
            assertEquals("TRTABBR", comlTraitType.getComlTraitTypeAbbr());
            assertEquals("TRT TYPE DESC", comlTraitType.getComlTraitTypeDesc());

            assertEquals(1, nonMonEvent.getComlTraitNames().size());
            ComlTraitName comlTraitName = nonMonEvent.getComlTraitNames().iterator().next();
            assertEquals("TNABBR", comlTraitName.getTraitAbbr());
            assertEquals("TRT NAME DESC", comlTraitName.getTraitDesc());
            assertTrue(comlTraitName.isActive());

            assertEquals(1, nonMonEvent.getNonMonEventConstructs().size());
            NonMonEventConstruct construct = nonMonEvent.getNonMonEventConstructs().iterator().next();
            assertEquals("CON_111", construct.getConstructName());
         }
      }
   }

   @Test 
 public void testReturnsMultipleMatchingNonMonEventsWithSameChildDataForValidNonMonEvent() {
      final ComlTraitTypeBuilder comlTraitTypeBuilder =
         new ComlTraitTypeBuilder().withTraitTypeAbbr("TRTABBR").withTraitTypeDesc("TRT TYPE DESC");
      final ComlTraitNameBuilder comlTraitNameBuilder =
         new ComlTraitNameBuilder().withTraitAbbr("TNABBR").withTraitDesc("TRT NAME DESC");

      insert(new AcceptanceTestData<NonMonEvent>()
      {
         public NonMonEvent dataToInsert() {
            return new NonMonEventBuilder().
               withEventDescription("ZM_1111").
               withCropPubkey(CropBuilder.soybeans().getCropPubkey()).
               withNonMonEventConstruct(new NonMonEventConstructBuilder().
                  withConstructName("CON_111")).
               withComlTraitType(comlTraitTypeBuilder).
               withComlTraitName(comlTraitNameBuilder).
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROT NAME").
                  withProteinNamePubkey("1234").
                  withProteinDescription("PROT DESC").
                  withOrigSourceOrganism("ORIG SOURCE ORG").
                  create()).
               create();
         }
      });

      insert(new AcceptanceTestData<NonMonEvent>()
      {
         public NonMonEvent dataToInsert() {
            return new NonMonEventBuilder().
               withEventDescription("ZM_1111").
               withCropPubkey(CropBuilder.corn().getCropPubkey()).
               withNonMonEventConstruct(new NonMonEventConstructBuilder().
                  withConstructName("CON_111")).
               withComlTraitType(comlTraitTypeBuilder).
               withComlTraitName(comlTraitNameBuilder).
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROT NAME").
                  withProteinNamePubkey("1234").
                  withProteinDescription("PROT DESC").
                  withOrigSourceOrganism("ORIG SOURCE ORG").
                  createObj()).
               create();
         }
      });

      com.monsanto.tps.lexicon.nonmonevent.NonMonEvent[] nonMonEvents =
         nonMonEventService.findByNonMonEvent("ZM_1111");

      assertTrue(containsNonMonEvent("ZM_1111", nonMonEvents));
      boolean soybeanEventFound = false;
      boolean cornEventFound = false;
      for (com.monsanto.tps.lexicon.nonmonevent.NonMonEvent nonMonEvent : nonMonEvents) {
         assertEquals(true, nonMonEvent.isActive());
         if (nonMonEvent.getEventDescription().equals("ZM_1111")) {
            if (nonMonEvent.getCropPubkey().equals("1115")) {
               soybeanEventFound = true;
            }
            else if (nonMonEvent.getCropPubkey().equals("1015")) {
               cornEventFound = true;
            }
            assertEquals(1, nonMonEvent.getProteinNames().size());
            ProteinName proteinName = nonMonEvent.getProteinNames().iterator().next();
            assertEquals("PROT NAME", proteinName.getProteinName());
            assertEquals("1234", proteinName.getProteinNamePubkey());

            assertEquals(1, nonMonEvent.getComlTraitTypes().size());
            ComlTraitType comlTraitType = nonMonEvent.getComlTraitTypes().iterator().next();
            assertEquals("TRTABBR", comlTraitType.getComlTraitTypeAbbr());
            assertEquals("TRT TYPE DESC", comlTraitType.getComlTraitTypeDesc());

            assertEquals(1, nonMonEvent.getComlTraitNames().size());
            ComlTraitName comlTraitName =
               nonMonEvent.getComlTraitNames().iterator().next();
            assertEquals("TNABBR", comlTraitName.getTraitAbbr());
            assertEquals("TRT NAME DESC", comlTraitName.getTraitDesc());
            assertTrue(comlTraitName.isActive());

            assertEquals(1, nonMonEvent.getNonMonEventConstructs().size());
            NonMonEventConstruct construct = nonMonEvent.getNonMonEventConstructs().iterator().next();
            assertEquals("CON_111", construct.getConstructName());
         }
      }

      assertTrue(soybeanEventFound);
      assertTrue(cornEventFound);
   }

   @Test 
 public void testReturnsMultipleMatchingNonMonEventsWithDifferentChildDataForValidNonMonEvent() {
      insert(new AcceptanceTestData<NonMonEvent>()
      {
         public NonMonEvent dataToInsert() {
            return new NonMonEventBuilder().
               withEventDescription("ZM_1111").
               withCropPubkey(CropBuilder.soybeans().getCropPubkey()).
               withNonMonEventConstruct(new NonMonEventConstructBuilder().
                  withConstructName("CON_111")).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("TRTABBR1").
                  withTraitTypeDesc("TRT TYPE DESC 1")).
               withComlTraitName(new ComlTraitNameBuilder().
                  withTraitAbbr("TNABBR1").
                  withTraitDesc("TRT NAME DESC 1")).
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROT NAME 1").
                  withProteinNamePubkey("12341").
                  withProteinDescription("PROT DESC 1").
                  withOrigSourceOrganism("ORIG SOURCE ORG 1").create()).
               create();
         }
      });

      insert(new AcceptanceTestData<NonMonEvent>()
      {
         public NonMonEvent dataToInsert() {
            return new NonMonEventBuilder().
               withEventDescription("ZM_1111").
               withCropPubkey(CropBuilder.corn().getCropPubkey()).
               withNonMonEventConstruct(new NonMonEventConstructBuilder().
                  withConstructName("CON_222")).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("TRTABBR2").
                  withTraitTypeDesc("TRT TYPE DESC 2")).
               withComlTraitName(new ComlTraitNameBuilder().
                  withTraitAbbr("TNABBR2").
                  withTraitDesc("TRT NAME DESC 2")).
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROT NAME 2").
                  withProteinNamePubkey("12342").
                  withProteinDescription("PROT DESC 2").
                  withOrigSourceOrganism("ORIG SOURCE ORG 2").create()).
               create();
         }
      });

      com.monsanto.tps.lexicon.nonmonevent.NonMonEvent[] nonMonEvents = nonMonEventService.findByNonMonEvent("ZM_1111");

      assertTrue(containsNonMonEvent("ZM_1111", nonMonEvents));
      boolean soybeanEventFound = false;
      boolean cornEventFound = false;
      for (com.monsanto.tps.lexicon.nonmonevent.NonMonEvent nonMonEvent : nonMonEvents) {
         assertEquals(true, nonMonEvent.isActive());
         if (nonMonEvent.getEventDescription().equals("ZM_1111")) {
            if (nonMonEvent.getCropPubkey().equals("1115")) {
               soybeanEventFound = true;
               assertEquals(1, nonMonEvent.getProteinNames().size());
               ProteinName proteinName = nonMonEvent.getProteinNames().iterator().next();
               assertEquals("PROT NAME 1", proteinName.getProteinName());
               assertEquals("12341", proteinName.getProteinNamePubkey());

               assertEquals(1, nonMonEvent.getComlTraitTypes().size());
               ComlTraitType comlTraitType = nonMonEvent.getComlTraitTypes().iterator().next();
               assertEquals("TRTABBR1", comlTraitType.getComlTraitTypeAbbr());
               assertEquals("TRT TYPE DESC 1", comlTraitType.getComlTraitTypeDesc());

               assertEquals(1, nonMonEvent.getComlTraitNames().size());
               ComlTraitName comlTraitName = nonMonEvent.getComlTraitNames().iterator().next();
               assertEquals("TNABBR1", comlTraitName.getTraitAbbr());
               assertEquals("TRT NAME DESC 1", comlTraitName.getTraitDesc());
               assertTrue(comlTraitName.isActive());

               assertEquals(1, nonMonEvent.getNonMonEventConstructs().size());
               NonMonEventConstruct construct = nonMonEvent.getNonMonEventConstructs().iterator().next();
               assertEquals("CON_111", construct.getConstructName());
            }
            else if (nonMonEvent.getCropPubkey().equals("1015")) {
               cornEventFound = true;
               assertEquals(1, nonMonEvent.getProteinNames().size());
               ProteinName proteinName = nonMonEvent.getProteinNames().iterator().next();
               assertEquals("PROT NAME 2", proteinName.getProteinName());
               assertEquals("12342", proteinName.getProteinNamePubkey());

               assertEquals(1, nonMonEvent.getComlTraitTypes().size());
               ComlTraitType comlTraitType = nonMonEvent.getComlTraitTypes().iterator().next();
               assertEquals("TRTABBR2", comlTraitType.getComlTraitTypeAbbr());
               assertEquals("TRT TYPE DESC 2", comlTraitType.getComlTraitTypeDesc());

               assertEquals(1, nonMonEvent.getComlTraitNames().size());
               ComlTraitName comlTraitName = nonMonEvent.getComlTraitNames().iterator().next();
               assertEquals("TNABBR2", comlTraitName.getTraitAbbr());
               assertEquals("TRT NAME DESC 2", comlTraitName.getTraitDesc());
               assertTrue(comlTraitName.isActive());

               assertEquals(1, nonMonEvent.getNonMonEventConstructs().size());
               NonMonEventConstruct construct = nonMonEvent.getNonMonEventConstructs().iterator().next();
               assertEquals("CON_222", construct.getConstructName());
            }
         }
      }

      assertTrue(soybeanEventFound);
      assertTrue(cornEventFound);
   }

   @Test 
 public void testReturnsNoDataForNonActiveNonMonEventByNonMonEvent() {
      insert(new AcceptanceTestData<NonMonEvent>()
      {
         public NonMonEvent dataToInsert() {
            return new NonMonEventBuilder().
               withEventDescription("ZM_1111").
               withCropPubkey(CropBuilder.soybeans().getCropPubkey()).
               withActiveStatus(false).
               withNonMonEventConstruct(new NonMonEventConstructBuilder().
                  withConstructName("CON_111")).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("TRTABBR").
                  withTraitTypeDesc("TRT TYPE DESC")).
               withComlTraitName(new ComlTraitNameBuilder().
                  withTraitAbbr("TNABBR").
                  withTraitDesc("TRT NAME DESC")).
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROT NAME").
                  withProteinNamePubkey("1234").
                  withProteinDescription("PROT DESC").
                  withOrigSourceOrganism("ORIG SOURCE ORG").create()).
               create();
         }
      });

      com.monsanto.tps.lexicon.nonmonevent.NonMonEvent[] nonMonEvents =
         nonMonEventService.findByNonMonEvent("ZM_1111");

      assertFalse(containsNonMonEvent("ZM_1111", nonMonEvents));
   }

   @Test 
 public void testReturnsNoDataForInvalidNonMonEvent() {
      com.monsanto.tps.lexicon.nonmonevent.NonMonEvent[] nonMonEvents =
         nonMonEventService.findByNonMonEvent("InvalidNonMonEvent");

      assertEquals(0, nonMonEvents.length);
   }

   @Test 
 public void testFindByNonMonEventAndCrop_ReturnsMatchingNonMonEventWithSingleChildDataForValidCropAndNonMonEvent() {
      insert(new AcceptanceTestData<NonMonEvent>()
      {
         public NonMonEvent dataToInsert() {
            return new NonMonEventBuilder().
               withEventDescription("ZM_1111").
               withCropPubkey(CropBuilder.soybeans().getCropPubkey()).
               withNonMonEventConstruct(new NonMonEventConstructBuilder().
                  withConstructName("CON_111")).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("TRTABBR").
                  withTraitTypeDesc("TRT TYPE DESC")).
               withComlTraitName(new ComlTraitNameBuilder().
                  withTraitAbbr("TNABBR").
                  withTraitDesc("TRT NAME DESC")).
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROT NAME").
                  withProteinNamePubkey("1234").
                  withProteinDescription("PROT DESC").
                  withOrigSourceOrganism("ORIG SOURCE ORG").create()).
               create();
         }
      });

      com.monsanto.tps.lexicon.nonmonevent.NonMonEvent[] nonMonEvents = nonMonEventService.findByNonMonEventAndCrop("ZM_1111", CropBuilder.soybeans().getCropPubkey());

      assertTrue(containsNonMonEvent("ZM_1111", nonMonEvents));
      for (com.monsanto.tps.lexicon.nonmonevent.NonMonEvent nonMonEvent : nonMonEvents) {
         assertEquals("1115", nonMonEvent.getCropPubkey());
         assertEquals(true, nonMonEvent.isActive());
         if (nonMonEvent.getEventDescription().equals("ZM_1111")) {
            assertEquals(1, nonMonEvent.getProteinNames().size());
            ProteinName proteinName = nonMonEvent.getProteinNames().iterator().next();
            assertEquals("PROT NAME", proteinName.getProteinName());
            assertEquals("1234", proteinName.getProteinNamePubkey());

            assertEquals(1, nonMonEvent.getComlTraitTypes().size());
            ComlTraitType comlTraitType = nonMonEvent.getComlTraitTypes().iterator().next();
            assertEquals("TRTABBR", comlTraitType.getComlTraitTypeAbbr());
            assertEquals("TRT TYPE DESC", comlTraitType.getComlTraitTypeDesc());

            assertEquals(1, nonMonEvent.getComlTraitNames().size());
            ComlTraitName comlTraitName = nonMonEvent.getComlTraitNames().iterator().next();
            assertEquals("TNABBR", comlTraitName.getTraitAbbr());
            assertEquals("TRT NAME DESC", comlTraitName.getTraitDesc());
            assertTrue(comlTraitName.isActive());

            assertEquals(1, nonMonEvent.getNonMonEventConstructs().size());
            NonMonEventConstruct construct = nonMonEvent.getNonMonEventConstructs().iterator().next();
            assertEquals("CON_111", construct.getConstructName());
         }
      }
   }

   @Test 
 public void testFindByNonMonEventAndCrop_ReturnsMultipleMatchingNonMonEventsWithSameChildDataForValidCropAndNonMonEvent() {
      final ComlTraitTypeBuilder comlTraitTypeBuilder =
         new ComlTraitTypeBuilder().withTraitTypeAbbr("TRTABBR").withTraitTypeDesc("TRT TYPE DESC");
      final ComlTraitNameBuilder comlTraitNameBuilder =
         new ComlTraitNameBuilder().withTraitAbbr("TNABBR").withTraitDesc("TRT NAME DESC");

      insert(new AcceptanceTestData<NonMonEvent>()
      {
         public NonMonEvent dataToInsert() {
            return new NonMonEventBuilder().
               withEventDescription("ZM_1111").
               withCropPubkey(CropBuilder.soybeans().getCropPubkey()).
               withNonMonEventConstruct(new NonMonEventConstructBuilder().
                  withConstructName("CON_111")).
               withComlTraitType(comlTraitTypeBuilder).
               withComlTraitName(comlTraitNameBuilder).
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROT NAME").
                  withProteinNamePubkey("1234").
                  withProteinDescription("PROT DESC").
                  withOrigSourceOrganism("ORIG SOURCE ORG").
                  create()).
               create();
         }
      });

      insert(new AcceptanceTestData<NonMonEvent>()
      {
         public NonMonEvent dataToInsert() {
            return new NonMonEventBuilder().
               withEventDescription("ZM_1111").
               withCropPubkey(CropBuilder.soybeans().getCropPubkey()).
               withNonMonEventConstruct(new NonMonEventConstructBuilder().
                  withConstructName("CON_111")).
               withComlTraitType(comlTraitTypeBuilder).
               withComlTraitName(comlTraitNameBuilder).
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROT NAME").
                  withProteinNamePubkey("1234").
                  withProteinDescription("PROT DESC").
                  withOrigSourceOrganism("ORIG SOURCE ORG").
                  createObj()).
               create();
         }
      });

      com.monsanto.tps.lexicon.nonmonevent.NonMonEvent[] nonMonEvents =
         nonMonEventService.findByNonMonEventAndCrop("ZM_1111", CropBuilder.soybeans().getCropPubkey());

      assertTrue(containsNonMonEvent("ZM_1111", nonMonEvents));
      int eventFound = 0;
      for (com.monsanto.tps.lexicon.nonmonevent.NonMonEvent nonMonEvent : nonMonEvents) {
         assertEquals(true, nonMonEvent.isActive());
         if (nonMonEvent.getEventDescription().equals("ZM_1111")) {
            eventFound++;
            assertEquals(1, nonMonEvent.getProteinNames().size());
            ProteinName proteinName = nonMonEvent.getProteinNames().iterator().next();
            assertEquals("PROT NAME", proteinName.getProteinName());
            assertEquals("1234", proteinName.getProteinNamePubkey());

            assertEquals(1, nonMonEvent.getComlTraitTypes().size());
            ComlTraitType comlTraitType = nonMonEvent.getComlTraitTypes().iterator().next();
            assertEquals("TRTABBR", comlTraitType.getComlTraitTypeAbbr());
            assertEquals("TRT TYPE DESC", comlTraitType.getComlTraitTypeDesc());

            assertEquals(1, nonMonEvent.getComlTraitNames().size());
            ComlTraitName comlTraitName =
               nonMonEvent.getComlTraitNames().iterator().next();
            assertEquals("TNABBR", comlTraitName.getTraitAbbr());
            assertEquals("TRT NAME DESC", comlTraitName.getTraitDesc());
            assertTrue(comlTraitName.isActive());

            assertEquals(1, nonMonEvent.getNonMonEventConstructs().size());
            NonMonEventConstruct construct = nonMonEvent.getNonMonEventConstructs().iterator().next();
            assertEquals("CON_111", construct.getConstructName());
         }
      }

      assertEquals(2, eventFound);
   }

   @Test 
 public void testFindByNonMonEventAndCrop_ReturnsMultipleMatchingNonMonEventsWithDifferentChildDataForValidCropAndNonMonEvent() {
      insert(new AcceptanceTestData<NonMonEvent>()
      {
         public NonMonEvent dataToInsert() {
            return new NonMonEventBuilder().
               withEventDescription("ZM_1111").
               withCropPubkey(CropBuilder.soybeans().getCropPubkey()).
               withNonMonEventConstruct(new NonMonEventConstructBuilder().
                  withConstructName("CON_111")).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("TRTABBR1").
                  withTraitTypeDesc("TRT TYPE DESC 1")).
               withComlTraitName(new ComlTraitNameBuilder().
                  withTraitAbbr("TNABBR1").
                  withTraitDesc("TRT NAME DESC 1")).
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROT NAME 1").
                  withProteinNamePubkey("12341").
                  withProteinDescription("PROT DESC 1").
                  withOrigSourceOrganism("ORIG SOURCE ORG 1").create()).
               create();
         }
      });

      insert(new AcceptanceTestData<NonMonEvent>()
      {
         public NonMonEvent dataToInsert() {
            return new NonMonEventBuilder().
               withEventDescription("ZM_1111").
               withCropPubkey(CropBuilder.soybeans().getCropPubkey()).
               withNonMonEventConstruct(new NonMonEventConstructBuilder().
                  withConstructName("CON_222")).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("TRTABBR2").
                  withTraitTypeDesc("TRT TYPE DESC 2")).
               withComlTraitName(new ComlTraitNameBuilder().
                  withTraitAbbr("TNABBR2").
                  withTraitDesc("TRT NAME DESC 2")).
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROT NAME 2").
                  withProteinNamePubkey("12342").
                  withProteinDescription("PROT DESC 2").
                  withOrigSourceOrganism("ORIG SOURCE ORG 2").create()).
               create();
         }
      });

      com.monsanto.tps.lexicon.nonmonevent.NonMonEvent[] nonMonEvents = nonMonEventService.findByNonMonEventAndCrop("ZM_1111", CropBuilder.soybeans().getCropPubkey());

      assertTrue(containsNonMonEvent("ZM_1111", nonMonEvents));
      int eventFound = 0;
      for (com.monsanto.tps.lexicon.nonmonevent.NonMonEvent nonMonEvent : nonMonEvents) {
         assertEquals(true, nonMonEvent.isActive());
         if (nonMonEvent.getEventDescription().equals("ZM_1111")) {
            eventFound++;
            assertEquals("1115", nonMonEvent.getCropPubkey());

            if ("CON_111".equals(nonMonEvent.getNonMonEventConstructs().iterator().next().getConstructName())) {
               assertEquals("1115", nonMonEvent.getCropPubkey());
               assertEquals(1, nonMonEvent.getProteinNames().size());
               ProteinName proteinName = nonMonEvent.getProteinNames().iterator().next();
               assertEquals("PROT NAME 1", proteinName.getProteinName());
               assertEquals("12341", proteinName.getProteinNamePubkey());

               assertEquals(1, nonMonEvent.getComlTraitTypes().size());
               ComlTraitType comlTraitType = nonMonEvent.getComlTraitTypes().iterator().next();
               assertEquals("TRTABBR1", comlTraitType.getComlTraitTypeAbbr());
               assertEquals("TRT TYPE DESC 1", comlTraitType.getComlTraitTypeDesc());

               assertEquals(1, nonMonEvent.getComlTraitNames().size());
               ComlTraitName comlTraitName = nonMonEvent.getComlTraitNames().iterator().next();
               assertEquals("TNABBR1", comlTraitName.getTraitAbbr());
               assertEquals("TRT NAME DESC 1", comlTraitName.getTraitDesc());
               assertTrue(comlTraitName.isActive());

               assertEquals(1, nonMonEvent.getNonMonEventConstructs().size());
               NonMonEventConstruct construct = nonMonEvent.getNonMonEventConstructs().iterator().next();
               assertEquals("CON_111", construct.getConstructName());
            }
            else if ("CON_222".equals(nonMonEvent.getNonMonEventConstructs().iterator().next().getConstructName())) {
               assertEquals(1, nonMonEvent.getProteinNames().size());
               ProteinName proteinName = nonMonEvent.getProteinNames().iterator().next();
               assertEquals("PROT NAME 2", proteinName.getProteinName());
               assertEquals("12342", proteinName.getProteinNamePubkey());

               assertEquals(1, nonMonEvent.getComlTraitTypes().size());
               ComlTraitType comlTraitType = nonMonEvent.getComlTraitTypes().iterator().next();
               assertEquals("TRTABBR2", comlTraitType.getComlTraitTypeAbbr());
               assertEquals("TRT TYPE DESC 2", comlTraitType.getComlTraitTypeDesc());

               assertEquals(1, nonMonEvent.getComlTraitNames().size());
               ComlTraitName comlTraitName = nonMonEvent.getComlTraitNames().iterator().next();
               assertEquals("TNABBR2", comlTraitName.getTraitAbbr());
               assertEquals("TRT NAME DESC 2", comlTraitName.getTraitDesc());
               assertTrue(comlTraitName.isActive());

               assertEquals(1, nonMonEvent.getNonMonEventConstructs().size());
               NonMonEventConstruct construct = nonMonEvent.getNonMonEventConstructs().iterator().next();
               assertEquals("CON_222", construct.getConstructName());
            }
         }
      }

      assertEquals(2, eventFound);
   }

   @Test 
 public void testFindByNonMonEventAndCrop_ReturnsNoDataForNonActiveNonMonEventByCropAndNonMonEvent() {
      insert(new AcceptanceTestData<NonMonEvent>()
      {
         public NonMonEvent dataToInsert() {
            return new NonMonEventBuilder().
               withEventDescription("ZM_1111").
               withCropPubkey(CropBuilder.soybeans().getCropPubkey()).
               withActiveStatus(false).
               withNonMonEventConstruct(new NonMonEventConstructBuilder().
                  withConstructName("CON_111")).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("TRTABBR").
                  withTraitTypeDesc("TRT TYPE DESC")).
               withComlTraitName(new ComlTraitNameBuilder().
                  withTraitAbbr("TNABBR").
                  withTraitDesc("TRT NAME DESC")).
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROT NAME").
                  withProteinNamePubkey("1234").
                  withProteinDescription("PROT DESC").
                  withOrigSourceOrganism("ORIG SOURCE ORG").create()).
               create();
         }
      });

      com.monsanto.tps.lexicon.nonmonevent.NonMonEvent[] nonMonEvents =
         nonMonEventService.findByNonMonEventAndCrop("ZM_1111", CropBuilder.soybeans().getCropPubkey());

      assertFalse(containsNonMonEvent("ZM_1111", nonMonEvents));
   }

   @Test 
 public void testFindByNonMonEventAndCrop_ReturnsNoDataForValidNonMonEventAndInvalidCrop() {
      insert(new AcceptanceTestData<NonMonEvent>()
      {
         public NonMonEvent dataToInsert() {
            return new NonMonEventBuilder().
               withEventDescription("ZM_1111").
               withCropPubkey(CropBuilder.soybeans().getCropPubkey()).
               create();
         }
      });

      com.monsanto.tps.lexicon.nonmonevent.NonMonEvent[] nonMonEvents =
         nonMonEventService.findByNonMonEventAndCrop("ZM_1111", "InvalidCropPubkey");

      assertFalse(containsNonMonEvent("ZM_1111", nonMonEvents));
   }

   @Test 
 public void testFindByNonMonEventAndCrop_ReturnsNoDataForInvalidNonMonEventAndValidCrop() {
      insert(new AcceptanceTestData<NonMonEvent>()
      {
         public NonMonEvent dataToInsert() {
            return new NonMonEventBuilder().
               withEventDescription("ZM_1111").
               withCropPubkey(CropBuilder.soybeans().getCropPubkey()).
               create();
         }
      });

      com.monsanto.tps.lexicon.nonmonevent.NonMonEvent[] nonMonEvents =
         nonMonEventService.findByNonMonEventAndCrop("InvalidEvent", CropBuilder.soybeans().getCropPubkey());

      assertFalse(containsNonMonEvent("ZM_1111", nonMonEvents));
   }

   @Test 
 public void testFindByNonMonEventAndCrop_ReturnsNoDataForInvalidCropAndNonMonEvent() {
      com.monsanto.tps.lexicon.nonmonevent.NonMonEvent[] nonMonEvents =
         nonMonEventService.findByNonMonEventAndCrop("InvalidNonMonEvent", "InvalidCropPubkey");

      assertEquals(0, nonMonEvents.length);
   }

   @Test 
 public void testReturnsAllNonMonEvents() {
      insert(new AcceptanceTestData<NonMonEvent>()
      {
         public NonMonEvent dataToInsert() {
            return new NonMonEventBuilder().
               withEventDescription("ZM_1111").
               withCropPubkey(CropBuilder.soybeans().getCropPubkey()).
               withNonMonEventConstruct(new NonMonEventConstructBuilder().
                  withConstructName("CON_111")).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("TRTABBR").
                  withTraitTypeDesc("TRT TYPE DESC")).
               withComlTraitName(new ComlTraitNameBuilder().
                  withTraitAbbr("TNABBR").
                  withTraitDesc("TRT NAME DESC")).
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROT NAME").
                  withProteinNamePubkey("1234").
                  withProteinDescription("PROT DESC").
                  withOrigSourceOrganism("ORIG SOURCE ORG").create()).
               create();
         }
      });

      com.monsanto.tps.lexicon.nonmonevent.NonMonEvent[] nonMonEvents = nonMonEventService.findAll();

      assertTrue(containsNonMonEvent("ZM_1111", nonMonEvents));
   }

   private boolean containsNonMonEvent(String nonMonEventDescription, com.monsanto.tps.lexicon.nonmonevent.NonMonEvent[] nonMonEvents) {
      for (com.monsanto.tps.lexicon.nonmonevent.NonMonEvent nonMonEvent : nonMonEvents) {
         if (nonMonEventDescription.equals(nonMonEvent.getEventDescription())) {
            return true;
         }
      }
      return false;
   }
}
