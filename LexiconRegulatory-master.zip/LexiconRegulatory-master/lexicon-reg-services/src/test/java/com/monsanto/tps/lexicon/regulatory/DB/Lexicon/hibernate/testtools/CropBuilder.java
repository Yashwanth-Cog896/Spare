package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Crop;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

/**
 * nbwald - Aug 26, 2008 4:19:05 PM
 */
public class CropBuilder
{
   public static Crop corn() {
      return findCropByName("CORN");
   }

   public static Crop soybeans() {
      return findCropByName("SOYBEANS");
   }

   private static Crop findCropByName(String cropName) {
      Criteria cropByNameCriteria = TestSessions.getLexiconSession().createCriteria(Crop.class).add(Restrictions.eq("cropName", cropName));
      return (Crop) cropByNameCriteria.uniqueResult();
   }

   public static Crop canola() {
      return findCropByName("OSR-CANOLA");
   }
}
