package com.monsanto.tps.lexicon.regulatory.storagecondition.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.DBUnitTest;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.StorageCondition;
import com.monsanto.tps.springframework.test.listener.dbunit.DBUnitTestExecutionListener;
import com.monsanto.tps.springframework.test.listener.dbunit.DataSet;
import com.monsanto.tps.springframework.test.listener.dbunit.DatasetOperation;
import com.monsanto.tps.springframework.test.listener.dbunit.Datasource;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.support.DirtiesContextTestExecutionListener;
import org.springframework.test.context.transaction.TransactionalTestExecutionListener;
import org.springframework.transaction.annotation.Transactional;

import java.util.Comparator;
import java.util.List;

import static com.google.common.collect.Ordering.from;
import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/1/12
 * Time: 7:47 PM
 * To change this template use File | Settings | File Templates.
 */

@DataSet(
        schema = "LEXICON", dataSourceKey = "dataSource", setupOperation = DatasetOperation.CLEAN_INSERT, teardownOperation = DatasetOperation.NONE,
        value = {"/com/monsanto/tps/lexicon/regulatory/storagecondition/dao/storage_condition.xml"}
)
public class StorageConditionDAOImpl_DUT extends DBUnitTest {

    @Autowired
    private StorageConditionDAO storageConditionDAO;

    @Test
    public void findStorageCondition_results_wildcard() throws Exception {
        final List<StorageCondition> storageConditions = storageConditionDAO.findStorageConditions("F%");
        assertNotNull(storageConditions);
        assertFalse(storageConditions.isEmpty());
    }

    @Test
    public void findStorageCondition_results_exactMatch() throws Exception {
        final List<StorageCondition> storageConditions = storageConditionDAO.findStorageConditions("dry ice");
        assertNotNull(storageConditions);
        assertFalse(storageConditions.isEmpty());
    }

    @Test
    public void findStorageCondition_noResults() throws Exception {
        final List<StorageCondition> storageConditions = storageConditionDAO.findStorageConditions("asdf");
        assertNotNull(storageConditions);
        assertTrue(storageConditions.isEmpty());
    }

    @Test
    public void findStorageCondition_results_active() throws Exception {
        final List<StorageCondition> storageConditions = storageConditionDAO.findStorageConditions("");
        assertNotNull(storageConditions);
        assertFalse(storageConditions.isEmpty());

        for (StorageCondition storageCondition : storageConditions) {
            assertTrue(storageCondition.getActiveStatus());
        }
    }

    @Test
    public void findStorageCondition_sorted() throws Exception {
        final List<StorageCondition> storageConditions = storageConditionDAO.findStorageConditions("%");
        assertNotNull(storageConditions);

        assertTrue(from(new StorageConditionComparator()).isOrdered(storageConditions));
    }

    class StorageConditionComparator implements Comparator {

        public final int compare(Object o1, Object o2) {

            int ctCompare = 0;

            StorageCondition c1 = (StorageCondition) o1;
            StorageCondition c2 = (StorageCondition) o2;

            if (c1 != null && c2 != null) {
                String ct1 = c1.getStorageCondition();
                String ct2 = c2.getStorageCondition();
                if (ct1 != null && ct2 != null) {
                    ctCompare = ct1.compareToIgnoreCase(ct2);
                }
            }

            return ctCompare;
        }
    }
}

