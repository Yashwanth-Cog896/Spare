/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.eventtraitservice.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.LexiconDataUnitTestCase;
import org.junit.Test;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.List;

import static junit.framework.Assert.*;

/* vvkalu - 7/29/11 */
public class EventConstructTraitStackDao_DUT extends LexiconDataUnitTestCase {

    @Resource
    private EventConstructTraitStackDao eventConstructTraitStackDao;

    @Test
    public void test_getComTraitStackIdByEventConstructs_ReturnsNull() throws Exception {
        List<BigDecimal> idByEventConstructs = eventConstructTraitStackDao.getComTraitStackIdByEventConstructs(7678);
        assertTrue(idByEventConstructs.isEmpty());
    }

    @Test
    public void test_getComTraitStackIdByEventConstructs() throws Exception {
        List<BigDecimal> idByEventConstructs = eventConstructTraitStackDao.getComTraitStackIdByEventConstructs(131650);
        assertNotNull(idByEventConstructs);
        assertEquals(1, idByEventConstructs.size());
        assertEquals(1031, idByEventConstructs.get(0).intValue());
    }
}