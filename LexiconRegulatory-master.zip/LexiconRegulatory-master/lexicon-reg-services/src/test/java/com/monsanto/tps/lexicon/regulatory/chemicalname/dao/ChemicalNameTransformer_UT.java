package com.monsanto.tps.lexicon.regulatory.chemicalname.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ChemicalName;
import org.hamcrest.Matchers;
import org.junit.Test;

import java.util.ArrayList;

import static junit.framework.Assert.assertEquals;
import static org.hamcrest.MatcherAssert.assertThat;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 7/18/12
 * Time: 10:17 PM
 */
public class ChemicalNameTransformer_UT {

    private ChemicalNameTransformer chemicalMaterialTransformer = new ChemicalNameTransformer();

    @Test
    public void testTransformTuple() {

        Object[] tuple = new Object[8];
        String[] aliases = new String[8];
        tuple[0] = new Long(1);
        tuple[1] = "ABOLISH";
        tuple[2] = "THIOBENCARB";
        tuple[3] = "CommercialProduct";
        tuple[4] = "Y";
        tuple[5] = "8";
        tuple[6] = "#/G";
        tuple[7] = "EMULSIFIABLE CONCENTRATE";
        ChemicalName name = (ChemicalName) chemicalMaterialTransformer.transformTuple(tuple, aliases);
        assertEquals(name.getMaterialName(), "ABOLISH");
        assertEquals(name.getActiveIngredient(), "THIOBENCARB");
        assertEquals(name.getMaterialClassification(), "CommercialProduct");
        assertEquals(name.getFormulatedAmount(), "8");
        assertEquals(name.getFormulatedAmountUnit(), "#/G");
        assertEquals(name.getFormulationDesignation(), "EMULSIFIABLE CONCENTRATE");
        assertEquals(name.getActiveStatus(), true);
    }
    @Test
    public void testTransformList() {
        ArrayList list = new ArrayList();
        ArrayList collection = (ArrayList)chemicalMaterialTransformer.transformList(list);
        assertThat(collection, Matchers.is(list));
    }
}
