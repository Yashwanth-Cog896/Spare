package com.monsanto.tps.lexicon.regulatory.plantname.business;

import com.monsanto.tps.lexicon.plantname.OrionPlantProduct;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Crop;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.PlantName;
import com.monsanto.tps.lexicon.regulatory.plantname.dao.PlantNameDAO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/1/12
 * Time: 7:47 PM
 */
@RunWith(MockitoJUnitRunner.class)
public class PlantNameBusiness_UT {

    @Mock
    private PlantNameDAO plantNameDAO;

    @InjectMocks
    private PlantNameBusiness plantNameBusiness = new PlantNameBusiness();

    private final List<PlantName> singlePlantNameListFromDAO;
    private final List<PlantName> multiPlantNameListFromDAO;
    private static final List<PlantName> emptyListFromDAO = new ArrayList<PlantName>();

    private final List<OrionPlantProduct> singlePlantNameListFromBusiness;
    private final List<OrionPlantProduct> multiPlantNameListFromBusiness;
    private static final List<OrionPlantProduct> emptyListFromBusiness = new ArrayList<OrionPlantProduct>();

    public PlantNameBusiness_UT() {
        singlePlantNameListFromDAO = new ArrayList<PlantName>();
        singlePlantNameListFromDAO.add(plantName("name", "brand", "prevName", "crop", "country", "class", true));

        multiPlantNameListFromDAO = new ArrayList<PlantName>();
        multiPlantNameListFromDAO.add(plantName("name1", "brand1", "prevName1", "crop1", "country1", "class1", true));
        multiPlantNameListFromDAO.add(plantName("name2", "brand2", "prevName2", "crop2", "country2", "class2", true));

        singlePlantNameListFromBusiness = new ArrayList<OrionPlantProduct>();
        singlePlantNameListFromBusiness.add(new OrionPlantProduct("name", "crop"));

        multiPlantNameListFromBusiness = new ArrayList<OrionPlantProduct>();
        multiPlantNameListFromBusiness.add(new OrionPlantProduct("name1", "crop1"));
        multiPlantNameListFromBusiness.add(new OrionPlantProduct("name2", "crop2"));
    }

    private PlantName plantName(String materialName, String brandName, String previousName, String cropName, String countryName, String materialClassification, boolean activeStatus) {
        PlantName plantName = new PlantName();
        plantName.setMaterialName(materialName);
        plantName.setBrand(brandName);
        plantName.setPreviousNames(previousName);
        Crop crop = new Crop();
        crop.setCropName(cropName);
        plantName.setCrop(crop);
        plantName.setCountry(countryName);
        plantName.setMaterialClassification(materialClassification);
        plantName.setActiveStatus(activeStatus);
        return plantName;
    }

    @Test
    public void findPlantName_findNone() throws Exception {

        when(plantNameDAO.findPlantNames("asdf")).thenReturn(emptyListFromDAO);

        final List<OrionPlantProduct> actualPlantNames = plantNameBusiness.findPlantNames("asdf");

        checkPlantNameLists(actualPlantNames, emptyListFromBusiness);
    }

    @Test
    public void findPlantName_findSingle() throws Exception {

        when(plantNameDAO.findPlantNames("BollGard Cotton")).thenReturn(singlePlantNameListFromDAO);

        final List<OrionPlantProduct> actualPlantNames = plantNameBusiness.findPlantNames("BollGard Cotton");

        checkPlantNameLists(actualPlantNames, singlePlantNameListFromBusiness);
    }

    @Test
    public void findPlantName_findByWildcard() throws Exception {

        when(plantNameDAO.findPlantNames("Round%")).thenReturn(multiPlantNameListFromDAO);

        final List<OrionPlantProduct> actualPlantNames = plantNameBusiness.findPlantNames("Round*");

        checkPlantNameLists(actualPlantNames, multiPlantNameListFromBusiness);
    }

    @Test
    public void findPlantName_findAll() throws Exception {

        when(plantNameDAO.findPlantNames("%")).thenReturn(multiPlantNameListFromDAO);

        final List<OrionPlantProduct> actualPlantNames = plantNameBusiness.findPlantNames("");

        checkPlantNameLists(actualPlantNames, multiPlantNameListFromBusiness);
    }

    private void checkPlantNameLists(final List<OrionPlantProduct> actualPlantNames, final List<OrionPlantProduct> singlePlantNameListFromBusiness) {
        assertNotNull(actualPlantNames);

        for(int i=0; i<singlePlantNameListFromBusiness.size(); i++) {
            final OrionPlantProduct plantName = actualPlantNames.get(i);
            assertEquals(plantName.getName(), singlePlantNameListFromBusiness.get(i).getName());
            assertEquals(plantName.getCrop(), singlePlantNameListFromBusiness.get(i).getCrop());
        }
    }
}
