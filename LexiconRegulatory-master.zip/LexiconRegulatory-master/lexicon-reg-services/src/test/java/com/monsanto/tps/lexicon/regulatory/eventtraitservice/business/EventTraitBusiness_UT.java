/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.eventtraitservice.business;

import com.monsanto.tps.lexicon.eventtraitservice.transfer.GermplasmEventTrait;
import com.monsanto.tps.lexicon.eventtraitservice.transfer.GermplasmEventTraitResponse;
import com.monsanto.tps.lexicon.eventtraitservice.transfer.TraitStack;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitStack;
import com.monsanto.tps.lexicon.regulatory.commercialtrait.dao.CommercialTraitDao;
import com.monsanto.tps.lexicon.regulatory.eventtraitservice.dao.EventConstructTraitStackDao;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

/* vvkalu - 8/1/11 */
public class EventTraitBusiness_UT {

    private static final Long GERMPLASM_ID = 33L;
    private EventTraitBusiness eventTraitBusiness;
    private ComlTraitStackBuilder comlTraitStackBuilder;
    private EventConstructTraitStackDao eventConstructTraitStackDao;
    private CommercialTraitDao commercialTraitDao;

    @Before
    public void seyUp() {
        eventTraitBusiness = new EventTraitBusiness();
        comlTraitStackBuilder = mock(ComlTraitStackBuilder.class);
        eventConstructTraitStackDao = mock(EventConstructTraitStackDao.class);
        commercialTraitDao = mock(CommercialTraitDao.class);
        eventTraitBusiness.setComlTraitStackBuilder(comlTraitStackBuilder);
        eventTraitBusiness.setCommercialTraitDao(commercialTraitDao);
        eventTraitBusiness.setEventConstructTraitStackDao(eventConstructTraitStackDao);
    }

    @Test
    public void test_When_List_Null() throws Exception {
        when(eventConstructTraitStackDao.getComTraitStackIdByEventConstructs(GERMPLASM_ID)).thenReturn(null);
        GermplasmEventTraitResponse response = new GermplasmEventTraitResponse();
        GermplasmEventTraitResponse comlTraitForEvents = eventTraitBusiness.getComlTraitForEvents(GERMPLASM_ID, response);
        assertNotNull(comlTraitForEvents);
        assertTrue(comlTraitForEvents.getGermplasmEventTraits().isEmpty());
        verifyZeroInteractions(comlTraitStackBuilder);
        verifyZeroInteractions(commercialTraitDao);
    }

    @Test
    public void test_When_List_Empty() throws Exception {
        when(eventConstructTraitStackDao.getComTraitStackIdByEventConstructs(GERMPLASM_ID)).thenReturn(new ArrayList<BigDecimal>());
        GermplasmEventTraitResponse eventTraitResponse = new GermplasmEventTraitResponse();
        GermplasmEventTraitResponse comlTraitForEvents = eventTraitBusiness.getComlTraitForEvents(GERMPLASM_ID, eventTraitResponse);
        assertNotNull(comlTraitForEvents);
        assertTrue(comlTraitForEvents.getGermplasmEventTraits().isEmpty());
        verifyZeroInteractions(comlTraitStackBuilder);
        verifyZeroInteractions(commercialTraitDao);
    }

    @Test
    public void test_When_List_HasMoreThan_One() throws Exception {
        when(eventConstructTraitStackDao.getComTraitStackIdByEventConstructs(GERMPLASM_ID)).
                thenReturn(Arrays.asList(new BigDecimal("67"), new BigDecimal("76")));
        GermplasmEventTraitResponse eventTraitResponse = new GermplasmEventTraitResponse();
        GermplasmEventTraitResponse comlTraitForEvents = eventTraitBusiness.getComlTraitForEvents(GERMPLASM_ID, eventTraitResponse);
        assertNotNull(comlTraitForEvents);
        assertTrue(comlTraitForEvents.getGermplasmEventTraits().isEmpty());
        verifyZeroInteractions(comlTraitStackBuilder);
        verifyZeroInteractions(commercialTraitDao);
    }

    @Test
    public void test_When_List_ComlTraitStack_Null() throws Exception {
        when(eventConstructTraitStackDao.getComTraitStackIdByEventConstructs(GERMPLASM_ID)).
                thenReturn(Arrays.asList(new BigDecimal("67")));
        when(commercialTraitDao.getComlTraitStackById(67)).thenReturn(null);
        GermplasmEventTraitResponse eventTraitResponse = new GermplasmEventTraitResponse();
        GermplasmEventTraitResponse comlTraitForEvents = eventTraitBusiness.getComlTraitForEvents(GERMPLASM_ID, eventTraitResponse);
        assertNotNull(comlTraitForEvents);
        assertTrue(comlTraitForEvents.getGermplasmEventTraits().isEmpty());
        verifyZeroInteractions(comlTraitStackBuilder);
    }

    @Test
    public void test_With_ComlTraitStack() throws Exception {
        when(eventConstructTraitStackDao.getComTraitStackIdByEventConstructs(GERMPLASM_ID)).
                thenReturn(Arrays.asList(new BigDecimal("67")));
        ComlTraitStack comlTraitStack = new ComlTraitStack();
        comlTraitStack.setComlTraitStackId(67);
        when(commercialTraitDao.getComlTraitStackById(67)).thenReturn(comlTraitStack);
        GermplasmEventTraitResponse traitEventConstructs = new GermplasmEventTraitResponse();
        GermplasmEventTrait germplasmEventTrait = new GermplasmEventTrait();
        germplasmEventTrait.setGermplasmId(GERMPLASM_ID);
        TraitStack traitStack = new TraitStack();
        traitStack.setComlTraitStackId(67);
        germplasmEventTrait.setTraitStack(traitStack);
        traitEventConstructs.setGermplasmEventTraits(Arrays.asList(germplasmEventTrait));
        when(comlTraitStackBuilder.buildComlTraitStack(GERMPLASM_ID, 67, comlTraitStack, traitEventConstructs)).thenReturn(traitEventConstructs);
        GermplasmEventTraitResponse comlTraitForEvents = eventTraitBusiness.getComlTraitForEvents(GERMPLASM_ID, traitEventConstructs);
        assertNotNull(comlTraitForEvents);
        assertNotNull(comlTraitForEvents.getGermplasmEventTraits().iterator().next().getTraitStack());
        assertEquals(67, comlTraitForEvents.getGermplasmEventTraits().iterator().next().getTraitStack().getComlTraitStackId());
    }

    @Test
    public void testGetComTraitStackIdByEventConstructs() {
        when(eventConstructTraitStackDao.getComTraitStackIdByEventConstructs(GERMPLASM_ID)).
                thenReturn(Arrays.asList(new BigDecimal("67")));
        List<Long> ids = eventTraitBusiness.getComTraitStackIdByEventConstructs(GERMPLASM_ID);
        assertThat(ids.size(), is(1));
        assertThat(ids.get(0), is(67L));
    }

}