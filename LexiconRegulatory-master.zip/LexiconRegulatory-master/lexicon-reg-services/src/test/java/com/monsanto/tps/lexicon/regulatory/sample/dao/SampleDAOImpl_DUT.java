package com.monsanto.tps.lexicon.regulatory.sample.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.DBUnitTest;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.SampleType;
import com.monsanto.tps.lexicon.regulatory.sample.dao.SampleDAO;
import com.monsanto.tps.springframework.test.listener.dbunit.DataSet;
import com.monsanto.tps.springframework.test.listener.dbunit.DatasetOperation;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.Comparator;
import java.util.List;

import static com.google.common.collect.Ordering.from;
import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/1/12
 * Time: 7:47 PM
 * To change this template use File | Settings | File Templates.
 */
@DataSet(
        schema = "LEXICON", dataSourceKey = "dataSource", setupOperation = DatasetOperation.CLEAN_INSERT, teardownOperation = DatasetOperation.NONE,
        value = {"/com/monsanto/tps/lexicon/regulatory/sample/dao/sample_type.xml"}
)public class SampleDAOImpl_DUT extends DBUnitTest {

    @Autowired
    private SampleDAO sampleDAO;

    @Test
    public void findSampleTypes_results_wildcard() throws Exception {
        final List<SampleType> samples = sampleDAO.findSampleTypes("Bud%");
        assertNotNull(samples);
        assertFalse(samples.isEmpty());
    }

    @Test
    public void findSampleTypes_results_exactMatch() throws Exception {
        final List<SampleType> samples = sampleDAO.findSampleTypes("Bloom");
        assertNotNull(samples);
        assertFalse(samples.isEmpty());
    }

    @Test
    public void findSampleTypes_noResults() throws Exception {
        final List<SampleType> samples = sampleDAO.findSampleTypes("asdf");
        assertNotNull(samples);
        assertTrue(samples.isEmpty());
    }

    @Test
    public void findSampleTypes_results_active() throws Exception {
        final List<SampleType> samples = sampleDAO.findSampleTypes("");
        assertFalse(samples.isEmpty());

        for (SampleType sample : samples) {
            assertTrue(sample.getActiveStatus());
        }
    }

    @Test
    public void findSampleTypes_sorted() throws Exception {
        final List<SampleType> samples = sampleDAO.findSampleTypes("%");
        assertNotNull(samples);

        assertTrue(from(new SampleComparator()).isOrdered(samples));
    }

    private class SampleComparator implements Comparator<SampleType> {

        public final int compare(SampleType c1, SampleType c2) {

            int ctCompare = 0;

            if (c1 != null && c2 != null) {
                String ct1 = c1.getSampleType();
                String ct2 = c2.getSampleType();
                if (ct1 != null && ct2 != null) {
                    ctCompare = ct1.compareToIgnoreCase(ct2);
                }
            }

            return ctCompare;
        }
    }
}

