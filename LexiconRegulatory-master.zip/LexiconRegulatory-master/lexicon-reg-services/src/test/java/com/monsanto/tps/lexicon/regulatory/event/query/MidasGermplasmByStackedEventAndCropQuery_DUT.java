package com.monsanto.tps.lexicon.regulatory.event.query;

import com.monsanto.tps.lexicon.regulatory.DB.TestUtil.TPSTestConstants;

/**
 * rrchak1 - Jul 15, 2009 4:52:43 PM
 */
public class MidasGermplasmByStackedEventAndCropQuery_DUT
        extends com.monsanto.tps.lexicon.regulatory.DB.Midas.Tests.MidasDataTestCase {

    private final String stackedEvent = "101-5-1,ZM_M2598";
    private final String stackedEventMixedCase = "101-5-1,zM_m2598";
    private final String nonexistentStack = "101074781,101074801";
    private final long stackedGermplasmId = 1872246210710L;


    public void testFind_NoResults()
            throws Exception {
        MidasGermplasmByStackedEventAndCropQuery query =
                new MidasGermplasmByStackedEventAndCropQuery(nonexistentStack, TPSTestConstants.CORN_GENUS_SPECIES);
        Long germplasmIds = query.getSingleGermplasmId();

        assertNull(germplasmIds);

    }

    public void testFind_EventsBelongToSameGermplasmAndGermplasmHasOnlyTheseEvents_ReturnsGermplasmId()
            throws Exception {

        MidasGermplasmByStackedEventAndCropQuery query =
                new MidasGermplasmByStackedEventAndCropQuery(stackedEvent, TPSTestConstants.CORN_GENUS_SPECIES);
        Long germplasmId = query.getSingleGermplasmId();

        assertNotNull(germplasmId);
        assertEquals(new Long(stackedGermplasmId), germplasmId);
    }

    public void testFind_EventsBelongToSameGermplasmAndGermplasmHasOnlyTheseEventsMixedCase_ReturnsGermplasmId()
            throws Exception {

        MidasGermplasmByStackedEventAndCropQuery query =
                new MidasGermplasmByStackedEventAndCropQuery(stackedEventMixedCase, TPSTestConstants.CORN_GENUS_SPECIES);
        Long germplasmId = query.getSingleGermplasmId();

        assertNotNull(germplasmId);
        assertEquals(new Long(stackedGermplasmId), germplasmId);
    }

}
