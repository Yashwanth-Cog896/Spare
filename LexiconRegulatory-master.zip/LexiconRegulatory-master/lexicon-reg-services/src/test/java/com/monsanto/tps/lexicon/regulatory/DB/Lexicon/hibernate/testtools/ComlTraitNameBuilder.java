package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Company;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.DataFilter;
import org.hibernate.Session;

/**
 * Created by IntelliJ IDEA.
 * User: gdleon
 * Date: May 7, 2009
 * Time: 9:19:39 AM
 */
public class ComlTraitNameBuilder
{
   private ComlTraitName comlTraitName;

   public ComlTraitNameBuilder() {
      BuilderID builderID = new BuilderID();
      comlTraitName = new ComlTraitName();
      comlTraitName.setComlTraitNameId(builderID.id());
      comlTraitName.setTraitAbbr(builderID.sid(8));
      comlTraitName.setTraitDesc(builderID.sid(50));
      comlTraitName.setCompany(CompanyBuilder.monsanto());
      comlTraitName.setActive(true);
   }

   public ComlTraitNameBuilder withTraitAbbr(String traitAbbr) {
      this.comlTraitName.setTraitAbbr(traitAbbr);
      return this;
   }

   public ComlTraitNameBuilder withTraitDesc(String traitDesc) {
      this.comlTraitName.setTraitDesc(traitDesc);
      return this;
   }

   public ComlTraitNameBuilder withCompany(Company company) {
      this.comlTraitName.setCompany(company);
      return this;
   }

   public ComlTraitName create() {
      Session session = TestSessions.getLexiconSession();
      session.save(comlTraitName);
      return comlTraitName;
   }

   public ComlTraitName createObj() {
      return comlTraitName;
   }

   public ComlTraitNameBuilder withDataFilter(DataFilter dataFilter) {
      this.comlTraitName.getDataFilters().add(dataFilter);
      return this;
   }
}
