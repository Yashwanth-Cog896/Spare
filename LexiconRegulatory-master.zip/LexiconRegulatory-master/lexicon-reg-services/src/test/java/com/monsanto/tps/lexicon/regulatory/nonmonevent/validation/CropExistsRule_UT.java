package com.monsanto.tps.lexicon.regulatory.nonmonevent.validation;

import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Crop;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import org.junit.Test;

/**
 * nbwald - May 21, 2009 5:09:50 PM
 */
public class CropExistsRule_UT
{
   @Test
   public void testViolated_False()
      throws Exception
   {
      Crop crop = new Crop();
      Rule<String> rule = new CropExistsRule(crop);

      assertThat(rule.violated(), is(false));
   }

   @Test
   public void testViolated_True()
      throws Exception
   {
      Crop crop = null;
      Rule<String> rule = new CropExistsRule(crop);

      assertThat(rule.violated(), is(true));
   }

   @Test
   public void testGetViolation()
      throws Exception
   {
      Crop crop = null;
      Rule<String> rule = new CropExistsRule(crop);

      assertThat(rule.getViolation(), is("Crop is required."));
   }
}
