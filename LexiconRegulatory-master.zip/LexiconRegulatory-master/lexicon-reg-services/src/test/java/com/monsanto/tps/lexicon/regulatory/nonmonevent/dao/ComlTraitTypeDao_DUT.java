package com.monsanto.tps.lexicon.regulatory.nonmonevent.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.ComlTraitTypeBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.LexiconDataUnitTestCase;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType;
import org.junit.Test;

import javax.annotation.Resource;
import java.util.Collection;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

/**
 * nbwald - May 22, 2009 12:24:03 PM
 */
public class ComlTraitTypeDao_DUT
   extends LexiconDataUnitTestCase
{
   @Resource
   private ComlTraitTypeDao comlTraitTypeDao;


   @Test
 public void testFindByAbbrs_NoResults()
      throws Exception
   {
      Collection<ComlTraitType> traitTypes = comlTraitTypeDao.findByAbbrs("not existent", "also not existent");

      assertThat(traitTypes.isEmpty(), is(true));
   }

   @Test
 public void testFindByAbbrs_NoAbbrs_NoResults()
      throws Exception
   {
      Collection<ComlTraitType> traitTypes = comlTraitTypeDao.findByAbbrs();

      assertThat(traitTypes.isEmpty(), is(true));
   }

   @Test
 public void testFindByAbbrs_MultipleResults()
      throws Exception
   {
      ComlTraitType comlTraitTypeA = new ComlTraitTypeBuilder().create();
      ComlTraitType comlTraitTypeB = new ComlTraitTypeBuilder().create();

      Collection<ComlTraitType> traitTypes = comlTraitTypeDao.findByAbbrs(comlTraitTypeA.getComlTraitTypeAbbr(), comlTraitTypeB.getComlTraitTypeAbbr());

      assertThat(traitTypes.size(), is(2));
      assertThat(hasTraitType(traitTypes, comlTraitTypeA), is(true));
      assertThat(hasTraitType(traitTypes, comlTraitTypeB), is(true));
   }

   private boolean hasTraitType(Collection<ComlTraitType> traitTypes, ComlTraitType targetTraitType) {
      for (ComlTraitType traitType : traitTypes) {
         if (targetTraitType.getComlTraitTypeId() == traitType.getComlTraitTypeId() &&
            targetTraitType.getComlTraitTypeAbbr().equals(traitType.getComlTraitTypeAbbr()) &&
            targetTraitType.getComlTraitTypeDesc().equals(traitType.getComlTraitTypeDesc())) {
            return true;
         }
      }
      return false;
   }
}
