package com.monsanto.tps.lexicon.regulatory.event.delegate;

import org.apache.commons.lang.ArrayUtils;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import static org.junit.Assert.*;
/**
 * rlcasw - Sep 2, 2010 3:41:05 PM
 */
public class EventSplitter_UT
{
   EventSplitter eventSplitter = new EventSplitter();
 @Test
  public void testSplitEvents1(){
     String [] events=  buildEvents("Stuff",1);
     List<String []> splitEvents = eventSplitter.splitEvents(events);
     assertEquals(1,splitEvents.size());
     assertEquals(1,splitEvents.get(0).length);
  }
 @Test
  public void testSplitEventsLessThan1000(){
     String [] events=  buildEvents("Stuff",999);
     List<String []> splitEvents = eventSplitter.splitEvents(events);
     assertEquals(1,splitEvents.size());
     assertEquals(999,splitEvents.get(0).length);
  }
   @Test
    public void testSplitEventsEquals1000(){
       String [] events=  buildEvents("Stuff",1000);
       List<String []> splitEvents = eventSplitter.splitEvents(events);
       assertEquals(1,splitEvents.size());
       assertEquals(1000,splitEvents.get(0).length);
    }
   @Test
    public void testSplitEventsGreaterThan1000(){
       String [] events=  buildEvents("Stuff",1001);
       List<String []> splitEvents = eventSplitter.splitEvents(events);
       assertEquals(2,splitEvents.size());
       assertArrayEquals( ArrayUtils.subarray(events, 0, Math.min(events.length, 1000)),splitEvents.get(0));
       assertEquals(1000,splitEvents.get(0).length);
      assertArrayEquals( ArrayUtils.subarray(events, 1000, Math.min(events.length, 1001)),splitEvents.get(1));
      assertEquals(1,splitEvents.get(1).length);
    }
   @Test
    public void testSplitEventsGreaterThan2000(){
       String [] events=  buildEvents("Stuff",2001);
       List<String []> splitEvents = eventSplitter.splitEvents(events);
       assertEquals(3,splitEvents.size());
      assertArrayEquals( ArrayUtils.subarray(events, 0, Math.min(events.length, 1000)),splitEvents.get(0));
       assertEquals(1000,splitEvents.get(0).length);
      assertArrayEquals( ArrayUtils.subarray(events, 1000, Math.min(events.length, 2000)),splitEvents.get(1));
       assertEquals(1000,splitEvents.get(1).length);
      assertArrayEquals( ArrayUtils.subarray(events, 2000, Math.min(events.length, 2001)),splitEvents.get(2));
       assertEquals(1,splitEvents.get(2).length);
    }


  private String[] buildEvents(String eventPrefix, int count) {
      List<String> list = new ArrayList<String>();
      for (int i = 0; i < count; i++) {
         list.add(eventPrefix + "_" + i);
      }
      return list.toArray(new String[list.size()]);
   }
}
