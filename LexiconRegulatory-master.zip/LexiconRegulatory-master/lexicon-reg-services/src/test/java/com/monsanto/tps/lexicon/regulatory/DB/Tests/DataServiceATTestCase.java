package com.monsanto.tps.lexicon.regulatory.DB.Tests;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.tcc.lexiconcommon.db.audit.LexiconAuditor;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.monitor.MonitoredConnectionFactory;
import com.monsanto.tcc.lexiconcommon.db.monitor.TransactionMonitorManager;
import com.monsanto.tcc.lexiconcommon.db.monitor.test.TestFixtureTransactionMonitorManager;
import com.monsanto.tcc.lexiconcommon.db.test.LexiconTestTools;
import com.monsanto.tcc.lexiconcommon.test.SchemaValidatingTestCase;
import com.monsanto.tps.lexicon.regulatory.DB.factories.midas.MidasConnectionFactoryProperties;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Oct 23, 2006
 * Time: 3:45:13 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class DataServiceATTestCase
   extends SchemaValidatingTestCase
{
   private TransactionMonitorManager oldManager;
   private TestFixtureTransactionMonitorManager testManager;

   protected void setUp()
      throws Exception
   {
      oldManager = TransactionMonitorManager.getInstance();
      testManager = new TestFixtureTransactionMonitorManager();
      TransactionMonitorManager.setInstance(testManager);
   }

   protected void tearDown()
      throws Exception
   {
      try {
         testManager.tearDownDeactivation();
      }
      finally {
         TransactionMonitorManager.setInstance(oldManager);
      }
   }

   // Depricate Method, making it final so that nobody can accidentally "override" it.
   // Should use setupTestData or setupNonAuditedTestData
   protected final void insertTestData()
      throws Exception
   {
   }

   protected void setupTestData(TestDataFunctor functor)
      throws Exception
   {
      performAuditorSetup();
      functor.insertTestData();
//      tearDownAuditor();
   }

   private void performAuditorSetup()
      throws Exception
   {
      getLexAuditor().initializeStaging(getLexConn());
   }

   private void tearDownAuditor()
      throws Exception
   {
      getLexAuditor().removeStaging(getLexConn());
   }

   private LexiconAuditor getLexAuditor() {
      return LexiconTestTools.LEXICON_TEST_AUDITOR;
   }

   protected PersistentStoreConnection getLexConn()
      throws WrappingException
   {
      return new MonitoredConnectionFactory(new LexiconConnectionFactoryProperties()).getConnection();
   }

   public PersistentStoreConnection getMidasConn()
      throws WrappingException
   {
      return new MonitoredConnectionFactory(new MidasConnectionFactoryProperties()).getConnection();
   }

   public TestFixtureTransactionMonitorManager getTestManager() {
      return testManager;
   }
}
