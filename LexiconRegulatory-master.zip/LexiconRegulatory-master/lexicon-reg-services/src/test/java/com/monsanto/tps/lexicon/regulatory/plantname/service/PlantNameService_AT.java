package com.monsanto.tps.lexicon.regulatory.plantname.service;


import com.monsanto.tps.lexicon.plantname.OrionPlantProduct;
import com.monsanto.tps.lexicon.plantname.PlantNameService;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/2/12
 * Time: 7:40 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:/com/monsanto/tps/lexicon/regulatory/contexts/lexicon-test-service-at-context.xml"})
@Transactional
public class PlantNameService_AT {

    @Autowired
    private PlantNameService plantNameService;

    @Test
    public void findPlantName_results_wildcard() throws Exception {
        final List<OrionPlantProduct> plantNames = plantNameService.findPlantNames("Rou*");
        assertNotNull(plantNames);
        assertFalse(plantNames.isEmpty());
    }

    @Test
    public void findPlantName_results_exactMatch() throws Exception {
        final List<OrionPlantProduct> plantNames = plantNameService.findPlantNames("BollGard Cotton");
        assertNotNull(plantNames);
        assertFalse(plantNames.isEmpty());
    }

    @Test
    public void findPlantName_noResults() throws Exception {
        final List<OrionPlantProduct> plantNames = plantNameService.findPlantNames("asdf");
        assertNotNull(plantNames);
        assertTrue(plantNames.isEmpty());
    }
}
