package com.monsanto.tps.lexicon.regulatory.agency.validation;

import com.monsanto.tps.lexicon.agency.AgencySearchCriteria;
import junit.framework.TestCase;

/**
 * rrchak1 - Oct 21, 2008 1:10:34 PM
 */
public class AgencySearchCriteriaValidatorImpl_UT
   extends TestCase
{
   private AgencySearchCriteriaValidatorImpl validator;

   protected void setUp()
      throws Exception
   {
      validator = new AgencySearchCriteriaValidatorImpl();
   }

   public void testThrowsIllegalArgumentExceptionForNonAlphaNumericAgencyPubkey()
      throws Exception
   {
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setAgencyPubkey(new String[]{"$AA234F"});
      try {
         validator.validate(agencySearchCriteria);
         fail("should have thrown IllegalArgumentException");
      }
      catch (IllegalArgumentException e) {
         assertEquals("Agency Pubkey must contain only AlphaNumeric characters.", e.getMessage());
      }
   }

   public void testDoesNotThrowsIllegalArgumentExceptionForNumericAgencyPubkey()
      throws Exception
   {
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setAgencyPubkey(new String[]{"1", "2222"});
      validator.validate(agencySearchCriteria);
   }

   public void testDoesNotThrowsIllegalArgumentExceptionForAlphaAgencyPubkey()
      throws Exception
   {
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setAgencyPubkey(new String[]{"AAAA"});
      validator.validate(agencySearchCriteria);
   }

   public void testThrowsIllegalArgumentExceptionForNonAlphaNumericAgencyAbbr()
      throws Exception
   {
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setAgencyAbbr(new String[]{"$EPA21"});
      try {
         validator.validate(agencySearchCriteria);
         fail("should have thrown IllegalArgumentException");
      }
      catch (IllegalArgumentException e) {
         assertEquals("Agency Abbreviation must contain alphanumeric characters; is wildcardable for a single request.", e.getMessage());
      }
   }

   public void testDoesNotThrowsIllegalArgumentExceptionForAgencyAbbr()
      throws Exception
   {
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setAgencyAbbr(new String[]{"11USEPA"});
      validator.validate(agencySearchCriteria);
   }

   public void testDoesNotThrowsIllegalArgumentExceptionForCriteriaEndingWithWildcardedAgencyAbbr()
      throws Exception
   {
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setAgencyAbbr(new String[]{"S*"});
      validator.validate(agencySearchCriteria);
   }

   public void testDoesNotThrowsIllegalArgumentExceptionForCriteriaBeginningWithWildcardedAgencyAbbr()
      throws Exception
   {
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setAgencyAbbr(new String[]{"*S"});
      validator.validate(agencySearchCriteria);
   }

   public void testDoesNotThrowsIllegalArgumentExceptionForWildcardedAgencyAbbr()
      throws Exception
   {
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setAgencyAbbr(new String[]{"*S*"});
      validator.validate(agencySearchCriteria);
   }

   public void testThrowsIllegalArgumentExceptionForOnlyWildcardedAgencyAbbr()
      throws Exception
   {
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setAgencyAbbr(new String[]{"*"});
      try {
         validator.validate(agencySearchCriteria);
         fail("should have thrown IllegalArgumentException");
      }
      catch (IllegalArgumentException e) {
         assertEquals("Agency Abbreviation must contain alphanumeric characters; is wildcardable for a single request.", e.getMessage());
      }
   }

   public void testThrowsIllegalArgumentExceptionForWildcardedAgencyAbbr()
      throws Exception
   {
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setAgencyAbbr(new String[]{"**"});
      try {
         validator.validate(agencySearchCriteria);
         fail("should have thrown IllegalArgumentException");
      }
      catch (IllegalArgumentException e) {
         assertEquals("Agency Abbreviation must contain alphanumeric characters; is wildcardable for a single request.", e.getMessage());
      }
   }

   public void testDoesNotThrowsIllegalArgumentExceptionForAlphaAgencyAbbr()
      throws Exception
   {
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setAgencyAbbr(new String[]{"EPA", "USDA"});
      validator.validate(agencySearchCriteria);
   }

   public void testThrowsIllegalArgumentExceptionForMultipleWildcardedAgencyAbbr()
      throws Exception
   {
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setAgencyAbbr(new String[]{"A*", "B*"});
      try {
         validator.validate(agencySearchCriteria);
         fail("should have thrown IllegalArgumentException");
      }
      catch (IllegalArgumentException e) {
         assertEquals("Agency Abbreviation must contain alphanumeric characters; is wildcardable for a single request.", e.getMessage());
      }
   }

   public void testThrowsIllegalArgumentExceptionForNonAlphabeticCountryCode()
      throws Exception
   {
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setAgencyCountryIsoCode(new String[]{"$1"});
      try {
         validator.validate(agencySearchCriteria);
         fail("should have thrown IllegalArgumentException");
      }
      catch (IllegalArgumentException e) {
         assertEquals("Country ISO Code must contain only two alphabetic characters.", e.getMessage());
      }
   }

   public void testThrowsIllegalArgumentExceptionForThreeLetterCountryCode()
      throws Exception
   {
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setAgencyCountryIsoCode(new String[]{"USA"});
      try {
         validator.validate(agencySearchCriteria);
         fail("should have thrown IllegalArgumentException");
      }
      catch (IllegalArgumentException e) {
         assertEquals("Country ISO Code must contain only two alphabetic characters.", e.getMessage());
      }
   }

   public void testDoesNotThrowsIllegalArgumentExceptionForTwoLetterCountryCode()
      throws Exception
   {
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setAgencyCountryIsoCode(new String[]{"US", "IN"});
      validator.validate(agencySearchCriteria);
   }

   public void testDoesNotThrowsIllegalArgumentExceptionForWildcardedAgencyDeptName()
      throws Exception
   {
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setDepartmentNames(new String[]{"*E*"});
      validator.validate(agencySearchCriteria);
   }

   public void testDoesNotThrowsIllegalArgumentExceptionForAgencyDeptName()
      throws Exception
   {
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setDepartmentNames(new String[]{"HEAD QUARTERS"});
      validator.validate(agencySearchCriteria);
   }

   public void testThrowsIllegalArgumentExceptionForOnlyWildcardedAgencyDeptName()
      throws Exception
   {
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setDepartmentNames(new String[]{"*"});
      try {
         validator.validate(agencySearchCriteria);
         fail("should have thrown IllegalArgumentException");
      }
      catch (IllegalArgumentException e) {
         assertEquals("Agency Department must contain only Alpha characters, comma and space; is wildcardable for a single request.", e.getMessage());
      }
   }

   public void testThrowsIllegalArgumentExceptionForWildcardedAgencyDeptName()
      throws Exception
   {
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setDepartmentNames(new String[]{"**"});
      try {
         validator.validate(agencySearchCriteria);
         fail("should have thrown IllegalArgumentException");
      }
      catch (IllegalArgumentException e) {
         assertEquals("Agency Department must contain only Alpha characters, comma and space; is wildcardable for a single request.", e.getMessage());
      }
   }

   public void testThrowsIllegalArgumentExceptionForNonAlphaAgencyDeptName()
      throws Exception
   {
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setDepartmentNames(new String[]{"EPA2"});
      try {
         validator.validate(agencySearchCriteria);
         fail("should have thrown IllegalArgumentException");
      }
      catch (IllegalArgumentException e) {
         assertEquals("Agency Department must contain only Alpha characters, comma and space; is wildcardable for a single request.", e.getMessage());
      }
   }

   public void testThrowsIllegalArgumentExceptionForMultipleWildcardedAgencyDeptName()
      throws Exception
   {
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setDepartmentNames(new String[]{"A*", "B*"});
      try {
         validator.validate(agencySearchCriteria);
         fail("should have thrown IllegalArgumentException");
      }
      catch (IllegalArgumentException e) {
         assertEquals("Agency Department must contain only Alpha characters, comma and space; is wildcardable for a single request.", e.getMessage());
      }
   }

   public void testDoesNotThrowsIllegalArgumentExceptionForAgencyDeptNameWithComma()
      throws Exception
   {
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setDepartmentNames(new String[]{"USDA, APHC", "EPA"});
      validator.validate(agencySearchCriteria);
   }

}
