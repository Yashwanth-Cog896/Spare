package com.monsanto.tps.lexicon.regulatory.event.dao.eventconstructtransformation.midas;

import com.monsanto.tcc.lexiconcommon.db.test.MidasTestTools;
import com.monsanto.tps.lexicon.regulatory.DB.Midas.Tests.MidasDataTestCase;
import com.monsanto.tps.lexicon.regulatory.DB.TestUtil.TPSTestConstants;
import com.monsanto.tps.lexicon.regulatory.TPS.LineType.LineTypeRef;
import com.monsanto.tps.lexicon.regulatory.event.model.RegulatoryEventConstructTransformation;

/**
 * User: pjberry
 * Date: Jul 25, 2007
 * Time: 9:57:44 AM
 */
public class MidasRegulatoryEventConstructTransformationByEventNameAndCropQuery_DUT
        extends MidasDataTestCase {
    private static final int GERMPLASM_ID_ONE = -1323;
    private static final int GERMPLASM_ID_TWO = -3831;

    private static final int GENETIC_MATERIAL_ID_ONE = -8632;
    private static final int GENETIC_MATERIAL_ID_TWO = -2768;

    private static final int GERMPLASM_EVENT_CONSTRUCT_ID_ONE = -12863;
    private static final int GERMPLASM_EVENT_CONSTRUCT_ID_TWO = -83682;

    private static final int EVENT_CONSTRUCT_ID_ONE = -86346;
    private static final int EVENT_CONSTRUCT_ID_TWO = -46439;

    private static final String EVENT_NAME = "eventName";
    private static final String CONSTRUCT_NAME_ONE = "constructNameOne";
    private static final String CONSTRUCT_NAME_TWO = "constructNameTwo";

    private static final String TRANSFORMATION_GENOTYPE = "transformationGenotype";


    public void testObtainSingleResult()
            throws Exception {
        MidasTestTools.insertFakeGermplasm(getMidasConn(), GERMPLASM_ID_ONE, "pedigree", LineTypeRef.HYBRID, TRANSFORMATION_GENOTYPE, TPSTestConstants.MIDAS_CORN_ID, false, true, false);
        MidasTestTools.insertFakeGeneticMaterialWithGeneration(getMidasConn(), GENETIC_MATERIAL_ID_ONE, "source", "lineage", GERMPLASM_ID_ONE, "srcOpertaion", "R0");

        MidasTestTools.insertFakeEventConstruct(getMidasConn(), EVENT_CONSTRUCT_ID_ONE, EVENT_NAME, CONSTRUCT_NAME_ONE, TPSTestConstants.MIDAS_CORN_ID);
        MidasTestTools.insertFakeGermplasmEventConstruct(getMidasConn(), GERMPLASM_EVENT_CONSTRUCT_ID_ONE, EVENT_CONSTRUCT_ID_ONE, GERMPLASM_ID_ONE);

        MidasRegulatoryEventConstructTransformationByEventNameAndCropQuery query = new MidasRegulatoryEventConstructTransformationByEventNameAndCropQuery(EVENT_NAME, "ZM");
        RegulatoryEventConstructTransformation[] regulatoryEventConstructTransformations = query.getEventConstructTransformations();

        assertNotNull(regulatoryEventConstructTransformations);
        assertEquals(1, regulatoryEventConstructTransformations.length);

        assertEquals(EVENT_NAME, regulatoryEventConstructTransformations[0].getEvent());
        assertEquals(CONSTRUCT_NAME_ONE, regulatoryEventConstructTransformations[0].getConstruct());
        assertEquals(TRANSFORMATION_GENOTYPE, regulatoryEventConstructTransformations[0].getTransformationBackground());
    }


    public void testEventsMatchingIsCaseInsensitive()
            throws Exception {
        MidasTestTools.insertFakeGermplasm(getMidasConn(), GERMPLASM_ID_ONE, "pedigree", LineTypeRef.HYBRID, TRANSFORMATION_GENOTYPE, TPSTestConstants.MIDAS_CORN_ID, false, true, false);
        MidasTestTools.insertFakeGeneticMaterialWithGeneration(getMidasConn(), GENETIC_MATERIAL_ID_ONE, "source", "lineage", GERMPLASM_ID_ONE, "srcOpertaion", "R0");

        MidasTestTools.insertFakeEventConstruct(getMidasConn(), EVENT_CONSTRUCT_ID_ONE, EVENT_NAME.toLowerCase(), CONSTRUCT_NAME_ONE, TPSTestConstants.MIDAS_CORN_ID);
        MidasTestTools.insertFakeGermplasmEventConstruct(getMidasConn(), GERMPLASM_EVENT_CONSTRUCT_ID_ONE, EVENT_CONSTRUCT_ID_ONE, GERMPLASM_ID_ONE);

        MidasRegulatoryEventConstructTransformationByEventNameAndCropQuery query = new MidasRegulatoryEventConstructTransformationByEventNameAndCropQuery(EVENT_NAME, "ZM");
        RegulatoryEventConstructTransformation[] regulatoryEventConstructTransformations = query.getEventConstructTransformations();

        assertNotNull(regulatoryEventConstructTransformations);
        assertEquals(1, regulatoryEventConstructTransformations.length);

        assertEquals(EVENT_NAME.toLowerCase(), regulatoryEventConstructTransformations[0].getEvent());
        assertEquals(CONSTRUCT_NAME_ONE, regulatoryEventConstructTransformations[0].getConstruct());
        assertEquals(TRANSFORMATION_GENOTYPE, regulatoryEventConstructTransformations[0].getTransformationBackground());
    }


    public void testMultipleResults()
            throws Exception {
        MidasTestTools.insertFakeGermplasm(getMidasConn(), GERMPLASM_ID_ONE, "pedigree", LineTypeRef.HYBRID, TRANSFORMATION_GENOTYPE, TPSTestConstants.MIDAS_CORN_ID, false, true, false);
        MidasTestTools.insertFakeGeneticMaterialWithGeneration(getMidasConn(), GENETIC_MATERIAL_ID_ONE, "source", "lineage", GERMPLASM_ID_ONE, "srcOpertaion", "R0");

        MidasTestTools.insertFakeGermplasm(getMidasConn(), GERMPLASM_ID_TWO, "pedigree", LineTypeRef.HYBRID, TRANSFORMATION_GENOTYPE, TPSTestConstants.MIDAS_CORN_ID, false, true, false);
        MidasTestTools.insertFakeGeneticMaterialWithGeneration(getMidasConn(), GENETIC_MATERIAL_ID_TWO, "source", "lineage", GERMPLASM_ID_TWO, "srcOpertaion", "R0");

        MidasTestTools.insertFakeEventConstruct(getMidasConn(), EVENT_CONSTRUCT_ID_ONE, EVENT_NAME, CONSTRUCT_NAME_ONE, TPSTestConstants.MIDAS_CORN_ID);
        MidasTestTools.insertFakeEventConstruct(getMidasConn(), EVENT_CONSTRUCT_ID_TWO, EVENT_NAME, CONSTRUCT_NAME_TWO, TPSTestConstants.MIDAS_CORN_ID);

        MidasTestTools.insertFakeGermplasmEventConstruct(getMidasConn(), GERMPLASM_EVENT_CONSTRUCT_ID_ONE, EVENT_CONSTRUCT_ID_ONE, GERMPLASM_ID_ONE);
        MidasTestTools.insertFakeGermplasmEventConstruct(getMidasConn(), GERMPLASM_EVENT_CONSTRUCT_ID_TWO, EVENT_CONSTRUCT_ID_TWO, GERMPLASM_ID_TWO);

        MidasRegulatoryEventConstructTransformationByEventNameAndCropQuery query = new MidasRegulatoryEventConstructTransformationByEventNameAndCropQuery(EVENT_NAME, "ZM");
        RegulatoryEventConstructTransformation[] regulatoryEventConstructTransformations = query.getEventConstructTransformations();

        assertNotNull(regulatoryEventConstructTransformations);
        assertEquals(2, regulatoryEventConstructTransformations.length);

        assertEquals(EVENT_NAME, regulatoryEventConstructTransformations[0].getEvent());
        assertEquals(CONSTRUCT_NAME_ONE, regulatoryEventConstructTransformations[0].getConstruct());
        assertEquals(TRANSFORMATION_GENOTYPE, regulatoryEventConstructTransformations[0].getTransformationBackground());

        assertEquals(EVENT_NAME, regulatoryEventConstructTransformations[1].getEvent());
        assertEquals(CONSTRUCT_NAME_TWO, regulatoryEventConstructTransformations[1].getConstruct());
        assertEquals(TRANSFORMATION_GENOTYPE, regulatoryEventConstructTransformations[1].getTransformationBackground());
    }


    public void testPullsBackUniqueMatches()
            throws Exception {
        MidasTestTools.insertFakeGermplasm(getMidasConn(), GERMPLASM_ID_ONE, "pedigree", LineTypeRef.HYBRID, TRANSFORMATION_GENOTYPE, TPSTestConstants.MIDAS_CORN_ID, false, true, false);
        MidasTestTools.insertFakeGeneticMaterialWithGeneration(getMidasConn(), GENETIC_MATERIAL_ID_ONE, "source", "lineage", GERMPLASM_ID_ONE, "srcOpertaion", "R0");

        MidasTestTools.insertFakeGermplasm(getMidasConn(), GERMPLASM_ID_TWO, "pedigree", LineTypeRef.HYBRID, TRANSFORMATION_GENOTYPE, TPSTestConstants.MIDAS_CORN_ID, false, true, false);
        MidasTestTools.insertFakeGeneticMaterialWithGeneration(getMidasConn(), GENETIC_MATERIAL_ID_TWO, "source", "lineage", GERMPLASM_ID_TWO, "srcOpertaion", "R0");

        MidasTestTools.insertFakeEventConstruct(getMidasConn(), EVENT_CONSTRUCT_ID_ONE, EVENT_NAME, CONSTRUCT_NAME_ONE, TPSTestConstants.MIDAS_CORN_ID);
        MidasTestTools.insertFakeEventConstruct(getMidasConn(), EVENT_CONSTRUCT_ID_TWO, EVENT_NAME, CONSTRUCT_NAME_ONE, TPSTestConstants.MIDAS_CORN_ID);

        MidasTestTools.insertFakeGermplasmEventConstruct(getMidasConn(), GERMPLASM_EVENT_CONSTRUCT_ID_ONE, EVENT_CONSTRUCT_ID_ONE, GERMPLASM_ID_ONE);
        MidasTestTools.insertFakeGermplasmEventConstruct(getMidasConn(), GERMPLASM_EVENT_CONSTRUCT_ID_TWO, EVENT_CONSTRUCT_ID_TWO, GERMPLASM_ID_TWO);

        MidasRegulatoryEventConstructTransformationByEventNameAndCropQuery query = new MidasRegulatoryEventConstructTransformationByEventNameAndCropQuery(EVENT_NAME, "ZM");
        RegulatoryEventConstructTransformation[] regulatoryEventConstructTransformations = query.getEventConstructTransformations();

        assertNotNull(regulatoryEventConstructTransformations);
        assertEquals(1, regulatoryEventConstructTransformations.length);

        assertEquals(EVENT_NAME, regulatoryEventConstructTransformations[0].getEvent());
        assertEquals(CONSTRUCT_NAME_ONE, regulatoryEventConstructTransformations[0].getConstruct());
        assertEquals(TRANSFORMATION_GENOTYPE, regulatoryEventConstructTransformations[0].getTransformationBackground());
    }


    public void testOnlyPullBackR0Generation()
            throws Exception {
        MidasTestTools.insertFakeGermplasm(getMidasConn(), GERMPLASM_ID_ONE, "pedigree", LineTypeRef.HYBRID, TRANSFORMATION_GENOTYPE, TPSTestConstants.MIDAS_CORN_ID, false, true, false);
        MidasTestTools.insertFakeGeneticMaterialWithGeneration(getMidasConn(), GENETIC_MATERIAL_ID_ONE, "source", "lineage", GERMPLASM_ID_ONE, "srcOpertaion", "R0");

        MidasTestTools.insertFakeGermplasm(getMidasConn(), GERMPLASM_ID_TWO, "pedigree", LineTypeRef.HYBRID, TRANSFORMATION_GENOTYPE, TPSTestConstants.MIDAS_CORN_ID, false, true, false);
        MidasTestTools.insertFakeGeneticMaterialWithGeneration(getMidasConn(), GENETIC_MATERIAL_ID_TWO, "source", "lineage", GERMPLASM_ID_TWO, "srcOpertaion", "R1");

        MidasTestTools.insertFakeEventConstruct(getMidasConn(), EVENT_CONSTRUCT_ID_ONE, EVENT_NAME, CONSTRUCT_NAME_ONE, TPSTestConstants.MIDAS_CORN_ID);
        MidasTestTools.insertFakeEventConstruct(getMidasConn(), EVENT_CONSTRUCT_ID_TWO, EVENT_NAME, CONSTRUCT_NAME_TWO, TPSTestConstants.MIDAS_CORN_ID);

        MidasTestTools.insertFakeGermplasmEventConstruct(getMidasConn(), GERMPLASM_EVENT_CONSTRUCT_ID_ONE, EVENT_CONSTRUCT_ID_ONE, GERMPLASM_ID_ONE);
        MidasTestTools.insertFakeGermplasmEventConstruct(getMidasConn(), GERMPLASM_EVENT_CONSTRUCT_ID_TWO, EVENT_CONSTRUCT_ID_TWO, GERMPLASM_ID_TWO);

        MidasRegulatoryEventConstructTransformationByEventNameAndCropQuery query = new MidasRegulatoryEventConstructTransformationByEventNameAndCropQuery(EVENT_NAME, "ZM");
        RegulatoryEventConstructTransformation[] regulatoryEventConstructTransformations = query.getEventConstructTransformations();

        assertNotNull(regulatoryEventConstructTransformations);
        assertEquals(1, regulatoryEventConstructTransformations.length);

        assertEquals(EVENT_NAME, regulatoryEventConstructTransformations[0].getEvent());
        assertEquals(CONSTRUCT_NAME_ONE, regulatoryEventConstructTransformations[0].getConstruct());
        assertEquals(TRANSFORMATION_GENOTYPE, regulatoryEventConstructTransformations[0].getTransformationBackground());
    }


    public void testNoMatches()
            throws Exception {
        MidasRegulatoryEventConstructTransformationByEventNameAndCropQuery query = new MidasRegulatoryEventConstructTransformationByEventNameAndCropQuery(EVENT_NAME, "ZM");
        RegulatoryEventConstructTransformation[] regulatoryEventConstructTransformations = query.getEventConstructTransformations();

        assertNotNull(regulatoryEventConstructTransformations);
        assertEquals(0, regulatoryEventConstructTransformations.length);
    }
}
