package com.monsanto.tps.lexicon.regulatory.event.service;

import com.monsanto.tps.lexicon.event.EventAgencyAlignmentRequest;
import com.monsanto.tps.lexicon.event.EventAgencyAlignmentRequestInfo;
import com.monsanto.tps.lexicon.event.EventAgencyAlignmentResponse;
import com.monsanto.tps.lexicon.event.EventAgencyAlignmentService;
import com.monsanto.tps.lexicon.event.EventAgencyAlignmentUpdateInfo;
import com.monsanto.tps.lexicon.event.EventAgencyAlignmentUpdateRequest;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.AgencyBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.AgencyDepartmentBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.EventAgencyAlignmentBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.EventAgencyAlignmentInfoBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.LexiconAcceptanceTestCase;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Agency;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;
import com.monsanto.tps.lexicon.regulatory.event.queryset.EventSearchServiceQuerySet;
import org.apache.commons.beanutils.BeanUtils;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;

import static org.junit.Assert.assertEquals;

/**
 * rrchak1 - Feb 9, 2009 2:06:03 PM
 */
@Transactional
public class EventAgencyAlignmentServiceImpl_AT
        extends LexiconAcceptanceTestCase {
    @Resource
    private EventAgencyAlignmentService eventAgencyAlignmentService;
    @Resource
    private EventSearchServiceQuerySet eventSearchServiceQuerySet;
    private static final String EVENT = "EVENTNAME";
    private static final String CORN = "CORN";

    @Test
    public void testSaveEventAgencyAlignment_ForGivenCropAndEvent()
            throws Exception {
        Agency testAgency = insert(new AcceptanceTestData<Agency>() {
            public Agency dataToInsert() {
                return new AgencyBuilder().
                        withAgencyDepartment(new AgencyDepartmentBuilder().
                                withName("XYZ")).
                        withPubKey("1111").
                        withAgencyAbbr("USQA").
                        create();
            }
        });
        EventAgencyAlignmentRequest eventAgencyAlignmentRequest = new EventAgencyAlignmentRequest();
        EventAgencyAlignmentRequestInfo eventAgencyAlignmentRequestInfo =
                new EventAgencyAlignmentInfoBuilder().
                        withMaxQuantity(100).
                        withDeregulatedEffectiveDate(new Date()).
                        withAgencyPubkey(testAgency.getAgencyPubkey()).
                        regulated().
                        getEventAgencyAlignmentInfo();
        eventAgencyAlignmentRequest.setEvent(EVENT);
        eventAgencyAlignmentRequest.setCrop(CORN);
        eventAgencyAlignmentRequest.setEventAgencyAlignments(new EventAgencyAlignmentRequestInfo[]{eventAgencyAlignmentRequestInfo});
        EventAgencyAlignmentResponse[] responses = eventAgencyAlignmentService.save(eventAgencyAlignmentRequest);
        Assert.assertNotNull(responses);
        EventAgencyAlignmentResponse response = responses[0];
        Assert.assertTrue(response.isSuccess());
        Assert.assertNotNull(response.getEventAgencyAlignmentPubkey());
    }

    @Test
    public void testSaveMultipleEventAgencyAlignments_ForGivenCropAndEvent()
            throws Exception {
        Agency testAgency = insert(new AcceptanceTestData<Agency>() {
            public Agency dataToInsert() {
                return new AgencyBuilder().
                        withAgencyDepartment(new AgencyDepartmentBuilder().
                                withName("XYZ")).
                        withPubKey("1111").
                        withAgencyAbbr("USQA").
                        create();
            }
        });
        Agency agencyTwo = insert(new AcceptanceTestData<Agency>() {
            public Agency dataToInsert() {
                return new AgencyBuilder().
                        withAgencyDepartment(new AgencyDepartmentBuilder().
                                withName("AAA")).
                        withPubKey("2222").
                        withAgencyAbbr("EAD").
                        create();
            }
        });
        EventAgencyAlignmentRequest eventAgencyAlignmentRequest = new EventAgencyAlignmentRequest();
        EventAgencyAlignmentRequestInfo eventAgencyAlignmentRequestInfo =
                new EventAgencyAlignmentInfoBuilder().
                        withMaxQuantity(100).
                        withDeregulatedEffectiveDate(new Date()).
                        withAgencyPubkey(testAgency.getAgencyPubkey()).
                        regulated().
                        getEventAgencyAlignmentInfo();
        EventAgencyAlignmentRequestInfo eventAgencyAlignmentRequestInfoTwo =
                new EventAgencyAlignmentInfoBuilder().
                        withMaxQuantity(200).
                        withDeregulatedEffectiveDate(new Date()).
                        withAgencyPubkey(agencyTwo.getAgencyPubkey()).
                        regulated().
                        getEventAgencyAlignmentInfo();
        eventAgencyAlignmentRequest.setEvent(EVENT);
        eventAgencyAlignmentRequest.setCrop(CORN);
        eventAgencyAlignmentRequest.setEventAgencyAlignments(new EventAgencyAlignmentRequestInfo[]{eventAgencyAlignmentRequestInfo, eventAgencyAlignmentRequestInfoTwo});
        EventAgencyAlignmentResponse[] responses = eventAgencyAlignmentService.save(eventAgencyAlignmentRequest);
        Assert.assertNotNull(responses);
        Assert.assertEquals(2, responses.length);
        EventAgencyAlignmentResponse response = responses[0];
        Assert.assertTrue(response.isSuccess());
        Assert.assertNotNull(response.getEventAgencyAlignmentPubkey());
        EventAgencyAlignmentResponse responseTwo = responses[1];
        Assert.assertTrue(responseTwo.isSuccess());
        Assert.assertNotNull(responseTwo.getEventAgencyAlignmentPubkey());
    }


    @Test
    public void testSaveDuplicateEventAgencyAlignments_ForExistingEventAndCrop_DoesPartialSave()
            throws Exception {
        Agency testAgency = insert(new AcceptanceTestData<Agency>() {
            public Agency dataToInsert() {
                return new AgencyBuilder().
                        withAgencyDepartment(new AgencyDepartmentBuilder().
                                withName("XYZ")).
                        withPubKey("1111").
                        withAgencyAbbr("USQA").
                        create();
            }
        });
        EventAgencyAlignmentRequest eventAgencyAlignmentRequest = new EventAgencyAlignmentRequest();
        EventAgencyAlignmentRequestInfo eventAgencyAlignmentRequestInfo =
                new EventAgencyAlignmentInfoBuilder().
                        withMaxQuantity(100).
                        withDeregulatedEffectiveDate(new Date()).
                        withAgencyPubkey(testAgency.getAgencyPubkey()).
                        regulated().
                        getEventAgencyAlignmentInfo();
        EventAgencyAlignmentRequestInfo eventAgencyAlignmentRequestInfoTwo =
                new EventAgencyAlignmentInfoBuilder().
                        withMaxQuantity(200).
                        withDeregulatedEffectiveDate(new Date()).
                        withAgencyPubkey(testAgency.getAgencyPubkey()).
                        regulated().
                        getEventAgencyAlignmentInfo();
        eventAgencyAlignmentRequest.setEvent(EVENT);
        eventAgencyAlignmentRequest.setCrop(CORN);
        eventAgencyAlignmentRequest.setEventAgencyAlignments(new EventAgencyAlignmentRequestInfo[]{eventAgencyAlignmentRequestInfo, eventAgencyAlignmentRequestInfoTwo});
        EventAgencyAlignmentResponse[] responses = eventAgencyAlignmentService.save(eventAgencyAlignmentRequest);
        Assert.assertNotNull(responses);
        Assert.assertEquals(2, responses.length);
        EventAgencyAlignmentResponse response = responses[0];
        Assert.assertTrue(response.isSuccess());
        Assert.assertNotNull(response.getEventAgencyAlignmentPubkey());
        EventAgencyAlignmentResponse responseTwo = responses[1];
        Assert.assertFalse(responseTwo.isSuccess());
        Assert.assertNull(responseTwo.getEventAgencyAlignmentPubkey());
        Assert.assertEquals("EventAgencyAlignment already exists", responseTwo.getMessage());
    }


    @Test
    public void testSaveEventAgencyAlignments_ForAnEventWithDifferentCropsWithSameAgency()
            throws Exception {
        Agency testAgency = insert(new AcceptanceTestData<Agency>() {
            public Agency dataToInsert() {
                return new AgencyBuilder().
                        withAgencyDepartment(new AgencyDepartmentBuilder().
                                withName("XYZ")).
                        withPubKey("1111").
                        withAgencyAbbr("USQA").
                        create();
            }
        });
        EventAgencyAlignmentRequest eventAgencyAlignmentRequest = new EventAgencyAlignmentRequest();
        EventAgencyAlignmentRequestInfo eventAgencyAlignmentRequestInfo =
                new EventAgencyAlignmentInfoBuilder().
                        withMaxQuantity(100).
                        withDeregulatedEffectiveDate(new Date()).
                        withAgencyPubkey(testAgency.getAgencyPubkey()).
                        regulated().
                        getEventAgencyAlignmentInfo();
        eventAgencyAlignmentRequest.setEvent(EVENT);
        eventAgencyAlignmentRequest.setCrop(CORN);
        eventAgencyAlignmentRequest.setEventAgencyAlignments(new EventAgencyAlignmentRequestInfo[]{eventAgencyAlignmentRequestInfo});
        EventAgencyAlignmentResponse[] responses = eventAgencyAlignmentService.save(eventAgencyAlignmentRequest);
        Assert.assertNotNull(responses);
        Assert.assertEquals(1, responses.length);
        EventAgencyAlignmentResponse response = responses[0];
        Assert.assertTrue(response.isSuccess());
        Assert.assertNotNull(response.getEventAgencyAlignmentPubkey());

        eventAgencyAlignmentRequest.setEvent(EVENT);
        eventAgencyAlignmentRequest.setCrop("SOYBEANS");
        eventAgencyAlignmentRequest.setEventAgencyAlignments(new EventAgencyAlignmentRequestInfo[]{eventAgencyAlignmentRequestInfo});
        EventAgencyAlignmentResponse[] responseArray = eventAgencyAlignmentService.save(eventAgencyAlignmentRequest);
        Assert.assertNotNull(responseArray);
        Assert.assertEquals(1, responseArray.length);
        EventAgencyAlignmentResponse responseObj = responseArray[0];
        Assert.assertTrue(responseObj.isSuccess());
        Assert.assertNotNull(responseObj.getEventAgencyAlignmentPubkey());
    }


    @Test
    public void testSaveEventAgencyAlignment_SavesEventInAscendingOrder_ForGivenCropAndStackedEvent()
            throws Exception {
        Agency testAgency = insert(new AcceptanceTestData<Agency>() {
            public Agency dataToInsert() {
                return new AgencyBuilder().
                        withAgencyDepartment(new AgencyDepartmentBuilder().
                                withName("XYZ")).
                        withPubKey("1111").
                        withAgencyAbbr("USQA").
                        create();
            }
        });
        EventAgencyAlignmentRequest eventAgencyAlignmentRequest = new EventAgencyAlignmentRequest();
        EventAgencyAlignmentRequestInfo eventAgencyAlignmentRequestInfo =
                new EventAgencyAlignmentInfoBuilder().
                        withMaxQuantity(100).
                        withDeregulatedEffectiveDate(new Date()).
                        withAgencyPubkey(testAgency.getAgencyPubkey()).
                        regulated().
                        getEventAgencyAlignmentInfo();
        eventAgencyAlignmentRequest.setEvent("ZM_1111,BM_2344");
        eventAgencyAlignmentRequest.setCrop(CORN);
        eventAgencyAlignmentRequest.setEventAgencyAlignments(new EventAgencyAlignmentRequestInfo[]{eventAgencyAlignmentRequestInfo});
        EventAgencyAlignmentResponse[] responses = eventAgencyAlignmentService.save(eventAgencyAlignmentRequest);
        Assert.assertNotNull(responses);
        EventAgencyAlignmentResponse response = responses[0];
        Assert.assertTrue(response.isSuccess());
        Assert.assertNotNull(response.getEventAgencyAlignmentPubkey());

        EventAgencyAlignment[] newAlignments =
                eventSearchServiceQuerySet.findEventAgencyAlignmentByPubkey(new String[]{response.getEventAgencyAlignmentPubkey()});
        EventAgencyAlignment after = newAlignments[0];
        Assert.assertNotNull(after);
        assertEquals("BM_2344,ZM_1111", after.getMaterialName());

    }

    @Test
    public void testUpdateEventAgencyAlignment_ForExistingAlignment()
            throws Exception {
        EventAgencyAlignment eventAgencyAlignment = insert(new AcceptanceTestData<EventAgencyAlignment>() {
            public EventAgencyAlignment dataToInsert() {
                return new EventAgencyAlignmentBuilder().
                        withEvent(EVENT).
                        withAgency(AgencyBuilder.epa()).
                        regulated().
                        withMaxQuantity(10).
                        withDeregulatedEffectiveDate(new Date()).
                        create();
            }
        });
        EventAgencyAlignment[] alignments =
                eventSearchServiceQuerySet.findEventAgencyAlignmentByPubkey(new String[]{eventAgencyAlignment.getEventAgencyAlignmentPubkey()});
        EventAgencyAlignment before = alignments[0];
        Assert.assertEquals(eventAgencyAlignment.getEventAgencyAlignmentPubkey(), before.getEventAgencyAlignmentPubkey());
        Assert.assertEquals(eventAgencyAlignment.getMaxQuantity(), before.getMaxQuantity());
        Assert.assertEquals(eventAgencyAlignment.getDeregulatedEffectiveDate(), before.getDeregulatedEffectiveDate());
        Assert.assertEquals(eventAgencyAlignment.getRegulated(), before.getRegulated());
        EventAgencyAlignment clone = (EventAgencyAlignment) BeanUtils.cloneBean(before);
        EventAgencyAlignmentUpdateInfo updateInfo = new EventAgencyAlignmentUpdateInfo();
        updateInfo.setEventAgencyAlignmentPubkey(before.getEventAgencyAlignmentPubkey());
        updateInfo.setMaxQuantity(100.0);
        updateInfo.setRegulated(false);
        updateInfo.setDeregulatedEffectiveDate(new Date());
        EventAgencyAlignmentUpdateRequest updateRequest = new EventAgencyAlignmentUpdateRequest();
        updateRequest.setEventAgencyAlignmentUpdates(new EventAgencyAlignmentUpdateInfo[]{updateInfo});
        EventAgencyAlignmentResponse[] responses = eventAgencyAlignmentService.update(updateRequest);
        Assert.assertNotNull(responses);
        EventAgencyAlignmentResponse response = responses[0];
        Assert.assertTrue(response.isSuccess());
        Assert.assertEquals(before.getEventAgencyAlignmentPubkey(), response.getEventAgencyAlignmentPubkey());
        EventAgencyAlignment[] newAlignments =
                eventSearchServiceQuerySet.findEventAgencyAlignmentByPubkey(new String[]{response.getEventAgencyAlignmentPubkey()});
        EventAgencyAlignment after = newAlignments[0];
        Assert.assertNotNull(after);
        Assert.assertFalse(clone.getMaxQuantity().equals(after.getMaxQuantity()));
        Assert.assertFalse(clone.getRegulated().equals(after.getRegulated()));
        Assert.assertFalse(clone.getDeregulatedEffectiveDate().equals(after.getDeregulatedEffectiveDate()));
    }


    @Test
    public void testUpdateEventAgencyAlignment_ReturnsMessageForNonExistingAlignment()
            throws Exception {
        EventAgencyAlignmentUpdateInfo updateInfo = new EventAgencyAlignmentUpdateInfo();
        updateInfo.setEventAgencyAlignmentPubkey("some pubkey");
        updateInfo.setMaxQuantity(100.01);
        updateInfo.setRegulated(false);
        updateInfo.setDeregulatedEffectiveDate(new Date());
        EventAgencyAlignmentUpdateRequest updateRequest = new EventAgencyAlignmentUpdateRequest();
        updateRequest.setEventAgencyAlignmentUpdates(new EventAgencyAlignmentUpdateInfo[]{updateInfo});
        EventAgencyAlignmentResponse[] responses = eventAgencyAlignmentService.update(updateRequest);
        Assert.assertNotNull(responses);
        EventAgencyAlignmentResponse response = responses[0];
        Assert.assertFalse(response.isSuccess());
        Assert.assertEquals("EventAgencyAlignment does not exist", response.getMessage());
    }

    @Test
    public void testUpdateMultipleEventAgencyAlignment()
            throws Exception {
        EventAgencyAlignment eventAgencyAlignment = insert(new AcceptanceTestData<EventAgencyAlignment>() {
            public EventAgencyAlignment dataToInsert() {
                return new EventAgencyAlignmentBuilder().
                        withEvent(EVENT).
                        withAgency(AgencyBuilder.epa()).
                        regulated().
                        withMaxQuantity(10).
                        withDeregulatedEffectiveDate(new Date()).
                        create();
            }
        });

        EventAgencyAlignment eventAgencyAlignmentTwo = insert(new AcceptanceTestData<EventAgencyAlignment>() {
            public EventAgencyAlignment dataToInsert() {
                return new EventAgencyAlignmentBuilder().
                        withEvent(EVENT).
                        withAgency(AgencyBuilder.usda()).
                        deregulated().
                        withMaxQuantity(20).
                        withDeregulatedEffectiveDate(new Date()).
                        create();
            }
        });

        EventAgencyAlignmentUpdateInfo updateInfo = new EventAgencyAlignmentUpdateInfo();
        updateInfo.setEventAgencyAlignmentPubkey(eventAgencyAlignment.getEventAgencyAlignmentPubkey());
        updateInfo.setMaxQuantity(100.01);
        updateInfo.setRegulated(false);
        updateInfo.setDeregulatedEffectiveDate(new Date());

        EventAgencyAlignmentUpdateInfo updateTwo = new EventAgencyAlignmentUpdateInfo();
        updateTwo.setEventAgencyAlignmentPubkey(eventAgencyAlignmentTwo.getEventAgencyAlignmentPubkey());
        updateTwo.setMaxQuantity(200.01);
        updateTwo.setRegulated(true);
        updateTwo.setDeregulatedEffectiveDate(new Date());

        EventAgencyAlignmentUpdateRequest updateRequest = new EventAgencyAlignmentUpdateRequest();
        updateRequest.setEventAgencyAlignmentUpdates(new EventAgencyAlignmentUpdateInfo[]{updateInfo, updateTwo});
        EventAgencyAlignmentResponse[] responses = eventAgencyAlignmentService.update(updateRequest);
        Assert.assertNotNull(responses);
        Assert.assertEquals(2, responses.length);
        EventAgencyAlignmentResponse response = responses[0];
        Assert.assertTrue(response.isSuccess());
        Assert.assertEquals(updateInfo.getEventAgencyAlignmentPubkey(), response.getEventAgencyAlignmentPubkey());
        EventAgencyAlignmentResponse responseTwo = responses[1];
        Assert.assertTrue(responseTwo.isSuccess());
        Assert.assertEquals(updateTwo.getEventAgencyAlignmentPubkey(), responseTwo.getEventAgencyAlignmentPubkey());
    }


}
