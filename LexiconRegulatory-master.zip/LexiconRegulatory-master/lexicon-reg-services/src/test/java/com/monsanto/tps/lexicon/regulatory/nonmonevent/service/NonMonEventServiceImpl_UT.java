package com.monsanto.tps.lexicon.regulatory.nonmonevent.service;

import com.monsanto.tps.aop.metric.DataPointHolder;
import com.monsanto.tps.lexicon.nonmonevent.NonMonEventPersistBatchRequest;
import com.monsanto.tps.lexicon.nonmonevent.NonMonEventPersistRequest;
import com.monsanto.tps.lexicon.nonmonevent.NonMonEventPersistResponse;
import com.monsanto.tps.lexicon.regulatory.helpers.AuditStagingDataPointEnum;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.delegate.NonMonEventCreation;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.delegate.NonMonEventUpdate;
import static org.easymock.classextension.EasyMock.*;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import org.junit.Before;
import org.junit.Test;

/**
 * nbwald - May 20, 2009 12:55:57 PM
 */
public class NonMonEventServiceImpl_UT
{
   private NonMonEventServiceImpl service;
   private NonMonEventCreation creation;
   private NonMonEventUpdate update;
   private DataPointHolder dataPointHolder;

   @Before
   public void before()
      throws Exception
   {
      creation = createMock(NonMonEventCreation.class);
      update = createMock(NonMonEventUpdate.class);
      dataPointHolder = createMock(DataPointHolder.class);
      service = new NonMonEventServiceImpl();
      service.setNonMonEventCreation(creation);
      service.setNonMonEventUpdate(update);
      service.setDataPointHolder(dataPointHolder);
   }

   @Test
   public void testSave_NoRequests_NoResponses()
      throws Exception
   {
      replay(creation, dataPointHolder);

      NonMonEventPersistBatchRequest batchRequest = new NonMonEventPersistBatchRequest();
      NonMonEventPersistResponse[] responses = service.save(batchRequest);

      verify(creation, dataPointHolder);
      assertThat(responses.length, is(0));
   }

   @Test
   public void testSave_BuildsAResponseForEachRequest()
      throws Exception
   {
      NonMonEventPersistBatchRequest batchRequest = new NonMonEventPersistBatchRequest();
      NonMonEventPersistRequest requestA = new NonMonEventPersistRequest();
      requestA.setAuditComment("AC_A");
      requestA.setAuditRequestor("AR_A");
      NonMonEventPersistRequest requestB = new NonMonEventPersistRequest();
      requestB.setAuditComment("AC_B");
      requestB.setAuditRequestor("AR_B");
      NonMonEventPersistRequest requestC = new NonMonEventPersistRequest();
      requestC.setAuditComment("AC_C");
      requestC.setAuditRequestor("AR_C");
      batchRequest.setValidateOnly(true);
      batchRequest.setRequests(requestA, requestB, requestC);
      dataPointHolder.add(AuditStagingDataPointEnum.AUDITCOMMENT.name(), "AC_A");
      expectLastCall();
      dataPointHolder.add(AuditStagingDataPointEnum.AUDITREQUESTOR.name(), "AR_A");
      expectLastCall();
      expect(creation.create(requestA, true)).andReturn(new NonMonEventPersistResponse());
      dataPointHolder.clear();
      expectLastCall();
      dataPointHolder.add(AuditStagingDataPointEnum.AUDITCOMMENT.name(), "AC_B");
      expectLastCall();
      dataPointHolder.add(AuditStagingDataPointEnum.AUDITREQUESTOR.name(), "AR_B");
      expectLastCall();
      expect(creation.create(requestB, true)).andReturn(new NonMonEventPersistResponse());
      dataPointHolder.clear();
      expectLastCall();
      dataPointHolder.add(AuditStagingDataPointEnum.AUDITCOMMENT.name(), "AC_C");
      expectLastCall();
      dataPointHolder.add(AuditStagingDataPointEnum.AUDITREQUESTOR.name(), "AR_C");
      expectLastCall();
      expect(creation.create(requestC, true)).andReturn(new NonMonEventPersistResponse());
      dataPointHolder.clear();
      expectLastCall();
      replay(creation, dataPointHolder);

      NonMonEventPersistResponse[] responses = service.save(batchRequest);

      verify(creation, dataPointHolder);
      assertThat(responses.length, is(3));
   }

   @Test
   public void testUpdate_NoRequests_NoResponses()
      throws Exception
   {
      replay(update, dataPointHolder);

      NonMonEventPersistBatchRequest batchRequest = new NonMonEventPersistBatchRequest();
      NonMonEventPersistResponse[] responses = service.save(batchRequest);

      verify(update, dataPointHolder);
      assertThat(responses.length, is(0));
   }

   @Test
   public void testUpdate_BuildsAResponseForEachRequest()
      throws Exception
   {
      NonMonEventPersistBatchRequest batchRequest = new NonMonEventPersistBatchRequest();
      NonMonEventPersistRequest requestA = new NonMonEventPersistRequest();
      requestA.setAuditComment("AC_A");
      requestA.setAuditRequestor("AR_A");
      NonMonEventPersistRequest requestB = new NonMonEventPersistRequest();
      requestB.setAuditComment("AC_B");
      requestB.setAuditRequestor("AR_B");
      NonMonEventPersistRequest requestC = new NonMonEventPersistRequest();
      requestC.setAuditComment("AC_C");
      requestC.setAuditRequestor("AR_C");
      batchRequest.setValidateOnly(true);
      batchRequest.setRequests(requestA, requestB, requestC);
      dataPointHolder.add(AuditStagingDataPointEnum.AUDITCOMMENT.name(), "AC_A");
      expectLastCall();
      dataPointHolder.add(AuditStagingDataPointEnum.AUDITREQUESTOR.name(), "AR_A");
      expectLastCall();
      expect(update.update(requestA, true)).andReturn(new NonMonEventPersistResponse());
      dataPointHolder.clear();
      expectLastCall();
      dataPointHolder.add(AuditStagingDataPointEnum.AUDITCOMMENT.name(), "AC_B");
      expectLastCall();
      dataPointHolder.add(AuditStagingDataPointEnum.AUDITREQUESTOR.name(), "AR_B");
      expectLastCall();
      expect(update.update(requestB, true)).andReturn(new NonMonEventPersistResponse());
      dataPointHolder.clear();
      expectLastCall();
      dataPointHolder.add(AuditStagingDataPointEnum.AUDITCOMMENT.name(), "AC_C");
      expectLastCall();
      dataPointHolder.add(AuditStagingDataPointEnum.AUDITREQUESTOR.name(), "AR_C");
      expectLastCall();
      expect(update.update(requestC, true)).andReturn(new NonMonEventPersistResponse());
      dataPointHolder.clear();
      expectLastCall();
      replay(update, dataPointHolder);

      NonMonEventPersistResponse[] responses = service.update(batchRequest);

      verify(update, dataPointHolder);
      assertThat(responses.length, is(3));
   }
}
