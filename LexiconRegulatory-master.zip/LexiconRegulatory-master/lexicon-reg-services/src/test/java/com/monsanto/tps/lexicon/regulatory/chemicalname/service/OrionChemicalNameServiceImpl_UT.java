package com.monsanto.tps.lexicon.regulatory.chemicalname.service;

import com.monsanto.tps.lexicon.chemicalname.OrionChemicalName;
import com.monsanto.tps.lexicon.regulatory.chemicalname.business.OrionChemicalNameBusiness;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/1/12
 * Time: 7:47 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class OrionChemicalNameServiceImpl_UT {

    @Mock
    private OrionChemicalNameBusiness chemicalNameBusiness;

    @InjectMocks
    private com.monsanto.tps.lexicon.chemicalname.ChemicalNameService chemicalNameService = new ChemicalNameServiceImpl();

    private static final List<OrionChemicalName> chemicalNameList = new ArrayList<OrionChemicalName>();

    @Before
    public void setup() {
        chemicalNameList.add(new OrionChemicalName());
    }

    @Test
    public void findChemicalName_success() throws Exception {
        when(chemicalNameBusiness.findChemicalNames("tryptophan")).thenReturn(chemicalNameList);

        final List<OrionChemicalName> actualChemicalNames = chemicalNameBusiness.findChemicalNames("tryptophan");

        assertEquals(actualChemicalNames, chemicalNameList);
    }
}