package com.monsanto.tps.lexicon.regulatory.event.queryset;

import com.monsanto.tps.compliance.referencedata.molecularinfo.ConstructIdentifier;
import com.monsanto.tps.compliance.referencedata.molecularinfo.ConstructPVCodeAssignment;
import com.monsanto.tps.compliance.referencedata.molecularinfo.PvCode;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Crop;
import com.monsanto.tps.lexicon.regulatory.crop.dao.CropDao;
import com.monsanto.tps.lexicon.regulatory.event.dao.eventconstructtransformation.midas.RegulatoryEventConstructTransformationWithoutTransformationBackgroundPSRowImpl;
import com.monsanto.tps.lexicon.regulatory.event.model.MockRegulatoryEventConstructTransformation;
import com.monsanto.tps.lexicon.regulatory.event.model.RegulatoryEventConstructTransformation;
import com.monsanto.tps.lexicon.regulatory.event.model.RegulatoryEventRequest;
import com.monsanto.tps.lexicon.regulatory.eventtraitservice.business.PVCodeAssignmentBuilder;
import com.monsanto.tps.lexicon.regulatory.eventtraitservice.business.PVCodesTransformer;
import org.apache.commons.lang.ArrayUtils;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Dec 8, 2005
 * Time: 11:08:41 AM
 */
public class RegulatoryEventRequestProcessor_UT {
    private static final String EVENT_ONE = "MON 1";

    private static final String PMON_ONE = "pMON13640_ONE";
    private static final String PMON_TWO = "pMON13640_TWO";

    private static final String CONSTRUCT = PMON_ONE;
    private static final String MULTI_PMON_CONSTRUCT = PMON_ONE + "," + PMON_TWO;

    private static final String TRANS_CODE_ONE = "PV-GMGT04_ONE";
    private static final String TRANS_CODE_TWO = "PV-GMGT04_TWO";

    private static final String TRANS_BG_ONE = "A5403_ONE";
    private static final long CORN_CROP_PUBKEY = 1015;
    private static final String CORN_CROP_PUBKEY_STRVAL = Long.toString(CORN_CROP_PUBKEY);
    private static final String CORN_CROP_NAME = "CORN";

    private static final String CROP_SPECIES = "ZM";
    private String[] pvCodes;
    private CropDao cropDao;
    private PVCodesTransformer pvCodesTransformer;
    private Crop crop;

    @Before
    public void before() {
        cropDao = mock(CropDao.class);
        crop = new Crop();
        crop.setCropPubkey(CORN_CROP_PUBKEY_STRVAL);
        crop.setAbbreviation(CROP_SPECIES);
        pvCodesTransformer = new PVCodesTransformer();
    }

    @Test
    public void testGetRegulatoryEvents_NoMatchesFound() throws Exception {
        MockRegulatoryEventQuerySet querySet = new MockRegulatoryEventQuerySet();
        RegulatoryEventRequest request = new RegulatoryEventRequest(EVENT_ONE, CORN_CROP_NAME);
        RegulatoryEventRequestProcessor processor = new RegulatoryEventRequestProcessorImpl(querySet, cropDao, pvCodesTransformer);
        when(cropDao.findByName(CORN_CROP_NAME)).thenReturn(crop);
        when(cropDao.findByAbbreviation(CROP_SPECIES)).thenReturn(Arrays.asList(crop));
        List<RegulatoryEventResponse> eventResponses = processor.getRegulatoryEvents(Arrays.asList(request));
        assertEquals(0, eventResponses.size());
    }

    @Test
    public void testGetRegulatoryEvents_NoConstruct_NoTransCodesFound_GetRegulatoryEvent() throws Exception {
        MockRegulatoryEventQuerySet querySet = new MockRegulatoryEventQuerySet();
        querySet.addEventConstructTransformation(EVENT_ONE, null, null);

        RegulatoryEventRequest request = new RegulatoryEventRequest(EVENT_ONE, CORN_CROP_NAME);
        RegulatoryEventRequestProcessor processor = new RegulatoryEventRequestProcessorImpl(querySet, cropDao, pvCodesTransformer);
        when(cropDao.findByName(CORN_CROP_NAME)).thenReturn(crop);
        when(cropDao.findByAbbreviation(CROP_SPECIES)).thenReturn(Arrays.asList(crop));

        List<RegulatoryEventResponse> eventResponses = processor.getRegulatoryEvents(Arrays.asList(request));
        assertEquals(1, eventResponses.size());
        assertEquals(EVENT_ONE, eventResponses.get(0).getEvent());
        assertNull(eventResponses.get(0).getEventConstructs().get(0).getConstruct());
        assertNull(eventResponses.get(0).getEventConstructs().get(0).getTransformationBackground());
        assertEquals(0, eventResponses.get(0).getEventConstructs().get(0).getTransCodes().length);
    }

    @Test
    public void testGetRegulatoryEvents_OnePmonInConstruct_NoTransCodesFound_GetRegulatoryEventWithNoTranscodes() throws Exception {
        MockRegulatoryEventQuerySet querySet = new MockRegulatoryEventQuerySet();
        querySet.addEventConstructTransformation(EVENT_ONE, CONSTRUCT, TRANS_BG_ONE);

        RegulatoryEventRequest request = new RegulatoryEventRequest(EVENT_ONE, CORN_CROP_NAME);
        RegulatoryEventRequestProcessor processor = new RegulatoryEventRequestProcessorImpl(querySet, cropDao, pvCodesTransformer);
        when(cropDao.findByName(CORN_CROP_NAME)).thenReturn(crop);
        when(cropDao.findByAbbreviation(CROP_SPECIES)).thenReturn(Arrays.asList(crop));

        List<RegulatoryEventResponse> eventResponses = processor.getRegulatoryEvents(Arrays.asList(request));
        assertEquals(1, eventResponses.size());
        assertEquals(EVENT_ONE, eventResponses.get(0).getEvent());
        assertEquals(CONSTRUCT, eventResponses.get(0).getEventConstructs().get(0).getConstruct());
        assertEquals(TRANS_BG_ONE, eventResponses.get(0).getEventConstructs().get(0).getTransformationBackground());
        assertEquals(0, eventResponses.get(0).getEventConstructs().get(0).getTransCodes().length);
    }

    @Test
    public void testGetRegulatoryEvents_OnePmonInConstruct_OneNonCombinedTransCodeForPmon_GetRegulatoryEventWithSingleTransCode() throws Exception {
        MockRegulatoryEventQuerySet querySet = new MockRegulatoryEventQuerySet();
        querySet.addEventConstructTransformation(EVENT_ONE, CONSTRUCT, TRANS_BG_ONE);
        querySet.addTransCodeForSinglePmonConstruct(TRANS_CODE_ONE);

        RegulatoryEventRequest request = new RegulatoryEventRequest(EVENT_ONE, CORN_CROP_NAME);
        RegulatoryEventRequestProcessor processor = new RegulatoryEventRequestProcessorImpl(querySet, cropDao, pvCodesTransformer);
        when(cropDao.findByName(CORN_CROP_NAME)).thenReturn(crop);
        when(cropDao.findByAbbreviation(CROP_SPECIES)).thenReturn(Arrays.asList(crop));
        List<RegulatoryEventResponse> eventResponses = processor.getRegulatoryEvents(Arrays.asList(request));

        assertEquals(1, eventResponses.size());
        assertEquals(EVENT_ONE, eventResponses.get(0).getEvent());
        assertEquals(CONSTRUCT, eventResponses.get(0).getEventConstructs().get(0).getConstruct());
        assertEquals(TRANS_BG_ONE, eventResponses.get(0).getEventConstructs().get(0).getTransformationBackground());
        assertEquals(TRANS_CODE_ONE, eventResponses.get(0).getEventConstructs().get(0).getTransCodes()[0]);
    }

    @Test
    public void testGetRegulatoryEvents_OnePmonInConstruct_TwoNonCombinedTransCodesForPmon_GetRegulatoryEventWithTwoTransCodes() throws Exception {
        MockRegulatoryEventQuerySet querySet = new MockRegulatoryEventQuerySet();
        querySet.addEventConstructTransformation(EVENT_ONE, CONSTRUCT, TRANS_BG_ONE);
        querySet.addTransCodeForSinglePmonConstruct(TRANS_CODE_ONE);
        querySet.addTransCodeForSinglePmonConstruct(TRANS_CODE_TWO);

        RegulatoryEventRequest request = new RegulatoryEventRequest(EVENT_ONE, CORN_CROP_NAME);
        RegulatoryEventRequestProcessor processor = new RegulatoryEventRequestProcessorImpl(querySet, cropDao, pvCodesTransformer);
        when(cropDao.findByName(CORN_CROP_NAME)).thenReturn(crop);
        when(cropDao.findByAbbreviation(CROP_SPECIES)).thenReturn(Arrays.asList(crop));
        List<RegulatoryEventResponse> eventResponses = processor.getRegulatoryEvents(Arrays.asList(request));

        assertEquals(1, eventResponses.size());
        assertEquals(EVENT_ONE, eventResponses.get(0).getEvent());
        assertEquals(CONSTRUCT, eventResponses.get(0).getEventConstructs().get(0).getConstruct());
        assertEquals(TRANS_BG_ONE, eventResponses.get(0).getEventConstructs().get(0).getTransformationBackground());

        assertEquals(2, eventResponses.get(0).getEventConstructs().get(0).getTransCodes().length);
        List transCodes = Arrays.asList(eventResponses.get(0).getEventConstructs().get(0).getTransCodes());
        assertTrue(transCodes.contains(TRANS_CODE_ONE));
        assertTrue(transCodes.contains(TRANS_CODE_TWO));
    }

    @Test
    public void testGetRegulatoryEvents_TwoPmonInConstruct_NoTransCodesFound_GetRegulatoryEventWithoutTransCodes() throws Exception {
        MockRegulatoryEventQuerySet querySet = new MockRegulatoryEventQuerySet();
        querySet.addEventConstructTransformation(EVENT_ONE, MULTI_PMON_CONSTRUCT, TRANS_BG_ONE);

        RegulatoryEventRequest request = new RegulatoryEventRequest(EVENT_ONE, CORN_CROP_NAME);
        RegulatoryEventRequestProcessor processor = new RegulatoryEventRequestProcessorImpl(querySet, cropDao, pvCodesTransformer);
        when(cropDao.findByName(CORN_CROP_NAME)).thenReturn(crop);
        when(cropDao.findByAbbreviation(CROP_SPECIES)).thenReturn(Arrays.asList(crop));
        List<RegulatoryEventResponse> eventResponses = processor.getRegulatoryEvents(Arrays.asList(request));

        assertEquals(1, eventResponses.size());
        assertEquals(EVENT_ONE, eventResponses.get(0).getEvent());
        assertEquals(MULTI_PMON_CONSTRUCT, eventResponses.get(0).getEventConstructs().get(0).getConstruct());
        assertEquals(TRANS_BG_ONE, eventResponses.get(0).getEventConstructs().get(0).getTransformationBackground());
        assertTrue(ArrayUtils.isEmpty(eventResponses.get(0).getEventConstructs().get(0).getTransCodes()));
    }

    @Test
    public void testGetRegulatoryEvents_TwoPmonsInConstruct_OneCombinedTransCodeForPmons_GetRegulatoryEventWithSingleTransCode() throws Exception {
        // public List<ConstructPVCodeAssignment> findProductVectorsByCropIdAndConstructs(long cropPubkey, List<ConstructIdentifier> constructIdentifiers)
        RegulatoryEventQuerySet querySet = mock(RegulatoryEventQuerySet.class);
        ConstructIdentifier ci = new ConstructIdentifier(PMON_ONE, PMON_TWO);
        List<PvCode> pvCodes = PVCodeAssignmentBuilder.formPVCodes(Arrays.asList(TRANS_CODE_ONE));
        ConstructPVCodeAssignment assignment = new ConstructPVCodeAssignment(ci, pvCodes);
        MockRegulatoryEventConstructTransformation xformation = new MockRegulatoryEventConstructTransformation(EVENT_ONE, MULTI_PMON_CONSTRUCT, TRANS_BG_ONE);
        when(querySet.getEventConstructTransformations(eq(EVENT_ONE), eq(CROP_SPECIES))).thenReturn(new RegulatoryEventConstructTransformation[]{xformation});
        when(querySet.findProductVectorsByCropIdAndConstructs(eq(new Long(crop.getCropPubkey())), eq(Arrays.asList(ci)))).thenReturn(Arrays.asList(assignment));
//      querySet.addEventConstructTransformation(EVENT_ONE, MULTI_PMON_CONSTRUCT, TRANS_BG_ONE);
//      querySet.setTransCodeForMultiPmonConstruct(TRANS_CODE_ONE);

        RegulatoryEventRequest request = new RegulatoryEventRequest(EVENT_ONE, CORN_CROP_NAME);
        when(cropDao.findByName(CORN_CROP_NAME)).thenReturn(crop);
        when(cropDao.findByAbbreviation(CROP_SPECIES)).thenReturn(Arrays.asList(crop));
        RegulatoryEventRequestProcessor processor = new RegulatoryEventRequestProcessorImpl(querySet, cropDao, pvCodesTransformer);

        List<RegulatoryEventResponse> eventResponses = processor.getRegulatoryEvents(Arrays.asList(request));
        assertEquals(1, eventResponses.size());

        assertEquals(EVENT_ONE, eventResponses.get(0).getEvent());
        assertEquals(MULTI_PMON_CONSTRUCT, eventResponses.get(0).getEventConstructs().get(0).getConstruct());
        assertEquals(TRANS_BG_ONE, eventResponses.get(0).getEventConstructs().get(0).getTransformationBackground());
        assertEquals(1, eventResponses.get(0).getEventConstructs().get(0).getTransCodes().length);
        assertEquals(TRANS_CODE_ONE, eventResponses.get(0).getEventConstructs().get(0).getTransCodes()[0]);
    }

    @Test
    public void testRegulatoryEventRequestProcessorCalls_FindProductVectorsForCombinedConstructInRegulatoryEventQuerySet_ForMultiplePMONs() throws Exception {
        RegulatoryEventQuerySet regulatoryEventQuerySet = mock(RegulatoryEventQuerySet.class);
        RegulatoryEventRequestProcessor processor = new RegulatoryEventRequestProcessorImpl(regulatoryEventQuerySet, cropDao, pvCodesTransformer);
        pvCodes = new String[]{"PV-BNCTT1111"};
        String[] combinedConstructs = new String[]{PMON_ONE, PMON_TWO};

        RegulatoryEventRequest request = new RegulatoryEventRequest(EVENT_ONE, CORN_CROP_NAME);
        RegulatoryEventConstructTransformation[] regulatoryEventConstructTransformations
                = new RegulatoryEventConstructTransformation[2];
        regulatoryEventConstructTransformations[0] = new RegulatoryEventConstructTransformationWithoutTransformationBackgroundPSRowImpl(EVENT_ONE, PMON_ONE);
        regulatoryEventConstructTransformations[1] = new RegulatoryEventConstructTransformationWithoutTransformationBackgroundPSRowImpl(EVENT_ONE, PMON_TWO);

        when(cropDao.findByName(CORN_CROP_NAME)).thenReturn(crop);
        when(cropDao.findByAbbreviation(CROP_SPECIES)).thenReturn(Arrays.asList(crop));
        when(regulatoryEventQuerySet.getEventConstructTransformations(
                EVENT_ONE, CROP_SPECIES)).thenReturn(regulatoryEventConstructTransformations);
        when(regulatoryEventQuerySet.findProductVectorsByCropIdAndConstructNameForCombinedConstructs(
                eq(CORN_CROP_PUBKEY), eq(combinedConstructs))).thenReturn(pvCodes);
        List<RegulatoryEventResponse> responses = processor.getRegulatoryEvents(Arrays.asList(request));
        assertThat(responses.size(), is(1));
        assertThat(responses.get(0).getEvent(), is(EVENT_ONE));
        assertThat(responses.get(0).getEventConstructs().get(0).getConstruct(), is(PMON_ONE));
        assertThat(responses.get(0).getEventConstructs().get(0).getCrop(), is(CORN_CROP_NAME));
        assertThat(responses.get(0).getEventConstructs().get(0).getTransformationBackground(), nullValue());
        assertThat(responses.get(0).getEventConstructs().get(1).getConstruct(), is(PMON_TWO));
        assertThat(responses.get(0).getEventConstructs().get(1).getCrop(), is(CORN_CROP_NAME));
        assertThat(responses.get(0).getEventConstructs().get(1).getTransformationBackground(), nullValue());
    }

    @Test
    public void testRegulatoryEventRequestProcessorCalls_findProductVectorsForSingleConstructs_InRegulatoryEventQuerySet_ForSinglePMON() throws Exception {
        RegulatoryEventQuerySet regulatoryEventQuerySet = mock(RegulatoryEventQuerySet.class);
        CropDao cropDao = mock(CropDao.class);
        RegulatoryEventRequestProcessor processor = new RegulatoryEventRequestProcessorImpl(regulatoryEventQuerySet, cropDao, pvCodesTransformer);
        Crop crop = new Crop();
        crop.setAbbreviation(CROP_SPECIES);
        crop.setCropPubkey(CORN_CROP_PUBKEY_STRVAL);
        pvCodes = new String[]{"PV-ZMST1111"};
        RegulatoryEventRequest request = new RegulatoryEventRequest(EVENT_ONE, CORN_CROP_NAME);

        when(cropDao.findByName(CORN_CROP_NAME)).thenReturn(crop);
        when(cropDao.findByAbbreviation(CROP_SPECIES)).thenReturn(Arrays.asList(crop));
        RegulatoryEventConstructTransformation[] regulatoryEventConstructTransformations
                = new RegulatoryEventConstructTransformation[1];
        regulatoryEventConstructTransformations[0] = new RegulatoryEventConstructTransformationWithoutTransformationBackgroundPSRowImpl(EVENT_ONE, PMON_ONE);
        when(regulatoryEventQuerySet.getEventConstructTransformations(EVENT_ONE, CROP_SPECIES)).thenReturn(regulatoryEventConstructTransformations);
        when(regulatoryEventQuerySet.findProductVectorsByCropIdAndConstructNameForSingleConstructs(CORN_CROP_PUBKEY, PMON_ONE)).thenReturn(pvCodes);

        List<RegulatoryEventResponse> responses = processor.getRegulatoryEvents(Arrays.asList(request));
        assertThat(responses.size(), is(1));
        assertThat(responses.get(0).getEvent(), is(EVENT_ONE));
        assertThat(responses.get(0).getEventConstructs().get(0).getConstruct(), is(PMON_ONE));
        assertThat(responses.get(0).getEventConstructs().get(0).getCrop(), is(CORN_CROP_NAME));
        assertThat(responses.get(0).getEventConstructs().get(0).getTransformationBackground(), nullValue());
    }


    @Test
    public void testGetRegulatoryEvents_MultipleEvents_TriesCombinedConstruct_NoConstruct_NoTransCodesFound_GetRegulatoryEvent() throws Exception {
        MockRegulatoryEventQuerySet querySet = new MockRegulatoryEventQuerySet();
        querySet.addEventConstructTransformation(EVENT_ONE, null, null);
        querySet.addEventConstructTransformation(EVENT_ONE, null, null);

        RegulatoryEventRequest request = new RegulatoryEventRequest(EVENT_ONE, CORN_CROP_NAME);
        RegulatoryEventRequestProcessor processor = new RegulatoryEventRequestProcessorImpl(querySet, cropDao, pvCodesTransformer);
        when(cropDao.findByName(CORN_CROP_NAME)).thenReturn(crop);
        when(cropDao.findByAbbreviation(CROP_SPECIES)).thenReturn(Arrays.asList(crop));

        List<RegulatoryEventResponse> responses = processor.getRegulatoryEvents(Arrays.asList(request));

        assertEquals(1, responses.size());
        assertEquals(EVENT_ONE, responses.get(0).getEvent());
        assertEquals(2, responses.get(0).getEventConstructs().size());
        assertNull(responses.get(0).getEventConstructs().get(0).getConstruct());
        assertNull(responses.get(0).getEventConstructs().get(0).getTransformationBackground());
        assertTrue(ArrayUtils.isEmpty(responses.get(0).getEventConstructs().get(0).getTransCodes()));
    }
}
