package com.monsanto.tps.lexicon.regulatory.chemicalname.business;

import com.monsanto.tps.lexicon.chemicalname.OrionChemicalName;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ChemicalName;
import com.monsanto.tps.lexicon.regulatory.chemicalname.dao.ChemicalNameDAO;
import org.hamcrest.Matchers;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/1/12
 * Time: 7:47 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class ChemicalNameBusiness_UT {

    @Mock
    private ChemicalNameDAO chemicalNameDAO;

    @InjectMocks
    private ChemicalNameBusiness chemicalNameBusiness = new ChemicalNameBusiness();

    private final List<ChemicalName> singleChemicalNameListFromDAO;
    private final List<ChemicalName> multiChemicalNameListFromDAO;
    private final List<ChemicalName> anotherChemicalNameListFromDAO;
    private static final List<ChemicalName> emptyListFromDAO = new ArrayList<ChemicalName>();

    private final List<OrionChemicalName> singleChemicalNameListFromBusiness;
    private final List<OrionChemicalName> multiChemicalNameListFromBusiness;
    private final List<OrionChemicalName> anotherChemicalNameListFromBusiness;
    private static final List<OrionChemicalName> emptyListFromBusiness = new ArrayList<OrionChemicalName>();

    private final List<String> singleActiveIngredientList;
    private final List<String> multipleActiveIngredientList;
    private final List<String> emptyActiveIngredientList = new ArrayList<String>();

    public ChemicalNameBusiness_UT() {
        singleChemicalNameListFromDAO = new ArrayList<ChemicalName>();
        singleChemicalNameListFromDAO.add(new ChemicalName(0, "ingredient", true, "alias", "CAS", "IUPAC", "cpNumber",
                "amt", "unit", "designation", "class", "name"));

        multiChemicalNameListFromDAO = new ArrayList<ChemicalName>();
        multiChemicalNameListFromDAO.add(new ChemicalName(1, "ingredient1", true, "alias1", "CAS1", "IUPAC1", "cpNumber1",
                "amt1", "unit1", "designation1", "class1", "name1"));
        multiChemicalNameListFromDAO.add(new ChemicalName(2, "ingredient2", true, "alias2", "CAS2", "IUPAC2", "cpNumber2",
                "amt2", "unit2", "designation2", "class2", "name2"));

        anotherChemicalNameListFromDAO = new ArrayList<ChemicalName>();
        anotherChemicalNameListFromDAO.add(new ChemicalName(3, "ingredient3", true, "alias3", "CAS3", "IUPAC3", "cpNumber3",
                "amt3", "unit3", "designation3", "class3", "name3"));

        singleChemicalNameListFromBusiness = new ArrayList<OrionChemicalName>();
        singleChemicalNameListFromBusiness.add(new OrionChemicalName("ingredient", true, "alias", "CAS", "IUPAC", "cpNumber",
                "amt", "unit", "designation", "class", "name"));

        multiChemicalNameListFromBusiness = new ArrayList<OrionChemicalName>();
        multiChemicalNameListFromBusiness.add(new OrionChemicalName("ingredient1", true, "alias1", "CAS1", "IUPAC1", "cpNumber1",
                "amt1", "unit1", "designation1", "class1", "name1"));
        multiChemicalNameListFromBusiness.add(new OrionChemicalName("ingredient2", true, "alias2", "CAS2", "IUPAC2", "cpNumber2",
                "amt2", "unit2", "designation2", "class2", "name2"));

        anotherChemicalNameListFromBusiness = new ArrayList<OrionChemicalName>();
        anotherChemicalNameListFromBusiness.add(new OrionChemicalName("ingredient3", true, "alias3", "CAS3", "IUPAC3", "cpNumber3",
                "amt3", "unit3", "designation3", "class3", "name3"));

        singleActiveIngredientList = Arrays.asList("ingredientA");
        multipleActiveIngredientList = Arrays.asList("ingredientB", "ingredientC");
    }

    @Test
    public void findChemicalName_findNone() throws Exception {

        when(chemicalNameDAO.findChemicalNames("asdf")).thenReturn(emptyListFromDAO);

        final List<OrionChemicalName> actualChemicalNames = chemicalNameBusiness.findChemicalNames("asdf");

        checkChemicalNameLists(actualChemicalNames, emptyListFromBusiness);
    }

    @Test
    public void findChemicalName_findSingle() throws Exception {

        when(chemicalNameDAO.findChemicalNames("tryptophan")).thenReturn(singleChemicalNameListFromDAO);

        final List<OrionChemicalName> actualChemicalNames = chemicalNameBusiness.findChemicalNames("tryptophan");

        checkChemicalNameLists(actualChemicalNames, singleChemicalNameListFromBusiness);
    }

    @Test
    public void findChemicalName_findByWildcard() throws Exception {

        when(chemicalNameDAO.findChemicalNames("Tri%")).thenReturn(multiChemicalNameListFromDAO);

        final List<OrionChemicalName> actualChemicalNames = chemicalNameBusiness.findChemicalNames("Tri*");

        checkChemicalNameLists(actualChemicalNames, multiChemicalNameListFromBusiness);
    }

    @Test
    public void findChemicalName_findAll() throws Exception {

        when(chemicalNameDAO.findChemicalNames("%")).thenReturn(multiChemicalNameListFromDAO);

        final List<OrionChemicalName> actualChemicalNames = chemicalNameBusiness.findChemicalNames("");

        checkChemicalNameLists(actualChemicalNames, multiChemicalNameListFromBusiness);
    }

    private void checkChemicalNameLists(final List<OrionChemicalName> actualChemicalNames, final List<OrionChemicalName> singleChemicalNameListFromBusiness) {
        assertNotNull(actualChemicalNames);

        for(int i=0; i<singleChemicalNameListFromBusiness.size(); i++) {
            final OrionChemicalName chemicalName = actualChemicalNames.get(i);
            assertTrue(containsChemical(chemicalName, actualChemicalNames));
        }
    }

    private boolean containsChemical(final OrionChemicalName chemicalName, final List<OrionChemicalName> list) {
        for(OrionChemicalName name : list) {
            if(name.getMaterialName().equals(chemicalName.getMaterialName()) && name.getActiveIngredient().equals(chemicalName.getActiveIngredient())
                && name.getMaterialClassification().equals(chemicalName.getMaterialClassification()) && name.getActiveStatus() == chemicalName.getActiveStatus()
                && name.getFormulatedAmount().equals(chemicalName.getFormulatedAmount()) && name.getFormulatedAmountUnit().equals(chemicalName.getFormulatedAmountUnit())
                && name.getFormulationDesignation().equals(chemicalName.getFormulationDesignation())) {

                return true;
            }
        }
        return false;
    }

    @Test
    public void findChemicalMaterial() {
        when(chemicalNameDAO.findChemicalCommercialProduct("c%")).thenReturn(multiChemicalNameListFromDAO);
        when(chemicalNameDAO.findChemicalFormulation("c%")).thenReturn(singleChemicalNameListFromDAO);
        when(chemicalNameDAO.findChemicalActiveIngredient("c%")).thenReturn(anotherChemicalNameListFromDAO);
        when(chemicalNameDAO.findActiveIngredientNames(0, "name")).thenReturn(singleActiveIngredientList);
        when(chemicalNameDAO.findActiveIngredientNames(1, "name1")).thenReturn(multipleActiveIngredientList);
        when(chemicalNameDAO.findActiveIngredientNames(2, "name2")).thenReturn(emptyActiveIngredientList);

        final List<OrionChemicalName> actualChemicalNames = chemicalNameBusiness.findChemicalMaterials("c*");

        verify(chemicalNameDAO).findActiveIngredientNames(0, "name");
        verify(chemicalNameDAO).findActiveIngredientNames(1, "name1");
        verify(chemicalNameDAO).findActiveIngredientNames(2, "name2");
        checkChemicalNameLists(actualChemicalNames, multiChemicalNameListFromBusiness);
        checkChemicalNameLists(actualChemicalNames, singleChemicalNameListFromBusiness);
        checkChemicalNameLists(actualChemicalNames, anotherChemicalNameListFromBusiness);

        for(OrionChemicalName name : actualChemicalNames) {
            if(name.getMaterialName().equals("name")) {
                assertThat(name.getActiveIngredient(), Matchers.equalTo("ingredientA"));
            }
            else if(name.getMaterialName().equals("name1")) {
                assertThat(name.getActiveIngredient(), Matchers.equalTo("ingredientB,ingredientC"));
            }
            else if(name.getMaterialName().equals("name2")) {
                assertThat(name.getActiveIngredient(), Matchers.equalTo(""));
            }
        }
    }
}
