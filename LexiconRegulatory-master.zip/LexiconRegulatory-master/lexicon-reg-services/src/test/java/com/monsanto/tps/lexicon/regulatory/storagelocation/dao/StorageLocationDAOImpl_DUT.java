package com.monsanto.tps.lexicon.regulatory.storagelocation.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.LexiconDataUnitTestCase;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.StorageLocation;
import com.monsanto.tps.lexicon.regulatory.eventsreginfo.util.dao.lexicon.TempSessionOcdDao;
import org.junit.Test;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

/**
 * Created by IntelliJ IDEA.
 * User: MMR
 * Date: 2/21/12
 * Time: 6:28 PM
 */
public class StorageLocationDAOImpl_DUT extends LexiconDataUnitTestCase {

    private static final int REQUEST_ID = 20122002;

    @Resource
    private TempSessionOcdDao tempSessionOcdDao;

    @Resource
    private StorageLocationDAO storageLocationDAO;

    @Test
    public void findStorageLocationsByStorageLocationWildCardIsSuccessful() throws Exception {
        StorageLocation storageLocation = new StorageLocation();
        storageLocation.setStorageLocation("S%");
        List<StorageLocation> storageLocations = storageLocationDAO.findActiveStorageLocations(storageLocation);
        assertNotNull(storageLocations);
    }

    @Test
    public void findStorageLocationsByPhysicalLocationIsSuccessful() throws Exception {
        StorageLocation storageLocation = new StorageLocation();
        storageLocation.setPhysicalLocation("%280");
        List<StorageLocation> storageLocations = storageLocationDAO.findActiveStorageLocations(storageLocation);
        assertNotNull(storageLocations);
    }

    @Test
    public void findStorageLocationsByListIsSuccessful() throws Exception {
        tempSessionOcdDao.clearValues(REQUEST_ID);
        tempSessionOcdDao.insertText1Values(REQUEST_ID, getStorageLocations());
        List<StorageLocation> storageLocations = storageLocationDAO.findStorageLocationsByList();
        assertNotNull(storageLocations);
        assertFalse(storageLocations.isEmpty());
    }

    private List<String> getStorageLocations() {
        List<String> storageLocations = new ArrayList<String>();
        storageLocations.add("Q1UOL N Cage");
        storageLocations.add("Q1UOL S Cage");
        return storageLocations;
    }

}
