package com.monsanto.tps.lexicon.regulatory.event.dao;

import com.monsanto.dbdataservices.SQLUtil;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.AgencyBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.AgencyMaterialTypeBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.ChemicalNameBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.CropBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.EventAgencyAlignmentBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.LexiconDataUnitTestCase;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Agency;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.AgencyMaterialType;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Crop;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MaterialChemicalName;
import org.apache.commons.lang.ArrayUtils;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.junit.Assert;
import org.junit.Test;

import javax.annotation.Resource;
import java.util.Date;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

/**
 * nbwald - Jan 7, 2009 5:04:05 PM
 */
public class EventAgencyAlignmentDaoImpl_DUT
        extends LexiconDataUnitTestCase {
    @Resource
    private EventAgencyAlignmentDaoImpl eventAgencyAlignmentDao;

    @Resource
    private SessionFactory lexiconSessionFactory;

    @Test
    public void testFindByEvent_EventAgencyAlignmentNotFound()
            throws Exception {
        EventAgencyAlignment[] eventAgencies = eventAgencyAlignmentDao.findByEventAndCrop("ZM_1234", "CORN");

        assertEquals(0, eventAgencies.length);
    }

    @Test
    public void testFindByEvent_MultipleEventAgencyAlignmentsFound()
            throws Exception {
        Crop crop = CropBuilder.corn();
        EventAgencyAlignment expectedEpa = new EventAgencyAlignmentBuilder().
                withEvent("ZM_5678").
                withAgency(AgencyBuilder.epa()).
                regulated().
                withDeregulatedEffectiveDate(new Date()).
                withMaxQuantity(100).
                withCrop(crop).
                create();

        EventAgencyAlignment expectedUsda = new EventAgencyAlignmentBuilder().
                withEvent("ZM_5678").
                withAgency(AgencyBuilder.usda()).
                regulated().
                withDeregulatedEffectiveDate(new Date()).
                withMaxQuantity(100).
                withCrop(crop).
                create();

        EventAgencyAlignment notExpected = new EventAgencyAlignmentBuilder().
                withEvent("ZM_5678").
                withAgency(AgencyBuilder.epa()).
                regulated().
                withDeregulatedEffectiveDate(new Date()).
                withMaxQuantity(100).
                withCrop(CropBuilder.soybeans()).
                create();

        EventAgencyAlignment notExpectedTwo = new EventAgencyAlignmentBuilder().
                withEvent("ZM_5678").
                withAgency(AgencyBuilder.stewardship()).
                regulated().
                withDeregulatedEffectiveDate(new Date()).
                withMaxQuantity(100).
                withCrop(CropBuilder.soybeans()).
                create();

        EventAgencyAlignment[] eventAgencies = eventAgencyAlignmentDao.findByEventAndCrop("ZM_5678", crop.getCropName());

        assertEquals(2, eventAgencies.length);

        EventAgencyAlignment actualEpa = findAgencyWithAbbreviation(eventAgencies, "EPA");
        assertEquals(expectedEpa.getAgency().getAgencyPubkey(), actualEpa.getAgency().getAgencyPubkey());
        assertEquals(expectedEpa.getDeregulatedEffectiveDate(), actualEpa.getDeregulatedEffectiveDate());
        assertEquals(expectedEpa.getMaterialName(), actualEpa.getMaterialName());
        assertEquals(expectedEpa.getEventAgencyAlignmentId(), actualEpa.getEventAgencyAlignmentId());
        assertEquals(expectedEpa.getEventAgencyAlignmentPubkey(), actualEpa.getEventAgencyAlignmentPubkey());
        assertEquals(expectedEpa.getMaxQuantity(), actualEpa.getMaxQuantity());
        assertEquals(expectedEpa.getRegulated(), actualEpa.getRegulated());

        EventAgencyAlignment actualUsda = findAgencyWithAbbreviation(eventAgencies, "USDA");
        assertEquals(expectedUsda.getAgency().getAgencyPubkey(), actualUsda.getAgency().getAgencyPubkey());
        assertEquals(expectedUsda.getDeregulatedEffectiveDate(), actualUsda.getDeregulatedEffectiveDate());
        assertEquals(expectedUsda.getMaterialName(), actualUsda.getMaterialName());
        assertEquals(expectedUsda.getEventAgencyAlignmentId(), actualUsda.getEventAgencyAlignmentId());
        assertEquals(expectedUsda.getEventAgencyAlignmentPubkey(), actualUsda.getEventAgencyAlignmentPubkey());
        assertEquals(expectedUsda.getMaxQuantity(), actualUsda.getMaxQuantity());
        assertEquals(expectedUsda.getRegulated(), actualUsda.getRegulated());
    }

    @Test
    public void testFindByEvent_EventNameAndCropNameIsCaseInsensitive()
            throws Exception {
        EventAgencyAlignment expected = new EventAgencyAlignmentBuilder().
                withEvent("ZM_5678").
                withAgency(AgencyBuilder.epa()).
                regulated().
                withDeregulatedEffectiveDate(new Date()).
                withMaxQuantity(100).
                withCrop(CropBuilder.corn()).
                create();

        EventAgencyAlignment notExpected = new EventAgencyAlignmentBuilder().
                withEvent("ZM_5678").
                withAgency(AgencyBuilder.usda()).
                regulated().
                withDeregulatedEffectiveDate(new Date()).
                withMaxQuantity(100).
                withCrop(CropBuilder.soybeans()).
                create();

        EventAgencyAlignment[] eventAgencies = eventAgencyAlignmentDao.findByEventAndCrop("zm_5678", "corn");

        assertEquals(1, eventAgencies.length);
        EventAgencyAlignment actual = eventAgencies[0];
        assertEquals(expected.getAgency().getAgencyPubkey(), actual.getAgency().getAgencyPubkey());
        assertEquals(expected.getDeregulatedEffectiveDate(), actual.getDeregulatedEffectiveDate());
        assertEquals(expected.getMaterialName(), actual.getMaterialName());
        assertEquals(expected.getEventAgencyAlignmentId(), actual.getEventAgencyAlignmentId());
        assertEquals(expected.getEventAgencyAlignmentPubkey(), actual.getEventAgencyAlignmentPubkey());
        assertEquals(expected.getMaxQuantity(), actual.getMaxQuantity());
        assertEquals(expected.getRegulated(), actual.getRegulated());
        assertEquals(expected.getCrop().getCropName(), actual.getCrop().getCropName());
    }

    @Test
    public void testFindByEventAndCrop_FindDeregulatedEvent()
            throws Exception {
        Crop crop = CropBuilder.corn();
        EventAgencyAlignment expected = new EventAgencyAlignmentBuilder().
                withEvent("ZM_5678").
                withAgency(AgencyBuilder.epa()).
                deregulated().
                withDeregulatedEffectiveDate(new Date()).
                withMaxQuantity(100).
                withCrop(crop).
                create();

        EventAgencyAlignment[] eventAgencies = eventAgencyAlignmentDao.findByEventAndCrop("zm_5678", crop.getCropName());

        assertEquals(1, eventAgencies.length);
        EventAgencyAlignment actual = eventAgencies[0];
        assertEquals(expected.getAgency().getAgencyPubkey(), actual.getAgency().getAgencyPubkey());
        assertEquals(expected.getDeregulatedEffectiveDate(), actual.getDeregulatedEffectiveDate());
        assertEquals(expected.getMaterialName(), actual.getMaterialName());
        assertEquals(expected.getEventAgencyAlignmentId(), actual.getEventAgencyAlignmentId());
        assertEquals(expected.getEventAgencyAlignmentPubkey(), actual.getEventAgencyAlignmentPubkey());
        assertEquals(expected.getMaxQuantity(), actual.getMaxQuantity());
        assertEquals(expected.getRegulated(), actual.getRegulated());
    }

    @Test
    public void testFindByEventAndCrop_FindEventWithDiscoveryMaterialSet()
            throws Exception {
        Crop crop = CropBuilder.corn();
        EventAgencyAlignment expected = new EventAgencyAlignmentBuilder().
                withEvent("ZM_5678").
                withAgency(AgencyBuilder.epa()).
                deregulated().
                withDeregulatedEffectiveDate(new Date()).
                withMaxQuantity(100).
                withCrop(crop).
                withDiscoveryMaterial(Boolean.TRUE).
                create();

        Session session = lexiconSessionFactory.getCurrentSession();
        session.flush();
        session.clear();
        EventAgencyAlignment[] eventAgencies = eventAgencyAlignmentDao.findByEventAndCrop("zm_5678", crop.getCropName());

        assertEquals(1, eventAgencies.length);
        EventAgencyAlignment actual = eventAgencies[0];
        assertEquals(expected.getAgency().getAgencyPubkey(), actual.getAgency().getAgencyPubkey());
        assertEquals(Boolean.TRUE, actual.getDiscoveryMaterial());
    }

    @Test
    public void testFindByEventCropAndAgencyPubkey_EventAgencyAlignmentNotFound()
            throws Exception {
        EventAgencyAlignment eventAgencyAlignment = eventAgencyAlignmentDao.findByEventCropAndAgencyPubkey("ZM_1234", "Corn", "1111");
        assertNull(eventAgencyAlignment);
    }

    @Test
    public void testFindByEventCropAndAgencyPubkey_ReturnsEventAgencyAlignment()
            throws Exception {
        Agency agency = AgencyBuilder.epa();
        Crop crop = CropBuilder.corn();
        EventAgencyAlignment expected = new EventAgencyAlignmentBuilder().
                withEvent("ZM_5678").
                withAgency(agency).
                deregulated().
                withDeregulatedEffectiveDate(new Date()).
                withMaxQuantity(100).
                withCrop(crop).
                create();

        EventAgencyAlignment notExpected = new EventAgencyAlignmentBuilder().
                withEvent("ZM_5678").
                withAgency(agency).
                deregulated().
                withDeregulatedEffectiveDate(new Date()).
                withMaxQuantity(100).
                withCrop(CropBuilder.soybeans()).
                create();

        EventAgencyAlignment eventAgencyAlignment = eventAgencyAlignmentDao.findByEventCropAndAgencyPubkey("zm_5678", crop.getCropName(), agency.getAgencyPubkey());

        assertNotNull(eventAgencyAlignment);
        assertEquals(expected.getAgency().getAgencyPubkey(), eventAgencyAlignment.getAgency().getAgencyPubkey());
        assertEquals(expected.getDeregulatedEffectiveDate(), eventAgencyAlignment.getDeregulatedEffectiveDate());
        assertEquals(expected.getMaterialName(), eventAgencyAlignment.getMaterialName());
        assertEquals(expected.getEventAgencyAlignmentId(), eventAgencyAlignment.getEventAgencyAlignmentId());
        assertEquals(expected.getEventAgencyAlignmentPubkey(), eventAgencyAlignment.getEventAgencyAlignmentPubkey());
        assertEquals(expected.getMaxQuantity(), eventAgencyAlignment.getMaxQuantity());
        assertEquals(expected.getRegulated(), eventAgencyAlignment.getRegulated());
        assertEquals(expected.getCrop().getCropName(), eventAgencyAlignment.getCrop().getCropName());
    }

    @Test
    public void testSaveEventAgencyAlignment_WithPubkey_GetsIdFromHibernate()
            throws Exception {
        String crop = "CORN";
        EventAgencyAlignment[] eventAgencies = eventAgencyAlignmentDao.findByEventAndCrop("zm_5678", crop);
        assertEquals(0, eventAgencies.length);
        /*Not using Builder because we dont want Id & pubkey set*/
        EventAgencyAlignment eventAgencyAlignment = new EventAgencyAlignment();
        eventAgencyAlignment.setEventAgencyAlignmentPubkey("1111");
        eventAgencyAlignment.setAgency(AgencyBuilder.epa());
        eventAgencyAlignment.setDeregulatedEffectiveDate(new Date());
        eventAgencyAlignment.setMaterialName("ZM_5678");
        eventAgencyAlignment.setMaxQuantity(100.6);
        eventAgencyAlignment.setRegulated(SQLUtil.booleanToString(true));
        eventAgencyAlignment.setCrop(CropBuilder.corn());
        eventAgencyAlignment.setAgencyMaterialType(AgencyMaterialTypeBuilder.trait());
        eventAgencyAlignment.setCreatedDate(new Date());
        eventAgencyAlignment.setModifiedDate(new Date());
        eventAgencyAlignment.setCreatedUserID("LEXICON_USER");
        eventAgencyAlignment.setModifiedUserId("LEXICON_USER");
        eventAgencyAlignmentDao.save(eventAgencyAlignment);
        //second save is to force production code to set uniqueId or else both records will try to have default Id (0) and will fail
        EventAgencyAlignment second = new EventAgencyAlignment();
        second.setEventAgencyAlignmentPubkey("2222");
        second.setAgency(AgencyBuilder.epa());
        second.setMaterialName("ZM_5679");
        second.setRegulated(SQLUtil.booleanToString(true));
        second.setCrop(CropBuilder.corn());
        second.setAgencyMaterialType(AgencyMaterialTypeBuilder.trait());
        second.setCreatedDate(new Date());
        second.setModifiedDate(new Date());
        second.setCreatedUserID("LEXICON_USER");
        second.setModifiedUserId("LEXICON_USER");
        eventAgencyAlignmentDao.save(second);
        EventAgencyAlignment[] eventAgencyAlignments = eventAgencyAlignmentDao.findByEventAndCrop("zm_5678", crop);
        assertEquals(1, eventAgencyAlignments.length);
        Assert.assertNotNull(eventAgencyAlignments[0].getEventAgencyAlignmentId());
        Assert.assertTrue(eventAgencyAlignments[0].getEventAgencyAlignmentId() != 0);
    }

    @Test
    public void testSaveEventAgencyAlignment_WithoutPubkey_GetsPubkeyFromSequence()
            throws Exception {
        String crop = "CORN";
        EventAgencyAlignment[] eventAgencies = eventAgencyAlignmentDao.findByEventAndCrop("zm_5678", crop);
        assertEquals(0, eventAgencies.length);
        /*Not using Builder because we dont want Id & pubkey set*/
        EventAgencyAlignment eventAgencyAlignment = new EventAgencyAlignment();
        eventAgencyAlignment.setAgency(AgencyBuilder.epa());
        eventAgencyAlignment.setDeregulatedEffectiveDate(new Date());
        eventAgencyAlignment.setMaterialName("ZM_5678");
        eventAgencyAlignment.setMaxQuantity(100.5);
        eventAgencyAlignment.setRegulated(SQLUtil.booleanToString(true));
        eventAgencyAlignment.setCrop(CropBuilder.corn());
        eventAgencyAlignment.setAgencyMaterialType(AgencyMaterialTypeBuilder.trait());
        eventAgencyAlignment.setCreatedDate(new Date());
        eventAgencyAlignment.setModifiedDate(new Date());
        eventAgencyAlignment.setCreatedUserID("LEXICON_USER");
        eventAgencyAlignment.setModifiedUserId("LEXICON_USER");
        eventAgencyAlignmentDao.save(eventAgencyAlignment);
        EventAgencyAlignment[] eventAgencyAlignments = eventAgencyAlignmentDao.findByEventAndCrop("zm_5678", crop);
        assertEquals(1, eventAgencyAlignments.length);
    }

    @Test
    public void testUpdateEventAgencyAlignment()
            throws Exception {
        Crop crop = CropBuilder.corn();
        EventAgencyAlignment eventAgencyAlignment = new EventAgencyAlignmentBuilder().
                withEvent("ZM_5678").
                withAgency(AgencyBuilder.epa()).
                regulated().
                withDeregulatedEffectiveDate(new Date()).
                withMaxQuantity(100).
                withCrop(crop).
                create();

        EventAgencyAlignment[] eventAgencies = eventAgencyAlignmentDao.findByEventAndCrop("zm_5678", crop.getCropName());
        assertEquals(1, eventAgencies.length);
        EventAgencyAlignment before = eventAgencies[0];
        assertEquals(eventAgencyAlignment.getRegulated(), before.getRegulated());
        eventAgencyAlignment.setRegulated(SQLUtil.booleanToString(false));
        eventAgencyAlignmentDao.update(eventAgencyAlignment);
        EventAgencyAlignment[] eventAgencyAlignments = eventAgencyAlignmentDao.findByEventAndCrop("zm_5678", crop.getCropName());
        assertEquals(1, eventAgencyAlignments.length);
        EventAgencyAlignment after = eventAgencyAlignments[0];
        assertFalse(SQLUtil.stringToBoolean(after.getRegulated()));
    }

    @Test
    public void testFindEventAgencyAlignmentByPubkey()
            throws Exception {
        EventAgencyAlignment expected = new EventAgencyAlignmentBuilder().
                withEvent("ZM_5678").
                withAgency(AgencyBuilder.epa()).
                regulated().
                withDeregulatedEffectiveDate(new Date()).
                withMaxQuantity(100).
                create();

        EventAgencyAlignment[] alignmentsReceived = eventAgencyAlignmentDao.findByPubkey(new String[]{expected.getEventAgencyAlignmentPubkey()});
        assertEquals(1, alignmentsReceived.length);
        EventAgencyAlignment received = alignmentsReceived[0];
        assertEquals(expected.getEventAgencyAlignmentPubkey(), received.getEventAgencyAlignmentPubkey());
        assertEquals(expected.getMaterialName(), received.getMaterialName());
        assertEquals(expected.getDeregulatedEffectiveDate(), received.getDeregulatedEffectiveDate());
        assertEquals(expected.getMaxQuantity(), received.getMaxQuantity());
        assertEquals(expected.getRegulated(), received.getRegulated());
    }

    @Test
    public void testFindMultipleEventAgencyAlignmentByPubkeys()
            throws Exception {
        EventAgencyAlignment expectedOne = new EventAgencyAlignmentBuilder().
                withEvent("ZM_5678").
                withAgency(AgencyBuilder.epa()).
                regulated().
                withDeregulatedEffectiveDate(new Date()).
                withMaxQuantity(100).
                create();

        EventAgencyAlignment expectedTwo = new EventAgencyAlignmentBuilder().
                withEvent("ZM_5678").
                withAgency(AgencyBuilder.usda()).
                regulated().
                withDeregulatedEffectiveDate(new Date()).
                withMaxQuantity(100).
                create();

        EventAgencyAlignment[] alignmentsReceived =
                eventAgencyAlignmentDao.findByPubkey
                        (new String[]{expectedOne.getEventAgencyAlignmentPubkey(), expectedTwo.getEventAgencyAlignmentPubkey()});
        assertEquals(2, alignmentsReceived.length);
        EventAgencyAlignment receivedOne = alignmentsReceived[0];
        assertEquals(expectedOne.getEventAgencyAlignmentPubkey(), receivedOne.getEventAgencyAlignmentPubkey());
        assertEquals(expectedOne.getMaterialName(), receivedOne.getMaterialName());
        assertEquals(expectedOne.getDeregulatedEffectiveDate(), receivedOne.getDeregulatedEffectiveDate());
        assertEquals(expectedOne.getMaxQuantity(), receivedOne.getMaxQuantity());
        assertEquals(expectedOne.getRegulated(), receivedOne.getRegulated());
        EventAgencyAlignment receivedTwo = alignmentsReceived[1];
        assertEquals(expectedTwo.getEventAgencyAlignmentPubkey(), receivedTwo.getEventAgencyAlignmentPubkey());
        assertEquals(expectedTwo.getMaterialName(), receivedTwo.getMaterialName());
        assertEquals(expectedTwo.getDeregulatedEffectiveDate(), receivedTwo.getDeregulatedEffectiveDate());
        assertEquals(expectedTwo.getMaxQuantity(), receivedTwo.getMaxQuantity());
        assertEquals(expectedTwo.getRegulated(), receivedTwo.getRegulated());
    }

    @Test
    public void testFindEventAgencyAlignmentByPubkeyReturnsNullForNonExistingPubkey()
            throws Exception {
        EventAgencyAlignment[] received = eventAgencyAlignmentDao.findByPubkey(new String[]{"NONEXISTING"});
        assertEquals(0, received.length);
    }

    @Test
    public void testFindEventAgencyAlignmentByAgencyAbbr()
            throws Exception {
        Agency agency = AgencyBuilder.epa();
        EventAgencyAlignment expected = new EventAgencyAlignmentBuilder().
                withEvent("ZM_5678").
                withAgency(agency).
                regulated().
                withDeregulatedEffectiveDate(new Date()).
                withCrop(CropBuilder.corn()).
                withMaxQuantity(100).
                create();

        EventAgencyAlignment[] alignmentsReceived = eventAgencyAlignmentDao.findByAgencyAbbr(new String[]{agency.getAgencyAbbr()});
        EventAgencyAlignment received = findAgencyWithEventAndCrop(alignmentsReceived, expected.getMaterialName(), expected.getCrop().getCropName());
        assertNotNull(received);
        assertEquals(expected.getEventAgencyAlignmentPubkey(), received.getEventAgencyAlignmentPubkey());
        assertEquals(expected.getMaterialName(), received.getMaterialName());
        assertEquals(expected.getDeregulatedEffectiveDate(), received.getDeregulatedEffectiveDate());
        assertEquals(expected.getMaxQuantity(), received.getMaxQuantity());
        assertEquals(expected.getRegulated(), received.getRegulated());
        assertEquals(expected.getAgency().getAgencyAbbr(), received.getAgency().getAgencyAbbr());
        assertEquals(expected.getCrop().getCropName(), received.getCrop().getCropName());
    }

    @Test
    public void testFindEventAgencyAlignmentByAgencyAbbr_IsCaseInsensitive()
            throws Exception {
        Agency agency = new AgencyBuilder()
                .withAgencyAbbr("testAGENCY")
                .create();
        EventAgencyAlignment expected = new EventAgencyAlignmentBuilder().
                withEvent("ZM_5678").
                withAgency(agency).
                regulated().
                withDeregulatedEffectiveDate(new Date()).
                withCrop(CropBuilder.corn()).
                withMaxQuantity(100).
                create();

        EventAgencyAlignment[] alignmentsReceived = eventAgencyAlignmentDao.findByAgencyAbbr(new String[]{"TESTagency"});
        EventAgencyAlignment received = findAgencyWithEventAndCrop(alignmentsReceived, expected.getMaterialName(), expected.getCrop().getCropName());
        assertNotNull(received);
        assertEquals(expected.getEventAgencyAlignmentPubkey(), received.getEventAgencyAlignmentPubkey());
        assertEquals(expected.getMaterialName(), received.getMaterialName());
        assertEquals(expected.getDeregulatedEffectiveDate(), received.getDeregulatedEffectiveDate());
        assertEquals(expected.getMaxQuantity(), received.getMaxQuantity());
        assertEquals(expected.getRegulated(), received.getRegulated());
        assertEquals(expected.getAgency().getAgencyAbbr(), received.getAgency().getAgencyAbbr());
        assertEquals(expected.getCrop().getCropName(), received.getCrop().getCropName());
    }

    @Test
    public void testFindEventAgencyAlignmentByNonExistentAgencyAbbr_ReturnsEmpty()
            throws Exception {
        EventAgencyAlignment[] alignmentsReceived = eventAgencyAlignmentDao.findByAgencyAbbr(new String[]{"NON EXISTENT"});
        assertEquals(0, alignmentsReceived.length);
    }

    @Test
    public void testFindEventAgencyAlignmentByCaseInsensitiveAgencyAbbr_ReturnsAlignments()
            throws Exception {
        Agency agency = AgencyBuilder.stewardship();
        EventAgencyAlignment expected = new EventAgencyAlignmentBuilder().
                withEvent("ZM_5678").
                withAgency(agency).
                regulated().
                withDeregulatedEffectiveDate(new Date()).
                withCrop(CropBuilder.corn()).
                withMaxQuantity(100).
                create();

        EventAgencyAlignment[] alignmentsReceived = eventAgencyAlignmentDao.findByAgencyAbbr(new String[]{"STWRDSH"});
        EventAgencyAlignment received = findAgencyWithEventAndCrop(alignmentsReceived, expected.getMaterialName(), expected.getCrop().getCropName());
        assertNotNull(received);
        assertEquals(expected.getEventAgencyAlignmentPubkey(), received.getEventAgencyAlignmentPubkey());
        assertEquals(expected.getMaterialName(), received.getMaterialName());
        assertEquals(expected.getDeregulatedEffectiveDate(), received.getDeregulatedEffectiveDate());
        assertEquals(expected.getMaxQuantity(), received.getMaxQuantity());
        assertEquals(expected.getRegulated(), received.getRegulated());
        assertEquals(expected.getAgency().getAgencyAbbr(), received.getAgency().getAgencyAbbr());
        assertEquals(expected.getCrop().getCropName(), received.getCrop().getCropName());
    }

    @Test
    public void testFindByEventsCropAndAgencyAbbr_InvalidSearchCriteria_DoesNotReturnEventAgencyAlignment()
            throws Exception {
        Agency agency = AgencyBuilder.epa();
        Crop crop = CropBuilder.corn();
        String event = "ZM_5678";
        EventAgencyAlignment expected = new EventAgencyAlignmentBuilder().
                withEvent(event).
                withAgency(agency).
                deregulated().
                withDeregulatedEffectiveDate(new Date()).
                withMaxQuantity(100).
                withCrop(crop).
                create();

        EventAgencyAlignment[] response = eventAgencyAlignmentDao.findByEventsCropAndAgencyAbbrs(
                new String[]{"NON_EXISTENT"},
                crop.getCropName(),
                new String[]{agency.getAgencyAbbr()});
        assertTrue(ArrayUtils.isEmpty(response));
    }

    @Test
    public void testFindByEventsCropAndAgencyAbbr_ReturnsEventAgencyAlignment()
            throws Exception {
        Agency agency = AgencyBuilder.epa();
        Crop crop = CropBuilder.corn();
        String event = "ZM_5678";
        EventAgencyAlignment expected = new EventAgencyAlignmentBuilder().
                withEvent(event).
                withAgency(agency).
                deregulated().
                withDeregulatedEffectiveDate(new Date()).
                withMaxQuantity(100).
                withCrop(crop).
                create();

        EventAgencyAlignment[] response = eventAgencyAlignmentDao.findByEventsCropAndAgencyAbbrs(
                new String[]{event},
                crop.getCropName(),
                new String[]{agency.getAgencyAbbr()});
        assertFalse(ArrayUtils.isEmpty(response));
        EventAgencyAlignment eventAgencyAlignment = response[0];
        assertNotNull(eventAgencyAlignment);
        assertEquals(expected.getAgency().getAgencyPubkey(), eventAgencyAlignment.getAgency().getAgencyPubkey());
        assertEquals(expected.getDeregulatedEffectiveDate(), eventAgencyAlignment.getDeregulatedEffectiveDate());
        assertEquals(expected.getMaterialName(), eventAgencyAlignment.getMaterialName());
        assertEquals(expected.getEventAgencyAlignmentId(), eventAgencyAlignment.getEventAgencyAlignmentId());
        assertEquals(expected.getEventAgencyAlignmentPubkey(), eventAgencyAlignment.getEventAgencyAlignmentPubkey());
        assertEquals(expected.getMaxQuantity(), eventAgencyAlignment.getMaxQuantity());
        assertEquals(expected.getRegulated(), eventAgencyAlignment.getRegulated());
        assertEquals(expected.getCrop().getCropName(), eventAgencyAlignment.getCrop().getCropName());
    }

    @Test
    public void testFindByEventsCropAndAgencyAbbr_OneEventAssociatedWithMultipleAgenciesReturnsMultipleEventAgencyAlignments()
            throws Exception {
        Agency epa = AgencyBuilder.epa();
        Agency usda = AgencyBuilder.usda();
        Crop crop = CropBuilder.corn();
        String event = "ZM_5678";
        EventAgencyAlignment epaEvent = new EventAgencyAlignmentBuilder().
                withEvent(event).
                withAgency(epa).
                deregulated().
                withDeregulatedEffectiveDate(new Date()).
                withMaxQuantity(100).
                withCrop(crop).
                create();

        EventAgencyAlignment usdaEvent = new EventAgencyAlignmentBuilder().
                withEvent(event).
                withAgency(usda).
                deregulated().
                withDeregulatedEffectiveDate(new Date()).
                withMaxQuantity(100).
                withCrop(crop).
                create();

        EventAgencyAlignment[] response = eventAgencyAlignmentDao.findByEventsCropAndAgencyAbbrs(
                new String[]{event},
                crop.getCropName(),
                new String[]{epa.getAgencyAbbr(), usda.getAgencyAbbr()});
        assertFalse(ArrayUtils.isEmpty(response));
        EventAgencyAlignment epaAgencyAlignment = response[0];
        assertNotNull(epaAgencyAlignment);
        assertEquals(epaEvent.getAgency().getAgencyPubkey(), epaAgencyAlignment.getAgency().getAgencyPubkey());
        assertEquals(epaEvent.getDeregulatedEffectiveDate(), epaAgencyAlignment.getDeregulatedEffectiveDate());
        assertEquals(epaEvent.getMaterialName(), epaAgencyAlignment.getMaterialName());
        assertEquals(epaEvent.getEventAgencyAlignmentId(), epaAgencyAlignment.getEventAgencyAlignmentId());
        assertEquals(epaEvent.getEventAgencyAlignmentPubkey(), epaAgencyAlignment.getEventAgencyAlignmentPubkey());
        assertEquals(epaEvent.getMaxQuantity(), epaAgencyAlignment.getMaxQuantity());
        assertEquals(epaEvent.getRegulated(), epaAgencyAlignment.getRegulated());
        assertEquals(epaEvent.getCrop().getCropName(), epaAgencyAlignment.getCrop().getCropName());

        EventAgencyAlignment usdaAgencyAlignment = response[1];
        assertNotNull(usdaAgencyAlignment);
        assertEquals(usdaEvent.getAgency().getAgencyPubkey(), usdaAgencyAlignment.getAgency().getAgencyPubkey());
        assertEquals(usdaEvent.getDeregulatedEffectiveDate(), usdaAgencyAlignment.getDeregulatedEffectiveDate());
        assertEquals(usdaEvent.getMaterialName(), usdaAgencyAlignment.getMaterialName());
        assertEquals(usdaEvent.getEventAgencyAlignmentId(), usdaAgencyAlignment.getEventAgencyAlignmentId());
        assertEquals(usdaEvent.getEventAgencyAlignmentPubkey(), usdaAgencyAlignment.getEventAgencyAlignmentPubkey());
        assertEquals(usdaEvent.getMaxQuantity(), usdaAgencyAlignment.getMaxQuantity());
        assertEquals(usdaEvent.getRegulated(), usdaAgencyAlignment.getRegulated());
        assertEquals(usdaEvent.getCrop().getCropName(), usdaAgencyAlignment.getCrop().getCropName());
    }

    @Test
    public void testFindByEventsCropAndAgencyAbbr_MultipleEventsAssociatedWithOneAgencyReturnsMultipleEventAgencyAlignments()
            throws Exception {
        Agency epa = AgencyBuilder.epa();
        Crop crop = CropBuilder.corn();
        String eventOne = "ZM_5678";
        EventAgencyAlignment firstEvent = new EventAgencyAlignmentBuilder().
                withEvent(eventOne).
                withAgency(epa).
                deregulated().
                withDeregulatedEffectiveDate(new Date()).
                withMaxQuantity(100).
                withCrop(crop).
                create();

        String eventTwo = "ZM_4456";
        EventAgencyAlignment secondEvent = new EventAgencyAlignmentBuilder().
                withEvent(eventTwo).
                withAgency(epa).
                deregulated().
                withDeregulatedEffectiveDate(new Date()).
                withMaxQuantity(100).
                withCrop(crop).
                create();

        EventAgencyAlignment[] response = eventAgencyAlignmentDao.findByEventsCropAndAgencyAbbrs(
                new String[]{eventOne, eventTwo},
                crop.getCropName(),
                new String[]{epa.getAgencyAbbr()});
        assertFalse(ArrayUtils.isEmpty(response));
        assertEquals(2, response.length);
        EventAgencyAlignment firstAgencyAlignment = findAlignment(response, eventOne, epa.getAgencyAbbr());
        assertNotNull(firstAgencyAlignment);
        assertEquals(firstEvent.getAgency().getAgencyPubkey(), firstAgencyAlignment.getAgency().getAgencyPubkey());
        assertEquals(firstEvent.getDeregulatedEffectiveDate(), firstAgencyAlignment.getDeregulatedEffectiveDate());
        assertEquals(firstEvent.getMaterialName(), firstAgencyAlignment.getMaterialName());
        assertEquals(firstEvent.getEventAgencyAlignmentId(), firstAgencyAlignment.getEventAgencyAlignmentId());
        assertEquals(firstEvent.getEventAgencyAlignmentPubkey(), firstAgencyAlignment.getEventAgencyAlignmentPubkey());
        assertEquals(firstEvent.getMaxQuantity(), firstAgencyAlignment.getMaxQuantity());
        assertEquals(firstEvent.getRegulated(), firstAgencyAlignment.getRegulated());
        assertEquals(firstEvent.getCrop().getCropName(), firstAgencyAlignment.getCrop().getCropName());

        EventAgencyAlignment secondAgencyAlignment = findAlignment(response, eventTwo, epa.getAgencyAbbr());
        assertNotNull(secondAgencyAlignment);
        assertEquals(secondEvent.getAgency().getAgencyPubkey(), secondAgencyAlignment.getAgency().getAgencyPubkey());
        assertEquals(secondEvent.getDeregulatedEffectiveDate(), secondAgencyAlignment.getDeregulatedEffectiveDate());
        assertEquals(secondEvent.getMaterialName(), secondAgencyAlignment.getMaterialName());
        assertEquals(secondEvent.getEventAgencyAlignmentId(), secondAgencyAlignment.getEventAgencyAlignmentId());
        assertEquals(secondEvent.getEventAgencyAlignmentPubkey(), secondAgencyAlignment.getEventAgencyAlignmentPubkey());
        assertEquals(secondEvent.getMaxQuantity(), secondAgencyAlignment.getMaxQuantity());
        assertEquals(secondEvent.getRegulated(), secondAgencyAlignment.getRegulated());
        assertEquals(secondEvent.getCrop().getCropName(), secondAgencyAlignment.getCrop().getCropName());
    }

    @Test
    public void testFindByEventsCropAndAgencyAbbr_MultipleEventsAssociatedWithMultipleAgenciesReturnsMultipleEventAgencyAlignments()
            throws Exception {
        Agency epa = AgencyBuilder.epa();
        Agency usda = AgencyBuilder.usda();
        Crop crop = CropBuilder.corn();
        String eventOne = "ZM_5678";
        EventAgencyAlignment firstEventWithEpa = new EventAgencyAlignmentBuilder().
                withEvent(eventOne).
                withAgency(epa).
                deregulated().
                withDeregulatedEffectiveDate(new Date()).
                withMaxQuantity(100).
                withCrop(crop).
                create();

        EventAgencyAlignment firstEventWithUsda = new EventAgencyAlignmentBuilder().
                withEvent(eventOne).
                withAgency(usda).
                deregulated().
                withDeregulatedEffectiveDate(new Date()).
                withMaxQuantity(100).
                withCrop(crop).
                create();

        String eventTwo = "ZM_4456";
        EventAgencyAlignment secondEventWithEpa = new EventAgencyAlignmentBuilder().
                withEvent(eventTwo).
                withAgency(epa).
                deregulated().
                withDeregulatedEffectiveDate(new Date()).
                withMaxQuantity(100).
                withCrop(crop).
                create();

        EventAgencyAlignment secondEventWithUsda = new EventAgencyAlignmentBuilder().
                withEvent(eventTwo).
                withAgency(usda).
                deregulated().
                withDeregulatedEffectiveDate(new Date()).
                withMaxQuantity(100).
                withCrop(crop).
                create();

        EventAgencyAlignment[] response = eventAgencyAlignmentDao.findByEventsCropAndAgencyAbbrs(
                new String[]{eventOne, eventTwo},
                crop.getCropName(),
                new String[]{epa.getAgencyAbbr(), usda.getAgencyAbbr()});
        assertFalse(ArrayUtils.isEmpty(response));
        assertEquals(4, response.length);
        EventAgencyAlignment firstAgencyAlignment = findAlignment(response, eventOne, epa.getAgencyAbbr());
        assertNotNull(firstAgencyAlignment);
        assertEquals(firstEventWithEpa.getAgency().getAgencyPubkey(), firstAgencyAlignment.getAgency().getAgencyPubkey());
        assertEquals(firstEventWithEpa.getDeregulatedEffectiveDate(), firstAgencyAlignment.getDeregulatedEffectiveDate());
        assertEquals(firstEventWithEpa.getMaterialName(), firstAgencyAlignment.getMaterialName());
        assertEquals(firstEventWithEpa.getEventAgencyAlignmentId(), firstAgencyAlignment.getEventAgencyAlignmentId());
        assertEquals(firstEventWithEpa.getEventAgencyAlignmentPubkey(), firstAgencyAlignment.getEventAgencyAlignmentPubkey());
        assertEquals(firstEventWithEpa.getMaxQuantity(), firstAgencyAlignment.getMaxQuantity());
        assertEquals(firstEventWithEpa.getRegulated(), firstAgencyAlignment.getRegulated());
        assertEquals(firstEventWithEpa.getCrop().getCropName(), firstAgencyAlignment.getCrop().getCropName());

        EventAgencyAlignment secondAgencyAlignment = findAlignment(response, eventOne, usda.getAgencyAbbr());
        assertNotNull(secondAgencyAlignment);
        assertEquals(firstEventWithUsda.getAgency().getAgencyPubkey(), secondAgencyAlignment.getAgency().getAgencyPubkey());
        assertEquals(firstEventWithUsda.getDeregulatedEffectiveDate(), secondAgencyAlignment.getDeregulatedEffectiveDate());
        assertEquals(firstEventWithUsda.getMaterialName(), secondAgencyAlignment.getMaterialName());
        assertEquals(firstEventWithUsda.getEventAgencyAlignmentId(), secondAgencyAlignment.getEventAgencyAlignmentId());
        assertEquals(firstEventWithUsda.getEventAgencyAlignmentPubkey(), secondAgencyAlignment.getEventAgencyAlignmentPubkey());
        assertEquals(firstEventWithUsda.getMaxQuantity(), secondAgencyAlignment.getMaxQuantity());
        assertEquals(firstEventWithUsda.getRegulated(), secondAgencyAlignment.getRegulated());
        assertEquals(firstEventWithUsda.getCrop().getCropName(), secondAgencyAlignment.getCrop().getCropName());

        EventAgencyAlignment thirdAgencyAlignment = findAlignment(response, eventTwo, epa.getAgencyAbbr());
        assertNotNull(thirdAgencyAlignment);
        assertEquals(secondEventWithEpa.getAgency().getAgencyPubkey(), thirdAgencyAlignment.getAgency().getAgencyPubkey());
        assertEquals(secondEventWithEpa.getDeregulatedEffectiveDate(), thirdAgencyAlignment.getDeregulatedEffectiveDate());
        assertEquals(secondEventWithEpa.getMaterialName(), thirdAgencyAlignment.getMaterialName());
        assertEquals(secondEventWithEpa.getEventAgencyAlignmentId(), thirdAgencyAlignment.getEventAgencyAlignmentId());
        assertEquals(secondEventWithEpa.getEventAgencyAlignmentPubkey(), thirdAgencyAlignment.getEventAgencyAlignmentPubkey());
        assertEquals(secondEventWithEpa.getMaxQuantity(), thirdAgencyAlignment.getMaxQuantity());
        assertEquals(secondEventWithEpa.getRegulated(), thirdAgencyAlignment.getRegulated());
        assertEquals(secondEventWithEpa.getCrop().getCropName(), thirdAgencyAlignment.getCrop().getCropName());

        EventAgencyAlignment fourthAgencyAlignment = findAlignment(response, eventTwo, usda.getAgencyAbbr());
        assertNotNull(fourthAgencyAlignment);
        assertEquals(secondEventWithUsda.getAgency().getAgencyPubkey(), fourthAgencyAlignment.getAgency().getAgencyPubkey());
        assertEquals(secondEventWithUsda.getDeregulatedEffectiveDate(), fourthAgencyAlignment.getDeregulatedEffectiveDate());
        assertEquals(secondEventWithUsda.getMaterialName(), fourthAgencyAlignment.getMaterialName());
        assertEquals(secondEventWithUsda.getEventAgencyAlignmentId(), fourthAgencyAlignment.getEventAgencyAlignmentId());
        assertEquals(secondEventWithUsda.getEventAgencyAlignmentPubkey(), fourthAgencyAlignment.getEventAgencyAlignmentPubkey());
        assertEquals(secondEventWithUsda.getMaxQuantity(), fourthAgencyAlignment.getMaxQuantity());
        assertEquals(secondEventWithUsda.getRegulated(), fourthAgencyAlignment.getRegulated());
        assertEquals(secondEventWithUsda.getCrop().getCropName(), fourthAgencyAlignment.getCrop().getCropName());
    }

    @Test
    public void testFindByEventsCrop_MultipleEventsAssociatedWithMultipleAgenciesReturnsMultipleEventAgencyAlignments()
            throws Exception {
        Agency epa = AgencyBuilder.epa();
        Agency usda = AgencyBuilder.usda();
        Crop crop = CropBuilder.corn();
        String eventOne = "ZM_5678";
        EventAgencyAlignment firstEventWithEpa = new EventAgencyAlignmentBuilder().
                withEvent(eventOne).
                withAgency(epa).
                deregulated().
                withDeregulatedEffectiveDate(new Date()).
                withMaxQuantity(100).
                withCrop(crop).
                create();

        EventAgencyAlignment firstEventWithUsda = new EventAgencyAlignmentBuilder().
                withEvent(eventOne).
                withAgency(usda).
                deregulated().
                withDeregulatedEffectiveDate(new Date()).
                withMaxQuantity(100).
                withCrop(crop).
                create();

        String eventTwo = "ZM_4456";
        EventAgencyAlignment secondEventWithEpa = new EventAgencyAlignmentBuilder().
                withEvent(eventTwo).
                withAgency(epa).
                deregulated().
                withDeregulatedEffectiveDate(new Date()).
                withMaxQuantity(100).
                withCrop(crop).
                create();

        EventAgencyAlignment secondEventWithUsda = new EventAgencyAlignmentBuilder().
                withEvent(eventTwo).
                withAgency(usda).
                deregulated().
                withDeregulatedEffectiveDate(new Date()).
                withMaxQuantity(100).
                withCrop(crop).
                create();

        EventAgencyAlignment[] response = eventAgencyAlignmentDao.findByEventsCrop(
                new String[]{eventOne, eventTwo},
                crop.getCropName());
        assertFalse(ArrayUtils.isEmpty(response));
        assertEquals(4, response.length);
        EventAgencyAlignment firstAgencyAlignment = findAlignment(response, eventOne, epa.getAgencyAbbr());
        assertNotNull(firstAgencyAlignment);
        assertEquals(firstEventWithEpa.getAgency().getAgencyPubkey(), firstAgencyAlignment.getAgency().getAgencyPubkey());
        assertEquals(firstEventWithEpa.getDeregulatedEffectiveDate(), firstAgencyAlignment.getDeregulatedEffectiveDate());
        assertEquals(firstEventWithEpa.getMaterialName(), firstAgencyAlignment.getMaterialName());
        assertEquals(firstEventWithEpa.getEventAgencyAlignmentId(), firstAgencyAlignment.getEventAgencyAlignmentId());
        assertEquals(firstEventWithEpa.getEventAgencyAlignmentPubkey(), firstAgencyAlignment.getEventAgencyAlignmentPubkey());
        assertEquals(firstEventWithEpa.getMaxQuantity(), firstAgencyAlignment.getMaxQuantity());
        assertEquals(firstEventWithEpa.getRegulated(), firstAgencyAlignment.getRegulated());
        assertEquals(firstEventWithEpa.getCrop().getCropName(), firstAgencyAlignment.getCrop().getCropName());

        EventAgencyAlignment secondAgencyAlignment = findAlignment(response, eventOne, usda.getAgencyAbbr());
        assertNotNull(secondAgencyAlignment);
        assertEquals(firstEventWithUsda.getAgency().getAgencyPubkey(), secondAgencyAlignment.getAgency().getAgencyPubkey());
        assertEquals(firstEventWithUsda.getDeregulatedEffectiveDate(), secondAgencyAlignment.getDeregulatedEffectiveDate());
        assertEquals(firstEventWithUsda.getMaterialName(), secondAgencyAlignment.getMaterialName());
        assertEquals(firstEventWithUsda.getEventAgencyAlignmentId(), secondAgencyAlignment.getEventAgencyAlignmentId());
        assertEquals(firstEventWithUsda.getEventAgencyAlignmentPubkey(), secondAgencyAlignment.getEventAgencyAlignmentPubkey());
        assertEquals(firstEventWithUsda.getMaxQuantity(), secondAgencyAlignment.getMaxQuantity());
        assertEquals(firstEventWithUsda.getRegulated(), secondAgencyAlignment.getRegulated());
        assertEquals(firstEventWithUsda.getCrop().getCropName(), secondAgencyAlignment.getCrop().getCropName());

        EventAgencyAlignment thirdAgencyAlignment = findAlignment(response, eventTwo, epa.getAgencyAbbr());
        assertNotNull(thirdAgencyAlignment);
        assertEquals(secondEventWithEpa.getAgency().getAgencyPubkey(), thirdAgencyAlignment.getAgency().getAgencyPubkey());
        assertEquals(secondEventWithEpa.getDeregulatedEffectiveDate(), thirdAgencyAlignment.getDeregulatedEffectiveDate());
        assertEquals(secondEventWithEpa.getMaterialName(), thirdAgencyAlignment.getMaterialName());
        assertEquals(secondEventWithEpa.getEventAgencyAlignmentId(), thirdAgencyAlignment.getEventAgencyAlignmentId());
        assertEquals(secondEventWithEpa.getEventAgencyAlignmentPubkey(), thirdAgencyAlignment.getEventAgencyAlignmentPubkey());
        assertEquals(secondEventWithEpa.getMaxQuantity(), thirdAgencyAlignment.getMaxQuantity());
        assertEquals(secondEventWithEpa.getRegulated(), thirdAgencyAlignment.getRegulated());
        assertEquals(secondEventWithEpa.getCrop().getCropName(), thirdAgencyAlignment.getCrop().getCropName());

        EventAgencyAlignment fourthAgencyAlignment = findAlignment(response, eventTwo, usda.getAgencyAbbr());
        assertNotNull(fourthAgencyAlignment);
        assertEquals(secondEventWithUsda.getAgency().getAgencyPubkey(), fourthAgencyAlignment.getAgency().getAgencyPubkey());
        assertEquals(secondEventWithUsda.getDeregulatedEffectiveDate(), fourthAgencyAlignment.getDeregulatedEffectiveDate());
        assertEquals(secondEventWithUsda.getMaterialName(), fourthAgencyAlignment.getMaterialName());
        assertEquals(secondEventWithUsda.getEventAgencyAlignmentId(), fourthAgencyAlignment.getEventAgencyAlignmentId());
        assertEquals(secondEventWithUsda.getEventAgencyAlignmentPubkey(), fourthAgencyAlignment.getEventAgencyAlignmentPubkey());
        assertEquals(secondEventWithUsda.getMaxQuantity(), fourthAgencyAlignment.getMaxQuantity());
        assertEquals(secondEventWithUsda.getRegulated(), fourthAgencyAlignment.getRegulated());
        assertEquals(secondEventWithUsda.getCrop().getCropName(), fourthAgencyAlignment.getCrop().getCropName());
    }


    @Test
    public void testFindByMaterialsCropReturnsEventAgencyAlignmentsWithEventName()
            throws Exception {
        Agency epa = AgencyBuilder.epa();
        Crop crop = CropBuilder.corn();
        AgencyMaterialType agencyMaterialType = AgencyMaterialTypeBuilder.trait();
        String eventOne = "ZM_5678";

        EventAgencyAlignment firstEventWithEpa = new EventAgencyAlignmentBuilder().
                withEvent(eventOne).
                withAgency(epa).
                deregulated().
                withDeregulatedEffectiveDate(new Date()).
                withMaxQuantity(100).
                withCrop(crop).
                withAgencyMaterialType(agencyMaterialType).
                withCreatedDate().
                withCreatedUserId().
                withModifiedDate().
                withModifiedUserId().
                create();

        EventAgencyAlignment[] response = eventAgencyAlignmentDao.findByMaterialCrop(
                new String[]{eventOne},
                crop.getCropName());
        assertFalse(ArrayUtils.isEmpty(response));
        assertEquals(1, response.length);
        EventAgencyAlignment firstAgencyAlignment = response[0];
        assertNotNull(firstAgencyAlignment);
        assertEquals(firstEventWithEpa.getAgency().getAgencyPubkey(), firstAgencyAlignment.getAgency().getAgencyPubkey());
        assertEquals(firstEventWithEpa.getDeregulatedEffectiveDate(), firstAgencyAlignment.getDeregulatedEffectiveDate());
        assertEquals(firstEventWithEpa.getMaterialName(), firstAgencyAlignment.getMaterialName());
        assertEquals(firstEventWithEpa.getEventAgencyAlignmentId(), firstAgencyAlignment.getEventAgencyAlignmentId());
        assertEquals(firstEventWithEpa.getEventAgencyAlignmentPubkey(), firstAgencyAlignment.getEventAgencyAlignmentPubkey());
        assertEquals(firstEventWithEpa.getMaxQuantity(), firstAgencyAlignment.getMaxQuantity());
        assertEquals(firstEventWithEpa.getRegulated(), firstAgencyAlignment.getRegulated());
        assertEquals(firstEventWithEpa.getCrop().getCropName(), firstAgencyAlignment.getCrop().getCropName());
        assertEquals(firstEventWithEpa.getAgencyMaterialType().getMaterialTypeDesc(), firstAgencyAlignment.getAgencyMaterialType().getMaterialTypeDesc());

    }

    @Test
    public void testFindByMaterialsCropReturnsEventAgencyAlignmentsWithChemicalName()
            throws Exception {
        Agency epa = AgencyBuilder.epa();
        Crop crop = CropBuilder.corn();
        AgencyMaterialType agencyMaterialType = AgencyMaterialTypeBuilder.chemical();
        MaterialChemicalName materialChemicalName = ChemicalNameBuilder.findMaterialName();
        String eventOne = materialChemicalName.getChemicalName();

        EventAgencyAlignment firstEventWithEpa = new EventAgencyAlignmentBuilder().
                withEvent("chem1").
                withAgency(epa).
                deregulated().
                withDeregulatedEffectiveDate(new Date()).
                withMaxQuantity(100).
                withCrop(crop).
                withAgencyMaterialType(agencyMaterialType).
                withChemicalName(materialChemicalName).
                withCreatedDate().
                withCreatedUserId().
                withModifiedDate().
                withModifiedUserId().
                create();

        assertNotNull(firstEventWithEpa);

        EventAgencyAlignment[] response = eventAgencyAlignmentDao.findByMaterialCrop(
                new String[]{eventOne},
                crop.getCropName());
        assertFalse(ArrayUtils.isEmpty(response));
        assertEquals(1, response.length);
        EventAgencyAlignment firstAgencyAlignment = response[0];
        ;
        assertNotNull(firstAgencyAlignment);
        assertEquals(firstEventWithEpa.getAgency().getAgencyPubkey(), firstAgencyAlignment.getAgency().getAgencyPubkey());
        assertEquals(firstEventWithEpa.getDeregulatedEffectiveDate(), firstAgencyAlignment.getDeregulatedEffectiveDate());
        assertEquals(firstEventWithEpa.getMaterialName(), firstAgencyAlignment.getMaterialName());
        assertEquals(firstEventWithEpa.getEventAgencyAlignmentId(), firstAgencyAlignment.getEventAgencyAlignmentId());
        assertEquals(firstEventWithEpa.getEventAgencyAlignmentPubkey(), firstAgencyAlignment.getEventAgencyAlignmentPubkey());
        assertEquals(firstEventWithEpa.getMaxQuantity(), firstAgencyAlignment.getMaxQuantity());
        assertEquals(firstEventWithEpa.getRegulated(), firstAgencyAlignment.getRegulated());
        assertEquals(firstEventWithEpa.getCrop().getCropName(), firstAgencyAlignment.getCrop().getCropName());
        assertEquals(firstEventWithEpa.getAgencyMaterialType().getMaterialTypeDesc(), firstAgencyAlignment.getAgencyMaterialType().getMaterialTypeDesc());


    }

    @Test
    public void testFindByMaterialsCropReturnsEventAgencyAlignmentsWithMultipleEventNames()
            throws Exception {
        Agency epa = AgencyBuilder.epa();
        Crop crop = CropBuilder.corn();
        AgencyMaterialType agencyMaterialType = AgencyMaterialTypeBuilder.trait();
        String eventOne = "ZM_5678";

        EventAgencyAlignment firstEventWithEpa = new EventAgencyAlignmentBuilder().
                withEvent(eventOne).
                withAgency(epa).
                deregulated().
                withDeregulatedEffectiveDate(new Date()).
                withMaxQuantity(100).
                withCrop(crop).
                withAgencyMaterialType(agencyMaterialType).
                withCreatedDate().
                withCreatedUserId().
                withModifiedDate().
                withModifiedUserId().
                create();


        String eventTwo = "ZM_4456";
        EventAgencyAlignment secondEventWithEpa = new EventAgencyAlignmentBuilder().
                withEvent(eventTwo).
                withAgency(epa).
                deregulated().
                withDeregulatedEffectiveDate(new Date()).
                withMaxQuantity(50).
                withCrop(crop).
                withAgencyMaterialType(agencyMaterialType).
                withCreatedDate().
                withCreatedUserId().
                withModifiedDate().
                withModifiedUserId().
                create();


        EventAgencyAlignment[] response = eventAgencyAlignmentDao.findByMaterialCrop(
                new String[]{eventOne, eventTwo},
                crop.getCropName());
        assertFalse(ArrayUtils.isEmpty(response));
        assertEquals(2, response.length);
        EventAgencyAlignment firstAgencyAlignment = response[0];
        assertNotNull(firstAgencyAlignment);
        assertEquals(firstEventWithEpa.getAgency().getAgencyPubkey(), firstAgencyAlignment.getAgency().getAgencyPubkey());
        assertEquals(firstEventWithEpa.getDeregulatedEffectiveDate(), firstAgencyAlignment.getDeregulatedEffectiveDate());
        assertEquals(firstEventWithEpa.getMaterialName(), firstAgencyAlignment.getMaterialName());
        assertEquals(firstEventWithEpa.getEventAgencyAlignmentId(), firstAgencyAlignment.getEventAgencyAlignmentId());
        assertEquals(firstEventWithEpa.getEventAgencyAlignmentPubkey(), firstAgencyAlignment.getEventAgencyAlignmentPubkey());
        assertEquals(firstEventWithEpa.getMaxQuantity(), firstAgencyAlignment.getMaxQuantity());
        assertEquals(firstEventWithEpa.getRegulated(), firstAgencyAlignment.getRegulated());
        assertEquals(firstEventWithEpa.getCrop().getCropName(), firstAgencyAlignment.getCrop().getCropName());
        assertEquals(firstEventWithEpa.getAgencyMaterialType().getMaterialTypeDesc(), firstAgencyAlignment.getAgencyMaterialType().getMaterialTypeDesc());

        EventAgencyAlignment secondAgencyAlignment = response[1];
        assertNotNull(firstAgencyAlignment);
        assertEquals(secondEventWithEpa.getAgency().getAgencyPubkey(), secondAgencyAlignment.getAgency().getAgencyPubkey());
        assertEquals(secondEventWithEpa.getDeregulatedEffectiveDate(), secondAgencyAlignment.getDeregulatedEffectiveDate());
        assertEquals(secondEventWithEpa.getMaterialName(), secondAgencyAlignment.getMaterialName());
        assertEquals(secondEventWithEpa.getEventAgencyAlignmentId(), secondAgencyAlignment.getEventAgencyAlignmentId());
        assertEquals(secondEventWithEpa.getEventAgencyAlignmentPubkey(), secondAgencyAlignment.getEventAgencyAlignmentPubkey());
        assertEquals(secondEventWithEpa.getMaxQuantity(), secondAgencyAlignment.getMaxQuantity());
        assertEquals(secondEventWithEpa.getRegulated(), secondAgencyAlignment.getRegulated());
        assertEquals(secondEventWithEpa.getCrop().getCropName(), secondAgencyAlignment.getCrop().getCropName());
        assertEquals(secondEventWithEpa.getAgencyMaterialType().getMaterialTypeDesc(), secondAgencyAlignment.getAgencyMaterialType().getMaterialTypeDesc());

    }

    private EventAgencyAlignment findAlignment(EventAgencyAlignment[] alignments, String eventName, String agencyAbbr) {
        for (EventAgencyAlignment alignment : alignments) {
            if (eventName.equals(alignment.getMaterialName()) && agencyAbbr.equals(alignment.getAgency().getAgencyAbbr())) {
                return alignment;
            }
        }
        throw new AssertionError("Could not find expected alignment '" + eventName + ", " + agencyAbbr + "'");
    }

    private EventAgencyAlignment findAgencyWithEventAndCrop(EventAgencyAlignment[] alignmentsReceived, String event, String cropName) {
        for (EventAgencyAlignment eventAgencyAlignment : alignmentsReceived) {
            if (event.equals(eventAgencyAlignment.getMaterialName()) && cropName.equals(eventAgencyAlignment.getCrop().getCropName())) {
                return eventAgencyAlignment;
            }
        }
        return null;
    }

    private EventAgencyAlignment findAgencyWithAbbreviation(EventAgencyAlignment[] eventAgencies, String agencyAbbreviation) {
        for (EventAgencyAlignment eventAgency : eventAgencies) {
            Agency agency = eventAgency.getAgency();
            if (agencyAbbreviation.equals(agency.getAgencyAbbr())) {
                return eventAgency;
            }
        }
        return null;
    }
}
