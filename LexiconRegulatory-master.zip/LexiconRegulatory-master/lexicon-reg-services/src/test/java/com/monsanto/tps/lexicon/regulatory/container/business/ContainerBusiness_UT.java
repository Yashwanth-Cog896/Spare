package com.monsanto.tps.lexicon.regulatory.container.business;

import com.monsanto.tps.lexicon.container.OrionContainer;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ContainerType;
import com.monsanto.tps.lexicon.regulatory.container.dao.ContainerDAO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/1/12
 * Time: 7:47 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class ContainerBusiness_UT {

    @Mock
    private ContainerDAO containerDAO;

    @InjectMocks
    private ContainerBusiness containerBusiness = new ContainerBusiness();

    private final List<ContainerType> singleContainerListFromDAO;
    private final List<ContainerType> multiContainerListFromDAO;
    private static final List<ContainerType> emptyListFromDAO = new ArrayList<ContainerType>();

    private final List<OrionContainer> singleContainerListFromBusiness;
    private final List<OrionContainer> multiContainerListFromBusiness;
    private static final List<OrionContainer> emptyListFromBusiness = new ArrayList<OrionContainer>();

    public ContainerBusiness_UT() {
        singleContainerListFromDAO = new ArrayList<ContainerType>();
        singleContainerListFromDAO.add(new ContainerType("type", "container", true));

        multiContainerListFromDAO = new ArrayList<ContainerType>();
        multiContainerListFromDAO.add(new ContainerType("type1", "container1", true));
        multiContainerListFromDAO.add(new ContainerType("type2", "container2", false));

        singleContainerListFromBusiness = new ArrayList<OrionContainer>();
        singleContainerListFromBusiness.add(new OrionContainer("type", "container", true));

        multiContainerListFromBusiness = new ArrayList<OrionContainer>();
        multiContainerListFromBusiness.add(new OrionContainer("type1", "container1", true));
        multiContainerListFromBusiness.add(new OrionContainer("type2", "container2", false));
    }

    @Test
    public void findContainerTypes_findNone() throws Exception {

        when(containerDAO.findContainerTypes("asdf")).thenReturn(emptyListFromDAO);

        final List<OrionContainer> actualContainers = containerBusiness.findContainerTypes("asdf");

        checkContainerLists(actualContainers, emptyListFromBusiness);
    }

    @Test
    public void findContainerTypes_findSingle() throws Exception {

        when(containerDAO.findContainerTypes("Jar")).thenReturn(singleContainerListFromDAO);

        final List<OrionContainer> actualContainers = containerBusiness.findContainerTypes("Jar");

        checkContainerLists(actualContainers, singleContainerListFromBusiness);
    }

    @Test
    public void findContainerTypes_findByWildcard() throws Exception {

        when(containerDAO.findContainerTypes("Glass%")).thenReturn(multiContainerListFromDAO);

        final List<OrionContainer> actualContainers = containerBusiness.findContainerTypes("Glass*");

        checkContainerLists(actualContainers, multiContainerListFromBusiness);
    }

    @Test
    public void findContainerTypes_findAll() throws Exception {

        when(containerDAO.findContainerTypes("%")).thenReturn(multiContainerListFromDAO);

        final List<OrionContainer> actualContainers = containerBusiness.findContainerTypes("");

        checkContainerLists(actualContainers, multiContainerListFromBusiness);
    }

    private void checkContainerLists(final List<OrionContainer> actualContainers, final List<OrionContainer> singleContainerListFromBusiness) {
        assertNotNull(actualContainers);

        for(int i=0; i<singleContainerListFromBusiness.size(); i++) {
            final OrionContainer container = actualContainers.get(i);
            assertEquals(container.getContainerType(), singleContainerListFromBusiness.get(i).getContainerType());
            assertEquals(container.getStorageCondition(), singleContainerListFromBusiness.get(i).getStorageCondition());
            assertEquals(container.getActiveStatus(), singleContainerListFromBusiness.get(i).getActiveStatus());
        }
    }
}
