package com.monsanto.tps.lexicon.regulatory.util.test.hamcrest;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.junit.internal.matchers.TypeSafeMatcher;


/**
 * nbwald - Feb 20, 2009 9:42:59 AM
 */
public class NumericMatcher
{
   public static Matcher<Integer> greaterThan(final int i) {
      return new TypeSafeMatcher<Integer>()
      {
         @Override
         public boolean matchesSafely(Integer item) {
            return item > i;
         }

         @Override
         public void describeTo(Description description) {
            description.appendText("greater than ").appendValue(i);
         }
      };
   }

   public static Matcher<Integer> lessThan(final int i) {
      return new TypeSafeMatcher<Integer>()
      {
         @Override
         public boolean matchesSafely(Integer item) {
            return item < i;
         }

         @Override
         public void describeTo(Description description) {
            description.appendText("less than ").appendValue(i);
         }
      };
   }
}
