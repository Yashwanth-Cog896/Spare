package com.monsanto.tps.lexicon.regulatory.formulation.service;

import com.monsanto.tps.lexicon.formulation.FormulationService;
import com.monsanto.tps.lexicon.formulation.OrionFormulation;
import com.monsanto.tps.lexicon.regulatory.formulation.business.FormulationBusiness;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 3/5/12
 * Time: 1:51 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class FormulationServiceImpl_UT {

    @Mock
    private FormulationBusiness formulationBusiness;

    @InjectMocks
    private FormulationService formulationService = new FormulationServiceImpl();

    private static final List<OrionFormulation> containerList = new ArrayList<OrionFormulation>();

    @Test
    public void findFormulationTypes_success() throws Exception {
        when(formulationBusiness.findFormulationTypes("TB")).thenReturn(containerList);

        final List<OrionFormulation> actualFormulation = formulationBusiness.findFormulationTypes("TB");

        assertEquals(actualFormulation, containerList);
    }
}
