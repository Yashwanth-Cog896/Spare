package com.monsanto.tps.lexicon.regulatory.nonmonevent.validation;

import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import org.junit.Test;

/**
 * nbwald - May 21, 2009 5:56:27 PM
 */
public class NonMonEventDoesNotExistRule_UT
{
   @Test
   public void testViolated_False()
      throws Exception
   {
      NonMonEvent event = null;
      Rule<String> rule = new NonMonEventDoesNotExistRule(event);

      assertThat(rule.violated(), is(false));
   }

   @Test
   public void testViolated_True()
      throws Exception
   {
      NonMonEvent event = new NonMonEvent();
      Rule<String> rule = new NonMonEventDoesNotExistRule(event);

      assertThat(rule.violated(), is(true));
   }

   @Test
   public void testGetViolation()
      throws Exception
   {
      assertThat(new NonMonEventDoesNotExistRule(null).getViolation(), is("Non-Monsanto event already exists."));
   }
}
