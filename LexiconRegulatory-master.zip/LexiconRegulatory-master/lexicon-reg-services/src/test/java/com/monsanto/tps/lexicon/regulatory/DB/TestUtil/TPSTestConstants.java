package com.monsanto.tps.lexicon.regulatory.DB.TestUtil;

/**
 * Created by IntelliJ IDEA.
 * User: MAWEAV1
 * Date: Sep 8, 2004
 * Time: 1:11:04 PM
 * To change this template use File | Settings | File Templates.
 */
public class TPSTestConstants
{
   public static final String SINGLE_PMON_CONSTRUCT_FOR_FCM_PVCODE = "pMON94946";
   public static final int GENETIC_MATERIAL_ID_ONE = -8632;
   public static final int GERMPLASM_ID_ONE = -1323;
   public static final String GENERATION_R0 = "R0";
   public static final long MIDAS_CANOLA_ID = 65929216;
   public static final int EVENT_CONSTRUCT_ID_ONE = -86346;
   public static final int GERMPLASM_EVENT_CONSTRUCT_ID_ONE = -12863;
   public static final String TRANSFORMATION_GENOTYPE = "transformationGenotype"; // This guy is the transformation background in Midas
   public static final long MIDAS_CORN_ID = 65601536;
   public static final String CORN_GENUS_SPECIES = "ZM";
   public static final String GENETIC_ITEM_KEY_ONE = "-878439";
   public static final String CANOLA_GENUS_SPECIES = "BN";
   public static final String PV_CODE_FOR_EVENT_SINGLE_PMON_CONSTRUCT = "PV-BNAP5848";
   public static final String SINGLE_PMON_CONSTRUCT_FOR_MULTIPLE_FCM_PVCODES = "PMON52051";
   public static final int EVENT_CONSTRUCT_ID_TWO = -96344;
   public static final String MULTIPLE_PVCODES = "PV-BNAP5749,PV-GMAP2622,PV-GMGOX20";
   public static final String COMBINED_PMON_CONSTRUCT_FOR_FCM_PVCODE = "pCGN9009,pMON77216";
   public static final String PV_CODE_FOR_EVENT_COMBINED_PMON_CONSTRUCT = "PV-BNCTB2442";
   public static final int GERMPLASM_EVENT_CONSTRUCT_ID_TWO = -19287;
   public static final int EVENT_CONSTRUCT_ID_THREE = -87654;
   public static final int GERMPLASM_EVENT_CONSTRUCT_ID_THREE = -76543;
   public static final int GERMPLASM_ID_TWO = -420189;
   public static final long MIDAS_COTTON_ID = 65994752;
}
