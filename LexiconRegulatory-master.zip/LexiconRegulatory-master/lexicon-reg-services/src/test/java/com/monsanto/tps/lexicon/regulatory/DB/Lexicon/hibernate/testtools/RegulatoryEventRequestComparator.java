package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools;

import com.monsanto.tps.lexicon.regulatory.event.model.RegulatoryEventRequest;

import java.util.Comparator;

/**
 * rrchak1 - Dec 19, 2008 4:03:09 PM
 */
public class RegulatoryEventRequestComparator
   implements Comparator<RegulatoryEventRequest>
{
   public int compare(RegulatoryEventRequest o1, RegulatoryEventRequest o2) {
      if (o1.getEvent().compareTo(o2.getEvent()) == 0 && o1.getCrop().compareTo(o2.getCrop()) == 0) {
         return 0;
      }
      else {
         return 1;
      }
   }
}
