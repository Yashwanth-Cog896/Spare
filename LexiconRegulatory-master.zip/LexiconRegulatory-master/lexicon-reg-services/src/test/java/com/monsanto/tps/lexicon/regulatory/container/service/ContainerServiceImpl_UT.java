package com.monsanto.tps.lexicon.regulatory.container.service;

import com.monsanto.tps.lexicon.container.ContainerService;
import com.monsanto.tps.lexicon.container.OrionContainer;
import com.monsanto.tps.lexicon.regulatory.container.business.ContainerBusiness;
import com.monsanto.tps.lexicon.regulatory.container.dao.ContainerDAO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/1/12
 * Time: 7:47 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class ContainerServiceImpl_UT {

    @Mock
    private ContainerBusiness containerBusiness;

    @InjectMocks
    private ContainerService containerService = new ContainerServiceImpl();

    private static final List<OrionContainer> containerList = new ArrayList<OrionContainer>();

    @Test
    public void findContainerTypes_success() throws Exception {
        when(containerBusiness.findContainerTypes("Jar")).thenReturn(containerList);

        final List<OrionContainer> actualContainers = containerBusiness.findContainerTypes("Jar");

        assertEquals(actualContainers, containerList);
    }
}
