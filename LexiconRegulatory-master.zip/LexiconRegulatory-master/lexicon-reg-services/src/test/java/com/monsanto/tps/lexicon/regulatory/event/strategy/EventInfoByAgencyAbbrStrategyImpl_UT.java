package com.monsanto.tps.lexicon.regulatory.event.strategy;

import com.monsanto.tps.lexicon.event.EventInfo;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Crop;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber;
import com.monsanto.tps.lexicon.regulatory.event.model.EventConstruct;
import com.monsanto.tps.lexicon.regulatory.event.model.MockEventConstruct;
import com.monsanto.tps.lexicon.regulatory.event.queryset.EventCrop;
import com.monsanto.tps.lexicon.regulatory.event.queryset.EventSearchServiceQuerySet;
import com.monsanto.tps.lexicon.regulatory.event.queryset.RegulatoryEventResponse;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

import static com.monsanto.tps.lexicon.regulatory.util.test.hamcrest.NumericMatcher.greaterThan;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * rrchak1 - Feb 17, 2009 12:32:03 PM
 */
public class EventInfoByAgencyAbbrStrategyImpl_UT {
    private EventSearchServiceQuerySet querySet;
    private EventInfoByAgencyAbbrStrategy strategy;

    @Before
    public void before() {
        querySet = mock(EventSearchServiceQuerySet.class);
        strategy = new EventInfoByAgencyAbbrStrategyImpl(querySet);
    }

    @Test
    public void testFindByPubkey_FindsEventAgencyAlignment_RegulatoryEvent_MonNumber()
            throws Exception {
        String eventName = "ZM_1111";
        EventAgencyAlignment eventAgencyAlignment = new EventAgencyAlignment();
        eventAgencyAlignment.setMaterialName(eventName);
        Crop crop = new Crop();
        crop.setCropName("CORN");
        eventAgencyAlignment.setCrop(crop);
        String[] agencyAbbr = new String[]{"DEA"};
        when(querySet.findByAgencyAbbr(agencyAbbr)).thenReturn(new EventAgencyAlignment[]{eventAgencyAlignment});
        RegulatoryEventResponse response = new RegulatoryEventResponse();
        response.setEventConstructs(Arrays.asList((EventConstruct) new MockEventConstruct(eventName, crop.getCropName())));
        response.setEvent(eventName);
        when(querySet.findRegulatoryEventByEventAndCrop(eq(new HashSet(Arrays.asList(new EventCrop(eventName, crop.getCropName())))))).thenReturn(Arrays.asList(response));
        when(querySet.findMonNumberByEventAndCrop(eq(eventName), eq(crop.getCropName()))).thenReturn(new MonNumber());

        EventInfo[] eventInfos = strategy.find(agencyAbbr);


        assertThat(eventInfos.length, is(greaterThan(0)));
    }

    @Test
    public void testFind_AlignmentsAttachedToNonexistentEvents()
            throws Exception {
        String eventName = "ZM_1111";
        EventAgencyAlignment eventAgencyAlignment = new EventAgencyAlignment();
        eventAgencyAlignment.setMaterialName(eventName);
        Crop crop = new Crop();
        crop.setCropName("CORN");
        eventAgencyAlignment.setCrop(crop);
        String[] agencyAbbr = new String[]{"DEA"};
        when(querySet.findByAgencyAbbr(agencyAbbr)).thenReturn(new EventAgencyAlignment[]{eventAgencyAlignment});
        when(querySet.findRegulatoryEventByEventAndCrop(eq(new HashSet(Arrays.asList(new EventCrop(eventName, crop.getCropName())))))).thenReturn(new ArrayList<RegulatoryEventResponse>());

        EventInfo[] eventInfos = strategy.find(agencyAbbr);


        assertThat(eventInfos.length, is(0));
    }
}
