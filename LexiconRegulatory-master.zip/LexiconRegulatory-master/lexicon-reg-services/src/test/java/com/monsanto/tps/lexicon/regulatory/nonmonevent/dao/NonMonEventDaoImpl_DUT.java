package com.monsanto.tps.lexicon.regulatory.nonmonevent.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.ComlTraitNameBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.ComlTraitTypeBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.CropBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.LexiconDataUnitTestCase;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.NonMonEventBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.NonMonEventConstructBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.ProteinNameBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEventConstruct;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName;
import org.junit.Test;

import javax.annotation.Resource;

import static org.junit.Assert.*;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: gdleon
 * Date: May 6, 2009
 * Time: 2:18:05 PM
 */
public class NonMonEventDaoImpl_DUT
   extends LexiconDataUnitTestCase
{
   @Resource
   private NonMonEventDao nonMonEventDao;

   @Test
 public void testFindByCrop() {
       String materialName = "MAT NAME";
       new NonMonEventBuilder().
         withEventDescription("ZM_1111").
         withCropPubkey(CropBuilder.soybeans().getCropPubkey()).
         withMaterialName(materialName).
         withNonMonEventConstruct(new NonMonEventConstructBuilder().
            withConstructName("CON_111")).
         withComlTraitType(new ComlTraitTypeBuilder().
            withTraitTypeAbbr("TRTABBR").
            withTraitTypeDesc("TRT TYPE DESC")).
         withComlTraitName(new ComlTraitNameBuilder().
            withTraitAbbr("TNABBR").
            withTraitDesc("TRT NAME DESC")).
         withProteinName(new ProteinNameBuilder().
            withProteinName("PROT NAME").
            withProteinNamePubkey("1234").
            withProteinDescription("PROT DESC").
            withOrigSourceOrganism("ORIG SOURCE ORG").
            create()).
         create();

       NonMonEvent[] nonMonEvents = nonMonEventDao.findByCrop("1115");

       assertTrue(nonMonEvents.length > 0);
       assertTrue(containsNonMonEvent("ZM_1111", nonMonEvents));
       for (NonMonEvent nonMonEvent : nonMonEvents) {
          assertTrue(nonMonEvent.getCropPubkey().equals("1115"));
          assertTrue(nonMonEvent.isActiveStatus());
          if (nonMonEvent.getEventDescription().equals("ZM_1111")) {
             assertTrue(containsConstructName("CON_111", nonMonEvent));
             assertTrue(containsTraitType("TRTABBR", nonMonEvent));
             assertTrue(containsTraitName("TNABBR", nonMonEvent));
             assertTrue(containsProteinName("PROT NAME", nonMonEvent));
             assertEquals(materialName, nonMonEvent.getMaterialName());
         }
      }
   }

   @Test
 public void testFindByCrop_MultipleNonMonEventsSingleSimilarValues() {
      ComlTraitTypeBuilder comlTraitTypeBuilder =
         new ComlTraitTypeBuilder().
            withTraitTypeAbbr("TRTABBR").
            withTraitTypeDesc("TRT TYPE DESC");

      ComlTraitNameBuilder comlTraitNameBuilder =
         new ComlTraitNameBuilder().
            withTraitAbbr("TNABBR").
            withTraitDesc("TRT NAME DESC");

      ProteinName proteinName =
         new ProteinNameBuilder().
            withProteinName("PROT NAME").
            withProteinNamePubkey("1234").
            withProteinDescription("PROT DESC").
            withOrigSourceOrganism("ORIG SOURCE ORG").create();

       String materialName = "MAT NAME";
       new NonMonEventBuilder().
         withEventDescription("ZM_1111").
         withMaterialName(materialName).
         withCropPubkey(CropBuilder.soybeans().getCropPubkey()).
         withNonMonEventConstruct(
            new NonMonEventConstructBuilder().
               withConstructName("CON_111")
         ).
         withComlTraitType(comlTraitTypeBuilder).
         withComlTraitName(comlTraitNameBuilder).
         withProteinName(proteinName).
         create();

       new NonMonEventBuilder().
         withEventDescription("ZM_2222").
         withMaterialName(materialName).
         withCropPubkey(CropBuilder.soybeans().getCropPubkey()).
         withNonMonEventConstruct(
            new NonMonEventConstructBuilder().
               withConstructName("CON_111")
         ).
         withComlTraitType(comlTraitTypeBuilder).
         withComlTraitName(comlTraitNameBuilder).
         withProteinName(proteinName).
         create();

      NonMonEvent[] nonMonEvents = nonMonEventDao.findByCrop("1115");

      assertTrue(nonMonEvents.length > 0);
      assertTrue(containsNonMonEvent("ZM_1111", nonMonEvents));
      assertTrue(containsNonMonEvent("ZM_2222", nonMonEvents));
      for (NonMonEvent nonMonEvent : nonMonEvents) {
         assertTrue(nonMonEvent.getCropPubkey().equals("1115"));
         assertTrue(nonMonEvent.isActiveStatus());
         if (nonMonEvent.getEventDescription().equals("ZM_1111") ||
            nonMonEvent.getEventDescription().equals("ZM_2222")) {
            assertTrue(containsConstructName("CON_111", nonMonEvent));
            assertTrue(containsTraitType("TRTABBR", nonMonEvent));
            assertTrue(containsTraitName("TNABBR", nonMonEvent));
            assertTrue(containsProteinName("PROT NAME", nonMonEvent));
            assertEquals(materialName, nonMonEvent.getMaterialName());
         }
      }
   }

   @Test
 public void testFindByCrop_MultipleNonMonEventsMultipleDifferentValues() {
      new NonMonEventBuilder().
         withEventDescription("ZM_1111").
         withMaterialName("MAT NAME1").
         withCropPubkey(CropBuilder.soybeans().getCropPubkey()).
         withNonMonEventConstruct(
            new NonMonEventConstructBuilder().
               withConstructName("CON_111")
         ).
         withComlTraitType(
            new ComlTraitTypeBuilder().
               withTraitTypeAbbr("TRTABB1").
               withTraitTypeDesc("TRT TYPE DESC 1")
         ).
         withComlTraitName(
            new ComlTraitNameBuilder().
               withTraitAbbr("TNABB1").
               withTraitDesc("TRT NAME DESC 1")
         ).
         withProteinName(new ProteinNameBuilder().
            withProteinName("PROT NAME 1").
            withProteinNamePubkey("12341").
            withProteinDescription("PROT DESC 1").
            withOrigSourceOrganism("ORIG SOURCE ORG 1").create()).
         create();

      new NonMonEventBuilder().
         withEventDescription("ZM_2222").
         withMaterialName("MAT NAME2").
         withCropPubkey(CropBuilder.soybeans().getCropPubkey()).
         withNonMonEventConstruct(
            new NonMonEventConstructBuilder().
               withConstructName("CON_222")
         ).
         withComlTraitType(
            new ComlTraitTypeBuilder().
               withTraitTypeAbbr("TRTABB2").
               withTraitTypeDesc("TRT TYPE DESC 2")
         ).
         withComlTraitName(
            new ComlTraitNameBuilder().
               withTraitAbbr("TNABB2").
               withTraitDesc("TRT NAME DESC 2")
         ).
         withProteinName(new ProteinNameBuilder().
            withProteinName("PROT NAME 2").
            withProteinNamePubkey("12342").
            withProteinDescription("PROT DESC 2").
            withOrigSourceOrganism("ORIG SOURCE ORG 2").create()).
         create();

      NonMonEvent[] nonMonEvents = nonMonEventDao.findByCrop("1115");

      assertTrue(nonMonEvents.length > 0);
      assertTrue(containsNonMonEvent("ZM_1111", nonMonEvents));
      assertTrue(containsNonMonEvent("ZM_2222", nonMonEvents));
      for (NonMonEvent nonMonEvent : nonMonEvents) {
         assertTrue(nonMonEvent.getCropPubkey().equals("1115"));
         assertTrue(nonMonEvent.isActiveStatus());
         if (nonMonEvent.getEventDescription().equals("ZM_1111")) {
            assertTrue(containsConstructName("CON_111", nonMonEvent));
            assertTrue(containsTraitType("TRTABB1", nonMonEvent));
            assertTrue(containsTraitName("TNABB1", nonMonEvent));
            assertTrue(containsProteinName("PROT NAME 1", nonMonEvent));
            assertEquals("MAT NAME1", nonMonEvent.getMaterialName());
         }
         else if (nonMonEvent.getEventDescription().equals("ZM_2222")) {
            assertTrue(containsConstructName("CON_222", nonMonEvent));
            assertTrue(containsTraitType("TRTABB2", nonMonEvent));
            assertTrue(containsTraitName("TNABB2", nonMonEvent));
            assertTrue(containsProteinName("PROT NAME 2", nonMonEvent));
            assertEquals("MAT NAME2", nonMonEvent.getMaterialName());
         }
      }
   }

   @Test
 public void testFindByCrop_NoDataFound() {
      NonMonEvent[] nonMonEvents = nonMonEventDao.findByCrop("InvalidCropPubkey");

      assertEquals(0, nonMonEvents.length);
   }

   @Test
 public void testFindByNonMonEvent() {
      String materialName = "MAT NAME";
      new NonMonEventBuilder().
         withEventDescription("ZM_1111").
         withMaterialName(materialName).
         withCropPubkey(CropBuilder.soybeans().getCropPubkey()).
         withNonMonEventConstruct(
            new NonMonEventConstructBuilder().
               withConstructName("CON_111")
         ).
         withComlTraitType(
            new ComlTraitTypeBuilder().
               withTraitTypeAbbr("TRTABBR").
               withTraitTypeDesc("TRT TYPE DESC")
         ).
         withComlTraitName(
            new ComlTraitNameBuilder().
               withTraitAbbr("TNABBR").
               withTraitDesc("TRT NAME DESC")
         ).
         withProteinName(new ProteinNameBuilder().
            withProteinName("PROT NAME").
            withProteinNamePubkey("1234").
            withProteinDescription("PROT DESC").
            withOrigSourceOrganism("ORIG SOURCE ORG").create()).
         create();

      NonMonEvent[] nonMonEvents = nonMonEventDao.findByNonMonEvent("ZM_1111");

      assertTrue(nonMonEvents.length > 0);
      assertTrue(containsNonMonEvent("ZM_1111", nonMonEvents));
      for (NonMonEvent nonMonEvent : nonMonEvents) {
         assertTrue(nonMonEvent.getCropPubkey().equals("1115"));
         assertTrue(nonMonEvent.isActiveStatus());
         if (nonMonEvent.getEventDescription().equals("ZM_1111")) {
            assertTrue(containsConstructName("CON_111", nonMonEvent));
            assertTrue(containsTraitType("TRTABBR", nonMonEvent));
            assertTrue(containsTraitName("TNABBR", nonMonEvent));
            assertTrue(containsProteinName("PROT NAME", nonMonEvent));
            assertEquals(materialName, nonMonEvent.getMaterialName());
         }
      }
   }

   @Test
 public void testFindByNonMonEvent_MultipleMonEventsSingleSimilarValues() {
      ComlTraitTypeBuilder comlTraitTypeBuilder =
         new ComlTraitTypeBuilder().
            withTraitTypeAbbr("TRTABBR").
            withTraitTypeDesc("TRT TYPE DESC");

      ComlTraitNameBuilder comlTraitNameBuilder =
         new ComlTraitNameBuilder().
            withTraitAbbr("TNABBR").
            withTraitDesc("TRT NAME DESC");

      ProteinName proteinName =
         new ProteinNameBuilder().
            withProteinName("PROT NAME").
            withProteinNamePubkey("1234").
            withProteinDescription("PROT DESC").
            withOrigSourceOrganism("ORIG SOURCE ORG").create();

      String materialName = "MAT NAME";
      new NonMonEventBuilder().
         withEventDescription("ZM_1111").
         withMaterialName(materialName).
         withCropPubkey(CropBuilder.soybeans().getCropPubkey()).
         withNonMonEventConstruct(
            new NonMonEventConstructBuilder().
               withConstructName("CON_111")
         ).
         withComlTraitType(comlTraitTypeBuilder).
         withComlTraitName(comlTraitNameBuilder).
         withProteinName(proteinName).
         create();

      new NonMonEventBuilder().
         withEventDescription("ZM_1111").
         withMaterialName(materialName).
         withCropPubkey(CropBuilder.corn().getCropPubkey()).
         withNonMonEventConstruct(
            new NonMonEventConstructBuilder().
               withConstructName("CON_111")
         ).
         withComlTraitType(comlTraitTypeBuilder).
         withComlTraitName(comlTraitNameBuilder).
         withProteinName(proteinName).
         create();

      NonMonEvent[] nonMonEvents = nonMonEventDao.findByNonMonEvent("ZM_1111");

      assertTrue(nonMonEvents.length > 0);
      assertTrue(containsNonMonEvent("ZM_1111", nonMonEvents));
      for (NonMonEvent nonMonEvent : nonMonEvents) {
         assertTrue(nonMonEvent.isActiveStatus());
         if (nonMonEvent.getEventDescription().equals("ZM_1111")) {
            assertTrue(nonMonEvent.getCropPubkey().equals("1015") ||
               nonMonEvent.getCropPubkey().equals("1115"));
            assertTrue(containsConstructName("CON_111", nonMonEvent));
            assertTrue(containsTraitType("TRTABBR", nonMonEvent));
            assertTrue(containsTraitName("TNABBR", nonMonEvent));
            assertTrue(containsProteinName("PROT NAME", nonMonEvent));
            assertEquals(materialName, nonMonEvent.getMaterialName());
         }
      }
   }

   @Test
 public void testFindByNonMonEvent_MultipleNonMonEventsMultipleDifferentValues() {
      new NonMonEventBuilder().
         withEventDescription("ZM_1111").
         withMaterialName("MAT NAME1").
         withCropPubkey(CropBuilder.soybeans().getCropPubkey()).
         withNonMonEventConstruct(
            new NonMonEventConstructBuilder().
               withConstructName("CON_111")
         ).
         withComlTraitType(
            new ComlTraitTypeBuilder().
               withTraitTypeAbbr("TRTABB1").
               withTraitTypeDesc("TRT TYPE DESC 1")
         ).
         withComlTraitName(
            new ComlTraitNameBuilder().
               withTraitAbbr("TNABB1").
               withTraitDesc("TRT NAME DESC 1")
         ).
         withProteinName(new ProteinNameBuilder().
            withProteinName("PROT NAME 1").
            withProteinNamePubkey("12341").
            withProteinDescription("PROT DESC 1").
            withOrigSourceOrganism("ORIG SOURCE ORG 1").create()).
         create();

      new NonMonEventBuilder().
         withEventDescription("ZM_1111").
         withMaterialName("MAT NAME2").
         withCropPubkey(CropBuilder.corn().getCropPubkey()).
         withNonMonEventConstruct(
            new NonMonEventConstructBuilder().
               withConstructName("CON_222")
         ).
         withComlTraitType(
            new ComlTraitTypeBuilder().
               withTraitTypeAbbr("TRTABB2").
               withTraitTypeDesc("TRT TYPE DESC 2")
         ).
         withComlTraitName(
            new ComlTraitNameBuilder().
               withTraitAbbr("TNABB2").
               withTraitDesc("TRT NAME DESC 2")
         ).
         withProteinName(new ProteinNameBuilder().
            withProteinName("PROT NAME 2").
            withProteinNamePubkey("12342").
            withProteinDescription("PROT DESC 2").
            withOrigSourceOrganism("ORIG SOURCE ORG 2").create()).
         create();

      NonMonEvent[] nonMonEvents = nonMonEventDao.findByNonMonEvent("ZM_1111");

      assertTrue(nonMonEvents.length > 0);
      assertTrue(containsNonMonEvent("ZM_1111", nonMonEvents));
      for (NonMonEvent nonMonEvent : nonMonEvents) {
         assertTrue(nonMonEvent.isActiveStatus());
         if (nonMonEvent.getEventDescription().equals("ZM_1111") &&
            nonMonEvent.getCropPubkey().equals("1115")) {
            assertTrue(containsConstructName("CON_111", nonMonEvent));
            assertTrue(containsTraitType("TRTABB1", nonMonEvent));
            assertTrue(containsTraitName("TNABB1", nonMonEvent));
            assertTrue(containsProteinName("PROT NAME 1", nonMonEvent));
            assertEquals("MAT NAME1", nonMonEvent.getMaterialName());
         }
         else if (nonMonEvent.getEventDescription().equals("ZM_1111") &&
            nonMonEvent.getCropPubkey().equals("1015")) {
            assertTrue(containsConstructName("CON_222", nonMonEvent));
            assertTrue(containsTraitType("TRTABB2", nonMonEvent));
            assertTrue(containsTraitName("TNABB2", nonMonEvent));
            assertTrue(containsProteinName("PROT NAME 2", nonMonEvent));
            assertEquals("MAT NAME2", nonMonEvent.getMaterialName());
         }
         else if (nonMonEvent.getEventDescription().equals("ZM_1111")) {
            fail("Invalid Non-Mon Event found.");
         }
      }
   }

   @Test
 public void testFindByNonMonEvent_NoDataFound() {
      NonMonEvent[] nonMonEvents = nonMonEventDao.findByNonMonEvent("InvalidNonMonEvent");

      assertEquals(0, nonMonEvents.length);
   }

   @Test
 public void testFindByNonMonEventAndCrop() {
      new NonMonEventBuilder().
         withEventDescription("ZM_1111").
         withCropPubkey(CropBuilder.soybeans().getCropPubkey()).
         withNonMonEventConstruct(
            new NonMonEventConstructBuilder().
               withConstructName("CON_111")
         ).
         withComlTraitType(
            new ComlTraitTypeBuilder().
               withTraitTypeAbbr("TRTABBR").
               withTraitTypeDesc("TRT TYPE DESC")
         ).
         withComlTraitName(
            new ComlTraitNameBuilder().
               withTraitAbbr("TNABBR").
               withTraitDesc("TRT NAME DESC")
         ).
         withProteinName(new ProteinNameBuilder().
            withProteinName("PROT NAME").
            withProteinNamePubkey("1234").
            withProteinDescription("PROT DESC").
            withOrigSourceOrganism("ORIG SOURCE ORG").create()).
         create();

      NonMonEvent[] nonMonEvents = nonMonEventDao.findByNonMonEventAndCrop("ZM_1111", CropBuilder.soybeans().getCropPubkey());

      assertTrue(nonMonEvents.length > 0);
      assertTrue(containsNonMonEvent("ZM_1111", nonMonEvents));
      for (NonMonEvent nonMonEvent : nonMonEvents) {
         assertTrue(nonMonEvent.getCropPubkey().equals("1115"));
         assertTrue(nonMonEvent.isActiveStatus());
         if (nonMonEvent.getEventDescription().equals("ZM_1111")) {
            assertTrue(containsConstructName("CON_111", nonMonEvent));
            assertTrue(containsTraitType("TRTABBR", nonMonEvent));
            assertTrue(containsTraitName("TNABBR", nonMonEvent));
            assertTrue(containsProteinName("PROT NAME", nonMonEvent));
         }
      }
   }

   @Test
 public void testFindByNonMonEventAndCrop_MultipleMonEventsSingleSimilarValues() {
      ComlTraitTypeBuilder comlTraitTypeBuilder =
         new ComlTraitTypeBuilder().
            withTraitTypeAbbr("TRTABBR").
            withTraitTypeDesc("TRT TYPE DESC");

      ComlTraitNameBuilder comlTraitNameBuilder =
         new ComlTraitNameBuilder().
            withTraitAbbr("TNABBR").
            withTraitDesc("TRT NAME DESC");

      ProteinName proteinName =
         new ProteinNameBuilder().
            withProteinName("PROT NAME").
            withProteinNamePubkey("1234").
            withProteinDescription("PROT DESC").
            withOrigSourceOrganism("ORIG SOURCE ORG").create();

      new NonMonEventBuilder().
         withEventDescription("ZM_1111").
         withCropPubkey(CropBuilder.corn().getCropPubkey()).
         withNonMonEventConstruct(
            new NonMonEventConstructBuilder().
               withConstructName("CON_111")
         ).
         withComlTraitType(comlTraitTypeBuilder).
         withComlTraitName(comlTraitNameBuilder).
         withProteinName(proteinName).
         create();

      new NonMonEventBuilder().
         withEventDescription("ZM_1111").
         withCropPubkey(CropBuilder.corn().getCropPubkey()).
         withNonMonEventConstruct(
            new NonMonEventConstructBuilder().
               withConstructName("CON_111")
         ).
         withComlTraitType(comlTraitTypeBuilder).
         withComlTraitName(comlTraitNameBuilder).
         withProteinName(proteinName).
         create();

      NonMonEvent[] nonMonEvents = nonMonEventDao.findByNonMonEventAndCrop("ZM_1111", CropBuilder.corn().getCropPubkey());

      assertTrue(nonMonEvents.length > 0);
      assertTrue(containsNonMonEvent("ZM_1111", nonMonEvents));
      for (NonMonEvent nonMonEvent : nonMonEvents) {
         assertTrue(nonMonEvent.isActiveStatus());
         if (nonMonEvent.getEventDescription().equals("ZM_1111")) {
            assertTrue(nonMonEvent.getCropPubkey().equals("1015") ||
               nonMonEvent.getCropPubkey().equals("1115"));
            assertTrue(containsConstructName("CON_111", nonMonEvent));
            assertTrue(containsTraitType("TRTABBR", nonMonEvent));
            assertTrue(containsTraitName("TNABBR", nonMonEvent));
            assertTrue(containsProteinName("PROT NAME", nonMonEvent));
         }
      }
   }

   @Test
 public void testFindByNonMonEventAndCrop_MultipleNonMonEventsMultipleDifferentValues() {
      new NonMonEventBuilder().
         withEventDescription("ZM_1111").
         withCropPubkey(CropBuilder.corn().getCropPubkey()).
         withNonMonEventConstruct(
            new NonMonEventConstructBuilder().
               withConstructName("CON_111")
         ).
         withComlTraitType(
            new ComlTraitTypeBuilder().
               withTraitTypeAbbr("TRTABB1").
               withTraitTypeDesc("TRT TYPE DESC 1")
         ).
         withComlTraitName(
            new ComlTraitNameBuilder().
               withTraitAbbr("TNABB1").
               withTraitDesc("TRT NAME DESC 1")
         ).
         withProteinName(new ProteinNameBuilder().
            withProteinName("PROT NAME 1").
            withProteinNamePubkey("12341").
            withProteinDescription("PROT DESC 1").
            withOrigSourceOrganism("ORIG SOURCE ORG 1").create()).
         create();

      new NonMonEventBuilder().
         withEventDescription("ZM_1111").
         withCropPubkey(CropBuilder.corn().getCropPubkey()).
         withNonMonEventConstruct(
            new NonMonEventConstructBuilder().
               withConstructName("CON_222")
         ).
         withComlTraitType(
            new ComlTraitTypeBuilder().
               withTraitTypeAbbr("TRTABB2").
               withTraitTypeDesc("TRT TYPE DESC 2")
         ).
         withComlTraitName(
            new ComlTraitNameBuilder().
               withTraitAbbr("TNABB2").
               withTraitDesc("TRT NAME DESC 2")
         ).
         withProteinName(new ProteinNameBuilder().
            withProteinName("PROT NAME 2").
            withProteinNamePubkey("12342").
            withProteinDescription("PROT DESC 2").
            withOrigSourceOrganism("ORIG SOURCE ORG 2").create()).
         create();

      NonMonEvent[] nonMonEvents = nonMonEventDao.findByNonMonEventAndCrop("ZM_1111", CropBuilder.corn().getCropPubkey());

      assertTrue(nonMonEvents.length > 0);
      assertTrue(containsNonMonEvent("ZM_1111", nonMonEvents));
      for (NonMonEvent nonMonEvent : nonMonEvents) {
         assertTrue(nonMonEvent.isActiveStatus());
         if (nonMonEvent.getEventDescription().equals("ZM_1111") &&
            containsConstructName("CON_111", nonMonEvent)) {
            assertTrue(containsTraitType("TRTABB1", nonMonEvent));
            assertTrue(containsTraitName("TNABB1", nonMonEvent));
            assertTrue(containsProteinName("PROT NAME 1", nonMonEvent));
         }
         else if (nonMonEvent.getEventDescription().equals("ZM_1111") &&
            containsConstructName("CON_222", nonMonEvent)) {
            assertTrue(containsTraitType("TRTABB2", nonMonEvent));
            assertTrue(containsTraitName("TNABB2", nonMonEvent));
            assertTrue(containsProteinName("PROT NAME 2", nonMonEvent));
         }
         else if (nonMonEvent.getEventDescription().equals("ZM_1111")) {
            fail("Invalid Non-Mon Event found.");
         }
      }
   }

   @Test
 public void testFindByNonMonEventAndCrop_NonMonEventNotFoundForWrongCrop() {
      new NonMonEventBuilder().
         withEventDescription("ZM_1111").
         withCropPubkey(CropBuilder.soybeans().getCropPubkey()).
         withNonMonEventConstruct(
            new NonMonEventConstructBuilder().
               withConstructName("CON_111")
         ).
         withComlTraitType(
            new ComlTraitTypeBuilder().
               withTraitTypeAbbr("TRTABBR").
               withTraitTypeDesc("TRT TYPE DESC")
         ).
         withComlTraitName(
            new ComlTraitNameBuilder().
               withTraitAbbr("TNABBR").
               withTraitDesc("TRT NAME DESC")
         ).
         withProteinName(new ProteinNameBuilder().
            withProteinName("PROT NAME").
            withProteinNamePubkey("1234").
            withProteinDescription("PROT DESC").
            withOrigSourceOrganism("ORIG SOURCE ORG").create()).
         create();

      NonMonEvent[] nonMonEvents = nonMonEventDao.findByNonMonEventAndCrop("ZM_1111", CropBuilder.corn().getCropPubkey());

      assertEquals(0, nonMonEvents.length);
   }

   @Test
 public void testFindByNonMonEventAndCrop_NonMonEventNotFoundForWrongNonMonEvent() {
      new NonMonEventBuilder().
         withEventDescription("ZM_1111").
         withCropPubkey(CropBuilder.soybeans().getCropPubkey()).
         withNonMonEventConstruct(
            new NonMonEventConstructBuilder().
               withConstructName("CON_111")
         ).
         withComlTraitType(
            new ComlTraitTypeBuilder().
               withTraitTypeAbbr("TRTABBR").
               withTraitTypeDesc("TRT TYPE DESC")
         ).
         withComlTraitName(
            new ComlTraitNameBuilder().
               withTraitAbbr("TNABBR").
               withTraitDesc("TRT NAME DESC")
         ).
         withProteinName(new ProteinNameBuilder().
            withProteinName("PROT NAME").
            withProteinNamePubkey("1234").
            withProteinDescription("PROT DESC").
            withOrigSourceOrganism("ORIG SOURCE ORG").create()).
         create();

      NonMonEvent[] nonMonEvents = nonMonEventDao.findByNonMonEventAndCrop("QQ_1111", CropBuilder.soybeans().getCropPubkey());

      assertEquals(0, nonMonEvents.length);
   }

   @Test
 public void testFindByNonMonEventAndCrop_NoDataFound() {
      NonMonEvent[] nonMonEvents = nonMonEventDao.findByNonMonEventAndCrop("InvalidNonMonEvent", "InvalidCropPubkey");

      assertEquals(0, nonMonEvents.length);
   }

   @Test
 public void testFindAllNonMonEvents() {
      new NonMonEventBuilder().
         withEventDescription("ZM_1111").
         withMaterialName("MAT NAME").
         withCropPubkey(CropBuilder.soybeans().getCropPubkey()).
         withNonMonEventConstruct(
            new NonMonEventConstructBuilder().
               withConstructName("CON_111")
         ).
         withComlTraitType(
            new ComlTraitTypeBuilder().
               withTraitTypeAbbr("TRTABBR").
               withTraitTypeDesc("TRT TYPE DESC")
         ).
         withComlTraitName(
            new ComlTraitNameBuilder().
               withTraitAbbr("TNABBR").
               withTraitDesc("TRT NAME DESC")
         ).
         withProteinName(new ProteinNameBuilder().
            withProteinName("PROT NAME").
            withProteinNamePubkey("1234").
            withProteinDescription("PROT DESC").
            withOrigSourceOrganism("ORIG SOURCE ORG").create()).
         create();

      NonMonEvent[] nonMonEvents = nonMonEventDao.findAll();

      assertTrue(nonMonEvents.length > 0);
      NonMonEvent nonMonEvent = findMyNonMonEvent("ZM_1111", nonMonEvents);
      assertNotNull(nonMonEvent);
      assertEquals("1115", nonMonEvent.getCropPubkey());
      assertTrue(containsConstructName("CON_111", nonMonEvent));
      assertTrue(containsTraitType("TRTABBR", nonMonEvent));
      assertTrue(containsTraitName("TNABBR", nonMonEvent));
      assertTrue(containsProteinName("PROT NAME", nonMonEvent));
      assertEquals("MAT NAME", nonMonEvent.getMaterialName());
   }

   @Test
 public void testSaveNewNonMonEvent()
      throws Exception
   {
      NonMonEvent nonMonEvent = new NonMonEventBuilder().createObj();

      nonMonEventDao.save(nonMonEvent);

      NonMonEvent[] actualNonMonEvents = nonMonEventDao.findByNonMonEventAndCrop(nonMonEvent.getEventDescription(), nonMonEvent.getCropPubkey());
      NonMonEvent actualNonMonEvent = actualNonMonEvents[0];
      assertThat(actualNonMonEvent.getNonMonEventId(), is(nonMonEvent.getNonMonEventId()));
   }

   @Test
 public void testUpdateExistingNonMonEvent()
      throws Exception
   {
      NonMonEvent nonMonEvent = new NonMonEventBuilder().withCropPubkey(CropBuilder.corn().getCropPubkey()).create();
      nonMonEvent.setCropPubkey(CropBuilder.soybeans().getCropPubkey());
      nonMonEvent.setMaterialName("MAT NAME");

      nonMonEventDao.update(nonMonEvent);

      NonMonEvent[] actualNonMonEvents = nonMonEventDao.findByNonMonEventAndCrop(nonMonEvent.getEventDescription(), nonMonEvent.getCropPubkey());
      NonMonEvent actualNonMonEvent = actualNonMonEvents[0];
      assertThat(actualNonMonEvent.getNonMonEventId(), is(nonMonEvent.getNonMonEventId()));
      assertThat(actualNonMonEvent.getCropPubkey(), is(CropBuilder.soybeans().getCropPubkey()));
      assertThat(actualNonMonEvent.getMaterialName(), is("MAT NAME"));
   }

   private NonMonEvent findMyNonMonEvent(String eventDesc, NonMonEvent[] nonMonEvents) {
      for (NonMonEvent nonMonEvent : nonMonEvents) {
         if (eventDesc.equalsIgnoreCase(nonMonEvent.getEventDescription())) {
            return nonMonEvent;
         }
      }
      return null;
   }

   private boolean containsConstructName(String constructName, NonMonEvent nonMonEvent) {
      Collection<NonMonEventConstruct> nonMonEventConstructs = nonMonEvent.getNonMonEventConstructs();
      for (NonMonEventConstruct nonMonEventConstruct : nonMonEventConstructs) {
         if (constructName.equals(nonMonEventConstruct.getConstructName())) {
            return true;
         }
      }
      return false;
   }

   private boolean containsProteinName(String proteinNameValue, NonMonEvent nonMonEvent) {
      Collection<ProteinName> proteinNames = nonMonEvent.getProteinNames();
      for (ProteinName proteinName : proteinNames) {
         if (proteinNameValue.equals(proteinName.getProteinName())) {
            return true;
         }
      }
      return false;
   }

   private boolean containsTraitType(String traitTypeAbbr, NonMonEvent nonMonEvent) {
      Collection<ComlTraitType> traitTypes = nonMonEvent.getComlTraitTypes();
      for (ComlTraitType traitType : traitTypes) {
         if (traitTypeAbbr.equalsIgnoreCase(traitType.getComlTraitTypeAbbr())) {
            return true;
         }
      }
      return false;
   }

   private boolean containsTraitName(String traitAbbr, NonMonEvent nonMonEvent) {
      Collection<ComlTraitName> traitNames = nonMonEvent.getComlTraitNames();
      for (ComlTraitName traitName : traitNames) {
         if (traitAbbr.equalsIgnoreCase(traitName.getTraitAbbr())) {
            return true;
         }
      }
      return false;
   }

   private boolean containsNonMonEvent(String nonMonEventDescription, NonMonEvent[] nonMonEvents) {
      for (NonMonEvent nonMonEvent : nonMonEvents) {
         if (nonMonEventDescription.equals(nonMonEvent.getEventDescription())) {
            return true;
         }
      }
      return false;
   }
}
