package com.monsanto.tps.lexicon.regulatory.nonmonevent.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Crop;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName;

import java.util.Collection;
import java.util.Collections;

/**
 * nbwald - Jun 10, 2009 11:25:43 AM
 */
public class StubNonMonEventPersistQuerySet
   extends NonMonEventPersistQuerySet
{
   public StubNonMonEventPersistQuerySet() {
      super(null, null, null, null, null);
   }

   @Override
   public String[] findConstructsByEventAndCrop(String eventName, String cropName) {
      return new String[0];
   }

   @Override
   public Crop findCropByPubkey(String cropPubkey) {
      return new Crop();
   }

   @Override
   public Collection<ProteinName> findProteinNamesByPubkeys(String[] proteinNamePubkeys) {
      return Collections.emptyList();
   }

   @Override
   public Collection<ComlTraitName> findRegulatoryTraitNamesByAbbrs(String[] traitNameAbbrevations) {
      return Collections.emptyList();
   }

   @Override
   public Collection<ComlTraitType> findRegulatoryTraitTypesByAbbrs(String[] traitTypeAbbrevations) {
      return Collections.emptyList();
   }

   @Override
   public NonMonEvent findNonMonEventByEventAndCrop(String eventName, String cropPubkey) {
      return new NonMonEvent();
   }
}
