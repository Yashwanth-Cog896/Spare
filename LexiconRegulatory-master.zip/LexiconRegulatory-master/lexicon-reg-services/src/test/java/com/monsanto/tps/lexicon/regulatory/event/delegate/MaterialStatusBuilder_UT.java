package com.monsanto.tps.lexicon.regulatory.event.delegate;

import com.monsanto.tps.lexicon.event.AgencyMaterial;
import com.monsanto.tps.lexicon.event.AgencyMaterialDeregulationStatus;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Agency;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.AgencyMaterialType;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Country;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Crop;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MaterialChemicalName;
import org.apache.commons.lang.ArrayUtils;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * rrchak1 - Jun 23, 2009 3:15:06 PM
 */
public class MaterialStatusBuilder_UT {
    Crop crop;
    Country country;
    private String eventOne = "EVENT_ONE";
    private String cornCropName = "CORN";
    private String usaCountryName = "USA";
    private String usdaAgencyAbbr = "USDA";
    private String epaAgencyAbbr = "EPA";
    private String eventTwo = "EVENT_TWO";

    @Before
    public void before() {
        crop = new Crop();
        crop.setCropName(cornCropName);
        country = new Country();
        country.setCountryName(usaCountryName);
    }

    @Test
    public void build_ReturnsEventDeregulationStatus_ForSingle_EventAgencyAlignment() {
        EventAgencyAlignment eventAgencyAlignment = new EventAgencyAlignment();
        eventAgencyAlignment.setMaterialName(eventOne);
        eventAgencyAlignment.setCrop(crop);
        Agency agency = new Agency();
        agency.setAgencyAbbr(usdaAgencyAbbr);
        agency.setCountry(country);
        eventAgencyAlignment.setAgency(agency);
        MaterialStatusBuilder builder = new MaterialStatusBuilder();
        List<AgencyMaterialDeregulationStatus> response = builder.build(new EventAgencyAlignment[]{eventAgencyAlignment}, crop.getCropName());
        assertFalse(response.isEmpty());
        assertEquals(1, response.size());
        AgencyMaterialDeregulationStatus eventDeregulationStatus = response.get(0);
        assertNotNull(eventDeregulationStatus);
        assertEquals(eventOne, eventDeregulationStatus.getEventName());
        assertEquals(cornCropName, eventDeregulationStatus.getCrop());
        AgencyMaterial[] agencies = eventDeregulationStatus.getAgencyMaterials();
        assertFalse(ArrayUtils.isEmpty(agencies));
        assertEquals(1, agencies.length);
        AgencyMaterial eventAgency = agencies[0];
        assertEquals(usaCountryName, eventAgency.getCountryName());
        assertEquals(usdaAgencyAbbr, eventAgency.getAgencyAbbr());
    }


    @Test
    public void build_ReturnsEventDeregulationStatus_ForSingle_EventAgencyAlignmentWithChemicalName() {
        EventAgencyAlignment eventAgencyAlignment = new EventAgencyAlignment();
        //eventAgencyAlignment.setMaterialName(eventOne);
        eventAgencyAlignment.setCrop(crop);
        Agency agency = new Agency();
        agency.setAgencyAbbr(usdaAgencyAbbr);
        agency.setCountry(country);
        eventAgencyAlignment.setAgency(agency);
        MaterialChemicalName name = new MaterialChemicalName();
        name.setChemicalName("chemName");
        eventAgencyAlignment.setMaterialChemicalName(name);
        AgencyMaterialType type = new AgencyMaterialType();
        type.setMaterialTypeDesc("desc");
        eventAgencyAlignment.setAgencyMaterialType(type);
        MaterialStatusBuilder builder = new MaterialStatusBuilder();
        List<AgencyMaterialDeregulationStatus> response = builder.build(new EventAgencyAlignment[]{eventAgencyAlignment}, crop.getCropName());
        assertFalse(response.isEmpty());
        assertEquals(1, response.size());
        AgencyMaterialDeregulationStatus eventDeregulationStatus = response.get(0);
        assertNotNull(eventDeregulationStatus);
        assertEquals("chemName", eventDeregulationStatus.getEventName());
        assertEquals(cornCropName, eventDeregulationStatus.getCrop());
        AgencyMaterial[] agencies = eventDeregulationStatus.getAgencyMaterials();
        assertFalse(ArrayUtils.isEmpty(agencies));
        assertEquals(1, agencies.length);
        AgencyMaterial eventAgency = agencies[0];
        assertEquals(usaCountryName, eventAgency.getCountryName());
        assertEquals(usdaAgencyAbbr, eventAgency.getAgencyAbbr());
        assertEquals("desc", eventAgency.getAgencyMaterialType());
    }

    @Test
    public void build_ReturnsEventDeregulationStatus_ForSingle_EventAgencyAlignmentWithNoMaterialName() {
        EventAgencyAlignment eventAgencyAlignment = new EventAgencyAlignment();
        //eventAgencyAlignment.setMaterialName(eventOne);
        eventAgencyAlignment.setCrop(crop);
        Agency agency = new Agency();
        agency.setAgencyAbbr(usdaAgencyAbbr);
        agency.setCountry(country);
        eventAgencyAlignment.setAgency(agency);
        MaterialChemicalName name = new MaterialChemicalName();
        name.setChemicalName("chemName");
        eventAgencyAlignment.setMaterialChemicalName(name);
        AgencyMaterialType type = new AgencyMaterialType();
        type.setMaterialTypeDesc("desc");
        eventAgencyAlignment.setAgencyMaterialType(type);
        MaterialStatusBuilder builder = new MaterialStatusBuilder();
        List<AgencyMaterialDeregulationStatus> response = builder.build(new EventAgencyAlignment[]{eventAgencyAlignment}, crop.getCropName());
        assertFalse(response.isEmpty());
        assertEquals(1, response.size());
        AgencyMaterialDeregulationStatus eventDeregulationStatus = response.get(0);
        assertNotNull(eventDeregulationStatus);
        assertEquals("chemName", eventDeregulationStatus.getEventName());
        assertEquals(cornCropName, eventDeregulationStatus.getCrop());
        AgencyMaterial[] agencies = eventDeregulationStatus.getAgencyMaterials();
        assertFalse(ArrayUtils.isEmpty(agencies));
        assertEquals(1, agencies.length);
        AgencyMaterial eventAgency = agencies[0];
        assertEquals(usaCountryName, eventAgency.getCountryName());
        assertEquals(usdaAgencyAbbr, eventAgency.getAgencyAbbr());
        assertEquals("desc", eventAgency.getAgencyMaterialType());
    }

    @Test
    public void build_ReturnsEventDeregulationStatus_OneEventAssociatedWithMultipleAgencies() {
        Agency usdaAgency = new Agency();
        usdaAgency.setAgencyAbbr(usdaAgencyAbbr);
        usdaAgency.setCountry(country);

        Agency epaAgency = new Agency();
        epaAgency.setAgencyAbbr(epaAgencyAbbr);
        epaAgency.setCountry(country);

        EventAgencyAlignment alignmentOne = new EventAgencyAlignment();
        alignmentOne.setCrop(crop);
        alignmentOne.setMaterialName(eventOne);
        alignmentOne.setAgency(usdaAgency);

        EventAgencyAlignment alignmentTwo = new EventAgencyAlignment();
        alignmentTwo.setCrop(crop);
        alignmentTwo.setMaterialName(eventOne);
        alignmentTwo.setAgency(epaAgency);


        MaterialStatusBuilder builder = new MaterialStatusBuilder();
        List<AgencyMaterialDeregulationStatus> response = builder.build(new EventAgencyAlignment[]{alignmentOne, alignmentTwo}, crop.getCropName());
        assertFalse(response.isEmpty());
        assertEquals(1, response.size());
        AgencyMaterialDeregulationStatus eventDeregulationStatus = response.get(0);
        assertNotNull(eventDeregulationStatus);
        assertEquals(eventOne, eventDeregulationStatus.getEventName());
        assertEquals(cornCropName, eventDeregulationStatus.getCrop());
        AgencyMaterial[] agencies = eventDeregulationStatus.getAgencyMaterials();
        assertFalse(ArrayUtils.isEmpty(agencies));
        assertEquals(2, agencies.length);
        assertTrue(hasAgency(usdaAgencyAbbr, agencies));
        assertTrue(hasAgency(epaAgencyAbbr, agencies));
    }

    @Test
    public void build_ReturnsEventDeregulationStatus_MultipleEventsAssociatedWithOneAgency() {

        Agency usdaAgency = new Agency();
        usdaAgency.setAgencyAbbr(usdaAgencyAbbr);
        usdaAgency.setCountry(country);

        EventAgencyAlignment alignmentOne = new EventAgencyAlignment();
        alignmentOne.setCrop(crop);
        alignmentOne.setMaterialName(eventOne);
        alignmentOne.setAgency(usdaAgency);

        EventAgencyAlignment alignmentTwo = new EventAgencyAlignment();
        alignmentTwo.setCrop(crop);
        alignmentTwo.setMaterialName(eventTwo);
        alignmentTwo.setAgency(usdaAgency);


        MaterialStatusBuilder builder = new MaterialStatusBuilder();
        List<AgencyMaterialDeregulationStatus> response = builder.build(new EventAgencyAlignment[]{alignmentOne, alignmentTwo}, crop.getCropName());
        assertFalse(response.isEmpty());
        assertEquals(2, response.size());
        AgencyMaterialDeregulationStatus eventDeregulationStatus = response.get(0);
        assertNotNull(eventDeregulationStatus);
        assertEquals(eventOne, eventDeregulationStatus.getEventName());
        assertEquals(cornCropName, eventDeregulationStatus.getCrop());
        AgencyMaterial[] agencies = eventDeregulationStatus.getAgencyMaterials();
        assertFalse(ArrayUtils.isEmpty(agencies));
        assertEquals(1, agencies.length);
        assertTrue(hasAgency(usdaAgencyAbbr, agencies));

        AgencyMaterialDeregulationStatus deregulationStatus = response.get(1);
        assertNotNull(deregulationStatus);
        assertEquals(eventTwo, deregulationStatus.getEventName());
        assertEquals(cornCropName, deregulationStatus.getCrop());
        AgencyMaterial[] eventAgencies = eventDeregulationStatus.getAgencyMaterials();
        assertFalse(ArrayUtils.isEmpty(eventAgencies));
        assertEquals(1, eventAgencies.length);
        assertTrue(hasAgency(usdaAgencyAbbr, eventAgencies));

    }

    @Test
    public void build_ReturnsEventDeregulationStatus_MultipleEventsAssociatedWithMultipleAgencies() {


        Agency usdaAgency = new Agency();
        usdaAgency.setAgencyAbbr(usdaAgencyAbbr);
        usdaAgency.setCountry(country);

        Agency epaAgency = new Agency();
        epaAgency.setAgencyAbbr(epaAgencyAbbr);
        epaAgency.setCountry(country);

        EventAgencyAlignment eventOneUsdaAlignment = new EventAgencyAlignment();
        eventOneUsdaAlignment.setCrop(crop);
        eventOneUsdaAlignment.setMaterialName(eventOne);
        eventOneUsdaAlignment.setAgency(usdaAgency);

        EventAgencyAlignment eventOneEpaAlignment = new EventAgencyAlignment();
        eventOneEpaAlignment.setCrop(crop);
        eventOneEpaAlignment.setMaterialName(eventOne);
        eventOneEpaAlignment.setAgency(epaAgency);

        EventAgencyAlignment eventTwoUsdaAlignment = new EventAgencyAlignment();
        eventTwoUsdaAlignment.setCrop(crop);
        eventTwoUsdaAlignment.setMaterialName(eventTwo);
        eventTwoUsdaAlignment.setAgency(usdaAgency);

        EventAgencyAlignment eventTwoEpaAlignment = new EventAgencyAlignment();
        eventTwoEpaAlignment.setCrop(crop);
        eventTwoEpaAlignment.setMaterialName(eventTwo);
        eventTwoEpaAlignment.setAgency(epaAgency);


        MaterialStatusBuilder builder = new MaterialStatusBuilder();
        List<AgencyMaterialDeregulationStatus> response = builder.build(new EventAgencyAlignment[]{eventOneUsdaAlignment,
                eventOneEpaAlignment, eventTwoUsdaAlignment, eventTwoEpaAlignment}, crop.getCropName());
        assertFalse(response.isEmpty());
        assertEquals(2, response.size());
        AgencyMaterialDeregulationStatus eventDeregulationStatus = response.get(0);
        assertNotNull(eventDeregulationStatus);
        assertEquals(eventOne, eventDeregulationStatus.getEventName());
        assertEquals(cornCropName, eventDeregulationStatus.getCrop());
        AgencyMaterial[] agencies = eventDeregulationStatus.getAgencyMaterials();
        assertFalse(ArrayUtils.isEmpty(agencies));
        assertEquals(2, agencies.length);
        assertTrue(hasAgency(usdaAgencyAbbr, agencies));
        assertTrue(hasAgency(epaAgencyAbbr, agencies));

        AgencyMaterialDeregulationStatus deregulationStatus = response.get(1);
        assertNotNull(deregulationStatus);
        assertEquals(eventTwo, deregulationStatus.getEventName());
        assertEquals(cornCropName, deregulationStatus.getCrop());
        AgencyMaterial[] eventAgencies = deregulationStatus.getAgencyMaterials();
        assertFalse(ArrayUtils.isEmpty(eventAgencies));
        assertEquals(2, eventAgencies.length);
        assertTrue(hasAgency(usdaAgencyAbbr, eventAgencies));
        assertTrue(hasAgency(epaAgencyAbbr, eventAgencies));

    }

    private boolean hasAgency(String agencyAbbr, AgencyMaterial[] agencies) {
        for (AgencyMaterial agency : agencies) {
            if (agencyAbbr.equalsIgnoreCase(agency.getAgencyAbbr())) {
                return true;
            }
        }
        return false;
    }
}
