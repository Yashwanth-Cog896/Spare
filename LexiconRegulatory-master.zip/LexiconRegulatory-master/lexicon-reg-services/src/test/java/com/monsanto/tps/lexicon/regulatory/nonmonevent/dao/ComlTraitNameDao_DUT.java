package com.monsanto.tps.lexicon.regulatory.nonmonevent.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.ComlTraitNameBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.LexiconDataUnitTestCase;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName;
import org.junit.Test;

import javax.annotation.Resource;

import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.util.Collection;

/**
 * nbwald - May 22, 2009 12:24:03 PM
 */
public class ComlTraitNameDao_DUT
   extends LexiconDataUnitTestCase
{
   @Resource
   private ComlTraitNameDao comlTraitNameDao;


   @Test
 public void testFindByAbbrs_NoResults()
      throws Exception
   {
      Collection<ComlTraitName> traitNames = comlTraitNameDao.findByAbbrs("not existent", "also not existent");

      assertThat(traitNames.isEmpty(), is(true));
   }

   @Test
 public void testFindByAbbrs_NoAbbrs_NoResults()
      throws Exception
   {
      Collection<ComlTraitName> traitNames = comlTraitNameDao.findByAbbrs();

      assertThat(traitNames.isEmpty(), is(true));
   }

   @Test
 public void testFindByAbbrs_MultipleResults()
      throws Exception
   {
      ComlTraitName comlTraitNameA = new ComlTraitNameBuilder().create();
      ComlTraitName comlTraitNameB = new ComlTraitNameBuilder().create();

      Collection<ComlTraitName> traitNames = comlTraitNameDao.findByAbbrs(comlTraitNameA.getTraitAbbr(), comlTraitNameB.getTraitAbbr());

      assertThat(traitNames.size(), is(2));
      assertThat(hasTraitName(traitNames, comlTraitNameA), is(true));
      assertThat(hasTraitName(traitNames, comlTraitNameB), is(true));
   }

   private boolean hasTraitName(Collection<ComlTraitName> traitNames, ComlTraitName targetTraitName) {
      for (ComlTraitName traitName : traitNames) {
         if (targetTraitName.getComlTraitNameId() == traitName.getComlTraitNameId() &&
            targetTraitName.getTraitAbbr().equals(traitName.getTraitAbbr()) &&
            targetTraitName.getTraitDesc().equals(traitName.getTraitDesc())) {
            return true;
         }
      }
      return false;
   }
}