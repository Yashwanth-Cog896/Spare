package com.monsanto.tps.lexicon.regulatory.util;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/5/12
 * Time: 7:30 PM
 * To change this template use File | Settings | File Templates.
 */
public class WildcardUtil_UT {

    @Test
    public void testReplaceEmptyStringWithWildcard_emptyString() {
        assertEquals("%", WildcardUtil.replaceEmptyStringWithWildcard(""));
    }

    @Test
    public void testReplaceEmptyStringWithWildcard_null() {
        assertEquals("%", WildcardUtil.replaceEmptyStringWithWildcard(null));
    }

    @Test
    public void testReplaceEmptyStringWithWildcard_notEmpty() {
        assertEquals("asdf", WildcardUtil.replaceEmptyStringWithWildcard("asdf"));
    }

}
