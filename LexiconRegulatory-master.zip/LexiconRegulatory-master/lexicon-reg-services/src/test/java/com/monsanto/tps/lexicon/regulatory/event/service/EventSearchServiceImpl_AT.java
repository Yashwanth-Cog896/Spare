package com.monsanto.tps.lexicon.regulatory.event.service;

import com.monsanto.tcc.lexiconcommon.db.test.MidasTestTools;
import com.monsanto.tps.lexicon.event.Construct;
import com.monsanto.tps.lexicon.event.EventAgency;
import com.monsanto.tps.lexicon.event.EventComponent;
import com.monsanto.tps.lexicon.event.EventDeregulationStatus;
import com.monsanto.tps.lexicon.event.EventInfo;
import com.monsanto.tps.lexicon.event.EventSearchService;
import com.monsanto.tps.lexicon.event.EventDeregulationStatusWithMonNumber;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.AgencyBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.CropBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.EventAgencyAlignmentBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.LexiconAcceptanceTestCase;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.MonNumberBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Agency;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber;
import com.monsanto.tps.lexicon.regulatory.DB.TestUtil.TPSTestConstants;
import com.monsanto.tps.lexicon.regulatory.DB.Tests.EventBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Tests.LexiconDataServiceATTestCase;
import junit.framework.AssertionFailedError;
import org.apache.commons.lang.ArrayUtils;
import org.junit.After;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

import static org.junit.Assert.*;

/**
 * rrchak1 - Dec 22, 2008 10:49:47 AM
 */
@Transactional
public class EventSearchServiceImpl_AT extends LexiconAcceptanceTestCase {

   @Resource
   private EventSearchService eventSearchService;
   private EventBuilder eventBuilder = new EventBuilder();
   private static final String EVENT = "AT_EVENTNAME";
   private static final String EVENT_MIXED_CASE = "AT_eVeNtNaMe";
   private static final String CANOLA = "OSR-Canola";
   private static final String CANOLA_MIXED_CASE = "osr-caNola";
   private static final String EVENT_TWO = "AT_EVENT_TWO";

    @Ignore @Test
   public void testFindByEventAndCrop_GivenEventNameAndCropReturnsEventDetailsWithMonNumberWithAgencyAlignment()
      throws Exception
   {
      eventBuilder.setupConnections();
      eventBuilder.insertEvent(EVENT);
      MonNumber monNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().withMonNumber("MON_1111XX").withEventName(EVENT).withCrop(CropBuilder.canola()).createInDb();
         }
      });

      EventAgencyAlignment eventAgencyAlignment = insert(new AcceptanceTestData<EventAgencyAlignment>()
      {
         public EventAgencyAlignment dataToInsert() {
            return new EventAgencyAlignmentBuilder().
               withEvent(EVENT).
               withAgency(AgencyBuilder.epa()).
               regulated().
               withMaxQuantity(10).
               withCrop(CropBuilder.canola()).
               create();
         }
      });

      EventInfo eventInfo = eventSearchService.findByEventAndCrop(EVENT, CANOLA);

      assertNotNull(eventInfo);
      assertEquals(CANOLA, eventInfo.getCrop());
      assertFalse(ArrayUtils.isEmpty(eventInfo.getEventComponents()));
      EventComponent[] eventComponents = eventInfo.getEventComponents();
      EventComponent eventComponent = eventComponents[0];
      assertEquals(EVENT, eventComponent.getEventName());
      Construct[] constructs = eventComponent.getConstructs();
      assertNotNull(constructs);
      assertEquals(1, constructs.length);
      Construct construct = constructs[0];
      assertEquals(TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_FCM_PVCODE, construct.getPlasmidPMon());
      assertEquals(TPSTestConstants.PV_CODE_FOR_EVENT_SINGLE_PMON_CONSTRUCT, construct.getPlasmidPVCode());
      assertEquals(monNumber.getMonNumber(), eventComponent.getMonNumber());
      assertFalse(ArrayUtils.isEmpty(eventInfo.getEventAgencies()));
      assertEquals(1, eventInfo.getEventAgencies().length);
      EventAgency actual = eventInfo.getEventAgencies()[0];
      assertEquals(eventAgencyAlignment.getEventAgencyAlignmentPubkey(), actual.getPublicKey());
      assertEquals("United States of America", actual.getCountryName());
      assertEquals("EPA", actual.getAgencyAbbr());
      assertTrue(actual.isRegulated());
      assertEquals(eventAgencyAlignment.getDeregulatedEffectiveDate(), actual.getDeregulatedEffectiveDate());
      assertEquals(eventAgencyAlignment.getAgency().getSurfaceAreaUomCode(), actual.getSurfaceAreaUomCode());
      assertEquals((Double)10D, actual.getMaxQuantity());
      eventBuilder.tearDownConnections();
   }

   @Ignore @Test
   public void testFindByEventAndCrop_GivenEventNameAndCropReturnsEventDetailsWithoutMonNumber_AndWithoutAgencyAlignment()
      throws Exception
   {
      eventBuilder.setupConnections();
      eventBuilder.insertEvent(EVENT);

      EventInfo eventInfo = eventSearchService.findByEventAndCrop(EVENT, CANOLA);

      assertNotNull(eventInfo);
      assertEquals(CANOLA, eventInfo.getCrop());
      assertFalse(ArrayUtils.isEmpty(eventInfo.getEventComponents()));
      EventComponent[] eventComponents = eventInfo.getEventComponents();
      EventComponent eventComponent = eventComponents[0];
      assertEquals(EVENT, eventComponent.getEventName());
      assertNull(eventComponent.getMonNumber());
      Construct[] constructs = eventComponent.getConstructs();
      assertNotNull(constructs);
      assertEquals(1, constructs.length);
      Construct construct = constructs[0];
      assertEquals(TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_FCM_PVCODE, construct.getPlasmidPMon());
      assertEquals(TPSTestConstants.PV_CODE_FOR_EVENT_SINGLE_PMON_CONSTRUCT, construct.getPlasmidPVCode());
      assertEquals(0, eventInfo.getEventAgencies().length);
      eventBuilder.tearDownConnections();
   }

   @Ignore @Test
   public void testFindByEventAndCrop_MonNumberExistsWithDifferentCrop_ReturnsNoMonNumberDetails()
      throws Exception
   {
      eventBuilder.setupConnections();
      eventBuilder.insertEvent(EVENT);
      insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName(EVENT).
               withCrop(CropBuilder.soybeans()).
               createInDb();
         }
      });

      EventInfo eventInfo = eventSearchService.findByEventAndCrop(EVENT, CANOLA);

      assertNotNull(eventInfo);
      assertEquals(CANOLA, eventInfo.getCrop());
      assertFalse(ArrayUtils.isEmpty(eventInfo.getEventComponents()));
      EventComponent[] eventComponents = eventInfo.getEventComponents();
      EventComponent eventComponent = eventComponents[0];
      assertEquals(EVENT, eventComponent.getEventName());
      assertNull(eventComponent.getMonNumber());
      eventBuilder.tearDownConnections();
   }

   @Ignore @Test
   public void testFindByEventAndCrop_EventExists_WithMixedCase_FindsIt()
      throws Exception
   {
      eventBuilder.setupConnections();
      eventBuilder.insertEvent(EVENT_MIXED_CASE);

      EventInfo eventInfo = eventSearchService.findByEventAndCrop(EVENT, CANOLA);

      assertEquals(CANOLA, eventInfo.getCrop());
      assertFalse(ArrayUtils.isEmpty(eventInfo.getEventComponents()));
      EventComponent[] eventComponents = eventInfo.getEventComponents();
      EventComponent eventComponent = eventComponents[0];
      assertNull(eventComponent.getMonNumber());
      assertEquals(EVENT_MIXED_CASE, eventComponent.getEventName());
      Construct[] constructs = eventComponent.getConstructs();
      assertNotNull(constructs);
      assertEquals(1, constructs.length);
      Construct construct = constructs[0];
      assertEquals(TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_FCM_PVCODE, construct.getPlasmidPMon());
      assertEquals(TPSTestConstants.PV_CODE_FOR_EVENT_SINGLE_PMON_CONSTRUCT, construct.getPlasmidPVCode());
      assertEquals(0, eventInfo.getEventAgencies().length);
      eventBuilder.tearDownConnections();
   }

   @Ignore @Test
   public void testFindByEventAndCrop_EventExists_SearchedByMixedCase_FindsIt()
      throws Exception
   {
      eventBuilder.setupConnections();
      eventBuilder.insertEvent(EVENT);

      EventInfo eventInfo = eventSearchService.findByEventAndCrop(EVENT_MIXED_CASE, CANOLA_MIXED_CASE);

      assertEquals(CANOLA_MIXED_CASE, eventInfo.getCrop());
      assertFalse(ArrayUtils.isEmpty(eventInfo.getEventComponents()));
      EventComponent[] eventComponents = eventInfo.getEventComponents();
      EventComponent eventComponent = eventComponents[0];
      assertNull(eventComponent.getMonNumber());
      Construct[] constructs = eventComponent.getConstructs();
      assertEquals(EVENT, eventComponent.getEventName());
      assertNotNull(constructs);
      assertEquals(1, constructs.length);
      Construct construct = constructs[0];
      assertEquals(TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_FCM_PVCODE, construct.getPlasmidPMon());
      assertEquals(TPSTestConstants.PV_CODE_FOR_EVENT_SINGLE_PMON_CONSTRUCT, construct.getPlasmidPVCode());
      assertEquals(0, eventInfo.getEventAgencies().length);
      eventBuilder.tearDownConnections();
   }

   @Ignore @Test
   public void testFindByEventAndCrop_FindsNonR0Events()
      throws Exception
   {
      eventBuilder.setupConnections();
      eventBuilder.insertEventConstruct(EVENT, TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_FCM_PVCODE, TPSTestConstants.MIDAS_CANOLA_ID, TPSTestConstants.EVENT_CONSTRUCT_ID_ONE);

      EventInfo eventInfo = eventSearchService.findByEventAndCrop(EVENT, CANOLA);

      assertNotNull(eventInfo);
      assertEquals(CANOLA, eventInfo.getCrop());
      EventComponent[] eventComponents = eventInfo.getEventComponents();
      EventComponent eventComponent = eventComponents[0];
      assertEquals(EVENT, eventComponent.getEventName());
      assertNull(eventComponent.getMonNumber());
      Construct[] constructs = eventComponent.getConstructs();
      assertNotNull(constructs);
      assertEquals(1, constructs.length);
      Construct construct = constructs[0];
      assertEquals(TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_FCM_PVCODE, construct.getPlasmidPMon());
      assertNotNull(construct.getPlasmidPVCode());
      assertEquals(0, eventInfo.getEventAgencies().length);
      eventBuilder.tearDownConnections();
   }

   @Ignore @Test
   public void testFindByEventsAndCrop_GivenEventNamesAndCropReturnsEventDetailsWithoutMonNumber_AndWithoutAgencyAlignment()
      throws Exception
   {
      eventBuilder.setupConnections();
      eventBuilder.insertEvent(EVENT);

      EventInfo[] eventInfos = eventSearchService.findByEventsAndCrop(new String[]{EVENT}, CANOLA);

      assertNotNull(eventInfos);
      assertEquals(1, eventInfos.length);
      EventInfo eventInfo = eventInfos[0];
      assertEquals(CANOLA, eventInfo.getCrop());
      EventComponent[] eventComponents = eventInfo.getEventComponents();
      EventComponent eventComponent = eventComponents[0];
      assertEquals(EVENT, eventComponent.getEventName());
      assertNull(eventComponent.getMonNumber());
      Construct[] constructs = eventComponent.getConstructs();
      assertNotNull(constructs);
      assertEquals(1, constructs.length);
      Construct construct = constructs[0];
      assertEquals(TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_FCM_PVCODE, construct.getPlasmidPMon());
      assertEquals(TPSTestConstants.PV_CODE_FOR_EVENT_SINGLE_PMON_CONSTRUCT, construct.getPlasmidPVCode());
      assertEquals(0, eventInfo.getEventAgencies().length);
      eventBuilder.tearDownConnections();
   }

   @Ignore @Test
   public void testFindByMonNumber_MonNumberExists_EventExists_AlignmentExists()
      throws Exception
   {
      eventBuilder.setupConnections();
      eventBuilder.insertEvent(EVENT);
      MonNumber monNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName(EVENT).
               withCrop(CropBuilder.canola()).createInDb();
         }
      });

      EventAgencyAlignment eventAgencyAlignment = insert(new AcceptanceTestData<EventAgencyAlignment>()
      {
         public EventAgencyAlignment dataToInsert() {
            return new EventAgencyAlignmentBuilder().
               withEvent(EVENT).
               withAgency(AgencyBuilder.epa()).
               withCrop(CropBuilder.canola()).
               regulated().
               withMaxQuantity(10.5).
               create();
         }
      });

      EventInfo eventInfo = eventSearchService.findByMonNumber("MON_1111");

      assertNotNull(eventInfo);
      EventComponent[] eventComponents = eventInfo.getEventComponents();
      EventComponent eventComponent = eventComponents[0];
      assertEquals(EVENT, eventComponent.getEventName());
      assertEquals(monNumber.getCrop().getCropName(), eventInfo.getCrop());
      assertEquals(monNumber.getMonNumber(), eventComponent.getMonNumber());
      Construct[] constructs = eventComponent.getConstructs();
      assertNotNull(constructs);
      assertEquals(1, constructs.length);
      Construct construct = constructs[0];
      assertEquals(TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_FCM_PVCODE, construct.getPlasmidPMon());
      assertEquals(TPSTestConstants.PV_CODE_FOR_EVENT_SINGLE_PMON_CONSTRUCT, construct.getPlasmidPVCode());

      assertEquals(1, eventInfo.getEventAgencies().length);
      EventAgency actual = eventInfo.getEventAgencies()[0];
      assertEquals(eventAgencyAlignment.getEventAgencyAlignmentPubkey(), actual.getPublicKey());
      assertEquals("United States of America", actual.getCountryName());
      assertEquals("EPA", actual.getAgencyAbbr());
      assertTrue(actual.isRegulated());
      assertEquals(eventAgencyAlignment.getDeregulatedEffectiveDate(), actual.getDeregulatedEffectiveDate());
      assertEquals(eventAgencyAlignment.getAgency().getSurfaceAreaUomCode(), actual.getSurfaceAreaUomCode());
      assertEquals((Double)10.5, actual.getMaxQuantity());
      eventBuilder.tearDownConnections();
   }

   @Ignore @Test
   public void testFindByMonNumber_MonNumberDoesNotExist_ReturnsNull()
      throws Exception
   {
      eventBuilder.setupConnections();
      eventBuilder.insertEvent(EVENT);

      EventInfo eventInfo = eventSearchService.findByMonNumber("MON_1111");

      assertNull(eventInfo);
      eventBuilder.tearDownConnections();
   }

   @Ignore @Test
   public void testFindByMonNumber_MonNumberExists_ButNotEvent_ReturnsNull()
      throws Exception
   {
      final String invalidEventName = "DUMMY";

      eventBuilder.setupConnections();
      insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1117").
               withEventName(invalidEventName).createInDb();
         }
      });

      EventInfo eventInfo = eventSearchService.findByMonNumber("MON_1117");

      assertNull(eventInfo);
      eventBuilder.tearDownConnections();
   }

   @Ignore @Test
   public void testFindByMonNumber_MonNumberExists_EventExistsWithDifferentCrop_ReturnsNull()
      throws Exception
   {
      eventBuilder.setupConnections();
      eventBuilder.insertEvent(EVENT);
      insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName(EVENT).
               withCrop(CropBuilder.soybeans()).
               createInDb();
         }
      });

      EventInfo eventInfo = eventSearchService.findByMonNumber("MON_1111");

      assertNull(eventInfo);
      eventBuilder.tearDownConnections();
   }

   @Ignore @Test
   public void testFindByMonNumber_FindsNonR0Events()
      throws Exception
   {
      eventBuilder.setupConnections();
      eventBuilder.insertEventConstruct(EVENT, TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_FCM_PVCODE, TPSTestConstants.MIDAS_CANOLA_ID, TPSTestConstants.EVENT_CONSTRUCT_ID_ONE);
      MonNumber monNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName(EVENT).
               withCrop(CropBuilder.canola()).createInDb();
         }
      });

      EventInfo eventInfo = eventSearchService.findByMonNumber("MON_1111");

      assertNotNull(eventInfo);
      EventComponent[] eventComponents = eventInfo.getEventComponents();
      EventComponent eventComponent = eventComponents[0];
      assertEquals(EVENT, eventComponent.getEventName());
      assertEquals(monNumber.getCrop().getCropName(), eventInfo.getCrop());
      assertEquals(monNumber.getMonNumber(), eventComponent.getMonNumber());
      Construct[] constructs = eventComponent.getConstructs();
      assertNotNull(constructs);
      assertEquals(1, constructs.length);
      Construct construct = constructs[0];
      assertEquals(TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_FCM_PVCODE, construct.getPlasmidPMon());
      assertNotNull(construct.getPlasmidPVCode());
      assertEquals(0, eventInfo.getEventAgencies().length);
      eventBuilder.tearDownConnections();
   }

   @Ignore @Test
   public void testFindByMonNumber_WithMixedCase_FindsIt()
      throws Exception
   {
      eventBuilder.setupConnections();
      eventBuilder.insertEventConstruct(EVENT_MIXED_CASE, TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_FCM_PVCODE, TPSTestConstants.MIDAS_CANOLA_ID, TPSTestConstants.EVENT_CONSTRUCT_ID_ONE);
      MonNumber monNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName(EVENT).withCrop(CropBuilder.canola()).createInDb();
         }
      });

      EventInfo eventInfo = eventSearchService.findByMonNumber("mon_1111");

      assertNotNull(eventInfo);
      EventComponent[] eventComponents = eventInfo.getEventComponents();
      EventComponent eventComponent = eventComponents[0];
      assertEquals(EVENT, eventComponent.getEventName());
      assertEquals(monNumber.getCrop().getCropName(), eventInfo.getCrop());
      assertEquals(monNumber.getMonNumber(), eventComponent.getMonNumber());
      Construct[] constructs = eventComponent.getConstructs();
      assertNotNull(constructs);
      assertEquals(1, constructs.length);
      Construct construct = constructs[0];
      assertEquals(TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_FCM_PVCODE, construct.getPlasmidPMon());
      assertNotNull(construct.getPlasmidPVCode());
      assertEquals(0, eventInfo.getEventAgencies().length);
      eventBuilder.tearDownConnections();
   }

   @Ignore @Test
   public void testFindByMonNumbers_MonNumberExists_EventExists()
      throws Exception
   {
      eventBuilder.setupConnections();
      eventBuilder.insertEvent(EVENT);
      MonNumber monNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName(EVENT).withCrop(CropBuilder.canola()).createInDb();
         }
      });

      EventInfo[] eventInfos = eventSearchService.findByMonNumbers(new String[]{"MON_1111"});

      assertEquals(1, eventInfos.length);
      EventInfo eventInfo = eventInfos[0];
      assertNotNull(eventInfo);
      EventComponent[] eventComponents = eventInfo.getEventComponents();
      EventComponent eventComponent = eventComponents[0];
      assertEquals(EVENT, eventComponent.getEventName());
      assertEquals(monNumber.getMonNumber(), eventComponent.getMonNumber());
      Construct[] constructs = eventComponent.getConstructs();
      assertNotNull(constructs);
      assertEquals(1, constructs.length);
      Construct construct = constructs[0];
      assertEquals(TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_FCM_PVCODE, construct.getPlasmidPMon());
      assertEquals(TPSTestConstants.PV_CODE_FOR_EVENT_SINGLE_PMON_CONSTRUCT, construct.getPlasmidPVCode());
      assertEquals(monNumber.getCrop().getCropName(), eventInfo.getCrop());
      eventBuilder.tearDownConnections();
   }

   @Ignore @Test
   public void testFindByAlignmentPubkeys_ReturnsEventInfoWithMonNumberAndAlignments()
      throws Exception
   {
      eventBuilder.setupConnections();
      eventBuilder.insertEvent(EVENT);
      MonNumber monNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withCrop(CropBuilder.canola()).
               withEventName(EVENT).createInDb();
         }
      });

      EventAgencyAlignment eventAgencyAlignment = insert(new AcceptanceTestData<EventAgencyAlignment>()
      {
         public EventAgencyAlignment dataToInsert() {
            return new EventAgencyAlignmentBuilder().
               withEvent(EVENT).
               withAgency(AgencyBuilder.epa()).
               regulated().
               withMaxQuantity(10.5).
               withCrop(CropBuilder.canola()).
               create();
         }
      });


      EventInfo[] eventInfos = eventSearchService.findByEventAgencyAlignmentPubkey(new String[]{eventAgencyAlignment.getEventAgencyAlignmentPubkey()});

      assertEquals(1, eventInfos.length);
      EventInfo eventInfo = eventInfos[0];
      assertNotNull(eventInfo);
      EventComponent[] eventComponents = eventInfo.getEventComponents();
      EventComponent eventComponent = eventComponents[0];
      assertEquals(EVENT, eventComponent.getEventName());
      assertEquals(monNumber.getMonNumber(), eventComponent.getMonNumber());
      assertEquals(monNumber.getCrop().getCropName().toUpperCase(), eventInfo.getCrop().toUpperCase());
      Construct[] constructs = eventComponent.getConstructs();
      assertNotNull(constructs);
      assertEquals(1, constructs.length);
      Construct construct = constructs[0];
      assertEquals(TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_FCM_PVCODE, construct.getPlasmidPMon());
      assertEquals(TPSTestConstants.PV_CODE_FOR_EVENT_SINGLE_PMON_CONSTRUCT, construct.getPlasmidPVCode());
      assertEquals(1, eventInfo.getEventAgencies().length);
      eventBuilder.tearDownConnections();
   }

   @Ignore @Test
   public void testFindByAlignmentPubkeys_DoesNotFindEventInfo_ForDifferentCrop()
      throws Exception
   {
      eventBuilder.setupConnections();
      eventBuilder.insertEvent(EVENT);
      insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withCrop(CropBuilder.canola()).
               withEventName(EVENT).createInDb();
         }
      });

      EventAgencyAlignment eventAgencyAlignment = insert(new AcceptanceTestData<EventAgencyAlignment>()
      {
         public EventAgencyAlignment dataToInsert() {
            return new EventAgencyAlignmentBuilder().
               withEvent(EVENT).
               withAgency(AgencyBuilder.epa()).
               regulated().
               withMaxQuantity(10.5).
               withCrop(CropBuilder.soybeans()).
               create();
         }
      });
      EventInfo[] eventInfos = eventSearchService.findByEventAgencyAlignmentPubkey(new String[]{eventAgencyAlignment.getEventAgencyAlignmentPubkey()});

      assertEquals(0, eventInfos.length);
      eventBuilder.tearDownConnections();
   }


   @Ignore @Test
   public void testFindByAlignmentPubkeys_DoesNotFindEventInfo()
      throws Exception
   {
      EventInfo[] eventInfos = eventSearchService.findByEventAgencyAlignmentPubkey(new String[]{"1111X"});
      assertEquals(0, eventInfos.length);
   }

   @Ignore @Test
   public void testFindByAlignmentPubkeys_DoesNotReturnValuesForEmptyRequest()
      throws Exception
   {
      EventInfo[] eventInfos = eventSearchService.findByEventAgencyAlignmentPubkey(new String[0]);
      assertEquals(0, eventInfos.length);
   }

   @Ignore @Test
   public void testFindByAgencyAbbr_NoAgency()
      throws Exception
   {
      EventInfo[] eventInfos = eventSearchService.findByAgencyAbbr(new String[]{"This agency does not exist"});

      assertEquals(0, eventInfos.length);
   }

   @Ignore @Test
   public void testFindByAgencyAbbr_AgencyDoesNotHaveAnyAlignments()
      throws Exception
   {
      Agency newAgency = insert(new AcceptanceTestData<Agency>()
      {
         @Override
         public Agency dataToInsert() {
            return new AgencyBuilder().
               withAgencyAbbr("ABC").
               create();
         }
      });

      EventInfo[] eventInfos = eventSearchService.findByAgencyAbbr(new String[]{newAgency.getAgencyAbbr()});

      assertEquals(0, eventInfos.length);
   }

   @Ignore @Test
   public void testFindByAgencyAbbr_MultipleAgenciesWithMultipleEvents()
      throws Exception
   {
      LexiconDataServiceATTestCase atTestCase = new LexiconDataServiceATTestCase();
      try {
         atTestCase.setUp();
         MidasTestTools.insertFakeEventConstruct(atTestCase.getMidasConn(), -5645634, "EVENT A", "CONSTRUCT A", TPSTestConstants.MIDAS_CORN_ID);
         MidasTestTools.insertFakeEventConstruct(atTestCase.getMidasConn(), -6546543, "EVENT B", "CONSTRUCT B", TPSTestConstants.MIDAS_CORN_ID);
         insert(new AcceptanceTestData<Agency>()
         {
            @Override
            public Agency dataToInsert() {
               Agency agencyA = new AgencyBuilder().
                  withAgencyAbbr("AGENCY A").
                  create();

               new EventAgencyAlignmentBuilder().
                  withAgency(agencyA).
                  withEvent("EVENT A").
                  create();

               Agency agencyB = new AgencyBuilder().
                  withAgencyAbbr("AGENCY B").
                  create();

               new EventAgencyAlignmentBuilder().
                  withAgency(agencyB).
                  withEvent("EVENT B").
                  create();
               return null;
            }
         });

         EventInfo[] eventInfos = eventSearchService.findByAgencyAbbr(new String[]{"Agency A", "This agency does not exist", "Agency B"});

         assertEquals(2, eventInfos.length);
         EventInfo eventInfo = findEventInfoWithEventName(eventInfos, "EVENT A");
         EventComponent[] eventComponents = eventInfo.getEventComponents();
         assertFalse(ArrayUtils.isEmpty(eventComponents));
         EventComponent eventComponent = eventComponents[0];
         assertEquals("EVENT A", eventComponent.getEventName());
         assertEquals("CORN", eventInfo.getCrop());
         assertNull(eventComponent.getMonNumber());
         assertEquals(1, eventInfo.getEventAgencies().length);
         EventAgency eventAgency = eventInfo.getEventAgencies()[0];
         assertEquals("AGENCY A", eventAgency.getAgencyAbbr());
         assertEquals(1, eventComponent.getConstructs().length);
         Construct construct = eventComponent.getConstructs()[0];
         assertEquals("CONSTRUCT A", construct.getPlasmidPMon());

         eventInfo = findEventInfoWithEventName(eventInfos, "EVENT B");
         eventComponents = eventInfo.getEventComponents();
         assertFalse(ArrayUtils.isEmpty(eventComponents));
         eventComponent = eventComponents[0];
         assertEquals("EVENT B", eventComponent.getEventName());
         assertEquals("CORN", eventInfo.getCrop());
         assertNull(eventComponent.getMonNumber());
         assertEquals(1, eventInfo.getEventAgencies().length);
         eventAgency = eventInfo.getEventAgencies()[0];
         assertEquals("AGENCY B", eventAgency.getAgencyAbbr());
         assertEquals(1, eventComponent.getConstructs().length);
         construct = eventComponent.getConstructs()[0];
         assertEquals("CONSTRUCT B", construct.getPlasmidPMon());
      }
      finally {
         atTestCase.tearDown();
      }
   }

   @Ignore @Test
   public void testGetEventDeregulationStatus_InvalidCriteria_DoesNotReturnEventDeregulationStatus() {
      EventDeregulationStatus[] eventDeregulationStatusResponse =
         eventSearchService.getEventDeregulationStatus(new String[]{EVENT}, CANOLA, new String[]{"NONEXISTENT AGENCY"});
      assertTrue(ArrayUtils.isEmpty(eventDeregulationStatusResponse));
   }

   @Ignore @Test
   public void testGetEventDeregulationStatus_Returns_EventDeregulationStatus_SingleEventSingleAgency() {
      final Agency epaAgency = AgencyBuilder.epa();
      EventAgencyAlignment eventAgencyAlignment = insert(new AcceptanceTestData<EventAgencyAlignment>()
      {
         public EventAgencyAlignment dataToInsert() {
            return new EventAgencyAlignmentBuilder().
               withEvent(EVENT).
               withAgency(epaAgency).
               regulated().
               withMaxQuantity(10).
               withCrop(CropBuilder.canola()).
               create();
         }
      });

      EventDeregulationStatus[] eventDeregulationStatusResponse =
         eventSearchService.getEventDeregulationStatus(new String[]{EVENT}, CANOLA, new String[]{epaAgency.getAgencyAbbr()});
      assertFalse(ArrayUtils.isEmpty(eventDeregulationStatusResponse));
      EventDeregulationStatus eventDeregulationStatus = eventDeregulationStatusResponse[0];
      assertNotNull(eventDeregulationStatus);
      assertEquals(EVENT, eventDeregulationStatus.getEventName());
      assertEquals(CANOLA, eventDeregulationStatus.getCrop());
      EventAgency[] agencies = eventDeregulationStatus.getEventAgencies();
      assertFalse(ArrayUtils.isEmpty(agencies));
      EventAgency eventAgency = agencies[0];
      assertNotNull(eventAgency);
      assertEquals(epaAgency.getAgencyAbbr(), eventAgency.getAgencyAbbr());
      assertTrue(eventAgency.isRegulated());
   }


   @Ignore @Test
   public void testGetEventDeregulationStatus_Returns_EventDeregulationStatus_MultipleEventSingleAgency() {
      final Agency epaAgency = AgencyBuilder.epa();
      EventAgencyAlignment eventOneAlignment = insert(new AcceptanceTestData<EventAgencyAlignment>()
      {
         public EventAgencyAlignment dataToInsert() {
            return new EventAgencyAlignmentBuilder().
               withEvent(EVENT).
               withAgency(epaAgency).
               regulated().
               withMaxQuantity(10).
               withCrop(CropBuilder.canola()).
               create();
         }
      });

      EventAgencyAlignment eventTwoAlignment = insert(new AcceptanceTestData<EventAgencyAlignment>()
      {
         public EventAgencyAlignment dataToInsert() {
            return new EventAgencyAlignmentBuilder().
               withEvent(EVENT_TWO).
               withAgency(epaAgency).
               regulated().
               withMaxQuantity(10).
               withCrop(CropBuilder.canola()).
               create();
         }
      });

      EventDeregulationStatus[] results =
         eventSearchService.getEventDeregulationStatus(new String[]{EVENT, EVENT_TWO}, CANOLA, new String[]{epaAgency.getAgencyAbbr()});
      assertFalse(ArrayUtils.isEmpty(results));
      assertEquals(2, results.length);

      EventDeregulationStatus eventOneDeregulationStatus = findByEventName(EVENT, results);
      assertNotNull(eventOneDeregulationStatus);
      assertEquals(CANOLA, eventOneDeregulationStatus.getCrop());
      EventAgency[] agencies = eventOneDeregulationStatus.getEventAgencies();
      assertFalse(ArrayUtils.isEmpty(agencies));
      EventAgency eventAgency = agencies[0];
      assertNotNull(eventAgency);
      assertEquals(epaAgency.getAgencyAbbr(), eventAgency.getAgencyAbbr());
      assertTrue(eventAgency.isRegulated());

      EventDeregulationStatus eventTwoDeregulationStatus = findByEventName(EVENT_TWO, results);
      assertNotNull(eventTwoDeregulationStatus);
      assertEquals(EVENT_TWO, eventTwoDeregulationStatus.getEventName());
      assertEquals(CANOLA, eventTwoDeregulationStatus.getCrop());
      EventAgency[] eventAgencies = eventTwoDeregulationStatus.getEventAgencies();
      assertFalse(ArrayUtils.isEmpty(eventAgencies));
      EventAgency agency = eventAgencies[0];
      assertNotNull(agency);
      assertEquals(epaAgency.getAgencyAbbr(), agency.getAgencyAbbr());
      assertTrue(agency.isRegulated());
   }

   @Ignore @Test
   public void testGetEventDeregulationStatusByCrop() {
      final Agency epaAgency = AgencyBuilder.epa();
      EventAgencyAlignment eventOneAlignment = insert(new AcceptanceTestData<EventAgencyAlignment>()
      {
         public EventAgencyAlignment dataToInsert() {
            return new EventAgencyAlignmentBuilder().
               withEvent(EVENT).
               withAgency(epaAgency).
               regulated().
               withMaxQuantity(10).
               withCrop(CropBuilder.canola()).
               create();
         }
      });

      EventAgencyAlignment eventTwoAlignment = insert(new AcceptanceTestData<EventAgencyAlignment>()
      {
         public EventAgencyAlignment dataToInsert() {
            return new EventAgencyAlignmentBuilder().
               withEvent(EVENT_TWO).
               withAgency(epaAgency).
               regulated().
               withMaxQuantity(10).
               withCrop(CropBuilder.canola()).
               create();
         }
      });

      EventDeregulationStatus[] results =
         eventSearchService.getEventDeregulationStatus(new String[]{EVENT, EVENT_TWO}, CANOLA);
      assertFalse(ArrayUtils.isEmpty(results));
      assertEquals(2, results.length);

      EventDeregulationStatus eventOneDeregulationStatus = findByEventName(EVENT, results);
      assertNotNull(eventOneDeregulationStatus);
      assertEquals(CANOLA, eventOneDeregulationStatus.getCrop());
      EventAgency[] agencies = eventOneDeregulationStatus.getEventAgencies();
      assertFalse(ArrayUtils.isEmpty(agencies));
      EventAgency eventAgency = agencies[0];
      assertNotNull(eventAgency);
      assertEquals(epaAgency.getAgencyAbbr(), eventAgency.getAgencyAbbr());
      assertTrue(eventAgency.isRegulated());

      EventDeregulationStatus eventTwoDeregulationStatus = findByEventName(EVENT_TWO, results);
      assertNotNull(eventTwoDeregulationStatus);
      assertEquals(EVENT_TWO, eventTwoDeregulationStatus.getEventName());
      assertEquals(CANOLA, eventTwoDeregulationStatus.getCrop());
      EventAgency[] eventAgencies = eventTwoDeregulationStatus.getEventAgencies();
      assertFalse(ArrayUtils.isEmpty(eventAgencies));
      EventAgency agency = eventAgencies[0];
      assertNotNull(agency);
      assertEquals(epaAgency.getAgencyAbbr(), agency.getAgencyAbbr());
      assertTrue(agency.isRegulated());
   }



   @Ignore @Test
   public void testGetEventDeregulationStatus_Returns_EventDeregulationStatus_OneEventMultipleAgencies() {
      final Agency epaAgency = AgencyBuilder.epa();
      final Agency usdaAgency = AgencyBuilder.usda();

      EventAgencyAlignment eventOneAlignment = insert(new AcceptanceTestData<EventAgencyAlignment>()
      {
         public EventAgencyAlignment dataToInsert() {
            return new EventAgencyAlignmentBuilder().
               withEvent(EVENT).
               withAgency(epaAgency).
               regulated().
               withMaxQuantity(10).
               withCrop(CropBuilder.canola()).
               create();
         }
      });

      EventAgencyAlignment eventTwoAlignment = insert(new AcceptanceTestData<EventAgencyAlignment>()
      {
         public EventAgencyAlignment dataToInsert() {
            return new EventAgencyAlignmentBuilder().
               withEvent(EVENT).
               withAgency(usdaAgency).
               regulated().
               withMaxQuantity(10).
               withCrop(CropBuilder.canola()).
               create();
         }
      });

      EventDeregulationStatus[] results =
         eventSearchService.getEventDeregulationStatus(new String[]{EVENT}, CANOLA, new String[]{epaAgency.getAgencyAbbr(), usdaAgency.getAgencyAbbr()});
      assertFalse(ArrayUtils.isEmpty(results));
      assertEquals(1, results.length);

      EventDeregulationStatus eventDeregulationStatus = results[0];
      assertNotNull(eventDeregulationStatus);
      assertEquals(CANOLA, eventDeregulationStatus.getCrop());
      EventAgency[] agencies = eventDeregulationStatus.getEventAgencies();
      assertFalse(ArrayUtils.isEmpty(agencies));
      EventAgency agencyOne = findByAgencyAbbr(epaAgency.getAgencyAbbr(), agencies);
      assertNotNull(agencyOne);
      assertTrue(agencyOne.isRegulated());
      EventAgency agencyTwo = findByAgencyAbbr(usdaAgency.getAgencyAbbr(), agencies);
      assertNotNull(agencyTwo);
      assertTrue(agencyTwo.isRegulated());
   }


   @Ignore @Test
   public void testGetEventDeregulationStatus_Returns_EventDeregulationStatus_MultipleEventsMultipleAgencies() {
      final Agency epaAgency = AgencyBuilder.epa();
      final Agency usdaAgency = AgencyBuilder.usda();

      EventAgencyAlignment eventOneUsdaAlignment = insert(new AcceptanceTestData<EventAgencyAlignment>()
      {
         public EventAgencyAlignment dataToInsert() {
            return new EventAgencyAlignmentBuilder().
               withEvent(EVENT).
               withAgency(usdaAgency).
               regulated().
               withMaxQuantity(10).
               withCrop(CropBuilder.canola()).
               create();
         }
      });

      EventAgencyAlignment eventOneEpaAlignment = insert(new AcceptanceTestData<EventAgencyAlignment>()
      {
         public EventAgencyAlignment dataToInsert() {
            return new EventAgencyAlignmentBuilder().
               withEvent(EVENT).
               withAgency(epaAgency).
               regulated().
               withMaxQuantity(10).
               withCrop(CropBuilder.canola()).
               create();
         }
      });

      EventAgencyAlignment eventTwousdaAlignment = insert(new AcceptanceTestData<EventAgencyAlignment>()
      {
         public EventAgencyAlignment dataToInsert() {
            return new EventAgencyAlignmentBuilder().
               withEvent(EVENT_TWO).
               withAgency(usdaAgency).
               regulated().
               withMaxQuantity(10).
               withCrop(CropBuilder.canola()).
               create();
         }
      });

      EventAgencyAlignment eventTwoEpaAlignment = insert(new AcceptanceTestData<EventAgencyAlignment>()
      {
         public EventAgencyAlignment dataToInsert() {
            return new EventAgencyAlignmentBuilder().
               withEvent(EVENT_TWO).
               withAgency(epaAgency).
               regulated().
               withMaxQuantity(10).
               withCrop(CropBuilder.canola()).
               create();
         }
      });

      EventDeregulationStatus[] results =
         eventSearchService.getEventDeregulationStatus(new String[]{EVENT, EVENT_TWO}, CANOLA, new String[]{epaAgency.getAgencyAbbr(), usdaAgency.getAgencyAbbr()});
      assertFalse(ArrayUtils.isEmpty(results));
      assertEquals(2, results.length);

      EventDeregulationStatus eventOneDeregulationStatus = findByEventName(EVENT, results);
      assertNotNull(eventOneDeregulationStatus);
      assertEquals(CANOLA, eventOneDeregulationStatus.getCrop());
      EventAgency[] agencies = eventOneDeregulationStatus.getEventAgencies();
      assertFalse(ArrayUtils.isEmpty(agencies));
      EventAgency agencyOne = findByAgencyAbbr(epaAgency.getAgencyAbbr(), agencies);
      assertNotNull(agencyOne);
      assertTrue(agencyOne.isRegulated());
      EventAgency agencyTwo = findByAgencyAbbr(usdaAgency.getAgencyAbbr(), agencies);
      assertNotNull(agencyTwo);
      assertTrue(agencyTwo.isRegulated());

      EventDeregulationStatus eventTwoDeregulationStatus = findByEventName(EVENT_TWO, results);
      assertNotNull(eventTwoDeregulationStatus);
      assertEquals(CANOLA, eventTwoDeregulationStatus.getCrop());
      EventAgency[] eventAgencies = eventTwoDeregulationStatus.getEventAgencies();
      assertFalse(ArrayUtils.isEmpty(eventAgencies));
      EventAgency epa = findByAgencyAbbr(epaAgency.getAgencyAbbr(), eventAgencies);
      assertNotNull(epa);
      assertTrue(epa.isRegulated());
      EventAgency usda = findByAgencyAbbr(usdaAgency.getAgencyAbbr(), eventAgencies);
      assertNotNull(usda);
      assertTrue(usda.isRegulated());

   }

   @Ignore @Test
   public void testGetEventDeregulationStatus_Returns_EventDeregulationStatus_SearchCriteriaCountMoreThanMaxAllowed() {
      final Agency epaAgency = AgencyBuilder.epa();
      EventAgencyAlignment eventAgencyAlignment = insert(new AcceptanceTestData<EventAgencyAlignment>()
      {
         public EventAgencyAlignment dataToInsert() {
            return new EventAgencyAlignmentBuilder().
               withEvent(EVENT).
               withAgency(epaAgency).
               regulated().
               withMaxQuantity(10).
               withCrop(CropBuilder.canola()).
               create();
         }
      });
      String[] events = new String[1501];
      fillEvents(events, EVENT, 1500);
      events[1500] = EVENT;
      EventDeregulationStatus[] eventDeregulationStatusResponse =
         eventSearchService.getEventDeregulationStatus(events, CANOLA, new String[]{epaAgency.getAgencyAbbr()});
      assertFalse(ArrayUtils.isEmpty(eventDeregulationStatusResponse));
      EventDeregulationStatus eventDeregulationStatus = eventDeregulationStatusResponse[0];
      assertNotNull(eventDeregulationStatus);
      assertEquals(EVENT, eventDeregulationStatus.getEventName());
      assertEquals(CANOLA, eventDeregulationStatus.getCrop());
      EventAgency[] agencies = eventDeregulationStatus.getEventAgencies();
      assertFalse(ArrayUtils.isEmpty(agencies));
      EventAgency eventAgency = agencies[0];
      assertNotNull(eventAgency);
      assertEquals(epaAgency.getAgencyAbbr(), eventAgency.getAgencyAbbr());
      assertTrue(eventAgency.isRegulated());
   }

   private EventAgency findByAgencyAbbr(String agencyAbbr, EventAgency[] agencies) {
      for (EventAgency agency : agencies) {
         if (agencyAbbr.equalsIgnoreCase(agency.getAgencyAbbr())) {
            return agency;
         }
      }
      return null;
   }


   private EventDeregulationStatus findByEventName(String eventName, EventDeregulationStatus[] eventDeregulationStatuses) {
      for (EventDeregulationStatus eventDeregulationStatus : eventDeregulationStatuses) {
         if (eventName.equalsIgnoreCase(eventDeregulationStatus.getEventName())) {
            return eventDeregulationStatus;
         }
      }
      return null;
   }


   @Ignore @Test
   public void testGetEventDeregulationStatusWithMonNumber_InvalidCriteria_DoesNotReturnEventDeregulationStatusWithMonNumber() {
      EventDeregulationStatusWithMonNumber[] EventDeregulationStatusWithMonNumberResponse =
         eventSearchService.getEventDeregulationStatusWithMonNumber(new String[]{EVENT}, CANOLA, new String[]{"NONEXISTENT AGENCY"});
      assertTrue(ArrayUtils.isEmpty(EventDeregulationStatusWithMonNumberResponse));
   }

   @Ignore @Test
   public void testGetEventDeregulationStatusWithMonNumber_Returns_EventDeregulationStatusWithMonNumber_SingleEventSingleAgency() {
      final Agency epaAgency = AgencyBuilder.epa();
      EventAgencyAlignment eventAgencyAlignment = insert(new AcceptanceTestData<EventAgencyAlignment>()
      {
         public EventAgencyAlignment dataToInsert() {
            return new EventAgencyAlignmentBuilder().
               withEvent(EVENT).
               withAgency(epaAgency).
               regulated().
               withMaxQuantity(10).
               withCrop(CropBuilder.canola()).
               create();
         }
      });

      EventDeregulationStatusWithMonNumber[] EventDeregulationStatusWithMonNumberResponse =
         eventSearchService.getEventDeregulationStatusWithMonNumber(new String[]{EVENT}, CANOLA, new String[]{epaAgency.getAgencyAbbr()});
      assertFalse(ArrayUtils.isEmpty(EventDeregulationStatusWithMonNumberResponse));
      EventDeregulationStatusWithMonNumber EventDeregulationStatusWithMonNumber = EventDeregulationStatusWithMonNumberResponse[0];
      assertNotNull(EventDeregulationStatusWithMonNumber);
      assertEquals(EVENT, EventDeregulationStatusWithMonNumber.getEventName());
      assertEquals(CANOLA, EventDeregulationStatusWithMonNumber.getCrop());
      EventAgency[] agencies = EventDeregulationStatusWithMonNumber.getEventAgencies();
      assertFalse(ArrayUtils.isEmpty(agencies));
      EventAgency eventAgency = agencies[0];
      assertNotNull(eventAgency);
      assertEquals(epaAgency.getAgencyAbbr(), eventAgency.getAgencyAbbr());
      assertTrue(eventAgency.isRegulated());
   }


   @Ignore @Test
   public void testGetEventDeregulationStatusWithMonNumber_Returns_EventDeregulationStatusWithMonNumber_MultipleEventSingleAgency() {
      final Agency epaAgency = AgencyBuilder.epa();
      EventAgencyAlignment eventOneAlignment = insert(new AcceptanceTestData<EventAgencyAlignment>()
      {
         public EventAgencyAlignment dataToInsert() {
            return new EventAgencyAlignmentBuilder().
               withEvent(EVENT).
               withAgency(epaAgency).
               regulated().
               withMaxQuantity(10).
               withCrop(CropBuilder.canola()).
               create();
         }
      });

      EventAgencyAlignment eventTwoAlignment = insert(new AcceptanceTestData<EventAgencyAlignment>()
      {
         public EventAgencyAlignment dataToInsert() {
            return new EventAgencyAlignmentBuilder().
               withEvent(EVENT_TWO).
               withAgency(epaAgency).
               regulated().
               withMaxQuantity(10).
               withCrop(CropBuilder.canola()).
               create();
         }
      });

      EventDeregulationStatusWithMonNumber[] results =
         eventSearchService.getEventDeregulationStatusWithMonNumber(new String[]{EVENT, EVENT_TWO}, CANOLA, new String[]{epaAgency.getAgencyAbbr()});
      assertFalse(ArrayUtils.isEmpty(results));
      assertEquals(2, results.length);

      EventDeregulationStatusWithMonNumber eventOneDeregulationStatus = findByEventName(EVENT, results);
      assertNotNull(eventOneDeregulationStatus);
      assertEquals(CANOLA, eventOneDeregulationStatus.getCrop());
      EventAgency[] agencies = eventOneDeregulationStatus.getEventAgencies();
      assertFalse(ArrayUtils.isEmpty(agencies));
      EventAgency eventAgency = agencies[0];
      assertNotNull(eventAgency);
      assertEquals(epaAgency.getAgencyAbbr(), eventAgency.getAgencyAbbr());
      assertTrue(eventAgency.isRegulated());

      EventDeregulationStatusWithMonNumber eventTwoDeregulationStatus = findByEventName(EVENT_TWO, results);
      assertNotNull(eventTwoDeregulationStatus);
      assertEquals(EVENT_TWO, eventTwoDeregulationStatus.getEventName());
      assertEquals(CANOLA, eventTwoDeregulationStatus.getCrop());
      EventAgency[] eventAgencies = eventTwoDeregulationStatus.getEventAgencies();
      assertFalse(ArrayUtils.isEmpty(eventAgencies));
      EventAgency agency = eventAgencies[0];
      assertNotNull(agency);
      assertEquals(epaAgency.getAgencyAbbr(), agency.getAgencyAbbr());
      assertTrue(agency.isRegulated());
   }


   @Ignore @Test
   public void testGetEventDeregulationStatusWithMonNumber_Returns_EventDeregulationStatusWithMonNumber_OneEventMultipleAgencies() {
      final Agency epaAgency = AgencyBuilder.epa();
      final Agency usdaAgency = AgencyBuilder.usda();

      EventAgencyAlignment eventOneAlignment = insert(new AcceptanceTestData<EventAgencyAlignment>()
      {
         public EventAgencyAlignment dataToInsert() {
            return new EventAgencyAlignmentBuilder().
               withEvent(EVENT).
               withAgency(epaAgency).
               regulated().
               withMaxQuantity(10).
               withCrop(CropBuilder.canola()).
               create();
         }
      });

      EventAgencyAlignment eventTwoAlignment = insert(new AcceptanceTestData<EventAgencyAlignment>()
      {
         public EventAgencyAlignment dataToInsert() {
            return new EventAgencyAlignmentBuilder().
               withEvent(EVENT).
               withAgency(usdaAgency).
               regulated().
               withMaxQuantity(10).
               withCrop(CropBuilder.canola()).
               create();
         }
      });

      EventDeregulationStatusWithMonNumber[] results =
         eventSearchService.getEventDeregulationStatusWithMonNumber(new String[]{EVENT}, CANOLA, new String[]{epaAgency.getAgencyAbbr(), usdaAgency.getAgencyAbbr()});
      assertFalse(ArrayUtils.isEmpty(results));
      assertEquals(1, results.length);

      EventDeregulationStatusWithMonNumber EventDeregulationStatusWithMonNumber = results[0];
      assertNotNull(EventDeregulationStatusWithMonNumber);
      assertEquals(CANOLA, EventDeregulationStatusWithMonNumber.getCrop());
      EventAgency[] agencies = EventDeregulationStatusWithMonNumber.getEventAgencies();
      assertFalse(ArrayUtils.isEmpty(agencies));
      EventAgency agencyOne = findByAgencyAbbr(epaAgency.getAgencyAbbr(), agencies);
      assertNotNull(agencyOne);
      assertTrue(agencyOne.isRegulated());
      EventAgency agencyTwo = findByAgencyAbbr(usdaAgency.getAgencyAbbr(), agencies);
      assertNotNull(agencyTwo);
      assertTrue(agencyTwo.isRegulated());
   }


   @Ignore @Test
   public void testGetEventDeregulationStatusWithMonNumber_Returns_EventDeregulationStatusWithMonNumber_MultipleEventsMultipleAgencies() {
      final Agency epaAgency = AgencyBuilder.epa();
      final Agency usdaAgency = AgencyBuilder.usda();

      EventAgencyAlignment eventOneUsdaAlignment = insert(new AcceptanceTestData<EventAgencyAlignment>()
      {
         public EventAgencyAlignment dataToInsert() {
            return new EventAgencyAlignmentBuilder().
               withEvent(EVENT).
               withAgency(usdaAgency).
               regulated().
               withMaxQuantity(10).
               withCrop(CropBuilder.canola()).
               create();
         }
      });

      EventAgencyAlignment eventOneEpaAlignment = insert(new AcceptanceTestData<EventAgencyAlignment>()
      {
         public EventAgencyAlignment dataToInsert() {
            return new EventAgencyAlignmentBuilder().
               withEvent(EVENT).
               withAgency(epaAgency).
               regulated().
               withMaxQuantity(10).
               withCrop(CropBuilder.canola()).
               create();
         }
      });

      EventAgencyAlignment eventTwousdaAlignment = insert(new AcceptanceTestData<EventAgencyAlignment>()
      {
         public EventAgencyAlignment dataToInsert() {
            return new EventAgencyAlignmentBuilder().
               withEvent(EVENT_TWO).
               withAgency(usdaAgency).
               regulated().
               withMaxQuantity(10).
               withCrop(CropBuilder.canola()).
               create();
         }
      });

      EventAgencyAlignment eventTwoEpaAlignment = insert(new AcceptanceTestData<EventAgencyAlignment>()
      {
         public EventAgencyAlignment dataToInsert() {
            return new EventAgencyAlignmentBuilder().
               withEvent(EVENT_TWO).
               withAgency(epaAgency).
               regulated().
               withMaxQuantity(10).
               withCrop(CropBuilder.canola()).
               create();
         }
      });

      EventDeregulationStatusWithMonNumber[] results =
         eventSearchService.getEventDeregulationStatusWithMonNumber(new String[]{EVENT, EVENT_TWO}, CANOLA, new String[]{epaAgency.getAgencyAbbr(), usdaAgency.getAgencyAbbr()});
      assertFalse(ArrayUtils.isEmpty(results));
      assertEquals(2, results.length);

      EventDeregulationStatusWithMonNumber eventOneDeregulationStatus = findByEventName(EVENT, results);
      assertNotNull(eventOneDeregulationStatus);
      assertEquals(CANOLA, eventOneDeregulationStatus.getCrop());
      EventAgency[] agencies = eventOneDeregulationStatus.getEventAgencies();
      assertFalse(ArrayUtils.isEmpty(agencies));
      EventAgency agencyOne = findByAgencyAbbr(epaAgency.getAgencyAbbr(), agencies);
      assertNotNull(agencyOne);
      assertTrue(agencyOne.isRegulated());
      EventAgency agencyTwo = findByAgencyAbbr(usdaAgency.getAgencyAbbr(), agencies);
      assertNotNull(agencyTwo);
      assertTrue(agencyTwo.isRegulated());

      EventDeregulationStatusWithMonNumber eventTwoDeregulationStatus = findByEventName(EVENT_TWO, results);
      assertNotNull(eventTwoDeregulationStatus);
      assertEquals(CANOLA, eventTwoDeregulationStatus.getCrop());
      EventAgency[] eventAgencies = eventTwoDeregulationStatus.getEventAgencies();
      assertFalse(ArrayUtils.isEmpty(eventAgencies));
      EventAgency epa = findByAgencyAbbr(epaAgency.getAgencyAbbr(), eventAgencies);
      assertNotNull(epa);
      assertTrue(epa.isRegulated());
      EventAgency usda = findByAgencyAbbr(usdaAgency.getAgencyAbbr(), eventAgencies);
      assertNotNull(usda);
      assertTrue(usda.isRegulated());

   }

   @Ignore @Test
   public void testGetEventDeregulationStatusWithMonNumber_Returns_EventDeregulationStatusWithMonNumber_SearchCriteriaCountMoreThanMaxAllowed() {
      final Agency epaAgency = AgencyBuilder.epa();
      EventAgencyAlignment eventAgencyAlignment = insert(new AcceptanceTestData<EventAgencyAlignment>()
      {
         public EventAgencyAlignment dataToInsert() {
            return new EventAgencyAlignmentBuilder().
               withEvent(EVENT).
               withAgency(epaAgency).
               regulated().
               withMaxQuantity(10).
               withCrop(CropBuilder.canola()).
               create();
         }
      });
      String[] events = new String[1501];
      fillEvents(events, EVENT, 1500);
      events[1500] = EVENT;
      EventDeregulationStatusWithMonNumber[] EventDeregulationStatusWithMonNumberResponse =
         eventSearchService.getEventDeregulationStatusWithMonNumber(events, CANOLA, new String[]{epaAgency.getAgencyAbbr()});
      assertFalse(ArrayUtils.isEmpty(EventDeregulationStatusWithMonNumberResponse));
      EventDeregulationStatusWithMonNumber EventDeregulationStatusWithMonNumber = EventDeregulationStatusWithMonNumberResponse[0];
      assertNotNull(EventDeregulationStatusWithMonNumber);
      assertEquals(EVENT, EventDeregulationStatusWithMonNumber.getEventName());
      assertEquals(CANOLA, EventDeregulationStatusWithMonNumber.getCrop());
      EventAgency[] agencies = EventDeregulationStatusWithMonNumber.getEventAgencies();
      assertFalse(ArrayUtils.isEmpty(agencies));
      EventAgency eventAgency = agencies[0];
      assertNotNull(eventAgency);
      assertEquals(epaAgency.getAgencyAbbr(), eventAgency.getAgencyAbbr());
      assertTrue(eventAgency.isRegulated());
   }


   private EventDeregulationStatusWithMonNumber findByEventName(String eventName, EventDeregulationStatusWithMonNumber[] EventDeregulationStatusWithMonNumberes) {
      for (EventDeregulationStatusWithMonNumber EventDeregulationStatusWithMonNumber : EventDeregulationStatusWithMonNumberes) {
         if (eventName.equalsIgnoreCase(EventDeregulationStatusWithMonNumber.getEventName())) {
            return EventDeregulationStatusWithMonNumber;
         }
      }
      return null;
   }




   private EventInfo findEventInfoWithEventName(EventInfo[] eventInfos, String eventName) {
      for (EventInfo eventInfo : eventInfos) {
         EventComponent[] components = eventInfo.getEventComponents();
         for (EventComponent component : components) {
            if (eventName.equalsIgnoreCase(component.getEventName())) {
               return eventInfo;
            }
         }
      }
      throw new AssertionFailedError("Could not find event info with event name '" + eventName + "'");
   }


   private String[] fillEvents(String[] array, String eventPrefix, int count) {
      for (int i = 0; i < count; i++) {
         array[i] = eventPrefix + "_" + i;
      }
      return array;
   }



   @After
   public void onTearDown()
      throws Exception
   {
      if (eventBuilder.getTestManager() != null) {
         eventBuilder.tearDownConnections();
      }
   }
}
