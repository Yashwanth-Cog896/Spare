package com.monsanto.tps.lexicon.regulatory.eventsreginfo.util.domain.lexicon;

import com.monsanto.tcc.lexiconcommon.test.EqualityTester;
import org.junit.Test;

/**
 * Created by IntelliJ IDEA.
 * User: vvkalu
 * Date: Oct 11, 2010
 * Time: 8:44:00 AM
 * To change this template use File | Settings | File Templates.
 */
public class TempSessionOcd_UT {

   @Test
   public void testEquals()
      throws Exception
   {
      TempSessionOcd equalA = create(1L, 3L, "A", 2L);
      TempSessionOcd equalB = create(1L, 3L, "A", 2L);
      TempSessionOcd[] nonEqual = {
         create(1L, 4L, "A", 3L),
         create(1L, 4L, "B", 2L),
         create(2L, 4L, "A", 2L),
         create(2L, 4L, "B", 2L),
         create(2L, 4L, "B", 3L),
         create(1L, 3L, "A", 3L),
         create(1L, 3L, "B", 2L),
         create(2L, 3L, "A", 2L),
         create(2L, 3L, "B", 2L),
         create(2L, 3L, "B", 3L),
      };
      TempSessionOcd nullValue = create(null, null, null, null);
      EqualityTester.testEquality(equalA, equalB, nonEqual, nullValue);
   }

   @Test
   public void testHashCode()
      throws Exception
   {
      TempSessionOcd equalA = create(1L, 3L, "A", 2L);
      TempSessionOcd equalB = create(1L, 3L, "A", 2L);
      TempSessionOcd[] nonEqual = {
         create(1L, 4L, "A", 3L),
         create(1L, 4L, "B", 2L),
         create(2L, 4L, "A", 2L),
         create(2L, 4L, "B", 2L),
         create(2L, 4L, "B", 3L),
         create(1L, 3L, "A", 3L),
         create(1L, 3L, "B", 2L),
         create(2L, 3L, "A", 2L),
         create(2L, 3L, "B", 2L),
         create(2L, 3L, "B", 3L),
      };
      TempSessionOcd nullValue = create(null, null, null, null);
      EqualityTester.testHashCode(equalA, equalB, nonEqual, nullValue);
   }

   private TempSessionOcd create(Long requestId, Long number1, String text1, Long sortOrder) {
      TempSessionOcd ocd = new TempSessionOcd();
      ocd.setRequestId(requestId);
      ocd.setNumber1(number1);
      ocd.setText1(text1);
      ocd.setSortOrder(sortOrder);
      return ocd;
   }
}
