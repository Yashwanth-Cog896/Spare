package com.monsanto.tps.lexicon.regulatory.proteinname.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.DBUnitTest;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.GeneticBackground;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName;
import com.monsanto.tps.springframework.test.listener.dbunit.DataSet;
import com.monsanto.tps.springframework.test.listener.dbunit.DatasetOperation;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.Comparator;
import java.util.List;

import static com.google.common.collect.Ordering.from;
import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/1/12
 * Time: 7:47 PM
 * To change this template use File | Settings | File Templates.
 */
@DataSet(
        schema = "LEXICON", dataSourceKey = "dataSource", setupOperation = DatasetOperation.CLEAN_INSERT, teardownOperation = DatasetOperation.NONE,
        value = {"/com/monsanto/tps/lexicon/regulatory/proteinname/dao/protein_name.xml"}
)
public class ProteinNameDAOImpl_DUT extends DBUnitTest {

    @Autowired
    private ProteinNameDAO proteinNameDAO;

    @Test
    public void findProteinName_results_wildcard() throws Exception {
        final List<ProteinName> proteinNames = proteinNameDAO.findProteinNames("Cry%");
        assertNotNull(proteinNames);
        assertFalse(proteinNames.isEmpty());
    }

    @Test
    public void findProteinName_results_exactMatch() throws Exception {
        final List<ProteinName> proteinNames = proteinNameDAO.findProteinNames("Cre");
        assertNotNull(proteinNames);
        assertFalse(proteinNames.isEmpty());
    }

    @Test
    public void findProteinName_noResults() throws Exception {
        final List<ProteinName> proteinNames = proteinNameDAO.findProteinNames("asdf");
        assertNotNull(proteinNames);
        assertTrue(proteinNames.isEmpty());
    }

    @Test
    public void findProteinName_results_active() throws Exception {
        final List<ProteinName> proteinNames = proteinNameDAO.findProteinNames("");
        assertNotNull(proteinNames);
        assertFalse(proteinNames.isEmpty());

        for (ProteinName proteinName : proteinNames) {
            assertTrue(proteinName.isActiveStatus());
        }
    }

    @Test
    public void findProteinName_sorted() throws Exception {
        final List<ProteinName> proteinNames = proteinNameDAO.findProteinNames("%");
        assertNotNull(proteinNames);

        assertTrue(from(new ProteinNameComparator()).isOrdered(proteinNames));
    }

    private class ProteinNameComparator implements Comparator<ProteinName> {

        public final int compare(ProteinName c1, ProteinName c2) {

            int ctCompare = 0;

            if (c1 != null && c2 != null) {
                String ct1 = c1.getProteinName();
                String ct2 = c2.getProteinName();
                if (ct1 != null && ct2 != null) {
                    ctCompare = ct1.compareToIgnoreCase(ct2);
                }
            }

            return ctCompare;
        }
    }
}

