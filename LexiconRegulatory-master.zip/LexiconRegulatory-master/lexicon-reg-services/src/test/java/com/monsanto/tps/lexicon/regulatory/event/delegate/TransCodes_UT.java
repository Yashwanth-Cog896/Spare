package com.monsanto.tps.lexicon.regulatory.event.delegate;

import static org.hamcrest.core.Is.is;
import static org.hamcrest.core.IsNull.nullValue;
import static org.junit.Assert.assertThat;
import org.junit.Test;

/**
 * nbwald - Jan 5, 2009 2:20:38 PM
 */
public class TransCodes_UT
{
   @Test
   public void testGetDisplayText_NoValues_IsEmptyString()
      throws Exception
   {
      String[] transCodeArray = new String[0];

      TransCodes transCodes = new TransCodes(transCodeArray);

      assertThat(transCodes.getDisplayText(), is(nullValue()));
   }

   @Test
   public void testGetDisplayText_IsCaseSensitive()
      throws Exception
   {
      String[] transCodeArray = {"caseSensitive"};

      TransCodes transCodes = new TransCodes(transCodeArray);

      assertThat(transCodes.getDisplayText(), is("caseSensitive"));
   }

   @Test
   public void testGetDisplayText_MultipleValues_AreCSVd()
      throws Exception
   {
      String[] transCodeArray = {"A", "B", "C"};

      TransCodes transCodes = new TransCodes(transCodeArray);

      assertThat(transCodes.getDisplayText(), is("A,B,C"));
   }

   @Test
   public void testGetDisplayText_MultipleValues_AreOrdered()
      throws Exception
   {
      String[] transCodeArray = {"A", "D", "B", "E", "C"};

      TransCodes transCodes = new TransCodes(transCodeArray);

      assertThat(transCodes.getDisplayText(), is("A,B,C,D,E"));
   }
}
