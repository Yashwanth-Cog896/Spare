package com.monsanto.tps.lexicon.regulatory.event.queryset;

import com.monsanto.tps.compliance.referencedata.molecularinfo.ConstructIdentifier;
import com.monsanto.tps.compliance.referencedata.molecularinfo.ConstructPVCodeAssignment;
import com.monsanto.tps.compliance.referencedata.molecularinfo.PvCode;
import com.monsanto.tps.lexicon.regulatory.event.model.MockRegulatoryEventConstructTransformation;
import com.monsanto.tps.lexicon.regulatory.event.model.RegulatoryEventConstructTransformation;
import com.monsanto.tps.lexicon.regulatory.eventtraitservice.business.PVCodeAssignmentBuilder;

import java.util.ArrayList;
import java.util.List;

/**
 * User: pjberry
 * Date: Jul 27, 2007
 * Time: 3:34:28 PM
 */
public class MockRegulatoryEventQuerySet
   implements RegulatoryEventQuerySet
{
   private List<RegulatoryEventConstructTransformation> regulatoryECTs = new ArrayList<RegulatoryEventConstructTransformation>();
   private List<String> transCodesForSinglePmonConstruct = new ArrayList<String>();
   private String transCodeForMultiPmonConstruct;

   public RegulatoryEventConstructTransformation[] getEventConstructTransformations(String eventName, String cropAbbreviation) {
      return regulatoryECTs.toArray(new RegulatoryEventConstructTransformation[regulatoryECTs.size()]);
   }

/*   public String[] getTransCodesForSinglePmonConstruct(TransCodeQueryParams transCodeQueryParams)
      throws WrappingException
   {
      return transCodesForSinglePmonConstruct.toArray(new String[transCodesForSinglePmonConstruct.size()]);
   }

   public String getTransCodeForMultiPmonConstruct(TransCodeQueryParams transCodeQueryParams) {
      return transCodeForMultiPmonConstruct;
   }*/

   public String getGenusSpecies(String requestedCrop) {
      return null;
   }

   @Override
   public String[] findProductVectorsByCropIdAndConstructNameForCombinedConstructs(long cropPubkey, String[] constructNames) {
      return transCodeForMultiPmonConstruct == null ? null : new String[]{transCodeForMultiPmonConstruct};
   }

   @Override
   public String[] findProductVectorsByCropIdAndConstructNameForSingleConstructs(long cropPubkey, String constructName) {
      return transCodesForSinglePmonConstruct.toArray(new String[transCodesForSinglePmonConstruct.size()]);
   }

    @Override
    public List<ConstructPVCodeAssignment> findProductVectorsByCropIdAndConstructs(long cropPubkey, List<ConstructIdentifier> constructIdentifiers) {
        List<ConstructPVCodeAssignment> assigments = new ArrayList<ConstructPVCodeAssignment>();
        for(ConstructIdentifier constructIdentifier: constructIdentifiers){
            List<PvCode> pvCodes = PVCodeAssignmentBuilder.formPVCodes(transCodesForSinglePmonConstruct);
            assigments.add(new ConstructPVCodeAssignment(constructIdentifier,pvCodes));
        }
        return assigments;
    }

    public void addEventConstructTransformation(String event, String construct, String transformationBackground) {
      regulatoryECTs.add(new MockRegulatoryEventConstructTransformation(event, construct, transformationBackground));
   }

   public void addTransCodeForSinglePmonConstruct(String transCode) {
      transCodesForSinglePmonConstruct.add(transCode);
   }

   public void setTransCodeForMultiPmonConstruct(String transCode) {
      this.transCodeForMultiPmonConstruct = transCode;
   }

}
