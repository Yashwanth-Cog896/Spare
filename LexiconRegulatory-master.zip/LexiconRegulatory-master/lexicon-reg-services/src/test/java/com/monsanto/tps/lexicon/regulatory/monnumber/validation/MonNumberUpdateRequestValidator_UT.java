package com.monsanto.tps.lexicon.regulatory.monnumber.validation;

import com.monsanto.tps.lexicon.monnumber.MonNumberSaveRequest;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber;
import com.monsanto.tps.lexicon.regulatory.monnumber.dao.MonNumberDao;
import org.easymock.EasyMock;
import static org.easymock.EasyMock.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import org.junit.Before;
import org.junit.Test;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;

/**
 * rrchak1 - May 11, 2009 10:36:51 AM
 */
public class MonNumberUpdateRequestValidator_UT
{

   private MonNumberDao monNumberDao;
   private String validMonNumberValue = "MON 99999";
   MonNumberUpdateRequestValidator validator;
   private String oecdNumber = "12";

   @Before
   public void before() {
      monNumberDao = EasyMock.createMock(MonNumberDao.class);
      validator = new MonNumberUpdateRequestValidator();
      validator.setMonNumberDao(monNumberDao);
   }

   @Test
   public void UpdateRequestValiator_ThrowsErrorIfMonNumberNotFound() {
      MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
      monNumberSaveRequest.setMonNumber(validMonNumberValue);
      expect(monNumberDao.find(validMonNumberValue)).andReturn(null);
      expect(monNumberDao.findByEvent(null)).andReturn(null);
      replay(monNumberDao);
      BindException errors = new BindException(monNumberSaveRequest, "MonNumberSaveRequest");
      validator.validate(monNumberSaveRequest, errors);
      verify(monNumberDao);
      assertTrue(errors.hasErrors());
      FieldError fieldError = errors.getFieldError("monNumber");
      assertEquals("Mon Number does not exist.", fieldError.getDefaultMessage());
   }


   @Test
   public void UpdateRequestValiator_ThrowsErrorIfEventIsAssociatedWithOtherMonNumber() {
      MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
      monNumberSaveRequest.setMonNumber(validMonNumberValue);
      monNumberSaveRequest.setEvent("UT_event");
      expect(monNumberDao.find(validMonNumberValue)).andReturn(new MonNumber());
      MonNumber otherMonNumber = new MonNumber();
      otherMonNumber.setMonNumber("MON 91919");
      expect(monNumberDao.findByEvent("UT_event")).andReturn(otherMonNumber);
      replay(monNumberDao);
      BindException errors = new BindException(monNumberSaveRequest, "MonNumberSaveRequest");
      validator.validate(monNumberSaveRequest, errors);
      verify(monNumberDao);
      assertTrue(errors.hasErrors());
      FieldError fieldError = errors.getFieldError("event");
      assertEquals("Duplicate Event; " + "UT_event" + " is already defined.", fieldError.getDefaultMessage());
   }

   @Test
   public void UpdateRequestValiator_ThrowsErrorIfOecdNumberIsAssociatedWithOtherMonNumber() {
      MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
      monNumberSaveRequest.setMonNumber(validMonNumberValue);
      monNumberSaveRequest.setOecdNumber(oecdNumber);
      expect(monNumberDao.findByEvent(null)).andReturn(null);
      expect(monNumberDao.find(validMonNumberValue)).andReturn(new MonNumber());
      MonNumber otherMonNumber = new MonNumber();
      otherMonNumber.setMonNumber("MON 91919");
      expect(monNumberDao.findByOecdNumber(oecdNumber)).andReturn(otherMonNumber);
      replay(monNumberDao);
      BindException errors = new BindException(monNumberSaveRequest, "MonNumberSaveRequest");
      validator.validate(monNumberSaveRequest, errors);
      verify(monNumberDao);
      assertTrue(errors.hasErrors());
      FieldError fieldError = errors.getFieldError("oecdNumber");
      assertEquals("OECD Number is already defined.", fieldError.getDefaultMessage());
   }
}
