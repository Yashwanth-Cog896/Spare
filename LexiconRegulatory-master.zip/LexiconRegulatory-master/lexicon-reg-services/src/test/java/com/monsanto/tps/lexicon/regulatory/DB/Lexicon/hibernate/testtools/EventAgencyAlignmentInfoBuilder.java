package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools;

import com.monsanto.tps.lexicon.event.EventAgencyAlignmentRequestInfo;

import java.util.Date;

/**
 * rrchak1 - Feb 3, 2009 5:49:47 PM
 */
public class EventAgencyAlignmentInfoBuilder
{
   private final EventAgencyAlignmentRequestInfo eventAgencyAlignmentRequestInfo = new EventAgencyAlignmentRequestInfo();

   public EventAgencyAlignmentInfoBuilder() {
   }

   public EventAgencyAlignmentInfoBuilder withMaxQuantity(double maxQuantity) {
      eventAgencyAlignmentRequestInfo.setMaxQuantity(maxQuantity);
      return this;
   }

   public EventAgencyAlignmentRequestInfo getEventAgencyAlignmentInfo() {
      return eventAgencyAlignmentRequestInfo;
   }

   public EventAgencyAlignmentInfoBuilder regulated() {
      eventAgencyAlignmentRequestInfo.setRegulated(true);
      return this;
   }

   public EventAgencyAlignmentInfoBuilder withDeregulatedEffectiveDate(Date date) {
      eventAgencyAlignmentRequestInfo.setDeregulatedEffectiveDate(date);
      return this;
   }

   public EventAgencyAlignmentInfoBuilder withAgencyPubkey(String agencyPubKey) {
      eventAgencyAlignmentRequestInfo.setAgencyPubkey(agencyPubKey);
      return this;
   }
}
