package com.monsanto.tps.lexicon.regulatory.event.strategy;

import com.monsanto.tps.lexicon.event.EventInfo;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Crop;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber;
import com.monsanto.tps.lexicon.regulatory.event.model.EventConstruct;
import com.monsanto.tps.lexicon.regulatory.event.model.MockEventConstruct;
import com.monsanto.tps.lexicon.regulatory.event.queryset.EventCrop;
import com.monsanto.tps.lexicon.regulatory.event.queryset.EventSearchServiceQuerySet;
import static org.easymock.EasyMock.*;
import static org.hamcrest.core.Is.is;
import static org.hamcrest.core.IsNot.not;
import static org.hamcrest.core.IsNull.nullValue;
import static org.junit.Assert.assertThat;

import com.monsanto.tps.lexicon.regulatory.event.queryset.RegulatoryEventResponse;
import org.junit.Before;
import org.junit.Test;
import java.util.Arrays;
/**
 * nbwald - Jan 30, 2009 11:25:55 AM
 */
public class EventInfoByMonNumberStrategyImpl_UT
{
   private EventSearchServiceQuerySet querySet;
   private EventInfoByMonNumberStrategy strategy;
   private String monNumberValue = "MON 1111";
   private String eventName = "ZM_1111";
   private String cropName = "SOYBEANS";
   private MonNumber monNumber;
   private MockEventConstruct event;

   @Before
   public void before() {
      querySet = createMock(EventSearchServiceQuerySet.class);
      strategy = new EventInfoByMonNumberStrategyImpl(querySet);
      monNumber = new MonNumber();
      monNumber.setMonNumber(monNumberValue);
      monNumber.setEvent(eventName);
      Crop crop = new Crop();
      crop.setCropName(cropName);
      monNumber.setCrop(crop);
      event = new MockEventConstruct();
      event.setEvent(eventName);
   }

   @Test
   public void testFind_MonNumberDoesNotExist_ReturnsNullEventInfo()
      throws Exception
   {
      expect(querySet.findMonNumber(monNumberValue)).andReturn(null);
      replay(querySet);

      EventInfo eventInfo = strategy.find(monNumberValue);

      verify(querySet);
      assertThat(eventInfo, is(nullValue()));
   }

   @Test
   public void testFind_MonNumberExists_RegulatoryEventDoesNotExist_ReturnsNullEventInfo()
      throws Exception
   {
      expect(querySet.findMonNumber(monNumberValue)).andReturn(monNumber);
      expect(querySet.findRegulatoryEventByEventAndCrop(Arrays.asList(new EventCrop(eventName, cropName)))).andReturn(null);
      replay(querySet);

      EventInfo eventInfo = strategy.find(monNumberValue);

      verify(querySet);
      assertThat(eventInfo, is(nullValue()));
   }

   @Test
   public void testFind_MonNumberExists_RegulatoryEventExists_NoEventAgencies_ReturnsEventInfo()
      throws Exception
   {
      expect(querySet.findMonNumber(monNumberValue)).andReturn(monNumber);
       RegulatoryEventResponse response = new RegulatoryEventResponse();
       response.setEventConstructs(Arrays.asList((EventConstruct)event));
      expect(querySet.findRegulatoryEventByEventAndCrop(Arrays.asList(new EventCrop(eventName, cropName)))).andReturn(Arrays.asList(response));
      expect(querySet.findEventAgencyAlignmentsByEventAndCrop(eventName, cropName)).andReturn(new EventAgencyAlignment[0]);
      replay(querySet);

      EventInfo eventInfo = strategy.find(monNumberValue);

      verify(querySet);
      assertThat(eventInfo, is(not(nullValue())));
   }

   @Test
   public void testFind_MonNumberExists_RegulatoryEventExists_MultipleEventAgencies_ReturnsEventInfo()
      throws Exception
   {
      expect(querySet.findMonNumber(monNumberValue)).andReturn(monNumber);
      RegulatoryEventResponse response = new RegulatoryEventResponse();
      response.setEventConstructs(Arrays.asList((EventConstruct)event));
      response.setEvent(eventName);
      expect(querySet.findRegulatoryEventByEventAndCrop(Arrays.asList(new EventCrop(eventName, cropName)))).andReturn(Arrays.asList(response));
      expect(querySet.findEventAgencyAlignmentsByEventAndCrop(eventName, cropName)).andReturn(new EventAgencyAlignment[]{new EventAgencyAlignment(), new EventAgencyAlignment()});
      replay(querySet);

      EventInfo eventInfo = strategy.find(monNumberValue);

      verify(querySet);
      assertThat(eventInfo, is(not(nullValue())));
   }
}
