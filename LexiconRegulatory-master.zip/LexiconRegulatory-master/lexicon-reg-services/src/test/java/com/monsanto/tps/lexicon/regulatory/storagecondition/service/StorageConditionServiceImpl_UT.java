package com.monsanto.tps.lexicon.regulatory.storagecondition.service;

import com.monsanto.tps.lexicon.regulatory.storagecondition.business.StorageConditionBusiness;
import com.monsanto.tps.lexicon.regulatory.storagecondition.service.StorageConditionServiceImpl;
import com.monsanto.tps.lexicon.storagecondition.OrionStorageCondition;
import com.monsanto.tps.lexicon.storagecondition.StorageConditionService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/1/12
 * Time: 7:47 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class StorageConditionServiceImpl_UT {

    @Mock
    private StorageConditionBusiness storageConditionBusiness;

    @InjectMocks
    private StorageConditionService storageConditionService = new StorageConditionServiceImpl();

    private static final List<OrionStorageCondition> storageConditionList = new ArrayList<OrionStorageCondition>();

    @Test
    public void findStorageCondition_success() throws Exception {
        when(storageConditionBusiness.findStorageConditions("Cool on Ice")).thenReturn(storageConditionList);

        final List<OrionStorageCondition> actualStorageConditions = storageConditionBusiness.findStorageConditions("Cool on Ice");

        assertEquals(actualStorageConditions, storageConditionList);
    }
}
