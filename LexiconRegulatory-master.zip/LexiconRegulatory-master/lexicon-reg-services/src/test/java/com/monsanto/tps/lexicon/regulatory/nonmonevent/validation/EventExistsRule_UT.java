package com.monsanto.tps.lexicon.regulatory.nonmonevent.validation;

import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import org.junit.Test;

/**
 * nbwald - May 21, 2009 6:03:33 PM
 */
public class EventExistsRule_UT
{
   @Test
   public void testViolated_False()
      throws Exception
   {
      String[] constructNames = new String[]{"SOMETHING"};
      Rule<String> rule = new EventExistsRule(constructNames);

      assertThat(rule.violated(), is(false));
   }

   @Test
   public void testViolated_True()
      throws Exception
   {
      String[] constructNames = new String[0];
      Rule<String> rule = new EventExistsRule(constructNames);

      assertThat(rule.violated(), is(true));
   }

   @Test
   public void testGetViolation()
      throws Exception
   {
      assertThat(new EventExistsRule().getViolation(), is("Invalid Event for Selected Crop."));
   }
}
