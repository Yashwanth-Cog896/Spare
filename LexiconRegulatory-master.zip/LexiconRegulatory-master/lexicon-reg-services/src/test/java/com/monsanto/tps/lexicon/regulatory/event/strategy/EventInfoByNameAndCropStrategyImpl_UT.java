package com.monsanto.tps.lexicon.regulatory.event.strategy;

import com.monsanto.tps.lexicon.event.EventInfo;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber;
import com.monsanto.tps.lexicon.regulatory.event.model.EventConstruct;
import com.monsanto.tps.lexicon.regulatory.event.model.MockEventConstruct;
import com.monsanto.tps.lexicon.regulatory.event.queryset.EventCrop;
import com.monsanto.tps.lexicon.regulatory.event.queryset.EventSearchServiceQuerySet;
import com.monsanto.tps.lexicon.regulatory.event.queryset.RegulatoryEventResponse;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.List;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.when;

/**
 * nbwald - Jan 30, 2009 10:39:48 AM
 */
@RunWith(MockitoJUnitRunner.class)
public class EventInfoByNameAndCropStrategyImpl_UT
{
    @Mock
   private EventSearchServiceQuerySet querySet;
    @InjectMocks
   private EventInfoByNameAndCropStrategy strategy = new EventInfoByNameAndCropStrategyImpl(null);


   @Test
   public void testFind_FindsRegulatoryEvent_DoesNotFindMonNumber_DoesNotFindAgencies_EventInfoIsNotNull()
      throws Exception
   {
      String eventName = "ZM_1111";
      String cropName = "CORN";
       
      RegulatoryEventResponse response = new RegulatoryEventResponse();
      response.setEventConstructs(Arrays.asList((EventConstruct)new MockEventConstruct(eventName,cropName)));
      response.setEvent(eventName);
      when(querySet.findRegulatoryEventByEventAndCrop(eq(Arrays.asList(new EventCrop(eventName, cropName))))).thenReturn(Arrays.asList(response));
      when(querySet.findMonNumberByEventAndCrop(eventName, cropName)).thenReturn(null);
      when(querySet.findEventAgencyAlignmentsByEventAndCrop(eventName, cropName)).thenReturn(new EventAgencyAlignment[0]);


      EventInfo eventInfo = strategy.find(new String[]{eventName}, cropName)[0];

     
      assertThat(eventInfo, is(not(nullValue())));
   }

   @Test
   public void testFind_FindsRegulatoryEvent_FindsMonNumber_DoesNotFindAgencies_EventInfoIsNotNull()
      throws Exception
   {
      String eventName = "ZM_1111";
      String cropName = "CORN";
      RegulatoryEventResponse response = new RegulatoryEventResponse();
      response.setEventConstructs(Arrays.asList((EventConstruct)new MockEventConstruct(eventName,cropName)));
      response.setEvent(eventName);
      when(querySet.findRegulatoryEventByEventAndCrop(eq(Arrays.asList(new EventCrop(eventName, cropName))))).thenReturn(Arrays.asList(response));
      when(querySet.findMonNumberByEventAndCrop(eventName, cropName)).thenReturn(new MonNumber());
      when(querySet.findEventAgencyAlignmentsByEventAndCrop(eventName, cropName)).thenReturn(new EventAgencyAlignment[0]);

      EventInfo eventInfo = strategy.find(new String[]{eventName}, cropName)[0];

    
      assertThat(eventInfo, is(not(nullValue())));
   }

   @Test
   public void testFind_FindsRegulatoryEvent_FindsMonNumber_FindsAgencies_EventInfoIsNotNull()
      throws Exception
   {
      String eventName = "ZM_1111";
      String cropName = "CORN";
      RegulatoryEventResponse response = new RegulatoryEventResponse();
      response.setEventConstructs(Arrays.asList((EventConstruct)new MockEventConstruct(eventName,cropName)));
      response.setEvent(eventName);
      when(querySet.findRegulatoryEventByEventAndCrop(eq(Arrays.asList(new EventCrop(eventName, cropName))))).thenReturn(Arrays.asList(response));
      when(querySet.findMonNumberByEventAndCrop(eventName, cropName)).thenReturn(new MonNumber());
      when(querySet.findEventAgencyAlignmentsByEventAndCrop(eventName, cropName)).thenReturn(new EventAgencyAlignment[]{new EventAgencyAlignment(), new EventAgencyAlignment()});

      EventInfo eventInfo = strategy.find(new String[]{eventName}, cropName)[0];


      assertThat(eventInfo, is(not(nullValue())));
   }

   @Test
   public void testFind_DoesNotFindRegulatoryEvent_EventInfoIsNull()
      throws Exception
   {
      String eventName = "ZM_1111";
      String cropName = "CORN";

      when(querySet.findRegulatoryEventByEventAndCrop(eq(Arrays.asList(new EventCrop(eventName, cropName))))).thenReturn(null);

      EventInfo[] eventInfos = strategy.find(new String[]{eventName}, cropName);


      assertThat(eventInfos.length, is(0));
   }

   @Test
   public void testFind_FindsMultipleRegulatoryEventsForStackedEvents_FindsMonNumberForEachEvent_FindsAgencies_EventInfoIsNotNull()
      throws Exception
   {
      String eventName = "ZM_1111,ZM_2345";
      String cropName = "CORN";


      RegulatoryEventResponse response = new RegulatoryEventResponse();
      response.setEventConstructs(Arrays.asList((EventConstruct)new MockEventConstruct("ZM_2345",cropName)));
      response.setEvent(eventName);
      when(querySet.findRegulatoryEventByEventAndCrop(eq(Arrays.asList(new EventCrop(eventName, cropName))))).thenReturn(Arrays.asList(response));
      when(querySet.findMonNumberByEventAndCrop("ZM_1111", cropName)).thenReturn(new MonNumber());
      when(querySet.findMonNumberByEventAndCrop("ZM_2345", cropName)).thenReturn(new MonNumber());
      when(querySet.findEventAgencyAlignmentsByEventAndCrop(eventName, cropName)).thenReturn(new EventAgencyAlignment[]{new EventAgencyAlignment(), new EventAgencyAlignment()});


      EventInfo eventInfo = strategy.find(new String[]{eventName}, cropName)[0];

      assertThat(eventInfo, is(not(nullValue())));
   }

   @Test
   public void testFind_FindsMultipleRegulatoryEventsForStackedEvents_FindsMonNumberForEachEvent_FindsAgenciesInAscendingOrder_EventInfoIsNotNull()
      throws Exception
   {
      String eventName = "ZM_2345,BY_1245";
      String eventNameInOrder = "BY_1245,ZM_2345";
      String cropName = "CORN";


      RegulatoryEventResponse response = new RegulatoryEventResponse();
      response.setEventConstructs(Arrays.asList((EventConstruct)new MockEventConstruct("BY_1245",cropName)));
      response.setEvent(eventName);
      when(querySet.findRegulatoryEventByEventAndCrop(eq(Arrays.asList(new EventCrop(eventNameInOrder, cropName))))).thenReturn(Arrays.asList(response));
      when(querySet.findMonNumberByEventAndCrop("ZM_2345", cropName)).thenReturn(new MonNumber());
      when(querySet.findMonNumberByEventAndCrop("BY_1245", cropName)).thenReturn(new MonNumber());
      when(querySet.findEventAgencyAlignmentsByEventAndCrop(eventNameInOrder, cropName)).thenReturn(new EventAgencyAlignment[]{new EventAgencyAlignment(), new EventAgencyAlignment()});


      EventInfo eventInfo = strategy.find(new String[]{eventName}, cropName)[0];


      assertThat(eventInfo, is(not(nullValue())));
   }

    @Test
    public void testFind_FindsMultipleRegulatoryEventsForStackedEventsSetsEventsToUpperCase()
       throws Exception
    {
       String ZM_2345 = "ZM_2345";
       String BY_1245 = "BY_1245";
       String zm_2345 = "zm_2345";
       String by_1245 = "by_1245";
       String eventNames = by_1245+","+zm_2345;
       String cropName = "CORN";
       String upperEventNames = BY_1245+","+ZM_2345;


       RegulatoryEventResponse response = new RegulatoryEventResponse();

       response.setEventConstructs(Arrays.asList((EventConstruct)new MockEventConstruct(BY_1245,cropName),(EventConstruct)new MockEventConstruct(ZM_2345,cropName)));
       response.setEvent(eventNames);
       when(querySet.findRegulatoryEventByEventAndCrop(eq(Arrays.asList(new EventCrop(upperEventNames, cropName))))).thenReturn(Arrays.asList(response));
       when(querySet.findMonNumberByEventAndCrop(ZM_2345, cropName)).thenReturn(new MonNumber());
       when(querySet.findMonNumberByEventAndCrop(BY_1245, cropName)).thenReturn(new MonNumber());
       when(querySet.findEventAgencyAlignmentsByEventAndCrop(eventNames, cropName)).thenReturn(new EventAgencyAlignment[]{new EventAgencyAlignment(), new EventAgencyAlignment()});

       EventInfo eventInfo = strategy.find(new String[]{eventNames}, cropName)[0];

       assertThat(eventInfo, is(not(nullValue())));
       assertThat(eventInfo.getEventComponents().length,is(2));
       List<String> eventComponentNames = Arrays.asList(eventInfo.getEventComponents()[0].getEventName(),eventInfo.getEventComponents()[1].getEventName());
       assertThat(eventComponentNames.contains(ZM_2345),is(true));
       assertThat(eventComponentNames.contains(BY_1245),is(true));
    }

   @Test
   public void testFind_FindsMultipleRegulatoryEventConstructsForEvent_FindsMonNumber_FindsAgencies_EventInfoIsNotNull()
      throws Exception
   {
      String eventName = "ZM_1111";
      String cropName = "CORN";


      RegulatoryEventResponse response = new RegulatoryEventResponse();
      response.setEventConstructs(Arrays.asList((EventConstruct)new MockEventConstruct("ZM_1111",cropName), new MockEventConstruct("ZM_1111",cropName)));
      response.setEvent(eventName);
      when(querySet.findRegulatoryEventByEventAndCrop(eq(Arrays.asList(new EventCrop(eventName, cropName))))).thenReturn(Arrays.asList(response));
      when(querySet.findMonNumberByEventAndCrop("ZM_1111", cropName)).thenReturn(new MonNumber());
      when(querySet.findEventAgencyAlignmentsByEventAndCrop(eventName, cropName)).thenReturn(new EventAgencyAlignment[]{new EventAgencyAlignment(), new EventAgencyAlignment()});


      EventInfo eventInfo = strategy.find(new String []{eventName}, cropName)[0];
      assertThat(eventInfo, is(not(nullValue())));
   }
}
