package com.monsanto.tps.lexicon.regulatory.event.queryset;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.RegulatoryEventRequestComparator;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber;
import com.monsanto.tps.lexicon.regulatory.event.dao.EventAgencyAlignmentDao;
import com.monsanto.tps.lexicon.regulatory.event.model.EventConstruct;
import com.monsanto.tps.lexicon.regulatory.event.model.MockEventConstruct;
import com.monsanto.tps.lexicon.regulatory.event.model.RegulatoryEventRequest;
import com.monsanto.tps.lexicon.regulatory.monnumber.dao.MonNumberDao;
import org.easymock.LogicalOperator;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

import static org.easymock.EasyMock.cmp;
import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

/**
 * nbwald - Jan 7, 2009 3:12:23 PM
 */
public class EventSearchServiceQuerySetImpl_UT {
    private EventSearchServiceQuerySetImpl querySet;

    private MonNumberDao monNumberDao;
    private EventAgencyAlignmentDao eventAgencyAlignmentDao;
    private RegulatoryEventRequestProcessor regulatoryEventRequestProcessor;

    @Before
    public void before() {
        this.monNumberDao = createMock(MonNumberDao.class);
        this.eventAgencyAlignmentDao = createMock(EventAgencyAlignmentDao.class);
        this.regulatoryEventRequestProcessor = createMock(RegulatoryEventRequestProcessor.class);
        this.querySet = new EventSearchServiceQuerySetImpl(monNumberDao, eventAgencyAlignmentDao, regulatoryEventRequestProcessor);
    }

    @Test
    public void findMonNumber_DelegatesToMonNumberDao()
            throws Exception {
        MonNumber expectedMonNumber = new MonNumber();
        expect(monNumberDao.find("some mon number")).andReturn(expectedMonNumber);
        replay(monNumberDao);

        MonNumber actualMonNumber = querySet.findMonNumber("some mon number");

        verify(monNumberDao);
        assertThat(actualMonNumber, is(expectedMonNumber));
    }

    @Test
    public void findMonNumberByEventAndCrop_DelegatesToMonNumberDao()
            throws Exception {
        MonNumber expectedMonNumber = new MonNumber();
        expect(monNumberDao.findByEventAndCrop("some event", "crop")).andReturn(expectedMonNumber);
        replay(monNumberDao);

        MonNumber actualMonNumber = querySet.findMonNumberByEventAndCrop("some event", "crop");

        verify(monNumberDao);
        assertThat(actualMonNumber, is(expectedMonNumber));
    }

    @Test
    public void findEventAgencyAlignmentsByEvent_DelegatesToEventAgencyDao()
            throws Exception {
        EventAgencyAlignment[] expectedEventAgencyAlignments = {
                new EventAgencyAlignment(),
                new EventAgencyAlignment()
        };
        expect(eventAgencyAlignmentDao.findByEventAndCrop("some event", "CORN")).andReturn(expectedEventAgencyAlignments);
        replay(eventAgencyAlignmentDao);

        EventAgencyAlignment[] actualEventAgencyAlignments = querySet.findEventAgencyAlignmentsByEventAndCrop("some event", "CORN");

        verify(eventAgencyAlignmentDao);
        Assert.assertArrayEquals(expectedEventAgencyAlignments, actualEventAgencyAlignments);
    }

    @Test
    public void findRegulatoryEventByEventAndCrop_DelegatesToRegulatoryEventRequestProcessor()
            throws Exception {
        RegulatoryEventRequest request = new RegulatoryEventRequest("some event", "some crop");
        RegulatoryEventRequestListComparator regulatoryEventComparator = new RegulatoryEventRequestListComparator();
        EventConstruct[] expectedRegulatoryEvents = new EventConstruct[]{
                new MockEventConstruct(),
                new MockEventConstruct(),
        };
        String event = "some event";
        RegulatoryEventResponse response = new RegulatoryEventResponse();
        response.setEventConstructs(Arrays.asList(expectedRegulatoryEvents));
        response.setEvent(event);
        expect(regulatoryEventRequestProcessor.getRegulatoryEvents(cmp(Arrays.asList(request), regulatoryEventComparator, LogicalOperator.EQUAL))).andReturn(Arrays.asList(response));
        replay(regulatoryEventRequestProcessor);
        List<RegulatoryEventResponse> responses = querySet.findRegulatoryEventByEventAndCrop(Arrays.asList(new EventCrop(event, "some crop")));
        verify(regulatoryEventRequestProcessor);
        assertThat(responses.get(0).getEventConstructs(), is(Arrays.asList(expectedRegulatoryEvents)));
    }

    @Test(expected = RuntimeException.class)
    public void findRegulatoryEventByEventAndCrop_DelegatesToRegulatoryEventRequestProcessor_DelegateThrowsWrappingException_PropogatesAsRuntimeException()
            throws Exception {
        RegulatoryEventRequest request = new RegulatoryEventRequest("some event", "some crop");
        RegulatoryEventRequestListComparator regulatoryEventComparator = new RegulatoryEventRequestListComparator();
        expect(regulatoryEventRequestProcessor.getRegulatoryEvents(cmp(Arrays.asList(request), regulatoryEventComparator, LogicalOperator.EQUAL))).andThrow(new WrappingException(new Exception("nested exception")));
        replay(regulatoryEventRequestProcessor);

        try {
            querySet.findRegulatoryEventByEventAndCrop(Arrays.asList(new EventCrop("some event", "some crop")));
        } finally {
            verify(regulatoryEventRequestProcessor);
        }
    }

    @Test(expected = RuntimeException.class)
    public void findRegulatoryEventByEventAndCrop_DelegatesToRegulatoryEventRequestProcessor_DelegateThrowsIOException_PropogatesAsRuntimeException()
            throws Exception {
        RegulatoryEventRequest request = new RegulatoryEventRequest("some event", "some crop");
        RegulatoryEventRequestListComparator regulatoryEventComparator = new RegulatoryEventRequestListComparator();
        expect(regulatoryEventRequestProcessor.getRegulatoryEvents(cmp(Arrays.asList(request), regulatoryEventComparator, LogicalOperator.EQUAL))).andThrow(new IOException());
        replay(regulatoryEventRequestProcessor);

        try {
            querySet.findRegulatoryEventByEventAndCrop(Arrays.asList(new EventCrop("some event", "some crop")));
        } finally {
            verify(regulatoryEventRequestProcessor);
        }
    }

    @Test
    public void findEventAgencyAlignmentsByEventCropAndAgencyPubkey_DelegatesToEventAgencyDao()
            throws Exception {
        EventAgencyAlignment expected = new EventAgencyAlignment();
        expected.setMaterialName("some event");
        expect(eventAgencyAlignmentDao.findByEventCropAndAgencyPubkey("some event", "some crop", "1111")).andReturn(expected);
        replay(eventAgencyAlignmentDao);

        EventAgencyAlignment received = querySet.findEventAgencyAlignmentsByEventCropAndAgencyPubkey("some event", "some crop", "1111");

        verify(eventAgencyAlignmentDao);
        Assert.assertEquals(expected.getMaterialName(), received.getMaterialName());
    }

    @Test
    public void findEventAgencyAlignmentByPubkey_DelegatesToEventAgencyDao()
            throws Exception {
        EventAgencyAlignment expected = new EventAgencyAlignment();
        expected.setMaterialName("some event");
        String[] eventAgencyAlignmentPubkey = new String[]{"1111"};
        expect(eventAgencyAlignmentDao.findByPubkey(eventAgencyAlignmentPubkey)).andReturn(new EventAgencyAlignment[]{expected});
        replay(eventAgencyAlignmentDao);

        EventAgencyAlignment[] received = querySet.findEventAgencyAlignmentByPubkey(eventAgencyAlignmentPubkey);

        verify(eventAgencyAlignmentDao);
        EventAgencyAlignment receivedAlignment = received[0];
        Assert.assertEquals(expected.getMaterialName(), receivedAlignment.getMaterialName());
    }

    @Test
    public void findEventAgencyAlignmentByAgencyAbbr_DelegatesToEventAgencyDao()
            throws Exception {
        EventAgencyAlignment expected = new EventAgencyAlignment();
        expected.setMaterialName("some event");
        String[] agencyAbbreviations = new String[]{"DEA"};
        expect(eventAgencyAlignmentDao.findByAgencyAbbr(agencyAbbreviations)).andReturn(new EventAgencyAlignment[]{expected});
        replay(eventAgencyAlignmentDao);

        EventAgencyAlignment[] received = querySet.findByAgencyAbbr(agencyAbbreviations);

        verify(eventAgencyAlignmentDao);
        EventAgencyAlignment receivedAlignment = received[0];
        Assert.assertEquals(expected.getMaterialName(), receivedAlignment.getMaterialName());
    }

    class RegulatoryEventRequestListComparator implements Comparator<List<RegulatoryEventRequest>> {
        RegulatoryEventRequestComparator comparator = new RegulatoryEventRequestComparator();

        @Override
        public int compare(List<RegulatoryEventRequest> o1, List<RegulatoryEventRequest> o2) {

            if (o1.size() > o2.size()) {
                return 1;//To change body of implemented methods use File | Settings | File Templates.
            } else if (o1.size() < o2.size()) {
                return 0;
            } else {
                int retval = 0;
                for (int i = 0; i < o1.size() && retval == 0; i++) {
                    retval = comparator.compare(o1.get(i), o2.get(i));
                }
                return retval;
            }

        }
    }
}
