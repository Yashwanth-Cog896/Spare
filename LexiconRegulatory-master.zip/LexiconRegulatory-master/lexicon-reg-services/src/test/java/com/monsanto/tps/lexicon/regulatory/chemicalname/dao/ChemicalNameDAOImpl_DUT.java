package com.monsanto.tps.lexicon.regulatory.chemicalname.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ChemicalName;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static junit.framework.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/1/12
 * Time: 7:47 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:/com/monsanto/tps/lexicon/regulatory/contexts/lexicon-test-service-at-context.xml"})
@Transactional
public class ChemicalNameDAOImpl_DUT{

    @Autowired
    private ChemicalNameDAO chemicalNameDAO;

    @Test
    public void findCommercialProducts() {
        List<ChemicalName> commercialProducts = chemicalNameDAO.findChemicalCommercialProduct("ab%");
        assertTrue(commercialProducts.size()>0);
        assertStartsWith(commercialProducts, "ab");
    }


    @Test
    public void findChemicalFormulation() {
        List<ChemicalName> chemicalFormulations = chemicalNameDAO.findChemicalFormulation("MON 0%");
        assertTrue(chemicalFormulations.size()>0);
        assertStartsWith(chemicalFormulations, "MON 0");
    }

    @Test
    public void findChemicalActiveIngredient() {
        List<ChemicalName> activeIngredients = chemicalNameDAO.findChemicalActiveIngredient("a%");
        assertTrue(activeIngredients.size()>0);
        assertStartsWith(activeIngredients, "a");
    }

    @Test
    public void findActiveIngredientNames() {
        List<String> activeIngredients = chemicalNameDAO.findActiveIngredientNames(2010071902074430L, "a%");
        assertTrue(activeIngredients.size()>0);
    }

    private void assertStartsWith(List<ChemicalName> products, String startsWith) {
        for(ChemicalName product : products) {
            assertTrue(product.getMaterialName().startsWith(startsWith.toLowerCase()) ||
                    product.getMaterialName().startsWith(startsWith.toUpperCase()));
        }
    }
}

