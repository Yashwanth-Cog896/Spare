package com.monsanto.tps.lexicon.regulatory.sample.service;

import com.monsanto.tps.lexicon.sample.SampleService;
import com.monsanto.tps.lexicon.sample.OrionSample;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/2/12
 * Time: 7:40 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:/com/monsanto/tps/lexicon/regulatory/contexts/lexicon-test-service-at-context.xml"})
@Transactional
public class SampleService_AT {

    @Autowired
    SampleService sampleService;

    @Test
    public void findSampleTypes_results_wildcard() throws Exception {
        final List<OrionSample> samples = sampleService.findSampleTypes("Bud*");
        assertNotNull(samples);
        assertFalse(samples.isEmpty());
    }

    @Test
    public void findSampleTypes_results_exactMatch() throws Exception {
        final List<OrionSample> samples = sampleService.findSampleTypes("Bloom");
        assertNotNull(samples);
        assertFalse(samples.isEmpty());
    }

    @Test
    public void findSampleTypes_noResults() throws Exception {
        final List<OrionSample> samples = sampleService.findSampleTypes("asdf");
        assertNotNull(samples);
        assertTrue(samples.isEmpty());
    }
}
