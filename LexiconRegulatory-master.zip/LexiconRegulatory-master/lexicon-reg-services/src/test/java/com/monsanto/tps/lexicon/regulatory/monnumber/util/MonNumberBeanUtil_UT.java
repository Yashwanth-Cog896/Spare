package com.monsanto.tps.lexicon.regulatory.monnumber.util;

import com.monsanto.tps.lexicon.commercialtrait.ComlTraitName;
import com.monsanto.tps.lexicon.commercialtrait.ComlTraitType;
import com.monsanto.tps.lexicon.monnumber.MonNumber;
import com.monsanto.tps.lexicon.monnumber.MonNumberConstruct;
import com.monsanto.tps.lexicon.monnumber.ProteinName;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Crop;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: gdleon
 * Date: Apr 24, 2009
 * Time: 2:33:45 PM
 * To change this template use File | Settings | File Templates.
 */
public class MonNumberBeanUtil_UT
{
   private MonNumberBeanUtil monNumberBeanUtil;
   private Crop crop;

   @Before
   public void before() {
      monNumberBeanUtil = new MonNumberBeanUtil();
      crop = new Crop();
      crop.setCropName("CORN");
      crop.setCropPubkey("1015");
   }

   @Test
   public void testBuildMonNumber_BuildsCorrectly() {
      com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber monNumber =
         new com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber();
      monNumber.setActiveStatus(true);
      monNumber.setCrop(crop);
      monNumber.setEvent("Event");
      monNumber.setJvNumber("JvNumber");
      monNumber.setLocked(false);
      monNumber.setMaterialName("MatName");
      monNumber.setMonNumber("MonNum");
      monNumber.setMonNumberId(1234);
      monNumber.setOecdNumber("OecdNum");
      monNumber.setOecdNumberCommunicationDate(new Timestamp(System.currentTimeMillis()));
      monNumber.setPreviousNames("PrevNames");
      monNumber.setRegulatedStatus(false);
      monNumber.setRegulatoryGenesPresent("n");
      monNumber.setTransformationBackground("TB");
      monNumber.setRegulatoryParentalLine("RPL");

      com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName proteinName =
         new com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName();
      Set<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName> proteinNames =
         new HashSet<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName>();
      proteinNames.add(proteinName);
      proteinName.setActiveStatus(true);
      proteinName.setOrigSourceOrganism("OSO");
      proteinName.setProteinDescription("PROTDESC");
      proteinName.setProteinName("PROTNAME");
      proteinName.setProteinNameId(1111);
      proteinName.setProteinNamePubkey("PROTPUBKEY");
      monNumber.setProteinNames(proteinNames);

      com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType comlTraitType =
         new com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType();
      Set<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType> comlTraitTypes =
         new HashSet<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType>();
      comlTraitTypes.add(comlTraitType);
      comlTraitType.setComlTraitTypeAbbr("CTTABBR");
      comlTraitType.setComlTraitTypeDesc("CTTDESC");
      comlTraitType.setComlTraitTypeId(321);
      monNumber.setComlTraitTypes(comlTraitTypes);

      com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName comlTraitName =
         new com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName();
      comlTraitName.setTraitAbbr("CTTABBR");
      comlTraitName.setTraitDesc("CTTDESC");
      comlTraitName.setComlTraitNameId(321);
      com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Company company =
         new com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Company();
      company.setActive("y");
      company.setCompanyName("companyName");
      company.setCompanyPubkey("1111");
      company.setCompetitor("competitor");
      comlTraitName.setCompany(company);
      Set<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName> comlTraitNames =
         new HashSet<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName>();
      comlTraitNames.add(comlTraitName);
      monNumber.setComlTraitNames(comlTraitNames);

      com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumberConstruct construct =
         new com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumberConstruct();
      Set<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumberConstruct> constructs =
         new HashSet<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumberConstruct>();
      constructs.add(construct);
      construct.setConstructName("CNAME");
      construct.setMonNumber(monNumber);
      construct.setMonNumberConstructId(2222);
      construct.setPvCode("PVCODE");
      monNumber.setMonNumberConstructs(constructs);

      MonNumber resultMonNumber = monNumberBeanUtil.buildMonNumber(monNumber);

      assertEquals(monNumber.isActiveStatus(), resultMonNumber.isActiveStatus());
      assertEquals("CORN", resultMonNumber.getCropName());
      assertEquals(monNumber.getCrop().getCropPubkey(), resultMonNumber.getCropPubkey());
      assertEquals(monNumber.getEvent(), resultMonNumber.getEvent());
      assertEquals(monNumber.getJvNumber(), resultMonNumber.getJvNumber());
      assertEquals(monNumber.isLocked(), resultMonNumber.isLocked());
      assertEquals(monNumber.getMaterialName(), resultMonNumber.getMaterialName());
      assertEquals(monNumber.getMonNumber(), resultMonNumber.getMonNumber());
      assertEquals(monNumber.getOecdNumber(), resultMonNumber.getOecdNumber());
      assertEquals(monNumber.getOecdNumberCommunicationDate(), resultMonNumber.getOecdNumberCommunicationDate());
      assertEquals(monNumber.getPreviousNames(), resultMonNumber.getPreviousNames());
      assertEquals(monNumber.isRegulatedStatus(), resultMonNumber.isRegulatedStatus());
      assertEquals(monNumber.getRegulatoryGenesPresent(), resultMonNumber.getRegulatoryGenesPresent());
      assertEquals(monNumber.getTransformationBackground(), resultMonNumber.getTransformationBackground());
      assertEquals(monNumber.getRegulatoryParentalLine(), resultMonNumber.getRegulatoryParentalLine());

      assertEquals(1, resultMonNumber.getProteinNames().size());
      ProteinName resultProteinName = resultMonNumber.getProteinNames().iterator().next();
      assertEquals(proteinName.getProteinName(), resultProteinName.getProteinName());
      assertEquals(proteinName.getProteinNamePubkey(), resultProteinName.getProteinNamePubkey());

      assertEquals(1, resultMonNumber.getComlTraitTypes().size());
      ComlTraitType resultComlTraitType = resultMonNumber.getComlTraitTypes().iterator().next();
      assertEquals(comlTraitType.getComlTraitTypeAbbr(), resultComlTraitType.getComlTraitTypeAbbr());
      assertEquals(comlTraitType.getComlTraitTypeDesc(), resultComlTraitType.getComlTraitTypeDesc());

      assertEquals(1, resultMonNumber.getComlTraitNames().size());
      ComlTraitName resultComlTraitName = resultMonNumber.getComlTraitNames().iterator().next();
      assertEquals(comlTraitName.getTraitAbbr(), resultComlTraitName.getTraitAbbr());
      assertEquals(comlTraitName.getTraitDesc(), resultComlTraitName.getTraitDesc());

      assertEquals(1, resultMonNumber.getMonNumberConstructs().size());
      MonNumberConstruct resultConstruct = resultMonNumber.getMonNumberConstructs().iterator().next();
      assertEquals(construct.getConstructName(), resultConstruct.getConstructName());
      assertEquals(construct.getPvCode(), resultConstruct.getPvCode());
   }

   @Test
   public void testBuildMonNumber_EmptyChildrenHandledProperly() {
      com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber monNumber =
         new com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber();
      Set<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber> monNumbers =
         new HashSet<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber>();
      monNumbers.add(monNumber);
      monNumber.setActiveStatus(true);
      monNumber.setCrop(crop);
      monNumber.setEvent("Event");
      monNumber.setJvNumber("JvNumber");
      monNumber.setLocked(false);
      monNumber.setMaterialName("MatName");
      monNumber.setMonNumber("MonNum");
      monNumber.setMonNumberId(1234);
      monNumber.setOecdNumber("OecdNum");
      monNumber.setOecdNumberCommunicationDate(new Timestamp(System.currentTimeMillis()));
      monNumber.setPreviousNames("PrevNames");
      monNumber.setRegulatedStatus(false);
      monNumber.setRegulatoryGenesPresent("n");
      monNumber.setTransformationBackground("TB");
      monNumber.setRegulatoryParentalLine("RPL");
      monNumber.setProteinNames(new HashSet<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName>());
      monNumber.setComlTraitTypes(new HashSet<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType>());
      monNumber.setMonNumberConstructs(new HashSet<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumberConstruct>());
      monNumber.setComlTraitNames(new HashSet<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName>());

      MonNumber resultMonNumber = monNumberBeanUtil.buildMonNumber(monNumber);

      assertEquals(monNumber.isActiveStatus(), resultMonNumber.isActiveStatus());
      assertEquals("CORN", resultMonNumber.getCropName());
      assertEquals(monNumber.getCrop().getCropPubkey(), resultMonNumber.getCropPubkey());
      assertEquals(monNumber.getEvent(), resultMonNumber.getEvent());
      assertEquals(monNumber.getJvNumber(), resultMonNumber.getJvNumber());
      assertEquals(monNumber.isLocked(), resultMonNumber.isLocked());
      assertEquals(monNumber.getMaterialName(), resultMonNumber.getMaterialName());
      assertEquals(monNumber.getMonNumber(), resultMonNumber.getMonNumber());
      assertEquals(monNumber.getOecdNumber(), resultMonNumber.getOecdNumber());
      assertEquals(monNumber.getOecdNumberCommunicationDate(), resultMonNumber.getOecdNumberCommunicationDate());
      assertEquals(monNumber.getPreviousNames(), resultMonNumber.getPreviousNames());
      assertEquals(monNumber.isRegulatedStatus(), resultMonNumber.isRegulatedStatus());
      assertEquals(monNumber.getRegulatoryGenesPresent(), resultMonNumber.getRegulatoryGenesPresent());
      assertEquals(monNumber.getTransformationBackground(), resultMonNumber.getTransformationBackground());
      assertEquals(monNumber.getRegulatoryParentalLine(), resultMonNumber.getRegulatoryParentalLine());

      assertEquals(0, resultMonNumber.getProteinNames().size());
      assertEquals(0, resultMonNumber.getComlTraitTypes().size());
      assertEquals(0, resultMonNumber.getComlTraitNames().size());
      assertEquals(0, resultMonNumber.getMonNumberConstructs().size());
   }

   @Test
   public void testBuildMonNumbers_BuildCorrectly() {
      com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber monNumber1 =
         new com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber();
      com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber[] monNumbers =
         new com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber[2];
      monNumbers[0] = monNumber1;
      monNumber1.setActiveStatus(true);
      monNumber1.setCrop(crop);
      monNumber1.setEvent("Event");
      monNumber1.setJvNumber("JvNumber");
      monNumber1.setLocked(false);
      monNumber1.setMaterialName("MatName");
      monNumber1.setMonNumber("MonNum");
      monNumber1.setMonNumberId(1234);
      monNumber1.setOecdNumber("OecdNum");
      monNumber1.setOecdNumberCommunicationDate(new Timestamp(System.currentTimeMillis()));
      monNumber1.setPreviousNames("PrevNames");
      monNumber1.setRegulatedStatus(false);
      monNumber1.setRegulatoryGenesPresent("n");
      monNumber1.setTransformationBackground("TB");
      monNumber1.setRegulatoryParentalLine("RPL");
      monNumber1.setProteinNames(new HashSet<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName>());
      monNumber1.setComlTraitTypes(new HashSet<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType>());
      monNumber1.setMonNumberConstructs(new HashSet<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumberConstruct>());

      com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber monNumber2 =
         new com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber();
      monNumbers[1] = monNumber2;
      monNumber2.setActiveStatus(false);
      Crop crop2 = new Crop();
      crop2.setCropName("SOYBEANS");
      crop2.setCropPubkey("1415");
      monNumber2.setCrop(crop2);
      monNumber2.setEvent("Event2");
      monNumber2.setJvNumber("JvNumber2");
      monNumber2.setLocked(true);
      monNumber2.setMaterialName("MatName2");
      monNumber2.setMonNumber("MonNum2");
      monNumber2.setMonNumberId(12342);
      monNumber2.setOecdNumber("OecdNum2");
      monNumber2.setOecdNumberCommunicationDate(new Timestamp(System.currentTimeMillis()));
      monNumber2.setPreviousNames("PrevNames2");
      monNumber2.setRegulatedStatus(true);
      monNumber2.setRegulatoryGenesPresent("y");
      monNumber2.setTransformationBackground("TB2");
      monNumber2.setRegulatoryParentalLine("RPL2");
      monNumber2.setProteinNames(new HashSet<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName>());
      monNumber2.setComlTraitTypes(new HashSet<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType>());
      monNumber2.setMonNumberConstructs(new HashSet<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumberConstruct>());
      MonNumber[] resultMonNumbers = monNumberBeanUtil.buildMonNumbers(monNumbers);
      assertEquals(monNumbers[0].isActiveStatus(), resultMonNumbers[0].isActiveStatus());
      assertEquals("CORN", resultMonNumbers[0].getCropName());
      assertEquals(monNumbers[0].getCrop().getCropPubkey(), resultMonNumbers[0].getCropPubkey());
      assertEquals(monNumbers[0].getEvent(), resultMonNumbers[0].getEvent());
      assertEquals(monNumbers[0].getJvNumber(), resultMonNumbers[0].getJvNumber());
      assertEquals(monNumbers[0].isLocked(), resultMonNumbers[0].isLocked());
      assertEquals(monNumbers[0].getMaterialName(), resultMonNumbers[0].getMaterialName());
      assertEquals(monNumbers[0].getMonNumber(), resultMonNumbers[0].getMonNumber());
      assertEquals(monNumbers[0].getOecdNumber(), resultMonNumbers[0].getOecdNumber());
      assertEquals(monNumbers[0].getOecdNumberCommunicationDate(), resultMonNumbers[0].getOecdNumberCommunicationDate());
      assertEquals(monNumbers[0].getPreviousNames(), resultMonNumbers[0].getPreviousNames());
      assertEquals(monNumbers[0].isRegulatedStatus(), resultMonNumbers[0].isRegulatedStatus());
      assertEquals(monNumbers[0].getRegulatoryGenesPresent(), resultMonNumbers[0].getRegulatoryGenesPresent());
      assertEquals(monNumbers[0].getTransformationBackground(), resultMonNumbers[0].getTransformationBackground());
      assertEquals(monNumbers[0].getRegulatoryParentalLine(), resultMonNumbers[0].getRegulatoryParentalLine());

      assertEquals(0, resultMonNumbers[0].getProteinNames().size());
      assertEquals(0, resultMonNumbers[0].getComlTraitTypes().size());
      assertEquals(0, resultMonNumbers[0].getMonNumberConstructs().size());
      assertEquals(0, resultMonNumbers[0].getComlTraitNames().size());

      assertEquals(monNumbers[1].isActiveStatus(), resultMonNumbers[1].isActiveStatus());
      assertEquals("SOYBEANS", resultMonNumbers[1].getCropName());
      assertEquals(monNumbers[1].getCrop().getCropPubkey(), resultMonNumbers[1].getCropPubkey());
      assertEquals(monNumbers[1].getEvent(), resultMonNumbers[1].getEvent());
      assertEquals(monNumbers[1].getJvNumber(), resultMonNumbers[1].getJvNumber());
      assertEquals(monNumbers[1].isLocked(), resultMonNumbers[1].isLocked());
      assertEquals(monNumbers[1].getMaterialName(), resultMonNumbers[1].getMaterialName());
      assertEquals(monNumbers[1].getMonNumber(), resultMonNumbers[1].getMonNumber());
      assertEquals(monNumbers[1].getOecdNumber(), resultMonNumbers[1].getOecdNumber());
      assertEquals(monNumbers[1].getOecdNumberCommunicationDate(), resultMonNumbers[1].getOecdNumberCommunicationDate());
      assertEquals(monNumbers[1].getPreviousNames(), resultMonNumbers[1].getPreviousNames());
      assertEquals(monNumbers[1].isRegulatedStatus(), resultMonNumbers[1].isRegulatedStatus());
      assertEquals(monNumbers[1].getRegulatoryGenesPresent(), resultMonNumbers[1].getRegulatoryGenesPresent());
      assertEquals(monNumbers[1].getTransformationBackground(), resultMonNumbers[1].getTransformationBackground());
      assertEquals(monNumbers[1].getRegulatoryParentalLine(), resultMonNumbers[1].getRegulatoryParentalLine());

      assertEquals(0, resultMonNumbers[1].getProteinNames().size());
      assertEquals(0, resultMonNumbers[1].getComlTraitTypes().size());
      assertEquals(0, resultMonNumbers[1].getMonNumberConstructs().size());
      assertEquals(0, resultMonNumbers[1].getComlTraitNames().size());

   }
}
