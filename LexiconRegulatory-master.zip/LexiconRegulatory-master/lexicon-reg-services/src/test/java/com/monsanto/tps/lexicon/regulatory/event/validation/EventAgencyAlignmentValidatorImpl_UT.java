package com.monsanto.tps.lexicon.regulatory.event.validation;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tps.lexicon.event.EventAgencyAlignmentRequest;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Crop;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;
import com.monsanto.tps.lexicon.regulatory.event.queryset.EventSearchServiceQuerySet;
import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;

/**
 * rrchak1 - Feb 5, 2009 4:11:34 PM
 */
public class EventAgencyAlignmentValidatorImpl_UT {
    EventAgencyAlignmentValidatorImpl eventAgencyAlignmentValidator;
    private EventSearchServiceQuerySet eventSearchServiceQuerySet;
    private static final String CROP_NAME = "Corn";
    private static final String EVENT = "some event";

    @Before
    public void before() {
        eventAgencyAlignmentValidator = new EventAgencyAlignmentValidatorImpl();
        eventSearchServiceQuerySet = EasyMock.createMock(EventSearchServiceQuerySet.class);
        eventAgencyAlignmentValidator.setEventSearchServiceQuerySet(eventSearchServiceQuerySet);
    }

    @Test
    public void validateSuccessWithNonExistentEventAgencyAlignment()
            throws WrappingException {
        EventAgencyAlignmentRequest eventAgencyAlignmentRequest = new EventAgencyAlignmentRequest();
        eventAgencyAlignmentRequest.setEvent(EVENT);
        eventAgencyAlignmentRequest.setCrop(CROP_NAME);
        String agencyPubkey = "1111";
        EasyMock.expect(eventSearchServiceQuerySet.findEventAgencyAlignmentsByEventCropAndAgencyPubkey(EVENT, CROP_NAME, agencyPubkey))
                .andReturn(null);
        replay(eventSearchServiceQuerySet);
        eventAgencyAlignmentValidator.valiateAgencyAlignedToEventAndCrop(agencyPubkey, eventAgencyAlignmentRequest);
        verify(eventSearchServiceQuerySet);
    }

    @Test
    public void validateThrowsExceptionWhenItFindsEventAgencyAlignmentExists() {
        String agencyPubkey = "1111";
        EasyMock.expect(eventSearchServiceQuerySet.findEventAgencyAlignmentsByEventCropAndAgencyPubkey(EVENT, CROP_NAME, agencyPubkey))
                .andReturn(new EventAgencyAlignment());
        replay(eventSearchServiceQuerySet);
        try {
            EventAgencyAlignmentRequest eventAgencyAlignmentRequest = new EventAgencyAlignmentRequest();
            eventAgencyAlignmentRequest.setEvent(EVENT);
            eventAgencyAlignmentRequest.setCrop(CROP_NAME);
            eventAgencyAlignmentValidator.valiateAgencyAlignedToEventAndCrop(agencyPubkey, eventAgencyAlignmentRequest);
            Assert.fail("Should not have come here");
        } catch (WrappingException e) {
            Assert.assertEquals("EventAgencyAlignment already exists", e.getMessage());
        } finally {
            verify(eventSearchServiceQuerySet);
        }
    }

    @Test
    public void validateByPubkeySuccessfulWithExistingEventAgencyAlignment()
            throws WrappingException {
        EventAgencyAlignment expectedAlignment = new EventAgencyAlignment();
        expectedAlignment.setMaterialName(EVENT);
        Crop crop = new Crop();
        crop.setCropName(CROP_NAME);
        expectedAlignment.setCrop(crop);
        String[] eventAgencyAlignmentPubkey = new String[]{"1111"};
        EventAgencyAlignment[] expected = new EventAgencyAlignment[]{expectedAlignment};
        EasyMock.expect(eventSearchServiceQuerySet.findEventAgencyAlignmentByPubkey(EasyMock.aryEq(eventAgencyAlignmentPubkey)))
                .andReturn(expected);
        replay(eventSearchServiceQuerySet);
        EventAgencyAlignment actual = eventAgencyAlignmentValidator.validateAlignmentExists("1111");
        verify(eventSearchServiceQuerySet);
        Assert.assertNotNull(actual);
        Assert.assertEquals(expectedAlignment.getMaterialName(), actual.getMaterialName());
        Assert.assertEquals(expectedAlignment.getCrop().getCropName(), actual.getCrop().getCropName());
    }

    @Test
    public void validateByPubkeyThrowsExceptionWhenItDoesNotFindEventAgencyAlignment()
            throws WrappingException {
        String[] eventAgencyAlignmentPubkey = new String[]{"1111"};
        EasyMock.expect(eventSearchServiceQuerySet.findEventAgencyAlignmentByPubkey(EasyMock.aryEq(eventAgencyAlignmentPubkey)))
                .andReturn(null);
        replay(eventSearchServiceQuerySet);
        try {
            eventAgencyAlignmentValidator.validateAlignmentExists("1111");
            Assert.fail("Should not have come here");
        } catch (WrappingException e) {
            Assert.assertEquals("EventAgencyAlignment does not exist", e.getMessage());
        } finally {
            verify(eventSearchServiceQuerySet);
        }
    }
}