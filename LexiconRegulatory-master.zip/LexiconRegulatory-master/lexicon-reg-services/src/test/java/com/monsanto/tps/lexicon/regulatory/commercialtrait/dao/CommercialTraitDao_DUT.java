/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.commercialtrait.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.HibernateAssertTestUtil;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.LexiconDataUnitTestCase;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.TestDataBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitStack;
import org.hibernate.Session;
import org.junit.Test;

import javax.annotation.Resource;
import java.util.HashSet;
import java.util.List;

import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.assertTrue;

/* vvkalu - 7/27/11 */
public class CommercialTraitDao_DUT extends LexiconDataUnitTestCase {

    @Resource
    private CommercialTraitDao commercialTraitDao;

    @Test
    public void test_TypeDescs() throws Exception {
        List<String> typeDescs = commercialTraitDao.getComTraitTypeDescByComlTraitStackId(1001);
        assertNotNull(typeDescs);
        assertTrue(typeDescs.contains("Herbicide Tolerant"));
        assertTrue(typeDescs.contains("Insect Protected"));
        assertTrue(typeDescs.contains("Transgenic"));
    }

    @Test
    public void test_ComlTraitStackById() throws Exception {
        Session session = lexiconSessionFactory.getCurrentSession();
        ComlTraitStack comlTraitStack = new ComlTraitStack();
        comlTraitStack.setComlTraitStackId(TestDataBuilder.generateRandomNegativeLong());
        comlTraitStack.setCrop(TestDataBuilder.buildLexiconCrop(session, null));
        comlTraitStack.setComlTraitStackPubkey(TestDataBuilder.generateRandomNumberString(20));
        comlTraitStack.setPreComlInd(false);
        comlTraitStack.setManfTraitCode("DUT");
        comlTraitStack.setStackAbbr(TestDataBuilder.generateRandomNumberString(50));
        comlTraitStack.setStackDesc(TestDataBuilder.generateRandomNumberString(50));
        comlTraitStack.setReportingName(TestDataBuilder.generateRandomNumberString(50));
        comlTraitStack.setComlTraitNames(new HashSet<ComlTraitName>());
        session.save(comlTraitStack);
        session.flush();
        session.clear();

        ComlTraitStack comlTraitStackDB = commercialTraitDao.getComlTraitStackById(comlTraitStack.getComlTraitStackId());
        assertNotNull(comlTraitStackDB);
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(comlTraitStack, comlTraitStackDB);
    }

}