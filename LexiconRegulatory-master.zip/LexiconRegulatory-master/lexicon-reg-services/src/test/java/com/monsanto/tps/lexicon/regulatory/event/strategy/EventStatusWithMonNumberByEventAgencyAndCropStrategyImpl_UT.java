package com.monsanto.tps.lexicon.regulatory.event.strategy;

import com.monsanto.tps.lexicon.event.EventDeregulationStatusWithMonNumber;
import com.monsanto.tps.lexicon.monnumber.MonNumberInfo;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;
import com.monsanto.tps.lexicon.regulatory.event.dao.EventAgencyAlignmentDao;
import com.monsanto.tps.lexicon.regulatory.event.delegate.EventSplitter;
import com.monsanto.tps.lexicon.regulatory.event.delegate.EventStatusWithMonNumberBuilder;
import com.monsanto.tps.lexicon.regulatory.monnumber.dao.MonNumberDao;
import org.apache.commons.lang.ArrayUtils;
import static org.easymock.EasyMock.expect;
import org.easymock.classextension.EasyMock;
import static org.easymock.classextension.EasyMock.*;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * rrchak1 - Jun 23, 2009 11:18:09 AM
 */
public class EventStatusWithMonNumberByEventAgencyAndCropStrategyImpl_UT
{

   EventStatusWithMonNumberByEventAgencyAndCropStrategy eventStatusByEventAgencyAndCropStrategy;
   private EventAgencyAlignmentDao eventAgencyAlignmentDao;
   private MonNumberDao monNumberDao;
   private EventSplitter eventSplitter;

   private String EVENT = "EVENT";
   private String USDA_AGENCY = "USDA";
   private String cropName = "CANOLA";
   private String MON_NUMBER = "MON_NUMBER";
   private EventStatusWithMonNumberBuilder eventStatusBuilder;

   @Before
   public void before() {
      eventAgencyAlignmentDao = createMock(EventAgencyAlignmentDao.class);
      monNumberDao = createMock(MonNumberDao.class);
      eventStatusBuilder = createMock(EventStatusWithMonNumberBuilder.class);
      eventSplitter = new EventSplitter();
      eventStatusByEventAgencyAndCropStrategy = new EventStatusWithMonNumberByEventAgencyAndCropStrategyImpl(
         eventAgencyAlignmentDao, monNumberDao, eventStatusBuilder,eventSplitter);
   }

   @Test
   public void test_find() {
      String[] events = new String[]{EVENT};
      String[] agencyAbbrs = new String[]{USDA_AGENCY};
      EventAgencyAlignment eventAgencyAlignment = new EventAgencyAlignment();
      EventAgencyAlignment[] agencyAlignments = new EventAgencyAlignment[]{eventAgencyAlignment};
      MonNumberInfo monNumberInfo = new MonNumberInfo();
      final List<MonNumberInfo> monNumberInfos = Arrays.asList(monNumberInfo);
      expect(monNumberDao.findByEventsAndCrop(aryEq(events), EasyMock.eq(cropName))).andReturn(monNumberInfos);
      expect(eventAgencyAlignmentDao.findByEventsCropAndAgencyAbbrs(aryEq(events), eq(cropName), aryEq(agencyAbbrs))).andReturn(agencyAlignments);
      EventDeregulationStatusWithMonNumber eventDeregulationStatus = new EventDeregulationStatusWithMonNumber();
      List<EventDeregulationStatusWithMonNumber> expected = new ArrayList<EventDeregulationStatusWithMonNumber>();
      expected.add(eventDeregulationStatus);
      expect(eventStatusBuilder.build(agencyAlignments,monNumberInfos,cropName)).andReturn(expected);
      replay(eventAgencyAlignmentDao);
      replay(eventStatusBuilder);
      replay(monNumberDao);
      EventDeregulationStatusWithMonNumber[] actuals = eventStatusByEventAgencyAndCropStrategy.find(
         events, cropName, agencyAbbrs);
      verify(eventAgencyAlignmentDao);
      verify(eventStatusBuilder);
      assertThat(actuals.length, is(1));
   }

   @Test
   public void test_find_CallsDaoMultipletimes_IfRequestCountExceedsMaximumAllowedCount_TestFixed() {
      String[] events = buildEvents("EVENT", 2000);
      String[] agencyAbbrs = new String[]{USDA_AGENCY};
      EventAgencyAlignment eventAgencyAlignment = new EventAgencyAlignment();
      EventAgencyAlignment[] agencyAlignments = new EventAgencyAlignment[]{eventAgencyAlignment};
      MonNumberInfo monNumberInfo = new MonNumberInfo();
      monNumberInfo.setEvent("EVENT");
      monNumberInfo.setMonNumber("MON_NUMBER");
      final List<MonNumberInfo> monNumberInfos = Arrays.asList(monNumberInfo);
      expect(monNumberDao.findByEventsAndCrop(aryEq((String[]) ArrayUtils.subarray(events, 0, 1000)), EasyMock.eq(cropName))).andReturn(monNumberInfos);
      expect(monNumberDao.findByEventsAndCrop(aryEq((String[]) ArrayUtils.subarray(events, 1000,2000)), EasyMock.eq(cropName))).andReturn(monNumberInfos);
      expect(eventAgencyAlignmentDao.findByEventsCropAndAgencyAbbrs(aryEq((String[]) ArrayUtils.subarray(events, 0, 1000)), eq(cropName), aryEq(agencyAbbrs))).andReturn(agencyAlignments);
      expect(eventAgencyAlignmentDao.findByEventsCropAndAgencyAbbrs(aryEq((String[]) ArrayUtils.subarray(events, 1000, 2000)), eq(cropName), aryEq(agencyAbbrs))).andReturn(agencyAlignments);
      replay(eventAgencyAlignmentDao);
      EventDeregulationStatusWithMonNumber eventDeregulationStatus = new EventDeregulationStatusWithMonNumber();
      List<EventDeregulationStatusWithMonNumber> expected = new ArrayList<EventDeregulationStatusWithMonNumber>();
      expected.add(eventDeregulationStatus);
      expect(eventStatusBuilder.build(agencyAlignments, monNumberInfos,cropName)).andReturn(expected).times(2);
      replay(eventStatusBuilder);
      replay(monNumberDao);
      EventDeregulationStatusWithMonNumber[] actuals = eventStatusByEventAgencyAndCropStrategy.find(
         events, cropName, agencyAbbrs);
      verify(eventAgencyAlignmentDao);
      verify(eventStatusBuilder);
      verify(monNumberDao);
      assertThat(actuals.length, is(2));
   }

   @Test
   public void test_find_CallsDaoMultipletimes_IfRequestCountExceedsMaximumAllowedCount_TestBoundry_Below() {
      String[] events = buildEvents("EVENT", 1999);
      String[] agencyAbbrs = new String[]{USDA_AGENCY};
      MonNumberInfo monNumberInfo = new MonNumberInfo();
      monNumberInfo.setEvent("EVENT");
      monNumberInfo.setMonNumber("MON_NUMBER");
      final List<MonNumberInfo> monNumberInfos = Arrays.asList(monNumberInfo);
      expect(monNumberDao.findByEventsAndCrop(aryEq((String[]) ArrayUtils.subarray(events, 0, 1000)), EasyMock.eq(cropName))).andReturn(monNumberInfos);
      expect(monNumberDao.findByEventsAndCrop(aryEq((String[]) ArrayUtils.subarray(events, 1000,2000)), EasyMock.eq(cropName))).andReturn(monNumberInfos);
      EventAgencyAlignment eventAgencyAlignment = new EventAgencyAlignment();
      EventAgencyAlignment[] agencyAlignments = new EventAgencyAlignment[]{eventAgencyAlignment};
      expect(eventAgencyAlignmentDao.findByEventsCropAndAgencyAbbrs(aryEq((String[]) ArrayUtils.subarray(events, 0, 1000)), eq(cropName), aryEq(agencyAbbrs))).andReturn(agencyAlignments);
      expect(eventAgencyAlignmentDao.findByEventsCropAndAgencyAbbrs(aryEq((String[]) ArrayUtils.subarray(events, 1000, 2000)), eq(cropName), aryEq(agencyAbbrs))).andReturn(agencyAlignments);
      replay(eventAgencyAlignmentDao);
      replay(monNumberDao);
      EventDeregulationStatusWithMonNumber eventDeregulationStatus = new EventDeregulationStatusWithMonNumber();
      List<EventDeregulationStatusWithMonNumber> expected = new ArrayList<EventDeregulationStatusWithMonNumber>();
      expected.add(eventDeregulationStatus);
      expect(eventStatusBuilder.build(agencyAlignments,monNumberInfos, cropName)).andReturn(expected).times(2);
      replay(eventStatusBuilder);
      EventDeregulationStatusWithMonNumber[] actuals = eventStatusByEventAgencyAndCropStrategy.find(
         events, cropName, agencyAbbrs);
      verify(eventAgencyAlignmentDao);
      verify(eventStatusBuilder);
      verify(monNumberDao);
      assertThat(actuals.length, is(2));
   }

   @Test
   public void test_find_CallsDaoMultipletimes_IfRequestCountExceedsMaximumAllowedCount_TestBoundry_Above() {
      String[] events = buildEvents("EVENT", 2001);
      String[] agencyAbbrs = new String[]{USDA_AGENCY};
      MonNumberInfo monNumberInfo = new MonNumberInfo();
      monNumberInfo.setEvent("EVENT");
      monNumberInfo.setMonNumber("MON_NUMBER");
      List<MonNumberInfo> monNumberInfos = Arrays.asList(monNumberInfo);
      EventAgencyAlignment eventAgencyAlignment = new EventAgencyAlignment();
      EventAgencyAlignment[] agencyAlignments = new EventAgencyAlignment[]{eventAgencyAlignment};
      expect(monNumberDao.findByEventsAndCrop(aryEq((String[]) ArrayUtils.subarray(events, 0, 1000)), EasyMock.eq(cropName))).andReturn(monNumberInfos);
      expect(monNumberDao.findByEventsAndCrop(aryEq((String[]) ArrayUtils.subarray(events, 1000,2000)), EasyMock.eq(cropName))).andReturn(monNumberInfos);
      expect(monNumberDao.findByEventsAndCrop(aryEq((String[]) ArrayUtils.subarray(events, 2000,2001)), EasyMock.eq(cropName))).andReturn(monNumberInfos);
      replay(monNumberDao);


      expect(eventAgencyAlignmentDao.findByEventsCropAndAgencyAbbrs(aryEq((String[]) ArrayUtils.subarray(events, 0, 1000)), eq(cropName), aryEq(agencyAbbrs))).andReturn(agencyAlignments);
      expect(eventAgencyAlignmentDao.findByEventsCropAndAgencyAbbrs(aryEq((String[]) ArrayUtils.subarray(events, 1000, 2000)), eq(cropName), aryEq(agencyAbbrs))).andReturn(agencyAlignments);
      expect(eventAgencyAlignmentDao.findByEventsCropAndAgencyAbbrs(aryEq((String[]) ArrayUtils.subarray(events, 2000, 2001)), eq(cropName), aryEq(agencyAbbrs))).andReturn(agencyAlignments);
      replay(eventAgencyAlignmentDao);

      EventDeregulationStatusWithMonNumber eventDeregulationStatus = new EventDeregulationStatusWithMonNumber();
      List<EventDeregulationStatusWithMonNumber> expected = new ArrayList<EventDeregulationStatusWithMonNumber>();
      expected.add(eventDeregulationStatus);
      expect(eventStatusBuilder.build(agencyAlignments, monNumberInfos,cropName)).andReturn(expected).times(3);
      replay(eventStatusBuilder);
      EventDeregulationStatusWithMonNumber[] actuals = eventStatusByEventAgencyAndCropStrategy.find(
         events, cropName, agencyAbbrs);
      verify(eventAgencyAlignmentDao);
      verify(eventStatusBuilder);
      verify(monNumberDao);
      assertThat(actuals.length, is(3));
   }


   private String[] buildEvents(String eventPrefix, int count) {
      List<String> list = new ArrayList<String>();
      for (int i = 0; i < count; i++) {
         list.add(eventPrefix + "_" + i);
      }
      return list.toArray(new String[list.size()]);
   }


}
