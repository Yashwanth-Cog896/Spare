package com.monsanto.tps.lexicon.regulatory.chemicalname.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.DBUnitTest;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ChemicalName;
import com.monsanto.tps.springframework.test.listener.dbunit.DataSet;
import com.monsanto.tps.springframework.test.listener.dbunit.DatasetOperation;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Comparator;
import java.util.List;

import static com.google.common.collect.Ordering.from;
import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/1/12
 * Time: 7:47 PM
 * To change this template use File | Settings | File Templates.
 */
@DataSet(
        schema = "LEXICON", dataSourceKey = "dataSource", setupOperation = DatasetOperation.CLEAN_INSERT, teardownOperation = DatasetOperation.NONE,
        value = {"/com/monsanto/tps/lexicon/regulatory/chemicalname/dao/chemical_name.xml"}
)
public class ChemicalNameDAOImpl_UT extends DBUnitTest {

    @Autowired
    private ChemicalNameDAO chemicalNameDAO;

    @Test
    public void findChemicalName_results_wildcard() throws Exception {
        final List<ChemicalName> chemicalNames = chemicalNameDAO.findChemicalNames("Tri%");
        assertNotNull(chemicalNames);
        assertFalse(chemicalNames.isEmpty());
    }

    @Test
    public void findChemicalName_results_exactMatch() throws Exception {
        final List<ChemicalName> chemicalNames = chemicalNameDAO.findChemicalNames("tryptophan");
        assertNotNull(chemicalNames);
        assertFalse(chemicalNames.isEmpty());
    }

    @Test
    public void findChemicalName_noResults() throws Exception {
        final List<ChemicalName> chemicalNames = chemicalNameDAO.findChemicalNames("asdf");
        assertNotNull(chemicalNames);
        assertTrue(chemicalNames.isEmpty());
    }

    @Test
    public void findChemicalName_results_active() throws Exception {
        final List<ChemicalName> chemicalNames = chemicalNameDAO.findChemicalNames("");
        assertNotNull(chemicalNames);
        assertFalse(chemicalNames.isEmpty());

        for (ChemicalName chemicalName : chemicalNames) {
            assertTrue(chemicalName.getActiveStatus());
        }
    }

    @Test
    public void findChemicalName_sorted() throws Exception {
        final List<ChemicalName> chemicalNames = chemicalNameDAO.findChemicalNames("%");
        assertNotNull(chemicalNames);

        assertTrue(from(new ChemicalNameComparator()).isOrdered(chemicalNames));
    }

    private class ChemicalNameComparator implements Comparator<ChemicalName> {

        public final int compare(ChemicalName c1, ChemicalName c2) {

            int ctCompare = 0;

            if (c1 != null && c2 != null) {
                String ct1 = c1.getMaterialName();
                String ct2 = c2.getMaterialName();
                if (ct1 != null && ct2 != null) {
                    ctCompare = ct1.compareToIgnoreCase(ct2);
                }
            }

            return ctCompare;
        }
    }
}

