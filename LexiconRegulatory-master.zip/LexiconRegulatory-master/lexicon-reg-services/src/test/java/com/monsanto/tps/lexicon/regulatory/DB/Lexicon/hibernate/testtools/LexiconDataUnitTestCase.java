package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools;

import com.monsanto.tcc.lexiconcommon.db.test.LexiconTestTools;
import com.monsanto.tps.lexicon.regulatory.audit.dao.AuditStagingDao;

import org.hibernate.SessionFactory;
import org.junit.Before;

import javax.annotation.Resource;

/**
 * nbwald - Sep 11, 2008 12:12:44 PM
 */
public abstract class LexiconDataUnitTestCase extends LexiconSpringContextTests {

   @Resource
   private AuditStagingDao auditStagingDao;

   @Resource(name = "sessionFactory")
   public SessionFactory lexiconSessionFactory ;

   @Before
   public  void onSetUpInTransaction() throws Exception {
      TestSessions.setLexiconSessionFactory(lexiconSessionFactory);
      insertAuditStaging();
   }

   private void insertAuditStaging() {
      auditStagingDao.create(
         LexiconTestTools.UNIT_TEST_USER_LOGIN_ID,
         LexiconTestTools.UNIT_TEST_PROCESS_NAME,
         LexiconTestTools.UNIT_TEST_AUDIT_COMMENT,
         LexiconTestTools.UNIT_TEST_AUDIT_REQUESTOR);
   }
}
