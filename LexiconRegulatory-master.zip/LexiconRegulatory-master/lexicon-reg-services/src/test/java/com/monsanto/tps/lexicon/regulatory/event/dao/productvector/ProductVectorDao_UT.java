package com.monsanto.tps.lexicon.regulatory.event.dao.productvector;

import com.monsanto.tps.compliance.referencedata.services.ProductVectorLookupService;
import org.easymock.EasyMock;
import static org.easymock.EasyMock.*;
import org.junit.Before;
import org.junit.Test;

/**
 * rrchak1 - Apr 24, 2009 11:15:15 AM
 */
public class ProductVectorDao_UT
{
   ProductVectorLookupService productVectorLookupService;
   ProductVectorDaoImpl productVectorDao;
   private static final String PMON_TWO = "PMON_TWO";
   private static final String PMON_ONE = "PMON_ONE";
   private static final long CROP_PUBKEY = 1015;

   @Before
   public void before() {
      productVectorLookupService =
         EasyMock.createMock(ProductVectorLookupService.class);
      productVectorDao = new ProductVectorDaoImpl();
      productVectorDao.setProductVectorLookupService(productVectorLookupService);
   }

   @Test
   public void productVectorDaoCallsFCM_productVectorLookupService_ForCombined() {
      String[] constructNames = new String[]{PMON_ONE, PMON_TWO};
      expect(productVectorLookupService.findProductVectorsByCropIdAndConstructNameForCombinedConstructs(CROP_PUBKEY, constructNames)).andReturn(null);
      replay(productVectorLookupService);
      productVectorDao.findProductVectorsByCropIdAndConstructNameForCombinedConstructs(CROP_PUBKEY, constructNames);
      verify(productVectorLookupService);
   }

   @Test
   public void productVectorDaoCallsFCM_productVectorLookupService_ForSingle() {
      expect(productVectorLookupService.findProductVectorsByCropIdAndConstructNameForSingleConstructs(CROP_PUBKEY, PMON_ONE)).andReturn(null);
      replay(productVectorLookupService);
      productVectorDao.findProductVectorsByCropIdAndConstructNameForSingleConstructs(CROP_PUBKEY, PMON_ONE);
      verify(productVectorLookupService);
   }

}
