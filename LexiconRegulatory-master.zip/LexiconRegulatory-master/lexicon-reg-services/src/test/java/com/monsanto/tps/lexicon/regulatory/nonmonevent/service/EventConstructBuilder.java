package com.monsanto.tps.lexicon.regulatory.nonmonevent.service;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.tcc.lexiconcommon.db.test.MidasTestTools;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.BuilderID;
import com.monsanto.tps.lexicon.regulatory.DB.midas.MidasBoolean;

/**
 * nbwald - May 21, 2009 4:05:11 PM
 */
public class EventConstructBuilder
{
   private final long eventConstructId;
   private String eventName;
   private String constructName;
   private long midasCropId;
   private boolean active;

   public EventConstructBuilder() {
      BuilderID builderId = new BuilderID();
      this.eventConstructId = builderId.id();
      this.active = true;
   }

   public EventConstructBuilder withEventName(String eventName) {
      this.eventName = eventName;
      return this;
   }

   public EventConstructBuilder withConstructName(String constructName) {
      this.constructName = constructName;
      return this;
   }


   public EventConstructBuilder withCrop(long midasCropId) {
      this.midasCropId = midasCropId;
      return this;
   }

   public EventConstructBuilder inactive() {
      this.active = false;
      return this;
   }

   public void create(PersistentStoreConnection midasConn)
      throws WrappingException
   {
      MidasTestTools.insertFakeEventConstruct(midasConn, eventConstructId, eventName, constructName, midasCropId, new MidasBoolean(active).getDatabaseRepresentation());
   }
}
