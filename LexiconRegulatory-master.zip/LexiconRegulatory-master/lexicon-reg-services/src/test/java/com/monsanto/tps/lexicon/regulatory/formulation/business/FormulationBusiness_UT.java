package com.monsanto.tps.lexicon.regulatory.formulation.business;

import com.monsanto.tps.lexicon.formulation.OrionFormulation;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.FormulationType;
import com.monsanto.tps.lexicon.regulatory.formulation.business.FormulationBusiness;
import com.monsanto.tps.lexicon.regulatory.formulation.dao.FormulationDAO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 3/5/12
 * Time: 1:52 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class FormulationBusiness_UT {

    @Mock
    private FormulationDAO formulationDAO;

    @InjectMocks
    private FormulationBusiness formulationBusiness = new FormulationBusiness();

    private final List<FormulationType> singleFormulationListFromDAO;
    private final List<FormulationType> multiFormulationListFromDAO;
    private static final List<FormulationType> emptyListFromDAO = new ArrayList<FormulationType>();

    private final List<OrionFormulation> singleFormulationListFromBusiness;
    private final List<OrionFormulation> multiFormulationListFromBusiness;
    private static final List<OrionFormulation> emptyListFromBusiness = new ArrayList<OrionFormulation>();

    public FormulationBusiness_UT() {
        singleFormulationListFromDAO = new ArrayList<FormulationType>();
        singleFormulationListFromDAO.add(new FormulationType("type", "formulation", true));

        multiFormulationListFromDAO = new ArrayList<FormulationType>();
        multiFormulationListFromDAO.add(new FormulationType("type1", "formulation1", true));
        multiFormulationListFromDAO.add(new FormulationType("type2", "formulation2", false));

        singleFormulationListFromBusiness = new ArrayList<OrionFormulation>();
        singleFormulationListFromBusiness.add(new OrionFormulation("type", "formulation", true));

        multiFormulationListFromBusiness = new ArrayList<OrionFormulation>();
        multiFormulationListFromBusiness.add(new OrionFormulation("type1", "formulation1", true));
        multiFormulationListFromBusiness.add(new OrionFormulation("type2", "formulation2", false));
    }

    @Test
    public void findFormulationTypes_findNone() throws Exception {

        when(formulationDAO.findFormulationTypes("asdf")).thenReturn(emptyListFromDAO);

        final List<OrionFormulation> actualFormulations = formulationBusiness.findFormulationTypes("asdf");

        checkFormulationLists(actualFormulations, emptyListFromBusiness);
    }

    @Test
    public void findFormulationTypes_findSingle() throws Exception {

        when(formulationDAO.findFormulationTypes("TB")).thenReturn(singleFormulationListFromDAO);

        final List<OrionFormulation> actualFormulations = formulationBusiness.findFormulationTypes("TB");

        checkFormulationLists(actualFormulations, singleFormulationListFromBusiness);
    }

    @Test
    public void findFormulationTypes_findByWildcard() throws Exception {

        when(formulationDAO.findFormulationTypes("S%")).thenReturn(multiFormulationListFromDAO);

        final List<OrionFormulation> actualFormulations = formulationBusiness.findFormulationTypes("S*");

        checkFormulationLists(actualFormulations, multiFormulationListFromBusiness);
    }

    @Test
    public void findFormulationTypes_findAll() throws Exception {

        when(formulationDAO.findFormulationTypes("%")).thenReturn(multiFormulationListFromDAO);

        final List<OrionFormulation> actualFormulations = formulationBusiness.findFormulationTypes("");

        checkFormulationLists(actualFormulations, multiFormulationListFromBusiness);
    }

    private void checkFormulationLists(final List<OrionFormulation> actualFormulations, final List<OrionFormulation> singleFormulationListFromBusiness) {
        assertNotNull(actualFormulations);

        for(int i=0; i<singleFormulationListFromBusiness.size(); i++) {
            final OrionFormulation formulation = actualFormulations.get(i);
            assertEquals(formulation.getFormulationType(), singleFormulationListFromBusiness.get(i).getFormulationType());
            assertEquals(formulation.getFormulationTypeDescription(), singleFormulationListFromBusiness.get(i).getFormulationTypeDescription());
            assertEquals(formulation.getActiveStatus(), singleFormulationListFromBusiness.get(i).getActiveStatus());
        }
    }
}

