package com.monsanto.tps.lexicon.regulatory.additionalmaterial.service;

import com.monsanto.tps.lexicon.additionalmaterialinfo.AdditionalMaterialService;
import com.monsanto.tps.lexicon.additionalmaterialinfo.OrionAdditionalMaterial;
import com.monsanto.tps.lexicon.regulatory.additionalmaterialinfo.business.AdditionalMaterialBusiness;
import com.monsanto.tps.lexicon.regulatory.additionalmaterialinfo.service.AdditionalMaterialServiceImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/1/12
 * Time: 7:47 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class AdditionalMaterialServiceImpl_UT {

    @Mock
    private AdditionalMaterialBusiness additionalMaterialBusiness;

    @InjectMocks
    private AdditionalMaterialService additionalMaterialService = new AdditionalMaterialServiceImpl();

    private static final List<OrionAdditionalMaterial> additionalMaterialList = new ArrayList<OrionAdditionalMaterial>();

    @Test
    public void findAdditionalMaterial_success() throws Exception {
        when(additionalMaterialBusiness.findAdditionalMaterials("tri*")).thenReturn(additionalMaterialList);

        final List<OrionAdditionalMaterial> actualAdditionalMaterials = additionalMaterialBusiness.findAdditionalMaterials("triasulfuron");

        assertEquals(actualAdditionalMaterials, additionalMaterialList);
    }
}
