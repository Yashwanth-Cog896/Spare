package com.monsanto.tps.lexicon.regulatory.agency.service;

import com.monsanto.tps.lexicon.agency.AgencySaveUpdateRequest;
import com.monsanto.tps.lexicon.agency.AgencySaveUpdateResponse;
import com.monsanto.tps.lexicon.regulatory.util.validationresults.ValidationResults;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import org.junit.Test;

/**
 * aagosw - Mar 10, 2009 2:45:47 PM
 */
public class AgencySaveUpdateResponseBuilderImpl_UT
{
   @Test
   public void testBuildResponseBuildsCorrectly() {
      AgencySaveUpdateResponseBuilder builder = new AgencySaveUpdateResponseBuilderImpl();
      AgencySaveUpdateRequest request = new AgencySaveUpdateRequest();
      request.setAgencyAbbr("abbr1");
      request.setAgencyDeptAbbr("deptabbr1");
      request.setCountryIsoCode("country1");
      ValidationResults results = new ValidationResults(new String[]{"error1"});
      AgencySaveUpdateResponse response = builder.buildResponse(request, results);
      assertThat(response.getAgencyAbbvr(), is("abbr1"));
      assertThat(response.getDeptAbbvr(), is("deptabbr1"));
      assertThat(response.getAgencyCountryIsoCode(), is("country1"));
      assertThat(response.isSuccessful(), is(false));
      assertThat(response.getMessages()[0], is("Error: error1"));
   }
}
