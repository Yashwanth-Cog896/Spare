/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitStack;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Company;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Country;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Crop;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.LexiconBrandEntity;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.LexiconStageEntity;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MaterialChemicalName;
import com.monsanto.tps.lexicon.regulatory.DB.midas.model.LineTypeEntity;
import com.monsanto.tps.lexicon.regulatory.DB.midas.model.MidasCropEntity;
import com.monsanto.tps.lexicon.regulatory.DB.midas.model.ProgramEntity;
import org.hibernate.Session;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Random;

/* vvkalu - 7/25/11 */
public class TestDataBuilder {

    public static LineTypeEntity buildLineType(Session session) {
        LineTypeEntity lineType = new LineTypeEntity();
        lineType.setId(generateRandomNegativeLong());
        lineType.setRefId(generateRandomNumberString(20));
        lineType.setName(generateRandomNumberString(50));
        lineType.setPedEngineRefId(generateRandomNumberString(20));
        lineType.setRefActive(true);
        session.save(lineType);
        return lineType;
    }

    public static MidasCropEntity buildMidasCrop(Session session) {
        MidasCropEntity cropEntity = new MidasCropEntity();
        cropEntity.setId(generateRandomNegativeLong());
        cropEntity.setName(generateRandomNumberString(50));
        cropEntity.setGenusSpecies(generateRandomNumberString(2));
        cropEntity.setRefActive(true);
        cropEntity.setRemCropId(true);
        cropEntity.setRmIncrement(new BigDecimal(new BigInteger("46778"), 2));
        cropEntity.setRmMin(new BigDecimal(new BigInteger("601"), 1));
        cropEntity.setRmMax(new BigDecimal(new BigInteger("1001"), 1));
        session.save(cropEntity);
        return cropEntity;
    }

    public static Crop buildLexiconCrop(Session session, String cropName) {
        Crop cropEntity = new Crop();
        cropEntity.setCropId(generateRandomNegativeLong());
        cropEntity.setCropName(cropName == null ? generateRandomNumberString(50) : cropName);
        cropEntity.setMajorCrop("n");
        cropEntity.setCropPubkey(generateRandomNumberString(8));
        cropEntity.setRegulatoryCrop("n");
        cropEntity.setStageCategoryId(1);
        cropEntity.setAbbreviation("ZM");
        session.save(cropEntity);
        return cropEntity;
    }

    public static ProgramEntity buildProgramEntity(Session session) {
        ProgramEntity programEntity = new ProgramEntity();
        programEntity.setCrop(buildMidasCrop(session));
        programEntity.setId(generateRandomNegativeLong());
        programEntity.setMidasProgram(true);
        programEntity.setName(generateRandomNumberString(50));
        programEntity.setRefActive(true);
        programEntity.setRefId(generateRandomNumberString(3));
        session.save(programEntity);
        return programEntity;
    }

    public static LexiconStageEntity buildLexiconStage(Session session) {
        LexiconStageEntity stageEntity = new LexiconStageEntity();
        stageEntity.setComlStage(false);
        stageEntity.setStageAbbr(generateRandomNumberString(4));
        stageEntity.setStageDesc(generateRandomNumberString(50));
        stageEntity.setId(generateRandomNegativeLong());
        stageEntity.setStagePubkey(generateRandomNumberString(20));
        stageEntity.setOrderByNum(generateRandomNegativeLong());
        session.save(stageEntity);
        return stageEntity;
    }

    public static LexiconBrandEntity buildLexiconBrand(Session session) {
        LexiconBrandEntity brandEntity = new LexiconBrandEntity();
        brandEntity.setActive(true);
        brandEntity.setBrandAbbr(generateRandomNumberString(20));
        brandEntity.setId(generateRandomNegativeLong());
        brandEntity.setBrandName(generateRandomNumberString(50));
        brandEntity.setBrandPubkey(generateRandomNumberString(20));
        brandEntity.setTdRestricted(false);
        brandEntity.setCompany(buildLexiconCompany(session));
        session.save(brandEntity);
        return brandEntity;
    }

    public static Company buildLexiconCompany(Session session) {
        Company company = new Company();
        company.setActive("y");
        company.setCompanyId(generateRandomNegativeLong());
        company.setCompanyName(generateRandomNumberString(50));
        company.setCompanyPubkey(generateRandomNumberString(20));
        company.setCompetitor("n");
        session.save(company);
        return company;
    }

    public static Country buildLexiconCountry(Session session) {
        Country country = new Country();
        country.setCountryId(generateRandomNegativeLong());
        country.setCountryPubkey(generateRandomNumberString(20));
        country.setCountryAbbr(generateRandomNumberString(3));
        country.setCountryName(generateRandomNumberString(80));
        country.setIsoCode(generateRandomNumberString(2));
        country.setUnCode(890);
        session.save(country);
        return country;
    }

    public static ComlTraitStack buildComlTraitStack(Session session) {
        ComlTraitStack comlTraitStack = new ComlTraitStack();
        comlTraitStack.setComlTraitStackId(generateRandomNegativeLong());
        comlTraitStack.setComlTraitStackPubkey(generateRandomNumberString(20));
        comlTraitStack.setStackDesc(generateRandomNumberString(50));
        comlTraitStack.setStackAbbr(generateRandomNumberString(50));
        comlTraitStack.setCrop(buildLexiconCrop(session, null));
        comlTraitStack.setPreComlInd(false);
        session.save(comlTraitStack);
        return comlTraitStack;
    }

    public static MaterialChemicalName buildChemicalName(Session session, String name) {
        MaterialChemicalName chemicalName = new MaterialChemicalName();
        chemicalName.setChemicalNameId(generateRandomNegativeLong());
        chemicalName.setChemicalName(name);
        chemicalName.setProdId(generateRandomNegativeLong());
        chemicalName.setExpertlInd("F");
        session.save(chemicalName);
        return chemicalName;
    }

    public static Long generateRandomNegativeLong() {
        return -Math.abs(new Random().nextLong());
    }

    public static String generateRandomNumberString(int maxLength) {
        Random random = new Random();
        StringBuilder sb = new StringBuilder(maxLength);
        for (int x = 0; x < maxLength; x++) {
            sb.append(random.nextInt(10));
        }
        return sb.toString();
    }
}