package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Country;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

/**
 * nbwald - Aug 27, 2008 3:51:38 PM
 */
public class CountryBuilder
{
   public static Country usa() {
      return findCountryByAbbreviation("USA");
   }

   public static Country japan() {
      return findCountryByAbbreviation("JPN");
   }

   private static Country findCountryByAbbreviation(String countryAbbreviation) {
      Criteria criteria = TestSessions.getLexiconSession().createCriteria(Country.class).add(Restrictions.eq("countryAbbr", countryAbbreviation));
      return (Country) criteria.uniqueResult();
   }
}
