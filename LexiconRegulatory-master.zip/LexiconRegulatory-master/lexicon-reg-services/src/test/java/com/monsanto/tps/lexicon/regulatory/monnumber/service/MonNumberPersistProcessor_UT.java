package com.monsanto.tps.lexicon.regulatory.monnumber.service;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.lexiconcommon.ArrayUtils;
import com.monsanto.tps.lexicon.event.Construct;
import com.monsanto.tps.lexicon.monnumber.MonNumberSaveRequest;
import com.monsanto.tps.lexicon.monnumber.MonNumberSaveResponse;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Crop;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumberConstruct;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName;
import com.monsanto.tps.lexicon.regulatory.commercialtrait.dao.CommercialTraitDao;
import com.monsanto.tps.lexicon.regulatory.crop.dao.CropDao;
import com.monsanto.tps.lexicon.regulatory.monnumber.dao.MonNumberDao;
import static junit.framework.Assert.assertEquals;
import static org.easymock.EasyMock.*;
import org.easymock.IAnswer;
import org.easymock.classextension.EasyMock;
import static org.easymock.classextension.EasyMock.replay;
import static org.easymock.classextension.EasyMock.verify;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import org.junit.Before;
import org.junit.Test;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.validation.Validator;

import java.io.IOException;
import java.util.Date;

/**
 * rrchak1 - Jun 1, 2009 2:46:18 PM
 */
public class MonNumberPersistProcessor_UT
{
   Validator monNumberSaveRequestValidator;
   Validator monNumberUpdateRequestValidator;
   MonNumberPersistProcessor monNumberPersistProcessor;
   EventConstructProcessor eventConstructProcessor;
   MonNumberDao monNumberDao;
   String objectName = "MonNumberSaveRequest";
   private String cropPubkey = "1015";
   private String event = "UT_EVENT";
   private String proteinNamePubkey = "1234";
   private String traitAbbr = "traitAbbr";
   private String traitTypeAbbr = "traitTypeAbbr";
   private String auditComment = "auditComment";
   private String auditRequestor = "requestor";
   private String monNumberVal = "MON 99999";
   private String genes = "genes";
   private String construct = "UT_CONS";
   private String transformationBk = "trans_bk";
   private String pvCode = "pvCode";
   CropDao cropDao;
   CommercialTraitDao commercialTraitDao;

   @Before
   public void before() {
      monNumberPersistProcessor = new MonNumberPersistProcessor();
      monNumberSaveRequestValidator = EasyMock.createMock(Validator.class);
      monNumberUpdateRequestValidator = EasyMock.createMock(Validator.class);
      monNumberDao = EasyMock.createMock(MonNumberDao.class);
      cropDao = EasyMock.createMock(CropDao.class);
      eventConstructProcessor = EasyMock.createMock(EventConstructProcessor.class);
      commercialTraitDao = EasyMock.createMock(CommercialTraitDao.class);
      monNumberPersistProcessor.setMonNumberSaveRequestValidator(monNumberSaveRequestValidator);
      monNumberPersistProcessor.setMonNumberUpdateRequestValidator(monNumberUpdateRequestValidator);
      monNumberPersistProcessor.setEventConstructProcessor(eventConstructProcessor);
      monNumberPersistProcessor.setMonNumberDao(monNumberDao);
      monNumberPersistProcessor.setCommercialTraitDao(commercialTraitDao);
      monNumberPersistProcessor.setCropDao(cropDao);
   }

   @Test
   public void processSave_ReturnsErrorMessagesForValidationErrors_WillNotCallSave()
      throws Exception
   {
      MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
      MonNumberSaveResponse monNumberSaveResponse = new MonNumberSaveResponse();
      BindException errors = new BindException(monNumberSaveRequest, objectName);
      monNumberSaveRequestValidator.validate(monNumberSaveRequest, errors);
      expectLastCall().andAnswer(new IAnswer()
      {
         @Override
         public Object answer()
            throws Throwable
         {
            Object[] arguments = EasyMock.getCurrentArguments();
            BindException errors = (BindException) arguments[1];
            errors.addError(new FieldError("MonNumberSaveRequest", "", ""));
            return errors;
         }
      }
      );
      expect(eventConstructProcessor.processSaveEvent(isA(MonNumberSaveResponse.class), isA(BindException.class), eq(objectName), eq(monNumberSaveRequest))).andReturn(monNumberSaveResponse);
      replay(monNumberSaveRequestValidator);
      replay(eventConstructProcessor);
      replay(monNumberDao);
      monNumberSaveResponse = monNumberPersistProcessor.processSave(false, monNumberSaveRequest);
      verify(monNumberSaveRequestValidator);
      verify(eventConstructProcessor);
      verify(monNumberDao);
      assertFalse(monNumberSaveResponse.isSuccess());
      assertTrue(ArrayUtils.hasItems(monNumberSaveResponse.getMessages()));
   }

   @Test
   public void monNumberService_save_CallsAllsDependencies()
      throws IOException, WrappingException
   {
      MonNumberSaveResponse monNumberSaveResponse = new MonNumberSaveResponse();
      MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
      monNumberSaveRequest.setCropPubkey(cropPubkey);
      monNumberSaveRequest.setEvent(event);
      monNumberSaveRequest.setOecdNumberCommunicationDate(new Date());
      monNumberSaveRequest.setTraitTypeAbbreviations(new String[]{traitTypeAbbr});
      monNumberSaveRequest.setTraitNameAbbreviations(new String[]{traitAbbr});
      monNumberSaveRequest.setProteinNamePubkeys(new String[]{proteinNamePubkey});
      BindException errors = new BindException(monNumberSaveRequest, objectName);
      monNumberSaveRequestValidator.validate(monNumberSaveRequest, errors);
      expectLastCall();
      Construct constructObj = new Construct();
      constructObj.setPlasmidPMon(construct);
      monNumberSaveResponse.setEventConstructs(new Construct[]{constructObj});
      expect(eventConstructProcessor.processSaveEvent(isA(MonNumberSaveResponse.class),
         isA(BindException.class),
         eq(objectName),
         eq(monNumberSaveRequest))).andReturn(monNumberSaveResponse);

      expect(cropDao.findByPubkey(cropPubkey)).andReturn(new Crop());
      MonNumber monNumber = new MonNumber();
      expect(monNumberDao.save(isA(MonNumber.class))).andReturn(monNumber);
      expect(monNumberDao.saveMonNumberConstruct(isA(MonNumberConstruct.class))).andReturn(new MonNumberConstruct());
      expect(monNumberDao.findProteinNameByPubkey(proteinNamePubkey)).andReturn(new ProteinName());
      expect(commercialTraitDao.findCommercialTraitTypeByAbbr(traitTypeAbbr)).andReturn(new ComlTraitType());
      expect(commercialTraitDao.findCommercialTraitByAbbr(traitAbbr)).andReturn(new ComlTraitName());

      replay(monNumberSaveRequestValidator);
      replay(eventConstructProcessor);
      replay(cropDao);
      replay(monNumberDao);
      replay(commercialTraitDao);

      monNumberSaveResponse = monNumberPersistProcessor.processSave(false, monNumberSaveRequest);

      verify(monNumberSaveRequestValidator);
      verify(eventConstructProcessor);
      verify(cropDao);
      verify(monNumberDao);
      verify(commercialTraitDao);
      assertTrue(monNumberSaveResponse.isSuccess());
      assertFalse(ArrayUtils.hasItems(monNumberSaveResponse.getMessages()));
   }

   @Test
   public void monNumberService_save_EmptyProteinNamePubkeys_WillNotSaveMonNumberProtein()
      throws IOException, WrappingException
   {
      MonNumberSaveResponse monNumberSaveResponse = new MonNumberSaveResponse();
      MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
      monNumberSaveRequest.setCropPubkey(cropPubkey);
      monNumberSaveRequest.setEvent(event);
      monNumberSaveRequest.setOecdNumberCommunicationDate(new Date());
      monNumberSaveRequest.setTraitTypeAbbreviations(new String[]{traitTypeAbbr});
      monNumberSaveRequest.setTraitNameAbbreviations(new String[]{traitAbbr});
      BindException errors = new BindException(monNumberSaveRequest, objectName);
      monNumberSaveRequestValidator.validate(monNumberSaveRequest, errors);
      expectLastCall();
      Construct constructObj = new Construct();
      constructObj.setPlasmidPMon(construct);
      monNumberSaveResponse.setEventConstructs(new Construct[]{constructObj});
      expect(eventConstructProcessor.processSaveEvent(isA(MonNumberSaveResponse.class),
         isA(BindException.class),
         eq(objectName),
         eq(monNumberSaveRequest))).andReturn(monNumberSaveResponse);

      expect(cropDao.findByPubkey(cropPubkey)).andReturn(new Crop());
      MonNumber monNumber = new MonNumber();
      expect(monNumberDao.save(isA(MonNumber.class))).andReturn(monNumber);
      expect(monNumberDao.saveMonNumberConstruct(isA(MonNumberConstruct.class))).andReturn(new MonNumberConstruct());
      expect(commercialTraitDao.findCommercialTraitTypeByAbbr(traitTypeAbbr)).andReturn(new ComlTraitType());
      expect(commercialTraitDao.findCommercialTraitByAbbr(traitAbbr)).andReturn(new ComlTraitName());

      replay(monNumberSaveRequestValidator);
      replay(eventConstructProcessor);
      replay(cropDao);
      replay(monNumberDao);
      replay(commercialTraitDao);

      monNumberSaveResponse = monNumberPersistProcessor.processSave(false, monNumberSaveRequest);

      verify(monNumberSaveRequestValidator);
      verify(eventConstructProcessor);
      verify(cropDao);
      verify(monNumberDao);
      verify(commercialTraitDao);
      assertTrue(monNumberSaveResponse.isSuccess());
      assertFalse(ArrayUtils.hasItems(monNumberSaveResponse.getMessages()));
   }

   @Test
   public void monNumberService_save_EmptyTraitTypeAbbr_WillNotSaveMonNumberTraitType()
      throws IOException, WrappingException
   {
      MonNumberSaveResponse monNumberSaveResponse = new MonNumberSaveResponse();
      MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
      monNumberSaveRequest.setCropPubkey(cropPubkey);
      monNumberSaveRequest.setEvent(event);
      monNumberSaveRequest.setOecdNumberCommunicationDate(new Date());
      monNumberSaveRequest.setTraitNameAbbreviations(new String[]{traitAbbr});
      BindException errors = new BindException(monNumberSaveRequest, objectName);
      monNumberSaveRequestValidator.validate(monNumberSaveRequest, errors);
      expectLastCall();
      Construct constructObj = new Construct();
      constructObj.setPlasmidPMon(construct);
      monNumberSaveResponse.setEventConstructs(new Construct[]{constructObj});
      expect(eventConstructProcessor.processSaveEvent(isA(MonNumberSaveResponse.class), isA(BindException.class), eq(objectName), eq(monNumberSaveRequest))).andReturn(monNumberSaveResponse);
      expect(cropDao.findByPubkey(cropPubkey)).andReturn(new Crop());
      MonNumber monNumber = new MonNumber();
      expect(monNumberDao.save(isA(MonNumber.class))).andReturn(monNumber);
      expect(monNumberDao.saveMonNumberConstruct(isA(MonNumberConstruct.class))).andReturn(new MonNumberConstruct());
      expect(commercialTraitDao.findCommercialTraitByAbbr(traitAbbr)).andReturn(new ComlTraitName());

      replay(monNumberSaveRequestValidator);
      replay(eventConstructProcessor);
      replay(cropDao);
      replay(monNumberDao);
      replay(commercialTraitDao);

      monNumberSaveResponse = monNumberPersistProcessor.processSave(false, monNumberSaveRequest);

      verify(monNumberSaveRequestValidator);
      verify(eventConstructProcessor);
      verify(cropDao);
      verify(monNumberDao);
      verify(commercialTraitDao);
      assertTrue(monNumberSaveResponse.isSuccess());
      assertFalse(ArrayUtils.hasItems(monNumberSaveResponse.getMessages()));
   }

   @Test
   public void monNumberService_save_EmptyTraitNameAbbr_WillNotSaveMonNumberTraitName()
      throws IOException, WrappingException
   {
      MonNumberSaveResponse monNumberSaveResponse = new MonNumberSaveResponse();
      MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
      monNumberSaveRequest.setCropPubkey(cropPubkey);
      monNumberSaveRequest.setEvent(event);
      monNumberSaveRequest.setOecdNumberCommunicationDate(new Date());
      monNumberSaveRequest.setTraitTypeAbbreviations(new String[]{traitTypeAbbr});
      BindException errors = new BindException(monNumberSaveRequest, objectName);
      monNumberSaveRequestValidator.validate(monNumberSaveRequest, errors);
      expectLastCall();
      Construct constructObj = new Construct();
      constructObj.setPlasmidPMon(construct);
      monNumberSaveResponse.setEventConstructs(new Construct[]{constructObj});
      expect(eventConstructProcessor.processSaveEvent(isA(MonNumberSaveResponse.class), isA(BindException.class), eq(objectName), eq(monNumberSaveRequest))).andReturn(monNumberSaveResponse);
      expect(cropDao.findByPubkey(cropPubkey)).andReturn(new Crop());
      MonNumber monNumber = new MonNumber();
      expect(monNumberDao.save(isA(MonNumber.class))).andReturn(monNumber);
      expect(monNumberDao.saveMonNumberConstruct(isA(MonNumberConstruct.class))).andReturn(new MonNumberConstruct());
      expect(commercialTraitDao.findCommercialTraitTypeByAbbr(traitTypeAbbr)).andReturn(new ComlTraitType());

      replay(monNumberSaveRequestValidator);
      replay(eventConstructProcessor);
      replay(cropDao);
      replay(monNumberDao);
      replay(commercialTraitDao);

      monNumberSaveResponse = monNumberPersistProcessor.processSave(false, monNumberSaveRequest);

      verify(monNumberSaveRequestValidator);
      verify(eventConstructProcessor);
      verify(cropDao);
      verify(monNumberDao);
      verify(commercialTraitDao);
      assertTrue(monNumberSaveResponse.isSuccess());
      assertFalse(ArrayUtils.hasItems(monNumberSaveResponse.getMessages()));
   }

   @Test
   public void monNumberService_save_ValidateOnly_WillNotCallSave()
      throws IOException, WrappingException
   {
      MonNumberSaveResponse monNumberSaveResponse = new MonNumberSaveResponse();
      MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
      monNumberSaveRequest.setCropPubkey(cropPubkey);
      monNumberSaveRequest.setEvent(event);
      monNumberSaveRequest.setOecdNumberCommunicationDate(new Date());
      monNumberSaveRequest.setTraitTypeAbbreviations(new String[]{traitTypeAbbr});
      monNumberSaveRequest.setTraitNameAbbreviations(new String[]{traitAbbr});
      BindException errors = new BindException(monNumberSaveRequest, objectName);
      monNumberSaveRequestValidator.validate(monNumberSaveRequest, errors);
      expectLastCall();
      expect(eventConstructProcessor.processSaveEvent(isA(MonNumberSaveResponse.class), isA(BindException.class), eq(objectName), eq(monNumberSaveRequest))).andReturn(monNumberSaveResponse);
      replay(monNumberSaveRequestValidator);
      replay(eventConstructProcessor);
      replay(cropDao);
      replay(monNumberDao);
      replay(commercialTraitDao);
      monNumberSaveResponse = monNumberPersistProcessor.processSave(true, monNumberSaveRequest);
      verify(monNumberSaveRequestValidator);
      verify(eventConstructProcessor);
      verify(cropDao);
      verify(monNumberDao);
      verify(commercialTraitDao);
      assertTrue(monNumberSaveResponse.isSuccess());
      assertFalse(ArrayUtils.hasItems(monNumberSaveResponse.getMessages()));
   }

   @Test
   public void monNumberService_save_HasEventAndCropInRequest_ErrorFromEventLookup()
      throws IOException, WrappingException
   {
      MonNumberSaveResponse monNumberSaveResponse = new MonNumberSaveResponse();
      MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
      monNumberSaveRequest.setCropPubkey(cropPubkey);
      monNumberSaveRequest.setEvent(event);
      monNumberSaveRequest.setOecdNumberCommunicationDate(new Date());
      monNumberSaveRequest.setTraitTypeAbbreviations(new String[]{traitTypeAbbr});
      monNumberSaveRequest.setTraitNameAbbreviations(new String[]{traitAbbr});
      BindException errors = new BindException(monNumberSaveRequest, objectName);
      monNumberSaveRequestValidator.validate(monNumberSaveRequest, errors);
      expectLastCall();
      expect(eventConstructProcessor.processSaveEvent(isA(MonNumberSaveResponse.class),
         isA(BindException.class),
         eq(objectName),
         eq(monNumberSaveRequest)
      )).andAnswer(new IAnswer()
      {
         @Override
         public Object answer()
            throws Throwable
         {
            Object[] arguments = EasyMock.getCurrentArguments();
            BindException errors = (BindException) arguments[1];
            errors.addError(new FieldError(objectName, "event", "Invalid Event for Selected Crop."));
            MonNumberSaveResponse response = (MonNumberSaveResponse) arguments[0];
            return response;
         }
      }
      );
      replay(monNumberSaveRequestValidator);
      replay(eventConstructProcessor);
      replay(cropDao);
      replay(monNumberDao);
      replay(commercialTraitDao);
      monNumberSaveResponse = monNumberPersistProcessor.processSave(true, monNumberSaveRequest);
      verify(monNumberSaveRequestValidator);
      verify(eventConstructProcessor);
      verify(cropDao);
      verify(monNumberDao);
      verify(commercialTraitDao);
      assertFalse(monNumberSaveResponse.isSuccess());
      assertTrue(ArrayUtils.hasItems(monNumberSaveResponse.getMessages()));
      assertEquals("Invalid Event for Selected Crop.", monNumberSaveResponse.getMessages()[0]);
   }

   @Test
   public void processUpdate_ReturnsErrorMessagesForValidationErrors_WillNotUpdate()
      throws Exception
   {
      MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
      MonNumberSaveResponse monNumberSaveResponse = new MonNumberSaveResponse();
      MonNumber monNumber = new MonNumber();
      BindException errors = new BindException(monNumberSaveRequest, objectName);
      monNumberUpdateRequestValidator.validate(monNumberSaveRequest, errors);
      expectLastCall().andAnswer(new IAnswer()
      {
         @Override
         public Object answer()
            throws Throwable
         {
            Object[] arguments = EasyMock.getCurrentArguments();
            BindException errors = (BindException) arguments[1];
            errors.addError(new FieldError("MonNumberSaveRequest", "", ""));
            return errors;
         }
      }
      );
      expect(monNumberDao.find(null)).andReturn(monNumber);
      expect(eventConstructProcessor.processUpdateEvent(isA(MonNumberSaveResponse.class), isA(BindException.class), eq(objectName), eq(monNumber), eq(monNumberSaveRequest))).andReturn(monNumberSaveResponse);
      replay(monNumberUpdateRequestValidator);
      replay(eventConstructProcessor);
      replay(monNumberDao);
      monNumberSaveResponse = monNumberPersistProcessor.processUpdate(false, monNumberSaveRequest);
      verify(monNumberUpdateRequestValidator);
      verify(eventConstructProcessor);
      verify(monNumberDao);
      assertFalse(monNumberSaveResponse.isSuccess());
      assertTrue(ArrayUtils.hasItems(monNumberSaveResponse.getMessages()));
   }

   @Test
   public void processUpdate_DoesNotFindMonNumber_DoesNotProcessEvent_IfMonNumberValidatorErrors()
      throws Exception
   {
      MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
      MonNumberSaveResponse monNumberSaveResponse = new MonNumberSaveResponse();
      MonNumber monNumber = new MonNumber();
      BindException errors = new BindException(monNumberSaveRequest, objectName);
      monNumberUpdateRequestValidator.validate(monNumberSaveRequest, errors);
      expectLastCall().andAnswer(new IAnswer()
      {
         @Override
         public Object answer()
            throws Throwable
         {
            Object[] arguments = EasyMock.getCurrentArguments();
            BindException errors = (BindException) arguments[1];
            errors.addError(new FieldError("MonNumberSaveRequest", "monNumber", ""));
            return errors;
         }
      }
      );
      replay(monNumberUpdateRequestValidator);
      replay(eventConstructProcessor);
      replay(monNumberDao);
      monNumberSaveResponse = monNumberPersistProcessor.processUpdate(false, monNumberSaveRequest);
      verify(monNumberUpdateRequestValidator);
      verify(eventConstructProcessor);
      verify(monNumberDao);
      assertFalse(monNumberSaveResponse.isSuccess());
      assertTrue(ArrayUtils.hasItems(monNumberSaveResponse.getMessages()));
   }

   @Test
   public void processUpdate_ValidateOnly_WillNotUpdate()
      throws IOException, WrappingException
   {
      MonNumberSaveResponse monNumberSaveResponse = new MonNumberSaveResponse();
      MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
      monNumberSaveRequest.setCropPubkey(cropPubkey);
      monNumberSaveRequest.setEvent(event);
      monNumberSaveRequest.setOecdNumberCommunicationDate(new Date());
      monNumberSaveRequest.setTraitTypeAbbreviations(new String[]{traitTypeAbbr});
      monNumberSaveRequest.setTraitNameAbbreviations(new String[]{traitAbbr});
      MonNumber monNumber = new MonNumber();
      BindException errors = new BindException(monNumberSaveRequest, objectName);
      monNumberUpdateRequestValidator.validate(monNumberSaveRequest, errors);
      expectLastCall();
      expect(monNumberDao.find(null)).andReturn(monNumber);
      expect(eventConstructProcessor.processUpdateEvent(isA(MonNumberSaveResponse.class), isA(BindException.class), eq(objectName), eq(monNumber), eq(monNumberSaveRequest))).andReturn(monNumberSaveResponse);
      replay(monNumberUpdateRequestValidator);
      replay(eventConstructProcessor);
      replay(cropDao);
      replay(monNumberDao);
      replay(commercialTraitDao);
      monNumberSaveResponse = monNumberPersistProcessor.processUpdate(true, monNumberSaveRequest);
      verify(monNumberUpdateRequestValidator);
      verify(eventConstructProcessor);
      verify(cropDao);
      verify(monNumberDao);
      verify(commercialTraitDao);
      assertTrue(monNumberSaveResponse.isSuccess());
      assertFalse(ArrayUtils.hasItems(monNumberSaveResponse.getMessages()));
   }

}
