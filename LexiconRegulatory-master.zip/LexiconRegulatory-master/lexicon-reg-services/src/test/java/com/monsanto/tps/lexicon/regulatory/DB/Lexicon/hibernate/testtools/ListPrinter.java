/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools;

import java.util.List;

public class ListPrinter {

    private List dataList;

    public ListPrinter(List dataList) {
        this.dataList = dataList;
    }

    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append("[");
        for (Object item : dataList) {
            sb.append("{");
            if (item == null) {
                sb.append("null");
            } else {
                sb.append(item);
            }
            sb.append("}");
        }
        sb.append("]");
        return sb.toString();
    }
}