/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.DB.Midas.model;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.HibernateAssertTestUtil;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.LexiconAcceptanceTestCase;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.TestDataBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.midas.model.GermplasmEntity;
import com.monsanto.tps.lexicon.regulatory.DB.midas.model.ProductGermplasmEntity;
import org.junit.Test;

import java.util.ArrayList;

import static org.junit.Assert.assertFalse;

/* vvkalu - 7/25/11 */
public class GermplasmEntity_DUT extends LexiconAcceptanceTestCase {

    @Test
    public void testMapping() {
        GermplasmEntity germplasm = new GermplasmEntity();
        germplasm.setId(TestDataBuilder.generateRandomNegativeLong());
        germplasm.setEventDisplay(TestDataBuilder.generateRandomNumberString(20));
        germplasm.setDeleted(false);
        germplasm.setFinished(true);
        germplasm.setLinecode(TestDataBuilder.generateRandomNumberString(50));
        germplasm.setLineType(TestDataBuilder.buildLineType(currentSession));
        germplasm.setCrop(TestDataBuilder.buildMidasCrop(currentSession));
        germplasm.setOrigin(TestDataBuilder.generateRandomNumberString(50));
        germplasm.setOwnerProgram(TestDataBuilder.buildProgramEntity(currentSession));
        germplasm.setPedigree(TestDataBuilder.generateRandomNumberString(100));
        germplasm.setTransgenic(true);
        germplasm.setProductGermplasms(new ArrayList<ProductGermplasmEntity>());
        currentSession.save(germplasm);
        currentSession.flush();
        currentSession.clear();

        GermplasmEntity germplasmEntity = (GermplasmEntity) currentSession.get(GermplasmEntity.class, germplasm.getId());
        assertFalse(germplasm == germplasmEntity);
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(germplasm, germplasmEntity);
    }
}