package com.monsanto.tps.lexicon.regulatory.nonmonevent.validation;

import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import org.junit.Test;

/**
 * nbwald - May 21, 2009 6:15:13 PM
 */
public class EventHasSingleConstructRule_UT
{
   @Test
   public void testViolated_SingleConstructName_NotViolated()
      throws Exception
   {
      String[] constructNames = new String[]{"SOMETHING"};
      Rule<String> rule = new EventHasSingleConstructRule(constructNames);

      assertThat(rule.violated(), is(false));
   }

   @Test
   public void testViolated_NoConstructName_NotViolated()
      throws Exception
   {
      String[] constructNames = new String[0];
      Rule<String> rule = new EventHasSingleConstructRule(constructNames);

      assertThat(rule.violated(), is(false));
   }

   @Test
   public void testViolated_MultipleConstructNames_Violated()
      throws Exception
   {
      String[] constructNames = new String[]{"THING 1", "THING 2"};
      Rule<String> rule = new EventHasSingleConstructRule(constructNames);

      assertThat(rule.violated(), is(true));
   }

   @Test
   public void testGetViolation()
      throws Exception
   {
      assertThat(new EventHasSingleConstructRule().getViolation(), is("Event has multiple constructs."));
   }
}
