package com.monsanto.tps.lexicon.regulatory.geneticbackground.dao;

import com.monsanto.tps.lexicon.geneticbackground.OrionGeneticBackground;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.DBUnitTest;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.GeneticBackground;
import com.monsanto.tps.lexicon.regulatory.geneticbackground.dao.GeneticBackgroundDAO;
import com.monsanto.tps.springframework.test.listener.dbunit.DataSet;
import com.monsanto.tps.springframework.test.listener.dbunit.DatasetOperation;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.Comparator;
import java.util.List;

import static com.google.common.collect.Ordering.from;
import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/1/12
 * Time: 7:47 PM
 * To change this template use File | Settings | File Templates.
 */
@DataSet(
        schema = "LEXICON", dataSourceKey = "dataSource", setupOperation = DatasetOperation.CLEAN_INSERT, teardownOperation = DatasetOperation.NONE,
        value = {"/com/monsanto/tps/lexicon/regulatory/geneticbackground/dao/genetic_background.xml"}
)
public class GeneticBackgroundDAOImpl_DUT extends DBUnitTest {

    @Autowired
    private GeneticBackgroundDAO geneticBackgroundDAO;

    @Test
    public void findGeneticBackground_results_wildcard() throws Exception {
        final List<GeneticBackground> geneticBackgrounds = geneticBackgroundDAO.findGeneticBackgrounds("Con%");
        assertNotNull(geneticBackgrounds);
        assertFalse(geneticBackgrounds.isEmpty());
    }

    @Test
    public void findGeneticBackground_results_exactMatch() throws Exception {
        final List<GeneticBackground> geneticBackgrounds = geneticBackgroundDAO.findGeneticBackgrounds("Amidon");
        assertNotNull(geneticBackgrounds);
        assertFalse(geneticBackgrounds.isEmpty());
    }

    @Test
    public void findGeneticBackground_noResults() throws Exception {
        final List<GeneticBackground> geneticBackgrounds = geneticBackgroundDAO.findGeneticBackgrounds("asdf");
        assertNotNull(geneticBackgrounds);
        assertTrue(geneticBackgrounds.isEmpty());
    }

    @Test
    public void findGeneticBackground_results_active() throws Exception {
        final List<GeneticBackground> geneticBackgrounds = geneticBackgroundDAO.findGeneticBackgrounds("");
        assertNotNull(geneticBackgrounds);
        assertFalse(geneticBackgrounds.isEmpty());

        for (GeneticBackground geneticBackground : geneticBackgrounds) {
            assertTrue(geneticBackground.getActiveStatus());
        }
    }

    @Test
    public void findGeneticBackground_sorted() throws Exception {
        final List<GeneticBackground> geneticBackgrounds = geneticBackgroundDAO.findGeneticBackgrounds("%");
        assertNotNull(geneticBackgrounds);

        assertTrue(from(new GeneticBackgroundComparator()).isOrdered(geneticBackgrounds));
    }

    private class GeneticBackgroundComparator implements Comparator<GeneticBackground> {

        public final int compare(GeneticBackground c1, GeneticBackground c2) {

            int ctCompare = 0;

            if (c1 != null && c2 != null) {
                String ct1 = c1.getGeneticBackground();
                String ct2 = c2.getGeneticBackground();
                if (ct1 != null && ct2 != null) {
                    ctCompare = ct1.compareToIgnoreCase(ct2);
                }
            }

            return ctCompare;
        }
    }
}
