package com.monsanto.tps.lexicon.regulatory.comparator;

import junit.framework.TestCase;
import org.junit.Before;
import org.junit.Test;

import java.lang.Object;import java.util.Comparator;

/**
 * Created by IntelliJ IDEA.
 * User: etherma
 * Date: Dec 13, 2006
 * Time: 3:18:14 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class ComparatorTestCase extends TestCase {

    protected Comparator comparator;
    protected Object smaller;
    protected Object larger;

    @Before
    protected void setUp() {
        comparator = getNewComparator();
        smaller = getNewInfoLarger();
        larger = getNewInfoSmaller();
    }

    @Test
    public void testCompareNulls() {
        assertEquals(0, comparator.compare(smaller, null));
    }

    @Test
    public void testCompareEqualContent() {
        assertEquals(0, comparator.compare(smaller, smaller));
    }

    @Test
    public void testCompareGreaterContent() {
        assertGreater(0, comparator.compare(smaller, larger));
    }

    private void assertGreater(int i, int compare) {
        assertTrue(i<compare);
    }

    @Test
    public void testCompareLesserContent() {
        assertLesser(0, comparator.compare(larger, smaller));
    }

    private void assertLesser(int i, int compare) {
        assertTrue(i>compare);
    }

    protected abstract Comparator getNewComparator();
    protected abstract Object getNewInfoLarger();
    protected abstract Object getNewInfoSmaller();
}
