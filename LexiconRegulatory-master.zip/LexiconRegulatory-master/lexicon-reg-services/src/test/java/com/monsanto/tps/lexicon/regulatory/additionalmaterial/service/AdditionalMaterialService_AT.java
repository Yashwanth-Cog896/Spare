package com.monsanto.tps.lexicon.regulatory.additionalmaterial.service;

import com.monsanto.tps.lexicon.additionalmaterialinfo.AdditionalMaterialService;
import com.monsanto.tps.lexicon.additionalmaterialinfo.OrionAdditionalMaterial;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static junit.framework.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 6/11/12
 * Time: 3:55 PM
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:/com/monsanto/tps/lexicon/regulatory/contexts/lexicon-test-service-at-context.xml"})
@Transactional
public class AdditionalMaterialService_AT {

    @Autowired
    AdditionalMaterialService additionalMaterialService;

    @Test
    public void findAdditionalMaterial_results_wildcard() throws Exception {
        final List<OrionAdditionalMaterial> additionalMaterials = additionalMaterialService.findAdditionalMaterials("a*");
        assertNotNull(additionalMaterials);
        assertFalse(additionalMaterials.isEmpty());
    }

    @Test
    public void findAdditionalMaterial_results_exactMatch() throws Exception {
        final List<OrionAdditionalMaterial> additionalMaterials = additionalMaterialService.findAdditionalMaterials("triasulfuron");
        assertNotNull(additionalMaterials);
        assertFalse(additionalMaterials.isEmpty());
    }

    @Test
    public void findAdditionalMaterial_noResults() throws Exception {
        final List<OrionAdditionalMaterial> additionalMaterials = additionalMaterialService.findAdditionalMaterials("asdf");
        assertNotNull(additionalMaterials);
        assertTrue(additionalMaterials.isEmpty());
    }
}
