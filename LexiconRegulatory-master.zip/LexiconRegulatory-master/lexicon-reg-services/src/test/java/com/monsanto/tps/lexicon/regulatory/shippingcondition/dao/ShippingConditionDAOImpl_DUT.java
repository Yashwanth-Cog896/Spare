package com.monsanto.tps.lexicon.regulatory.shippingcondition.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.DBUnitTest;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ShippingCondition;
import com.monsanto.tps.lexicon.regulatory.shippingcondition.dao.ShippingConditionDAO;
import com.monsanto.tps.springframework.test.listener.dbunit.DataSet;
import com.monsanto.tps.springframework.test.listener.dbunit.DatasetOperation;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.Comparator;
import java.util.List;

import static com.google.common.collect.Ordering.from;
import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/1/12
 * Time: 7:47 PM
 * To change this template use File | Settings | File Templates.
 */

@DataSet(
        schema = "LEXICON", dataSourceKey = "dataSource", setupOperation = DatasetOperation.CLEAN_INSERT, teardownOperation = DatasetOperation.NONE,
        value = {"/com/monsanto/tps/lexicon/regulatory/shippingcondition/dao/shipping_condition.xml"}
)
public class ShippingConditionDAOImpl_DUT extends DBUnitTest {

    @Autowired
    private ShippingConditionDAO shippingConditionDAO;

    @Test
    public void findShippingCondition_results_wildcard() throws Exception {
        final List<ShippingCondition> shippingConditions = shippingConditionDAO.findShippingConditions("F%");
        assertNotNull(shippingConditions);
        assertFalse(shippingConditions.isEmpty());
    }

    @Test
    public void findShippingCondition_results_exactMatch() throws Exception {
        final List<ShippingCondition> shippingConditions = shippingConditionDAO.findShippingConditions("Cool on Ice");
        assertNotNull(shippingConditions);
        assertFalse(shippingConditions.isEmpty());
    }

    @Test
    public void findShippingCondition_noResults() throws Exception {
        final List<ShippingCondition> shippingConditions = shippingConditionDAO.findShippingConditions("asdf");
        assertNotNull(shippingConditions);
        assertTrue(shippingConditions.isEmpty());
    }

    @Test
    public void findShippingCondition_results_active() throws Exception {
        final List<ShippingCondition> shippingConditions = shippingConditionDAO.findShippingConditions("%");
        assertNotNull(shippingConditions);
        assertFalse(shippingConditions.isEmpty());

        for (ShippingCondition shippingCondition : shippingConditions) {
            assertTrue(shippingCondition.getActiveStatus());
        }
    }

    @Test
    public void findShippingCondition_sorted() throws Exception {
        final List<ShippingCondition> shippingConditions = shippingConditionDAO.findShippingConditions("%");
        assertNotNull(shippingConditions);

        assertTrue(from(new ShippingConditionComparator()).isOrdered(shippingConditions));
    }

    private class ShippingConditionComparator implements Comparator<ShippingCondition> {

        public final int compare(ShippingCondition c1, ShippingCondition c2) {

            int ctCompare = 0;

            if (c1 != null && c2 != null) {
                String ct1 = c1.getShippingCondition();
                String ct2 = c2.getShippingCondition();
                if (ct1 != null && ct2 != null) {
                    ctCompare = ct1.compareToIgnoreCase(ct2);
                }
            }

            return ctCompare;
        }
    }
}

