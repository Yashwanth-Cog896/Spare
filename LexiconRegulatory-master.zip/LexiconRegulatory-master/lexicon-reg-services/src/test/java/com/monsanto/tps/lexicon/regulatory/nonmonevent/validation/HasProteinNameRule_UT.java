package com.monsanto.tps.lexicon.regulatory.nonmonevent.validation;

import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collection;

/**
 * nbwald - May 21, 2009 5:40:05 PM
 */
public class HasProteinNameRule_UT
{
   @Test
   public void testViolated_False()
      throws Exception
   {
      Collection<ProteinName> proteinNames = Arrays.asList(new ProteinName());
      Rule<String> rule = new HasProteinNameRule(proteinNames);

      assertThat(rule.violated(), is(false));
   }

   @Test
   public void testViolated_True()
      throws Exception
   {
      Collection<ProteinName> proteinNames = Arrays.asList();
      Rule<String> rule = new HasProteinNameRule(proteinNames);

      assertThat(rule.violated(), is(true));
   }

   @Test
   public void testGetViolation()
      throws Exception
   {
      assertThat(new HasProteinNameRule(null).getViolation(), is("At least one protein name is required."));
   }
}
