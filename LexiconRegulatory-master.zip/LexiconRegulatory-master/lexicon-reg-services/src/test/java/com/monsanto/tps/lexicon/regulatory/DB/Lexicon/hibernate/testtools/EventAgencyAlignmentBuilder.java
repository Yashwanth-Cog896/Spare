package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools;

import com.monsanto.dbdataservices.SQLUtil;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Agency;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.AgencyMaterialType;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Crop;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MaterialChemicalName;
import org.hibernate.Session;

import java.util.Date;

/**
 * nbwald - Jan 9, 2009 3:28:35 PM
 */
public class EventAgencyAlignmentBuilder {
    private final EventAgencyAlignment eventAgencyAlignment = new EventAgencyAlignment();

    public EventAgencyAlignmentBuilder() {
        BuilderID builderID = new BuilderID();
        eventAgencyAlignment.setEventAgencyAlignmentId(builderID.id());
        eventAgencyAlignment.setEventAgencyAlignmentPubkey(builderID.sid());
        eventAgencyAlignment.setMaterialName("ZM_1234");
        eventAgencyAlignment.setAgency(AgencyBuilder.epa());
        eventAgencyAlignment.setRegulated(SQLUtil.booleanToString(true));
        eventAgencyAlignment.setCrop(CropBuilder.corn());
        eventAgencyAlignment.setAgencyMaterialType(AgencyMaterialTypeBuilder.trait());
        withCreatedDate();
        withModifiedDate();
        withModifiedUserId();
        withCreatedUserId();
    }

    public EventAgencyAlignmentBuilder withEvent(String event) {
        eventAgencyAlignment.setMaterialName(event);
        return this;
    }

    public EventAgencyAlignmentBuilder withAgency(Agency agency) {
        eventAgencyAlignment.setAgency(agency);
        return this;
    }

    public EventAgencyAlignmentBuilder regulated() {
        eventAgencyAlignment.setRegulated(SQLUtil.booleanToString(true));
        return this;
    }

    public EventAgencyAlignmentBuilder deregulated() {
        eventAgencyAlignment.setRegulated(SQLUtil.booleanToString(false));
        return this;
    }

    public EventAgencyAlignmentBuilder withDeregulatedEffectiveDate(Date deregulatedEffectiveDate) {
        eventAgencyAlignment.setDeregulatedEffectiveDate(deregulatedEffectiveDate);
        return this;
    }

    public EventAgencyAlignmentBuilder withMaxQuantity(double maxQuantity) {
        eventAgencyAlignment.setMaxQuantity(maxQuantity);
        return this;
    }

    public EventAgencyAlignment create() {
        Session session = TestSessions.getLexiconSession();
        session.save(eventAgencyAlignment);
        return eventAgencyAlignment;
    }

    public EventAgencyAlignment getEventAgencyAlignmentObj() {
        return eventAgencyAlignment;
    }

    public EventAgencyAlignmentBuilder withCrop(Crop crop) {
        eventAgencyAlignment.setCrop(crop);
        return this;
    }

    public EventAgencyAlignmentBuilder withDiscoveryMaterial(Boolean discoveryMaterial) {
        eventAgencyAlignment.setDiscoveryMaterial(discoveryMaterial);
        return this;
    }

    public EventAgencyAlignmentBuilder withAgencyMaterialType(AgencyMaterialType materialType) {
        eventAgencyAlignment.setAgencyMaterialType(materialType);
        return this;
    }

    public EventAgencyAlignmentBuilder withChemicalName(MaterialChemicalName chemicalName) {
        eventAgencyAlignment.setMaterialChemicalName(chemicalName);
        return this;
    }

    public EventAgencyAlignmentBuilder withCreatedDate() {
        eventAgencyAlignment.setCreatedDate(new Date());
        return this;
    }

    public EventAgencyAlignmentBuilder withModifiedDate() {
        eventAgencyAlignment.setModifiedDate(new Date());
        return this;
    }

    public EventAgencyAlignmentBuilder withCreatedUserId() {
        eventAgencyAlignment.setCreatedUserID("LEXICON_USER");
        return this;
    }

    public EventAgencyAlignmentBuilder withModifiedUserId() {
        eventAgencyAlignment.setModifiedUserId("LEXICON_USER");
        return this;
    }

}
