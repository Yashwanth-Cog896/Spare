package com.monsanto.tps.lexicon.regulatory.event.queryset;

import com.monsanto.tps.lexicon.regulatory.event.dao.productvector.ProductVectorDao;
import static org.easymock.EasyMock.*;
import org.junit.Before;
import org.junit.Test;

/**
 * rrchak1 - Apr 24, 2009 10:56:41 AM
 */

public class RegulatoryEventQuerySet_UT
{

   RegulatoryEventQuerySet regulatoryEventQuerySet;
   ProductVectorDao productVectorDao;
   private static final String PMON_TWO = "PMON_TWO";
   private static final String PMON_ONE = "PMON_ONE";
   private static final long CROP_PUBKEY = 1015;

   @Before
   public void before() {
      productVectorDao = createMock(ProductVectorDao.class);
      regulatoryEventQuerySet = new RegulatoryEventQuerySetImpl(productVectorDao);
   }

   @Test
   public void testfindProductVectorsByCropIdAndConstructNameForCombinedConstructsCallsProductVectorDao() {
      String[] combinedConstructs = new String[]{PMON_ONE, PMON_TWO};
      expect(productVectorDao.findProductVectorsByCropIdAndConstructNameForCombinedConstructs(CROP_PUBKEY, combinedConstructs)).andReturn(null);
      replay(productVectorDao);
      regulatoryEventQuerySet.findProductVectorsByCropIdAndConstructNameForCombinedConstructs(CROP_PUBKEY, combinedConstructs);
      verify(productVectorDao);
   }

   @Test
   public void testfindProductVectorsByCropIdAndConstructNameForSingleConstructsCallsProductVectorDao() {
      expect(productVectorDao.findProductVectorsByCropIdAndConstructNameForSingleConstructs(CROP_PUBKEY, PMON_ONE)).andReturn(null);
      replay(productVectorDao);
      regulatoryEventQuerySet.findProductVectorsByCropIdAndConstructNameForSingleConstructs(CROP_PUBKEY, PMON_ONE);
      verify(productVectorDao);
   }
}
