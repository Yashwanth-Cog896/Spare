package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.DataFilter;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

/**
 * nbwald - Aug 26, 2008 4:19:05 PM
 */
public class DataFilterBuilder
{
   public static DataFilter regulatory() {
      return findDataFilterByName("REGULATORY");
   }

   private static DataFilter findDataFilterByName(String filterName) {
      Criteria dataFilterByNameCriteria = TestSessions.getLexiconSession().createCriteria(DataFilter.class)
         .add(Restrictions.eq("filterName", filterName))
         .add(Restrictions.eq("active", true));
      return (DataFilter) dataFilterByNameCriteria.uniqueResult();
   }

}