/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.eventtraitservice.service;

import com.monsanto.tps.lexicon.eventtraitservice.transfer.GermplasmEventTraitRequest;
import com.monsanto.tps.lexicon.eventtraitservice.transfer.GermplasmEventTraitResponse;
import com.monsanto.tps.lexicon.regulatory.eventtraitservice.business.EventTraitBusiness;
import com.monsanto.tps.lexicon.regulatory.eventtraitservice.business.EventTraitServiceBusiness;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/* vvkalu - 8/1/11 */
public class EventTraitServiceImpl_UT {
    private static final long GERMPLASM_ID = 6848L;
    private EventTraitServiceImpl eventTraitService;
    private EventTraitServiceBusiness eventTraitServiceBusiness;
    private EventTraitBusiness eventTraitBusiness;

    @Before
    public void setUp() {
        eventTraitService = new EventTraitServiceImpl();
        eventTraitServiceBusiness = mock(EventTraitServiceBusiness.class);
        eventTraitBusiness = mock(EventTraitBusiness.class);
        eventTraitService.setEventTraitServiceBusiness(eventTraitServiceBusiness);
    }

    @Test
    public void test_When_Null() throws Exception {
        when(eventTraitServiceBusiness.getGermplasmTraitEventConstructs(null)).thenReturn(new GermplasmEventTraitResponse());
        GermplasmEventTraitResponse traitEventConstructs = eventTraitService.getGermplasmTraitEventConstructs(null);
        assertNotNull(traitEventConstructs);
        assertTrue(traitEventConstructs.getGermplasmEventTraits().isEmpty());
    }

    @Test
    public void test_Not_Null() throws Exception {
        GermplasmEventTraitRequest request = new GermplasmEventTraitRequest();
        request.setGermplasmIds(Arrays.asList(GERMPLASM_ID));
        when(eventTraitServiceBusiness.getGermplasmTraitEventConstructs(request)).thenReturn(new GermplasmEventTraitResponse());
        GermplasmEventTraitResponse traitEventConstructs = eventTraitService.getGermplasmTraitEventConstructs(request);
        assertNotNull(traitEventConstructs);
        assertTrue(traitEventConstructs.getGermplasmEventTraits().isEmpty());
    }

    @Test
    public void testGetGermplasmTraitEventConstructs() {
        List<Long> traitStackIds = Arrays.asList(33L);
        long germplasmId = 12L;
        when(eventTraitBusiness.getComTraitStackIdByEventConstructs(germplasmId)).thenReturn(traitStackIds);
        assertThat(eventTraitBusiness.getComTraitStackIdByEventConstructs(germplasmId), is(traitStackIds));
    }
}