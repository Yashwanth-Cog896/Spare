package com.monsanto.tps.lexicon.regulatory.event.dao.crop;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.tps.lexicon.regulatory.DB.Midas.Tests.MidasDataTestCase;
import com.monsanto.tps.lexicon.regulatory.DB.midas.MidasBoolean;

/**
 * User: pjberry
 * Date: Jul 30, 2007
 * Time: 10:37:10 AM
 */
public class MidasGenusSpeciesByCropNameQuery_DUT
        extends MidasDataTestCase {

    public void testGetGenusSpecies_MatchFound()
            throws Exception {
        insertFakeCrop(-764189, "Crizzop", "CZ", true);

        MidasGenusSpeciesByCropNameQuery query = new MidasGenusSpeciesByCropNameQuery("Crizzop");
        String genusSpecies = query.getGenusSpecies();

        assertEquals("CZ", genusSpecies);
    }

    public void testGetGenusSpecies_CaseInsensitiveMatchFound()
            throws Exception {
        insertFakeCrop(-764189, "CrizzoP", "CZ", true);

        MidasGenusSpeciesByCropNameQuery query = new MidasGenusSpeciesByCropNameQuery("CriZzop");
        String genusSpecies = query.getGenusSpecies();

        assertEquals("CZ", genusSpecies);
    }


    public void testGetGenusSpecies_NoMatchFound()
            throws Exception {
        MidasGenusSpeciesByCropNameQuery query = new MidasGenusSpeciesByCropNameQuery("CriZzop");

        String genusSpecies = query.getGenusSpecies();

        assertNull(genusSpecies);
    }

    public void testGetGenusSpecies_MatchIsLogicallyDeleted_NotFound()
            throws Exception {
        insertFakeCrop(-764189, "Crizzop", "CZ", false);

        MidasGenusSpeciesByCropNameQuery query = new MidasGenusSpeciesByCropNameQuery("Crizzop");
        String genusSpecies = query.getGenusSpecies();

        assertNull(genusSpecies);
    }

    public void insertFakeCrop(long cropId, String cropName, String genusSpecies, boolean refActive)
            throws WrappingException {
        String sql =
                "insert into MIDAS.CROP (crop_id, name, rem_crop_id, ref_active, genus_species, crop_ref_id, list_order, rm_min, rm_max, rm_increment) " +
                        "values (?, ?, -1, ?, ?, 'XXXX', 1000, 0, 0, 0)";

        PersistentStoreStatement stmt = getMidasConn().prepareStatement(sql);
        try {
            stmt.setParam(1, cropId);
            stmt.setParam(2, cropName);
            stmt.setParam(3, new MidasBoolean(refActive).getDatabaseRepresentation());
            stmt.setParam(4, genusSpecies);

            stmt.executeInsert();
        } finally {
            stmt.close();
        }
    }
}
