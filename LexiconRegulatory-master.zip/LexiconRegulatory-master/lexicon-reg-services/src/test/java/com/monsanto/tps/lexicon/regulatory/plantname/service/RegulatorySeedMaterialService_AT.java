package com.monsanto.tps.lexicon.regulatory.plantname.service;

import com.monsanto.tps.lexicon.plantname.OrionPlantProduct;
import com.monsanto.tps.lexicon.plantname.RegulatorySeedMaterialService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 6/22/12
 * Time: 12:12 PM
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:/com/monsanto/tps/lexicon/regulatory/contexts/lexicon-test-service-at-context.xml"})
@Transactional
public class RegulatorySeedMaterialService_AT {

    @Autowired
    private RegulatorySeedMaterialService regulatorySeedMaterialService;

    @Test
    public void findPlantName_results_wildcard() throws Exception {
        final List<OrionPlantProduct> PlantNames = regulatorySeedMaterialService.findPlantNames("Round*");
        assertNotNull(PlantNames);
        assertFalse(PlantNames.isEmpty());
    }

    @Test
    public void findPlantName_results_exactMatch() throws Exception {
        final List<OrionPlantProduct> PlantNames = regulatorySeedMaterialService.findPlantNames("ROUND KING");
        assertNotNull(PlantNames);
        assertFalse(PlantNames.isEmpty());
    }

    @Test
    public void findPlantName_noResults() throws Exception {
        final List<OrionPlantProduct> PlantNames = regulatorySeedMaterialService.findPlantNames("asdf");
        assertNotNull(PlantNames);
        assertTrue(PlantNames.isEmpty());
    }
}
