package com.monsanto.tps.lexicon.regulatory.nonmonevent.validation;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Crop;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.dao.NonMonEventPersistQuerySet;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.model.NonMonEventPersistRichRequest;
import static org.easymock.classextension.EasyMock.createMock;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

/**
 * nbwald - May 21, 2009 6:28:16 PM
 */
public class NonMonEventSaveValidation_UT
{
   @Test
   public void testValidate_NoAuditComment()
      throws Exception
   {
      NonMonEventPersistRichRequest richRequest = new StubbedNonMonEventPersistRichRequest()
      {
         @Override
         public String getAuditComment() {
            return null;
         }
      };

      NonMonEventSaveValidation validation = new NonMonEventSaveValidation();
      ValidationResults validationResults = validation.validate(richRequest);

      assertThat(validationResults.isSuccess(), is(false));
      assertThat(Arrays.asList(validationResults.getMessages()).contains(new AuditCommentExistsRule(null).getViolation()), is(true));
   }

   @Test
   public void testValidate_NoAuditRequestor()
      throws Exception
   {
      NonMonEventPersistRichRequest richRequest = new StubbedNonMonEventPersistRichRequest()
      {
         @Override
         public String getAuditRequestor() {
            return null;
         }
      };

      NonMonEventSaveValidation validation = new NonMonEventSaveValidation();
      ValidationResults validationResults = validation.validate(richRequest);

      assertThat(validationResults.isSuccess(), is(false));
      assertThat(Arrays.asList(validationResults.getMessages()).contains(new AuditRequestorExistsRule(null).getViolation()), is(true));
   }

   @Test
   public void testValidate_NoCrop()
      throws Exception
   {
      NonMonEventPersistRichRequest richRequest = new StubbedNonMonEventPersistRichRequest()
      {
         @Override
         public Crop getCrop() {
            return null;
         }
      };

      NonMonEventSaveValidation validation = new NonMonEventSaveValidation();
      ValidationResults validationResults = validation.validate(richRequest);

      assertThat(validationResults.isSuccess(), is(false));
      assertThat(Arrays.asList(validationResults.getMessages()).contains(new CropExistsRule(null).getViolation()), is(true));
   }

   @Test
   public void testValidate_NoEvent()
      throws Exception
   {
      NonMonEventPersistRichRequest richRequest = new StubbedNonMonEventPersistRichRequest()
      {
         @Override
         public String[] getConstructs() {
            return new String[0];
         }
      };

      NonMonEventSaveValidation validation = new NonMonEventSaveValidation();
      ValidationResults validationResults = validation.validate(richRequest);

      assertThat(validationResults.isSuccess(), is(false));
      assertThat(Arrays.asList(validationResults.getMessages()).contains(new EventExistsRule().getViolation()), is(true));
   }

   @Test
   public void testValidate_MultipleConstructs()
      throws Exception
   {
      NonMonEventPersistRichRequest richRequest = new StubbedNonMonEventPersistRichRequest()
      {
         @Override
         public String[] getConstructs() {
            return new String[]{"A", "B", "C"};
         }
      };

      NonMonEventSaveValidation validation = new NonMonEventSaveValidation();
      ValidationResults validationResults = validation.validate(richRequest);

      assertThat(validationResults.isSuccess(), is(false));
      assertThat(Arrays.asList(validationResults.getMessages()).contains(new EventHasSingleConstructRule().getViolation()), is(true));
   }

   @Test
   public void testValidate_NoProteinNames()
      throws Exception
   {
      NonMonEventPersistRichRequest richRequest = new StubbedNonMonEventPersistRichRequest()
      {
         @Override
         public Collection<ProteinName> getProteinNames() {
            return new ArrayList<ProteinName>();
         }
      };

      NonMonEventSaveValidation validation = new NonMonEventSaveValidation();
      ValidationResults validationResults = validation.validate(richRequest);

      assertThat(validationResults.isSuccess(), is(false));
      assertThat(Arrays.asList(validationResults.getMessages()).contains(new HasProteinNameRule(null).getViolation()), is(true));
   }

   @Test
   public void testValidate_NoRegulatoryTraitOptions()
      throws Exception
   {
      NonMonEventPersistRichRequest richRequest = new StubbedNonMonEventPersistRichRequest()
      {
         @Override
         public Collection<ComlTraitName> getComlTraitNames() {
            return new ArrayList<ComlTraitName>();
         }

         @Override
         public Collection<ComlTraitType> getComlTraitTypes() {
            return new ArrayList<ComlTraitType>();
         }
      };

      NonMonEventSaveValidation validation = new NonMonEventSaveValidation();
      ValidationResults validationResults = validation.validate(richRequest);

      assertThat(validationResults.isSuccess(), is(false));
      assertThat(Arrays.asList(validationResults.getMessages()).contains(new HasRegulatoryTraitOptionRule(null, null).getViolation()), is(true));
   }

   @Test
   public void testValidate_NonMonEventExists()
      throws Exception
   {
      NonMonEventPersistRichRequest richRequest = new StubbedNonMonEventPersistRichRequest()
      {
         @Override
         public NonMonEvent getExistingNonMonEvent() {
            return new NonMonEvent();
         }
      };

      NonMonEventSaveValidation validation = new NonMonEventSaveValidation();
      ValidationResults validationResults = validation.validate(richRequest);

      assertThat(validationResults.isSuccess(), is(false));
      assertThat(Arrays.asList(validationResults.getMessages()).contains(new NonMonEventDoesNotExistRule(null).getViolation()), is(true));
   }

   @Test
   public void testValidate_EventNameIsNotSpecified()
      throws Exception
   {
      NonMonEventPersistRichRequest richRequest = new StubbedNonMonEventPersistRichRequest()
      {
         @Override
         public String getEventName() {
            return null;
         }
      };

      NonMonEventSaveValidation validation = new NonMonEventSaveValidation();
      ValidationResults validationResults = validation.validate(richRequest);

      assertThat(validationResults.isSuccess(), is(false));
      assertThat(Arrays.asList(validationResults.getMessages()).contains(new EventNameSpecifiedRule(null).getViolation()), is(true));
   }

   @Test
   public void testValidate_Success()
      throws Exception
   {
      NonMonEventPersistRichRequest richRequest = new StubbedNonMonEventPersistRichRequest();

      NonMonEventSaveValidation validation = new NonMonEventSaveValidation();
      ValidationResults validationResults = validation.validate(richRequest);

      assertThat(validationResults.isSuccess(), is(true));
      assertThat(validationResults.getMessages().length, is(0));
   }

   private class StubbedNonMonEventPersistRichRequest
      extends NonMonEventPersistRichRequest
   {
      public StubbedNonMonEventPersistRichRequest() {
         super(createMock(NonMonEventPersistQuerySet.class));
      }

      @Override
      public String getAuditComment() {
         return "AC";
      }

      @Override
      public String getAuditRequestor() {
         return "AR";
      }

      @Override
      public Crop getCrop() {
         return new Crop();
      }

      @Override
      public String[] getConstructs() {
         return new String[]{"CONSTRUCT"};
      }

      @Override
      public Collection<ProteinName> getProteinNames() {
         return Arrays.asList(new ProteinName());
      }

      @Override
      public Collection<ComlTraitName> getComlTraitNames() {
         return Arrays.asList(new ComlTraitName());
      }

      @Override
      public Collection<ComlTraitType> getComlTraitTypes() {
         return Arrays.asList(new ComlTraitType());
      }

      @Override
      public NonMonEvent getExistingNonMonEvent() {
         return null;
      }

      @Override
      public String getEventName() {
         return "some event name";
      }

      @Override
      public String getMaterialName() {
          return "some material name";
      }
   }
}
