package com.monsanto.tps.lexicon.regulatory.event.delegate;

import com.monsanto.dbdataservices.SQLUtil;
import com.monsanto.tps.lexicon.event.AgencyMaterial;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Agency;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.AgencyMaterialType;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Country;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;
import org.junit.Test;

import java.util.Date;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;

/**
 * nbwald - Jan 6, 2009 11:55:40 AM
 */
public class MaterialAgencies_UT {
    @Test
    public void testGetResponseEventAgencies_NoModels_NoResponses()
            throws Exception {
        EventAgencyAlignment[] models = new EventAgencyAlignment[0];

        MaterialAgencies materialAgencies = new MaterialAgencies(models);
        AgencyMaterial[] responses = materialAgencies.getResponseEventAgencies();

        assertThat(responses.length, is(0));
    }

    @Test
    public void testGetResponseEventAgencies_MultipleModels_SameNumberOfResponses()
            throws Exception {
        EventAgencyAlignment[] models = {
                new EventAgencyAlignment(),
                new EventAgencyAlignment(),
                new EventAgencyAlignment()
        };

        MaterialAgencies materialAgencies = new MaterialAgencies(models);
        AgencyMaterial[] responses = materialAgencies.getResponseEventAgencies();

        assertThat(responses.length, is(models.length));
    }

    @Test
    public void testGetResponseEventAgencies_ValuesAreCopiedOver()
            throws Exception {
        Country country = new Country();
        country.setCountryName("United States of America");
        Agency agency = new Agency();
        agency.setCountry(country);
        agency.setAgencyAbbr("FDA");
        agency.setSurfaceAreaUomCode("Acres");

        AgencyMaterialType agencyMaterialType = new AgencyMaterialType();
        agencyMaterialType.setMaterialTypeDesc("materialDesc");

        EventAgencyAlignment model = new EventAgencyAlignment();
        model.setRegulated(SQLUtil.booleanToString(true));
        model.setAgency(agency);
        model.setDeregulatedEffectiveDate(new Date());
        model.setMaxQuantity(5.2);
        model.setEventAgencyAlignmentPubkey("123");
        model.setAgencyMaterialType(agencyMaterialType);
        EventAgencyAlignment[] models = {model};

        MaterialAgencies materialAgencies = new MaterialAgencies(models);
        AgencyMaterial[] responses = materialAgencies.getResponseEventAgencies();

        assertThat(responses.length, is(1));
        AgencyMaterial response = responses[0];
        assertThat(response.isRegulated(), is(true));
        assertThat(response.getAgencyAbbr(), is(model.getAgency().getAgencyAbbr()));
        assertThat(response.getCountryName(), is(model.getAgency().getCountry().getCountryName()));
        assertThat(response.getDeregulatedEffectiveDate(), is(model.getDeregulatedEffectiveDate()));
        assertThat(response.getMaxQuantity(), is(model.getMaxQuantity()));
        assertThat(response.getPublicKey(), is(model.getEventAgencyAlignmentPubkey()));
        assertThat(response.getSurfaceAreaUomCode(), is(model.getAgency().getSurfaceAreaUomCode()));
        assertThat(response.getAgencyMaterialType(), is(model.getAgencyMaterialType().getMaterialTypeDesc()));
        assertNull(response.getDiscoveryMaterial());
    }

    @Test
    public void testGetResponseEventAgencies_Deregulated()
            throws Exception {
        EventAgencyAlignment model = new EventAgencyAlignment();
        model.setRegulated(SQLUtil.booleanToString(false));
        EventAgencyAlignment[] models = {model};

        MaterialAgencies materialAgencies = new MaterialAgencies(models);
        AgencyMaterial[] responses = materialAgencies.getResponseEventAgencies();

        assertThat(responses.length, is(1));
        AgencyMaterial response = responses[0];
        assertThat(response.isRegulated(), is(false));
    }

    @Test
    public void testGetResponseEventAgencies_DiscoveryMaterialSetFalse() {
        EventAgencyAlignment model = new EventAgencyAlignment();
        model.setDiscoveryMaterial(Boolean.FALSE);
        EventAgencyAlignment[] models = {model};

        MaterialAgencies materialAgencies = new MaterialAgencies(models);
        AgencyMaterial[] responses = materialAgencies.getResponseEventAgencies();

        assertThat(responses.length, is(1));
        AgencyMaterial response = responses[0];
        assertThat(response.getDiscoveryMaterial(), is(Boolean.FALSE));
    }

    @Test
    public void testGetResponseEventAgencies_DiscoveryMaterialSetTrue() {
        EventAgencyAlignment model = new EventAgencyAlignment();
        model.setDiscoveryMaterial(Boolean.TRUE);
        EventAgencyAlignment[] models = {model};

        MaterialAgencies materialAgencies = new MaterialAgencies(models);
        AgencyMaterial[] responses = materialAgencies.getResponseEventAgencies();

        assertThat(responses.length, is(1));
        AgencyMaterial response = responses[0];
        assertThat(response.getDiscoveryMaterial(), is(Boolean.TRUE));
    }
}
