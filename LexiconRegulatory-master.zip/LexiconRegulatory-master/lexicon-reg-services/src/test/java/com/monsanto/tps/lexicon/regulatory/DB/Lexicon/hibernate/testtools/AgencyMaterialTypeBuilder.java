package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.AgencyMaterialType;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;


public class AgencyMaterialTypeBuilder {
    public static AgencyMaterialType trait() {
        return findMaterialTypeDescByName("Trait");
    }

    public static AgencyMaterialType chemical() {
        return findMaterialTypeDescByName("Chemical Spray");

    }

    private static AgencyMaterialType findMaterialTypeDescByName(String materialType) {
        Criteria materialTypeByNameCriteria = TestSessions.getLexiconSession().createCriteria(AgencyMaterialType.class).add(Restrictions.eq("materialTypeDesc", materialType));
        return (AgencyMaterialType) materialTypeByNameCriteria.uniqueResult();
    }


}
