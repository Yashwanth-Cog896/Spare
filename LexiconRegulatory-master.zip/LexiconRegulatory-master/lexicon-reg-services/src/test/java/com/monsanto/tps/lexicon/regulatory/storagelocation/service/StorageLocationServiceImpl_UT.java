package com.monsanto.tps.lexicon.regulatory.storagelocation.service;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.LexiconAcceptanceTestCase;
import com.monsanto.tps.lexicon.regulatory.storagelocation.business.StorageLocationBusiness;
import com.monsanto.tps.lexicon.storagelocation.OrionStorageLocation;
import org.junit.Before;
import org.junit.Test;

import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: MMR
 * Date: 2/21/12
 * Time: 8:03 PM
 */
public class StorageLocationServiceImpl_UT extends LexiconAcceptanceTestCase {

    private StorageLocationBusiness business;
    StorageLocationServiceImpl storageLocationServiceImpl;

    @Before
    public void setUp() {
        business = mock(StorageLocationBusiness.class);
        storageLocationServiceImpl = new StorageLocationServiceImpl();
        storageLocationServiceImpl.setStorageLocationBusiness(business);
    }

    @Test
    public void findStorageLocationsByStorageLocationIsSuccessful() throws Exception {
        when(business.findStorageLocations("S*")).thenReturn(getOrionStorageLocations());

        List<OrionStorageLocation> storageLocations = storageLocationServiceImpl.findStorageLocations("S*");
        assertNotNull(storageLocations);
        assertTrue(storageLocations.size() == 1);
    }

    @Test
    public void findStorageLocationsByPhysicalLocationWildCardIsSuccessful() throws Exception {
        when(business.findStorageLocationsByPhysicalLocation("*2*")).thenReturn(getOrionStorageLocations());

        List<OrionStorageLocation> storageLocations = storageLocationServiceImpl.findStorageLocationsByPhysicalLocation("*2*");
        assertNotNull(storageLocations);
        assertTrue(storageLocations.size() == 1);
    }

    @Test
    public void findStorageLocationsByListIsSuccessful() throws Exception {
        when(business.findStorageLocationsByList(Collections.singletonList("Q1UOL N Cage"))).thenReturn(getOrionStorageLocations());

        List<OrionStorageLocation> storageLocations = storageLocationServiceImpl.findStorageLocationsByList(Collections.singletonList("Q1UOL N Cage"));
        assertNotNull(storageLocations);
        assertTrue(storageLocations.size() == 1);
    }

    @Test
    public void passingNullAsListReturnsEmptyStorageLocations() throws Exception {
        List<OrionStorageLocation> storageLocations = storageLocationServiceImpl.findStorageLocationsByList(null);
        assertNotNull(storageLocations);
    }

    public List<OrionStorageLocation> getOrionStorageLocations() {
        return Collections.singletonList(new OrionStorageLocation());
    }
}
