package com.monsanto.tps.lexicon.regulatory.eventsreginfo.service;

import com.monsanto.tps.lexicon.eventsreginfo.EventsRegInfoService;
import com.monsanto.tps.lexicon.eventsreginfo.transfer.EventRegInfo;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.*;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent;
import org.junit.Before;
import org.junit.Test;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.List;

import static junit.framework.Assert.*;
import static junit.framework.Assert.assertEquals;

/**
 * Created by IntelliJ IDEA.
 * User: vvkalu
 * Date: Oct 11, 2010
 * Time: 1:49:09 PM
 * To change this template use File | Settings | File Templates.
 */
public class EventsRegInfoServiceImpl_AT
    extends LexiconAcceptanceTestCase {

    @Resource
    private EventsRegInfoService service;

    @Before
    public void setUp() {
      insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
         withMonNumber("MON_1111").withEventName("ZM_1111").withMonNumberConstruct(
            new MonNumberConstructBuilder().
               withConstructName("CON_111").
               withPvCode("PV_111")
         ).withComlTraitType(
            new ComlTraitTypeBuilder().
               withTraitTypeAbbr("TRTABBR").
               withTraitTypeDesc("TRT TYPE DESC")
         ).withProteinName(
            new ProteinNameBuilder().
               withProteinName("PROT NAME").
               withProteinNamePubkey("1234").
               withProteinDescription("PROT DESC").
               withOrigSourceOrganism("ORIG SOURCE ORG")
         ).withComlTraitName(
            new ComlTraitNameBuilder().
               withTraitAbbr("TRTNABBR")
               .withTraitDesc("TRTNMDESC")
         ).createInDb();
         }
      });

      insert(new AcceptanceTestData<NonMonEvent>()
      {
         public NonMonEvent dataToInsert() {
            return new NonMonEventBuilder().
         withEventDescription("ZM_1111").
         withCropPubkey(CropBuilder.soybeans().getCropPubkey()).
         withNonMonEventConstruct(new NonMonEventConstructBuilder().
            withConstructName("CON_111")).
         withComlTraitType(new ComlTraitTypeBuilder().
            withTraitTypeAbbr("TRTABBRN").
            withTraitTypeDesc("TRTTYPEDESC")).
         withComlTraitName(new ComlTraitNameBuilder().
            withTraitAbbr("TNABBRNON").
            withTraitDesc("TRT NAME DESC")).
         withProteinName(new ProteinNameBuilder().
            withProteinName("PROT NAME NON").
            withProteinNamePubkey("12345").
            withProteinDescription("PROT DESC NON").
            withOrigSourceOrganism("ORIG SOURCE ORG NON").
            create()).
         create();
         }
      });
    }

    @Test
    public void findMonNumbersByCropAndMonNumber() {
        List<EventRegInfo> monNumber = service.findMonNumbersByCropAndMonNumber("MON_1111", "CORN");
        assertNotNull(monNumber);
        assertEquals("MON_1111", monNumber.get(0).getMonNumber());
    }

    @Test
    public void findMonNumbersByCropAndMonNumber_MonNumber_Wildcard() {
        List<EventRegInfo> monNumber = service.findMonNumbersByCropAndMonNumber("MON*11*", "CORN");
        assertNotNull(monNumber);
        assertTrue(monNumber.get(0).getMonNumber().contains("MON"));
    }

    @Test
    public void findMonNumbersByEvent() {
        List<EventRegInfo> monNumber = service.findMonNumbersByEvent("ZM_1111");
        assertNotNull(monNumber);
        assertEquals(2, monNumber.size());
        assertEquals("MON_1111", monNumber.get(0).getMonNumber());
        assertEquals("ZM_1111", monNumber.get(1).getMonNumber());
        assertEquals("CORN", monNumber.get(0).getCrop());
        assertEquals("SOYBEANS", monNumber.get(1).getCrop());
    }

    @Test
    public void findMonNumbersByEvent_Wildcard() {
        List<EventRegInfo> monNumber = service.findMonNumbersByEvent("ZM_11*");
        assertNotNull(monNumber);
        assertTrue(monNumber.get(0).getEvent().contains("ZM_"));
    }

    @Test
    public void findMonNumbers_CollectionCriteria() {
      List<EventRegInfo> monNumbers = service.findMonNumbers(Arrays.asList("MON_11112", "MON_1111"));
      assertNotNull(monNumbers);
      assertEquals(1, monNumbers.size());
      assertEquals("MON_1111", monNumbers.get(0).getMonNumber());
    }

    @Test
    public void findMonNumbersByPlasmidPmon_wildcard() {
       List<EventRegInfo> monNumbers = service.findMonNumbersByPlasmidPmon("*pMON*");
       assertNotNull(monNumbers);
       assertTrue(monNumbers.get(0).getPlasmidPMON().contains("pMON"));
    }

    @Test
    public void findMonNumbersByPlasmidPvCode_wildcard() {
       List<EventRegInfo> monNumbers = service.findMonNumbersByPlasmidPvCode("*pv*");
       assertNotNull(monNumbers);
       assertTrue(monNumbers.get(0).getPlasmidPVCode().contains("PV"));
    }

    @Test
    public void findMonNumbersByTransformationBackground_wildcard() {
       List<EventRegInfo> monNumbers = service.findMonNumbersByTransformationBackground("rp*");
       assertNotNull(monNumbers);
       assertTrue(monNumbers.get(0).getTransformationBackground().contains("RP"));
    }

    @Test
    public void findMonNumbersByRegulatoryTraitDescription_wildcard() {
       List<EventRegInfo> monNumbers = service.findMonNumbersByRegulatoryTraitDescription("Gyphosat*");
       assertNotNull(monNumbers);
       assertTrue(monNumbers.get(0).getRegulatoryTraitDescription().contains("Gyphosat"));
    }

    @Test
    public void findMonNumbersByRegulatoryGenesPresent() {
       List<EventRegInfo> monNumbers = service.findMonNumbersByRegulatoryGenesPresent("*TIC105*");
       assertNotNull(monNumbers);
       assertTrue(monNumbers.get(0).getRegulatoryGenesPresent().contains("TIC105"));
    }

    @Test
    public void findMonNumbersByRegulatedStatus() {
       List<EventRegInfo> monNumbers = service.findMonNumbersByRegulatedStatus(false);
       assertNotNull(monNumbers);
       assertFalse(monNumbers.get(0).getRegulatedStatus());
    }

    @Test
    public void findMonNumbersByJvNumber() {
       List<EventRegInfo> monNumbers = service.findMonNumbersByJvNumber("JV123");
       assertNotNull(monNumbers);
       assertTrue(monNumbers.get(0).getJvNumber().contains("JV"));
    }

    @Test
    public void findMonNumbersByOecdNumber() {
       List<EventRegInfo> monNumbers = service.findMonNumbersByOecdNumber("Mon*");
       assertNotNull(monNumbers);
       assertTrue(monNumbers.get(0).getOecdNumber().contains("MON"));
    }

    @Test
    public void findMonNumbersByMaterialNumber() {
       List<EventRegInfo> monNumbers = service.findMonNumbersByMaterialName("yield*");
       assertNotNull(monNumbers);
       assertTrue(monNumbers.get(0).getMaterialName().contains("Yield"));
    }
}
