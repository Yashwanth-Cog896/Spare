package com.monsanto.tps.lexicon.regulatory.sample.business;

import com.monsanto.tps.lexicon.sample.OrionSample;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.SampleType;
import com.monsanto.tps.lexicon.regulatory.sample.business.SampleBusiness;
import com.monsanto.tps.lexicon.regulatory.sample.dao.SampleDAO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/1/12
 * Time: 7:47 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class SampleBusiness_UT {

    @Mock
    private SampleDAO sampleDAO;

    @InjectMocks
    private SampleBusiness sampleBusiness = new SampleBusiness();

    private final List<SampleType> singleSampleListFromDAO;
    private final List<SampleType> multiSampleListFromDAO;
    private static final List<SampleType> emptyListFromDAO = new ArrayList<SampleType>();

    private final List<OrionSample> singleSampleListFromBusiness;
    private final List<OrionSample> multiSampleListFromBusiness;
    private static final List<OrionSample> emptyListFromBusiness = new ArrayList<OrionSample>();

    public SampleBusiness_UT() {
        singleSampleListFromDAO = new ArrayList<SampleType>();
        singleSampleListFromDAO.add(new SampleType("type", "container", "good", "sample", true));

        multiSampleListFromDAO = new ArrayList<SampleType>();
        multiSampleListFromDAO.add(new SampleType("type1", "container1", "good", "sample1", true));
        multiSampleListFromDAO.add(new SampleType("type2", "container2", "bad", "sample2", false));

        singleSampleListFromBusiness = new ArrayList<OrionSample>();
        singleSampleListFromBusiness.add(new OrionSample("type", "container", "good", "sample", true));

        multiSampleListFromBusiness = new ArrayList<OrionSample>();
        multiSampleListFromBusiness.add(new OrionSample("type1", "container1", "good", "sample1", true));
        multiSampleListFromBusiness.add(new OrionSample("type2", "container2", "bad", "sample2", false));
    }

    @Test
    public void findSampleTypes_findNone() throws Exception {

        when(sampleDAO.findSampleTypes("asdf")).thenReturn(emptyListFromDAO);

        final List<OrionSample> actualSamples = sampleBusiness.findSampleTypes("asdf");

        checkSampleLists(actualSamples, emptyListFromBusiness);
    }

    @Test
    public void findSampleTypes_findSingle() throws Exception {

        when(sampleDAO.findSampleTypes("Bloom")).thenReturn(singleSampleListFromDAO);

        final List<OrionSample> actualSamples = sampleBusiness.findSampleTypes("Bloom");

        checkSampleLists(actualSamples, singleSampleListFromBusiness);
    }

    @Test
    public void findSampleTypes_findByWildcard() throws Exception {

        when(sampleDAO.findSampleTypes("Bud%")).thenReturn(multiSampleListFromDAO);

        final List<OrionSample> actualSamples = sampleBusiness.findSampleTypes("Bud*");

        checkSampleLists(actualSamples, multiSampleListFromBusiness);
    }

    @Test
    public void findSampleTypes_findAll() throws Exception {

        when(sampleDAO.findSampleTypes("%")).thenReturn(multiSampleListFromDAO);

        final List<OrionSample> actualSamples = sampleBusiness.findSampleTypes("");

        checkSampleLists(actualSamples, multiSampleListFromBusiness);
    }

    private void checkSampleLists(final List<OrionSample> actualSamples, final List<OrionSample> singleSampleListFromBusiness) {
        assertNotNull(actualSamples);

        for(int i=0; i<singleSampleListFromBusiness.size(); i++) {
            final OrionSample sample = actualSamples.get(i);
            assertEquals(sample.getSampleType(), singleSampleListFromBusiness.get(i).getSampleType());
            assertEquals(sample.getStorageCondition(), singleSampleListFromBusiness.get(i).getStorageCondition());
            assertEquals(sample.getActiveStatus(), singleSampleListFromBusiness.get(i).getActiveStatus());
        }
    }
}
