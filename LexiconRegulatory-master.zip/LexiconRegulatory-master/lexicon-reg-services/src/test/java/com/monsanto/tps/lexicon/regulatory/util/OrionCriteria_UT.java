package com.monsanto.tps.lexicon.regulatory.util;

import org.junit.Test;

import static junit.framework.Assert.assertEquals;

/**
 * Created by IntelliJ IDEA.
 * User: MMR
 * Date: 2/22/12
 * Time: 1:02 PM
 */
public class OrionCriteria_UT {

    @Test
    public void nullReplacedWithPercentage() throws Exception {
        assertEquals("%", OrionCriteria.format(null));
    }

    @Test
    public void variousWildCardsReplacedWithPercentage() throws Exception {
        assertEquals("%", OrionCriteria.format("*"));
        assertEquals("S%", OrionCriteria.format("S*"));
        assertEquals("S%", OrionCriteria.format("S%"));
        assertEquals("%ABC", OrionCriteria.format("*ABC"));
        assertEquals("%1%", OrionCriteria.format("*1*"));
        assertEquals("", OrionCriteria.format(""));
    }

}
