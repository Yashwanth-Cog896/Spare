package com.monsanto.tps.lexicon.regulatory.nonmonevent.validation;

import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import org.junit.Test;

/**
 * nbwald - May 25, 2009 3:18:35 PM
 */
public class EventNameSpecifiedRule_UT
{
   @Test
   public void testViolated_False()
      throws Exception
   {
      String eventName = "eventName";

      Rule<String> rule = new EventNameSpecifiedRule(eventName);

      assertThat(rule.violated(), is(false));
   }

   @Test
   public void testViolated_Null_True()
      throws Exception
   {
      String eventName = null;

      Rule<String> rule = new EventNameSpecifiedRule(eventName);

      assertThat(rule.violated(), is(true));
   }

   @Test
   public void testViolated_Empty_True()
      throws Exception
   {
      String eventName = "";

      Rule<String> rule = new EventNameSpecifiedRule(eventName);

      assertThat(rule.violated(), is(true));
   }

   @Test
   public void testGetViolation()
      throws Exception
   {
      assertThat(new EventNameSpecifiedRule(null).getViolation(), is("Event name is required."));
   }
}
