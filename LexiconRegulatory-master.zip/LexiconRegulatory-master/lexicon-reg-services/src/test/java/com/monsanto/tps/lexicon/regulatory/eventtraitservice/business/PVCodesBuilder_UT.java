/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.eventtraitservice.business;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import com.monsanto.tps.compliance.referencedata.molecularinfo.ConstructIdentifier;
import com.monsanto.tps.compliance.referencedata.molecularinfo.ConstructPVCodeAssignment;
import com.monsanto.tps.compliance.referencedata.molecularinfo.PvCode;
import com.monsanto.tps.compliance.referencedata.services.ProductVectorLookupService;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Crop;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber;
import com.monsanto.tps.lexicon.regulatory.DB.midas.model.EventConstructEntity;
import com.monsanto.tps.lexicon.regulatory.DB.midas.model.GermplasmEntity;
import com.monsanto.tps.lexicon.regulatory.DB.midas.model.GermplasmEventConstructEntity;
import com.monsanto.tps.lexicon.regulatory.DB.midas.model.MidasCropEntity;
import com.monsanto.tps.lexicon.regulatory.crop.dao.CropDao;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import static junit.framework.Assert.*;
import static org.mockito.Mockito.*;

/* vvkalu - 8/15/11 */
public class PVCodesBuilder_UT {

    private PVCodesBuilder pvCodesBuilder;
    private ProductVectorLookupService productVectorLookupService;
    private CropDao cropDao;

    @Before
    public void setUp() {
        productVectorLookupService = mock(ProductVectorLookupService.class);
        cropDao = mock(CropDao.class);
        pvCodesBuilder = new PVCodesBuilder();
        pvCodesBuilder.setCropDao(cropDao);
        pvCodesBuilder.setProductVectorLookupService(productVectorLookupService);
    }

    @Test
    public void test_getConstructIdToPVCodesMap_SingleConstruct_With_MonNumber_Crop() {
        Multimap<String, GermplasmEventConstructEntity> eventsToEventConstructsMap = ArrayListMultimap.create();
        Multimap<String, MonNumber> eventToMonNumberMap = ArrayListMultimap.create();
        GermplasmEventConstructEntity eventConstructEntity = new GermplasmEventConstructEntity();
        EventConstructEntity eventConstruct = new EventConstructEntity();
        eventConstruct.setConstructName("ECN");
        eventConstruct.setId(8783);
        eventConstruct.setEventName("EN");
        eventConstructEntity.setEventConstruct(eventConstruct);
        eventsToEventConstructsMap.put("EN", eventConstructEntity);
        MonNumber monNumber = new MonNumber();
        monNumber.setEvent("EN");
        Crop lexiconCrop = new Crop();
        lexiconCrop.setCropPubkey("53763");
        monNumber.setCrop(lexiconCrop);
        eventToMonNumberMap.put("EN", monNumber);
        ConstructIdentifier constructIdentifier = new ConstructIdentifier();
        constructIdentifier.setNames(Arrays.asList("ECN"));
        List<PvCode> pvCodes = PVCodeAssignmentBuilder.formPVCodes(Arrays.asList("PVC1", "PVC2"));
        ConstructPVCodeAssignment pvCodeAssignment = new ConstructPVCodeAssignment(constructIdentifier, pvCodes);
        when(productVectorLookupService.findProductVectorsByCropIdAndConstructs(53763, Arrays.asList(constructIdentifier))).thenReturn(Arrays.asList(pvCodeAssignment));
        Multimap<Long, ConstructPVCodeAssignment> constructIdToPVCodesMap = pvCodesBuilder.getConstructIdToPVCodesMap(eventsToEventConstructsMap, eventToMonNumberMap);
        assertNotNull(constructIdToPVCodesMap);
        Collection<ConstructPVCodeAssignment> pvCodeAssignments = constructIdToPVCodesMap.get(8783L);
        assertEquals(1, pvCodeAssignments.size());
        ConstructIdentifier resultConstruct = pvCodeAssignments.iterator().next().getConstructIdentifier();
        assertEquals(constructIdentifier.getNames(), resultConstruct.getNames());
        List<PvCode> codeList = pvCodeAssignments.iterator().next().getPVCodes();
        assertTrue(codeList.contains(new PvCode("PVC1", null)));
        assertTrue(codeList.contains(new PvCode("PVC2", null)));
        verifyZeroInteractions(cropDao);
    }

    @Test
    public void test_getConstructIdToPVCodesMap_SingleConstruct_With_LexiconCrops() {
        Multimap<String, GermplasmEventConstructEntity> eventsToEventConstructsMap = ArrayListMultimap.create();
        Multimap<String, MonNumber> eventToMonNumberMap = ArrayListMultimap.create();
        GermplasmEventConstructEntity eventConstructEntity = new GermplasmEventConstructEntity();
        GermplasmEntity germplasm = new GermplasmEntity();
        MidasCropEntity midasCropEntity = new MidasCropEntity();
        midasCropEntity.setName("MIDAS_CROP");
        germplasm.setCrop(midasCropEntity);
        eventConstructEntity.setGermplasm(germplasm);
        EventConstructEntity eventConstruct = new EventConstructEntity();
        eventConstruct.setConstructName("ECN");
        eventConstruct.setId(8783);
        eventConstruct.setEventName("EN");
        eventConstructEntity.setEventConstruct(eventConstruct);
        eventsToEventConstructsMap.put("EN", eventConstructEntity);
        Crop lexiconCrop = new Crop();
        lexiconCrop.setCropPubkey("53763");
        lexiconCrop.setAbbreviation("ABBR");
        when(cropDao.findByName("MIDAS_CROP")).thenReturn(lexiconCrop);
        Crop lexiconCrop1 = new Crop();
        lexiconCrop1.setCropPubkey("36363");
        when(cropDao.findByAbbreviation("ABBR")).thenReturn(Arrays.asList(lexiconCrop, lexiconCrop1));
        ConstructIdentifier constructIdentifier = new ConstructIdentifier();
        constructIdentifier.setNames(Arrays.asList("ECN"));
        List<PvCode> pvCodes1 = PVCodeAssignmentBuilder.formPVCodes(Arrays.asList("PVC1", "PVC2"));
        ConstructPVCodeAssignment pvCodeAssignment = new ConstructPVCodeAssignment(constructIdentifier, pvCodes1);
        when(productVectorLookupService.findProductVectorsByCropIdAndConstructs(53763, Arrays.asList(constructIdentifier))).thenReturn(
                Arrays.asList(pvCodeAssignment));
        List<PvCode> pvCodes2 = PVCodeAssignmentBuilder.formPVCodes(Arrays.asList("PVC3", "PVC4"));
        ConstructPVCodeAssignment pvCodeAssignment1 = new ConstructPVCodeAssignment(constructIdentifier, pvCodes2);
        when(productVectorLookupService.findProductVectorsByCropIdAndConstructs(36363, Arrays.asList(constructIdentifier))).thenReturn(
                Arrays.asList(pvCodeAssignment1));
        Multimap<Long, ConstructPVCodeAssignment> constructIdToPVCodesMap = pvCodesBuilder.getConstructIdToPVCodesMap(eventsToEventConstructsMap,
                eventToMonNumberMap);
        assertNotNull(constructIdToPVCodesMap);
        List<ConstructPVCodeAssignment> pvCodeAssignments = (List<ConstructPVCodeAssignment>) constructIdToPVCodesMap.get(8783L);
        assertEquals(2, pvCodeAssignments.size());
        ConstructIdentifier resultConstruct = pvCodeAssignments.iterator().next().getConstructIdentifier();
        assertEquals(constructIdentifier.getNames(), resultConstruct.getNames());
        assertTrue(pvCodeAssignments.get(0).getPVCodes().contains(new PvCode("PVC1", null)));
        assertTrue(pvCodeAssignments.get(0).getPVCodes().contains(new PvCode("PVC2", null)));
        assertTrue(pvCodeAssignments.get(1).getPVCodes().contains(new PvCode("PVC3", null)));
        assertTrue(pvCodeAssignments.get(1).getPVCodes().contains(new PvCode("PVC4", null)));
    }

    @Test
    public void test_getConstructIdToPVCodesMap_CombinedConstruct_With_LexiconCrops() {
        Multimap<String, GermplasmEventConstructEntity> eventsToEventConstructsMap = ArrayListMultimap.create();
        Multimap<String, MonNumber> eventToMonNumberMap = ArrayListMultimap.create();
        GermplasmEventConstructEntity eventConstructEntity = new GermplasmEventConstructEntity();
        GermplasmEntity germplasm = new GermplasmEntity();
        MidasCropEntity midasCropEntity = new MidasCropEntity();
        midasCropEntity.setName("MIDAS_CROP");
        germplasm.setCrop(midasCropEntity);
        eventConstructEntity.setGermplasm(germplasm);
        EventConstructEntity eventConstruct = new EventConstructEntity();
        eventConstruct.setConstructName("ECN,ECN1");
        eventConstruct.setId(8783);
        eventConstruct.setEventName("EN");
        eventConstructEntity.setEventConstruct(eventConstruct);
        eventsToEventConstructsMap.put("EN", eventConstructEntity);
        Crop lexiconCrop = new Crop();
        lexiconCrop.setCropPubkey("53763");
        lexiconCrop.setAbbreviation("ABBR");
        when(cropDao.findByName("MIDAS_CROP")).thenReturn(lexiconCrop);
        Crop lexiconCrop1 = new Crop();
        lexiconCrop1.setCropPubkey("36363");
        when(cropDao.findByAbbreviation("ABBR")).thenReturn(Arrays.asList(lexiconCrop, lexiconCrop1));

        ConstructIdentifier constructIdentifier = new ConstructIdentifier();
        constructIdentifier.setNames(Arrays.asList("ECN", "ECN1"));
        List<PvCode> pvCodes1 = PVCodeAssignmentBuilder.formPVCodes(Arrays.asList("PVC1", "PVC2"));
        ConstructPVCodeAssignment pvCodeAssignment = new ConstructPVCodeAssignment(constructIdentifier, pvCodes1);
        when(productVectorLookupService.findProductVectorsByCropIdAndConstructs(53763, Arrays.asList(constructIdentifier))).thenReturn(
                Arrays.asList(pvCodeAssignment));

        List<PvCode> pvCodes2 = PVCodeAssignmentBuilder.formPVCodes(Arrays.asList("PVC3", "PVC4"));
        ConstructPVCodeAssignment pvCodeAssignment1 = new ConstructPVCodeAssignment(constructIdentifier, pvCodes2);
        when(productVectorLookupService.findProductVectorsByCropIdAndConstructs(36363, Arrays.asList(constructIdentifier))).thenReturn(
                Arrays.asList(pvCodeAssignment1));

        Multimap<Long, ConstructPVCodeAssignment> constructIdToPVCodesMap = pvCodesBuilder.getConstructIdToPVCodesMap(eventsToEventConstructsMap,
                eventToMonNumberMap);
        assertNotNull(constructIdToPVCodesMap);
        List<ConstructPVCodeAssignment> pvCodeAssignments = (List<ConstructPVCodeAssignment>) constructIdToPVCodesMap.get(8783L);
        assertEquals(2, pvCodeAssignments.size());
        ConstructIdentifier resultConstruct = pvCodeAssignments.iterator().next().getConstructIdentifier();
        assertEquals(constructIdentifier.getNames(), resultConstruct.getNames());
        assertTrue(pvCodeAssignments.get(0).getPVCodes().contains(new PvCode("PVC1", null)));
        assertTrue(pvCodeAssignments.get(0).getPVCodes().contains(new PvCode("PVC2", null)));
        assertTrue(pvCodeAssignments.get(1).getPVCodes().contains(new PvCode("PVC3", null)));
        assertTrue(pvCodeAssignments.get(1).getPVCodes().contains(new PvCode("PVC4", null)));
    }

    @Test
    public void test_getConstructIdToPVCodesMap_Two_DifferentEvents_CombinedConstruct_With_LexiconCrops() {
        Multimap<String, GermplasmEventConstructEntity> eventsToEventConstructsMap = ArrayListMultimap.create();
        Multimap<String, MonNumber> eventToMonNumberMap = ArrayListMultimap.create();
        GermplasmEventConstructEntity eventConstructEntity = new GermplasmEventConstructEntity();
        GermplasmEntity germplasm = new GermplasmEntity();
        MidasCropEntity midasCropEntity = new MidasCropEntity();
        midasCropEntity.setName("MIDAS_CROP");
        germplasm.setCrop(midasCropEntity);
        eventConstructEntity.setGermplasm(germplasm);
        EventConstructEntity eventConstruct = new EventConstructEntity();
        eventConstruct.setConstructName("ECN,ECN1");
        eventConstruct.setId(8783);
        eventConstruct.setEventName("EN");
        eventConstructEntity.setEventConstruct(eventConstruct);
        GermplasmEventConstructEntity eventConstructEntity1 = new GermplasmEventConstructEntity();
        GermplasmEntity germplasm1 = new GermplasmEntity();
        germplasm1.setCrop(midasCropEntity);
        eventConstructEntity1.setGermplasm(germplasm);
        EventConstructEntity eventConstruct1 = new EventConstructEntity();
        eventConstruct1.setConstructName("ECN/ECN1");
        eventConstruct1.setId(7464);
        eventConstruct1.setEventName("EN1");
        eventConstructEntity1.setEventConstruct(eventConstruct1);
        eventsToEventConstructsMap.put("EN", eventConstructEntity);
        eventsToEventConstructsMap.put("EN1", eventConstructEntity1);

        Crop lexiconCrop = new Crop();
        lexiconCrop.setCropPubkey("53763");
        lexiconCrop.setAbbreviation("ABBR");
        when(cropDao.findByName("MIDAS_CROP")).thenReturn(lexiconCrop);
        Crop lexiconCrop1 = new Crop();
        lexiconCrop1.setCropPubkey("36363");
        when(cropDao.findByAbbreviation("ABBR")).thenReturn(Arrays.asList(lexiconCrop, lexiconCrop1));

        ConstructIdentifier constructIdentifier = new ConstructIdentifier();
        constructIdentifier.setNames(Arrays.asList("ECN", "ECN1"));

        List<PvCode> pvCodes1 = PVCodeAssignmentBuilder.formPVCodes(Arrays.asList("PVC1", "PVC2"));
        ConstructPVCodeAssignment pvCodeAssignment = new ConstructPVCodeAssignment(constructIdentifier, pvCodes1);
        when(productVectorLookupService.findProductVectorsByCropIdAndConstructs(53763, Arrays.asList(constructIdentifier))).thenReturn(
                Arrays.asList(pvCodeAssignment));

        List<PvCode> pvCodes2 = PVCodeAssignmentBuilder.formPVCodes(Arrays.asList("PVC3", "PVC4"));
        ConstructPVCodeAssignment pvCodeAssignment1 = new ConstructPVCodeAssignment(constructIdentifier, pvCodes2);
        when(productVectorLookupService.findProductVectorsByCropIdAndConstructs(36363, Arrays.asList(constructIdentifier))).thenReturn(
                Arrays.asList(pvCodeAssignment1));

        List<PvCode> pvCodes3 = PVCodeAssignmentBuilder.formPVCodes(Arrays.asList("PVC5", "PVC6"));
        ConstructPVCodeAssignment pvCodeAssignment2 = new ConstructPVCodeAssignment(constructIdentifier, pvCodes3);
        when(productVectorLookupService.findProductVectorsByCropIdAndConstructs(53763, Arrays.asList(constructIdentifier))).thenReturn(
                Arrays.asList(pvCodeAssignment2));

        List<PvCode> pvCodes4 = PVCodeAssignmentBuilder.formPVCodes(Arrays.asList("PVC7", "PVC8"));
        ConstructPVCodeAssignment pvCodeAssignment3 = new ConstructPVCodeAssignment(constructIdentifier, pvCodes4);
        when(productVectorLookupService.findProductVectorsByCropIdAndConstructs(36363, Arrays.asList(constructIdentifier))).thenReturn(
                Arrays.asList(pvCodeAssignment3));

        Multimap<Long, ConstructPVCodeAssignment> constructIdToPVCodesMap = pvCodesBuilder.getConstructIdToPVCodesMap(eventsToEventConstructsMap,
                eventToMonNumberMap);
        assertNotNull(constructIdToPVCodesMap);
        List<ConstructPVCodeAssignment> pvCodeAssignments = (List<ConstructPVCodeAssignment>) constructIdToPVCodesMap.get(8783L);
        assertEquals(2, pvCodeAssignments.size());
        ConstructIdentifier resultConstruct = pvCodeAssignments.iterator().next().getConstructIdentifier();
        assertEquals(constructIdentifier.getNames(), resultConstruct.getNames());
        List<ConstructPVCodeAssignment> pvCodeAssignments1 = (List<ConstructPVCodeAssignment>) constructIdToPVCodesMap.get(7464L);
        assertEquals(2, pvCodeAssignments.size());
        ConstructIdentifier resultConstruct1 = pvCodeAssignments1.iterator().next().getConstructIdentifier();
        assertEquals(constructIdentifier.getNames(), resultConstruct1.getNames());
    }
}