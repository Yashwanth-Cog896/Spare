package com.monsanto.tps.lexicon.regulatory.agency.util;

import com.monsanto.tps.lexicon.agency.AgencySaveUpdateRequest;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.BuilderID;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Agency;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.AgencyDepartment;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Country;
import junit.framework.TestCase;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

/**
 * rrchak1 - Oct 20, 2008 3:23:46 PM
 */
public class AgencyBeanUtil_UT
   extends TestCase
{
   private BuilderID builderID;

   public void testReturnsAgencyForGivenAgencyDepartmentsWithSameAgency()
      throws Exception
   {
      AgencyBeanUtil agencyBeanUtil = new AgencyBeanUtil();
      builderID = new BuilderID();
      Agency agency = new Agency();
      agency.setAgencyAbbr("agencyAbbr");
      agency.setAgencyId(builderID.id());
      agency.setAgencyPubkey(builderID.sid());
      agency.setCountry(new Country());
      agency.setActive("true");
      agency.setAgencyName("Name");

      builderID = new BuilderID();
      AgencyDepartment agencyDepartment = new AgencyDepartment();
      agencyDepartment.setAddress1("A1");
      agencyDepartment.setAddress2("A2");
      agencyDepartment.setActive("true");
      agencyDepartment.setAgencyDeptAbbr("deptAbbr");
      agencyDepartment.setAgencyDeptId(builderID.id());
      agencyDepartment.setAgencyDeptPubkey(builderID.sid());
      agencyDepartment.setAgencyDeptName("deptName");
      agency.getDepartments().add(agencyDepartment);

      builderID = new BuilderID();
      AgencyDepartment departmentTwo = new AgencyDepartment();
      departmentTwo.setAddress1("A1");
      departmentTwo.setAddress2("A2");
      departmentTwo.setActive("true");
      departmentTwo.setAgencyDeptAbbr("deptAbbr");
      departmentTwo.setAgencyDeptId(builderID.id());
      departmentTwo.setAgencyDeptPubkey(builderID.sid());
      departmentTwo.setAgencyDeptName("deptName");
      agency.getDepartments().add(departmentTwo);

      agencyDepartment.setAgency(agency);
      departmentTwo.setAgency(agency);

      AgencyDepartment[] departments = new AgencyDepartment[2];
      departments[0] = agencyDepartment;
      departments[1] = departmentTwo;

      com.monsanto.tps.lexicon.agency.Agency[] agencies = agencyBeanUtil.buildAgencies(departments);
      assertNotNull(agencies);
      assertEquals(1, agencies.length);
      com.monsanto.tps.lexicon.agency.Agency output = agencies[0];
      assertNotNull(output);
      assertNotNull(output.getDepartments());
      assertEquals(2, output.getDepartments().size());
   }

   public void testReturnsAgenciesForGivenAgencyDepartmentsWithDifferentAgencies()
      throws Exception
   {
      AgencyBeanUtil agencyBeanUtil = new AgencyBeanUtil();
      builderID = new BuilderID();
      Agency agencyOne = new Agency();
      agencyOne.setAgencyAbbr("agencyAbbr");
      agencyOne.setAgencyId(builderID.id());
      agencyOne.setAgencyPubkey(builderID.sid());
      agencyOne.setCountry(new Country());
      agencyOne.setActive("true");
      agencyOne.setAgencyName("Name");

      builderID = new BuilderID();
      AgencyDepartment agencyDepartment = new AgencyDepartment();
      agencyDepartment.setAddress1("A1");
      agencyDepartment.setAddress2("A2");
      agencyDepartment.setActive("true");
      agencyDepartment.setAgencyDeptAbbr("deptAbbr");
      agencyDepartment.setAgencyDeptId(builderID.id());
      agencyDepartment.setAgencyDeptPubkey(builderID.sid());
      agencyDepartment.setAgencyDeptName("deptName");
      agencyOne.getDepartments().add(agencyDepartment);
      agencyDepartment.setAgency(agencyOne);

      builderID = new BuilderID();
      Agency agencyTwo = new Agency();
      agencyTwo.setAgencyAbbr("USDA");
      agencyTwo.setAgencyId(builderID.id());
      agencyTwo.setAgencyPubkey(builderID.sid());
      agencyTwo.setCountry(new Country());
      agencyTwo.setActive("false");
      agencyTwo.setAgencyName("United States Department of Agriculture");

      builderID = new BuilderID();
      AgencyDepartment departmentTwo = new AgencyDepartment();
      departmentTwo.setAddress1("A1");
      departmentTwo.setAddress2("A2");
      departmentTwo.setActive("true");
      departmentTwo.setAgencyDeptAbbr("deptAbbr");
      departmentTwo.setAgencyDeptId(builderID.id());
      departmentTwo.setAgencyDeptPubkey(builderID.sid());
      departmentTwo.setAgencyDeptName("deptName");
      agencyTwo.getDepartments().add(departmentTwo);
      departmentTwo.setAgency(agencyTwo);

      AgencyDepartment[] departments = new AgencyDepartment[2];
      departments[0] = agencyDepartment;
      departments[1] = departmentTwo;

      com.monsanto.tps.lexicon.agency.Agency[] agencies = agencyBeanUtil.buildAgencies(departments);
      assertNotNull(agencies);
      assertEquals(2, agencies.length);
      com.monsanto.tps.lexicon.agency.Agency output = agencies[0];
      assertNotNull(output);
      assertNotNull(output.getDepartments());
      assertEquals(1, output.getDepartments().size());
   }

   public void testEmptyDepartmentsReturnsEmptyAgencies()
      throws Exception
   {
      AgencyBeanUtil agencyBeanUtil = new AgencyBeanUtil();
      AgencyDepartment[] departments = new AgencyDepartment[0];
      com.monsanto.tps.lexicon.agency.Agency[] agencies = agencyBeanUtil.buildAgencies(departments);
      assertNotNull(agencies);
      assertEquals(0, agencies.length);
   }

   public void testBuildAgencyDepartmentDbObject_BuildsCorrectly() {
      AgencySaveUpdateRequest request = new AgencySaveUpdateRequest();
      request.setActive(true);
      request.setAgencyAbbr("testAgencyAbbvr");
      request.setAgencyName("testAgencyName");
      request.setCountryIsoCode("US");
      request.setSurfaceAreaUomCode("UM");
      request.setAddress1("addr1");
      request.setAddress2("addr2");
      request.setAgencyDeptAbbr("testDeptAbbr");
      request.setAgencyDeptName("testDeptName");
      request.setCity("city");
      request.setPostalCode("12345");
      request.setSubCountryAbbr("S1");
      request.setSubSubCountryName("S2");
      request.setAuditComment("TestAuditComment");
      request.setAgencyPubkey("agencypubkey");
      request.setAgencyDeptPubkey("agencydeptpubkey");

      AgencyBeanUtil beanUtil = new AgencyBeanUtil();
      AgencyDepartment department = beanUtil.buildAgencyDepartmentDBObject(request);
      Agency agency = department.getAgency();
      assertThat(agency.getActive(), is("y"));
      assertThat(agency.getAgencyAbbr(), is("testAgencyAbbvr"));
      assertThat(agency.getAgencyName(), is("testAgencyName"));
      assertThat(agency.getCountry().getIsoCode(), is("US"));
      assertThat(agency.getSurfaceAreaUomCode(), is("UM"));
      assertThat(department.getActive(), is("y"));
      assertThat(department.getAgencyDeptAbbr(), is("testDeptAbbr"));
      assertThat(department.getAgencyDeptName(), is("testDeptName"));
      assertThat(department.getAddress1(), is("addr1"));
      assertThat(department.getAddress2(), is("addr2"));
      assertThat(department.getCity(), is("city"));
      assertThat(department.getPostalCode(), is("12345"));
      assertThat(department.getSubCountryAbbr(), is("S1"));
      assertThat(department.getSubSubCountryName(), is("S2"));
      assertThat(department.getAgencyDeptPubkey(), is("agencydeptpubkey"));
      assertThat(agency.getAgencyPubkey(), is("agencypubkey"));
   }
}
