package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Company;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;


public class CompanyBuilder
{
   public static Company monsanto() {
      return findCompanyByName("MONSANTO");
   }

   private static Company findCompanyByName(String companyName) {
      Criteria companyByNameCriteria = TestSessions.getLexiconSession().createCriteria(Company.class)
         .add(Restrictions.eq("companyName", companyName));
      return (Company) companyByNameCriteria.uniqueResult();
   }

}