package com.monsanto.tps.lexicon.regulatory.event.service;

import com.monsanto.tps.aop.metric.DataPointHolder;
import com.monsanto.tps.lexicon.event.AgencyMaterialDeregulationStatus;
import com.monsanto.tps.lexicon.event.EventDeregulationStatus;
import com.monsanto.tps.lexicon.event.EventInfo;
import com.monsanto.tps.lexicon.regulatory.event.strategy.EventInfoByAgencyAbbrStrategy;
import com.monsanto.tps.lexicon.regulatory.event.strategy.EventInfoByAlignmentPubkeyStrategy;
import com.monsanto.tps.lexicon.regulatory.event.strategy.EventInfoByMonNumberStrategy;
import com.monsanto.tps.lexicon.regulatory.event.strategy.EventInfoByNameAndCropStrategy;
import com.monsanto.tps.lexicon.regulatory.event.strategy.EventStatusByCropStrategy;
import com.monsanto.tps.lexicon.regulatory.event.strategy.EventStatusByEventAgencyAndCropStrategy;
import org.junit.Before;
import org.junit.Test;

import static org.easymock.EasyMock.aryEq;
import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.eq;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.expectLastCall;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

/**
 * rrchak1 - Dec 17, 2008 11:40:30 AM
 */
public class EventSearchServiceImpl_UT {
    private EventSearchServiceImpl eventSearchService;

    private final String eventName = "ZM_1111";
    private final String cropName = "CORN";
    private final String monNumberValue = "MON 1111";
    private EventInfoByNameAndCropStrategy byNameAndCropStrategy;
    private EventInfoByMonNumberStrategy byMonNumberStrategy;
    private EventInfoByAlignmentPubkeyStrategy byAlignmentPubkeyStrategy;
    private EventInfoByAgencyAbbrStrategy byAgencyAbbrStrategy;
    private EventStatusByEventAgencyAndCropStrategy byEventAgencyAndCropStrategy;
    private EventStatusByCropStrategy byCropStrategy;
    private DataPointHolder dataPointHolder;

    @Before
    public void before() {
        byNameAndCropStrategy = createMock(EventInfoByNameAndCropStrategy.class);
        byMonNumberStrategy = createMock(EventInfoByMonNumberStrategy.class);
        byAlignmentPubkeyStrategy = createMock(EventInfoByAlignmentPubkeyStrategy.class);
        byAgencyAbbrStrategy = createMock(EventInfoByAgencyAbbrStrategy.class);
        byEventAgencyAndCropStrategy = createMock(EventStatusByEventAgencyAndCropStrategy.class);
        byCropStrategy = createMock(EventStatusByCropStrategy.class);
        dataPointHolder = createMock(DataPointHolder.class);
        eventSearchService = new EventSearchServiceImpl();
        eventSearchService.setByNameAndCropStrategy(byNameAndCropStrategy);
        eventSearchService.setByMonNumberStrategy(byMonNumberStrategy);
        eventSearchService.setByAlignmentPubkeyStrategy(byAlignmentPubkeyStrategy);
        eventSearchService.setByAgencyAbbrStrategy(byAgencyAbbrStrategy);
        eventSearchService.setByEventAgencyAndCropStrategy(byEventAgencyAndCropStrategy);
        eventSearchService.setDataPointHolder(dataPointHolder);
        eventSearchService.setByCropStrategy(byCropStrategy);
    }

    @Test
    public void findByEventAndCrop()
            throws Exception {
        EventInfo expected = new EventInfo();
        expect(byNameAndCropStrategy.find(aryEq(new String[]{eventName}), eq(cropName))).andReturn(new EventInfo[]{expected});
        replay(byNameAndCropStrategy);

        EventInfo actual = eventSearchService.findByEventAndCrop(eventName, cropName);

        verify(byNameAndCropStrategy);
        assertThat(actual, is(expected));
    }

    @Test
    public void testFindByEventsAndCrop()
            throws Exception {
        String eventName2 = eventName + "2";
        EventInfo expected = new EventInfo();
        EventInfo expected2 = new EventInfo();
        expect(byNameAndCropStrategy.find(aryEq(new String[]{eventName, eventName2}), eq(cropName))).andReturn(new EventInfo[]{expected, expected2}).times(1);
        dataPointHolder.add("Num Retrieved", 2);
        expectLastCall();
        replay(byNameAndCropStrategy, dataPointHolder);

        String[] eventNames = {eventName, eventName2};
        EventInfo[] actuals = eventSearchService.findByEventsAndCrop(eventNames, cropName);

        verify(byNameAndCropStrategy, dataPointHolder);
        assertThat(actuals.length, is(2));
    }

    @Test
    public void testFindByMonNumber()
            throws Exception {
        EventInfo expected = new EventInfo();
        expect(byMonNumberStrategy.find(monNumberValue)).andReturn(expected);
        replay(byMonNumberStrategy);

        EventInfo actual = eventSearchService.findByMonNumber(monNumberValue);

        verify(byMonNumberStrategy);
        assertThat(actual, is(expected));
    }

    @Test
    public void testFindByMonNumbers_NoMonNumbersSpecified()
            throws Exception {
        EventInfo expected = new EventInfo();
        expect(byMonNumberStrategy.find(monNumberValue)).andReturn(expected).times(2);
        dataPointHolder.add("Num Retrieved", 2);
        expectLastCall();
        replay(byMonNumberStrategy, dataPointHolder);

        String[] monNumbers = {monNumberValue, monNumberValue};
        EventInfo[] actuals = eventSearchService.findByMonNumbers(monNumbers);

        verify(byMonNumberStrategy, dataPointHolder);
        assertThat(actuals.length, is(2));
    }

    @Test
    public void testFindByEventAgencyAlignmentPubkey()
            throws Exception {
        EventInfo expectedEventInfo = new EventInfo();
        EventInfo[] expected = {expectedEventInfo};
        String[] eventAgencyAlignmentPubkey = {"1111"};
        expect(byAlignmentPubkeyStrategy.find(eventAgencyAlignmentPubkey)).andReturn(expected);
        dataPointHolder.add("Num Retrieved", 1);
        expectLastCall();
        replay(byAlignmentPubkeyStrategy, dataPointHolder);

        EventInfo[] actuals = eventSearchService.findByEventAgencyAlignmentPubkey(eventAgencyAlignmentPubkey);

        verify(byAlignmentPubkeyStrategy, dataPointHolder);
        assertThat(actuals.length, is(1));
    }

    @Test
    public void testFindByEventAgencyAlignmentPubkey_NoRequests_NoResponses()
            throws Exception {
        dataPointHolder.add("Num Retrieved", 0);
        expectLastCall();
        replay(byAlignmentPubkeyStrategy, dataPointHolder);

        EventInfo[] actuals = eventSearchService.findByEventAgencyAlignmentPubkey(new String[]{});

        verify(byAlignmentPubkeyStrategy, dataPointHolder);
        assertThat(actuals.length, is(0));
    }

    @Test
    public void testFindByAgencyAbbr()
            throws Exception {
        EventInfo expectedEventInfo = new EventInfo();
        EventInfo[] expected = {expectedEventInfo};
        String[] agencyAbbr = {"USDA"};
        expect(byAgencyAbbrStrategy.find(agencyAbbr)).andReturn(expected);
        dataPointHolder.add("Num Retrieved", 1);
        expectLastCall();
        replay(byAgencyAbbrStrategy, dataPointHolder);

        EventInfo[] actuals = eventSearchService.findByAgencyAbbr(agencyAbbr);

        verify(byAgencyAbbrStrategy, dataPointHolder);
        assertThat(actuals.length, is(1));
    }

    @Test
    public void testFindByAgencyAbbr_NoRequests_NoResponses()
            throws Exception {
        dataPointHolder.add("Num Retrieved", 0);
        expectLastCall();
        replay(byAgencyAbbrStrategy, dataPointHolder);

        EventInfo[] actuals = eventSearchService.findByAgencyAbbr(new String[]{});

        verify(byAgencyAbbrStrategy, dataPointHolder);
        assertThat(actuals.length, is(0));
    }

    @Test
    public void getEventDeregulationStatus() {
        String[] events = {eventName};
        String[] agencyAbbrs = {"USDA"};
        EventDeregulationStatus eventDeregulationStatus = new EventDeregulationStatus();
        EventDeregulationStatus[] expected = {eventDeregulationStatus};
        expect(byEventAgencyAndCropStrategy.find(events, cropName, agencyAbbrs)).andReturn(expected);
        dataPointHolder.add("Num Retrieved", 1);
        expectLastCall();
        replay(byEventAgencyAndCropStrategy, dataPointHolder);

        EventDeregulationStatus[] actuals = eventSearchService.getEventDeregulationStatus(events, cropName, agencyAbbrs);

        verify(byEventAgencyAndCropStrategy, dataPointHolder);
        assertThat(actuals.length, is(1));
    }

    @Test
    public void testGetEventDeregulationStatus_NullEvents_ReturnsNoResults()
            throws Exception {
        String[] events = null;
        String[] agencyAbbrs = {"USDA"};
        dataPointHolder.add("Num Retrieved", 0);
        expectLastCall();
        replay(byEventAgencyAndCropStrategy, dataPointHolder);

        EventDeregulationStatus[] actuals = eventSearchService.getEventDeregulationStatus(events, cropName, agencyAbbrs);

        verify(byEventAgencyAndCropStrategy, dataPointHolder);
        assertThat(actuals.length, is(0));
    }

    @Test
    public void testGetEventDeregulationStatus_EmptyEvents_ReturnsNoResults()
            throws Exception {
        String[] events = {};
        String[] agencyAbbrs = {"USDA"};
        dataPointHolder.add("Num Retrieved", 0);
        expectLastCall();
        replay(byEventAgencyAndCropStrategy, dataPointHolder);

        EventDeregulationStatus[] actuals = eventSearchService.getEventDeregulationStatus(events, cropName, agencyAbbrs);

        verify(byEventAgencyAndCropStrategy, dataPointHolder);
        assertThat(actuals.length, is(0));
    }

    @Test
    public void testGetEventDeregulationStatus_NullAgencies_ReturnsNoResults()
            throws Exception {
        String[] events = {eventName};
        String[] agencyAbbrs = null;
        dataPointHolder.add("Num Retrieved", 0);
        expectLastCall();
        replay(byEventAgencyAndCropStrategy, dataPointHolder);

        EventDeregulationStatus[] actuals = eventSearchService.getEventDeregulationStatus(events, cropName, agencyAbbrs);

        verify(byEventAgencyAndCropStrategy, dataPointHolder);
        assertThat(actuals.length, is(0));
    }

    @Test
    public void testGetEventDeregulationStatus_EmptyAgencies_ReturnsNoResults()
            throws Exception {
        String[] events = {eventName};
        String[] agencyAbbrs = {};
        dataPointHolder.add("Num Retrieved", 0);
        expectLastCall();
        replay(byEventAgencyAndCropStrategy, dataPointHolder);

        EventDeregulationStatus[] actuals = eventSearchService.getEventDeregulationStatus(events, cropName, agencyAbbrs);

        verify(byEventAgencyAndCropStrategy, dataPointHolder);
        assertThat(actuals.length, is(0));
    }

    @Test
    public void testGetEventDeregulationStatusEventsCrops() {

        String[] events = {eventName};

        EventDeregulationStatus eventDeregulationStatus = new EventDeregulationStatus();
        EventDeregulationStatus[] expected = {eventDeregulationStatus};
        expect(byCropStrategy.find(events, cropName)).andReturn(expected);
        dataPointHolder.add("Num Retrieved", 1);
        expectLastCall();
        replay(byCropStrategy, dataPointHolder);

        EventDeregulationStatus[] actuals = eventSearchService.getEventDeregulationStatus(events, cropName);

        verify(byCropStrategy, dataPointHolder);
        assertThat(actuals.length, is(1));
    }

    @Test
    public void testGetEventDeregulationStatusMaterialCrops() {

        String[] events = {eventName};

        AgencyMaterialDeregulationStatus eventDeregulationStatus = new AgencyMaterialDeregulationStatus();
        AgencyMaterialDeregulationStatus[] expected = {eventDeregulationStatus};
        expect(byCropStrategy.findByMaterialName(events, cropName)).andReturn(expected);
        dataPointHolder.add("Num Retrieved", 1);
        expectLastCall();
        replay(byCropStrategy, dataPointHolder);

        AgencyMaterialDeregulationStatus[] actuals = eventSearchService.getAgencyMaterialDeregulationStatus(events, cropName);

        verify(byCropStrategy, dataPointHolder);
        assertThat(actuals.length, is(1));
    }

    @Test
    public void testGetAgencyMaterialDeregulationStatus_NullMaterials_ReturnsNoResults()
            throws Exception {
        String[] events = null;
        dataPointHolder.add("Num Retrieved", 0);
        expectLastCall();
        replay(byCropStrategy, dataPointHolder);

        AgencyMaterialDeregulationStatus[] actuals = eventSearchService.getAgencyMaterialDeregulationStatus(events, cropName);

        verify(byCropStrategy, dataPointHolder);
        assertThat(actuals.length, is(0));
    }
}
