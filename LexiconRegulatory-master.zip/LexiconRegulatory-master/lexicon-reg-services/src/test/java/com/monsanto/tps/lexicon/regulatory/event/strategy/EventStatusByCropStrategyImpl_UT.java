package com.monsanto.tps.lexicon.regulatory.event.strategy;

import com.monsanto.tps.lexicon.event.AgencyMaterialDeregulationStatus;
import com.monsanto.tps.lexicon.event.EventDeregulationStatus;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;
import com.monsanto.tps.lexicon.regulatory.event.dao.EventAgencyAlignmentDao;
import com.monsanto.tps.lexicon.regulatory.event.delegate.EventSplitter;
import com.monsanto.tps.lexicon.regulatory.event.delegate.EventStatusBuilder;
import com.monsanto.tps.lexicon.regulatory.event.delegate.MaterialStatusBuilder;
import org.apache.commons.lang.ArrayUtils;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.easymock.EasyMock.expect;
import static org.easymock.classextension.EasyMock.aryEq;
import static org.easymock.classextension.EasyMock.createMock;
import static org.easymock.classextension.EasyMock.eq;
import static org.easymock.classextension.EasyMock.replay;
import static org.easymock.classextension.EasyMock.verify;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

/**
 * rrchak1 - Jun 23, 2009 11:18:09 AM
 */
public class EventStatusByCropStrategyImpl_UT {

    EventStatusByCropStrategy eventStatusByCropStrategy;
    private EventAgencyAlignmentDao eventAgencyAlignmentDao;
    private String EVENT = "EVENT";
    private String USDA_AGENCY = "USDA";
    private String cropName = "CANOLA";
    private EventStatusBuilder eventStatusBuilder;
    private EventSplitter eventSplitter;
    private MaterialStatusBuilder materialStatusBuilder;

    @Before
    public void before() {
        eventAgencyAlignmentDao = createMock(EventAgencyAlignmentDao.class);
        eventStatusBuilder = createMock(EventStatusBuilder.class);
        eventSplitter = new EventSplitter();
        materialStatusBuilder = createMock(MaterialStatusBuilder.class);
        eventStatusByCropStrategy = new EventStatusByCropStrategyImpl(
                eventAgencyAlignmentDao, eventStatusBuilder, eventSplitter, materialStatusBuilder);
    }

    @Test
    public void test_find() {
        String[] events = new String[]{EVENT};
        String[] agencyAbbrs = new String[]{USDA_AGENCY};
        EventAgencyAlignment eventAgencyAlignment = new EventAgencyAlignment();
        EventAgencyAlignment[] agencyAlignments = new EventAgencyAlignment[]{eventAgencyAlignment};
        expect(eventAgencyAlignmentDao.findByEventsCrop(aryEq(events), eq(cropName))).andReturn(agencyAlignments);
        EventDeregulationStatus eventDeregulationStatus = new EventDeregulationStatus();
        List<EventDeregulationStatus> expected = new ArrayList<EventDeregulationStatus>();
        expected.add(eventDeregulationStatus);
        expect(eventStatusBuilder.build(agencyAlignments, cropName)).andReturn(expected);
        replay(eventAgencyAlignmentDao);
        replay(eventStatusBuilder);
        EventDeregulationStatus[] actuals = eventStatusByCropStrategy.find(
                events, cropName);
        verify(eventAgencyAlignmentDao);
        verify(eventStatusBuilder);
        assertThat(actuals.length, is(1));
    }

    @Test
    public void test_find_CallsDaoMultipletimes_IfRequestCountExceedsMaximumAllowedCount_TestFixed() {
        String[] events = buildEvents("EVENT", 2000);
        String[] agencyAbbrs = new String[]{USDA_AGENCY};
        EventAgencyAlignment eventAgencyAlignment = new EventAgencyAlignment();
        EventAgencyAlignment[] agencyAlignments = new EventAgencyAlignment[]{eventAgencyAlignment};
        expect(eventAgencyAlignmentDao.findByEventsCrop(aryEq((String[]) ArrayUtils.subarray(events, 0, 1000)), eq(cropName))).andReturn(agencyAlignments);
        expect(eventAgencyAlignmentDao.findByEventsCrop(aryEq((String[]) ArrayUtils.subarray(events, 1000, 2000)), eq(cropName))).andReturn(agencyAlignments);
        replay(eventAgencyAlignmentDao);
        EventDeregulationStatus eventDeregulationStatus = new EventDeregulationStatus();
        List<EventDeregulationStatus> expected = new ArrayList<EventDeregulationStatus>();
        expected.add(eventDeregulationStatus);
        expect(eventStatusBuilder.build(agencyAlignments, cropName)).andReturn(expected).times(2);
        replay(eventStatusBuilder);
        EventDeregulationStatus[] actuals = eventStatusByCropStrategy.find(
                events, cropName);
        verify(eventAgencyAlignmentDao);
        verify(eventStatusBuilder);
        assertThat(actuals.length, is(2));
    }

    @Test
    public void test_find_CallsDaoMultipletimes_IfRequestCountExceedsMaximumAllowedCount_TestBoundry_Below() {
        String[] events = buildEvents("EVENT", 1999);
        String[] agencyAbbrs = new String[]{USDA_AGENCY};
        EventAgencyAlignment eventAgencyAlignment = new EventAgencyAlignment();
        EventAgencyAlignment[] agencyAlignments = new EventAgencyAlignment[]{eventAgencyAlignment};
        expect(eventAgencyAlignmentDao.findByEventsCrop(aryEq((String[]) ArrayUtils.subarray(events, 0, 1000)), eq(cropName))).andReturn(agencyAlignments);
        expect(eventAgencyAlignmentDao.findByEventsCrop(aryEq((String[]) ArrayUtils.subarray(events, 1000, 2000)), eq(cropName))).andReturn(agencyAlignments);
        replay(eventAgencyAlignmentDao);
        EventDeregulationStatus eventDeregulationStatus = new EventDeregulationStatus();
        List<EventDeregulationStatus> expected = new ArrayList<EventDeregulationStatus>();
        expected.add(eventDeregulationStatus);
        expect(eventStatusBuilder.build(agencyAlignments, cropName)).andReturn(expected).times(2);
        replay(eventStatusBuilder);
        EventDeregulationStatus[] actuals = eventStatusByCropStrategy.find(
                events, cropName);
        verify(eventAgencyAlignmentDao);
        verify(eventStatusBuilder);
        assertThat(actuals.length, is(2));
    }

    @Test
    public void test_find_CallsDaoMultipletimes_IfRequestCountExceedsMaximumAllowedCount_TestBoundry_Above() {
        String[] events = buildEvents("EVENT", 2001);
        String[] agencyAbbrs = new String[]{USDA_AGENCY};
        EventAgencyAlignment eventAgencyAlignment = new EventAgencyAlignment();
        EventAgencyAlignment[] agencyAlignments = new EventAgencyAlignment[]{eventAgencyAlignment};
        expect(eventAgencyAlignmentDao.findByEventsCrop(aryEq((String[]) ArrayUtils.subarray(events, 0, 1000)), eq(cropName))).andReturn(agencyAlignments);
        expect(eventAgencyAlignmentDao.findByEventsCrop(aryEq((String[]) ArrayUtils.subarray(events, 1000, 2000)), eq(cropName))).andReturn(agencyAlignments);
        expect(eventAgencyAlignmentDao.findByEventsCrop(aryEq((String[]) ArrayUtils.subarray(events, 2000, 2001)), eq(cropName))).andReturn(agencyAlignments);
        replay(eventAgencyAlignmentDao);
        EventDeregulationStatus eventDeregulationStatus = new EventDeregulationStatus();
        List<EventDeregulationStatus> expected = new ArrayList<EventDeregulationStatus>();
        expected.add(eventDeregulationStatus);
        expect(eventStatusBuilder.build(agencyAlignments, cropName)).andReturn(expected).times(3);
        replay(eventStatusBuilder);
        EventDeregulationStatus[] actuals = eventStatusByCropStrategy.find(
                events, cropName);
        verify(eventAgencyAlignmentDao);
        verify(eventStatusBuilder);
        assertThat(actuals.length, is(3));
    }

    @Test
    public void test_findByMaterialName() {
        String[] events = new String[]{EVENT};
        EventAgencyAlignment eventAgencyAlignment = new EventAgencyAlignment();
        EventAgencyAlignment[] agencyAlignments = new EventAgencyAlignment[]{eventAgencyAlignment};
        expect(eventAgencyAlignmentDao.findByMaterialCrop(aryEq(events), eq(cropName))).andReturn(agencyAlignments);
        AgencyMaterialDeregulationStatus eventDeregulationStatus = new AgencyMaterialDeregulationStatus();
        List<AgencyMaterialDeregulationStatus> expected = new ArrayList<AgencyMaterialDeregulationStatus>();
        expected.add(eventDeregulationStatus);
        expect(materialStatusBuilder.build(agencyAlignments, cropName)).andReturn(expected);
        replay(eventAgencyAlignmentDao);
        replay(materialStatusBuilder);
        AgencyMaterialDeregulationStatus[] actuals = eventStatusByCropStrategy.findByMaterialName(
                events, cropName);
        verify(eventAgencyAlignmentDao);
        verify(materialStatusBuilder);
        assertThat(actuals.length, is(1));
    }


    @Test
    public void test_find_findByMaterialNameCallsDaoMultipleTimes_IfRequestCountExceedsMaximumAllowedCount_TestFixed() {
        String[] events = buildEvents("EVENT", 2000);
        EventAgencyAlignment eventAgencyAlignment = new EventAgencyAlignment();
        EventAgencyAlignment[] agencyAlignments = new EventAgencyAlignment[]{eventAgencyAlignment};
        expect(eventAgencyAlignmentDao.findByMaterialCrop(aryEq((String[]) ArrayUtils.subarray(events, 0, 1000)), eq(cropName))).andReturn(agencyAlignments);
        expect(eventAgencyAlignmentDao.findByMaterialCrop(aryEq((String[]) ArrayUtils.subarray(events, 1000, 2000)), eq(cropName))).andReturn(agencyAlignments);
        replay(eventAgencyAlignmentDao);
        AgencyMaterialDeregulationStatus eventDeregulationStatus = new AgencyMaterialDeregulationStatus();
        List<AgencyMaterialDeregulationStatus> expected = new ArrayList<AgencyMaterialDeregulationStatus>();
        expected.add(eventDeregulationStatus);
        expect(materialStatusBuilder.build(agencyAlignments, cropName)).andReturn(expected).times(2);
        replay(materialStatusBuilder);
        AgencyMaterialDeregulationStatus[] actuals = eventStatusByCropStrategy.findByMaterialName(
                events, cropName);
        verify(eventAgencyAlignmentDao);
        verify(materialStatusBuilder);
        assertThat(actuals.length, is(2));
    }

    private String[] buildEvents(String eventPrefix, int count) {
        List<String> list = new ArrayList<String>();
        for (int i = 0; i < count; i++) {
            list.add(eventPrefix + "_" + i);
        }
        return list.toArray(new String[list.size()]);
    }


}
