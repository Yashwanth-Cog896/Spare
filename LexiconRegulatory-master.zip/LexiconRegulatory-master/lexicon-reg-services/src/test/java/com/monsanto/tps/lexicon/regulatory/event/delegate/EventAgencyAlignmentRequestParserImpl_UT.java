package com.monsanto.tps.lexicon.regulatory.event.delegate;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dbdataservices.SQLUtil;
import com.monsanto.tps.authentication.UserProfile;
import com.monsanto.tps.lexicon.agency.AgencySearchCriteria;
import com.monsanto.tps.lexicon.event.EventAgencyAlignmentRequest;
import com.monsanto.tps.lexicon.event.EventAgencyAlignmentRequestInfo;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.EventAgencyAlignmentInfoBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Agency;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.AgencyDepartment;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.AgencyMaterialType;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Crop;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;
import com.monsanto.tps.lexicon.regulatory.agency.dao.AgencyDao;
import com.monsanto.tps.lexicon.regulatory.crop.dao.CropDao;
import com.monsanto.tps.lexicon.regulatory.event.dao.EventAgencyAlignmentDao;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.Date;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.isA;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;

/**
 * rrchak1 - Feb 3, 2009 5:41:58 PM
 */
public class EventAgencyAlignmentRequestParserImpl_UT {
    private EventAgencyAlignmentRequestParserImpl eventAgencyAlignmentRequestParser;
    private EventAgencyAlignmentRequest eventAgencyAlignmentRequest;
    private AgencyDao agencyDao;
    private CropDao cropDao;
    private EventAgencyAlignmentDao eventAgencyAlignmentDao;
    private UserProfile userProfile;

    @Before
    public void before() {
        eventAgencyAlignmentRequestParser = new EventAgencyAlignmentRequestParserImpl();
        agencyDao = createMock(AgencyDao.class);
        cropDao = createMock(CropDao.class);
        eventAgencyAlignmentDao = createMock(EventAgencyAlignmentDao.class);
        userProfile = createMock(UserProfile.class);
        eventAgencyAlignmentRequestParser.setCropDao(cropDao);
        eventAgencyAlignmentRequestParser.setAgencyDao(agencyDao);
        eventAgencyAlignmentRequestParser.setEventAgencyAlignmentDao(eventAgencyAlignmentDao);
        eventAgencyAlignmentRequestParser.setUserProfile(userProfile);

    }

    @Test
    public void buildEventAgencyAlignmentsParsesRequestAndReturnsEventAgencyAlignments()
            throws WrappingException {
        EventAgencyAlignmentRequestInfo eventAgencyAlignmentRequestInfo =
                new EventAgencyAlignmentInfoBuilder().
                        withMaxQuantity(100.5).
                        regulated().
                        withDeregulatedEffectiveDate(new Date()).
                        withAgencyPubkey("1111").
                        getEventAgencyAlignmentInfo();
        eventAgencyAlignmentRequest = new EventAgencyAlignmentRequest();
        eventAgencyAlignmentRequest.setCrop("CORN");
        eventAgencyAlignmentRequest.setEvent("EVENT");

        Crop crop = new Crop();
        crop.setCropName("corn");
        expect(cropDao.findByName("CORN")).andReturn(crop);

        Agency agency = new Agency();
        agency.setAgencyPubkey("1111");
        AgencyDepartment[] departments = new AgencyDepartment[1];
        departments[0] = new AgencyDepartment();
        departments[0].setAgency(agency);

        expect(agencyDao.findDepartmentsBySearchCriteria(isA(AgencySearchCriteria.class))).andReturn(departments);
        replay(cropDao);
        replay(agencyDao);

        AgencyMaterialType type = new AgencyMaterialType();
        type.setMaterialTypeDesc("Trait");
        type.setMaterialTypeId(1L);

        expect(eventAgencyAlignmentDao.getAgencyMaterialTypeIdByName(isA(String.class))).andReturn(type);
        replay(eventAgencyAlignmentDao);

        expect(userProfile.getUserName()).andReturn("TestUser").anyTimes();
        replay(userProfile);

        EventAgencyAlignment eventAgencyAlignment = eventAgencyAlignmentRequestParser.buildEventAgencyAlignmentFromRequest(eventAgencyAlignmentRequestInfo, eventAgencyAlignmentRequest);
        verify(cropDao);
        verify(agencyDao);
        Assert.assertNotNull(eventAgencyAlignment);
        Assert.assertEquals("EVENT", eventAgencyAlignment.getMaterialName());
        Assert.assertEquals(eventAgencyAlignmentRequestInfo.getRegulated(), SQLUtil.stringToBoolean(eventAgencyAlignment.getRegulated()));
        Assert.assertEquals(eventAgencyAlignmentRequestInfo.getDeregulatedEffectiveDate(), eventAgencyAlignment.getDeregulatedEffectiveDate());
        assertThat(eventAgencyAlignment.getMaxQuantity(), is(100.5));
        Assert.assertEquals(agency.getAgencyPubkey(), eventAgencyAlignment.getAgency().getAgencyPubkey());
        Assert.assertEquals(crop.getCropName(), eventAgencyAlignment.getCrop().getCropName());
    }

    @Test
    public void buildEventAgencyAlignmentsParsesRequestAndThrowsWrappingExceptionForNonExistentCrop()
            throws WrappingException {
        EventAgencyAlignmentRequestInfo eventAgencyAlignmentRequestInfo =
                new EventAgencyAlignmentInfoBuilder().
                        withMaxQuantity(100.5).
                        regulated().
                        withDeregulatedEffectiveDate(new Date()).
                        withAgencyPubkey("1111").
                        getEventAgencyAlignmentInfo();
        eventAgencyAlignmentRequest = new EventAgencyAlignmentRequest();
        eventAgencyAlignmentRequest.setCrop("CORN");
        eventAgencyAlignmentRequest.setEvent("EVENT");
        expect(cropDao.findByName("CORN")).andReturn(null);
        replay(cropDao);
        try {
            eventAgencyAlignmentRequestParser.buildEventAgencyAlignmentFromRequest(eventAgencyAlignmentRequestInfo, eventAgencyAlignmentRequest);
            fail("Should not have come here");
        } catch (WrappingException e) {
            Assert.assertEquals("Crop not found for the given cropName", e.getMessage());
        } finally {
            verify(cropDao);
        }
    }

    @Test
    public void buildEventAgencyAlignmentsParsesRequestAndThrowsWrappingExceptionForNonExistentMaterialType()
            throws WrappingException {
        EventAgencyAlignmentRequestInfo eventAgencyAlignmentRequestInfo =
                new EventAgencyAlignmentInfoBuilder().
                        withMaxQuantity(100.5).
                        regulated().
                        withDeregulatedEffectiveDate(new Date()).
                        withAgencyPubkey("1111").
                        getEventAgencyAlignmentInfo();
        eventAgencyAlignmentRequest = new EventAgencyAlignmentRequest();
        eventAgencyAlignmentRequest.setCrop("CORN");
        eventAgencyAlignmentRequest.setEvent("EVENT");

        Crop crop = new Crop();
        crop.setCropName("corn");
        expect(cropDao.findByName("CORN")).andReturn(crop);
        Agency agency = new Agency();
        agency.setAgencyPubkey("1111");
        AgencyDepartment[] departments = new AgencyDepartment[1];
        departments[0] = new AgencyDepartment();
        departments[0].setAgency(agency);

        expect(agencyDao.findDepartmentsBySearchCriteria(isA(AgencySearchCriteria.class))).andReturn(departments);
        replay(cropDao);
        replay(agencyDao);
        expect(eventAgencyAlignmentDao.getAgencyMaterialTypeIdByName(isA(String.class))).andReturn(null);
        replay(eventAgencyAlignmentDao);

        try {
            eventAgencyAlignmentRequestParser.buildEventAgencyAlignmentFromRequest(eventAgencyAlignmentRequestInfo, eventAgencyAlignmentRequest);
            fail("Should not have come here");
        } catch (WrappingException e) {
            Assert.assertEquals("AgencyMaterialType not found for the given materialTypeDesc", e.getMessage());
        } finally {
            verify(cropDao);
        }
    }

    @Test
    public void buildEventAgencyAlignmentsParsesRequestAndThrowsWrappingExceptionForNonExistentAgency()
            throws WrappingException {
        EventAgencyAlignmentRequestInfo eventAgencyAlignmentRequestInfo =
                new EventAgencyAlignmentInfoBuilder().
                        withMaxQuantity(100.5).
                        regulated().
                        withDeregulatedEffectiveDate(new Date()).
                        withAgencyPubkey("1111").
                        getEventAgencyAlignmentInfo();
        eventAgencyAlignmentRequest = new EventAgencyAlignmentRequest();
        eventAgencyAlignmentRequest.setCrop("CORN");
        eventAgencyAlignmentRequest.setEvent("EVENT");

        Crop crop = new Crop();
        crop.setCropName("corn");
        expect(cropDao.findByName("CORN")).andReturn(crop);
        expect(agencyDao.findDepartmentsBySearchCriteria(isA(AgencySearchCriteria.class))).andReturn(null);
        replay(cropDao);
        replay(agencyDao);
        try {
            eventAgencyAlignmentRequestParser.buildEventAgencyAlignmentFromRequest(eventAgencyAlignmentRequestInfo, eventAgencyAlignmentRequest);
            fail("Should not have come here");
        } catch (WrappingException e) {
            Assert.assertEquals("Agency not found for the given pubkey", e.getMessage());
        } finally {
            verify(cropDao);
            verify(agencyDao);
        }
    }
}
