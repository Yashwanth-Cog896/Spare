package com.monsanto.tps.lexicon.regulatory.agency.service;

import com.monsanto.tps.lexicon.agency.Agency;
import com.monsanto.tps.lexicon.agency.AgencySaveUpdateBatchRequest;
import com.monsanto.tps.lexicon.agency.AgencySaveUpdateResponse;
import com.monsanto.tps.lexicon.agency.AgencySearchCriteria;
import com.monsanto.tps.lexicon.agency.AgencyService;
import org.apache.commons.lang.ArrayUtils;

import javax.jws.WebMethod;

/**
 * rrchak1 - Oct 10, 2008 3:16:02 PM
 */
public class AgencyServiceStub
   implements AgencyService
{
   public Agency[] findBySearchCriteria(AgencySearchCriteria agencySearchCriteria) {
      if (!ArrayUtils.isEmpty(agencySearchCriteria.getAgencyPubkey())) {
         Agency[] agencies = new Agency[agencySearchCriteria.getAgencyPubkey().length];
         for (int i = 0; i < agencySearchCriteria.getAgencyPubkey().length; i++) {
            agencies[i] = new Agency();
            agencies[i].setAgencyPubkey(agencySearchCriteria.getAgencyPubkey()[i]);
         }
         return agencies;
      }
      if (!ArrayUtils.isEmpty(agencySearchCriteria.getAgencyAbbr())) {
         Agency[] agencies = new Agency[agencySearchCriteria.getAgencyAbbr().length];
         for (int i = 0; i < agencySearchCriteria.getAgencyAbbr().length; i++) {
            agencies[i] = new Agency();
            agencies[i].setAgencyAbbr(agencySearchCriteria.getAgencyAbbr()[i]);
         }
         return agencies;
      }
      if (!ArrayUtils.isEmpty(agencySearchCriteria.getAgencyCountryIsoCode())) {
         Agency[] agencies = new Agency[agencySearchCriteria.getAgencyCountryIsoCode().length];
         for (int i = 0; i < agencySearchCriteria.getAgencyCountryIsoCode().length; i++) {
            agencies[i] = new Agency();
            agencies[i].setCountryIsoCode(agencySearchCriteria.getAgencyCountryIsoCode()[i]);
         }
         return agencies;
      }

      Agency[] agencies = new Agency[1];
      agencies[0] = new Agency();
      agencies[0].setActive(agencySearchCriteria.isIncludeInactive());
      return agencies;
   }

   @WebMethod
   public AgencySaveUpdateResponse[] saveOrValidate(AgencySaveUpdateBatchRequest request) {
      return new AgencySaveUpdateResponse[0];
   }

   @WebMethod
   public AgencySaveUpdateResponse[] updateOrValidate(AgencySaveUpdateBatchRequest request) {
      return new AgencySaveUpdateResponse[0];
   }
}
