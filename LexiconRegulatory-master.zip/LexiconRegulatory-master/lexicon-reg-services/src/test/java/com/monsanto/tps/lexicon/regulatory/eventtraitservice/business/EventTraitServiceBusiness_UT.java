/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.eventtraitservice.business;

import com.monsanto.tps.lexicon.eventtraitservice.transfer.GermplasmEventTraitRequest;
import com.monsanto.tps.lexicon.eventtraitservice.transfer.GermplasmEventTraitResponse;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

/* nbwald - 6/7/12 */
@RunWith(MockitoJUnitRunner.class)
public class EventTraitServiceBusiness_UT
{
    private EventTraitServiceBusiness eventTraitServiceBusiness;

    @Mock private ComlTraitBusiness comlTraitBusiness;
    @Mock private EventTraitBusiness eventTraitBusiness;
    @Mock private MonNumberAndPVCodesBusiness monNumberAndPVCodesBusiness;

    @Before
    public void before()
       throws Exception
    {
        eventTraitServiceBusiness = new EventTraitServiceBusiness();
        eventTraitServiceBusiness.setComlTraitBusiness(comlTraitBusiness);
        eventTraitServiceBusiness.setEventTraitBusiness(eventTraitBusiness);
        eventTraitServiceBusiness.setMonNumberAndPVCodesBusiness(monNumberAndPVCodesBusiness);
    }

    @Test
    public void testGetGermplasmTraitEventConstructs_EmptyRequest()
       throws Exception
    {
        GermplasmEventTraitRequest request = new GermplasmEventTraitRequest();

        GermplasmEventTraitResponse germplasmTraitEventConstructs = eventTraitServiceBusiness.getGermplasmTraitEventConstructs(request);

        assertThat(germplasmTraitEventConstructs.getGermplasmEventTraits().size(), is(0));
    }

    @Test
    public void testGetGermplasmTraitEventConstructs_MultipleGermplasm()
       throws Exception
    {
        GermplasmEventTraitRequest request = new GermplasmEventTraitRequest();
        request.setGermplasmIds(Arrays.asList(1L, 2L, 3L));

        GermplasmEventTraitResponse germplasmTraitEventConstructs = eventTraitServiceBusiness.getGermplasmTraitEventConstructs(request);

        assertThat(germplasmTraitEventConstructs.getGermplasmEventTraits().size(), is(3));
    }
}