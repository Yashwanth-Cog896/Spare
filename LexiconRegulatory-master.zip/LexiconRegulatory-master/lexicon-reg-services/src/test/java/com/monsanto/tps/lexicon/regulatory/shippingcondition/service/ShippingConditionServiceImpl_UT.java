package com.monsanto.tps.lexicon.regulatory.shippingcondition.service;

import com.monsanto.tps.lexicon.shippingcondition.ShippingConditionService;
import com.monsanto.tps.lexicon.shippingcondition.OrionShippingCondition;
import com.monsanto.tps.lexicon.regulatory.shippingcondition.business.ShippingConditionBusiness;
import com.monsanto.tps.lexicon.regulatory.shippingcondition.service.ShippingConditionServiceImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/1/12
 * Time: 7:47 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class ShippingConditionServiceImpl_UT {

    @Mock
    private ShippingConditionBusiness shippingConditionBusiness;

    @InjectMocks
    private ShippingConditionService shippingConditionService = new ShippingConditionServiceImpl();

    private static final List<OrionShippingCondition> shippingConditionList = new ArrayList<OrionShippingCondition>();

    @Test
    public void findShippingCondition_success() throws Exception {
        when(shippingConditionBusiness.findShippingConditions("Cool on Ice")).thenReturn(shippingConditionList);

        final List<OrionShippingCondition> actualShippingConditions = shippingConditionBusiness.findShippingConditions("Cool on Ice");

        assertEquals(actualShippingConditions, shippingConditionList);
    }
}
