package com.monsanto.tps.lexicon.regulatory.chemicalname.comparator;

import com.monsanto.tps.lexicon.chemicalname.OrionChemicalName;
import com.monsanto.tps.lexicon.regulatory.comparator.ComparatorTestCase;

import java.util.Comparator;

/**
 * Created by IntelliJ IDEA.
 * User: etherma
 * Date: Dec 13, 2006
 * Time: 3:29:28 PM
 * To change this template use File | Settings | File Templates.
 */
public class OrionChemicallNameComparator_UT extends ComparatorTestCase {
    protected Comparator getNewComparator() {
        return new OrionChemicalNameComparator();
    }

    protected Object getNewInfoSmaller() {
        OrionChemicalName orionChemicalName = new OrionChemicalName();
        orionChemicalName.setMaterialName("name 1");
        return orionChemicalName;
    }

    protected Object getNewInfoLarger() {
        OrionChemicalName orionChemicalName = new OrionChemicalName();
        orionChemicalName.setMaterialName("name 2");
        return orionChemicalName;
    }
}
