package com.monsanto.tps.lexicon.regulatory.proteinname.service;

import com.monsanto.tps.lexicon.proteinname.OrionProteinName;
import com.monsanto.tps.lexicon.proteinname.ProteinNameService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/2/12
 * Time: 7:40 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:/com/monsanto/tps/lexicon/regulatory/contexts/lexicon-test-service-at-context.xml"})
@Transactional
public class ProteinNameService_AT {

    @Resource
    ProteinNameService proteinNameServiceImpl;

    @Test
    public void findProteinName_results_wildcard() throws Exception {
        final List<OrionProteinName> ProteinNames = proteinNameServiceImpl.findProteinNames("Cry*");
        assertNotNull(ProteinNames);
        assertFalse(ProteinNames.isEmpty());
    }

    @Test
    public void findProteinName_results_exactMatch() throws Exception {
        final List<OrionProteinName> ProteinNames = proteinNameServiceImpl.findProteinNames("Cre");
        assertNotNull(ProteinNames);
        assertFalse(ProteinNames.isEmpty());
    }

    @Test
    public void findProteinName_noResults() throws Exception {
        final List<OrionProteinName> ProteinNames = proteinNameServiceImpl.findProteinNames("asdf");
        assertNotNull(ProteinNames);
        assertTrue(ProteinNames.isEmpty());
    }
}
