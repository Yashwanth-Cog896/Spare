package com.monsanto.tps.lexicon.regulatory.event.query;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.tcc.lexiconcommon.db.test.MidasTestTools;
import com.monsanto.tps.lexicon.regulatory.DB.Midas.Tests.MidasDataTestCase;
import com.monsanto.tps.lexicon.regulatory.DB.TestUtil.TPSTestConstants;
import com.monsanto.tps.lexicon.regulatory.DB.midas.MidasBoolean;
import com.monsanto.tps.lexicon.regulatory.TPS.LineType.LineTypeRef;
import com.monsanto.tps.lexicon.regulatory.event.model.RegulatoryEventConstructTransformation;
import org.junit.Test;

import java.util.Random;

/**
 * nbwald - Feb 17, 2009 3:07:11 PM
 */
public class MidasRegulatoryEventConstructTransformationsByEventAndCropQuery_DUT
        extends MidasDataTestCase {
    private final String eventName = "TEST_EN";
    private final String wackyCaseEventName = "TeSt_En";
    private final String cropGenusSpecies = "ZM";

    @Test
    public void testFind_NoResults()
            throws Exception {
        MidasRegulatoryEventConstructTransformationsByEventAndCropQuery query = new MidasRegulatoryEventConstructTransformationsByEventAndCropQuery(eventName, cropGenusSpecies);
        RegulatoryEventConstructTransformation[] eventConstructs = query.find();

        assertNotNull(eventConstructs);
        assertEquals(0, eventConstructs.length);
    }

    @Test
    public void testFind_MultipleConstructs_MultipleResults()
            throws Exception {
        insertEvent(eventName, TPSTestConstants.MIDAS_CORN_ID, "pMON_ABC");
        insertEvent(eventName, TPSTestConstants.MIDAS_CORN_ID, "pMON_DEF");

        MidasRegulatoryEventConstructTransformationsByEventAndCropQuery query = new MidasRegulatoryEventConstructTransformationsByEventAndCropQuery(eventName, cropGenusSpecies);
        RegulatoryEventConstructTransformation[] eventConstructs = query.find();

        assertNotNull(eventConstructs);
        assertEquals(2, eventConstructs.length);
        assertTrue(contains(eventConstructs, eventName, "pMON_ABC", null));
        assertTrue(contains(eventConstructs, eventName, "pMON_DEF", null));
    }

    @Test
    public void testFind_DoesNotFindLogicallyDeletedEvents()
            throws Exception {
        insertEvent(eventName, TPSTestConstants.MIDAS_CORN_ID, "pMON_ABC", false);

        MidasRegulatoryEventConstructTransformationsByEventAndCropQuery query = new MidasRegulatoryEventConstructTransformationsByEventAndCropQuery(eventName, cropGenusSpecies);
        RegulatoryEventConstructTransformation[] eventConstructs = query.find();

        assertNotNull(eventConstructs);
        assertEquals(0, eventConstructs.length);
    }

    @Test
    public void testFind_DoesNotFindEventWithADifferentCrop()
            throws Exception {
        insertEvent(eventName, TPSTestConstants.MIDAS_COTTON_ID, "pMON_ABC");

        MidasRegulatoryEventConstructTransformationsByEventAndCropQuery query = new MidasRegulatoryEventConstructTransformationsByEventAndCropQuery(eventName, cropGenusSpecies);
        RegulatoryEventConstructTransformation[] eventConstructs = query.find();

        assertNotNull(eventConstructs);
        assertEquals(0, eventConstructs.length);
    }

    @Test
    public void testFind_DoesNotFindEventWithARefActiveFalseCrop()
            throws Exception {
        long refActiveFalseCropId = insertCrop("QQ", false);
        insertEvent(eventName, refActiveFalseCropId, "pMON_ABC");

        MidasRegulatoryEventConstructTransformationsByEventAndCropQuery query = new MidasRegulatoryEventConstructTransformationsByEventAndCropQuery(eventName, "QQ");
        RegulatoryEventConstructTransformation[] eventConstructs = query.find();

        assertNotNull(eventConstructs);
        assertEquals(0, eventConstructs.length);
    }

    @Test
    public void testFind_EventNameIsCaseInsensitive()
            throws Exception {
        insertEvent(eventName, TPSTestConstants.MIDAS_CORN_ID, "pMON_ABC");

        MidasRegulatoryEventConstructTransformationsByEventAndCropQuery query = new MidasRegulatoryEventConstructTransformationsByEventAndCropQuery(wackyCaseEventName, cropGenusSpecies);
        RegulatoryEventConstructTransformation[] eventConstructs = query.find();

        assertNotNull(eventConstructs);
        assertEquals(1, eventConstructs.length);
        assertTrue(contains(eventConstructs, eventName, "pMON_ABC", null));
    }

    @Test
    public void testFind_TransformationBackgroundIsNeverFoundEvenIfItExists_BecauseItCausesPerformanceProblemsToJoinOnTheGermplasmTables()
            throws Exception {
        String transformationGenotype = "AKA_TransformationBackground";
        long germplasmId = -new Random().nextLong();
        MidasTestTools.insertFakeGermplasm(getMidasConn(), germplasmId, "pedigree", LineTypeRef.HYBRID, transformationGenotype, TPSTestConstants.MIDAS_CORN_ID, false, true, false);
        long eventConstructId = insertEvent(eventName, TPSTestConstants.MIDAS_CORN_ID, "pMON_ABC");
        MidasTestTools.insertFakeGermplasmEventConstruct(getMidasConn(), -new Random().nextLong(), eventConstructId, germplasmId);

        MidasRegulatoryEventConstructTransformationsByEventAndCropQuery query = new MidasRegulatoryEventConstructTransformationsByEventAndCropQuery(eventName, cropGenusSpecies);
        RegulatoryEventConstructTransformation[] eventConstructs = query.find();

        assertNotNull(eventConstructs);
        assertEquals(1, eventConstructs.length);
        assertTrue(contains(eventConstructs, eventName, "pMON_ABC", null));
    }

    private boolean contains(RegulatoryEventConstructTransformation[] eventConstructs, String eventName, String construct, String transformationBackground) {
        for (RegulatoryEventConstructTransformation eventConstruct : eventConstructs) {
            if (StringUtils.areEqual(eventName, eventConstruct.getEvent())
                    && StringUtils.areEqual(construct, eventConstruct.getConstruct())
                    && StringUtils.areEqual(transformationBackground, eventConstruct.getTransformationBackground())) {
                return true;
            }
        }
        return false;
    }

    private long insertEvent(String eventName, long midasCropId, String construct)
            throws WrappingException {
        return insertEvent(eventName, midasCropId, construct, true);
    }

    private long insertEvent(String eventName, long midasCropId, String construct, boolean refActive)
            throws WrappingException {
        long eventConstructId = -new Random().nextLong();
        MidasTestTools.insertFakeEventConstruct(getMidasConn(), eventConstructId, eventName, construct, midasCropId, new MidasBoolean(refActive).getDatabaseRepresentation());
        return eventConstructId;
    }

    private long insertCrop(String genusSpecies, boolean refActive)
            throws WrappingException {
        String sql = "INSERT INTO Midas.Crop (crop_id, rem_crop_id, ref_active, genus_species, rm_min, rm_max, rm_increment) VALUES (?, -1, ?, ?, 0, 0, 0)";
        PersistentStoreStatement statement = getMidasConn().prepareStatement(sql);
        try {
            long cropId = -453257823;
            statement.setParam(1, cropId);
            statement.setParam(2, new MidasBoolean(refActive).getDatabaseRepresentation());
            statement.setParam(3, genusSpecies);
            statement.executeInsert();
            return cropId;
        } finally {
            statement.close();
        }
    }
}
