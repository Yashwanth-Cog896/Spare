package com.monsanto.tps.lexicon.regulatory.proteinname.business;

import com.monsanto.tps.lexicon.proteinname.OrionProteinName;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName;
import com.monsanto.tps.lexicon.regulatory.proteinname.business.ProteinNameBusiness;
import com.monsanto.tps.lexicon.regulatory.proteinname.dao.ProteinNameDAO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/1/12
 * Time: 7:47 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class ProteinNameBusiness_UT {

    @Mock
    private ProteinNameDAO proteinNameDAO;

    @InjectMocks
    private ProteinNameBusiness proteinNameBusiness = new ProteinNameBusiness();

    private final List<ProteinName> singleProteinNameListFromDAO;
    private final List<ProteinName> multiProteinNameListFromDAO;
    private static final List<ProteinName> emptyListFromDAO = new ArrayList<ProteinName>();

    private final List<OrionProteinName> singleProteinNameListFromBusiness;
    private final List<OrionProteinName> multiProteinNameListFromBusiness;
    private static final List<OrionProteinName> emptyListFromBusiness = new ArrayList<OrionProteinName>();

    public ProteinNameBusiness_UT() {
        singleProteinNameListFromDAO = new ArrayList<ProteinName>();
        singleProteinNameListFromDAO.add(new ProteinName("type", true, "asdf", "desc", "artichoke"));

        multiProteinNameListFromDAO = new ArrayList<ProteinName>();
        multiProteinNameListFromDAO.add(new ProteinName("type1", true, "asdf", "desc1", "tomato"));
        multiProteinNameListFromDAO.add(new ProteinName("type2", false, "jkl;", "desc2", "potato"));

        singleProteinNameListFromBusiness = new ArrayList<OrionProteinName>();
        singleProteinNameListFromBusiness.add(new OrionProteinName("type", true));

        multiProteinNameListFromBusiness = new ArrayList<OrionProteinName>();
        multiProteinNameListFromBusiness.add(new OrionProteinName("type1", true));
        multiProteinNameListFromBusiness.add(new OrionProteinName("type2", false));
    }

    @Test
    public void findProteinName_findNone() throws Exception {

        when(proteinNameDAO.findProteinNames("asdf")).thenReturn(emptyListFromDAO);

        final List<OrionProteinName> actualProteinNames = proteinNameBusiness.findProteinNames("asdf");

        checkProteinNameLists(actualProteinNames, emptyListFromBusiness);
    }

    @Test
    public void findProteinName_findSingle() throws Exception {

        when(proteinNameDAO.findProteinNames("Jar")).thenReturn(singleProteinNameListFromDAO);

        final List<OrionProteinName> actualProteinNames = proteinNameBusiness.findProteinNames("Jar");

        checkProteinNameLists(actualProteinNames, singleProteinNameListFromBusiness);
    }

    @Test
    public void findProteinName_findByWildcard() throws Exception {

        when(proteinNameDAO.findProteinNames("Glass%")).thenReturn(multiProteinNameListFromDAO);

        final List<OrionProteinName> actualProteinNames = proteinNameBusiness.findProteinNames("Glass*");

        checkProteinNameLists(actualProteinNames, multiProteinNameListFromBusiness);
    }

    @Test
    public void findProteinName_findAll() throws Exception {

        when(proteinNameDAO.findProteinNames("%")).thenReturn(multiProteinNameListFromDAO);

        final List<OrionProteinName> actualProteinNames = proteinNameBusiness.findProteinNames("");

        checkProteinNameLists(actualProteinNames, multiProteinNameListFromBusiness);
    }

    private void checkProteinNameLists(final List<OrionProteinName> actualProteinNames, final List<OrionProteinName> singleProteinNameListFromBusiness) {
        assertNotNull(actualProteinNames);

        for(int i=0; i<singleProteinNameListFromBusiness.size(); i++) {
            final OrionProteinName proteinName = actualProteinNames.get(i);
            assertEquals(proteinName.getMaterialName(), singleProteinNameListFromBusiness.get(i).getMaterialName());
            assertEquals(proteinName.getActiveStatus(), singleProteinNameListFromBusiness.get(i).getActiveStatus());
        }
    }
}
