package com.monsanto.tps.lexicon.regulatory.container.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.DBUnitTest;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ContainerType;
import com.monsanto.tps.springframework.test.listener.dbunit.DataSet;
import com.monsanto.tps.springframework.test.listener.dbunit.DatasetOperation;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Comparator;
import java.util.List;

import static com.google.common.collect.Ordering.from;
import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/1/12
 * Time: 7:47 PM
 */
@DataSet(
        schema = "LEXICON", dataSourceKey = "dataSource", setupOperation = DatasetOperation.CLEAN_INSERT, teardownOperation = DatasetOperation.NONE,
        value = {"/com/monsanto/tps/lexicon/regulatory/container/dao/container_type.xml"}
)
public class ContainerDAOImpl_DUT extends DBUnitTest {

    @Autowired
    private ContainerDAO containerDAO;

    @Test
    public void findContainerTypes_results_wildcard() throws Exception {
        final List<ContainerType> containers = containerDAO.findContainerTypes("Glass%");
        assertNotNull(containers);
        assertFalse(containers.isEmpty());
    }

    @Test
    public void findContainerTypes_results_exactMatch() throws Exception {
        final List<ContainerType> containers = containerDAO.findContainerTypes("Jar");
        assertNotNull(containers);
        assertFalse(containers.isEmpty());
    }

    @Test
    public void findContainerTypes_noResults() throws Exception {
        final List<ContainerType> containers = containerDAO.findContainerTypes("asdf");
        assertNotNull(containers);
        assertTrue(containers.isEmpty());
    }

    @Test
    public void findContainerTypes_results_active() throws Exception {
        final List<ContainerType> containers = containerDAO.findContainerTypes("");
        assertNotNull(containers);
        assertFalse(containers.isEmpty());

        for(ContainerType container : containers) {
            assertTrue(container.getActiveStatus());
        }
    }

    @Test
    public void findContainerTypes_sorted() throws Exception {
        final List<ContainerType> containers = containerDAO.findContainerTypes("%");
        assertNotNull(containers);

        assertTrue(from(new ContainerComparator()).isOrdered(containers));
    }

    private class ContainerComparator implements Comparator<ContainerType> {

        public final int compare(ContainerType c1, ContainerType c2) {

            int ctCompare = 0;

            if (c1 != null && c2 != null) {
                String ct1 = c1.getContainerType();
                String ct2 = c2.getContainerType();
                if (ct1 != null && ct2 != null) {
                    ctCompare = ct1.compareToIgnoreCase(ct2);
                }
            }

            return ctCompare;
        }
    }
}