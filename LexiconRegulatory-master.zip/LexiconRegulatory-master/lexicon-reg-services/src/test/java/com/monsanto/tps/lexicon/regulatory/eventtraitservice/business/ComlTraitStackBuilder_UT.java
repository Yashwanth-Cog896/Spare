/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.eventtraitservice.business;

import com.monsanto.tps.lexicon.eventtraitservice.transfer.GermplasmEventTraitResponse;
import com.monsanto.tps.lexicon.eventtraitservice.transfer.TraitStack;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitStack;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Crop;
import com.monsanto.tps.lexicon.regulatory.commercialtrait.dao.CommercialTraitDao;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;

import static junit.framework.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/* vvkalu - 8/1/11 */
public class ComlTraitStackBuilder_UT {

    private static final long GERMPLASM_ID = 66;
    private ComlTraitStackBuilder comlTraitStackBuilder;
    private CommercialTraitDao commercialTraitDao;

    @Before
    public void setUp() {
        comlTraitStackBuilder = new ComlTraitStackBuilder();
        commercialTraitDao = mock(CommercialTraitDao.class);
        comlTraitStackBuilder.setCommercialTraitDao(commercialTraitDao);
    }

    @Test
    public void test_No_commercialTypeDesc() throws Exception {
        ComlTraitStack comlTraitStack = new ComlTraitStack();
        comlTraitStack.setCrop(new Crop());
        comlTraitStack.setComlTraitStackId(764);
        when(commercialTraitDao.getComTraitTypeDescByComlTraitStackId(764)).thenReturn(null);
        GermplasmEventTraitResponse eventTraitResponse = new GermplasmEventTraitResponse();
        GermplasmEventTraitResponse comlTraitForProduct = comlTraitStackBuilder.buildComlTraitStack(GERMPLASM_ID, 764, comlTraitStack, eventTraitResponse);
        assertNotNull(comlTraitForProduct);
        TraitStack traitStack = comlTraitForProduct.getGermplasmEventTraits().iterator().next().getTraitStack();
        assertNotNull(traitStack);
        assertEquals(GERMPLASM_ID, comlTraitForProduct.getGermplasmEventTraits().iterator().next().getGermplasmId());
        assertEquals(764, traitStack.getComlTraitStackId());
        assertNull(traitStack.getTraitTypeDesc());
    }

    @Test
    public void test_With_TraitStack() throws Exception {
        ComlTraitStack comlTraitStack = new ComlTraitStack();
        comlTraitStack.setCrop(new Crop());
        comlTraitStack.setComlTraitStackId(764);
        when(commercialTraitDao.getComTraitTypeDescByComlTraitStackId(764)).thenReturn(Arrays.asList("TEST1", "TEST2"));
        GermplasmEventTraitResponse eventTraitResponse = new GermplasmEventTraitResponse();
        GermplasmEventTraitResponse comlTraitForProduct = comlTraitStackBuilder.buildComlTraitStack(GERMPLASM_ID, 764, comlTraitStack, eventTraitResponse);
        assertNotNull(comlTraitForProduct);
        TraitStack traitStack = comlTraitForProduct.getGermplasmEventTraits().iterator().next().getTraitStack();
        assertNotNull(traitStack);
        assertEquals(GERMPLASM_ID, comlTraitForProduct.getGermplasmEventTraits().iterator().next().getGermplasmId());
        assertEquals(764, traitStack.getComlTraitStackId());
        assertNotNull(traitStack.getTraitTypeDesc());
        assertEquals("TEST1, TEST2", traitStack.getTraitTypeDesc());
    }
}