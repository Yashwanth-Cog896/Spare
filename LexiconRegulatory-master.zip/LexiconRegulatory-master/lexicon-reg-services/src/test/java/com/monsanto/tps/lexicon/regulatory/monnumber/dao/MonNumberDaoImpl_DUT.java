package com.monsanto.tps.lexicon.regulatory.monnumber.dao;

import com.monsanto.tps.lexicon.monnumber.MonNumberInfo;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.*;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.*;
import com.monsanto.tps.lexicon.regulatory.eventsreginfo.util.dao.lexicon.TempSessionOcdDao;
import org.apache.commons.lang.ArrayUtils;
import org.hibernate.Session;
import org.junit.Test;

import javax.annotation.Resource;
import java.util.*;

import static org.junit.Assert.*;

/**
 * nbwald - Jan 7, 2009 4:31:10 PM
 */
public class MonNumberDaoImpl_DUT
        extends LexiconDataUnitTestCase {
  private static final long REQUEST_ID = 87654321l;
    @Resource
    private MonNumberDaoImpl monNumberDao;

   @Resource
   private TempSessionOcdDao tempSessionOcdDao;

    @Test
    public void testFind()
            throws Exception {
        new MonNumberBuilder().
                withMonNumber("MON_1111").
                withEventName("ZM_1111").
                withMonNumberConstruct(
                        new MonNumberConstructBuilder().
                                withConstructName("CON_111").
                                withPvCode("PV_111")
                ).
                withComlTraitType(
                        new ComlTraitTypeBuilder().
                                withTraitTypeAbbr("TRTABBR").
                                withTraitTypeDesc("TRT TYPE DESC")
                ).
                withProteinName(
                        new ProteinNameBuilder().
                                withProteinName("PROT NAME").
                                withProteinNamePubkey("1234").
                                withProteinDescription("PROT DESC").
                                withOrigSourceOrganism("ORIG SOURCE ORG")
                ).
                withComlTraitName(
                        new ComlTraitNameBuilder().
                                withTraitAbbr("TRTNABBR")
                                .withTraitDesc("TRTNMDESC")
                ).
                createInDb();
        MonNumber monNumber = monNumberDao.find("MON_1111");

        assertEquals("MON_1111", monNumber.getMonNumber());
        assertEquals("ZM_1111", monNumber.getEvent());

        assertNotNull(monNumber.getMonNumberConstructs());
        assertEquals(1, monNumber.getMonNumberConstructs().size());
        MonNumberConstruct construct = monNumber.getMonNumberConstructs().iterator().next();
        assertEquals("CON_111", construct.getConstructName());
        assertEquals("PV_111", construct.getPvCode());

        assertNotNull(monNumber.getComlTraitTypes());
        assertEquals(1, monNumber.getComlTraitTypes().size());
        ComlTraitType comlTrait = monNumber.getComlTraitTypes().iterator().next();
        assertEquals("TRTABBR", comlTrait.getComlTraitTypeAbbr());
        assertEquals("TRT TYPE DESC", comlTrait.getComlTraitTypeDesc());

        assertNotNull(monNumber.getProteinNames());
        assertEquals(1, monNumber.getProteinNames().size());
        ProteinName proteinName = monNumber.getProteinNames().iterator().next();
        assertEquals("PROT NAME", proteinName.getProteinName());
        assertEquals("PROT DESC", proteinName.getProteinDescription());
        assertEquals("1234", proteinName.getProteinNamePubkey());
        assertEquals("ORIG SOURCE ORG", proteinName.getOrigSourceOrganism());

        assertNotNull(monNumber.getComlTraitNames());
        assertEquals(1, monNumber.getComlTraitNames().size());
        ComlTraitName comlTraitName = monNumber.getComlTraitNames().iterator().next();
        assertEquals("TRTNABBR", comlTraitName.getTraitAbbr());
        assertEquals("TRTNMDESC", comlTraitName.getTraitDesc());
    }

    @Test
    public void testFind_MonNumberIsCaseInsensitive()
            throws Exception {
        new MonNumberBuilder().
                withMonNumber("MON_1111").
                withEventName("ZM_1111").
                withMonNumberConstruct(
                        new MonNumberConstructBuilder().
                                withConstructName("CON_111").
                                withPvCode("PV_111")
                ).
                withComlTraitType(
                        new ComlTraitTypeBuilder().
                                withTraitTypeAbbr("TRTABBR").
                                withTraitTypeDesc("TRT TYPE DESC")
                ).
                withProteinName(
                        new ProteinNameBuilder().
                                withProteinName("PROT NAME").
                                withProteinNamePubkey("1234").
                                withProteinDescription("PROT DESC").
                                withOrigSourceOrganism("ORIG SOURCE ORG")
                ).
                createInDb();

        MonNumber monNumber = monNumberDao.find("mOn_1111");

        assertEquals("MON_1111", monNumber.getMonNumber());
        assertEquals("ZM_1111", monNumber.getEvent());

        assertNotNull(monNumber.getMonNumberConstructs());
        assertEquals(1, monNumber.getMonNumberConstructs().size());
        MonNumberConstruct construct = monNumber.getMonNumberConstructs().iterator().next();
        assertEquals("CON_111", construct.getConstructName());
        assertEquals("PV_111", construct.getPvCode());

        assertNotNull(monNumber.getComlTraitTypes());
        assertEquals(1, monNumber.getComlTraitTypes().size());
        ComlTraitType comlTrait = monNumber.getComlTraitTypes().iterator().next();
        assertEquals("TRTABBR", comlTrait.getComlTraitTypeAbbr());
        assertEquals("TRT TYPE DESC", comlTrait.getComlTraitTypeDesc());

        assertNotNull(monNumber.getProteinNames());
        assertEquals(1, monNumber.getProteinNames().size());
        ProteinName proteinName = monNumber.getProteinNames().iterator().next();
        assertEquals("PROT NAME", proteinName.getProteinName());
        assertEquals("PROT DESC", proteinName.getProteinDescription());
        assertEquals("1234", proteinName.getProteinNamePubkey());
        assertEquals("ORIG SOURCE ORG", proteinName.getOrigSourceOrganism());
    }

    @Test
    public void testFind_NotFound()
            throws Exception {
        MonNumber monNumber = monNumberDao.find("MON_1111");

        assertNull(monNumber);
    }

    @Test
    public void testFindByEventAndCrop()
            throws Exception {
        new MonNumberBuilder().
                withMonNumber("MON_1111").
                withEventName("ZM_1111").
                withCrop(CropBuilder.corn()).
                withMonNumberConstruct(
                        new MonNumberConstructBuilder().
                                withConstructName("CON_111").
                                withPvCode("PV_111")
                ).
                withComlTraitType(
                        new ComlTraitTypeBuilder().
                                withTraitTypeAbbr("TRTABBR").
                                withTraitTypeDesc("TRT TYPE DESC")
                ).
                withProteinName(
                        new ProteinNameBuilder().
                                withProteinName("PROT NAME").
                                withProteinNamePubkey("1234").
                                withProteinDescription("PROT DESC").
                                withOrigSourceOrganism("ORIG SOURCE ORG")
                ).
                createInDb();

        MonNumber monNumber = monNumberDao.findByEventAndCrop("ZM_1111", "CORN");

        assertEquals("MON_1111", monNumber.getMonNumber());
        assertEquals("ZM_1111", monNumber.getEvent());

        assertNotNull(monNumber.getMonNumberConstructs());
        assertEquals(1, monNumber.getMonNumberConstructs().size());
        MonNumberConstruct construct = monNumber.getMonNumberConstructs().iterator().next();
        assertEquals("CON_111", construct.getConstructName());
        assertEquals("PV_111", construct.getPvCode());

        assertNotNull(monNumber.getComlTraitTypes());
        assertEquals(1, monNumber.getComlTraitTypes().size());
        ComlTraitType comlTrait = monNumber.getComlTraitTypes().iterator().next();
        assertEquals("TRTABBR", comlTrait.getComlTraitTypeAbbr());
        assertEquals("TRT TYPE DESC", comlTrait.getComlTraitTypeDesc());

        assertNotNull(monNumber.getProteinNames());
        assertEquals(1, monNumber.getProteinNames().size());
        ProteinName proteinName = monNumber.getProteinNames().iterator().next();
        assertEquals("PROT NAME", proteinName.getProteinName());
        assertEquals("PROT DESC", proteinName.getProteinDescription());
        assertEquals("1234", proteinName.getProteinNamePubkey());
        assertEquals("ORIG SOURCE ORG", proteinName.getOrigSourceOrganism());
    }

    @Test
    public void testFindByEventAndCrop_EventNameIsCaseInsensitive()
            throws Exception {
        new MonNumberBuilder().
                withMonNumber("MON_1111").
                withEventName("ZM_1111").
                withCrop(CropBuilder.corn()).
                withMonNumberConstruct(
                        new MonNumberConstructBuilder().
                                withConstructName("CON_111").
                                withPvCode("PV_111")
                ).
                withComlTraitType(
                        new ComlTraitTypeBuilder().
                                withTraitTypeAbbr("TRTABBR").
                                withTraitTypeDesc("TRT TYPE DESC")
                ).
                withProteinName(
                        new ProteinNameBuilder().
                                withProteinName("PROT NAME").
                                withProteinNamePubkey("1234").
                                withProteinDescription("PROT DESC").
                                withOrigSourceOrganism("ORIG SOURCE ORG")
                ).
                createInDb();

        MonNumber monNumber = monNumberDao.findByEventAndCrop("zM_1111", "corn");

        assertEquals("MON_1111", monNumber.getMonNumber());
        assertEquals("ZM_1111", monNumber.getEvent());

        assertNotNull(monNumber.getMonNumberConstructs());
        assertEquals(1, monNumber.getMonNumberConstructs().size());
        MonNumberConstruct construct = monNumber.getMonNumberConstructs().iterator().next();
        assertEquals("CON_111", construct.getConstructName());
        assertEquals("PV_111", construct.getPvCode());

        assertNotNull(monNumber.getComlTraitTypes());
        assertEquals(1, monNumber.getComlTraitTypes().size());
        ComlTraitType comlTrait = monNumber.getComlTraitTypes().iterator().next();
        assertEquals("TRTABBR", comlTrait.getComlTraitTypeAbbr());
        assertEquals("TRT TYPE DESC", comlTrait.getComlTraitTypeDesc());

        assertNotNull(monNumber.getProteinNames());
        assertEquals(1, monNumber.getProteinNames().size());
        ProteinName proteinName = monNumber.getProteinNames().iterator().next();
        assertEquals("PROT NAME", proteinName.getProteinName());
        assertEquals("PROT DESC", proteinName.getProteinDescription());
        assertEquals("1234", proteinName.getProteinNamePubkey());
        assertEquals("ORIG SOURCE ORG", proteinName.getOrigSourceOrganism());
    }

    @Test
    public void testFindByEventAndCrop_NotFoundWithExistingEventAndNonexistingCrop()
            throws Exception {
        new MonNumberBuilder().
                withMonNumber("MON_1111").
                withEventName("ZM_1111").
                withCrop(CropBuilder.soybeans()).
                createInDb();

        MonNumber monNumber = monNumberDao.findByEventAndCrop("zM_1111", "CORN");
        assertNull(monNumber);
    }


    @Test
    public void testFindByEventAndCrop_NotFound()
            throws Exception {
        MonNumber monNumber = monNumberDao.findByEventAndCrop("ZM_1111", "Corn");

        assertNull(monNumber);
    }

    @Test
    public void testFindByCrop() {
        new MonNumberBuilder().
                withMonNumber("MON_1111").
                withEventName("ZM_1111").
                withCrop(CropBuilder.soybeans()).
                withMonNumberConstruct(
                        new MonNumberConstructBuilder().
                                withConstructName("CON_111").
                                withPvCode("PV_111")
                ).
                withComlTraitType(
                        new ComlTraitTypeBuilder().
                                withTraitTypeAbbr("TRTABBR").
                                withTraitTypeDesc("TRT TYPE DESC")
                ).
                withProteinName(
                        new ProteinNameBuilder().
                                withProteinName("PROT NAME").
                                withProteinNamePubkey("1234").
                                withProteinDescription("PROT DESC").
                                withOrigSourceOrganism("ORIG SOURCE ORG")
                ).
                createInDb();

        MonNumber[] monNumbers = monNumberDao.findByCrop("1115");

        assertTrue(monNumbers.length > 0);
        for (MonNumber monNumber : monNumbers) {
            assertTrue(monNumber.getCrop().getCropName().equalsIgnoreCase("SOYBEANS"));
            assertTrue(monNumber.getCrop().getCropPubkey().equals("1115"));
            if (monNumber.getMonNumber().equals("MON_1111")) {
                assertEquals("MON_1111", monNumber.getMonNumber());
                assertEquals("ZM_1111", monNumber.getEvent());

                assertNotNull(monNumber.getMonNumberConstructs());
                assertEquals(1, monNumber.getMonNumberConstructs().size());
                MonNumberConstruct construct = monNumber.getMonNumberConstructs().iterator().next();
                assertEquals("CON_111", construct.getConstructName());
                assertEquals("PV_111", construct.getPvCode());

                assertNotNull(monNumber.getComlTraitTypes());
                assertEquals(1, monNumber.getComlTraitTypes().size());
                ComlTraitType comlTrait = monNumber.getComlTraitTypes().iterator().next();
                assertEquals("TRTABBR", comlTrait.getComlTraitTypeAbbr());
                assertEquals("TRT TYPE DESC", comlTrait.getComlTraitTypeDesc());

                assertNotNull(monNumber.getProteinNames());
                assertEquals(1, monNumber.getProteinNames().size());
                ProteinName proteinName = monNumber.getProteinNames().iterator().next();
                assertEquals("PROT NAME", proteinName.getProteinName());
                assertEquals("PROT DESC", proteinName.getProteinDescription());
                assertEquals("1234", proteinName.getProteinNamePubkey());
                assertEquals("ORIG SOURCE ORG", proteinName.getOrigSourceOrganism());
            }
        }
    }

    @Test
    public void testFindByCrop_MultipleMonNumbersSingleSimilarValues() {
        ProteinNameBuilder proteinNameBuilder = new ProteinNameBuilder().
                withProteinName("PROTNAME").
                withProteinNamePubkey("1234");
        ComlTraitTypeBuilder comlTraitTypeBuilder = new ComlTraitTypeBuilder().
                withTraitTypeAbbr("CTTABBR").
                withTraitTypeDesc("CTTDESC");
        new MonNumberBuilder().
                withMonNumber("MON_1111").
                withEventName("ZM_1111").
                withOecdNumber("OECD1111").
                withCrop(CropBuilder.soybeans()).
                withProteinName(proteinNameBuilder).
                withComlTraitType(comlTraitTypeBuilder).
                withMonNumberConstruct(
                        new MonNumberConstructBuilder().
                                withConstructName("CONNAME").
                                withPvCode("CONPV")
                ).
                createInDb();

        new MonNumberBuilder().
                withMonNumber("MON_2222").
                withEventName("ZM_2222").
                withOecdNumber("OECD2222").
                withCrop(CropBuilder.soybeans()).
                withProteinName(proteinNameBuilder).
                withComlTraitType(comlTraitTypeBuilder).
                withMonNumberConstruct(
                        new MonNumberConstructBuilder().
                                withConstructName("CONNAME").
                                withPvCode("CONPV")
                ).
                createInDb();

        MonNumber[] monNumbers = monNumberDao.findByCrop("1115");

        assertTrue(monNumbers.length > 0);
        for (MonNumber monNumber : monNumbers) {
            if (monNumber.getMonNumber().equals("MON_1111") ||
                    monNumber.getMonNumber().equals("MON_2222")) {
                assertEquals(1, monNumber.getProteinNames().size());
                assertEquals("PROTNAME", monNumber.getProteinNames().iterator().next().getProteinName());
                assertEquals("1234", monNumber.getProteinNames().iterator().next().getProteinNamePubkey());

                assertEquals(1, monNumber.getComlTraitTypes().size());
                assertEquals("CTTABBR", monNumber.getComlTraitTypes().iterator().next().getComlTraitTypeAbbr());
                assertEquals("CTTDESC", monNumber.getComlTraitTypes().iterator().next().getComlTraitTypeDesc());

                assertEquals(1, monNumber.getMonNumberConstructs().size());
                assertEquals("CONNAME", monNumber.getMonNumberConstructs().iterator().next().getConstructName());
                assertEquals("CONPV", monNumber.getMonNumberConstructs().iterator().next().getPvCode());
            }
        }
    }

    @Test
    public void testFindByCrop_MultipleMonNumbersMultipleDifferentValues() {
        new MonNumberBuilder().
                withMonNumber("MON_1111").
                withEventName("ZM_1111").
                withOecdNumber("OECD1111").
                withCrop(CropBuilder.soybeans()).
                withProteinName(new ProteinNameBuilder().
                        withProteinName("PROTNAME1").
                        withProteinNamePubkey("12341")).
                withProteinName(new ProteinNameBuilder().
                        withProteinName("PROTNAME11").
                        withProteinNamePubkey("123411")).
                withComlTraitType(new ComlTraitTypeBuilder().
                        withTraitTypeAbbr("CTTABR1").
                        withTraitTypeDesc("CTTDESC1")).
                withComlTraitType(new ComlTraitTypeBuilder().
                        withTraitTypeAbbr("CTTABR11").
                        withTraitTypeDesc("CTTDESC11")).
                withMonNumberConstruct(new MonNumberConstructBuilder().
                        withConstructName("CONNAME1").
                        withPvCode("CONPV1")).
                withMonNumberConstruct(new MonNumberConstructBuilder().
                        withConstructName("CONNAME11").
                        withPvCode("CONPV11")).
                createInDb();

        new MonNumberBuilder().
                withMonNumber("MON_2222").
                withEventName("ZM_2222").
                withOecdNumber("OECD2222").
                withCrop(CropBuilder.soybeans()).
                withProteinName(new ProteinNameBuilder().
                        withProteinName("PROTNAME2").
                        withProteinNamePubkey("12342")).
                withComlTraitType(new ComlTraitTypeBuilder().
                        withTraitTypeAbbr("CTTABR2").
                        withTraitTypeDesc("CTTDESC2")).
                withMonNumberConstruct(new MonNumberConstructBuilder().
                        withConstructName("CONNAME2").
                        withPvCode("CONPV2")).
                createInDb();

        MonNumber[] monNumbers = monNumberDao.findByCrop("1115");

        assertTrue(monNumbers.length > 0);
        for (MonNumber monNumber : monNumbers) {
            if (monNumber.getMonNumber().equals("MON_1111")) {
                assertEquals(2, monNumber.getProteinNames().size());
                for (ProteinName proteinName : monNumber.getProteinNames()) {
                    if (proteinName.getProteinName().equals("PROTNAME1")) {
                        assertEquals("12341", proteinName.getProteinNamePubkey());
                    } else if (proteinName.getProteinName().equals("PROTNAME11")) {
                        assertEquals("123411", proteinName.getProteinNamePubkey());
                    } else {
                        fail("Invalid protein name found.");
                    }
                }

                assertEquals(2, monNumber.getComlTraitTypes().size());
                for (ComlTraitType comlTraitType : monNumber.getComlTraitTypes()) {
                    if (comlTraitType.getComlTraitTypeAbbr().equals("CTTABR1")) {
                        assertEquals("CTTDESC1", comlTraitType.getComlTraitTypeDesc());
                    } else if (comlTraitType.getComlTraitTypeAbbr().equals("CTTABR11")) {
                        assertEquals("CTTDESC11", comlTraitType.getComlTraitTypeDesc());
                    } else {
                        fail("Invalid commercial trait type found.");
                    }
                }

                assertEquals(2, monNumber.getMonNumberConstructs().size());
                for (MonNumberConstruct construct : monNumber.getMonNumberConstructs()) {
                    if (construct.getConstructName().equals("CONNAME1")) {
                        assertEquals("CONPV1", construct.getPvCode());
                    } else if (construct.getConstructName().equals("CONNAME11")) {
                        assertEquals("CONPV11", construct.getPvCode());
                    } else {
                        fail("Invalid mon number construct found.");
                    }
                }
            } else if (monNumber.getMonNumber().equals("MON_2222")) {
                assertEquals(1, monNumber.getProteinNames().size());
                assertEquals("PROTNAME2", monNumber.getProteinNames().iterator().next().getProteinName());
                assertEquals("12342", monNumber.getProteinNames().iterator().next().getProteinNamePubkey());

                assertEquals(1, monNumber.getComlTraitTypes().size());
                assertEquals("CTTABR2", monNumber.getComlTraitTypes().iterator().next().getComlTraitTypeAbbr());
                assertEquals("CTTDESC2", monNumber.getComlTraitTypes().iterator().next().getComlTraitTypeDesc());

                assertEquals(1, monNumber.getMonNumberConstructs().size());
                assertEquals("CONNAME2", monNumber.getMonNumberConstructs().iterator().next().getConstructName());
                assertEquals("CONPV2", monNumber.getMonNumberConstructs().iterator().next().getPvCode());
            }
        }
    }

    @Test
    public void testFindByCrop_NoDataFound() {
        MonNumber[] monNumbers = monNumberDao.findByCrop("InvalidCropPubkey");

        assertEquals(0, monNumbers.length);
    }

    @Test
    public void testFindByMonNumber() {
        new MonNumberBuilder().
                withMonNumber("MON_1111").
                withEventName("ZM_1111").
                withCrop(CropBuilder.soybeans()).
                withMonNumberConstruct(
                        new MonNumberConstructBuilder().
                                withConstructName("CON_111").
                                withPvCode("PV_111")
                ).
                withComlTraitType(
                        new ComlTraitTypeBuilder().
                                withTraitTypeAbbr("TRTABBR").
                                withTraitTypeDesc("TRT TYPE DESC")
                ).
                withProteinName(
                        new ProteinNameBuilder().
                                withProteinName("PROT NAME").
                                withProteinNamePubkey("1234").
                                withProteinDescription("PROT DESC").
                                withOrigSourceOrganism("ORIG SOURCE ORG")
                ).
                createInDb();

        MonNumber[] monNumbers = monNumberDao.findByMonNumber("MON_1111");

        assertTrue(monNumbers.length > 0);
        for (MonNumber monNumber : monNumbers) {
            assertTrue(monNumber.getCrop().getCropName().equalsIgnoreCase("SOYBEANS"));
            assertTrue(monNumber.getCrop().getCropPubkey().equals("1115"));
            if (monNumber.getMonNumber().equals("MON_1111")) {
                assertEquals("MON_1111", monNumber.getMonNumber());
                assertEquals("ZM_1111", monNumber.getEvent());

                assertNotNull(monNumber.getMonNumberConstructs());
                assertEquals(1, monNumber.getMonNumberConstructs().size());
                MonNumberConstruct construct = monNumber.getMonNumberConstructs().iterator().next();
                assertEquals("CON_111", construct.getConstructName());
                assertEquals("PV_111", construct.getPvCode());

                assertNotNull(monNumber.getComlTraitTypes());
                assertEquals(1, monNumber.getComlTraitTypes().size());
                ComlTraitType comlTrait = monNumber.getComlTraitTypes().iterator().next();
                assertEquals("TRTABBR", comlTrait.getComlTraitTypeAbbr());
                assertEquals("TRT TYPE DESC", comlTrait.getComlTraitTypeDesc());

                assertNotNull(monNumber.getProteinNames());
                assertEquals(1, monNumber.getProteinNames().size());
                ProteinName proteinName = monNumber.getProteinNames().iterator().next();
                assertEquals("PROT NAME", proteinName.getProteinName());
                assertEquals("PROT DESC", proteinName.getProteinDescription());
                assertEquals("1234", proteinName.getProteinNamePubkey());
                assertEquals("ORIG SOURCE ORG", proteinName.getOrigSourceOrganism());
            }
        }
    }

    @Test
    public void testFindByMonNumber_NoDataFound() {
        MonNumber[] monNumbers = monNumberDao.findByMonNumber("InvalidMonNumber");

        assertEquals(0, monNumbers.length);
    }

    @Test
    public void testFindByMonNumberAndCrop() {
        new MonNumberBuilder().
                withMonNumber("MON_1111").
                withEventName("ZM_1111").
                withCrop(CropBuilder.soybeans()).
                withMonNumberConstruct(
                        new MonNumberConstructBuilder().
                                withConstructName("CON_111").
                                withPvCode("PV_111")
                ).
                withComlTraitType(
                        new ComlTraitTypeBuilder().
                                withTraitTypeAbbr("TRTABBR").
                                withTraitTypeDesc("TRT TYPE DESC")
                ).
                withProteinName(
                        new ProteinNameBuilder().
                                withProteinName("PROT NAME").
                                withProteinNamePubkey("1234").
                                withProteinDescription("PROT DESC").
                                withOrigSourceOrganism("ORIG SOURCE ORG")
                ).
                createInDb();

        MonNumber[] monNumbers = monNumberDao.findByMonNumberAndCrop("MON_1111", "1115");

        assertTrue(monNumbers.length > 0);
        for (MonNumber monNumber : monNumbers) {
            assertTrue(monNumber.getCrop().getCropName().equalsIgnoreCase("SOYBEANS"));
            assertTrue(monNumber.getCrop().getCropPubkey().equals("1115"));
            if (monNumber.getMonNumber().equals("MON_1111")) {
                assertEquals("MON_1111", monNumber.getMonNumber());
                assertEquals("ZM_1111", monNumber.getEvent());

                assertNotNull(monNumber.getMonNumberConstructs());
                assertEquals(1, monNumber.getMonNumberConstructs().size());
                MonNumberConstruct construct = monNumber.getMonNumberConstructs().iterator().next();
                assertEquals("CON_111", construct.getConstructName());
                assertEquals("PV_111", construct.getPvCode());

                assertNotNull(monNumber.getComlTraitTypes());
                assertEquals(1, monNumber.getComlTraitTypes().size());
                ComlTraitType comlTrait = monNumber.getComlTraitTypes().iterator().next();
                assertEquals("TRTABBR", comlTrait.getComlTraitTypeAbbr());
                assertEquals("TRT TYPE DESC", comlTrait.getComlTraitTypeDesc());

                assertNotNull(monNumber.getProteinNames());
                assertEquals(1, monNumber.getProteinNames().size());
                ProteinName proteinName = monNumber.getProteinNames().iterator().next();
                assertEquals("PROT NAME", proteinName.getProteinName());
                assertEquals("PROT DESC", proteinName.getProteinDescription());
                assertEquals("1234", proteinName.getProteinNamePubkey());
                assertEquals("ORIG SOURCE ORG", proteinName.getOrigSourceOrganism());
            }
        }
    }

    @Test
    public void testFindByMonNumberAndCrop_NoDataFound() {
        MonNumber[] monNumbers = monNumberDao.findByMonNumberAndCrop("InvalidMonNumber", "InvalidCropPubkey");

        assertEquals(0, monNumbers.length);
    }

    @Test
    public void testFindByConstruct_SingleConstruct() {
        new MonNumberBuilder().
                withMonNumber("MON_1111").
                withEventName("ZM_1111").
                withCrop(CropBuilder.canola()).
                withMonNumberConstruct(
                        new MonNumberConstructBuilder().
                                withConstructName("CON_111").
                                withPvCode("PV_111")
                ).
                withComlTraitType(
                        new ComlTraitTypeBuilder().
                                withTraitTypeAbbr("TRTABBR").
                                withTraitTypeDesc("TRT TYPE DESC")
                ).
                withProteinName(
                        new ProteinNameBuilder().
                                withProteinName("PROT NAME").
                                withProteinNamePubkey("1234").
                                withProteinDescription("PROT DESC").
                                withOrigSourceOrganism("ORIG SOURCE ORG")
                ).
                createInDb();

        MonNumber[] monNumbers = monNumberDao.findByConstruct(new String[]{"CON_111"});

        assertEquals(1, monNumbers.length);
        MonNumber monNumber = monNumbers[0];
        assertEquals("MON_1111", monNumber.getMonNumber());
        assertEquals("ZM_1111", monNumber.getEvent());
        assertEquals("OSR-CANOLA", monNumber.getCrop().getCropName().toUpperCase());
        assertEquals("1415", monNumber.getCrop().getCropPubkey());

        assertEquals(1, monNumber.getProteinNames().size());
        ProteinName proteinName = monNumber.getProteinNames().iterator().next();
        assertEquals("PROT NAME", proteinName.getProteinName());
        assertEquals("1234", proteinName.getProteinNamePubkey());
        assertEquals("PROT DESC", proteinName.getProteinDescription());
        assertEquals("ORIG SOURCE ORG", proteinName.getOrigSourceOrganism());

        assertEquals(1, monNumber.getComlTraitTypes().size());
        ComlTraitType comlTraitType = monNumber.getComlTraitTypes().iterator().next();
        assertEquals("TRTABBR", comlTraitType.getComlTraitTypeAbbr());
        assertEquals("TRT TYPE DESC", comlTraitType.getComlTraitTypeDesc());

        assertEquals(1, monNumber.getMonNumberConstructs().size());
        MonNumberConstruct construct = monNumber.getMonNumberConstructs().iterator().next();
        assertEquals("CON_111", construct.getConstructName());
        assertEquals("PV_111", construct.getPvCode());
    }

    @Test
    public void testFindByConstruct_MultipleConstructs() {
        new MonNumberBuilder().
                withMonNumber("MON_1111").
                withEventName("ZM_1111").
                withCrop(CropBuilder.canola()).
                withMonNumberConstruct(
                        new MonNumberConstructBuilder().
                                withConstructName("CON_111, CON_222").
                                withPvCode("PV_111")
                ).
                withMonNumberConstruct(
                        new MonNumberConstructBuilder().
                                withConstructName("CON_222, CON_333").
                                withPvCode("PV_222")
                ).
                withComlTraitType(
                        new ComlTraitTypeBuilder().
                                withTraitTypeAbbr("TRTABBR").
                                withTraitTypeDesc("TRT TYPE DESC")
                ).
                withProteinName(
                        new ProteinNameBuilder().
                                withProteinName("PROT NAME").
                                withProteinNamePubkey("1234").
                                withProteinDescription("PROT DESC").
                                withOrigSourceOrganism("ORIG SOURCE ORG")
                ).
                createInDb();

        MonNumber[] monNumbers = monNumberDao.findByConstruct(new String[]{"CON_111", "CON_222"});

        assertEquals(1, monNumbers.length);
        MonNumber monNumber = monNumbers[0];
        assertEquals("MON_1111", monNumber.getMonNumber());
        assertEquals("ZM_1111", monNumber.getEvent());
        assertEquals("OSR-CANOLA", monNumber.getCrop().getCropName().toUpperCase());
        assertEquals("1415", monNumber.getCrop().getCropPubkey());

        assertEquals(1, monNumber.getProteinNames().size());
        ProteinName proteinName = monNumber.getProteinNames().iterator().next();
        assertEquals("PROT NAME", proteinName.getProteinName());
        assertEquals("1234", proteinName.getProteinNamePubkey());
        assertEquals("PROT DESC", proteinName.getProteinDescription());
        assertEquals("ORIG SOURCE ORG", proteinName.getOrigSourceOrganism());

        assertEquals(1, monNumber.getComlTraitTypes().size());
        ComlTraitType comlTraitType = monNumber.getComlTraitTypes().iterator().next();
        assertEquals("TRTABBR", comlTraitType.getComlTraitTypeAbbr());
        assertEquals("TRT TYPE DESC", comlTraitType.getComlTraitTypeDesc());

        assertEquals(2, monNumber.getMonNumberConstructs().size());
        for (MonNumberConstruct construct : monNumber.getMonNumberConstructs()) {
            if (construct.getConstructName().equals("CON_111, CON_222")) {
                assertEquals("PV_111", construct.getPvCode());
            } else if (construct.getConstructName().equals("CON_222, CON_333")) {
                assertEquals("PV_222", construct.getPvCode());
            } else {
                fail("Invalid mon number construct found.");
            }
        }
    }

    @Test
    public void testFindByPvCode_MultipleMonNumbersSingleConstruct() {
        ProteinNameBuilder proteinNameBuilder = new ProteinNameBuilder().
                withProteinName("PROT NAME").
                withProteinNamePubkey("1234").
                withProteinDescription("PROT DESC").
                withOrigSourceOrganism("ORIG SOURCE ORG");
        ComlTraitTypeBuilder comlTraitTypeBuilder = new ComlTraitTypeBuilder().
                withTraitTypeAbbr("TRTABBR").
                withTraitTypeDesc("TRT TYPE DESC");

        new MonNumberBuilder().
                withMonNumber("MON_1111").
                withEventName("ZM_1111").
                withOecdNumber("OECD1111").
                withCrop(CropBuilder.canola()).
                withMonNumberConstruct(
                        new MonNumberConstructBuilder().
                                withConstructName("CON_111").
                                withPvCode("PV_111")
                ).
                withComlTraitType(comlTraitTypeBuilder).
                withProteinName(proteinNameBuilder).
                createInDb();

        new MonNumberBuilder().
                withMonNumber("MON_2222").
                withEventName("ZM_2222").
                withOecdNumber("OECD2222").
                withCrop(CropBuilder.canola()).
                withMonNumberConstruct(
                        new MonNumberConstructBuilder().
                                withConstructName("CON_111").
                                withPvCode("PV_111")
                ).
                withComlTraitType(comlTraitTypeBuilder).
                withProteinName(proteinNameBuilder).
                createInDb();

        MonNumber[] monNumbers = monNumberDao.findByConstruct(new String[]{"CON_111"});

        assertEquals(2, monNumbers.length);
        for (MonNumber monNumber : monNumbers) {
            if (monNumber.getMonNumber().equals("MON_1111")) {
                assertEquals("ZM_1111", monNumber.getEvent());
                assertEquals("OECD1111", monNumber.getOecdNumber());
            } else {
                assertEquals("ZM_2222", monNumber.getEvent());
                assertEquals("OECD2222", monNumber.getOecdNumber());
            }
            assertEquals("OSR-CANOLA", monNumber.getCrop().getCropName().toUpperCase());
            assertEquals("1415", monNumber.getCrop().getCropPubkey());
            assertEquals(1, monNumber.getProteinNames().size());
            assertEquals(1, monNumber.getComlTraitTypes().size());
            assertEquals(1, monNumber.getMonNumberConstructs().size());
        }
    }

    @Test
    public void testFindByConstruct_NoDataFound() {
        MonNumber[] monNumbers = monNumberDao.findByConstruct(new String[]{"CON_111"});

        assertEquals(0, monNumbers.length);
    }

    @Test
    public void testFindByPvCode_SinglePvCode() {
        new MonNumberBuilder().
                withMonNumber("MON_1111").
                withEventName("ZM_1111").
                withCrop(CropBuilder.soybeans()).
                withMonNumberConstruct(
                        new MonNumberConstructBuilder().
                                withConstructName("CON_111").
                                withPvCode("PV_111")
                ).
                withComlTraitType(
                        new ComlTraitTypeBuilder().
                                withTraitTypeAbbr("TRTABBR").
                                withTraitTypeDesc("TRT TYPE DESC")
                ).
                withProteinName(
                        new ProteinNameBuilder().
                                withProteinName("PROT NAME").
                                withProteinNamePubkey("1234").
                                withProteinDescription("PROT DESC").
                                withOrigSourceOrganism("ORIG SOURCE ORG")
                ).
                createInDb();

        MonNumber[] monNumbers = monNumberDao.findByPvCode(new String[]{"PV_111"});

        assertEquals(1, monNumbers.length);
        MonNumber monNumber = monNumbers[0];
        assertEquals("MON_1111", monNumber.getMonNumber());
        assertEquals("ZM_1111", monNumber.getEvent());
        assertEquals("SOYBEANS", monNumber.getCrop().getCropName().toUpperCase());
        assertEquals("1115", monNumber.getCrop().getCropPubkey());

        assertEquals(1, monNumber.getProteinNames().size());
        ProteinName proteinName = monNumber.getProteinNames().iterator().next();
        assertEquals("PROT NAME", proteinName.getProteinName());
        assertEquals("1234", proteinName.getProteinNamePubkey());
        assertEquals("PROT DESC", proteinName.getProteinDescription());
        assertEquals("ORIG SOURCE ORG", proteinName.getOrigSourceOrganism());

        assertEquals(1, monNumber.getComlTraitTypes().size());
        ComlTraitType comlTraitType = monNumber.getComlTraitTypes().iterator().next();
        assertEquals("TRTABBR", comlTraitType.getComlTraitTypeAbbr());
        assertEquals("TRT TYPE DESC", comlTraitType.getComlTraitTypeDesc());

        assertEquals(1, monNumber.getMonNumberConstructs().size());
        MonNumberConstruct construct = monNumber.getMonNumberConstructs().iterator().next();
        assertEquals("CON_111", construct.getConstructName());
        assertEquals("PV_111", construct.getPvCode());
    }

    @Test
    public void testFindByPvCode_MultiplePvCodes() {
        new MonNumberBuilder().
                withMonNumber("MON_1111").
                withEventName("ZM_1111").
                withCrop(CropBuilder.soybeans()).
                withMonNumberConstruct(
                        new MonNumberConstructBuilder().
                                withConstructName("CON_111").
                                withPvCode("PV_111, PV_222")
                ).
                withMonNumberConstruct(
                        new MonNumberConstructBuilder().
                                withConstructName("CON_222").
                                withPvCode("PV_222, PV_333")
                ).
                withComlTraitType(
                        new ComlTraitTypeBuilder().
                                withTraitTypeAbbr("TRTABBR").
                                withTraitTypeDesc("TRT TYPE DESC")
                ).
                withProteinName(
                        new ProteinNameBuilder().
                                withProteinName("PROT NAME").
                                withProteinNamePubkey("1234").
                                withProteinDescription("PROT DESC").
                                withOrigSourceOrganism("ORIG SOURCE ORG")
                ).
                createInDb();

        MonNumber[] monNumbers = monNumberDao.findByPvCode(new String[]{"PV_111", "PV_222"});

        assertEquals(1, monNumbers.length);
        MonNumber monNumber = monNumbers[0];
        assertEquals("MON_1111", monNumber.getMonNumber());
        assertEquals("ZM_1111", monNumber.getEvent());
        assertEquals("SOYBEANS", monNumber.getCrop().getCropName().toUpperCase());
        assertEquals("1115", monNumber.getCrop().getCropPubkey());

        assertEquals(1, monNumber.getProteinNames().size());
        ProteinName proteinName = monNumber.getProteinNames().iterator().next();
        assertEquals("PROT NAME", proteinName.getProteinName());
        assertEquals("1234", proteinName.getProteinNamePubkey());
        assertEquals("PROT DESC", proteinName.getProteinDescription());
        assertEquals("ORIG SOURCE ORG", proteinName.getOrigSourceOrganism());

        assertEquals(1, monNumber.getComlTraitTypes().size());
        ComlTraitType comlTraitType = monNumber.getComlTraitTypes().iterator().next();
        assertEquals("TRTABBR", comlTraitType.getComlTraitTypeAbbr());
        assertEquals("TRT TYPE DESC", comlTraitType.getComlTraitTypeDesc());

        assertEquals(2, monNumber.getMonNumberConstructs().size());
        for (MonNumberConstruct construct : monNumber.getMonNumberConstructs()) {
            if (construct.getConstructName().equals("CON_111")) {
                assertEquals("PV_111, PV_222", construct.getPvCode());
            } else if (construct.getConstructName().equals("CON_222")) {
                assertEquals("PV_222, PV_333", construct.getPvCode());
            } else {
                fail("Invalid mon number construct found.");
            }
        }
    }

    @Test
    public void testFindByPvCode_MultipleMonNumbersSinglePvCode() {
        ProteinNameBuilder proteinNameBuilder = new ProteinNameBuilder().
                withProteinName("PROT NAME").
                withProteinNamePubkey("1234").
                withProteinDescription("PROT DESC").
                withOrigSourceOrganism("ORIG SOURCE ORG");
        ComlTraitTypeBuilder comlTraitTypeBuilder = new ComlTraitTypeBuilder().
                withTraitTypeAbbr("TRTABBR").
                withTraitTypeDesc("TRT TYPE DESC");

        new MonNumberBuilder().
                withMonNumber("MON_1111").
                withEventName("ZM_1111").
                withOecdNumber("OECD1111").
                withCrop(CropBuilder.soybeans()).
                withMonNumberConstruct(
                        new MonNumberConstructBuilder().
                                withConstructName("CON_111").
                                withPvCode("PV_111")
                ).
                withComlTraitType(comlTraitTypeBuilder).
                withProteinName(proteinNameBuilder).
                createInDb();

        new MonNumberBuilder().
                withMonNumber("MON_2222").
                withEventName("ZM_2222").
                withOecdNumber("OECD2222").
                withCrop(CropBuilder.soybeans()).
                withMonNumberConstruct(
                        new MonNumberConstructBuilder().
                                withConstructName("CON_111").
                                withPvCode("PV_111")
                ).
                withComlTraitType(comlTraitTypeBuilder).
                withProteinName(proteinNameBuilder).
                createInDb();

        MonNumber[] monNumbers = monNumberDao.findByPvCode(new String[]{"PV_111"});

        assertEquals(2, monNumbers.length);
        for (MonNumber monNumber : monNumbers) {
            if (monNumber.getMonNumber().equals("MON_1111")) {
                assertEquals("ZM_1111", monNumber.getEvent());
                assertEquals("OECD1111", monNumber.getOecdNumber());
            } else {
                assertEquals("ZM_2222", monNumber.getEvent());
                assertEquals("OECD2222", monNumber.getOecdNumber());
            }
            assertEquals("SOYBEANS", monNumber.getCrop().getCropName().toUpperCase());
            assertEquals("1115", monNumber.getCrop().getCropPubkey());
            assertEquals(1, monNumber.getProteinNames().size());
            assertEquals(1, monNumber.getComlTraitTypes().size());
            assertEquals(1, monNumber.getMonNumberConstructs().size());
        }
    }

    @Test
    public void testFindByPvCode_NoDataFound() {
        MonNumber[] monNumbers = monNumberDao.findByPvCode(new String[]{"PV_111"});

        assertEquals(0, monNumbers.length);
    }

    @Test
    public void testFindAllMonNumbers()
            throws Exception {

        ProteinNameBuilder proteinNameBuilder = new ProteinNameBuilder().
                withProteinName("PROT NAME").
                withProteinNamePubkey("1234").
                withProteinDescription("PROT DESC").
                withOrigSourceOrganism("ORIG SOURCE ORG");
        ComlTraitTypeBuilder comlTraitTypeBuilder = new ComlTraitTypeBuilder().
                withTraitTypeAbbr("TRTABBR").
                withTraitTypeDesc("TRT TYPE DESC");

        new MonNumberBuilder().
                withMonNumber("MON_1111").
                withEventName("ZM_1111").
                withOecdNumber("OECD1111").
                withCrop(CropBuilder.soybeans()).
                withMonNumberConstruct(
                        new MonNumberConstructBuilder().
                                withConstructName("CON_111").
                                withPvCode("PV_111")
                ).
                withComlTraitType(comlTraitTypeBuilder).
                withProteinName(proteinNameBuilder).
                createInDb();

        MonNumber[] monNumbers = monNumberDao.findAll();

        assertFalse(ArrayUtils.isEmpty(monNumbers));
        assertTrue(containsMonNumber("MON_1111", monNumbers));
        assertTrue(containsTraitType("TRTABBR", monNumbers));
        assertTrue(containsProteinName("PROT NAME", monNumbers));
        assertTrue(containsConstructName("CON_111", monNumbers));
    }

    /*
   Not using builder here so that Ids are not set
    */
    @Test
    public void testSaveMonNumberUsesSequence()
            throws Exception {
        MonNumber monNumber = new MonNumber();
        monNumber.setMonNumber("MON_1111");
        monNumber.setEvent("ZM_1111");
        monNumber.setOecdNumber("OECD1111");
        monNumber.setCrop(CropBuilder.soybeans());
        monNumber.setRegulatoryGenesPresent("y");
        monNumber.setActiveStatus(true);
        monNumber.setLocked(false);
        monNumber.setRegulatedStatus(false);
        monNumber.setJvNumber("JV123");
        monNumber.setRegulatoryParentalLine("rpl");
        monNumberDao.save(monNumber);
        MonNumber monNumberTwo = new MonNumber();
        monNumberTwo.setMonNumber("MON_1112");
        monNumberTwo.setEvent("ZM_1112");
        monNumberTwo.setOecdNumber("OECD1112");
        monNumberTwo.setCrop(CropBuilder.soybeans());
        monNumberTwo.setRegulatoryGenesPresent("y");
        monNumberTwo.setActiveStatus(true);
        monNumberTwo.setLocked(false);
        monNumberTwo.setRegulatedStatus(false);
        monNumberTwo.setRegulatoryParentalLine("rpl");
        monNumberTwo.setJvNumber("JV124");
        monNumberDao.save(monNumberTwo);
    }

    /*
   Not using builder here so that Ids are not set
    */
    @Test
    public void testSaveMonNumberWithTraitTypeProteinAndConstruct_AlsoverifiesUsageOfSequences()
            throws Exception {
        Session session = TestSessions.getLexiconSession();

        MonNumber monNumber = new MonNumber();
        monNumber.setMonNumber("MON_1111");
        monNumber.setEvent("ZM_1111");
        monNumber.setOecdNumber("OECD1111");
        monNumber.setCrop(CropBuilder.soybeans());
        monNumber.setRegulatoryGenesPresent("y");
        monNumber.setActiveStatus(true);
        monNumber.setLocked(false);
        monNumber.setRegulatedStatus(false);
        monNumber.setJvNumber("JV123");
        monNumber.setRegulatoryParentalLine("RPL123");
        monNumberDao.save(monNumber);


        HashSet<MonNumber> monNumberHashSet = new HashSet<MonNumber>();
        monNumberHashSet.add(monNumber);

        ProteinName proteinName = new ProteinName();
        proteinName.setProteinName("PROT NAME");
        proteinName.setProteinNamePubkey("1234");
        proteinName.setProteinDescription("PROT DESC");
        proteinName.setOrigSourceOrganism("ORIG SOURCE ORG");

        ProteinName proteinNameTwo = new ProteinName();
        proteinNameTwo.setProteinName("PROT NAME 1");
        proteinNameTwo.setProteinNamePubkey("12345");
        proteinNameTwo.setProteinDescription("PROT DESC");
        proteinNameTwo.setOrigSourceOrganism("ORIG SOURCE ORG");

        ComlTraitType comlTraitType = new ComlTraitType();
        comlTraitType.setComlTraitTypeAbbr("TRTABBR");
        comlTraitType.setComlTraitTypeDesc("TRT TYPE DESC");

        ComlTraitType comlTraitTypeTwo = new ComlTraitType();
        comlTraitTypeTwo.setComlTraitTypeAbbr("TRTABBR1");
        comlTraitTypeTwo.setComlTraitTypeDesc("TRT TYPE DESC");

        ComlTraitName comlTraitName = new ComlTraitName();
        comlTraitName.setTraitAbbr("TABBR");
        comlTraitName.setTraitDesc("TDESC");
        comlTraitName.setActive(true);

        MonNumberConstruct monNumberConstruct = new MonNumberConstruct();
        monNumberConstruct.setConstructName("CON_111");
        monNumberConstruct.setPvCode("PV_111");
        monNumberConstruct.setMonNumber(monNumber);
        MonNumberConstruct monNumberConstructTwo = new MonNumberConstruct();
        monNumberConstructTwo.setConstructName("CON_111");
        monNumberConstructTwo.setPvCode("PV_111");
        monNumberConstructTwo.setMonNumber(monNumber);

        session.save(proteinName);
        session.save(proteinNameTwo);
        session.save(comlTraitType);
        session.save(comlTraitTypeTwo);
        session.save(comlTraitName);
        monNumberDao.saveMonNumberConstruct(monNumberConstruct);
        monNumberDao.saveMonNumberConstruct(monNumberConstructTwo);

        Set<ComlTraitType> comlTraitTypes = new HashSet<ComlTraitType>();
        comlTraitTypes.add(comlTraitType);
        comlTraitTypes.add(comlTraitTypeTwo);
        monNumber.setComlTraitTypes(comlTraitTypes);

        Set<ComlTraitName> comlTraitNames = new HashSet<ComlTraitName>();
        comlTraitNames.add(comlTraitName);
        monNumber.setComlTraitNames(comlTraitNames);

        Set<ProteinName> proteinNames = new HashSet<ProteinName>();
        proteinNames.add(proteinName);
        proteinNames.add(proteinNameTwo);
        monNumber.setProteinNames(proteinNames);

        Set<MonNumberConstruct> monNumberConstructs = new HashSet<MonNumberConstruct>();
        monNumberConstructs.add(monNumberConstruct);
        monNumberConstructs.add(monNumberConstructTwo);
        monNumber.setMonNumberConstructs(monNumberConstructs);

        session.flush();

        MonNumber monNumberActual = monNumberDao.find("MON_1111");
        assertNotNull(monNumberActual);
        assertNotNull(monNumberActual.getMonNumberId());
        MonNumber[] monNumbers = {monNumberActual};
        assertTrue(containsConstructName("CON_111", monNumbers));
        assertTrue(containsTraitType("TRTABBR", monNumbers));
        assertTrue(containsProteinName("PROT NAME", monNumbers));
        assertTrue(containsTraitName("TABBR", monNumbers));
    }

    @Test
    public void testSaveMonNumber_RegulatoryParentalLineHasSpecialCharacters()
            throws Exception {
        Session session = TestSessions.getLexiconSession();

        MonNumber monNumber = new MonNumber();
        monNumber.setMonNumber("MON_1111");
        monNumber.setEvent("ZM_1111");
        monNumber.setOecdNumber("OECD1111");
        monNumber.setCrop(CropBuilder.soybeans());
        monNumber.setRegulatoryGenesPresent("y");
        monNumber.setActiveStatus(true);
        monNumber.setLocked(false);
        monNumber.setRegulatedStatus(false);
        monNumber.setJvNumber("JV123");
        monNumber.setRegulatoryParentalLine("RPL&copy;%&copy;");
        monNumberDao.save(monNumber);
        session.flush();
        MonNumber monNumberActual = monNumberDao.find("MON_1111");
        assertNotNull(monNumberActual);
        assertEquals(monNumber.getMonNumber(), monNumberActual.getMonNumber());
        assertEquals(monNumber.getRegulatoryParentalLine(), monNumberActual.getRegulatoryParentalLine());
    }

    @Test
    public void testFindProteinNameByPubkey()
            throws Exception {
        ProteinName proteinName = new ProteinNameBuilder().
                withProteinName("PROT NAME").
                withProteinNamePubkey("1234").
                withProteinDescription("PROT DESC").
                withOrigSourceOrganism("ORIG SOURCE ORG").create();
        ProteinName proteinNameReceived = monNumberDao.findProteinNameByPubkey(proteinName.getProteinNamePubkey());
        assertNotNull(proteinNameReceived);
        assertEquals(proteinName.getProteinNamePubkey(), proteinNameReceived.getProteinNamePubkey());
    }

    @Test
    public void testFindByEvent_FindsMonNumber()
            throws Exception {
        new MonNumberBuilder().
                withMonNumber("MON_1111").
                withEventName("ZM_1111").
                withCrop(CropBuilder.corn()).
                withMonNumberConstruct(
                        new MonNumberConstructBuilder().
                                withConstructName("CON_111").
                                withPvCode("PV_111")
                ).
                withComlTraitType(
                        new ComlTraitTypeBuilder().
                                withTraitTypeAbbr("TRTABBR").
                                withTraitTypeDesc("TRT TYPE DESC")
                ).
                withProteinName(
                        new ProteinNameBuilder().
                                withProteinName("PROT NAME").
                                withProteinNamePubkey("1234").
                                withProteinDescription("PROT DESC").
                                withOrigSourceOrganism("ORIG SOURCE ORG")
                ).
                createInDb();

        MonNumber monNumber = monNumberDao.findByEvent("ZM_1111");

        assertEquals("MON_1111", monNumber.getMonNumber());
        assertEquals("ZM_1111", monNumber.getEvent());

        assertNotNull(monNumber.getMonNumberConstructs());
        assertEquals(1, monNumber.getMonNumberConstructs().size());
        MonNumberConstruct construct = monNumber.getMonNumberConstructs().iterator().next();
        assertEquals("CON_111", construct.getConstructName());
        assertEquals("PV_111", construct.getPvCode());

        assertNotNull(monNumber.getComlTraitTypes());
        assertEquals(1, monNumber.getComlTraitTypes().size());
        ComlTraitType comlTrait = monNumber.getComlTraitTypes().iterator().next();
        assertEquals("TRTABBR", comlTrait.getComlTraitTypeAbbr());
        assertEquals("TRT TYPE DESC", comlTrait.getComlTraitTypeDesc());

        assertNotNull(monNumber.getProteinNames());
        assertEquals(1, monNumber.getProteinNames().size());
        ProteinName proteinName = monNumber.getProteinNames().iterator().next();
        assertEquals("PROT NAME", proteinName.getProteinName());
        assertEquals("PROT DESC", proteinName.getProteinDescription());
        assertEquals("1234", proteinName.getProteinNamePubkey());
        assertEquals("ORIG SOURCE ORG", proteinName.getOrigSourceOrganism());
    }


    @Test
    public void testFindByEvent_FindsMonNumber_IsCaseInsensitive()
            throws Exception {
        new MonNumberBuilder().
                withMonNumber("MON_1111").
                withEventName("ZM_1111").
                withCrop(CropBuilder.corn()).
                withMonNumberConstruct(
                        new MonNumberConstructBuilder().
                                withConstructName("CON_111").
                                withPvCode("PV_111")
                ).
                withComlTraitType(
                        new ComlTraitTypeBuilder().
                                withTraitTypeAbbr("TRTABBR").
                                withTraitTypeDesc("TRT TYPE DESC")
                ).
                withComlTraitName(
                        new ComlTraitNameBuilder().
                                withTraitAbbr("TABBR").
                                withTraitDesc("TDESC")
                ).
                withProteinName(
                        new ProteinNameBuilder().
                                withProteinName("PROT NAME").
                                withProteinNamePubkey("1234").
                                withProteinDescription("PROT DESC").
                                withOrigSourceOrganism("ORIG SOURCE ORG")
                ).
                createInDb();

        MonNumber monNumber = monNumberDao.findByEvent("zm_1111");

        assertEquals("MON_1111", monNumber.getMonNumber());
        assertEquals("ZM_1111", monNumber.getEvent());

        assertNotNull(monNumber.getMonNumberConstructs());
        assertEquals(1, monNumber.getMonNumberConstructs().size());
        MonNumberConstruct construct = monNumber.getMonNumberConstructs().iterator().next();
        assertEquals("CON_111", construct.getConstructName());
        assertEquals("PV_111", construct.getPvCode());

        assertNotNull(monNumber.getComlTraitTypes());
        assertEquals(1, monNumber.getComlTraitTypes().size());
        ComlTraitType comlTrait = monNumber.getComlTraitTypes().iterator().next();
        assertEquals("TRTABBR", comlTrait.getComlTraitTypeAbbr());
        assertEquals("TRT TYPE DESC", comlTrait.getComlTraitTypeDesc());

        assertNotNull(monNumber.getComlTraitNames());
        assertEquals(1, monNumber.getComlTraitNames().size());
        ComlTraitName comlTraitName = monNumber.getComlTraitNames().iterator().next();
        assertEquals("TABBR", comlTraitName.getTraitAbbr());
        assertEquals("TDESC", comlTraitName.getTraitDesc());

        assertNotNull(monNumber.getProteinNames());
        assertEquals(1, monNumber.getProteinNames().size());
        ProteinName proteinName = monNumber.getProteinNames().iterator().next();
        assertEquals("PROT NAME", proteinName.getProteinName());
        assertEquals("PROT DESC", proteinName.getProteinDescription());
        assertEquals("1234", proteinName.getProteinNamePubkey());
        assertEquals("ORIG SOURCE ORG", proteinName.getOrigSourceOrganism());
    }


    @Test
    public void testFindByEvent_NotFound()
            throws Exception {
        MonNumber monNumber = monNumberDao.findByEvent("ZM_1111");

        assertNull(monNumber);
    }


    @Test
    public void testFindByOecdNumber_FindsMonNumber()
            throws Exception {
        new MonNumberBuilder().
                withMonNumber("MON_1111").
                withEventName("ZM_1111").
                withOecdNumber("OECD2").
                withCrop(CropBuilder.corn()).
                withMonNumberConstruct(
                        new MonNumberConstructBuilder().
                                withConstructName("CON_111").
                                withPvCode("PV_111")
                ).
                withComlTraitType(
                        new ComlTraitTypeBuilder().
                                withTraitTypeAbbr("TRTABBR").
                                withTraitTypeDesc("TRT TYPE DESC")
                ).
                withComlTraitName(
                        new ComlTraitNameBuilder().
                                withTraitAbbr("TABBR").
                                withTraitDesc("TDESC")
                ).
                withProteinName(
                        new ProteinNameBuilder().
                                withProteinName("PROT NAME").
                                withProteinNamePubkey("1234").
                                withProteinDescription("PROT DESC").
                                withOrigSourceOrganism("ORIG SOURCE ORG")
                ).
                createInDb();

        MonNumber monNumber = monNumberDao.findByOecdNumber("OECD2");

        assertEquals("MON_1111", monNumber.getMonNumber());
        assertEquals("ZM_1111", monNumber.getEvent());

        assertNotNull(monNumber.getMonNumberConstructs());
        assertEquals(1, monNumber.getMonNumberConstructs().size());
        MonNumberConstruct construct = monNumber.getMonNumberConstructs().iterator().next();
        assertEquals("CON_111", construct.getConstructName());
        assertEquals("PV_111", construct.getPvCode());

        assertNotNull(monNumber.getComlTraitTypes());
        assertEquals(1, monNumber.getComlTraitTypes().size());
        ComlTraitType comlTrait = monNumber.getComlTraitTypes().iterator().next();
        assertEquals("TRTABBR", comlTrait.getComlTraitTypeAbbr());
        assertEquals("TRT TYPE DESC", comlTrait.getComlTraitTypeDesc());

        assertNotNull(monNumber.getComlTraitNames());
        assertEquals(1, monNumber.getComlTraitNames().size());
        ComlTraitName comlTraitName = monNumber.getComlTraitNames().iterator().next();
        assertEquals("TABBR", comlTraitName.getTraitAbbr());
        assertEquals("TDESC", comlTraitName.getTraitDesc());

        assertNotNull(monNumber.getProteinNames());
        assertEquals(1, monNumber.getProteinNames().size());
        ProteinName proteinName = monNumber.getProteinNames().iterator().next();
        assertEquals("PROT NAME", proteinName.getProteinName());
        assertEquals("PROT DESC", proteinName.getProteinDescription());
        assertEquals("1234", proteinName.getProteinNamePubkey());
        assertEquals("ORIG SOURCE ORG", proteinName.getOrigSourceOrganism());
    }


    @Test
    public void testFindByOecdNumber_FindsMonNumber_IsCaseInsensitive()
            throws Exception {
        new MonNumberBuilder().
                withMonNumber("MON_1111").
                withEventName("ZM_1111").
                withOecdNumber("OECD2").
                withCrop(CropBuilder.corn()).
                withMonNumberConstruct(
                        new MonNumberConstructBuilder().
                                withConstructName("CON_111").
                                withPvCode("PV_111")
                ).
                withComlTraitType(
                        new ComlTraitTypeBuilder().
                                withTraitTypeAbbr("TRTABBR").
                                withTraitTypeDesc("TRT TYPE DESC")
                ).
                withProteinName(
                        new ProteinNameBuilder().
                                withProteinName("PROT NAME").
                                withProteinNamePubkey("1234").
                                withProteinDescription("PROT DESC").
                                withOrigSourceOrganism("ORIG SOURCE ORG")
                ).
                createInDb();

        MonNumber monNumber = monNumberDao.findByOecdNumber("oecd2");

        assertEquals("MON_1111", monNumber.getMonNumber());
        assertEquals("ZM_1111", monNumber.getEvent());

        assertNotNull(monNumber.getMonNumberConstructs());
        assertEquals(1, monNumber.getMonNumberConstructs().size());
        MonNumberConstruct construct = monNumber.getMonNumberConstructs().iterator().next();
        assertEquals("CON_111", construct.getConstructName());
        assertEquals("PV_111", construct.getPvCode());

        assertNotNull(monNumber.getComlTraitTypes());
        assertEquals(1, monNumber.getComlTraitTypes().size());
        ComlTraitType comlTrait = monNumber.getComlTraitTypes().iterator().next();
        assertEquals("TRTABBR", comlTrait.getComlTraitTypeAbbr());
        assertEquals("TRT TYPE DESC", comlTrait.getComlTraitTypeDesc());

        assertNotNull(monNumber.getProteinNames());
        assertEquals(1, monNumber.getProteinNames().size());
        ProteinName proteinName = monNumber.getProteinNames().iterator().next();
        assertEquals("PROT NAME", proteinName.getProteinName());
        assertEquals("PROT DESC", proteinName.getProteinDescription());
        assertEquals("1234", proteinName.getProteinNamePubkey());
        assertEquals("ORIG SOURCE ORG", proteinName.getOrigSourceOrganism());
    }


    @Test
    public void testFindByOecdNumber_NotFound()
            throws Exception {
        MonNumber monNumber = monNumberDao.findByOecdNumber("1111");

        assertNull(monNumber);
    }


    @Test
    public void testUpdateMonNumber_UpdatesMonNumber() {

        new MonNumberBuilder().
                withMonNumber("MON_1111").
                withCrop(CropBuilder.corn())
                .createInDb();

        MonNumber monNumber = monNumberDao.find("MON_1111");
        monNumber.setRegulatoryGenesPresent("updated genes");
        monNumber.setRegulatoryParentalLine("updated rpl");
        monNumber.setActiveStatus(false);
        monNumber.setJvNumber("updated jv");
        monNumber.setMaterialName("updated material");
        monNumber.setOecdNumber("updatedOECD");
        TestSessions.getLexiconSession().flush();
        MonNumber monNumberUpdated = monNumberDao.find("MON_1111");
        assertEquals("updated jv", monNumberUpdated.getJvNumber());
        assertEquals("updated material", monNumberUpdated.getMaterialName());
        assertEquals("updatedOECD", monNumberUpdated.getOecdNumber());
        assertEquals("updated genes", monNumberUpdated.getRegulatoryGenesPresent());
        assertEquals("updated rpl", monNumberUpdated.getRegulatoryParentalLine());
    }

    @Test
    public void testUpdateMonNumber_UpdatesMonNumberConstruct() {

        MonNumber monNumberCreated = new MonNumberBuilder().
                withMonNumber("MON_1111").
                withCrop(CropBuilder.corn()).
                withMonNumberConstruct(
                        new MonNumberConstructBuilder().
                                withConstructName("CON_111").
                                withPvCode("PV_111")
                ).createInDb();

        MonNumberConstruct monNumberConstructCreated
                = monNumberCreated.getMonNumberConstructs().iterator().next();
        MonNumber monNumber = monNumberDao.find("MON_1111");
        monNumber.getMonNumberConstructs().remove(monNumberConstructCreated);
        MonNumberConstruct newMonNumberConstruct = new MonNumberConstruct();
        newMonNumberConstruct.setPvCode("PV_2222");
        newMonNumberConstruct.setConstructName("CON_222");
        newMonNumberConstruct.setMonNumber(monNumber);
        monNumber.getMonNumberConstructs().add(newMonNumberConstruct);
        TestSessions.getLexiconSession().flush();
        MonNumber monNumberUpdated = monNumberDao.find("MON_1111");
        Collection<MonNumberConstruct> constructCollection = monNumberUpdated.getMonNumberConstructs();
        assertFalse(constructCollection.isEmpty());
        assertEquals(1, constructCollection.size());
        MonNumberConstruct monNumberConstructUpdated
                = constructCollection.iterator().next();
        assertEquals("CON_222", monNumberConstructUpdated.getConstructName());
        assertEquals("PV_2222", monNumberConstructUpdated.getPvCode());

        MonNumberConstruct[] monNumberConstructs = monNumberDao.findMonNumberConstructByName("CON_111");
        assertTrue(ArrayUtils.isEmpty(monNumberConstructs));
    }


    @Test
    public void testUpdateMonNumber_UpdatesComlTraitTypes() {

        MonNumber monNumberCreated = new MonNumberBuilder().
                withMonNumber("MON_1111").
                withCrop(CropBuilder.corn()).
                withComlTraitType(
                        new ComlTraitTypeBuilder().
                                withTraitTypeAbbr("TRTABBR").
                                withTraitTypeDesc("TRT TYPE DESC")
                ).createInDb();

        ComlTraitType comlTraitTypeTwo = new ComlTraitTypeBuilder().withTraitTypeAbbr("TRTABBR2").create();


        ComlTraitType comlTraitTypeCreated
                = monNumberCreated.getComlTraitTypes().iterator().next();

        MonNumber monNumber = monNumberDao.find("MON_1111");
        monNumber.getComlTraitTypes().remove(comlTraitTypeCreated);
        monNumber.getComlTraitTypes().add(comlTraitTypeTwo);
        TestSessions.getLexiconSession().flush();

        MonNumber monNumberUpdated = monNumberDao.find("MON_1111");
        Collection<ComlTraitType> traitTypeCollection = monNumberUpdated.getComlTraitTypes();
        assertFalse(traitTypeCollection.isEmpty());
        assertEquals(1, traitTypeCollection.size());
        ComlTraitType ComlTraitType
                = traitTypeCollection.iterator().next();
        assertEquals("TRTABBR2", ComlTraitType.getComlTraitTypeAbbr());

    }


    @Test
    public void testUpdateMonNumber_UpdatesComlTraitNames() {

        MonNumber monNumberCreated = new MonNumberBuilder().
                withMonNumber("MON_1111").
                withCrop(CropBuilder.corn()).
                withComlTraitName(
                        new ComlTraitNameBuilder().
                                withTraitAbbr("TABBR").
                                withTraitDesc("TDESC")
                ).createInDb();

        ComlTraitName comlTraitNameTwo = new ComlTraitNameBuilder().withTraitAbbr("TABBR2").create();


        ComlTraitName comlTraitName
                = monNumberCreated.getComlTraitNames().iterator().next();

        MonNumber monNumber = monNumberDao.find("MON_1111");
        monNumber.getComlTraitNames().remove(comlTraitName);
        monNumber.getComlTraitNames().add(comlTraitNameTwo);
        TestSessions.getLexiconSession().flush();

        MonNumber monNumberUpdated = monNumberDao.find("MON_1111");
        Collection<ComlTraitName> traitNameCollection = monNumberUpdated.getComlTraitNames();
        assertFalse(traitNameCollection.isEmpty());
        assertEquals(1, traitNameCollection.size());
        ComlTraitName traitName
                = traitNameCollection.iterator().next();
        assertEquals("TABBR2", traitName.getTraitAbbr());

    }

    @Test
    public void testUpdateMonNumber_UpdatesProteinNames() {

        MonNumber monNumberCreated = new MonNumberBuilder().
                withMonNumber("MON_1111").
                withCrop(CropBuilder.corn()).
                withProteinName(
                        new ProteinNameBuilder().
                                withProteinName("PROT NAME").
                                withProteinNamePubkey("1234").
                                withProteinDescription("PROT DESC").
                                withOrigSourceOrganism("ORIG SOURCE ORG")
                ).createInDb();

        ProteinName proteinNameTwo = new ProteinNameBuilder().withProteinName("PROT NAME2").create();

        ProteinName proteinNameCreated
                = monNumberCreated.getProteinNames().iterator().next();

        MonNumber monNumber = monNumberDao.find("MON_1111");
        monNumber.getProteinNames().remove(proteinNameCreated);
        monNumber.getProteinNames().add(proteinNameTwo);
        TestSessions.getLexiconSession().flush();

        MonNumber monNumberUpdated = monNumberDao.find("MON_1111");
        Collection<ProteinName> proteinNameCollection = monNumberUpdated.getProteinNames();
        assertFalse(proteinNameCollection.isEmpty());
        assertEquals(1, proteinNameCollection.size());
        ProteinName proteinName
                = proteinNameCollection.iterator().next();
        assertEquals("PROT NAME2", proteinName.getProteinName());
    }


    @Test
    public void testFindMonNumberInfoByEventsAndCrop_FindsMonNumber()
            throws Exception {
        new MonNumberBuilder().
                withMonNumber("MON_1111").
                withEventName("ZM_1111").
                withCrop(CropBuilder.corn()).
                createInDb();

        String[] events = new String[]{"ZM_1111"};
        List<MonNumberInfo> monNumbers = monNumberDao.findByEventsAndCrop(events, "Corn");
        assertNotNull(monNumbers);
        assertFalse(monNumbers.isEmpty());
        MonNumberInfo monNumberInfo = monNumbers.get(0);
        assertEquals("MON_1111", monNumberInfo.getMonNumber());
        assertEquals("ZM_1111", monNumberInfo.getEvent());
    }

    @Test
    public void testFindMonNumberInfoByEventsAndCrop_DoesNotFind_ForNonExistantMonNumber()
            throws Exception {
        String[] events = new String[]{"ZM_1111"};
        List<MonNumberInfo> monNumbers = monNumberDao.findByEventsAndCrop(events, "Corn");
        assertNotNull(monNumbers);
        assertTrue(monNumbers.isEmpty());
    }


    @Test
    public void testFindMonNumberInfoByEventsAndCrop_FindsMonNumber_CaseInsensitiveCrop()
            throws Exception {
        new MonNumberBuilder().
                withMonNumber("MON_1111").
                withEventName("ZM_1111").
                withCrop(CropBuilder.corn()).
                createInDb();

        String[] events = new String[]{"ZM_1111"};
        List<MonNumberInfo> monNumbers = monNumberDao.findByEventsAndCrop(events, "coRN");
        assertNotNull(monNumbers);
        assertFalse(monNumbers.isEmpty());
        MonNumberInfo monNumberInfo = monNumbers.get(0);
        assertEquals("MON_1111", monNumberInfo.getMonNumber());
        assertEquals("ZM_1111", monNumberInfo.getEvent());
    }

    @Test
    public void testFindMonNumberInfoByEventsAndCrop_FindsMonNumber_CaseInsensitiveEvent()
            throws Exception {
        new MonNumberBuilder().
                withMonNumber("MON_1111").
                withEventName("ZM_1111").
                withCrop(CropBuilder.corn()).
                createInDb();

        String[] events = new String[]{"zM_1111"};
        List<MonNumberInfo> monNumbers = monNumberDao.findByEventsAndCrop(events, "Corn");
        assertNotNull(monNumbers);
        assertFalse(monNumbers.isEmpty());
        MonNumberInfo monNumberInfo = monNumbers.get(0);
        assertEquals("MON_1111", monNumberInfo.getMonNumber());
        assertEquals("ZM_1111", monNumberInfo.getEvent());
    }

    @Test
    public void testFindMonNumberInfoByEventsAndCrop_FindsMonNumber_MultipleEvents()
            throws Exception {
        new MonNumberBuilder().
                withMonNumber("MON_1111").
                withEventName("ZM_1111").
                withCrop(CropBuilder.corn()).
                createInDb();

        new MonNumberBuilder().
                withMonNumber("MON_2222").
                withEventName("ZM_2222").
                withOecdNumber("OECD4455").
                withCrop(CropBuilder.corn()).
                createInDb();

        String[] events = new String[]{"ZM_1111", "ZM_2222"};
        List<MonNumberInfo> monNumbers = monNumberDao.findByEventsAndCrop(events, "Corn");
        assertNotNull(monNumbers);
        assertFalse(monNumbers.isEmpty());
        assertEquals(2, monNumbers.size());
        MonNumberInfo monNumberInfo1 = monNumbers.get(0);
        MonNumberInfo monNumberInfo2 = monNumbers.get(1);
        if (!"MON_1111".equals(monNumberInfo1.getMonNumber())) {
            MonNumberInfo monNumberInfo = monNumberInfo1;
            monNumberInfo1 = monNumberInfo2;
            monNumberInfo2 = monNumberInfo;
        }
        assertEquals("MON_1111", monNumberInfo1.getMonNumber());
        assertEquals("ZM_1111", monNumberInfo1.getEvent());


        assertEquals("MON_2222", monNumberInfo2.getMonNumber());
        assertEquals("ZM_2222", monNumberInfo2.getEvent());
    }


    @Test
    public void testFindMonNumberInfoByMonNumbers_DoesNotFind_ForNonExistantMonNumber()
            throws Exception {
        List<MonNumberInfo> monNumbers = monNumberDao.findByMonNumbers(new String[]{"MON 1111"});
        assertNotNull(monNumbers);
        assertTrue(monNumbers.isEmpty());
    }

    @Test
    public void testFindMonNumberInfoByMonNumbers_ReturnsMonNumbers()
            throws Exception {
        new MonNumberBuilder().
                withMonNumber("MON_1111").
                withEventName("ZM_1111").
                withCrop(CropBuilder.corn()).
                createInDb();

        new MonNumberBuilder().
                withMonNumber("MON_2222").
                withEventName("ZM_2222").
                withOecdNumber("OECD4455").
                withCrop(CropBuilder.corn()).
                createInDb();

        List<MonNumberInfo> monNumbers = monNumberDao.findByMonNumbers(new String[]{"MON_1111", "MON_2222"});
        assertNotNull(monNumbers);
        assertFalse(monNumbers.isEmpty());
        assertEquals(2, monNumbers.size());
        MonNumberInfo monNumberInfo = monNumbers.get(0);
        List<String> monNumberCheck = Arrays.asList(monNumbers.get(0).getMonNumber(), monNumbers.get(1).getMonNumber());
        List<String> eventCheck = Arrays.asList(monNumbers.get(0).getEvent(), monNumbers.get(1).getEvent());
        assertTrue(monNumberCheck.contains("MON_1111"));
        assertTrue(eventCheck.contains("ZM_1111"));


        assertTrue(monNumberCheck.contains("MON_2222"));
        assertTrue(eventCheck.contains("ZM_2222"));
    }

    @Test
    public void testFindMonNumberInfoByMonNumbers_ReturnsMonNumbers_CaseInsensitiveSearch()
            throws Exception {
        new MonNumberBuilder().
                withMonNumber("MON_1111").
                withEventName("ZM_1111").
                withCrop(CropBuilder.corn()).
                createInDb();
        List<MonNumberInfo> monNumbers = monNumberDao.findByMonNumbers(new String[]{"mOn_1111"});
        assertNotNull(monNumbers);
        assertFalse(monNumbers.isEmpty());
        assertEquals(1, monNumbers.size());
        MonNumberInfo monNumberInfo = monNumbers.get(0);
        assertEquals("MON_1111", monNumberInfo.getMonNumber());
        assertEquals("ZM_1111", monNumberInfo.getEvent());

    }



    @Test
    public void testFindMonNumberInfoByMonNumbers_DoesNotReturnMonNumbers_ForEmptySearchCriteria()
            throws Exception {
        new MonNumberBuilder().
                withMonNumber("MON_1111").
                withEventName("ZM_1111").
                withCrop(CropBuilder.corn()).
                createInDb();
        List<MonNumberInfo> monNumbers = monNumberDao.findByMonNumbers(new String[]{""});
        assertNotNull(monNumbers);
        assertTrue(monNumbers.isEmpty());
    }

    @Test
    public void testFindMonNumberInfoByMonNumbers_DoesNotReturnMonNumbers_ForNullSearchCriteria()
            throws Exception {
        new MonNumberBuilder().
                withMonNumber("MON_1111").
                withEventName("ZM_1111").
                withCrop(CropBuilder.corn()).
                createInDb();
        List<MonNumberInfo> monNumbers = monNumberDao.findByMonNumbers(new String[]{null});
        assertNotNull(monNumbers);
        assertTrue(monNumbers.isEmpty());
    }

    @Test
    public void testFindMonNumberConstructByConstructName_IsCaseInsensitive_ReturnsMonNumberConstructs()
            throws Exception {
        new MonNumberConstructBuilder().
                withConstructName("CON_111").
                withPvCode("PV_111").create(new MonNumberBuilder().createInDb());
        MonNumberConstruct[] monNumberConstructs = monNumberDao.findMonNumberConstructByName("con_111");
        assertFalse(ArrayUtils.isEmpty(monNumberConstructs));
        assertEquals(1, monNumberConstructs.length);
        MonNumberConstruct monNumberConstruct = monNumberConstructs[0];
        assertEquals("CON_111", monNumberConstruct.getConstructName());
        assertEquals("PV_111", monNumberConstruct.getPvCode());
    }

   @Test
   public void testGetMonNumbersByMonNumber(){
      MonNumber monNumber =  new MonNumberBuilder().
         withMonNumber("MON_1234").
         withEventName("ZM_1234").
         withCrop(CropBuilder.corn()).
         createInDb();
      tempSessionOcdDao.clearValues(REQUEST_ID);
      tempSessionOcdDao.insertText1Values(REQUEST_ID, Arrays.asList(monNumber.getMonNumber()));
      List<MonNumber> monNumbers = monNumberDao.getMonNumbersByMonNumber(REQUEST_ID);
      assertNotNull(monNumber);
      assertEquals(monNumbers.get(0).getMonNumber(), monNumber.getMonNumber());
   }

    private boolean containsConstructName(String constructName, MonNumber[] monNumbers) {
        for (MonNumber monNumber : monNumbers) {
            Collection<MonNumberConstruct> monNumberConstructs = monNumber.getMonNumberConstructs();
            for (MonNumberConstruct monNumberConstruct : monNumberConstructs) {
                if (constructName.equalsIgnoreCase(monNumberConstruct.getConstructName())) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean containsProteinName(String proteinName, MonNumber[] monNumbers) {
        for (MonNumber monNumber : monNumbers) {
            Collection<ProteinName> proteinNames = monNumber.getProteinNames();
            for (ProteinName name : proteinNames) {
                if (proteinName.equalsIgnoreCase(name.getProteinName())) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean containsTraitType(String traitTypeAbbr, MonNumber[] monNumbers) {
        for (MonNumber monNumber : monNumbers) {
            Collection<ComlTraitType> traitTypes = monNumber.getComlTraitTypes();
            for (ComlTraitType traitType : traitTypes) {
                if (traitTypeAbbr.equalsIgnoreCase(traitType.getComlTraitTypeAbbr())) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean containsTraitName(String traitAbbr, MonNumber[] monNumbers) {
        for (MonNumber monNumber : monNumbers) {
            Collection<ComlTraitName> comlTraitNames = monNumber.getComlTraitNames();
            for (ComlTraitName traitName : comlTraitNames) {
                if (traitAbbr.equalsIgnoreCase(traitName.getTraitAbbr())) {
                    return true;
                }
            }
        }
        return false;
    }


    private boolean containsMonNumber(String monNumber, MonNumber[] monNumbers) {
        for (MonNumber number : monNumbers) {
            if (monNumber.equalsIgnoreCase(number.getMonNumber())) {
                return true;
            }
        }
        return false;
    }
}
