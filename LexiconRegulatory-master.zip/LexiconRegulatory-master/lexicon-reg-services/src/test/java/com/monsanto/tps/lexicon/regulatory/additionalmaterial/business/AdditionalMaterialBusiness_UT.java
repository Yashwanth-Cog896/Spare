package com.monsanto.tps.lexicon.regulatory.additionalmaterial.business;

import com.monsanto.tps.lexicon.additionalmaterialinfo.OrionAdditionalMaterial;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.AdditionalMaterial;
import com.monsanto.tps.lexicon.regulatory.additionalmaterialinfo.business.AdditionalMaterialBusiness;
import com.monsanto.tps.lexicon.regulatory.additionalmaterialinfo.dao.AdditionalMaterialDAO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static junit.framework.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/1/12
 * Time: 7:47 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class AdditionalMaterialBusiness_UT {

    @Mock
    private AdditionalMaterialDAO additionalMaterialDAO;

    @InjectMocks
    private AdditionalMaterialBusiness additionalMaterialBusiness = new AdditionalMaterialBusiness();

    private final List<AdditionalMaterial> singleAdditionalMaterialListFromDAO;
    private final List<AdditionalMaterial> multiAdditionalMaterialListFromDAO;
    private static final List<AdditionalMaterial> emptyListFromDAO = new ArrayList<AdditionalMaterial>();

    private final List<OrionAdditionalMaterial> singleAdditionalMaterialListFromBusiness;
    private final List<OrionAdditionalMaterial> multiAdditionalMaterialListFromBusiness;
    private static final List<OrionAdditionalMaterial> emptyListFromBusiness = new ArrayList<OrionAdditionalMaterial>();

    public AdditionalMaterialBusiness_UT() {
        singleAdditionalMaterialListFromDAO = new ArrayList<AdditionalMaterial>();
        singleAdditionalMaterialListFromDAO.add(new AdditionalMaterial("ingredient", "alias", "CAS", "IUPAC", "cpNumber", true));

        multiAdditionalMaterialListFromDAO = new ArrayList<AdditionalMaterial>();
        multiAdditionalMaterialListFromDAO.add(new AdditionalMaterial("ingredient1", "alias", "CAS", "IUPAC", "cpNumber", true));
        multiAdditionalMaterialListFromDAO.add(new AdditionalMaterial("ingredient2", "alias", "CAS", "IUPAC", "cpNumber", true));

        singleAdditionalMaterialListFromBusiness = new ArrayList<OrionAdditionalMaterial>();
        singleAdditionalMaterialListFromBusiness.add(createMaterial("ingredient", "alias", "CAS", "IUPAC", "cpNumber", true));

        multiAdditionalMaterialListFromBusiness = new ArrayList<OrionAdditionalMaterial>();
        multiAdditionalMaterialListFromBusiness.add(createMaterial("ingredient1", "alias", "CAS", "IUPAC", "cpNumber", true));
        multiAdditionalMaterialListFromBusiness.add(createMaterial("ingredient2", "alias", "CAS", "IUPAC", "cpNumber", true));
    }

    private OrionAdditionalMaterial createMaterial(String name, String alias, String cas, String iupac, String cp, boolean active) {
        OrionAdditionalMaterial material = new OrionAdditionalMaterial();
        material.setMaterialName(name);
        material.setAlias(alias);
        material.setChemicalNameCAS(cas);
        material.setChemicalNameIUPAC(iupac);
        material.setCpNumber(cp);
        material.setActiveStatus(active);

        return material;
    }

    @Test
    public void findAdditionalMaterial_findNone() throws Exception {

        when(additionalMaterialDAO.findAdditionalMaterials("asdf")).thenReturn(emptyListFromDAO);

        final List<OrionAdditionalMaterial> actualAdditionalMaterials = additionalMaterialBusiness.findAdditionalMaterials("asdf");

        checkAdditionalMaterialLists(actualAdditionalMaterials, emptyListFromBusiness);
    }

    @Test
    public void findAdditionalMaterial_findSingle() throws Exception {

        when(additionalMaterialDAO.findAdditionalMaterials("tryptophan")).thenReturn(singleAdditionalMaterialListFromDAO);

        final List<OrionAdditionalMaterial> actualAdditionalMaterials = additionalMaterialBusiness.findAdditionalMaterials("tryptophan");

        checkAdditionalMaterialLists(actualAdditionalMaterials, singleAdditionalMaterialListFromBusiness);
    }

    @Test
    public void findAdditionalMaterial_findByWildcard() throws Exception {

        when(additionalMaterialDAO.findAdditionalMaterials("Tri%")).thenReturn(multiAdditionalMaterialListFromDAO);

        final List<OrionAdditionalMaterial> actualAdditionalMaterials = additionalMaterialBusiness.findAdditionalMaterials("Tri*");

        checkAdditionalMaterialLists(actualAdditionalMaterials, multiAdditionalMaterialListFromBusiness);
    }

    @Test
    public void findAdditionalMaterial_findAll() throws Exception {

        when(additionalMaterialDAO.findAdditionalMaterials("%")).thenReturn(multiAdditionalMaterialListFromDAO);

        final List<OrionAdditionalMaterial> actualAdditionalMaterials = additionalMaterialBusiness.findAdditionalMaterials("");

        checkAdditionalMaterialLists(actualAdditionalMaterials, multiAdditionalMaterialListFromBusiness);
    }

    private void checkAdditionalMaterialLists(final List<OrionAdditionalMaterial> actualAdditionalMaterials, final List<OrionAdditionalMaterial> singleAdditionalMaterialListFromBusiness) {
        assertNotNull(actualAdditionalMaterials);

        for(int i=0; i<singleAdditionalMaterialListFromBusiness.size(); i++) {
            final OrionAdditionalMaterial additionalMaterial = actualAdditionalMaterials.get(i);
            assertEquals(additionalMaterial.getMaterialName(), singleAdditionalMaterialListFromBusiness.get(i).getMaterialName());
            assertEquals(additionalMaterial.getActiveStatus(), singleAdditionalMaterialListFromBusiness.get(i).getActiveStatus());
        }
    }
}
