package com.monsanto.tps.lexicon.regulatory.plantname.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.LexiconDataUnitTestCase;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.PlantNameBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.PlantName;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Comparator;
import java.util.List;

import static com.google.common.collect.Ordering.from;
import static junit.framework.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/1/12
 * Time: 7:47 PM
 */
public class PlantNameDAOImpl_DUT
    extends LexiconDataUnitTestCase
{
    @Autowired
    private PlantNameDAO plantNameDAO;

    @Test
    public void findPlantName_results_wildcard() throws Exception {
        new PlantNameBuilder().
            withMaterialName("Roundup Ready2 Testing").
            thatIsActive().
            create();

        List<PlantName> plantNames = plantNameDAO.findPlantNames("Round%");
        assertFalse(plantNames.isEmpty());
        assertStartsWith(plantNames, "Round");
    }

    @Test
    public void findPlantName_results_exactMatch() throws Exception {
        new PlantNameBuilder().
            withMaterialName("BollGard Cotton Testing").
            thatIsActive().
            create();

        final List<PlantName> plantNames = plantNameDAO.findPlantNames("BollGard Cotton Testing");
        assertFalse(plantNames.isEmpty());
        assertStartsWith(plantNames, "BollGard Cotton Testing");
    }

    @Test
    public void findPlantName_noResults() throws Exception {
        final List<PlantName> plantNames = plantNameDAO.findPlantNames("asdf");
        assertTrue(plantNames.isEmpty());
    }

    @Test
    public void findPlantName_results_active() throws Exception {
        final List<PlantName> plantNames = plantNameDAO.findPlantNames("");
        assertNotNull(plantNames);
        assertFalse(plantNames.isEmpty());

        for (PlantName plantName : plantNames) {
            assertTrue(plantName.getActiveStatus());
        }
    }

    @Test
    public void findPlantName_results_inactive() throws Exception {
        new PlantNameBuilder().
            withMaterialName("BollGard Cotton Testing").
            thatIsInactive().
            create();

        final List<PlantName> plantNames = plantNameDAO.findPlantNames("BollGard Cotton Testing");
        assertNotNull(plantNames);
        assertTrue(plantNames.isEmpty());
    }

    @Test
    public void findPlantName_sorted() throws Exception {
        final List<PlantName> plantNames = plantNameDAO.findPlantNames("%");
        assertNotNull(plantNames);

        assertTrue(from(new PlantNameComparator()).isOrdered(plantNames));
    }

    private class PlantNameComparator implements Comparator<PlantName> {

        public final int compare(PlantName c1, PlantName c2) {

            int ctCompare = 0;

            if (c1 != null && c2 != null) {
                String ct1 = c1.getMaterialName();
                String ct2 = c2.getMaterialName();
                if (ct1 != null && ct2 != null) {
                    ctCompare = ct1.compareToIgnoreCase(ct2);
                }
            }

            return ctCompare;
        }
    }

        private void assertStartsWith(List<PlantName> products, String startsWith) {
        for(PlantName product : products) {
            String materialName = product.getMaterialName().toUpperCase();
            assertTrue(materialName.startsWith(startsWith.toUpperCase()));
        }
    }
}

