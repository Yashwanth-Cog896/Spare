package com.monsanto.tps.lexicon.regulatory.event.delegate;

import com.monsanto.tps.lexicon.event.EventAgency;
import com.monsanto.tps.lexicon.event.EventDeregulationStatus;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Agency;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Country;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Crop;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;
import org.apache.commons.lang.ArrayUtils;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static junit.framework.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * rrchak1 - Jun 23, 2009 3:15:06 PM
 */
public class EventStatusBuilder_UT {
    Crop crop;
    Country country;
    private String eventOne = "EVENT_ONE";
    private String cornCropName = "CORN";
    private String usaCountryName = "USA";
    private String usdaAgencyAbbr = "USDA";
    private String epaAgencyAbbr = "EPA";
    private String eventTwo = "EVENT_TWO";

    @Before
    public void before() {
        crop = new Crop();
        crop.setCropName(cornCropName);
        country = new Country();
        country.setCountryName(usaCountryName);
    }

    @Test
    public void build_ReturnsEventDeregulationStatus_ForSingle_EventAgencyAlignment() {
        EventAgencyAlignment eventAgencyAlignment = new EventAgencyAlignment();
        eventAgencyAlignment.setMaterialName(eventOne);
        eventAgencyAlignment.setCrop(crop);
        Agency agency = new Agency();
        agency.setAgencyAbbr(usdaAgencyAbbr);
        agency.setCountry(country);
        eventAgencyAlignment.setAgency(agency);
        EventStatusBuilder builder = new EventStatusBuilder();
        List<EventDeregulationStatus> response = builder.build(new EventAgencyAlignment[]{eventAgencyAlignment}, crop.getCropName());
        assertFalse(response.isEmpty());
        assertEquals(1, response.size());
        EventDeregulationStatus eventDeregulationStatus = response.get(0);
        assertNotNull(eventDeregulationStatus);
        assertEquals(eventOne, eventDeregulationStatus.getEventName());
        assertEquals(cornCropName, eventDeregulationStatus.getCrop());
        EventAgency[] agencies = eventDeregulationStatus.getEventAgencies();
        assertFalse(ArrayUtils.isEmpty(agencies));
        assertEquals(1, agencies.length);
        EventAgency eventAgency = agencies[0];
        assertEquals(usaCountryName, eventAgency.getCountryName());
        assertEquals(usdaAgencyAbbr, eventAgency.getAgencyAbbr());
    }


    @Test
    public void build_ReturnsEventDeregulationStatus_OneEventAssociatedWithMultipleAgencies() {
        Agency usdaAgency = new Agency();
        usdaAgency.setAgencyAbbr(usdaAgencyAbbr);
        usdaAgency.setCountry(country);

        Agency epaAgency = new Agency();
        epaAgency.setAgencyAbbr(epaAgencyAbbr);
        epaAgency.setCountry(country);

        EventAgencyAlignment alignmentOne = new EventAgencyAlignment();
        alignmentOne.setCrop(crop);
        alignmentOne.setMaterialName(eventOne);
        alignmentOne.setAgency(usdaAgency);

        EventAgencyAlignment alignmentTwo = new EventAgencyAlignment();
        alignmentTwo.setCrop(crop);
        alignmentTwo.setMaterialName(eventOne);
        alignmentTwo.setAgency(epaAgency);


        EventStatusBuilder builder = new EventStatusBuilder();
        List<EventDeregulationStatus> response = builder.build(new EventAgencyAlignment[]{alignmentOne, alignmentTwo}, crop.getCropName());
        assertFalse(response.isEmpty());
        assertEquals(1, response.size());
        EventDeregulationStatus eventDeregulationStatus = response.get(0);
        assertNotNull(eventDeregulationStatus);
        assertEquals(eventOne, eventDeregulationStatus.getEventName());
        assertEquals(cornCropName, eventDeregulationStatus.getCrop());
        EventAgency[] agencies = eventDeregulationStatus.getEventAgencies();
        assertFalse(ArrayUtils.isEmpty(agencies));
        assertEquals(2, agencies.length);
        assertTrue(hasAgency(usdaAgencyAbbr, agencies));
        assertTrue(hasAgency(epaAgencyAbbr, agencies));
    }

    @Test
    public void build_ReturnsEventDeregulationStatus_MultipleEventsAssociatedWithOneAgency() {

        Agency usdaAgency = new Agency();
        usdaAgency.setAgencyAbbr(usdaAgencyAbbr);
        usdaAgency.setCountry(country);

        EventAgencyAlignment alignmentOne = new EventAgencyAlignment();
        alignmentOne.setCrop(crop);
        alignmentOne.setMaterialName(eventOne);
        alignmentOne.setAgency(usdaAgency);

        EventAgencyAlignment alignmentTwo = new EventAgencyAlignment();
        alignmentTwo.setCrop(crop);
        alignmentTwo.setMaterialName(eventTwo);
        alignmentTwo.setAgency(usdaAgency);


        EventStatusBuilder builder = new EventStatusBuilder();
        List<EventDeregulationStatus> response = builder.build(new EventAgencyAlignment[]{alignmentOne, alignmentTwo}, crop.getCropName());
        assertFalse(response.isEmpty());
        assertEquals(2, response.size());
        EventDeregulationStatus eventDeregulationStatus = response.get(0);
        assertNotNull(eventDeregulationStatus);
        assertEquals(eventOne, eventDeregulationStatus.getEventName());
        assertEquals(cornCropName, eventDeregulationStatus.getCrop());
        EventAgency[] agencies = eventDeregulationStatus.getEventAgencies();
        assertFalse(ArrayUtils.isEmpty(agencies));
        assertEquals(1, agencies.length);
        assertTrue(hasAgency(usdaAgencyAbbr, agencies));

        EventDeregulationStatus deregulationStatus = response.get(1);
        assertNotNull(deregulationStatus);
        assertEquals(eventTwo, deregulationStatus.getEventName());
        assertEquals(cornCropName, deregulationStatus.getCrop());
        EventAgency[] eventAgencies = deregulationStatus.getEventAgencies();
        assertFalse(ArrayUtils.isEmpty(eventAgencies));
        assertEquals(1, eventAgencies.length);
        assertTrue(hasAgency(usdaAgencyAbbr, eventAgencies));

    }

    @Test
    public void build_ReturnsEventDeregulationStatus_MultipleEventsAssociatedWithMultipleAgencies() {


        Agency usdaAgency = new Agency();
        usdaAgency.setAgencyAbbr(usdaAgencyAbbr);
        usdaAgency.setCountry(country);

        Agency epaAgency = new Agency();
        epaAgency.setAgencyAbbr(epaAgencyAbbr);
        epaAgency.setCountry(country);

        EventAgencyAlignment eventOneUsdaAlignment = new EventAgencyAlignment();
        eventOneUsdaAlignment.setCrop(crop);
        eventOneUsdaAlignment.setMaterialName(eventOne);
        eventOneUsdaAlignment.setAgency(usdaAgency);

        EventAgencyAlignment eventOneEpaAlignment = new EventAgencyAlignment();
        eventOneEpaAlignment.setCrop(crop);
        eventOneEpaAlignment.setMaterialName(eventOne);
        eventOneEpaAlignment.setAgency(epaAgency);

        EventAgencyAlignment eventTwoUsdaAlignment = new EventAgencyAlignment();
        eventTwoUsdaAlignment.setCrop(crop);
        eventTwoUsdaAlignment.setMaterialName(eventTwo);
        eventTwoUsdaAlignment.setAgency(usdaAgency);

        EventAgencyAlignment eventTwoEpaAlignment = new EventAgencyAlignment();
        eventTwoEpaAlignment.setCrop(crop);
        eventTwoEpaAlignment.setMaterialName(eventTwo);
        eventTwoEpaAlignment.setAgency(epaAgency);


        EventStatusBuilder builder = new EventStatusBuilder();
        List<EventDeregulationStatus> response = builder.build(new EventAgencyAlignment[]{eventOneUsdaAlignment,
                eventOneEpaAlignment, eventTwoUsdaAlignment, eventTwoEpaAlignment}, crop.getCropName());
        assertFalse(response.isEmpty());
        assertEquals(2, response.size());
        EventDeregulationStatus eventDeregulationStatus = response.get(0);
        assertNotNull(eventDeregulationStatus);
        assertEquals(eventOne, eventDeregulationStatus.getEventName());
        assertEquals(cornCropName, eventDeregulationStatus.getCrop());
        EventAgency[] agencies = eventDeregulationStatus.getEventAgencies();
        assertFalse(ArrayUtils.isEmpty(agencies));
        assertEquals(2, agencies.length);
        assertTrue(hasAgency(usdaAgencyAbbr, agencies));
        assertTrue(hasAgency(epaAgencyAbbr, agencies));

        EventDeregulationStatus deregulationStatus = response.get(1);
        assertNotNull(deregulationStatus);
        assertEquals(eventTwo, deregulationStatus.getEventName());
        assertEquals(cornCropName, deregulationStatus.getCrop());
        EventAgency[] eventAgencies = deregulationStatus.getEventAgencies();
        assertFalse(ArrayUtils.isEmpty(eventAgencies));
        assertEquals(2, eventAgencies.length);
        assertTrue(hasAgency(usdaAgencyAbbr, eventAgencies));
        assertTrue(hasAgency(epaAgencyAbbr, eventAgencies));

    }

    private boolean hasAgency(String agencyAbbr, EventAgency[] agencies) {
        for (EventAgency agency : agencies) {
            if (agencyAbbr.equalsIgnoreCase(agency.getAgencyAbbr())) {
                return true;
            }
        }
        return false;
    }
}
