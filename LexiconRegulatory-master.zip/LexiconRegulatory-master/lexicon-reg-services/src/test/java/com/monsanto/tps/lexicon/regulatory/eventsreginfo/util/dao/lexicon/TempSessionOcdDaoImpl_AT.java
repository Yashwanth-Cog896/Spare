package com.monsanto.tps.lexicon.regulatory.eventsreginfo.util.dao.lexicon;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.LexiconAcceptanceTestCase;
import com.monsanto.tps.lexicon.regulatory.eventsreginfo.util.domain.lexicon.TempSessionOcd;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.junit.Ignore;
import org.junit.Test;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertThat;
import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: vvkalu
 * Date: Oct 11, 2010
 * Time: 6:28:42 PM
 * To change this template use File | Settings | File Templates.
 */
public class TempSessionOcdDaoImpl_AT extends LexiconAcceptanceTestCase {

   @Resource
   private SessionFactory lexiconSessionFactory;
   @Resource
   private TempSessionOcdDao tempSessionOcdDao;

   @Test
   public void testInsertText1Values() throws Exception {
      Session session = lexiconSessionFactory.getCurrentSession();
      tempSessionOcdDao.insertText1Values(42L, Arrays.asList("1", "2"));
      List<TempSessionOcd> tsos = (List<TempSessionOcd>) session.createQuery("select t from TempSessionOcd as t order by t.sortOrder").list();
      assertEquals(2, tsos.size());
      TempSessionOcd tso1 = tsos.get(0);
      TempSessionOcd tso2 = tsos.get(1);
      assertEquals("1", tso1.getText1());
      assertEquals("2", tso2.getText1());
      assertFalse(tso1.getText1().equals(tso2.getText1()));
   }

   @Test
   public void testInsertNumber1Values() throws Exception {
        Session session = lexiconSessionFactory.getCurrentSession();
        long first = 30L;
        long second = 20L;
        long third = 50L;
        tempSessionOcdDao.insertNumber1Values(42L, Arrays.asList(first, second, third));
        List<TempSessionOcd> tempSessionOcds = (List<TempSessionOcd>) session.createQuery("select t from TempSessionOcd as t order by t.sortOrder").list();
        assertEquals(3, tempSessionOcds.size());
        assertEquals(30L, tempSessionOcds.get(0).getNumber1().longValue());
        assertEquals(20L, tempSessionOcds.get(1).getNumber1().longValue());
        assertEquals(50L, tempSessionOcds.get(2).getNumber1().longValue());
    }

    @Test
    @Ignore
    public void testClearValues() throws Exception {
         Session session = lexiconSessionFactory.getCurrentSession();
         long first = 30L;
         long second = 20L;
         long third = 50L;
         tempSessionOcdDao.insertNumber1Values(42L, Arrays.asList(first, second, third));
         List<TempSessionOcd> tempSessionOcds = (List<TempSessionOcd>) session.createQuery("select t from TempSessionOcd as t order by t.sortOrder").list();
         assertEquals(3, tempSessionOcds.size());

       // tempSessionOcdDao.clearValues();
        tempSessionOcds = (List<TempSessionOcd>) session.createQuery("select t from TempSessionOcd as t order by t.sortOrder").list();
        assertEquals(0, tempSessionOcds.size());
     }
}
