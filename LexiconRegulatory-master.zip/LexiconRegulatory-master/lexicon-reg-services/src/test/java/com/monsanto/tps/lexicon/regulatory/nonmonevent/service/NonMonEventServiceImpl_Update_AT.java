package com.monsanto.tps.lexicon.regulatory.nonmonevent.service;

import com.monsanto.tps.lexicon.nonmonevent.NonMonEventPersistBatchRequest;
import com.monsanto.tps.lexicon.nonmonevent.NonMonEventPersistRequest;
import com.monsanto.tps.lexicon.nonmonevent.NonMonEventPersistResponse;
import com.monsanto.tps.lexicon.nonmonevent.NonMonEventService;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.ComlTraitNameBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.ComlTraitTypeBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.CropBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.DataFilterBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.LexiconAcceptanceTestCase;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.NonMonEventBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.NonMonEventConstructBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.ProteinNameBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.TestSessions;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName;
import com.monsanto.tps.lexicon.regulatory.DB.TestUtil.TPSTestConstants;
import com.monsanto.tps.lexicon.regulatory.DB.Tests.LexiconDataServiceATTestCase;
import static org.hamcrest.CoreMatchers.*;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

import static org.junit.Assert.*;
import static org.junit.Assert.assertThat;

import java.util.Arrays;

/**
 * nbwald - May 25, 2009 4:06:34 PM
 */
@Transactional
public class NonMonEventServiceImpl_Update_AT
   extends LexiconAcceptanceTestCase
{
   @Resource
   private NonMonEventService nonMonEventService;
   private final LexiconDataServiceATTestCase lexiconDataServiceATTestCase = new LexiconDataServiceATTestCase();


   @Test
 public void testUpdate_Commit()
      throws Exception
   {
      insert(new AcceptanceTestData<NonMonEvent>()
      {
         @Override
         public NonMonEvent dataToInsert() {
            return new NonMonEventBuilder().
               withEventDescription("EVENTNAMEVALUE").
               withCropPubkey(CropBuilder.corn().getCropPubkey()).
               withMaterialName("MAT NAME1").
               withProteinName(new ProteinNameBuilder().
                  withProteinName("OLDPROTEINNAME").
                  create()).
               withComlTraitName(new ComlTraitNameBuilder().withDataFilter(DataFilterBuilder.regulatory())).
               withNonMonEventConstruct(new NonMonEventConstructBuilder().withConstructName("CONSTRUCTVALUE")).
               create();
         }
      });

      NonMonEventPersistRequest request = new NonMonEventPersistRequest();
      request.setEventName("EVENTNAMEVALUE");
      request.setConstruct("CONSTRUCTVALUE");
      request.setCropPubkey(CropBuilder.corn().getCropPubkey());
      request.setTraitTypeAbbreviations(createRegulatoryTraitType(), createRegulatoryTraitType(), createRegulatoryTraitType());
      request.setTraitNameAbbreviations(createRegulatoryTraitName(), createRegulatoryTraitName());
      request.setProteinPubkeys(createProtein(), createProtein(), createProtein(), createProtein());
      request.setActive(true);
      request.setAuditComment("AUDITCOMMENTVALUE");
      request.setAuditRequestor("AUDITREQUESTORVALUE");
      request.setMaterialName("MAT NAME2");

      NonMonEventPersistBatchRequest batchRequest = new NonMonEventPersistBatchRequest();
      batchRequest.setValidateOnly(false);
      batchRequest.setRequests(request);
      NonMonEventPersistResponse[] responses = nonMonEventService.update(batchRequest);

      assertThat(responses.length, is(1));
      NonMonEventPersistResponse response = responses[0];
      assertThat(response.isSuccess(), is(true));
      assertThat(response.getConstructs().length, is(1));
      assertThat(response.getConstructs()[0], is("CONSTRUCTVALUE"));

      NonMonEvent event = findEvent("EVENTNAMEVALUE");
      assertThat(event, is(not(nullValue())));
      assertThat(event.getEventDescription(), is(request.getEventName()));
      assertThat(event.getMaterialName(), is(request.getMaterialName()));
      assertThat(event.getNonMonEventConstructs().size(), is(1));
      assertThat(event.isActiveStatus(), is(request.isActive()));
      assertThat(event.getCropPubkey(), is(CropBuilder.corn().getCropPubkey()));
      assertThat(event.getProteinNames().size(), is(4));
      assertThat(event.getComlTraitTypes().size(), is(3));
      assertThat(event.getComlTraitNames().size(), is(2));
   }

   @Test 
 public void testUpdate_Commit_AddConstruct()
      throws Exception
   {
      insert(new AcceptanceTestData<NonMonEvent>()
      {
         @Override
         public NonMonEvent dataToInsert() {
            return new NonMonEventBuilder().
               withEventDescription("EVENTNAMEVALUE").
               withCropPubkey(CropBuilder.corn().getCropPubkey()).
               withProteinName(new ProteinNameBuilder().
                  withProteinName("OLDPROTEINNAME").
                  create()).
               withComlTraitName(new ComlTraitNameBuilder().withDataFilter(DataFilterBuilder.regulatory())).
               create();
         }
      });

      NonMonEventPersistRequest request = new NonMonEventPersistRequest();
      request.setEventName("EVENTNAMEVALUE");
      request.setConstruct("CONSTRUCTVALUE");
      request.setCropPubkey(CropBuilder.corn().getCropPubkey());
      request.setTraitTypeAbbreviations(createRegulatoryTraitType(), createRegulatoryTraitType(), createRegulatoryTraitType());
      request.setTraitNameAbbreviations(createRegulatoryTraitName(), createRegulatoryTraitName());
      request.setProteinPubkeys(createProtein(), createProtein(), createProtein(), createProtein());
      request.setActive(true);
      request.setAuditComment("AUDITCOMMENTVALUE");
      request.setAuditRequestor("AUDITREQUESTORVALUE");
      request.setMaterialName("MAT NAME2");

      NonMonEventPersistBatchRequest batchRequest = new NonMonEventPersistBatchRequest();
      batchRequest.setValidateOnly(false);
      batchRequest.setRequests(request);
      NonMonEventPersistResponse[] responses = nonMonEventService.update(batchRequest);

      assertThat(responses.length, is(1));
      NonMonEventPersistResponse response = responses[0];
      assertThat(response.isSuccess(), is(true));
      assertThat(response.getConstructs().length, is(1));
      assertThat(response.getConstructs()[0], is("CONSTRUCTVALUE"));

      NonMonEvent event = findEvent("EVENTNAMEVALUE");
      assertThat(event, is(not(nullValue())));
      assertThat(event.getEventDescription(), is(request.getEventName()));
      assertThat(event.getMaterialName(), is(request.getMaterialName()));
      assertThat(event.getNonMonEventConstructs().size(), is(1));
      assertThat(event.isActiveStatus(), is(request.isActive()));
      assertThat(event.getCropPubkey(), is(CropBuilder.corn().getCropPubkey()));
      assertThat(event.getProteinNames().size(), is(4));
      assertThat(event.getComlTraitTypes().size(), is(3));
      assertThat(event.getComlTraitNames().size(), is(2));
   }

   @Test
   @Ignore
 public void testUpdate_ValidateOnly_DoNotPassConstruct_EventNameExistsInMidas_WithSingleConstruct()
      throws Exception
   {
      insert(new AcceptanceTestData<NonMonEvent>()
      {
         @Override
         public NonMonEvent dataToInsert() {
            return new NonMonEventBuilder().
               withEventDescription("EVENTNAMEVALUE").
               withCropPubkey(CropBuilder.corn().getCropPubkey()).
               withProteinName(new ProteinNameBuilder().
                  withProteinName("OLDPROTEINNAME").
                  create()).
               withComlTraitName(new ComlTraitNameBuilder().withDataFilter(DataFilterBuilder.regulatory())).
               create();
         }
      });

      lexiconDataServiceATTestCase.setUp();
      try{
      new EventConstructBuilder().
         withEventName("EVENTNAMEVALUE").
         withConstructName("CONSTRUCTVALUE").
         withCrop(TPSTestConstants.MIDAS_CORN_ID).
         create(lexiconDataServiceATTestCase.getMidasConn());

      NonMonEventPersistRequest request = new NonMonEventPersistRequest();
      request.setEventName("EVENTNAMEVALUE");
      request.setCropPubkey(CropBuilder.corn().getCropPubkey());
      request.setTraitTypeAbbreviations(createRegulatoryTraitType());
      request.setProteinPubkeys(createProtein(), createProtein(), createProtein());
      request.setActive(true);
      request.setAuditComment("AUDITCOMMENTVALUE");
      request.setAuditRequestor("AUDITREQUESTORVALUE");

      NonMonEventPersistBatchRequest batchRequest = new NonMonEventPersistBatchRequest();
      batchRequest.setValidateOnly(true);
      batchRequest.setRequests(request);
      NonMonEventPersistResponse[] responses = nonMonEventService.update(batchRequest);

      assertThat(responses.length, is(1));
      NonMonEventPersistResponse response = responses[0];
      assertThat(response.isSuccess(), is(true));
      assertThat(response.getMessages().length, is(0));
      assertThat(response.getConstructs().length, is(1));
      assertThat(response.getConstructs()[0], is("CONSTRUCTVALUE"));

      NonMonEvent event = findEvent("EVENTNAMEVALUE");
      assertThat(event.getProteinNames().size(), is(1));
      }
      finally {
         lexiconDataServiceATTestCase.tearDown();
      }

   }

   @Test 
 public void testUpdate_ValidateOnly_DoNotPassConstruct_EventDoesNotExistInMidas()
      throws Exception
   {
      insert(new AcceptanceTestData<NonMonEvent>()
      {
         @Override
         public NonMonEvent dataToInsert() {
            return new NonMonEventBuilder().
               withEventDescription("EVENTNAMEVALUE").
               withCropPubkey(CropBuilder.corn().getCropPubkey()).
               withProteinName(new ProteinNameBuilder().
                  withProteinName("OLDPROTEINNAME").
                  create()).
               withComlTraitName(new ComlTraitNameBuilder().withDataFilter(DataFilterBuilder.regulatory())).
               create();
         }
      });

      NonMonEventPersistRequest request = new NonMonEventPersistRequest();
      request.setEventName("EVENTNAMEVALUE");
      request.setCropPubkey(CropBuilder.corn().getCropPubkey());
      request.setTraitTypeAbbreviations(createRegulatoryTraitType());
      request.setProteinPubkeys(createProtein(), createProtein(), createProtein());
      request.setActive(true);
      request.setAuditComment("AUDITCOMMENTVALUE");
      request.setAuditRequestor("AUDITREQUESTORVALUE");

      NonMonEventPersistBatchRequest batchRequest = new NonMonEventPersistBatchRequest();
      batchRequest.setValidateOnly(true);
      batchRequest.setRequests(request);
      NonMonEventPersistResponse[] responses = nonMonEventService.update(batchRequest);

      assertThat(responses.length, is(1));
      NonMonEventPersistResponse response = responses[0];
      assertThat(response.isSuccess(), is(false));
      assertThat(response.getMessages().length, is(1));
      assertThat(response.getMessages()[0], is("Invalid Event for Selected Crop."));
      assertThat(response.getConstructs().length, is(0));

      NonMonEvent event = findEvent("EVENTNAMEVALUE");
      assertThat(event.getProteinNames().size(), is(1));
   }

   @Test
   @Ignore
 public void testUpdate_ValidateOnly_DoNotPassConstruct_EventNameExistsInMidas_WithMultipleConstructs()
      throws Exception
   {

      insert(new AcceptanceTestData<NonMonEvent>()
      {
         @Override
         public NonMonEvent dataToInsert() {
            return new NonMonEventBuilder().
               withEventDescription("EVENTNAMEVALUE").
               withCropPubkey(CropBuilder.corn().getCropPubkey()).
               withProteinName(new ProteinNameBuilder().
                  withProteinName("OLDPROTEINNAME").
                  create()).
               withComlTraitName(new ComlTraitNameBuilder().withDataFilter(DataFilterBuilder.regulatory())).
               create();
         }
      });


      lexiconDataServiceATTestCase.setUp();
      try{
      new EventConstructBuilder().
         withEventName("EVENTNAMEVALUE").
         withConstructName("CONSTRUCTVALUE_A").
         withCrop(TPSTestConstants.MIDAS_CORN_ID).
         create(lexiconDataServiceATTestCase.getMidasConn());
      new EventConstructBuilder().
         withEventName("EVENTNAMEVALUE").
         withConstructName("CONSTRUCTVALUE_B").
         withCrop(TPSTestConstants.MIDAS_CORN_ID).
         create(lexiconDataServiceATTestCase.getMidasConn());

      NonMonEventPersistRequest request = new NonMonEventPersistRequest();
      request.setEventName("EVENTNAMEVALUE");
      request.setCropPubkey(CropBuilder.corn().getCropPubkey());
      request.setTraitTypeAbbreviations(createRegulatoryTraitType());
      request.setProteinPubkeys(createProtein(), createProtein(), createProtein(), createProtein());
      request.setActive(true);
      request.setAuditComment("AUDITCOMMENTVALUE");
      request.setAuditRequestor("AUDITREQUESTORVALUE");

      NonMonEventPersistBatchRequest batchRequest = new NonMonEventPersistBatchRequest();
      batchRequest.setValidateOnly(true);
      batchRequest.setRequests(request);
      NonMonEventPersistResponse[] responses = nonMonEventService.update(batchRequest);

      assertThat(responses.length, is(1));
      NonMonEventPersistResponse response = responses[0];
      assertThat(response.isSuccess(), is(false));
      assertThat(response.getMessages().length, is(1));
      assertThat(response.getMessages()[0], is("Event has multiple constructs."));
      assertThat(response.getConstructs().length, is(2));
      assertThat(Arrays.asList(response.getConstructs()).contains("CONSTRUCTVALUE_A"), is(true));
      assertThat(Arrays.asList(response.getConstructs()).contains("CONSTRUCTVALUE_B"), is(true));

      NonMonEvent event = findEvent("EVENTNAMEVALUE");
      assertThat(event.getProteinNames().size(), is(1));
      }
      finally{
         lexiconDataServiceATTestCase.tearDown();
      }
   }

   @Test 
 public void testUpdate_ValidateOnly_PassConstruct()
      throws Exception
   {
      insert(new AcceptanceTestData<NonMonEvent>()
      {
         @Override
         public NonMonEvent dataToInsert() {
            return new NonMonEventBuilder().
               withEventDescription("EVENTNAMEVALUE").
               withCropPubkey(CropBuilder.corn().getCropPubkey()).
               withProteinName(new ProteinNameBuilder().
                  withProteinName("OLDPROTEINNAME").
                  create()).
               withComlTraitName(new ComlTraitNameBuilder().withDataFilter(DataFilterBuilder.regulatory())).
               withNonMonEventConstruct(new NonMonEventConstructBuilder().withConstructName("CONSTRUCTVALUE")).
               create();
         }
      });

      NonMonEventPersistRequest request = new NonMonEventPersistRequest();
      request.setEventName("EVENTNAMEVALUE");
      request.setConstruct("CONSTRUCTVALUE");
      request.setCropPubkey(CropBuilder.corn().getCropPubkey());
      request.setTraitTypeAbbreviations(createRegulatoryTraitType());
      request.setProteinPubkeys(createProtein(), createProtein(), createProtein(), createProtein());
      request.setActive(true);
      request.setAuditComment("AUDITCOMMENTVALUE");
      request.setAuditRequestor("AUDITREQUESTORVALUE");
      request.setMaterialName("MAT NAME");

      NonMonEventPersistBatchRequest batchRequest = new NonMonEventPersistBatchRequest();
      batchRequest.setValidateOnly(true);
      batchRequest.setRequests(request);
      NonMonEventPersistResponse[] responses = nonMonEventService.update(batchRequest);

      assertThat(responses.length, is(1));
      NonMonEventPersistResponse response = responses[0];
      assertThat(response.isSuccess(), is(true));
      assertThat(response.getMessages().length, is(0));
      assertThat(response.getConstructs().length, is(1));
      assertThat(response.getConstructs()[0], is("CONSTRUCTVALUE"));

      NonMonEvent event = findEvent("EVENTNAMEVALUE");
      assertThat(event.getProteinNames().size(), is(1));
   }

   private NonMonEvent findEvent(String eventName) {
      Session session = TestSessions.getLexiconSession();
      return (NonMonEvent) session.createCriteria(NonMonEvent.class).add(Restrictions.eq("eventDescription", eventName)).uniqueResult();
   }

   private String createProtein() {
      return insert(new AcceptanceTestData<String>()
      {
         @Override
         public String dataToInsert() {
            ProteinName protein = new ProteinNameBuilder().create();
            return protein.getProteinNamePubkey();
         }
      });
   }

   private String createRegulatoryTraitName() {
      return insert(new AcceptanceTestData<String>()
      {
         @Override
         public String dataToInsert() {
            ComlTraitName traitName = new ComlTraitNameBuilder().
               withDataFilter(DataFilterBuilder.regulatory()).
               create();
            return traitName.getTraitAbbr();
         }
      });
   }

   private String createRegulatoryTraitType() {
      return insert(new AcceptanceTestData<String>()
      {
         @Override
         public String dataToInsert() {
            ComlTraitType traitType = new ComlTraitTypeBuilder().
               withDataFilter(DataFilterBuilder.regulatory()).
               create();
            return traitType.getComlTraitTypeAbbr();
         }
      });
   }
}
