package com.monsanto.tps.lexicon.regulatory.monnumber.service;

import com.monsanto.tps.lexicon.commercialtrait.ComlTraitType;
import com.monsanto.tps.lexicon.monnumber.MonNumberConstruct;
import com.monsanto.tps.lexicon.monnumber.MonNumberInfo;
import com.monsanto.tps.lexicon.monnumber.MonNumberService;
import com.monsanto.tps.lexicon.monnumber.ProteinName;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.ComlTraitTypeBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.CropBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.LexiconAcceptanceTestCase;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.MonNumberBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.MonNumberConstructBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.ProteinNameBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber;
import org.apache.commons.lang.ArrayUtils;
import org.junit.Test;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: gdleon
 * Date: Apr 22, 2009
 * Time: 3:27:02 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public class MonNumberServiceImpl_AT
   extends LexiconAcceptanceTestCase
{
   @Resource
   private MonNumberService monNumberService;

   @Test
 public void testReturnsMatchingMonNumberWithSingleChildDataForValidCrop() {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withCrop(CropBuilder.soybeans()).
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROTNAME").
                  withProteinNamePubkey("1234")
               ).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("CTRTABBR").
                  withTraitTypeDesc("CTRT DESC")
               ).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME").
                  withPvCode("CONPV")
               ).
               createInDb();
         }
      });

      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByCrop("1115");

      assertTrue(monNumbers.length > 0);

      boolean insertedMonNumberFound = false;
      for (com.monsanto.tps.lexicon.monnumber.MonNumber monNumber : monNumbers) {
         // all returned mon numbers should be active
         assertTrue(monNumber.isActiveStatus());

         if (monNumber.getMonNumber().equals("MON_1111")) {
            insertedMonNumberFound = true;

            assertEquals("MON_1111", monNumber.getMonNumber());
            assertEquals("ZM_1111", monNumber.getEvent());
            assertEquals("SOYBEANS", monNumber.getCropName());
            assertEquals("1115", monNumber.getCropPubkey());
            assertNull(monNumber.getMaterialName());
            assertNull(monNumber.getPreviousNames());
            assertEquals("y", monNumber.getRegulatoryGenesPresent().toLowerCase());
            assertEquals("OECD1234", monNumber.getOecdNumber());
            assertNotNull(monNumber.getOecdNumberCommunicationDate());
            assertFalse(monNumber.isRegulatedStatus());
            assertEquals("JV123", monNumber.getJvNumber());
            assertFalse(monNumber.isLocked());
            assertEquals("TB123", monNumber.getTransformationBackground());
            assertEquals("RPL", monNumber.getRegulatoryParentalLine());

            assertEquals(1, monNumber.getProteinNames().size());
            com.monsanto.tps.lexicon.monnumber.ProteinName proteinName =
               monNumber.getProteinNames().iterator().next();
            assertEquals("1234", proteinName.getProteinNamePubkey());
            assertEquals("PROTNAME", proteinName.getProteinName());

            assertEquals(1, monNumber.getComlTraitTypes().size());
            ComlTraitType comlTraitType =
               monNumber.getComlTraitTypes().iterator().next();
            assertEquals("CTRTABBR", comlTraitType.getComlTraitTypeAbbr());
            assertEquals("CTRT DESC", comlTraitType.getComlTraitTypeDesc());

            assertEquals(1, monNumber.getMonNumberConstructs().size());
            com.monsanto.tps.lexicon.monnumber.MonNumberConstruct construct =
               monNumber.getMonNumberConstructs().iterator().next();
            assertEquals("CONNAME", construct.getConstructName());
            assertEquals("CONPV", construct.getPvCode());
         }
      }

      assertTrue(insertedMonNumberFound);
   }

   @Test 
 public void testReturnsMatchingMonNumberWithMultipleProteinDataForValidCrop() {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withCrop(CropBuilder.soybeans()).
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROTONE").
                  withProteinNamePubkey("1111")
               ).
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROTTWO").
                  withProteinNamePubkey("2222")
               ).
               createInDb();
         }
      });

      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByCrop("1115");

      assertTrue(monNumbers.length > 0);

      boolean insertedMonNumberFound = false;

      for (com.monsanto.tps.lexicon.monnumber.MonNumber monNumber : monNumbers) {
         // all returned mon numbers should be active
         assertTrue(monNumber.isActiveStatus());

         if (monNumber.getMonNumber().equals("MON_1111")) {
            insertedMonNumberFound = true;
            assertEquals("MON_1111", monNumber.getMonNumber());
            assertEquals("ZM_1111", monNumber.getEvent());
            assertEquals("SOYBEANS", monNumber.getCropName());
            assertEquals("1115", monNumber.getCropPubkey());
            assertNull(monNumber.getMaterialName());
            assertNull(monNumber.getPreviousNames());
            assertEquals("y", monNumber.getRegulatoryGenesPresent().toLowerCase());
            assertEquals("OECD1234", monNumber.getOecdNumber());
            assertNotNull(monNumber.getOecdNumberCommunicationDate());
            assertFalse(monNumber.isRegulatedStatus());
            assertEquals("JV123", monNumber.getJvNumber());
            assertFalse(monNumber.isLocked());
            assertEquals("TB123", monNumber.getTransformationBackground());
            assertEquals("RPL", monNumber.getRegulatoryParentalLine());

            assertEquals(2, monNumber.getProteinNames().size());
            for (ProteinName proteinName : monNumber.getProteinNames()) {
               assertTrue(proteinName.getProteinName().equals("PROTONE") ||
                  proteinName.getProteinName().equals("PROTTWO"));
               if (proteinName.getProteinName().equals("PROTONE")) {
                  assertEquals("1111", proteinName.getProteinNamePubkey());
               }
               else if (proteinName.getProteinName().equals("PROTTWO")) {
                  assertEquals("2222", proteinName.getProteinNamePubkey());
               }
               else {
                  fail("Invalid protein name found.");
               }
            }

            assertEquals(0, monNumber.getComlTraitTypes().size());
            assertEquals(0, monNumber.getMonNumberConstructs().size());
         }
      }

      assertTrue(insertedMonNumberFound);
   }

   @Test 
 public void testReturnsMatchingMonNumberWithMultipleComlTraitDataForValidCrop() {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withCrop(CropBuilder.soybeans()).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("TRTONE").
                  withTraitTypeDesc("TRT ONE DESC")
               ).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("TRTTWO").
                  withTraitTypeDesc("TRT TWO DESC")
               ).
               createInDb();
         }
      });

      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByCrop("1115");

      assertTrue(monNumbers.length > 0);

      boolean insertedMonNumberFound = false;

      for (com.monsanto.tps.lexicon.monnumber.MonNumber monNumber : monNumbers) {
         // all returned mon numbers should be active
         assertTrue(monNumber.isActiveStatus());

         if (monNumber.getMonNumber().equals("MON_1111")) {
            insertedMonNumberFound = true;
            assertEquals("MON_1111", monNumber.getMonNumber());
            assertEquals("ZM_1111", monNumber.getEvent());
            assertEquals("SOYBEANS", monNumber.getCropName());
            assertEquals("1115", monNumber.getCropPubkey());
            assertNull(monNumber.getMaterialName());
            assertNull(monNumber.getPreviousNames());
            assertEquals("y", monNumber.getRegulatoryGenesPresent().toLowerCase());
            assertEquals("OECD1234", monNumber.getOecdNumber());
            assertNotNull(monNumber.getOecdNumberCommunicationDate());
            assertFalse(monNumber.isRegulatedStatus());
            assertEquals("JV123", monNumber.getJvNumber());
            assertFalse(monNumber.isLocked());
            assertEquals("TB123", monNumber.getTransformationBackground());
            assertEquals("RPL", monNumber.getRegulatoryParentalLine());
            assertEquals(0, monNumber.getProteinNames().size());

            assertEquals(2, monNumber.getComlTraitTypes().size());
            for (ComlTraitType comlTraitType : monNumber.getComlTraitTypes()) {
               assertTrue(comlTraitType.getComlTraitTypeAbbr().equals("TRTONE") ||
                  comlTraitType.getComlTraitTypeAbbr().equals("TRTTWO"));
               if (comlTraitType.getComlTraitTypeAbbr().equals("TRTONE")) {
                  assertEquals("TRT ONE DESC", comlTraitType.getComlTraitTypeDesc());
               }
               else if (comlTraitType.getComlTraitTypeAbbr().equals("TRTTWO")) {
                  assertEquals("TRT TWO DESC", comlTraitType.getComlTraitTypeDesc());
               }
               else {
                  fail("Invalid coml trait type found.");
               }
            }

            assertEquals(0, monNumber.getMonNumberConstructs().size());
         }
      }

      assertTrue(insertedMonNumberFound);
   }

   @Test 
 public void testReturnsMatchingMonNumberWithMultipleConstructDataForValidCrop() {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withCrop(CropBuilder.soybeans()).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONONE").
                  withPvCode("PVONE")
               ).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONTWO").
                  withPvCode("PVTWO")
               ).
               createInDb();
         }
      });

      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByCrop("1115");

      assertTrue(monNumbers.length > 0);

      boolean insertedMonNumberFound = false;

      for (com.monsanto.tps.lexicon.monnumber.MonNumber monNumber : monNumbers) {
         // all returned mon numbers should be active
         assertTrue(monNumber.isActiveStatus());

         if (monNumber.getMonNumber().equals("MON_1111")) {
            insertedMonNumberFound = true;
            assertEquals("MON_1111", monNumber.getMonNumber());
            assertEquals("ZM_1111", monNumber.getEvent());
            assertEquals("SOYBEANS", monNumber.getCropName());
            assertEquals("1115", monNumber.getCropPubkey());
            assertNull(monNumber.getMaterialName());
            assertNull(monNumber.getPreviousNames());
            assertEquals("y", monNumber.getRegulatoryGenesPresent().toLowerCase());
            assertEquals("OECD1234", monNumber.getOecdNumber());
            assertNotNull(monNumber.getOecdNumberCommunicationDate());
            assertFalse(monNumber.isRegulatedStatus());
            assertEquals("JV123", monNumber.getJvNumber());
            assertFalse(monNumber.isLocked());
            assertEquals("TB123", monNumber.getTransformationBackground());
            assertEquals("RPL", monNumber.getRegulatoryParentalLine());
            assertEquals(0, monNumber.getProteinNames().size());
            assertEquals(0, monNumber.getComlTraitTypes().size());

            assertEquals(2, monNumber.getMonNumberConstructs().size());
            for (MonNumberConstruct monNumberConstruct : monNumber.getMonNumberConstructs()) {
               assertTrue(monNumberConstruct.getConstructName().equals("CONONE") ||
                  monNumberConstruct.getConstructName().equals("CONTWO"));
               if (monNumberConstruct.getConstructName().equals("CONONE")) {
                  assertEquals("PVONE", monNumberConstruct.getPvCode());
               }
               else if (monNumberConstruct.getConstructName().equals("CONTWO")) {
                  assertEquals("PVTWO", monNumberConstruct.getPvCode());
               }
               else {
                  fail("Invalid mon number construct found.");
               }
            }
         }
      }

      assertTrue(insertedMonNumberFound);
   }

   @Test 
 public void testReturnsMultipleMatchingMonNumberWithSameChildDataForValidCrop() {
      final ProteinNameBuilder proteinNameBuilderOne = new ProteinNameBuilder().
         withProteinName("PROTNAME1").
         withProteinNamePubkey("12341");
      final ProteinNameBuilder proteinNameBuilderTwo = new ProteinNameBuilder().
         withProteinName("PROTNAME2").
         withProteinNamePubkey("12342");
      final ComlTraitTypeBuilder comlTraitTypeBuilderOne = new ComlTraitTypeBuilder().
         withTraitTypeAbbr("CTTABBR1").
         withTraitTypeDesc("CTTDESC1");
      final ComlTraitTypeBuilder comlTraitTypeBuilderTwo = new ComlTraitTypeBuilder().
         withTraitTypeAbbr("CTTABBR2").
         withTraitTypeDesc("CTTDESC2");
      final MonNumberConstructBuilder constructBuilderOne = new MonNumberConstructBuilder().
         withConstructName("CONNAME1").
         withPvCode("CONPV1");
      final MonNumberConstructBuilder constructBuilderTwo = new MonNumberConstructBuilder().
         withConstructName("CONNAME2").
         withPvCode("CONPV2");

      MonNumber testMonNumberOne = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withOecdNumber("OECD1111").
               withCrop(CropBuilder.soybeans()).
               withProteinName(proteinNameBuilderOne).
               withProteinName(proteinNameBuilderTwo).
               withComlTraitType(comlTraitTypeBuilderOne).
               withComlTraitType(comlTraitTypeBuilderTwo).
               withMonNumberConstruct(constructBuilderOne).
               withMonNumberConstruct(constructBuilderTwo).
               createInDb();
         }
      });

      MonNumber testMonNumberTwo = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_2222").
               withEventName("ZM_2222").
               withOecdNumber("OECD2222").
               withCrop(CropBuilder.soybeans()).
               withProteinName(proteinNameBuilderOne).
               withProteinName(proteinNameBuilderTwo).
               withComlTraitType(comlTraitTypeBuilderOne).
               withComlTraitType(comlTraitTypeBuilderTwo).
               withMonNumberConstruct(constructBuilderOne).
               withMonNumberConstruct(constructBuilderTwo).
               createInDb();
         }
      });

      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByCrop("1115");

      assertTrue(monNumbers.length > 0);

      int insertedMonNumbersFound = 0;

      for (com.monsanto.tps.lexicon.monnumber.MonNumber monNumber : monNumbers) {
         // all returned mon numbers should be active
         assertTrue(monNumber.isActiveStatus());

         if (monNumber.getMonNumber().equals("MON_1111") ||
            monNumber.getMonNumber().equals("MON_2222")) {
            insertedMonNumbersFound++;

            if (monNumber.getMonNumber().equals("MON_1111")) {
               assertEquals("ZM_1111", monNumber.getEvent());
               assertEquals("OECD1111", monNumber.getOecdNumber());
            }
            else {
               assertEquals("ZM_2222", monNumber.getEvent());
               assertEquals("OECD2222", monNumber.getOecdNumber());
            }

            assertEquals("SOYBEANS", monNumber.getCropName());
            assertEquals("1115", monNumber.getCropPubkey());

            assertEquals(2, monNumber.getProteinNames().size());
            for (ProteinName proteinName : monNumber.getProteinNames()) {
               System.out.println(proteinName.getProteinName());
               assertTrue(proteinName.getProteinName().equals("PROTNAME1") ||
                  proteinName.getProteinName().equals("PROTNAME2"));
               if (proteinName.getProteinName().equals("PROTNAME1")) {
                  assertEquals("12341", proteinName.getProteinNamePubkey());
               }
               else if (proteinName.getProteinName().equals("PROTNAME2")) {
                  assertEquals("12342", proteinName.getProteinNamePubkey());
               }
               else {
                  fail("Invalid protein name found.");
               }
            }

            assertEquals(2, monNumber.getComlTraitTypes().size());
            for (ComlTraitType comlTraitType : monNumber.getComlTraitTypes()) {
               assertTrue(comlTraitType.getComlTraitTypeAbbr().equals("CTTABBR1") ||
                  comlTraitType.getComlTraitTypeAbbr().equals("CTTABBR2"));
               if (comlTraitType.getComlTraitTypeAbbr().equals("CTTABBR1")) {
                  assertEquals("CTTDESC1", comlTraitType.getComlTraitTypeDesc());
               }
               else if (comlTraitType.getComlTraitTypeAbbr().equals("CTTABBR2")) {
                  assertEquals("CTTDESC2", comlTraitType.getComlTraitTypeDesc());
               }
               else {
                  fail("Invalid coml trait type found.");
               }
            }

            assertEquals(2, monNumber.getMonNumberConstructs().size());
            for (MonNumberConstruct monNumberConstruct : monNumber.getMonNumberConstructs()) {
               assertTrue(monNumberConstruct.getConstructName().equals("CONNAME1") ||
                  monNumberConstruct.getConstructName().equals("CONNAME2"));
               if (monNumberConstruct.getConstructName().equals("CONNAME1")) {
                  assertEquals("CONPV1", monNumberConstruct.getPvCode());
               }
               else if (monNumberConstruct.getConstructName().equals("CONNAME2")) {
                  assertEquals("CONPV2", monNumberConstruct.getPvCode());
               }
               else {
                  fail("Invalid mon number construct found.");
               }
            }
         }
      }

      assertEquals(2, insertedMonNumbersFound);
   }

   @Test 
 public void testReturnsMultipleMatchingMonNumberWithDifferentChildDataForValidCrop() {
      MonNumber testMonNumberOne = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withOecdNumber("OECD1111").
               withCrop(CropBuilder.soybeans()).
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROTNAME1").
                  withProteinNamePubkey("12341")).
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROTNAME11").
                  withProteinNamePubkey("123411")).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("CTTABR1").
                  withTraitTypeDesc("CTTDESC1")).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("CTTABR11").
                  withTraitTypeDesc("CTTDESC11")).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME1").
                  withPvCode("CONPV1")).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME11").
                  withPvCode("CONPV11")).
               createInDb();
         }
      });

      MonNumber testMonNumberTwo = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_2222").
               withEventName("ZM_2222").
               withOecdNumber("OECD2222").
               withCrop(CropBuilder.soybeans()).
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROTNAME2").
                  withProteinNamePubkey("12342")).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("CTTABR2").
                  withTraitTypeDesc("CTTDESC2")).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME2").
                  withPvCode("CONPV2")).
               createInDb();
         }
      });

      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByCrop("1115");

      assertTrue(monNumbers.length > 0);

      int insertedMonNumbersFound = 0;

      for (com.monsanto.tps.lexicon.monnumber.MonNumber monNumber : monNumbers) {
         // all returned mon numbers should be active
         assertTrue(monNumber.isActiveStatus());

         if (monNumber.getMonNumber().equals("MON_1111")) {
            insertedMonNumbersFound++;
            assertEquals("ZM_1111", monNumber.getEvent());
            assertEquals("OECD1111", monNumber.getOecdNumber());
            assertEquals("SOYBEANS", monNumber.getCropName());
            assertEquals("1115", monNumber.getCropPubkey());

            assertEquals(2, monNumber.getProteinNames().size());
            for (ProteinName proteinName : monNumber.getProteinNames()) {
               System.out.println(proteinName.getProteinName());
               assertTrue(proteinName.getProteinName().equals("PROTNAME1") ||
                  proteinName.getProteinName().equals("PROTNAME11"));
               if (proteinName.getProteinName().equals("PROTNAME1")) {
                  assertEquals("12341", proteinName.getProteinNamePubkey());
               }
               else if (proteinName.getProteinName().equals("PROTNAME11")) {
                  assertEquals("123411", proteinName.getProteinNamePubkey());
               }
               else {
                  fail("Invalid protein name found.");
               }
            }

            assertEquals(2, monNumber.getComlTraitTypes().size());
            for (ComlTraitType comlTraitType : monNumber.getComlTraitTypes()) {
               assertTrue(comlTraitType.getComlTraitTypeAbbr().equals("CTTABR1") ||
                  comlTraitType.getComlTraitTypeAbbr().equals("CTTABR11"));
               if (comlTraitType.getComlTraitTypeAbbr().equals("CTTABR1")) {
                  assertEquals("CTTDESC1", comlTraitType.getComlTraitTypeDesc());
               }
               else if (comlTraitType.getComlTraitTypeAbbr().equals("CTTABR11")) {
                  assertEquals("CTTDESC11", comlTraitType.getComlTraitTypeDesc());
               }
               else {
                  fail("Invalid coml trait type found.");
               }
            }

            assertEquals(2, monNumber.getMonNumberConstructs().size());
            for (MonNumberConstruct monNumberConstruct : monNumber.getMonNumberConstructs()) {
               assertTrue(monNumberConstruct.getConstructName().equals("CONNAME1") ||
                  monNumberConstruct.getConstructName().equals("CONNAME11"));
               if (monNumberConstruct.getConstructName().equals("CONNAME1")) {
                  assertEquals("CONPV1", monNumberConstruct.getPvCode());
               }
               else if (monNumberConstruct.getConstructName().equals("CONNAME11")) {
                  assertEquals("CONPV11", monNumberConstruct.getPvCode());
               }
               else {
                  fail("Invalid mon number construct found.");
               }
            }
         }
         else if (monNumber.getMonNumber().equals("MON_2222")) {
            insertedMonNumbersFound++;
            assertEquals("ZM_2222", monNumber.getEvent());
            assertEquals("OECD2222", monNumber.getOecdNumber());
            assertEquals("SOYBEANS", monNumber.getCropName());
            assertEquals("1115", monNumber.getCropPubkey());

            assertEquals(1, monNumber.getProteinNames().size());
            ProteinName proteinName = monNumber.getProteinNames().iterator().next();
            assertEquals("PROTNAME2", proteinName.getProteinName());
            assertEquals("12342", proteinName.getProteinNamePubkey());

            assertEquals(1, monNumber.getComlTraitTypes().size());
            ComlTraitType comlTraitType = monNumber.getComlTraitTypes().iterator().next();
            assertEquals("CTTABR2", comlTraitType.getComlTraitTypeAbbr());
            assertEquals("CTTDESC2", comlTraitType.getComlTraitTypeDesc());

            assertEquals(1, monNumber.getMonNumberConstructs().size());
            MonNumberConstruct construct = monNumber.getMonNumberConstructs().iterator().next();
            assertEquals("CONNAME2", construct.getConstructName());
            assertEquals("CONPV2", construct.getPvCode());

         }
      }

      assertEquals(2, insertedMonNumbersFound);
   }

   @Test 
 public void testReturnsNoDataForNonActiveMonNumberCrop() {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withCrop(CropBuilder.soybeans()).
               withActiveStatus(false).
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROTNAME").
                  withProteinNamePubkey("1234")
               ).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("CTRTABBR").
                  withTraitTypeDesc("CTRT DESC")
               ).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME").
                  withPvCode("CONPV")
               ).
               createInDb();
         }
      });

      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByCrop("1115");

      assertTrue(monNumbers.length > 0);

      boolean insertedMonNumberFound = false;
      for (com.monsanto.tps.lexicon.monnumber.MonNumber monNumber : monNumbers) {
         // all returned mon numbers should be active
         assertTrue(monNumber.isActiveStatus());

         if (monNumber.getMonNumber().equals("MON_1111")) {
            insertedMonNumberFound = true;
         }
      }

      assertFalse(insertedMonNumberFound);
   }

   @Test 
 public void testReturnsNoDataForInvalidCrop() {
      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByCrop("InvalidCropPubkey");

      assertEquals(0, monNumbers.length);
   }

   @Test 
 public void testReturnMonNumberWithSingleConstruct() {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROTNAME").
                  withProteinNamePubkey("1234")
               ).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("CTRTABBR").
                  withTraitTypeDesc("CTRT DESC")
               ).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME").
                  withPvCode("CONPV")
               ).
               createInDb();
         }
      });

      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByConstruct(new String[]{"CONNAME"});

      assertTrue(monNumbers.length > 0);

      int insertedMonNumberFound = 0;
      for (com.monsanto.tps.lexicon.monnumber.MonNumber monNumber : monNumbers) {
         // all returned mon numbers should be active
         assertTrue(monNumber.isActiveStatus());

         if (monNumber.getMonNumber().equals("MON_1111")) {
            insertedMonNumberFound++;

            assertEquals("MON_1111", monNumber.getMonNumber());
            assertEquals("ZM_1111", monNumber.getEvent());
            assertEquals("CORN", monNumber.getCropName());
            assertEquals("1015", monNumber.getCropPubkey());
            assertNull(monNumber.getMaterialName());
            assertNull(monNumber.getPreviousNames());
            assertEquals("y", monNumber.getRegulatoryGenesPresent().toLowerCase());
            assertEquals("OECD1234", monNumber.getOecdNumber());
            assertNotNull(monNumber.getOecdNumberCommunicationDate());
            assertFalse(monNumber.isRegulatedStatus());
            assertEquals("JV123", monNumber.getJvNumber());
            assertFalse(monNumber.isLocked());
            assertEquals("TB123", monNumber.getTransformationBackground());
            assertEquals("RPL", monNumber.getRegulatoryParentalLine());

            assertEquals(1, monNumber.getProteinNames().size());
            com.monsanto.tps.lexicon.monnumber.ProteinName proteinName =
               monNumber.getProteinNames().iterator().next();
            assertEquals("1234", proteinName.getProteinNamePubkey());
            assertEquals("PROTNAME", proteinName.getProteinName());

            assertEquals(1, monNumber.getComlTraitTypes().size());
            ComlTraitType comlTraitType =
               monNumber.getComlTraitTypes().iterator().next();
            assertEquals("CTRTABBR", comlTraitType.getComlTraitTypeAbbr());
            assertEquals("CTRT DESC", comlTraitType.getComlTraitTypeDesc());

            assertEquals(1, monNumber.getMonNumberConstructs().size());
            com.monsanto.tps.lexicon.monnumber.MonNumberConstruct construct =
               monNumber.getMonNumberConstructs().iterator().next();
            assertEquals("CONNAME", construct.getConstructName());
            assertEquals("CONPV", construct.getPvCode());
         }
      }

      assertEquals(1, insertedMonNumberFound);
   }

   @Test 
 public void testReturnMonNumberWithMultipleConstructEntries() {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROTNAME").
                  withProteinNamePubkey("1234")
               ).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("CTRTABBR").
                  withTraitTypeDesc("CTRT DESC")
               ).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME1").
                  withPvCode("CONPV1")
               ).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME2").
                  withPvCode("CONPV2")
               ).
               createInDb();
         }
      });

      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByConstruct(new String[]{"CONNAME1", "CONNAME2"});

      assertTrue(monNumbers.length > 0);

      int insertedMonNumberFound = 0;
      for (com.monsanto.tps.lexicon.monnumber.MonNumber monNumber : monNumbers) {
         // all returned mon numbers should be active
         assertTrue(monNumber.isActiveStatus());

         if (monNumber.getMonNumber().equals("MON_1111")) {
            insertedMonNumberFound++;

            assertEquals("MON_1111", monNumber.getMonNumber());
            assertEquals("ZM_1111", monNumber.getEvent());
            assertEquals("CORN", monNumber.getCropName());
            assertEquals("1015", monNumber.getCropPubkey());
            assertNull(monNumber.getMaterialName());
            assertNull(monNumber.getPreviousNames());
            assertEquals("y", monNumber.getRegulatoryGenesPresent().toLowerCase());
            assertEquals("OECD1234", monNumber.getOecdNumber());
            assertNotNull(monNumber.getOecdNumberCommunicationDate());
            assertFalse(monNumber.isRegulatedStatus());
            assertEquals("JV123", monNumber.getJvNumber());
            assertFalse(monNumber.isLocked());
            assertEquals("TB123", monNumber.getTransformationBackground());
            assertEquals("RPL", monNumber.getRegulatoryParentalLine());

            assertEquals(1, monNumber.getProteinNames().size());
            com.monsanto.tps.lexicon.monnumber.ProteinName proteinName =
               monNumber.getProteinNames().iterator().next();
            assertEquals("1234", proteinName.getProteinNamePubkey());
            assertEquals("PROTNAME", proteinName.getProteinName());

            assertEquals(1, monNumber.getComlTraitTypes().size());
            ComlTraitType comlTraitType =
               monNumber.getComlTraitTypes().iterator().next();
            assertEquals("CTRTABBR", comlTraitType.getComlTraitTypeAbbr());
            assertEquals("CTRT DESC", comlTraitType.getComlTraitTypeDesc());

            assertEquals(2, monNumber.getMonNumberConstructs().size());
            for (MonNumberConstruct construct : monNumber.getMonNumberConstructs()) {
               if (construct.getConstructName().equals("CONNAME1")) {
                  assertEquals("CONPV1", construct.getPvCode());
               }
               else if (construct.getConstructName().equals("CONNAME2")) {
                  assertEquals("CONPV2", construct.getPvCode());
               }
               else {
                  fail("Invalid construct found.");
               }
            }
         }
      }

      assertEquals(1, insertedMonNumberFound);
   }

   @Test 
 public void testReturnMonNumberWithMultipleCommaSeparatedConstructsRequestedValueFoundAtFront() {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROTNAME").
                  withProteinNamePubkey("1234")
               ).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("CTRTABBR").
                  withTraitTypeDesc("CTRT DESC")
               ).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("NAME1 , NAME2, NAME3").
                  withPvCode("CONPV")
               ).
               createInDb();
         }
      });

      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByConstruct(new String[]{"NAME1"});

      assertTrue(monNumbers.length > 0);

      int insertedMonNumberFound = 0;
      for (com.monsanto.tps.lexicon.monnumber.MonNumber monNumber : monNumbers) {
         // all returned mon numbers should be active
         assertTrue(monNumber.isActiveStatus());

         if (monNumber.getMonNumber().equals("MON_1111")) {
            insertedMonNumberFound++;

            assertEquals("MON_1111", monNumber.getMonNumber());
            assertEquals("ZM_1111", monNumber.getEvent());
            assertEquals("CORN", monNumber.getCropName());
            assertEquals("1015", monNumber.getCropPubkey());
            assertNull(monNumber.getMaterialName());
            assertNull(monNumber.getPreviousNames());
            assertEquals("y", monNumber.getRegulatoryGenesPresent().toLowerCase());
            assertEquals("OECD1234", monNumber.getOecdNumber());
            assertNotNull(monNumber.getOecdNumberCommunicationDate());
            assertFalse(monNumber.isRegulatedStatus());
            assertEquals("JV123", monNumber.getJvNumber());
            assertFalse(monNumber.isLocked());
            assertEquals("TB123", monNumber.getTransformationBackground());
            assertEquals("RPL", monNumber.getRegulatoryParentalLine());

            assertEquals(1, monNumber.getProteinNames().size());
            com.monsanto.tps.lexicon.monnumber.ProteinName proteinName =
               monNumber.getProteinNames().iterator().next();
            assertEquals("1234", proteinName.getProteinNamePubkey());
            assertEquals("PROTNAME", proteinName.getProteinName());

            assertEquals(1, monNumber.getComlTraitTypes().size());
            ComlTraitType comlTraitType =
               monNumber.getComlTraitTypes().iterator().next();
            assertEquals("CTRTABBR", comlTraitType.getComlTraitTypeAbbr());
            assertEquals("CTRT DESC", comlTraitType.getComlTraitTypeDesc());

            assertEquals(1, monNumber.getMonNumberConstructs().size());
            com.monsanto.tps.lexicon.monnumber.MonNumberConstruct construct =
               monNumber.getMonNumberConstructs().iterator().next();
            assertEquals("NAME1 , NAME2, NAME3", construct.getConstructName());
            assertEquals("CONPV", construct.getPvCode());
         }
      }

      assertEquals(1, insertedMonNumberFound);
   }

   @Test 
 public void testReturnMonNumberWithMultipleCommaSeparatedConstructsRequestedValueFoundInMiddle() {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROTNAME").
                  withProteinNamePubkey("1234")
               ).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("CTRTABBR").
                  withTraitTypeDesc("CTRT DESC")
               ).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("NAME1,NAME2,NAME3").
                  withPvCode("CONPV")
               ).
               createInDb();
         }
      });

      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByConstruct(new String[]{"NAME2"});

      assertTrue(monNumbers.length > 0);

      int insertedMonNumberFound = 0;
      for (com.monsanto.tps.lexicon.monnumber.MonNumber monNumber : monNumbers) {
         // all returned mon numbers should be active
         assertTrue(monNumber.isActiveStatus());

         if (monNumber.getMonNumber().equals("MON_1111")) {
            insertedMonNumberFound++;

            assertEquals("MON_1111", monNumber.getMonNumber());
            assertEquals("ZM_1111", monNumber.getEvent());
            assertEquals("CORN", monNumber.getCropName());
            assertEquals("1015", monNumber.getCropPubkey());
            assertNull(monNumber.getMaterialName());
            assertNull(monNumber.getPreviousNames());
            assertEquals("y", monNumber.getRegulatoryGenesPresent().toLowerCase());
            assertEquals("OECD1234", monNumber.getOecdNumber());
            assertNotNull(monNumber.getOecdNumberCommunicationDate());
            assertFalse(monNumber.isRegulatedStatus());
            assertEquals("JV123", monNumber.getJvNumber());
            assertFalse(monNumber.isLocked());
            assertEquals("TB123", monNumber.getTransformationBackground());
            assertEquals("RPL", monNumber.getRegulatoryParentalLine());

            assertEquals(1, monNumber.getProteinNames().size());
            com.monsanto.tps.lexicon.monnumber.ProteinName proteinName =
               monNumber.getProteinNames().iterator().next();
            assertEquals("1234", proteinName.getProteinNamePubkey());
            assertEquals("PROTNAME", proteinName.getProteinName());

            assertEquals(1, monNumber.getComlTraitTypes().size());
            ComlTraitType comlTraitType =
               monNumber.getComlTraitTypes().iterator().next();
            assertEquals("CTRTABBR", comlTraitType.getComlTraitTypeAbbr());
            assertEquals("CTRT DESC", comlTraitType.getComlTraitTypeDesc());

            assertEquals(1, monNumber.getMonNumberConstructs().size());
            com.monsanto.tps.lexicon.monnumber.MonNumberConstruct construct =
               monNumber.getMonNumberConstructs().iterator().next();
            assertEquals("NAME1,NAME2,NAME3", construct.getConstructName());
            assertEquals("CONPV", construct.getPvCode());
         }
      }

      assertEquals(1, insertedMonNumberFound);
   }

   @Test 
 public void testReturnMonNumberWithMultipleCommaSeparatedConstructsRequestedValueFoundAtBack() {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROTNAME").
                  withProteinNamePubkey("1234")
               ).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("CTRTABBR").
                  withTraitTypeDesc("CTRT DESC")
               ).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("NAME1,NAME2,NAME3").
                  withPvCode("CONPV")
               ).
               createInDb();
         }
      });

      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByConstruct(new String[]{"NAME3"});

      assertTrue(monNumbers.length > 0);

      int insertedMonNumberFound = 0;
      for (com.monsanto.tps.lexicon.monnumber.MonNumber monNumber : monNumbers) {
         // all returned mon numbers should be active
         assertTrue(monNumber.isActiveStatus());

         if (monNumber.getMonNumber().equals("MON_1111")) {
            insertedMonNumberFound++;

            assertEquals("MON_1111", monNumber.getMonNumber());
            assertEquals("ZM_1111", monNumber.getEvent());
            assertEquals("CORN", monNumber.getCropName());
            assertEquals("1015", monNumber.getCropPubkey());
            assertNull(monNumber.getMaterialName());
            assertNull(monNumber.getPreviousNames());
            assertEquals("y", monNumber.getRegulatoryGenesPresent().toLowerCase());
            assertEquals("OECD1234", monNumber.getOecdNumber());
            assertNotNull(monNumber.getOecdNumberCommunicationDate());
            assertFalse(monNumber.isRegulatedStatus());
            assertEquals("JV123", monNumber.getJvNumber());
            assertFalse(monNumber.isLocked());
            assertEquals("TB123", monNumber.getTransformationBackground());
            assertEquals("RPL", monNumber.getRegulatoryParentalLine());

            assertEquals(1, monNumber.getProteinNames().size());
            com.monsanto.tps.lexicon.monnumber.ProteinName proteinName =
               monNumber.getProteinNames().iterator().next();
            assertEquals("1234", proteinName.getProteinNamePubkey());
            assertEquals("PROTNAME", proteinName.getProteinName());

            assertEquals(1, monNumber.getComlTraitTypes().size());
            ComlTraitType comlTraitType =
               monNumber.getComlTraitTypes().iterator().next();
            assertEquals("CTRTABBR", comlTraitType.getComlTraitTypeAbbr());
            assertEquals("CTRT DESC", comlTraitType.getComlTraitTypeDesc());

            assertEquals(1, monNumber.getMonNumberConstructs().size());
            com.monsanto.tps.lexicon.monnumber.MonNumberConstruct construct =
               monNumber.getMonNumberConstructs().iterator().next();
            assertEquals("NAME1,NAME2,NAME3", construct.getConstructName());
            assertEquals("CONPV", construct.getPvCode());
         }
      }

      assertEquals(1, insertedMonNumberFound);
   }

   @Test 
 public void testReturnMonNumberWithMultipleAndCommaSeparatedConstructEntries() {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROTNAME").
                  withProteinNamePubkey("1234")
               ).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("CTRTABBR").
                  withTraitTypeDesc("CTRT DESC")
               ).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME1,CONNAME11").
                  withPvCode("CONPV1")
               ).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME2").
                  withPvCode("CONPV2")
               ).
               createInDb();
         }
      });

      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByConstruct(new String[]{"CONNAME1", "CONNAME11", "CONNAME2"});

      assertTrue(monNumbers.length > 0);

      int insertedMonNumberFound = 0;
      for (com.monsanto.tps.lexicon.monnumber.MonNumber monNumber : monNumbers) {
         // all returned mon numbers should be active
         assertTrue(monNumber.isActiveStatus());

         if (monNumber.getMonNumber().equals("MON_1111")) {
            insertedMonNumberFound++;

            assertEquals("MON_1111", monNumber.getMonNumber());
            assertEquals("ZM_1111", monNumber.getEvent());
            assertEquals("CORN", monNumber.getCropName());
            assertEquals("1015", monNumber.getCropPubkey());
            assertNull(monNumber.getMaterialName());
            assertNull(monNumber.getPreviousNames());
            assertEquals("y", monNumber.getRegulatoryGenesPresent().toLowerCase());
            assertEquals("OECD1234", monNumber.getOecdNumber());
            assertNotNull(monNumber.getOecdNumberCommunicationDate());
            assertFalse(monNumber.isRegulatedStatus());
            assertEquals("JV123", monNumber.getJvNumber());
            assertFalse(monNumber.isLocked());
            assertEquals("TB123", monNumber.getTransformationBackground());
            assertEquals("RPL", monNumber.getRegulatoryParentalLine());

            assertEquals(1, monNumber.getProteinNames().size());
            com.monsanto.tps.lexicon.monnumber.ProteinName proteinName =
               monNumber.getProteinNames().iterator().next();
            assertEquals("1234", proteinName.getProteinNamePubkey());
            assertEquals("PROTNAME", proteinName.getProteinName());

            assertEquals(1, monNumber.getComlTraitTypes().size());
            ComlTraitType comlTraitType =
               monNumber.getComlTraitTypes().iterator().next();
            assertEquals("CTRTABBR", comlTraitType.getComlTraitTypeAbbr());
            assertEquals("CTRT DESC", comlTraitType.getComlTraitTypeDesc());

            assertEquals(2, monNumber.getMonNumberConstructs().size());
            for (MonNumberConstruct construct : monNumber.getMonNumberConstructs()) {
               if (construct.getConstructName().equals("CONNAME1,CONNAME11")) {
                  assertEquals("CONPV1", construct.getPvCode());
               }
               else if (construct.getConstructName().equals("CONNAME2")) {
                  assertEquals("CONPV2", construct.getPvCode());
               }
               else {
                  fail("Invalid construct found.");
               }
            }
         }
      }

      assertEquals(1, insertedMonNumberFound);
   }

   @Test 
 public void testReturnMonNumberWithMoreConstructsThanInRequest() {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROTNAME").
                  withProteinNamePubkey("1234")
               ).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("CTRTABBR").
                  withTraitTypeDesc("CTRT DESC")
               ).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME1").
                  withPvCode("CONPV1")
               ).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME2,CONNAME3").
                  withPvCode("CONPV2")
               ).
               createInDb();
         }
      });

      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByConstruct(new String[]{"CONNAME1", "CONNAME2"});

      assertTrue(monNumbers.length > 0);

      int insertedMonNumberFound = 0;
      for (com.monsanto.tps.lexicon.monnumber.MonNumber monNumber : monNumbers) {
         // all returned mon numbers should be active
         assertTrue(monNumber.isActiveStatus());

         if (monNumber.getMonNumber().equals("MON_1111")) {
            insertedMonNumberFound++;

            assertEquals("MON_1111", monNumber.getMonNumber());
            assertEquals("ZM_1111", monNumber.getEvent());
            assertEquals("CORN", monNumber.getCropName());
            assertEquals("1015", monNumber.getCropPubkey());
            assertNull(monNumber.getMaterialName());
            assertNull(monNumber.getPreviousNames());
            assertEquals("y", monNumber.getRegulatoryGenesPresent().toLowerCase());
            assertEquals("OECD1234", monNumber.getOecdNumber());
            assertNotNull(monNumber.getOecdNumberCommunicationDate());
            assertFalse(monNumber.isRegulatedStatus());
            assertEquals("JV123", monNumber.getJvNumber());
            assertFalse(monNumber.isLocked());
            assertEquals("TB123", monNumber.getTransformationBackground());
            assertEquals("RPL", monNumber.getRegulatoryParentalLine());

            assertEquals(1, monNumber.getProteinNames().size());
            com.monsanto.tps.lexicon.monnumber.ProteinName proteinName =
               monNumber.getProteinNames().iterator().next();
            assertEquals("1234", proteinName.getProteinNamePubkey());
            assertEquals("PROTNAME", proteinName.getProteinName());

            assertEquals(1, monNumber.getComlTraitTypes().size());
            ComlTraitType comlTraitType =
               monNumber.getComlTraitTypes().iterator().next();
            assertEquals("CTRTABBR", comlTraitType.getComlTraitTypeAbbr());
            assertEquals("CTRT DESC", comlTraitType.getComlTraitTypeDesc());

            assertEquals(2, monNumber.getMonNumberConstructs().size());
            for (MonNumberConstruct construct : monNumber.getMonNumberConstructs()) {
               if (construct.getConstructName().equals("CONNAME1")) {
                  assertEquals("CONPV1", construct.getPvCode());
               }
               else if (construct.getConstructName().equals("CONNAME2,CONNAME3")) {
                  assertEquals("CONPV2", construct.getPvCode());
               }
               else {
                  fail("Invalid construct found.");
               }
            }
         }
      }

      assertEquals(1, insertedMonNumberFound);
   }

   @Test 
 public void testReturnMonNumberWithFewerConstructsThanInRequest() {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROTNAME").
                  withProteinNamePubkey("1234")
               ).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("CTRTABBR").
                  withTraitTypeDesc("CTRT DESC")
               ).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME1").
                  withPvCode("CONPV1")
               ).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME2,CONNAME3").
                  withPvCode("CONPV2")
               ).
               createInDb();
         }
      });

      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByConstruct(new String[]{"CONNAME1", "CONNAME2", "CONNAME3", "CONNAME4"});

      assertTrue(monNumbers.length > 0);

      int insertedMonNumberFound = 0;
      for (com.monsanto.tps.lexicon.monnumber.MonNumber monNumber : monNumbers) {
         // all returned mon numbers should be active
         assertTrue(monNumber.isActiveStatus());

         if (monNumber.getMonNumber().equals("MON_1111")) {
            insertedMonNumberFound++;

            assertEquals("MON_1111", monNumber.getMonNumber());
            assertEquals("ZM_1111", monNumber.getEvent());
            assertEquals("CORN", monNumber.getCropName());
            assertEquals("1015", monNumber.getCropPubkey());
            assertNull(monNumber.getMaterialName());
            assertNull(monNumber.getPreviousNames());
            assertEquals("y", monNumber.getRegulatoryGenesPresent().toLowerCase());
            assertEquals("OECD1234", monNumber.getOecdNumber());
            assertNotNull(monNumber.getOecdNumberCommunicationDate());
            assertFalse(monNumber.isRegulatedStatus());
            assertEquals("JV123", monNumber.getJvNumber());
            assertFalse(monNumber.isLocked());
            assertEquals("TB123", monNumber.getTransformationBackground());
            assertEquals("RPL", monNumber.getRegulatoryParentalLine());

            assertEquals(1, monNumber.getProteinNames().size());
            com.monsanto.tps.lexicon.monnumber.ProteinName proteinName =
               monNumber.getProteinNames().iterator().next();
            assertEquals("1234", proteinName.getProteinNamePubkey());
            assertEquals("PROTNAME", proteinName.getProteinName());

            assertEquals(1, monNumber.getComlTraitTypes().size());
            ComlTraitType comlTraitType =
               monNumber.getComlTraitTypes().iterator().next();
            assertEquals("CTRTABBR", comlTraitType.getComlTraitTypeAbbr());
            assertEquals("CTRT DESC", comlTraitType.getComlTraitTypeDesc());

            assertEquals(2, monNumber.getMonNumberConstructs().size());
            for (MonNumberConstruct construct : monNumber.getMonNumberConstructs()) {
               if (construct.getConstructName().equals("CONNAME1")) {
                  assertEquals("CONPV1", construct.getPvCode());
               }
               else if (construct.getConstructName().equals("CONNAME2,CONNAME3")) {
                  assertEquals("CONPV2", construct.getPvCode());
               }
               else {
                  fail("Invalid construct found.");
               }
            }
         }
      }

      assertEquals(1, insertedMonNumberFound);
   }

   @Test 
 public void testReturnMultipleMonNumbersWithSameConstruct() {
      final ProteinNameBuilder proteinNameBuilder = new ProteinNameBuilder().
         withProteinName("PROTNAME").
         withProteinNamePubkey("1234");
      final ComlTraitTypeBuilder comlTraitTypeBuilder = new ComlTraitTypeBuilder().
         withTraitTypeAbbr("CTRTABBR").
         withTraitTypeDesc("CTRT DESC");

      MonNumber testMonNumberOne = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withOecdNumber("OECD1111").
               withProteinName(proteinNameBuilder).
               withComlTraitType(comlTraitTypeBuilder).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME1,CONNAME2").
                  withPvCode("CONPV")
               ).
               createInDb();
         }
      });

      MonNumber testMonNumberTwo = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_2222").
               withEventName("ZM_2222").
               withOecdNumber("OECD2222").
               withProteinName(proteinNameBuilder).
               withComlTraitType(comlTraitTypeBuilder).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME1,CONNAME2").
                  withPvCode("CONPV")
               ).
               createInDb();
         }
      });

      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByConstruct(new String[]{"CONNAME1", "CONNAME2"});

      assertTrue(monNumbers.length > 0);

      int insertedMonNumberFound = 0;
      for (com.monsanto.tps.lexicon.monnumber.MonNumber monNumber : monNumbers) {
         // all returned mon numbers should be active
         assertTrue(monNumber.isActiveStatus());

         if (monNumber.getMonNumber().equals("MON_1111") ||
            monNumber.getMonNumber().equals("MON_2222")) {
            insertedMonNumberFound++;

            if (monNumber.getMonNumber().equals("MON_1111")) {
               assertEquals("ZM_1111", monNumber.getEvent());
               assertEquals("OECD1111", monNumber.getOecdNumber());
            }
            else {
               assertEquals("ZM_2222", monNumber.getEvent());
               assertEquals("OECD2222", monNumber.getOecdNumber());
            }

            assertEquals("CORN", monNumber.getCropName());
            assertEquals("1015", monNumber.getCropPubkey());
            assertNull(monNumber.getMaterialName());
            assertNull(monNumber.getPreviousNames());
            assertEquals("y", monNumber.getRegulatoryGenesPresent().toLowerCase());
            assertNotNull(monNumber.getOecdNumberCommunicationDate());
            assertFalse(monNumber.isRegulatedStatus());
            assertEquals("JV123", monNumber.getJvNumber());
            assertFalse(monNumber.isLocked());
            assertEquals("TB123", monNumber.getTransformationBackground());
            assertEquals("RPL", monNumber.getRegulatoryParentalLine());

            assertEquals(1, monNumber.getProteinNames().size());
            com.monsanto.tps.lexicon.monnumber.ProteinName proteinName =
               monNumber.getProteinNames().iterator().next();
            assertEquals("1234", proteinName.getProteinNamePubkey());
            assertEquals("PROTNAME", proteinName.getProteinName());

            assertEquals(1, monNumber.getComlTraitTypes().size());
            ComlTraitType comlTraitType =
               monNumber.getComlTraitTypes().iterator().next();
            assertEquals("CTRTABBR", comlTraitType.getComlTraitTypeAbbr());
            assertEquals("CTRT DESC", comlTraitType.getComlTraitTypeDesc());

            assertEquals(1, monNumber.getMonNumberConstructs().size());
            com.monsanto.tps.lexicon.monnumber.MonNumberConstruct construct =
               monNumber.getMonNumberConstructs().iterator().next();
            assertEquals("CONNAME1,CONNAME2", construct.getConstructName());
            assertEquals("CONPV", construct.getPvCode());
         }
      }

      assertEquals(2, insertedMonNumberFound);
   }

   @Test 
 public void testReturnMultipleMonNumbersWithDifferentConstructs() {
      final ProteinNameBuilder proteinNameBuilder = new ProteinNameBuilder().
         withProteinName("PROTNAME").
         withProteinNamePubkey("1234");
      final ComlTraitTypeBuilder comlTraitTypeBuilder = new ComlTraitTypeBuilder().
         withTraitTypeAbbr("CTRTABBR").
         withTraitTypeDesc("CTRT DESC");

      MonNumber testMonNumberOne = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withOecdNumber("OECD1111").
               withProteinName(proteinNameBuilder).
               withComlTraitType(comlTraitTypeBuilder).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME1").
                  withPvCode("CONPV")
               ).
               createInDb();
         }
      });

      MonNumber testMonNumberTwo = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_2222").
               withEventName("ZM_2222").
               withOecdNumber("OECD2222").
               withProteinName(proteinNameBuilder).
               withComlTraitType(comlTraitTypeBuilder).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME3,CONNAME2").
                  withPvCode("CONPV1")
               ).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME4").
                  withPvCode("CONPV2")
               ).
               createInDb();
         }
      });

      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByConstruct(new String[]{"CONNAME1", "CONNAME2"});

      assertTrue(monNumbers.length > 0);

      int insertedMonNumberFound = 0;
      for (com.monsanto.tps.lexicon.monnumber.MonNumber monNumber : monNumbers) {
         // all returned mon numbers should be active
         assertTrue(monNumber.isActiveStatus());

         if (monNumber.getMonNumber().equals("MON_1111") ||
            monNumber.getMonNumber().equals("MON_2222")) {
            insertedMonNumberFound++;

            if (monNumber.getMonNumber().equals("MON_1111")) {
               assertEquals("ZM_1111", monNumber.getEvent());
               assertEquals("OECD1111", monNumber.getOecdNumber());
               assertEquals(1, monNumber.getMonNumberConstructs().size());
               com.monsanto.tps.lexicon.monnumber.MonNumberConstruct construct =
                  monNumber.getMonNumberConstructs().iterator().next();
               assertEquals("CONNAME1", construct.getConstructName());
               assertEquals("CONPV", construct.getPvCode());
            }
            else {
               assertEquals("ZM_2222", monNumber.getEvent());
               assertEquals("OECD2222", monNumber.getOecdNumber());
               assertEquals(2, monNumber.getMonNumberConstructs().size());
               for (MonNumberConstruct construct : monNumber.getMonNumberConstructs()) {
                  if (construct.getConstructName().equals("CONNAME3,CONNAME2")) {
                     assertEquals("CONPV1", construct.getPvCode());
                  }
                  else if (construct.getConstructName().equals("CONNAME4")) {
                     assertEquals("CONPV2", construct.getPvCode());
                  }
                  else {
                     fail("Invalid construct found.");
                  }
               }
            }

            assertEquals("CORN", monNumber.getCropName());
            assertEquals("1015", monNumber.getCropPubkey());
            assertNull(monNumber.getMaterialName());
            assertNull(monNumber.getPreviousNames());
            assertEquals("y", monNumber.getRegulatoryGenesPresent().toLowerCase());
            assertNotNull(monNumber.getOecdNumberCommunicationDate());
            assertFalse(monNumber.isRegulatedStatus());
            assertEquals("JV123", monNumber.getJvNumber());
            assertFalse(monNumber.isLocked());
            assertEquals("TB123", monNumber.getTransformationBackground());
            assertEquals("RPL", monNumber.getRegulatoryParentalLine());

            assertEquals(1, monNumber.getProteinNames().size());
            com.monsanto.tps.lexicon.monnumber.ProteinName proteinName =
               monNumber.getProteinNames().iterator().next();
            assertEquals("1234", proteinName.getProteinNamePubkey());
            assertEquals("PROTNAME", proteinName.getProteinName());

            assertEquals(1, monNumber.getComlTraitTypes().size());
            ComlTraitType comlTraitType =
               monNumber.getComlTraitTypes().iterator().next();
            assertEquals("CTRTABBR", comlTraitType.getComlTraitTypeAbbr());
            assertEquals("CTRT DESC", comlTraitType.getComlTraitTypeDesc());
         }
      }

      assertEquals(2, insertedMonNumberFound);
   }

   @Test 
 public void testReturnNoDataForPartialConstructMatch() {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROTNAME").
                  withProteinNamePubkey("1234")
               ).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("CTRTABBR").
                  withTraitTypeDesc("CTRT DESC")
               ).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME").
                  withPvCode("CONPV")
               ).
               createInDb();
         }
      });

      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByConstruct(new String[]{"NAME"});

      boolean insertedMonNumberFound = false;
      for (com.monsanto.tps.lexicon.monnumber.MonNumber monNumber : monNumbers) {
         // all returned mon numbers should be active
         assertTrue(monNumber.isActiveStatus());

         if (monNumber.getMonNumber().equals("MON_1111")) {
            insertedMonNumberFound = true;
         }
      }

      assertFalse(insertedMonNumberFound);
   }

   @Test 
 public void testReturnNoDataForNonActiveMonNumberConstruct() {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withActiveStatus(false).
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROTNAME").
                  withProteinNamePubkey("1234")
               ).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("CTRTABBR").
                  withTraitTypeDesc("CTRT DESC")
               ).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME").
                  withPvCode("CONPV")
               ).
               createInDb();
         }
      });

      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByConstruct(new String[]{"CONNAME"});

      boolean insertedMonNumberFound = false;
      for (com.monsanto.tps.lexicon.monnumber.MonNumber monNumber : monNumbers) {
         // all returned mon numbers should be active
         assertTrue(monNumber.isActiveStatus());

         if (monNumber.getMonNumber().equals("MON_1111")) {
            insertedMonNumberFound = true;
         }
      }

      assertFalse(insertedMonNumberFound);
   }

   @Test 
 public void testReturnNoDataForInvalidConstruct() {
      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByConstruct(new String[]{"InvalidConstruct"});

      assertEquals(0, monNumbers.length);
   }

   @Test 
 public void testReturnMonNumberWithSinglePvCode() {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROTNAME").
                  withProteinNamePubkey("1234")
               ).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("CTRTABBR").
                  withTraitTypeDesc("CTRT DESC")
               ).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME").
                  withPvCode("CONPV")
               ).
               createInDb();
         }
      });

      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByPvCode(new String[]{"CONPV"});

      assertTrue(monNumbers.length > 0);

      int insertedMonNumberFound = 0;
      for (com.monsanto.tps.lexicon.monnumber.MonNumber monNumber : monNumbers) {
         // all returned mon numbers should be active
         assertTrue(monNumber.isActiveStatus());

         if (monNumber.getMonNumber().equals("MON_1111")) {
            insertedMonNumberFound++;

            assertEquals("MON_1111", monNumber.getMonNumber());
            assertEquals("ZM_1111", monNumber.getEvent());
            assertEquals("CORN", monNumber.getCropName());
            assertEquals("1015", monNumber.getCropPubkey());
            assertNull(monNumber.getMaterialName());
            assertNull(monNumber.getPreviousNames());
            assertEquals("y", monNumber.getRegulatoryGenesPresent().toLowerCase());
            assertEquals("OECD1234", monNumber.getOecdNumber());
            assertNotNull(monNumber.getOecdNumberCommunicationDate());
            assertFalse(monNumber.isRegulatedStatus());
            assertEquals("JV123", monNumber.getJvNumber());
            assertFalse(monNumber.isLocked());
            assertEquals("TB123", monNumber.getTransformationBackground());
            assertEquals("RPL", monNumber.getRegulatoryParentalLine());

            assertEquals(1, monNumber.getProteinNames().size());
            com.monsanto.tps.lexicon.monnumber.ProteinName proteinName =
               monNumber.getProteinNames().iterator().next();
            assertEquals("1234", proteinName.getProteinNamePubkey());
            assertEquals("PROTNAME", proteinName.getProteinName());

            assertEquals(1, monNumber.getComlTraitTypes().size());
            ComlTraitType comlTraitType =
               monNumber.getComlTraitTypes().iterator().next();
            assertEquals("CTRTABBR", comlTraitType.getComlTraitTypeAbbr());
            assertEquals("CTRT DESC", comlTraitType.getComlTraitTypeDesc());

            assertEquals(1, monNumber.getMonNumberConstructs().size());
            com.monsanto.tps.lexicon.monnumber.MonNumberConstruct construct =
               monNumber.getMonNumberConstructs().iterator().next();
            assertEquals("CONNAME", construct.getConstructName());
            assertEquals("CONPV", construct.getPvCode());
         }
      }

      assertEquals(1, insertedMonNumberFound);
   }

   @Test 
 public void testReturnMonNumberWithMultiplePvCodeEntries() {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROTNAME").
                  withProteinNamePubkey("1234")
               ).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("CTRTABBR").
                  withTraitTypeDesc("CTRT DESC")
               ).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME1").
                  withPvCode("CONPV1")
               ).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME2").
                  withPvCode("CONPV2")
               ).
               createInDb();
         }
      });

      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByPvCode(new String[]{"CONPV1", "CONPV2"});

      assertTrue(monNumbers.length > 0);

      int insertedMonNumberFound = 0;
      for (com.monsanto.tps.lexicon.monnumber.MonNumber monNumber : monNumbers) {
         // all returned mon numbers should be active
         assertTrue(monNumber.isActiveStatus());

         if (monNumber.getMonNumber().equals("MON_1111")) {
            insertedMonNumberFound++;

            assertEquals("MON_1111", monNumber.getMonNumber());
            assertEquals("ZM_1111", monNumber.getEvent());
            assertEquals("CORN", monNumber.getCropName());
            assertEquals("1015", monNumber.getCropPubkey());
            assertNull(monNumber.getMaterialName());
            assertNull(monNumber.getPreviousNames());
            assertEquals("y", monNumber.getRegulatoryGenesPresent().toLowerCase());
            assertEquals("OECD1234", monNumber.getOecdNumber());
            assertNotNull(monNumber.getOecdNumberCommunicationDate());
            assertFalse(monNumber.isRegulatedStatus());
            assertEquals("JV123", monNumber.getJvNumber());
            assertFalse("n", monNumber.isLocked());
            assertEquals("TB123", monNumber.getTransformationBackground());
            assertEquals("RPL", monNumber.getRegulatoryParentalLine());

            assertEquals(1, monNumber.getProteinNames().size());
            com.monsanto.tps.lexicon.monnumber.ProteinName proteinName =
               monNumber.getProteinNames().iterator().next();
            assertEquals("1234", proteinName.getProteinNamePubkey());
            assertEquals("PROTNAME", proteinName.getProteinName());

            assertEquals(1, monNumber.getComlTraitTypes().size());
            ComlTraitType comlTraitType =
               monNumber.getComlTraitTypes().iterator().next();
            assertEquals("CTRTABBR", comlTraitType.getComlTraitTypeAbbr());
            assertEquals("CTRT DESC", comlTraitType.getComlTraitTypeDesc());

            assertEquals(2, monNumber.getMonNumberConstructs().size());
            for (MonNumberConstruct monNumberConstruct : monNumber.getMonNumberConstructs()) {
               assertTrue(monNumberConstruct.getConstructName().equals("CONNAME1") ||
                  monNumberConstruct.getConstructName().equals("CONNAME2"));
               if (monNumberConstruct.getConstructName().equals("CONNAME1")) {
                  assertEquals("CONPV1", monNumberConstruct.getPvCode());
               }
               else if (monNumberConstruct.getConstructName().equals("CONNAME2")) {
                  assertEquals("CONPV2", monNumberConstruct.getPvCode());
               }
               else {
                  fail("Invalid mon number construct found.");
               }
            }
         }
      }

      assertEquals(1, insertedMonNumberFound);
   }

   @Test 
 public void testReturnMonNumberWithMultipleCommaSeparatedPvCodesRequestedValueFoundAtFront() {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROTNAME").
                  withProteinNamePubkey("1234")
               ).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("CTRTABBR").
                  withTraitTypeDesc("CTRT DESC")
               ).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME").
                  withPvCode("NAME1 , NAME2, NAME3")
               ).
               createInDb();
         }
      });

      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByPvCode(new String[]{"NAME1"});

      assertTrue(monNumbers.length > 0);

      int insertedMonNumberFound = 0;
      for (com.monsanto.tps.lexicon.monnumber.MonNumber monNumber : monNumbers) {
         // all returned mon numbers should be active
         assertTrue(monNumber.isActiveStatus());

         if (monNumber.getMonNumber().equals("MON_1111")) {
            insertedMonNumberFound++;

            assertEquals("MON_1111", monNumber.getMonNumber());
            assertEquals("ZM_1111", monNumber.getEvent());
            assertEquals("CORN", monNumber.getCropName());
            assertEquals("1015", monNumber.getCropPubkey());
            assertNull(monNumber.getMaterialName());
            assertNull(monNumber.getPreviousNames());
            assertEquals("y", monNumber.getRegulatoryGenesPresent().toLowerCase());
            assertEquals("OECD1234", monNumber.getOecdNumber());
            assertNotNull(monNumber.getOecdNumberCommunicationDate());
            assertFalse(monNumber.isRegulatedStatus());
            assertEquals("JV123", monNumber.getJvNumber());
            assertFalse("n", monNumber.isLocked());
            assertEquals("TB123", monNumber.getTransformationBackground());
            assertEquals("RPL", monNumber.getRegulatoryParentalLine());

            assertEquals(1, monNumber.getProteinNames().size());
            com.monsanto.tps.lexicon.monnumber.ProteinName proteinName =
               monNumber.getProteinNames().iterator().next();
            assertEquals("1234", proteinName.getProteinNamePubkey());
            assertEquals("PROTNAME", proteinName.getProteinName());

            assertEquals(1, monNumber.getComlTraitTypes().size());
            ComlTraitType comlTraitType =
               monNumber.getComlTraitTypes().iterator().next();
            assertEquals("CTRTABBR", comlTraitType.getComlTraitTypeAbbr());
            assertEquals("CTRT DESC", comlTraitType.getComlTraitTypeDesc());

            assertEquals(1, monNumber.getMonNumberConstructs().size());
            com.monsanto.tps.lexicon.monnumber.MonNumberConstruct construct =
               monNumber.getMonNumberConstructs().iterator().next();
            assertEquals("CONNAME", construct.getConstructName());
            assertEquals("NAME1 , NAME2, NAME3", construct.getPvCode());
         }
      }

      assertEquals(1, insertedMonNumberFound);
   }

   @Test 
 public void testReturnMonNumberWithMultipleCommaSeparatedPvCodesRequestedValueFoundInMiddle() {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROTNAME").
                  withProteinNamePubkey("1234")
               ).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("CTRTABBR").
                  withTraitTypeDesc("CTRT DESC")
               ).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME").
                  withPvCode("NAME1 , NAME2, NAME3")
               ).
               createInDb();
         }
      });

      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByPvCode(new String[]{"NAME2"});

      assertTrue(monNumbers.length > 0);

      int insertedMonNumberFound = 0;
      for (com.monsanto.tps.lexicon.monnumber.MonNumber monNumber : monNumbers) {
         // all returned mon numbers should be active
         assertTrue(monNumber.isActiveStatus());

         if (monNumber.getMonNumber().equals("MON_1111")) {
            insertedMonNumberFound++;

            assertEquals("MON_1111", monNumber.getMonNumber());
            assertEquals("ZM_1111", monNumber.getEvent());
            assertEquals("CORN", monNumber.getCropName());
            assertEquals("1015", monNumber.getCropPubkey());
            assertNull(monNumber.getMaterialName());
            assertNull(monNumber.getPreviousNames());
            assertEquals("y", monNumber.getRegulatoryGenesPresent().toLowerCase());
            assertEquals("OECD1234", monNumber.getOecdNumber());
            assertNotNull(monNumber.getOecdNumberCommunicationDate());
            assertFalse(monNumber.isRegulatedStatus());
            assertEquals("JV123", monNumber.getJvNumber());
            assertFalse("n", monNumber.isLocked());
            assertEquals("TB123", monNumber.getTransformationBackground());
            assertEquals("RPL", monNumber.getRegulatoryParentalLine());

            assertEquals(1, monNumber.getProteinNames().size());
            com.monsanto.tps.lexicon.monnumber.ProteinName proteinName =
               monNumber.getProteinNames().iterator().next();
            assertEquals("1234", proteinName.getProteinNamePubkey());
            assertEquals("PROTNAME", proteinName.getProteinName());

            assertEquals(1, monNumber.getComlTraitTypes().size());
            ComlTraitType comlTraitType =
               monNumber.getComlTraitTypes().iterator().next();
            assertEquals("CTRTABBR", comlTraitType.getComlTraitTypeAbbr());
            assertEquals("CTRT DESC", comlTraitType.getComlTraitTypeDesc());

            assertEquals(1, monNumber.getMonNumberConstructs().size());
            com.monsanto.tps.lexicon.monnumber.MonNumberConstruct construct =
               monNumber.getMonNumberConstructs().iterator().next();
            assertEquals("CONNAME", construct.getConstructName());
            assertEquals("NAME1 , NAME2, NAME3", construct.getPvCode());
         }
      }

      assertEquals(1, insertedMonNumberFound);
   }

   @Test 
 public void testReturnMonNumberWithMultipleCommaSeparatedPvCodesRequestedValueFoundAtBack() {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROTNAME").
                  withProteinNamePubkey("1234")
               ).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("CTRTABBR").
                  withTraitTypeDesc("CTRT DESC")
               ).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME").
                  withPvCode("NAME1 , NAME2, NAME3")
               ).
               createInDb();
         }
      });

      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByPvCode(new String[]{"NAME3"});

      assertTrue(monNumbers.length > 0);

      int insertedMonNumberFound = 0;
      for (com.monsanto.tps.lexicon.monnumber.MonNumber monNumber : monNumbers) {
         // all returned mon numbers should be active
         assertTrue(monNumber.isActiveStatus());

         if (monNumber.getMonNumber().equals("MON_1111")) {
            insertedMonNumberFound++;

            assertEquals("MON_1111", monNumber.getMonNumber());
            assertEquals("ZM_1111", monNumber.getEvent());
            assertEquals("CORN", monNumber.getCropName());
            assertEquals("1015", monNumber.getCropPubkey());
            assertNull(monNumber.getMaterialName());
            assertNull(monNumber.getPreviousNames());
            assertEquals("y", monNumber.getRegulatoryGenesPresent().toLowerCase());
            assertEquals("OECD1234", monNumber.getOecdNumber());
            assertNotNull(monNumber.getOecdNumberCommunicationDate());
            assertFalse(monNumber.isRegulatedStatus());
            assertEquals("JV123", monNumber.getJvNumber());
            assertFalse(monNumber.isLocked());
            assertEquals("TB123", monNumber.getTransformationBackground());
            assertEquals("RPL", monNumber.getRegulatoryParentalLine());

            assertEquals(1, monNumber.getProteinNames().size());
            com.monsanto.tps.lexicon.monnumber.ProteinName proteinName =
               monNumber.getProteinNames().iterator().next();
            assertEquals("1234", proteinName.getProteinNamePubkey());
            assertEquals("PROTNAME", proteinName.getProteinName());

            assertEquals(1, monNumber.getComlTraitTypes().size());
            ComlTraitType comlTraitType =
               monNumber.getComlTraitTypes().iterator().next();
            assertEquals("CTRTABBR", comlTraitType.getComlTraitTypeAbbr());
            assertEquals("CTRT DESC", comlTraitType.getComlTraitTypeDesc());

            assertEquals(1, monNumber.getMonNumberConstructs().size());
            com.monsanto.tps.lexicon.monnumber.MonNumberConstruct construct =
               monNumber.getMonNumberConstructs().iterator().next();
            assertEquals("CONNAME", construct.getConstructName());
            assertEquals("NAME1 , NAME2, NAME3", construct.getPvCode());
         }
      }

      assertEquals(1, insertedMonNumberFound);
   }

   @Test 
 public void testReturntestReturnMonNumberWithMorePvCodesThanInRequest() {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROTNAME").
                  withProteinNamePubkey("1234")
               ).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("CTRTABBR").
                  withTraitTypeDesc("CTRT DESC")
               ).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME1").
                  withPvCode("CONPV1")
               ).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME2").
                  withPvCode("CONPV2")
               ).
               createInDb();
         }
      });

      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByPvCode(new String[]{"CONPV1"});

      assertTrue(monNumbers.length > 0);

      int insertedMonNumberFound = 0;
      for (com.monsanto.tps.lexicon.monnumber.MonNumber monNumber : monNumbers) {
         // all returned mon numbers should be active
         assertTrue(monNumber.isActiveStatus());

         if (monNumber.getMonNumber().equals("MON_1111")) {
            insertedMonNumberFound++;

            assertEquals("MON_1111", monNumber.getMonNumber());
            assertEquals("ZM_1111", monNumber.getEvent());
            assertEquals("CORN", monNumber.getCropName());
            assertEquals("1015", monNumber.getCropPubkey());
            assertNull(monNumber.getMaterialName());
            assertNull(monNumber.getPreviousNames());
            assertEquals("y", monNumber.getRegulatoryGenesPresent().toLowerCase());
            assertEquals("OECD1234", monNumber.getOecdNumber());
            assertNotNull(monNumber.getOecdNumberCommunicationDate());
            assertFalse(monNumber.isRegulatedStatus());
            assertEquals("JV123", monNumber.getJvNumber());
            assertFalse(monNumber.isLocked());
            assertEquals("TB123", monNumber.getTransformationBackground());
            assertEquals("RPL", monNumber.getRegulatoryParentalLine());

            assertEquals(1, monNumber.getProteinNames().size());
            com.monsanto.tps.lexicon.monnumber.ProteinName proteinName =
               monNumber.getProteinNames().iterator().next();
            assertEquals("1234", proteinName.getProteinNamePubkey());
            assertEquals("PROTNAME", proteinName.getProteinName());

            assertEquals(1, monNumber.getComlTraitTypes().size());
            ComlTraitType comlTraitType =
               monNumber.getComlTraitTypes().iterator().next();
            assertEquals("CTRTABBR", comlTraitType.getComlTraitTypeAbbr());
            assertEquals("CTRT DESC", comlTraitType.getComlTraitTypeDesc());

            assertEquals(2, monNumber.getMonNumberConstructs().size());
            for (MonNumberConstruct monNumberConstruct : monNumber.getMonNumberConstructs()) {
               assertTrue(monNumberConstruct.getConstructName().equals("CONNAME1") ||
                  monNumberConstruct.getConstructName().equals("CONNAME2"));
               if (monNumberConstruct.getConstructName().equals("CONNAME1")) {
                  assertEquals("CONPV1", monNumberConstruct.getPvCode());
               }
               else if (monNumberConstruct.getConstructName().equals("CONNAME2")) {
                  assertEquals("CONPV2", monNumberConstruct.getPvCode());
               }
               else {
                  fail("Invalid mon number construct found.");
               }
            }
         }
      }

      assertEquals(1, insertedMonNumberFound);
   }

   @Test 
 public void testReturnMonNumberWithFewerPvCodesThanInRequest() {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROTNAME").
                  withProteinNamePubkey("1234")
               ).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("CTRTABBR").
                  withTraitTypeDesc("CTRT DESC")
               ).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME1").
                  withPvCode("CONPV1")
               ).
               createInDb();
         }
      });

      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByPvCode(new String[]{"CONPV1", "CONPV2"});

      assertTrue(monNumbers.length > 0);

      int insertedMonNumberFound = 0;
      for (com.monsanto.tps.lexicon.monnumber.MonNumber monNumber : monNumbers) {
         // all returned mon numbers should be active
         assertTrue(monNumber.isActiveStatus());

         if (monNumber.getMonNumber().equals("MON_1111")) {
            insertedMonNumberFound++;

            assertEquals("MON_1111", monNumber.getMonNumber());
            assertEquals("ZM_1111", monNumber.getEvent());
            assertEquals("CORN", monNumber.getCropName());
            assertEquals("1015", monNumber.getCropPubkey());
            assertNull(monNumber.getMaterialName());
            assertNull(monNumber.getPreviousNames());
            assertEquals("y", monNumber.getRegulatoryGenesPresent().toLowerCase());
            assertEquals("OECD1234", monNumber.getOecdNumber());
            assertNotNull(monNumber.getOecdNumberCommunicationDate());
            assertFalse(monNumber.isRegulatedStatus());
            assertEquals("JV123", monNumber.getJvNumber());
            assertFalse(monNumber.isLocked());
            assertEquals("TB123", monNumber.getTransformationBackground());
            assertEquals("RPL", monNumber.getRegulatoryParentalLine());

            assertEquals(1, monNumber.getProteinNames().size());
            com.monsanto.tps.lexicon.monnumber.ProteinName proteinName =
               monNumber.getProteinNames().iterator().next();
            assertEquals("1234", proteinName.getProteinNamePubkey());
            assertEquals("PROTNAME", proteinName.getProteinName());

            assertEquals(1, monNumber.getComlTraitTypes().size());
            ComlTraitType comlTraitType =
               monNumber.getComlTraitTypes().iterator().next();
            assertEquals("CTRTABBR", comlTraitType.getComlTraitTypeAbbr());
            assertEquals("CTRT DESC", comlTraitType.getComlTraitTypeDesc());

            assertEquals(1, monNumber.getMonNumberConstructs().size());
            com.monsanto.tps.lexicon.monnumber.MonNumberConstruct construct =
               monNumber.getMonNumberConstructs().iterator().next();
            assertEquals("CONNAME1", construct.getConstructName());
            assertEquals("CONPV1", construct.getPvCode());
         }
      }

      assertEquals(1, insertedMonNumberFound);
   }

   @Test 
 public void testReturnMultipleMonNumbersWithSamePvCode() {
      final ProteinNameBuilder proteinNameBuilder = new ProteinNameBuilder().
         withProteinName("PROTNAME").
         withProteinNamePubkey("1234");
      final ComlTraitTypeBuilder comlTraitTypeBuilder = new ComlTraitTypeBuilder().
         withTraitTypeAbbr("CTRTABBR").
         withTraitTypeDesc("CTRT DESC");

      MonNumber testMonNumberOne = insert(new AcceptanceTestData<MonNumber>()
      {

         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withOecdNumber("OECD1111").
               withProteinName(proteinNameBuilder).
               withComlTraitType(comlTraitTypeBuilder).
               withMonNumberConstruct(
                  new MonNumberConstructBuilder().
                     withConstructName("CONNAME1").
                     withPvCode("CONPV1")
               ).
               createInDb();
         }
      });

      MonNumber testMonNumberTwo = insert(new AcceptanceTestData<MonNumber>()
      {

         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_2222").
               withEventName("ZM_2222").
               withOecdNumber("OECD2222").
               withProteinName(proteinNameBuilder).
               withComlTraitType(comlTraitTypeBuilder).
               withMonNumberConstruct(
                  new MonNumberConstructBuilder().
                     withConstructName("CONNAME1").
                     withPvCode("CONPV1")
               ).
               createInDb();
         }
      });

      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByPvCode(new String[]{"CONPV1", "CONPV2"});

      assertTrue(monNumbers.length > 0);

      int insertedMonNumbersFound = 0;
      for (com.monsanto.tps.lexicon.monnumber.MonNumber monNumber : monNumbers) {
         // all returned mon numbers should be active
         assertTrue(monNumber.isActiveStatus());

         if (monNumber.getMonNumber().equals("MON_1111") ||
            monNumber.getMonNumber().equals("MON_2222")) {
            insertedMonNumbersFound++;
            if (monNumber.getMonNumber().equals("MON_1111")) {
               assertEquals("ZM_1111", monNumber.getEvent());
               assertEquals("OECD1111", monNumber.getOecdNumber());
            }
            else {
               assertEquals("ZM_2222", monNumber.getEvent());
               assertEquals("OECD2222", monNumber.getOecdNumber());
            }

            assertEquals("CORN", monNumber.getCropName());
            assertEquals("1015", monNumber.getCropPubkey());
            assertNull(monNumber.getMaterialName());
            assertNull(monNumber.getPreviousNames());
            assertEquals("y", monNumber.getRegulatoryGenesPresent().toLowerCase());
            assertNotNull(monNumber.getOecdNumberCommunicationDate());
            assertFalse(monNumber.isRegulatedStatus());
            assertEquals("JV123", monNumber.getJvNumber());
            assertFalse(monNumber.isLocked());
            assertEquals("TB123", monNumber.getTransformationBackground());
            assertEquals("RPL", monNumber.getRegulatoryParentalLine());

            assertEquals(1, monNumber.getProteinNames().size());
            com.monsanto.tps.lexicon.monnumber.ProteinName proteinName =
               monNumber.getProteinNames().iterator().next();
            assertEquals("1234", proteinName.getProteinNamePubkey());
            assertEquals("PROTNAME", proteinName.getProteinName());

            assertEquals(1, monNumber.getComlTraitTypes().size());
            ComlTraitType comlTraitType =
               monNumber.getComlTraitTypes().iterator().next();
            assertEquals("CTRTABBR", comlTraitType.getComlTraitTypeAbbr());
            assertEquals("CTRT DESC", comlTraitType.getComlTraitTypeDesc());

            assertEquals(1, monNumber.getMonNumberConstructs().size());
            com.monsanto.tps.lexicon.monnumber.MonNumberConstruct construct =
               monNumber.getMonNumberConstructs().iterator().next();
            assertEquals("CONNAME1", construct.getConstructName());
            assertEquals("CONPV1", construct.getPvCode());
         }
      }

      assertEquals(2, insertedMonNumbersFound);
   }

   @Test 
 public void testReturnMultipleMonNumbersWithDifferentPvCodes() {
      final ProteinNameBuilder proteinNameBuilder = new ProteinNameBuilder().
         withProteinName("PROTNAME").
         withProteinNamePubkey("1234");
      final ComlTraitTypeBuilder comlTraitTypeBuilder = new ComlTraitTypeBuilder().
         withTraitTypeAbbr("CTRTABBR").
         withTraitTypeDesc("CTRT DESC");

      MonNumber testMonNumberOne = insert(new AcceptanceTestData<MonNumber>()
      {

         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withOecdNumber("OECD1111").
               withProteinName(proteinNameBuilder).
               withComlTraitType(comlTraitTypeBuilder).
               withMonNumberConstruct(
                  new MonNumberConstructBuilder().
                     withConstructName("CONNAME1").
                     withPvCode("CONPV1")
               ).
               withMonNumberConstruct(
                  new MonNumberConstructBuilder().
                     withConstructName("CONNAME11").
                     withPvCode("CONPV11")
               ).
               createInDb();
         }
      });

      MonNumber testMonNumberTwo = insert(new AcceptanceTestData<MonNumber>()
      {

         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_2222").
               withEventName("ZM_2222").
               withOecdNumber("OECD2222").
               withProteinName(proteinNameBuilder).
               withComlTraitType(comlTraitTypeBuilder).
               withMonNumberConstruct(
                  new MonNumberConstructBuilder().
                     withConstructName("CONNAME2").
                     withPvCode("CONPV2")
               ).
               createInDb();
         }
      });

      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByPvCode(new String[]{"CONPV1", "CONPV11", "CONPV2", "ANOTHERPV"});

      assertTrue(monNumbers.length > 0);

      int insertedMonNumbersFound = 0;
      for (com.monsanto.tps.lexicon.monnumber.MonNumber monNumber : monNumbers) {
         // all returned mon numbers should be active
         assertTrue(monNumber.isActiveStatus());

         if (monNumber.getMonNumber().equals("MON_1111") ||
            monNumber.getMonNumber().equals("MON_2222")) {
            insertedMonNumbersFound++;
            if (monNumber.getMonNumber().equals("MON_1111")) {
               assertEquals("ZM_1111", monNumber.getEvent());
               assertEquals("OECD1111", monNumber.getOecdNumber());
               assertEquals(2, monNumber.getMonNumberConstructs().size());
               for (MonNumberConstruct construct : monNumber.getMonNumberConstructs()) {
                  if (construct.getConstructName().equals("CONNAME1")) {
                     assertEquals("CONPV1", construct.getPvCode());
                  }
                  else if (construct.getConstructName().equals("CONNAME11")) {
                     assertEquals("CONPV11", construct.getPvCode());
                  }
                  else {
                     fail("Invalid construct found.");
                  }
               }
            }
            else {
               assertEquals("ZM_2222", monNumber.getEvent());
               assertEquals("OECD2222", monNumber.getOecdNumber());
               assertEquals(1, monNumber.getMonNumberConstructs().size());
               com.monsanto.tps.lexicon.monnumber.MonNumberConstruct construct =
                  monNumber.getMonNumberConstructs().iterator().next();
               assertEquals("CONNAME2", construct.getConstructName());
               assertEquals("CONPV2", construct.getPvCode());
            }

            assertEquals("CORN", monNumber.getCropName());
            assertEquals("1015", monNumber.getCropPubkey());
            assertNull(monNumber.getMaterialName());
            assertNull(monNumber.getPreviousNames());
            assertEquals("y", monNumber.getRegulatoryGenesPresent().toLowerCase());
            assertNotNull(monNumber.getOecdNumberCommunicationDate());
            assertFalse(monNumber.isRegulatedStatus());
            assertEquals("JV123", monNumber.getJvNumber());
            assertFalse(monNumber.isLocked());
            assertEquals("TB123", monNumber.getTransformationBackground());
            assertEquals("RPL", monNumber.getRegulatoryParentalLine());

            assertEquals(1, monNumber.getProteinNames().size());
            com.monsanto.tps.lexicon.monnumber.ProteinName proteinName =
               monNumber.getProteinNames().iterator().next();
            assertEquals("1234", proteinName.getProteinNamePubkey());
            assertEquals("PROTNAME", proteinName.getProteinName());

            assertEquals(1, monNumber.getComlTraitTypes().size());
            ComlTraitType comlTraitType =
               monNumber.getComlTraitTypes().iterator().next();
            assertEquals("CTRTABBR", comlTraitType.getComlTraitTypeAbbr());
            assertEquals("CTRT DESC", comlTraitType.getComlTraitTypeDesc());
         }
      }

      assertEquals(2, insertedMonNumbersFound);
   }

   @Test 
 public void testReturnNoDataForPartialPvCodeMatch() {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROTNAME").
                  withProteinNamePubkey("1234")
               ).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("CTRTABBR").
                  withTraitTypeDesc("CTRT DESC")
               ).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME").
                  withPvCode("CONPV")
               ).
               createInDb();
         }
      });

      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByPvCode(new String[]{"PV"});

      boolean insertedMonNumberFound = false;
      for (com.monsanto.tps.lexicon.monnumber.MonNumber monNumber : monNumbers) {
         // all returned mon numbers should be active
         assertTrue(monNumber.isActiveStatus());

         if (monNumber.getMonNumber().equals("MON_1111")) {
            insertedMonNumberFound = true;
         }
      }

      assertFalse(insertedMonNumberFound);
   }

   @Test 
 public void testReturnNoDataForNonActiveMonNumberPvCode() {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withActiveStatus(false).
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROTNAME").
                  withProteinNamePubkey("1234")
               ).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("CTRTABBR").
                  withTraitTypeDesc("CTRT DESC")
               ).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME").
                  withPvCode("CONPV")
               ).
               createInDb();
         }
      });

      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByPvCode(new String[]{"CONPV"});

      boolean insertedMonNumberFound = false;
      for (com.monsanto.tps.lexicon.monnumber.MonNumber monNumber : monNumbers) {
         // all returned mon numbers should be active
         assertTrue(monNumber.isActiveStatus());

         if (monNumber.getMonNumber().equals("MON_1111")) {
            insertedMonNumberFound = true;
         }
      }

      assertFalse(insertedMonNumberFound);
   }

   @Test 
 public void testReturnNoDataForInvalidPvCode() {
      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByPvCode(new String[]{"InvalidPvCode"});

      assertEquals(0, monNumbers.length);
   }

   @Test 
 public void testFindByMonNumber_ReturnsMonNumber() {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROTNAME").
                  withProteinNamePubkey("1234")
               ).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("CTRTABBR").
                  withTraitTypeDesc("CTRT DESC")
               ).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME1").
                  withPvCode("CONPV1")
               ).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME2").
                  withPvCode("CONPV2")
               ).
               createInDb();
         }
      });

      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByMonNumber("MON_1111");

      assertTrue(monNumbers.length > 0);

      assertTrue(containsMonNumber("MON_1111", monNumbers));

      for (com.monsanto.tps.lexicon.monnumber.MonNumber monNumber : monNumbers) {
         // all returned mon numbers should be active
         assertTrue(monNumber.isActiveStatus());

         if (monNumber.getMonNumber().equals("MON_1111")) {
            assertEquals("MON_1111", monNumber.getMonNumber());
            assertEquals("ZM_1111", monNumber.getEvent());
            assertEquals("CORN", monNumber.getCropName());
            assertEquals("1015", monNumber.getCropPubkey());
            assertNull(monNumber.getMaterialName());
            assertNull(monNumber.getPreviousNames());
            assertEquals("y", monNumber.getRegulatoryGenesPresent().toLowerCase());
            assertEquals("OECD1234", monNumber.getOecdNumber());
            assertNotNull(monNumber.getOecdNumberCommunicationDate());
            assertFalse(monNumber.isRegulatedStatus());
            assertEquals("JV123", monNumber.getJvNumber());
            assertFalse(monNumber.isLocked());
            assertEquals("TB123", monNumber.getTransformationBackground());
            assertEquals("RPL", monNumber.getRegulatoryParentalLine());

            assertEquals(1, monNumber.getProteinNames().size());
            com.monsanto.tps.lexicon.monnumber.ProteinName proteinName =
               monNumber.getProteinNames().iterator().next();
            assertEquals("1234", proteinName.getProteinNamePubkey());
            assertEquals("PROTNAME", proteinName.getProteinName());

            assertEquals(1, monNumber.getComlTraitTypes().size());
            ComlTraitType comlTraitType =
               monNumber.getComlTraitTypes().iterator().next();
            assertEquals("CTRTABBR", comlTraitType.getComlTraitTypeAbbr());
            assertEquals("CTRT DESC", comlTraitType.getComlTraitTypeDesc());

            assertEquals(2, monNumber.getMonNumberConstructs().size());
            for (MonNumberConstruct monNumberConstruct : monNumber.getMonNumberConstructs()) {
               assertTrue(monNumberConstruct.getConstructName().equals("CONNAME1") ||
                  monNumberConstruct.getConstructName().equals("CONNAME2"));
               if (monNumberConstruct.getConstructName().equals("CONNAME1")) {
                  assertEquals("CONPV1", monNumberConstruct.getPvCode());
               }
               else if (monNumberConstruct.getConstructName().equals("CONNAME2")) {
                  assertEquals("CONPV2", monNumberConstruct.getPvCode());
               }
               else {
                  fail("Invalid mon number construct found.");
               }
            }
         }
      }
   }

   @Test 
 public void testFindByMonNumber_DoesNotFindInactiveMonNumber() {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withActiveStatus(false).
               createInDb();
         }
      });

      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByMonNumber("MON_1111");

      assertFalse(containsMonNumber("MON_1111", monNumbers));
   }

   @Test 
 public void testFindByMonNumber_DoesNotFindNonExistantMonNumber() {
      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByMonNumber("InvalidMonNumber");

      assertEquals(0, monNumbers.length);
   }

   @Test 
 public void testFindByMonNumberAndCrop_ReturnsMonNumber() {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withCrop(CropBuilder.corn()).
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROTNAME").
                  withProteinNamePubkey("1234")
               ).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("CTRTABBR").
                  withTraitTypeDesc("CTRT DESC")
               ).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME1").
                  withPvCode("CONPV1")
               ).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME2").
                  withPvCode("CONPV2")
               ).
               createInDb();
         }
      });

      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByMonNumberAndCrop("MON_1111", CropBuilder.corn().getCropPubkey());

      assertTrue(monNumbers.length > 0);

      assertTrue(containsMonNumber("MON_1111", monNumbers));

      for (com.monsanto.tps.lexicon.monnumber.MonNumber monNumber : monNumbers) {
         // all returned mon numbers should be active
         assertTrue(monNumber.isActiveStatus());

         if (monNumber.getMonNumber().equals("MON_1111")) {
            assertEquals("MON_1111", monNumber.getMonNumber());
            assertEquals("ZM_1111", monNumber.getEvent());
            assertEquals("CORN", monNumber.getCropName());
            assertEquals("1015", monNumber.getCropPubkey());
            assertNull(monNumber.getMaterialName());
            assertNull(monNumber.getPreviousNames());
            assertEquals("y", monNumber.getRegulatoryGenesPresent().toLowerCase());
            assertEquals("OECD1234", monNumber.getOecdNumber());
            assertNotNull(monNumber.getOecdNumberCommunicationDate());
            assertFalse(monNumber.isRegulatedStatus());
            assertEquals("JV123", monNumber.getJvNumber());
            assertFalse(monNumber.isLocked());
            assertEquals("TB123", monNumber.getTransformationBackground());
            assertEquals("RPL", monNumber.getRegulatoryParentalLine());

            assertEquals(1, monNumber.getProteinNames().size());
            com.monsanto.tps.lexicon.monnumber.ProteinName proteinName =
               monNumber.getProteinNames().iterator().next();
            assertEquals("1234", proteinName.getProteinNamePubkey());
            assertEquals("PROTNAME", proteinName.getProteinName());

            assertEquals(1, monNumber.getComlTraitTypes().size());
            ComlTraitType comlTraitType =
               monNumber.getComlTraitTypes().iterator().next();
            assertEquals("CTRTABBR", comlTraitType.getComlTraitTypeAbbr());
            assertEquals("CTRT DESC", comlTraitType.getComlTraitTypeDesc());

            assertEquals(2, monNumber.getMonNumberConstructs().size());
            for (MonNumberConstruct monNumberConstruct : monNumber.getMonNumberConstructs()) {
               assertTrue(monNumberConstruct.getConstructName().equals("CONNAME1") ||
                  monNumberConstruct.getConstructName().equals("CONNAME2"));
               if (monNumberConstruct.getConstructName().equals("CONNAME1")) {
                  assertEquals("CONPV1", monNumberConstruct.getPvCode());
               }
               else if (monNumberConstruct.getConstructName().equals("CONNAME2")) {
                  assertEquals("CONPV2", monNumberConstruct.getPvCode());
               }
               else {
                  fail("Invalid mon number construct found.");
               }
            }
         }
      }
   }

   @Test 
 public void testFindByMonNumberAndCrop_DoesNotFindInactiveMonNumber() {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withCrop(CropBuilder.corn()).
               withActiveStatus(false).
               createInDb();
         }
      });

      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByMonNumberAndCrop("MON_1111", CropBuilder.corn().getCropPubkey());

      assertFalse(containsMonNumber("MON_1111", monNumbers));
   }

   @Test 
 public void testFindByMonNumberAndCrop_DoesNotFindMonNumberWithDifferentCrop() {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withCrop(CropBuilder.corn()).
               createInDb();
         }
      });

      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByMonNumberAndCrop("MON_1111", CropBuilder.soybeans().getCropPubkey());

      assertFalse(containsMonNumber("MON_1111", monNumbers));
   }

   @Test 
 public void testFindByMonNumberAndCrop_DoesNotFindNonExistantMonNumber() {
      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findByMonNumberAndCrop("InvalidMonNumber", CropBuilder.corn().getCropPubkey());

      assertEquals(0, monNumbers.length);
   }

   @Test 
 public void testFindAllMonNumbers() {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withActiveStatus(false).
               withProteinName(new ProteinNameBuilder().
                  withProteinName("PROTNAME").
                  withProteinNamePubkey("1234")
               ).
               withComlTraitType(new ComlTraitTypeBuilder().
                  withTraitTypeAbbr("CTRTABBR").
                  withTraitTypeDesc("CTRT DESC")
               ).
               withMonNumberConstruct(new MonNumberConstructBuilder().
                  withConstructName("CONNAME").
                  withPvCode("CONPV")
               ).
               createInDb();
         }
      });

      com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers =
         monNumberService.findAll();
      assertFalse(ArrayUtils.isEmpty(monNumbers));
      assertTrue(containsMonNumber("MON_1111", monNumbers));
      assertTrue(containsConstructName("CONNAME", monNumbers));
      assertTrue(containsProteinName("PROTNAME", monNumbers));
      assertTrue(containsTraitType("CTRTABBR", monNumbers));
   }


   @Test 
 public void testFindMonNumberInfoByEventsAndCrop_FindsMonNumber()
      throws Exception
   {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withCrop(CropBuilder.corn()).
               createInDb();
         }
      });
      String[] events = new String[]{"ZM_1111"};
      List<MonNumberInfo> monNumbers = monNumberService.findByEventsAndCrop(events, "Corn");
      assertNotNull(monNumbers);
      assertFalse(monNumbers.isEmpty());
      MonNumberInfo monNumberInfo = monNumbers.get(0);
      assertEquals("MON_1111", monNumberInfo.getMonNumber());
      assertEquals("ZM_1111", monNumberInfo.getEvent());
   }

   @Test 
 public void testFindMonNumberInfoByEventsAndCrop_DoesNotFind_ForNonExistantMonNumber()
      throws Exception
   {
      String[] events = new String[]{"ZM_1111"};
      List<MonNumberInfo> monNumbers = monNumberService.findByEventsAndCrop(events, "Corn");
      assertNotNull(monNumbers);
      assertTrue(monNumbers.isEmpty());
   }

   @Test 
 public void testFindMonNumberInfoByEventsAndCrop_DoesNotFind_ForNullEvents()
      throws Exception
   {
      List<MonNumberInfo> monNumbers = monNumberService.findByEventsAndCrop(null, "Corn");
      assertNotNull(monNumbers);
      assertTrue(monNumbers.isEmpty());
   }

   @Test 
 public void testFindMonNumberInfoByEventsAndCrop_FindsMonNumber_CaseInsensitiveCrop()
      throws Exception
   {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withCrop(CropBuilder.corn()).
               createInDb();
         }
      });
      String[] events = new String[]{"ZM_1111"};
      List<MonNumberInfo> monNumbers = monNumberService.findByEventsAndCrop(events, "coRN");
      assertNotNull(monNumbers);
      assertFalse(monNumbers.isEmpty());
      MonNumberInfo monNumberInfo = monNumbers.get(0);
      assertEquals("MON_1111", monNumberInfo.getMonNumber());
      assertEquals("ZM_1111", monNumberInfo.getEvent());
   }

   @Test 
 public void testFindMonNumberInfoByEventsAndCrop_FindsMonNumber_CaseInsensitiveEvent()
      throws Exception
   {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withCrop(CropBuilder.corn()).
               createInDb();
         }
      });
      String[] events = new String[]{"zM_1111"};
      List<MonNumberInfo> monNumbers = monNumberService.findByEventsAndCrop(events, "Corn");
      assertNotNull(monNumbers);
      assertFalse(monNumbers.isEmpty());
      MonNumberInfo monNumberInfo = monNumbers.get(0);
      assertEquals("MON_1111", monNumberInfo.getMonNumber());
      assertEquals("ZM_1111", monNumberInfo.getEvent());
      assertEquals("CORN", monNumberInfo.getCropName());
   }

   @Test 
 public void testFindMonNumberInfoByEventsAndCrop_FindsMonNumber_MultipleEvents()
      throws Exception
   {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withCrop(CropBuilder.corn()).
               createInDb();
         }
      });
      MonNumber secondMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return
               new MonNumberBuilder().
                  withMonNumber("MON_2222").
                  withEventName("ZM_2222").
                  withOecdNumber("OECD4455").
                  withCrop(CropBuilder.corn()).
                  createInDb();
         }
      });
      String[] events = new String[]{"ZM_1111", "ZM_2222"};
      List<MonNumberInfo> monNumbers = monNumberService.findByEventsAndCrop(events, "Corn");
      assertNotNull(monNumbers);
      assertFalse(monNumbers.isEmpty());
      assertEquals(2, monNumbers.size());
      MonNumberInfo monNumberInfo = monNumbers.get(0);
      assertEquals("MON_1111", monNumberInfo.getMonNumber());
      assertEquals("ZM_1111", monNumberInfo.getEvent());

      monNumberInfo = monNumbers.get(1);
      assertEquals("MON_2222", monNumberInfo.getMonNumber());
      assertEquals("ZM_2222", monNumberInfo.getEvent());
   }


   @Test 
 public void testFindMonNumberInfoByByEventsAndCrop_ReturnsMonNumbers_SearchCriteriaCountMoreThanMaxAllowed()
      throws Exception
   {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withCrop(CropBuilder.corn()).
               createInDb();
         }
      });

      String[] events = new String[1001];
      fillMonNumbers(events, "ZM", 1000);
      events[1000] = "ZM_1111";
      List<MonNumberInfo> monNumbers = monNumberService.findByEventsAndCrop(events, "Corn");
      assertNotNull(monNumbers);
      assertFalse(monNumbers.isEmpty());
      assertEquals(1, monNumbers.size());
      MonNumberInfo monNumberInfo = monNumbers.get(0);
      assertEquals("MON_1111", monNumberInfo.getMonNumber());
      assertEquals("ZM_1111", monNumberInfo.getEvent());
   }

   @Test 
 public void testFindMonNumberInfoByMonNumbers_DoesNotFind_ForNonExistantMonNumber()
      throws Exception
   {
      List<MonNumberInfo> monNumbers = monNumberService.findByMonNumbers(new String[]{"MON 1111"});
      assertNotNull(monNumbers);
      assertTrue(monNumbers.isEmpty());
   }

   @Test 
 public void testFindMonNumberInfoByMonNumbers_ReturnsMonNumbers()
      throws Exception
   {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withCrop(CropBuilder.corn()).
               createInDb();
         }
      });
      MonNumber secondMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_2222").
               withEventName("ZM_2222").
               withOecdNumber("OECD4455").
               withCrop(CropBuilder.corn()).
               createInDb();
         }
      });
      List<MonNumberInfo> monNumbers = monNumberService.findByMonNumbers(new String[]{"MON_1111", "MON_2222"});
      assertNotNull(monNumbers);
      assertFalse(monNumbers.isEmpty());
      assertEquals(2, monNumbers.size());
      MonNumberInfo monNumberInfo = monNumbers.get(0);

      assertEquals("CORN", monNumberInfo.getCropName());

      monNumberInfo = monNumbers.get(1);

      assertEquals("CORN", monNumberInfo.getCropName());

      List<String> monNumberCheck = Arrays.asList(monNumbers.get(0).getMonNumber(),monNumbers.get(1).getMonNumber()) ;
      List<String> eventCheck = Arrays.asList(monNumbers.get(0).getEvent(),monNumbers.get(1).getEvent()) ;
      assertTrue(monNumberCheck.contains("MON_1111"));
      assertTrue(eventCheck.contains("ZM_1111"));

      assertTrue(monNumberCheck.contains("MON_2222"));
      assertTrue(eventCheck.contains("ZM_2222"));

   }

   @Test 
 public void testFindMonNumberInfoByMonNumbers_ReturnsMonNumbers_CaseInsensitiveSearch()
      throws Exception
   {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withCrop(CropBuilder.corn()).
               createInDb();
         }
      });
      List<MonNumberInfo> monNumbers = monNumberService.findByMonNumbers(new String[]{"mOn_1111"});
      assertNotNull(monNumbers);
      assertFalse(monNumbers.isEmpty());
      assertEquals(1, monNumbers.size());
      MonNumberInfo monNumberInfo = monNumbers.get(0);
      assertEquals("MON_1111", monNumberInfo.getMonNumber());
      assertEquals("ZM_1111", monNumberInfo.getEvent());

   }

   @Test 
 public void testFindMonNumberInfoByMonNumbers_DoesNotReturnMonNumbers_ForEmptySearchCriteria()
      throws Exception
   {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withCrop(CropBuilder.corn()).
               createInDb();
         }
      });
      List<MonNumberInfo> monNumbers = monNumberService.findByMonNumbers(new String[]{""});
      assertNotNull(monNumbers);
      assertTrue(monNumbers.isEmpty());
   }

   @Test 
 public void testFindMonNumberInfoByMonNumbers_DoesNotReturnMonNumbers_ForNullSearchCriteria()
      throws Exception
   {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withCrop(CropBuilder.corn()).
               createInDb();
         }
      });
      List<MonNumberInfo> monNumbers = monNumberService.findByMonNumbers(null);
      assertNotNull(monNumbers);
      assertTrue(monNumbers.isEmpty());
   }


   @Test 
 public void testFindMonNumberInfoByMonNumbers_ReturnsMonNumbers_SearchCriteriaCountMoreThanMaxAllowed()
      throws Exception
   {
      MonNumber testMonNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().
               withMonNumber("MON_1111").
               withEventName("ZM_1111").
               withCrop(CropBuilder.corn()).
               createInDb();
         }
      });

      String[] monNumbersToSearch = new String[1001];
      fillMonNumbers(monNumbersToSearch, "MON", 1000);
      monNumbersToSearch[1000] = "MON_1111";
      List<MonNumberInfo> monNumbers = monNumberService.findByMonNumbers(monNumbersToSearch);
      assertNotNull(monNumbers);
      assertFalse(monNumbers.isEmpty());
      assertEquals(1, monNumbers.size());
      MonNumberInfo monNumberInfo = monNumbers.get(0);
      assertEquals("MON_1111", monNumberInfo.getMonNumber());
      assertEquals("ZM_1111", monNumberInfo.getEvent());
   }

   private String[] fillMonNumbers(String[] array, String monPrefix, int count) {
      for (int i = 0; i < count; i++) {
         array[i] = monPrefix + "_" + i;
      }
      return array;
   }

   private boolean containsConstructName(String constructName, com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers) {
      for (com.monsanto.tps.lexicon.monnumber.MonNumber monNumber : monNumbers) {
         Collection<com.monsanto.tps.lexicon.monnumber.MonNumberConstruct> monNumberConstructs = monNumber.getMonNumberConstructs();
         for (com.monsanto.tps.lexicon.monnumber.MonNumberConstruct monNumberConstruct : monNumberConstructs) {
            if (constructName.equalsIgnoreCase(monNumberConstruct.getConstructName())) {
               return true;
            }
         }
      }
      return false;
   }

   private boolean containsProteinName(String proteinName, com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers) {
      for (com.monsanto.tps.lexicon.monnumber.MonNumber monNumber : monNumbers) {
         Collection<com.monsanto.tps.lexicon.monnumber.ProteinName> proteinNames = monNumber.getProteinNames();
         for (com.monsanto.tps.lexicon.monnumber.ProteinName name : proteinNames) {
            if (proteinName.equalsIgnoreCase(name.getProteinName())) {
               return true;
            }
         }
      }
      return false;
   }

   private boolean containsTraitType(String traitTypeAbbr, com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers) {
      for (com.monsanto.tps.lexicon.monnumber.MonNumber monNumber : monNumbers) {
         Collection<ComlTraitType> traitTypes = monNumber.getComlTraitTypes();
         for (ComlTraitType traitType : traitTypes) {
            if (traitTypeAbbr.equalsIgnoreCase(traitType.getComlTraitTypeAbbr())) {
               return true;
            }
         }
      }
      return false;
   }

   private boolean containsMonNumber(String monNumber, com.monsanto.tps.lexicon.monnumber.MonNumber[] monNumbers) {
      for (com.monsanto.tps.lexicon.monnumber.MonNumber number : monNumbers) {
         if (monNumber.equalsIgnoreCase(number.getMonNumber())) {
            return true;
         }
      }
      return false;
   }

}
