package com.monsanto.tps.lexicon.regulatory.nonmonevent.model;

import com.monsanto.tps.lexicon.nonmonevent.NonMonEventPersistRequest;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Crop;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.dao.NonMonEventPersistQuerySet;
import static org.easymock.classextension.EasyMock.*;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;

/**
 * nbwald - May 21, 2009 7:26:51 PM
 */
public class NonMonEventPersistRichRequest_UT
{
   private NonMonEventPersistRequest request;
   private NonMonEventPersistQuerySet querySet;
   private NonMonEventPersistRichRequest richRequest;

   @Before
   public void before()
      throws Exception
   {
      request = new NonMonEventPersistRequest();
      querySet = createNiceMock(NonMonEventPersistQuerySet.class);
     
      richRequest = new NonMonEventPersistRichRequest(querySet);
   }

   @Test
   public void testLoad_GetAuditComment()
      throws Exception
   {
      request.setAuditComment("auditComment");
      expect(querySet.findConstructsByEventAndCrop((String)anyObject(), (String)anyObject())).andReturn(new String[0]);
      replay(querySet);

      richRequest.load(request);

      assertThat(richRequest.getAuditComment(), is("auditComment"));
   }

   @Test
   public void testLoad_GetAuditRequestor()
      throws Exception
   {
      request.setAuditRequestor("auditRequestor");
      expect(querySet.findConstructsByEventAndCrop((String)anyObject(), (String)anyObject())).andReturn(new String[0]);
      replay(querySet);

      richRequest.load(request);

      assertThat(richRequest.getAuditRequestor(), is("auditRequestor"));
   }

   @Test
   public void testLoad_GetMaterialName()
      throws Exception
   {
      request.setMaterialName("materialName");
      expect(querySet.findConstructsByEventAndCrop((String)anyObject(), (String)anyObject())).andReturn(new String[0]);
      replay(querySet);

      richRequest.load(request);

      assertThat(richRequest.getMaterialName(), is("materialName"));
   }

   @Test
   public void testLoad_GetCrop()
      throws Exception
   {
      Crop crop = new Crop();
      request.setCropPubkey("cropPubkey");
      expect(querySet.findConstructsByEventAndCrop((String)anyObject(), (String)anyObject())).andReturn(new String[0]);
      expect(querySet.findCropByPubkey("cropPubkey")).andReturn(crop);
      replay(querySet);

      richRequest.load(request);

      verify(querySet);
      assertThat(richRequest.getCrop(), is(crop));
   }

   @Test
   public void testLoad_GetConstructs()
      throws Exception
   {
      String[] constructs = new String[0];
      Crop crop = new Crop();
      crop.setCropName("Corn");
      request.setEventName("eventName");
      request.setCropPubkey("cropPubkey");

      expect(querySet.findCropByPubkey("cropPubkey")).andReturn(crop);
      expect(querySet.findConstructsByEventAndCrop("eventName", "Corn")).andReturn(constructs);
      replay(querySet);

      richRequest.load(request);

      verify(querySet);
      assertThat(richRequest.getConstructs(), is(constructs));
   }

   @Test
   public void testLoad_GetConstructsReturnsConstruct()
      throws Exception
   {
       String construct = "construct1";
       String[] constructs = new String[]{construct};
      Crop crop = new Crop();
      crop.setCropName("Corn");
      request.setEventName("eventName");
      request.setCropPubkey("cropPubkey");

      expect(querySet.findCropByPubkey("cropPubkey")).andReturn(crop);
      expect(querySet.findConstructsByEventAndCrop("eventName", "Corn")).andReturn(constructs);
      replay(querySet);

      richRequest.load(request);

      verify(querySet);
       String[] constructsRead = richRequest.getConstructs();
       assertThat(constructsRead.length, is(1));
      assertThat(constructsRead[0],is(construct));
   }
   @Test
   public void testLoad_GetConstructsIgnoresNull()
      throws Exception
   {
       String construct = null;
       String[] constructs = new String[]{construct};
      Crop crop = new Crop();
      crop.setCropName("Corn");
      request.setEventName("eventName");
      request.setCropPubkey("cropPubkey");

      expect(querySet.findCropByPubkey("cropPubkey")).andReturn(crop);
      expect(querySet.findConstructsByEventAndCrop("eventName", "Corn")).andReturn(constructs);
      replay(querySet);

      richRequest.load(request);

      verify(querySet);
       String[] constructsRead = richRequest.getConstructs();
       assertThat(constructsRead.length, is(0));
   }
   @Test
   public void testLoad_GetConstructsIgnoresBlank()
      throws Exception
   {
       String construct = " ";
       String[] constructs = new String[]{construct};
      Crop crop = new Crop();
      crop.setCropName("Corn");
      request.setEventName("eventName");
      request.setCropPubkey("cropPubkey");

      expect(querySet.findCropByPubkey("cropPubkey")).andReturn(crop);
      expect(querySet.findConstructsByEventAndCrop("eventName", "Corn")).andReturn(constructs);
      replay(querySet);

      richRequest.load(request);

      verify(querySet);
       String[] constructsRead = richRequest.getConstructs();
       assertThat(constructsRead.length, is(0));
   }
   @Test
   public void testLoad_GetConstructs_RequestHasConstruct()
      throws Exception
   {
      String constuct = "CONSTRUCTVALUE";
      String[] constructs = new String[]{constuct};
      request.setConstruct(constuct);
      replay(querySet);

      richRequest.load(request);

      verify(querySet);
      assertThat(richRequest.getConstructs(), is(constructs));
   }


   @Test
   public void testLoad_GetConstructs_InvalidCrop()
      throws Exception
   {
      String[] constructs = new String[0];
      request.setEventName("eventName");
      request.setCropPubkey("invalidCropPubkey");

      expect(querySet.findCropByPubkey("invalidCropPubkey")).andReturn(null);
      expect(querySet.findConstructsByEventAndCrop("eventName", null)).andReturn(constructs);
      replay(querySet);

      richRequest.load(request);

      verify(querySet);
      assertThat(richRequest.getConstructs(), is(constructs));
   }

   @Test
   public void testLoad_GetProteinNames()
      throws Exception
   {
      Collection<ProteinName> proteinNames = new ArrayList<ProteinName>();
      String[] proteinNamePubkeys = {"A", "B", "C"};
      request.setProteinPubkeys(proteinNamePubkeys);
      expect(querySet.findProteinNamesByPubkeys(proteinNamePubkeys)).andReturn(proteinNames);
      expect(querySet.findConstructsByEventAndCrop((String)anyObject(), (String)anyObject())).andReturn(new String[0]);       
      replay(querySet);

      richRequest.load(request);

      verify(querySet);
      assertThat(richRequest.getProteinNames(), is(proteinNames));
   }

   @Test
   public void testLoad_GetComlTraitNames()
      throws Exception
   {
      Collection<ComlTraitName> comlTraitNames = new ArrayList<ComlTraitName>();
      String[] traitNameAbbrevations = {"A", "B", "C"};
      request.setTraitNameAbbreviations(traitNameAbbrevations);
      expect(querySet.findRegulatoryTraitNamesByAbbrs(traitNameAbbrevations)).andReturn(comlTraitNames);
      expect(querySet.findConstructsByEventAndCrop((String)anyObject(), (String)anyObject())).andReturn(new String[0]);       
      replay(querySet);

      richRequest.load(request);

      verify(querySet);
      assertThat(richRequest.getComlTraitNames(), is(comlTraitNames));
   }

   @Test
   public void testLoad_GetComlTraitTypes()
      throws Exception
   {
      Collection<ComlTraitType> comlTraitTypes = new ArrayList<ComlTraitType>();
      String[] traitTypeAbbrevations = {"A", "B", "C"};
      request.setTraitTypeAbbreviations(traitTypeAbbrevations);
      expect(querySet.findRegulatoryTraitTypesByAbbrs(traitTypeAbbrevations)).andReturn(comlTraitTypes);
      expect(querySet.findConstructsByEventAndCrop((String)anyObject(), (String)anyObject())).andReturn(new String[0]);       
      replay(querySet);

      richRequest.load(request);

      verify(querySet);
      assertThat(richRequest.getComlTraitTypes(), is(comlTraitTypes));
   }

   @Test
   public void testLoad_GetExistingNonMonEvent()
      throws Exception
   {
      NonMonEvent event = new NonMonEvent();
      request.setEventName("eventName");
      request.setCropPubkey("cropPubkey");
      expect(querySet.findNonMonEventByEventAndCrop("eventName", "cropPubkey")).andReturn(event);
      expect(querySet.findConstructsByEventAndCrop((String)anyObject(), (String)anyObject())).andReturn(new String[0]);
      replay(querySet);

      richRequest.load(request);

      verify(querySet);
      assertThat(richRequest.getExistingNonMonEvent(), is(event));
   }

   @Test
   public void testLoad_GetEventName()
      throws Exception
   {
      request.setEventName("eventName");
      expect(querySet.findConstructsByEventAndCrop((String)anyObject(), (String)anyObject())).andReturn(new String[0]);       
      replay(querySet);

      richRequest.load(request);

      verify(querySet);
      assertThat(richRequest.getEventName(), is("eventName"));
   }
}
