package com.monsanto.tps.lexicon.regulatory.event.delegate;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Crop;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;
import com.monsanto.tps.lexicon.regulatory.event.queryset.EventCrop;
import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

/**
 * rrchak1 - Feb 11, 2009 3:51:52 PM
 */
public class EventAgencyAlignments_UT {
    private static final String EVENT = "someEvent";
    private static final String EVENTTWO = "EVENTTWO";
    private EventCrop eventCrop;

    @Test
    public void getUniqueEventsAndAssociatedAlignments_OneAlignmentForOneEventCrop() {
        EventAgencyAlignment alignmentOne = new EventAgencyAlignment();
        alignmentOne.setMaterialName(EVENT);
        Crop crop = new Crop();
        crop.setCropName("CORN");
        alignmentOne.setCrop(crop);
        eventCrop = new EventCrop(EVENT, crop.getCropName());
        EventAgencyAlignment[] alignments = new EventAgencyAlignment[]{alignmentOne};
        EventAgencyAlignments eventAgencyAlignments = new EventAgencyAlignments(alignments);
        Map eventAlignmentMap = eventAgencyAlignments.getUniqueEventsAndAssociatedAlignments();
        Assert.assertFalse(eventAlignmentMap.isEmpty());
        Assert.assertTrue(eventAlignmentMap.size() == 1);
        Assert.assertTrue(eventAlignmentMap.containsKey(eventCrop));
        Collection alignmentList = (ArrayList) eventAlignmentMap.get(eventCrop);
        Assert.assertTrue(alignmentList.size() == 1);
    }

    @Test
    public void getUniqueEventsAndAssociatedAlignments_MultipleAlignmentsForSameEvent() {
        EventAgencyAlignment alignmentOne = new EventAgencyAlignment();
        alignmentOne.setMaterialName(EVENT);
        Crop crop = new Crop();
        crop.setCropName("CORN");
        alignmentOne.setCrop(crop);
        EventAgencyAlignment alignmentTwo = new EventAgencyAlignment();
        alignmentTwo.setMaterialName(EVENT);
        alignmentTwo.setCrop(crop);
        eventCrop = new EventCrop(EVENT, crop.getCropName());
        EventAgencyAlignment[] alignments = new EventAgencyAlignment[]{alignmentOne, alignmentTwo};
        EventAgencyAlignments eventAgencyAlignments = new EventAgencyAlignments(alignments);
        Map eventAlignmentMap = eventAgencyAlignments.getUniqueEventsAndAssociatedAlignments();
        Assert.assertFalse(eventAlignmentMap.isEmpty());
        Assert.assertTrue(eventAlignmentMap.size() == 1);
        Assert.assertTrue(eventAlignmentMap.containsKey(eventCrop));
        Collection alignmentList = (ArrayList) eventAlignmentMap.get(eventCrop);
        Assert.assertTrue(alignmentList.size() == 2);
    }

    @Test
    public void getUniqueEventsAndAssociatedAlignments_MultipleAlignmentsForMultipleEvents() {
        EventAgencyAlignment alignmentOne = new EventAgencyAlignment();
        alignmentOne.setMaterialName(EVENT);
        Crop crop = new Crop();
        crop.setCropName("CORN");
        alignmentOne.setCrop(crop);
        EventAgencyAlignment alignmentTwo = new EventAgencyAlignment();
        alignmentTwo.setMaterialName(EVENTTWO);
        Crop cropTwo = new Crop();
        cropTwo.setCropName("CORN");
        alignmentTwo.setCrop(crop);
        EventAgencyAlignment alignmentThree = new EventAgencyAlignment();
        alignmentThree.setMaterialName(EVENTTWO);
        alignmentThree.setCrop(crop);
        eventCrop = new EventCrop(EVENT, crop.getCropName());
        EventCrop eventCropTwo = new EventCrop(EVENTTWO, cropTwo.getCropName());
        EventAgencyAlignment[] alignments = new EventAgencyAlignment[]{alignmentOne, alignmentTwo, alignmentThree};
        EventAgencyAlignments eventAgencyAlignments = new EventAgencyAlignments(alignments);
        Map eventAlignmentMap = eventAgencyAlignments.getUniqueEventsAndAssociatedAlignments();
        Assert.assertFalse(eventAlignmentMap.isEmpty());
        Assert.assertTrue(eventAlignmentMap.size() == 2);
        Assert.assertTrue(eventAlignmentMap.containsKey(eventCrop));
        Assert.assertTrue(eventAlignmentMap.containsKey(eventCropTwo));
        Collection alignmentList = (ArrayList) eventAlignmentMap.get(eventCrop);
        Assert.assertTrue(alignmentList.size() == 1);
        Collection alignmentListTwo = (ArrayList) eventAlignmentMap.get(eventCropTwo);
        Assert.assertTrue(alignmentListTwo.size() == 2);

    }
}
