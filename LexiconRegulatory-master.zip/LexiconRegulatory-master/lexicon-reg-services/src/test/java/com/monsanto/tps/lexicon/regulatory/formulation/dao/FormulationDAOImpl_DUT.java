package com.monsanto.tps.lexicon.regulatory.formulation.dao;

import com.monsanto.tps.lexicon.formulation.OrionFormulation;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.DBUnitTest;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.FormulationType;
import com.monsanto.tps.lexicon.regulatory.formulation.dao.FormulationDAO;
import com.monsanto.tps.springframework.test.listener.dbunit.DataSet;
import com.monsanto.tps.springframework.test.listener.dbunit.DatasetOperation;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.Comparator;
import java.util.List;

import static com.google.common.collect.Ordering.from;
import static org.junit.Assert.*;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 3/5/12
 * Time: 1:52 PM
 * To change this template use File | Settings | File Templates.
 */
@DataSet(
        schema = "LEXICON", dataSourceKey = "dataSource", setupOperation = DatasetOperation.CLEAN_INSERT, teardownOperation = DatasetOperation.NONE,
        value = {"/com/monsanto/tps/lexicon/regulatory/formulation/dao/formulation_type.xml"}
)
public class FormulationDAOImpl_DUT extends DBUnitTest{

    @Autowired
    private FormulationDAO formulationDAO;

    @Test
    public void findFormulationTypes_results_wildcard() throws Exception {
        final List<FormulationType> formulations = formulationDAO.findFormulationTypes("S%");
        assertNotNull(formulations);
        assertFalse(formulations.isEmpty());
    }

    @Test
    public void findFormulationTypes_results_exactMatch() throws Exception {
        final List<FormulationType> formulations = formulationDAO.findFormulationTypes("TB");
        assertNotNull(formulations);
        assertFalse(formulations.isEmpty());
    }

    @Test
    public void findFormulationTypes_noResults() throws Exception {
        final List<FormulationType> formulations = formulationDAO.findFormulationTypes("asdf");
        assertNotNull(formulations);
        assertTrue(formulations.isEmpty());
    }

    @Test
    public void findFormulationTypes_results_active() throws Exception {
        final List<FormulationType> formulations = formulationDAO.findFormulationTypes("");
        assertNotNull(formulations);
        assertFalse(formulations.isEmpty());
        
        for(FormulationType formulation : formulations) {
            assertTrue(formulation.getActiveStatus());
        }
    }   
    
    @Test
    public void findFormulationTypes_sorted() throws Exception {
        final List<FormulationType> formulations = formulationDAO.findFormulationTypes("%");
        assertNotNull(formulations);

        assertTrue(from(new FormulationComparator()).isOrdered(formulations));
    }

    private class FormulationComparator implements Comparator<FormulationType> {

        public final int compare(FormulationType c1, FormulationType c2) {

            int ctCompare = 0;

            if (c1 != null && c2 != null) {
                String ct1 = c1.getFormulationType();
                String ct2 = c2.getFormulationType();
                if (ct1 != null && ct2 != null) {
                    ctCompare = ct1.compareToIgnoreCase(ct2);
                }
            }

            return ctCompare;
        }
    }
}



