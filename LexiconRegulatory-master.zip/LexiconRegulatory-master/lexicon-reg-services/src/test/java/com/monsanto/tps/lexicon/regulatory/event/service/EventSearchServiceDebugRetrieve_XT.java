package com.monsanto.tps.lexicon.regulatory.event.service;

import com.monsanto.tps.lexicon.event.Construct;
import com.monsanto.tps.lexicon.event.EventComponent;
import com.monsanto.tps.lexicon.event.EventInfo;
import com.monsanto.tps.lexicon.event.EventSearchService;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.LexiconAcceptanceTestCase;
import org.junit.Test;

import javax.annotation.Resource;

/**
 * Created by IntelliJ IDEA.
 * User: athanga
 * Date: 11/9/11
 * Time: 9:54 AM
 */
public class EventSearchServiceDebugRetrieve_XT extends LexiconAcceptanceTestCase {

    @Resource
    private EventSearchService eventSearchService;

    @Test
    public void testFindExistingEventsToHelpDebugging() throws Exception{
        EventInfo[] eventInfoArray = eventSearchService.findByEventsAndCrop(new String[]{"LY038,MON810"}, "Corn");
        System.out.println("eventInfoArray = " + eventInfoArray);
        for (EventInfo eventInfo : eventInfoArray) {
            EventComponent[] eventComponents = eventInfo.getEventComponents();
            System.out.println("eventInfo.getEventComponents() = " + eventComponents);
            for (EventComponent eventComponent : eventComponents) {
                System.out.println("eventComponent.getEventName() = " + eventComponent.getEventName());
                System.out.println("eventComponent.getMonNumber() = " + eventComponent.getMonNumber());
                Construct[] constructs = eventComponent.getConstructs();
                System.out.println("eventComponent.getConstructs() = " + constructs);
                for (Construct construct : constructs) {
                    System.out.println("construct.getPlasmidPMon() = " + construct.getPlasmidPMon());
                    System.out.println("construct.getPlasmidPVCode() = " + construct.getPlasmidPVCode());
                }
            }
        }
    }
}
