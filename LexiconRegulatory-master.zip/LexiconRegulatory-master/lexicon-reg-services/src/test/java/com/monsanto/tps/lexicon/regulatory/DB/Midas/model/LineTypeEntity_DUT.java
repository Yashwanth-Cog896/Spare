/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.DB.Midas.model;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.HibernateAssertTestUtil;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.LexiconAcceptanceTestCase;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.TestDataBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.midas.model.LineTypeEntity;
import org.junit.Test;

import static junit.framework.Assert.assertFalse;

/* vvkalu - 7/25/11 */
public class LineTypeEntity_DUT extends LexiconAcceptanceTestCase {

    @Test
    public void testMapping() throws Exception {
        LineTypeEntity lineTypeEntity = TestDataBuilder.buildLineType(currentSession);
        currentSession.save(lineTypeEntity);
        currentSession.flush();
        currentSession.clear();

        LineTypeEntity dbEntity = (LineTypeEntity) currentSession.load(LineTypeEntity.class, lineTypeEntity.getId());
        assertFalse(lineTypeEntity == dbEntity);
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(lineTypeEntity, dbEntity);
    }
}