package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumberConstruct;
import org.hibernate.Session;

/**
 * Created by IntelliJ IDEA.
 * User: gdleon
 * Date: Apr 21, 2009
 * Time: 2:16:34 PM
 * To change this template use File | Settings | File Templates.
 */
public class MonNumberConstructBuilder
{
   private MonNumberConstruct monNumberConstruct;
   private final BuilderID builderID = new BuilderID();

   public MonNumberConstructBuilder() {
      monNumberConstruct = new MonNumberConstruct();
      monNumberConstruct.setMonNumberConstructId(builderID.id());
      monNumberConstruct.setConstructName("CON_NAME");
      monNumberConstruct.setPvCode("PV_CODE");
   }

   public MonNumberConstruct create(MonNumber monNumber) {
      monNumberConstruct.setMonNumber(monNumber);
      Session session = TestSessions.getLexiconSession();
      session.save(monNumberConstruct);
      return monNumberConstruct;
   }

   public MonNumberConstructBuilder withConstructName(String constructName) {
      this.monNumberConstruct.setConstructName(constructName);
      return this;
   }

   public MonNumberConstructBuilder withPvCode(String pvCode) {
      this.monNumberConstruct.setPvCode(pvCode);
      return this;
   }

   public MonNumberConstruct createObj(MonNumber monNumber) {
      monNumberConstruct.setMonNumber(monNumber);
      return monNumberConstruct;
   }
}
