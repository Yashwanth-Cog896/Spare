package com.monsanto.tps.lexicon.regulatory.nonmonevent.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Crop;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName;
import com.monsanto.tps.lexicon.regulatory.crop.dao.CropDao;
import static org.easymock.classextension.EasyMock.*;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;

/**
 * nbwald - May 21, 2009 8:17:15 PM
 */
public class NonMonEventPersistQuerySet_UT
{
   private CropDao cropDao;
   private ProteinNameDao proteinNameDao;
   private ComlTraitNameDao comlTraitNameDao;
   private ComlTraitTypeDao comlTraitTypeDao;
   private NonMonEventDao nonMonEventDao;
   private NonMonEventPersistQuerySet querySet;

   @Before
   public void before()
      throws Exception
   {
      cropDao = createMock(CropDao.class);
      proteinNameDao = createMock(ProteinNameDao.class);
      comlTraitNameDao = createMock(ComlTraitNameDao.class);
      comlTraitTypeDao = createMock(ComlTraitTypeDao.class);
      nonMonEventDao = createMock(NonMonEventDao.class);
      querySet = new NonMonEventPersistQuerySet(cropDao, proteinNameDao, comlTraitNameDao, comlTraitTypeDao, nonMonEventDao);
   }

   @Test
   public void testFindCropByPubkey()
      throws Exception
   {
      Crop crop = new Crop();
      expect(cropDao.findByPubkey("cropPubkey")).andReturn(crop);
      replay(cropDao);

      assertThat(querySet.findCropByPubkey("cropPubkey"), is(crop));

      verify(cropDao);
   }

   @Test
   public void testFindProteinNamesByPubkeys()
      throws Exception
   {
      Collection<ProteinName> proteinNames = new ArrayList<ProteinName>();
      String[] proteinNamePubkeys = {"A", "B", "C"};
      expect(proteinNameDao.findByPubkeys(proteinNamePubkeys)).andReturn(proteinNames);
      replay(proteinNameDao);

      assertThat(querySet.findProteinNamesByPubkeys(proteinNamePubkeys), is(proteinNames));

      verify(proteinNameDao);
   }

   @Test
   public void testFindRegulatoryTraitNamesByAbbrs()
      throws Exception
   {
      Collection<ComlTraitName> comlTraitNames = new ArrayList<ComlTraitName>();
      String[] comlTraitNameAbbrs = {"A", "B", "C"};
      expect(comlTraitNameDao.findByAbbrs(comlTraitNameAbbrs)).andReturn(comlTraitNames);
      replay(comlTraitNameDao);

      assertThat(querySet.findRegulatoryTraitNamesByAbbrs(comlTraitNameAbbrs), is(comlTraitNames));

      verify(comlTraitNameDao);
   }

   @Test
   public void testFindRegulatoryTraitTypesByAbbrs()
      throws Exception
   {
      Collection<ComlTraitType> comlTraitTypes = new ArrayList<ComlTraitType>();
      String[] comlTraitTypeAbbrs = {"A", "B", "C"};
      expect(comlTraitTypeDao.findByAbbrs(comlTraitTypeAbbrs)).andReturn(comlTraitTypes);
      replay(comlTraitTypeDao);

      assertThat(querySet.findRegulatoryTraitTypesByAbbrs(comlTraitTypeAbbrs), is(comlTraitTypes));

      verify(comlTraitTypeDao);
   }

   @Test
   public void testFindNonMonEventByEventAndCrop()
      throws Exception
   {
      NonMonEvent event = new NonMonEvent();
      String eventName = "eventName";
      String cropPubkey = "cropPubkey";
      expect(nonMonEventDao.findByNonMonEventAndCrop(eventName, cropPubkey)).andReturn(new NonMonEvent[]{event});
      replay(nonMonEventDao);

      assertThat(querySet.findNonMonEventByEventAndCrop(eventName, cropPubkey), is(event));

      verify(nonMonEventDao);
   }
}
