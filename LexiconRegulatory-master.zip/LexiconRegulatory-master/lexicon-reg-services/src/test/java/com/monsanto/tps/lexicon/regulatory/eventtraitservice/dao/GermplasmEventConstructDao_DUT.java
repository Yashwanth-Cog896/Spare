/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.eventtraitservice.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.LexiconAcceptanceTestCase;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.TestDataBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.midas.model.EventConstructEntity;
import com.monsanto.tps.lexicon.regulatory.DB.midas.model.GermplasmEntity;
import com.monsanto.tps.lexicon.regulatory.DB.midas.model.GermplasmEventConstructEntity;
import com.monsanto.tps.lexicon.regulatory.DB.midas.model.ProductGermplasmEntity;
import org.junit.Test;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertTrue;

/* vvkalu - 8/15/11 */
public class GermplasmEventConstructDao_DUT extends LexiconAcceptanceTestCase {

    @Resource
    private GermplasmEventConstructDao germplasmEventConstructDao;

    @Test
    public void test_findGermplasmEventConstructs_ReturnsNull() throws Exception {
        List<GermplasmEventConstructEntity> germplasmEventConstructs = germplasmEventConstructDao
                .findGermplasmEventConstructs(TestDataBuilder.generateRandomNegativeLong());
        assertTrue(germplasmEventConstructs.isEmpty());
    }

    @Test
    public void test_findGermplasmEventConstructs() throws Exception {
        GermplasmEntity germplasm = new GermplasmEntity();
        Long germplasmId = TestDataBuilder.generateRandomNegativeLong();
        germplasm.setId(germplasmId);
        germplasm.setEventDisplay(TestDataBuilder.generateRandomNumberString(20));
        germplasm.setDeleted(false);
        germplasm.setFinished(true);
        germplasm.setLinecode(TestDataBuilder.generateRandomNumberString(50));
        germplasm.setLineType(TestDataBuilder.buildLineType(currentSession));
        germplasm.setCrop(TestDataBuilder.buildMidasCrop(currentSession));
        germplasm.setOrigin(TestDataBuilder.generateRandomNumberString(50));
        germplasm.setOwnerProgram(TestDataBuilder.buildProgramEntity(currentSession));
        germplasm.setPedigree(TestDataBuilder.generateRandomNumberString(100));
        germplasm.setTransgenic(true);
        germplasm.setProductGermplasms(new ArrayList<ProductGermplasmEntity>());

        EventConstructEntity constructEntity = new EventConstructEntity();
        constructEntity.setId(TestDataBuilder.generateRandomNegativeLong());
        constructEntity.setBarcode(TestDataBuilder.generateRandomNumberString(50));
        constructEntity.setCrop(TestDataBuilder.buildMidasCrop(currentSession));
        constructEntity.setConstructName(TestDataBuilder.generateRandomNumberString(200));
        constructEntity.setEventName(TestDataBuilder.generateRandomNumberString(50));
        constructEntity.setRefActive(true);
        constructEntity.setName(TestDataBuilder.generateRandomNumberString(80));

        EventConstructEntity constructEntity1 = new EventConstructEntity();
        constructEntity1.setId(TestDataBuilder.generateRandomNegativeLong());
        constructEntity1.setBarcode(TestDataBuilder.generateRandomNumberString(50));
        constructEntity1.setCrop(TestDataBuilder.buildMidasCrop(currentSession));
        constructEntity1.setConstructName(TestDataBuilder.generateRandomNumberString(200));
        constructEntity1.setEventName(TestDataBuilder.generateRandomNumberString(50));
        constructEntity1.setRefActive(true);
        constructEntity1.setName(TestDataBuilder.generateRandomNumberString(80));

        GermplasmEventConstructEntity germplasmEventConstructEntity = new GermplasmEventConstructEntity();
        germplasmEventConstructEntity.setEventConstruct(constructEntity);
        germplasmEventConstructEntity.setGermplasm(germplasm);
        germplasmEventConstructEntity.setId(TestDataBuilder.generateRandomNegativeLong());

        GermplasmEventConstructEntity germplasmEventConstructEntity1 = new GermplasmEventConstructEntity();
        germplasmEventConstructEntity1.setEventConstruct(constructEntity1);
        germplasmEventConstructEntity1.setGermplasm(germplasm);
        germplasmEventConstructEntity1.setId(TestDataBuilder.generateRandomNegativeLong());

        currentSession.save(constructEntity);
        currentSession.save(constructEntity1);
        currentSession.save(germplasm);
        currentSession.save(germplasmEventConstructEntity);
        currentSession.save(germplasmEventConstructEntity1);

        currentSession.flush();
        currentSession.clear();

        List<GermplasmEventConstructEntity> germplasmEventConstructs = germplasmEventConstructDao.findGermplasmEventConstructs(germplasmId);
        assertEquals(2, germplasmEventConstructs.size());
    }
}