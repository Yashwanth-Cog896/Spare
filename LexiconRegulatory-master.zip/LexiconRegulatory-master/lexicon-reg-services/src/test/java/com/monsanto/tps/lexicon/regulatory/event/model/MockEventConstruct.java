package com.monsanto.tps.lexicon.regulatory.event.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
/**
 * User: pjberry
 * Date: Jul 30, 2007
 * Time: 5:00:48 PM
 */
public class MockEventConstruct
   implements EventConstruct
{
   private String crop;
   private String event;
   private String construct;
   private String transformationBackground;
   private List<String> transCodes = new ArrayList<String>();

   public MockEventConstruct() {
   }

   public MockEventConstruct(String event, String crop) {
      this.event = event;
      this.crop=crop;
   }

   public MockEventConstruct(String event,String crop, String construct) {
      this(event,crop);
      this.construct = construct;
   }

   public String getEvent() {
      return event;
   }

   public void setEvent(String event) {
      this.event = event;
   }

    public String getCrop() {
        return crop;
    }

    public String getConstruct() {
      return construct;
   }

   public void setConstruct(String construct) {
      this.construct = construct;
   }

   public String getTransformationBackground() {
      return transformationBackground;
   }

   public void setTransformationBackground(String transformationBackground) {
      this.transformationBackground = transformationBackground;
   }

   public String[] getTransCodes() {
      return transCodes.toArray(new String[transCodes.size()]);
   }

   public void addTransCode(String transCode) {
      transCodes.add(transCode);
   }

    public void setTransCodes(String []transCodes) {
        this.transCodes = new ArrayList(Arrays.asList(transCodes));
    }
}
