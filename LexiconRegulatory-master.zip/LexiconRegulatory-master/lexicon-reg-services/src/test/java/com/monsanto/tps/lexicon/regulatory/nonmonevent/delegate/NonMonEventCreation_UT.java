package com.monsanto.tps.lexicon.regulatory.nonmonevent.delegate;

import com.monsanto.tps.lexicon.nonmonevent.NonMonEventPersistRequest;
import com.monsanto.tps.lexicon.nonmonevent.NonMonEventPersistResponse;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.dao.NonMonEventDao;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.dao.NonMonEventPersistQuerySet;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.dao.StubNonMonEventPersistQuerySet;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.model.NonMonEventPersistRichRequest;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.validation.NonMonEventSaveValidation;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.validation.ValidationResults;
import org.easymock.classextension.EasyMock;
import static org.easymock.classextension.EasyMock.*;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;

/**
 * nbwald - May 22, 2009 5:55:44 PM
 */
public class NonMonEventCreation_UT
{
   private NonMonEventDao dao;
   private NonMonEventSaveValidation validation;
   private ValidationResults success;
   private ValidationResults failure;
   private NonMonEventPersistRequest request;
   private NonMonEventCreation creation;

   @Before
   public void before()
      throws Exception
   {
      dao = createMock(NonMonEventDao.class);
      validation = createNiceMock(NonMonEventSaveValidation.class);
      NonMonEventPersistQuerySet querySet = new StubNonMonEventPersistQuerySet();
      success = new ValidationResults(Collections.<String>emptyList(), Collections.<String>emptyList());
      failure = new ValidationResults(Arrays.asList("some error"), Collections.<String>emptyList());
      request = new NonMonEventPersistRequest();
      creation = new NonMonEventCreation();
      creation.setDao(dao);
      creation.setQuerySet(querySet);
      creation.setValidation(validation);
   }

   @Test
   public void testCreate_ValidateOnly_FailsValidation_DoesNotCreate_ReturnsFailure()
      throws Exception
   {
      expect(validation.validate(EasyMock.<NonMonEventPersistRichRequest>anyObject())).andReturn(failure);
      replay(dao, validation);

      NonMonEventPersistResponse response = creation.create(request, true);

      verify(dao, validation);
      assertThat(response.isSuccess(), is(false));
   }

   @Test
   public void testCreate_ValidateOnly_PassesValidation_DoesNotCreate_ReturnsSuccess()
      throws Exception
   {
      expect(validation.validate(EasyMock.<NonMonEventPersistRichRequest>anyObject())).andReturn(success);
      replay(dao, validation);

      NonMonEventPersistResponse response = creation.create(request, true);

      verify(dao, validation);
      assertThat(response.isSuccess(), is(true));
   }

   @Test
   public void testCreate_NotValidateOnly_FailsValidation_DoesNotCreate_ReturnsFailure()
      throws Exception
   {
      expect(validation.validate(EasyMock.<NonMonEventPersistRichRequest>anyObject())).andReturn(failure);
      replay(dao, validation);

      NonMonEventPersistResponse response = creation.create(request, false);

      verify(dao, validation);
      assertThat(response.isSuccess(), is(false));
   }

   @Test
   public void testCreate_NotValidateOnly_PassesValidation_Creates_ReturnsSuccess()
      throws Exception
   {
      expect(validation.validate(EasyMock.<NonMonEventPersistRichRequest>anyObject())).andReturn(success);
      dao.save(EasyMock.<NonMonEvent>anyObject());
      expectLastCall();
      replay(dao, validation);

      NonMonEventPersistResponse response = creation.create(request, false);

      verify(dao, validation);
      assertThat(response.isSuccess(), is(true));
   }
}
