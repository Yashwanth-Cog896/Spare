package com.monsanto.tps.lexicon.regulatory.event.model;

/**
 * User: pjberry
 * Date: Jul 27, 2007
 * Time: 3:10:32 PM
 */
public class MockRegulatoryEventConstructTransformation
   implements RegulatoryEventConstructTransformation
{
   private final String event;
   private final String construct;
   private final String transformationBackground;

   public MockRegulatoryEventConstructTransformation(String event, String construct, String transformationBackground) {
      this.event = event;
      this.construct = construct;
      this.transformationBackground = transformationBackground;
   }

   public String getEvent() {
      return event;
   }

   public String getConstruct() {
      return construct;
   }

   public String getTransformationBackground() {
      return transformationBackground;
   }
}
