package com.monsanto.tps.lexicon.regulatory.event.delegate;

import com.monsanto.tps.lexicon.event.Construct;
import com.monsanto.tps.lexicon.event.EventComponent;
import com.monsanto.tps.lexicon.event.EventInfo;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;
import com.monsanto.tps.lexicon.regulatory.event.model.EventConstruct;
import com.monsanto.tps.lexicon.regulatory.event.model.MockEventConstruct;
import com.monsanto.tps.lexicon.regulatory.event.model.RegulatoryEvent;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * nbwald - Jan 8, 2009 11:26:58 AM
 */
public class EventInfoBuilder_UT
{
   @Test
   public void testBuild()
      throws Exception
   {
      MockEventConstruct eventConstruct = new MockEventConstruct();
      String monNumberValue = "MON 1111";
      eventConstruct.setEvent("ZM_1111");
      eventConstruct.setConstruct("construct");
      eventConstruct.addTransCode("transcode");
      EventConstruct[] eventConstructs = new EventConstruct[]{eventConstruct};

      RegulatoryEvent event = new RegulatoryEvent(eventConstructs, monNumberValue, "ZM_1111");
      List<RegulatoryEvent> regulatoryEvents = new ArrayList<RegulatoryEvent>();
      regulatoryEvents.add(event);

      EventAgencyAlignment[] eventAgencies = {
         new EventAgencyAlignment(),
         new EventAgencyAlignment()
      };

      String cropName = "CORN";

      EventInfoBuilder builder = new EventInfoBuilder();
      EventInfo eventInfo = builder.build(regulatoryEvents, eventAgencies, cropName);

      assertThat(eventInfo.getCrop(), is(cropName));
      assertThat(eventInfo.getEventAgencies().length, is(eventAgencies.length));
      assertThat(eventInfo.getEventComponents().length, is(regulatoryEvents.size()));
      EventComponent[] eventComponents = eventInfo.getEventComponents();
      EventComponent eventComponent = eventComponents[0];
      assertThat(eventComponent.getEventName(), is(eventConstruct.getEvent()));
      assertThat(eventComponent.getMonNumber(), is(monNumberValue));
      Construct[] constructs = eventComponent.getConstructs();
      Construct construct = constructs[0];
      assertThat(construct.getPlasmidPMon(), is(eventConstruct.getConstruct()));
      assertThat(construct.getPlasmidPVCode(), is(eventConstruct.getTransCodes()[0]));
   }

   @Test
   public void testBuildWithMultipleRegulatoryEventsWithDifferentConstructs()
      throws Exception
   {
      MockEventConstruct eventConstruct = new MockEventConstruct();
      eventConstruct.setEvent("ZM_1111");
      eventConstruct.setConstruct("construct");
      eventConstruct.addTransCode("transcode");
      MockEventConstruct eventConstructTwo = new MockEventConstruct();
      eventConstructTwo.setEvent("ZM_1111");
      eventConstructTwo.setConstruct("constructTwo");
      eventConstructTwo.addTransCode("transCodeTwo");
      EventConstruct[] eventConstructs = {eventConstruct, eventConstructTwo};

      EventAgencyAlignment[] eventAgencies = {
         new EventAgencyAlignment(),
         new EventAgencyAlignment()
      };

      String cropName = "CORN";
      String monNumberValue = "MON 1111";

      RegulatoryEvent event = new RegulatoryEvent(eventConstructs, monNumberValue, "ZM_1111");
      List<RegulatoryEvent> eventList = new ArrayList<RegulatoryEvent>();
      eventList.add(event);

      EventInfoBuilder builder = new EventInfoBuilder();
      EventInfo eventInfo = builder.build(eventList, eventAgencies, cropName);

      assertThat(eventInfo.getCrop(), is(cropName));
      assertThat(eventInfo.getEventAgencies().length, is(eventAgencies.length));
      assertThat(eventInfo.getEventComponents().length, is(eventList.size()));
      EventComponent[] eventComponents = eventInfo.getEventComponents();
      EventComponent eventComponent = eventComponents[0];

      assertThat(eventComponent.getEventName(), is(eventConstruct.getEvent()));
      assertThat(eventComponent.getMonNumber(), is(monNumberValue));
      Construct[] constructs = eventComponent.getConstructs();
      assertThat(constructs.length, is(2));
      Construct constructOne = constructs[0];
      assertThat(constructOne.getPlasmidPMon(), is(eventConstruct.getConstruct()));
      assertThat(constructOne.getPlasmidPVCode(), is(eventConstruct.getTransCodes()[0]));
      Construct constructTwo = constructs[1];
      assertThat(constructTwo.getPlasmidPMon(), is(eventConstructTwo.getConstruct()));
      assertThat(constructTwo.getPlasmidPVCode(), is(eventConstructTwo.getTransCodes()[0]));
   }

   @Test
   public void testBuild_MultipleEvents_WithDifferentCase()
      throws Exception
   {
      EventInfoBuilder builder = new EventInfoBuilder();
      String monNumberValue = "MON 1111";
      EventConstruct[] eventConstructs = {
         new MockEventConstruct("zm_1111","CORN", "construct A"),
         new MockEventConstruct("zM_1111","CORN", "construct B"),
      };
      RegulatoryEvent event = new RegulatoryEvent(eventConstructs, monNumberValue, "ZM_1111");
      List<RegulatoryEvent> eventList = new ArrayList<RegulatoryEvent>();
      eventList.add(event);
      EventInfo eventInfo = builder.build(
         eventList,
         new EventAgencyAlignment[0], "CORN");

      assertThat(eventInfo.getEventComponents().length, is(eventList.size()));
      EventComponent[] eventComponents = eventInfo.getEventComponents();
      EventComponent eventComponent = eventComponents[0];

      assertThat(eventComponent.getEventName(), is("ZM_1111"));
      assertThat(eventComponent.getConstructs().length, is(2));
      assertThat(contains(eventComponent.getConstructs(), "construct A"), is(true));
      assertThat(contains(eventComponent.getConstructs(), "construct B"), is(true));
   }


   @Test
   public void testBuild_StackedEvents_WithDifferentConstructs()
      throws Exception
   {
      EventInfoBuilder builder = new EventInfoBuilder();
      String monNumberOne = "MON 1111";
      String monNumberTwo = "MON 1111";
      EventConstruct[] eventOneConstructs = {
         new MockEventConstruct("ZM_1111", "CORN","construct A")
      };
      EventConstruct[] eventTwoConstructs = {
         new MockEventConstruct("ZM_2345", "CORN","construct B"),
      };
      RegulatoryEvent eventOne = new RegulatoryEvent(eventOneConstructs, monNumberOne, "ZM_1111");
      RegulatoryEvent eventTwo = new RegulatoryEvent(eventTwoConstructs, monNumberTwo, "ZM_2345");

      List<RegulatoryEvent> eventList = new ArrayList<RegulatoryEvent>();
      eventList.add(eventOne);
      eventList.add(eventTwo);

      EventAgencyAlignment[] eventAgencies = {
         new EventAgencyAlignment(),
         new EventAgencyAlignment()
      };

      EventInfo eventInfo = builder.build(
         eventList,
         eventAgencies, "CORN");
      assertThat(eventInfo.getEventAgencies().length, is(eventAgencies.length));
      assertThat(eventInfo.getEventComponents().length, is(eventList.size()));
      EventComponent[] eventComponents = eventInfo.getEventComponents();
      EventComponent eventComponentOne = eventComponents[0];
      assertThat(eventComponentOne.getEventName(), is("ZM_1111"));
      assertThat(eventComponentOne.getConstructs().length, is(1));
      assertThat(contains(eventComponentOne.getConstructs(), "construct A"), is(true));
      EventComponent eventComponentTwo = eventComponents[1];
      assertThat(eventComponentTwo.getEventName(), is("ZM_2345"));
      assertThat(eventComponentTwo.getConstructs().length, is(1));
      assertThat(contains(eventComponentTwo.getConstructs(), "construct B"), is(true));

   }

   private boolean contains(Construct[] constructs, String constructName) {
      for (Construct construct : constructs) {
         if (constructName.equals(construct.getPlasmidPMon())) {
            return true;
         }
      }
      return false;
   }
}
