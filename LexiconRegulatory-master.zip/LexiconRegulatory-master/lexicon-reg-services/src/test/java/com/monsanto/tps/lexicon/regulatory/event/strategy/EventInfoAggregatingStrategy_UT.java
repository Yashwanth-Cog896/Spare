package com.monsanto.tps.lexicon.regulatory.event.strategy;

import com.monsanto.tps.lexicon.event.EventInfo;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import org.junit.Test;

/**
 * nbwald - Jan 30, 2009 1:56:34 PM
 */
public class EventInfoAggregatingStrategy_UT
{
   @Test
   public void testFindAll_EmptyAggregateParameters_ReturnsEmptyEventInfos()
      throws Exception
   {
      EventInfoAggregatingStrategy aggregator = new MockEventInfoAggregatingStrategy();

      EventInfo[] eventInfos = aggregator.findAll(new String[0]);

      assertThat(eventInfos.length, is(0));
   }

   @Test
   public void testFindAll_NullAggregateParameters_ReturnsEmptyEventInfos()
      throws Exception
   {
      EventInfoAggregatingStrategy aggregator = new MockEventInfoAggregatingStrategy();

      EventInfo[] eventInfos = aggregator.findAll(null);

      assertThat(eventInfos.length, is(0));
   }

   @Test
   public void testFindAll_MultipleAggregateParameters_EachAggregateParameterReturnsAnEventInfo_ReturnsSameNumberOfEventInfos()
      throws Exception
   {
      EventInfoAggregatingStrategy aggregator = new MockEventInfoAggregatingStrategy();

      EventInfo[] eventInfos = aggregator.findAll(new String[]{"A", "B", "C"});

      assertThat(eventInfos.length, is(3));
   }


   @Test
   public void testFindAll_MultipleAggregateParameters_NotAllAggregateParameterReturnsAnEventInfo_ReturnsNonNullEventInfos()
      throws Exception
   {
      EventInfoAggregatingStrategy aggregator = new MockEventInfoAggregatingStrategy();

      EventInfo[] eventInfos = aggregator.findAll(new String[]{"A", "NOT FOUND", "B"});

      assertThat(eventInfos.length, is(2));
   }

   private class MockEventInfoAggregatingStrategy
      extends EventInfoAggregatingStrategy
   {
      public EventInfo find(String aggregateParameter) {
         return "A".equals(aggregateParameter) || "B".equals(aggregateParameter) || "C".equals(aggregateParameter) ? new EventInfo() : null;
      }
   }
}
