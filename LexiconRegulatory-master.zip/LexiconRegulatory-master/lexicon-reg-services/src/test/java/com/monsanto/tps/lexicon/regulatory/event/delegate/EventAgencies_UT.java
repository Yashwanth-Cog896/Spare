package com.monsanto.tps.lexicon.regulatory.event.delegate;

import com.monsanto.dbdataservices.SQLUtil;
import com.monsanto.tps.lexicon.event.EventAgency;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Agency;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Country;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertNull;
import org.junit.Test;

import java.util.Date;

/**
 * nbwald - Jan 6, 2009 11:55:40 AM
 */
public class EventAgencies_UT
{
   @Test
   public void testGetResponseEventAgencies_NoModels_NoResponses()
      throws Exception
   {
      EventAgencyAlignment[] models = new EventAgencyAlignment[0];

      EventAgencies eventAgencies = new EventAgencies(models);
      EventAgency[] responses = eventAgencies.getResponseEventAgencies();

      assertThat(responses.length, is(0));
   }

   @Test
   public void testGetResponseEventAgencies_MultipleModels_SameNumberOfResponses()
      throws Exception
   {
      EventAgencyAlignment[] models = {
         new EventAgencyAlignment(),
         new EventAgencyAlignment(),
         new EventAgencyAlignment()
      };

      EventAgencies eventAgencies = new EventAgencies(models);
      EventAgency[] responses = eventAgencies.getResponseEventAgencies();

      assertThat(responses.length, is(models.length));
   }

   @Test
   public void testGetResponseEventAgencies_ValuesAreCopiedOver()
      throws Exception
   {
      Country country = new Country();
      country.setCountryName("United States of America");
      Agency agency = new Agency();
      agency.setCountry(country);
      agency.setAgencyAbbr("FDA");
      agency.setSurfaceAreaUomCode("Acres");

      EventAgencyAlignment model = new EventAgencyAlignment();
      model.setRegulated(SQLUtil.booleanToString(true));
      model.setAgency(agency);
      model.setDeregulatedEffectiveDate(new Date());
      model.setMaxQuantity(5.2);
      model.setEventAgencyAlignmentPubkey("123");
      EventAgencyAlignment[] models = {model};

      EventAgencies eventAgencies = new EventAgencies(models);
      EventAgency[] responses = eventAgencies.getResponseEventAgencies();

      assertThat(responses.length, is(1));
      EventAgency response = responses[0];
      assertThat(response.isRegulated(), is(true));
      assertThat(response.getAgencyAbbr(), is(model.getAgency().getAgencyAbbr()));
      assertThat(response.getCountryName(), is(model.getAgency().getCountry().getCountryName()));
      assertThat(response.getDeregulatedEffectiveDate(), is(model.getDeregulatedEffectiveDate()));
      assertThat(response.getMaxQuantity(), is(model.getMaxQuantity()));
      assertThat(response.getPublicKey(), is(model.getEventAgencyAlignmentPubkey()));
      assertThat(response.getSurfaceAreaUomCode(), is(model.getAgency().getSurfaceAreaUomCode()));
      assertNull(response.getDiscoveryMaterial());
   }

   @Test
   public void testGetResponseEventAgencies_Deregulated()
      throws Exception
   {
      EventAgencyAlignment model = new EventAgencyAlignment();
      model.setRegulated(SQLUtil.booleanToString(false));
      EventAgencyAlignment[] models = {model};

      EventAgencies eventAgencies = new EventAgencies(models);
      EventAgency[] responses = eventAgencies.getResponseEventAgencies();

      assertThat(responses.length, is(1));
      EventAgency response = responses[0];
      assertThat(response.isRegulated(), is(false));
   }
   @Test
   public void testGetResponseEventAgencies_DiscoveryMaterialSetFalse(){
      EventAgencyAlignment model = new EventAgencyAlignment();
      model.setDiscoveryMaterial(Boolean.FALSE);
      EventAgencyAlignment[] models = {model};

      EventAgencies eventAgencies = new EventAgencies(models);
      EventAgency[] responses = eventAgencies.getResponseEventAgencies();

      assertThat(responses.length, is(1));
      EventAgency response = responses[0];
      assertThat(response.getDiscoveryMaterial(), is(Boolean.FALSE));
   }
   @Test
   public void testGetResponseEventAgencies_DiscoveryMaterialSetTrue(){
      EventAgencyAlignment model = new EventAgencyAlignment();
      model.setDiscoveryMaterial(Boolean.TRUE);
      EventAgencyAlignment[] models = {model};

      EventAgencies eventAgencies = new EventAgencies(models);
      EventAgency[] responses = eventAgencies.getResponseEventAgencies();

      assertThat(responses.length, is(1));
      EventAgency response = responses[0];
      assertThat(response.getDiscoveryMaterial(), is(Boolean.TRUE));
   }
}
