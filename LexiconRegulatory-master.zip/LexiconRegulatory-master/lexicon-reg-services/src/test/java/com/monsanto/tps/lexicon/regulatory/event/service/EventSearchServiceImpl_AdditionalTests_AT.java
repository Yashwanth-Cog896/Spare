package com.monsanto.tps.lexicon.regulatory.event.service;

import com.monsanto.tps.lexicon.event.Construct;
import com.monsanto.tps.lexicon.event.EventAgency;
import com.monsanto.tps.lexicon.event.EventComponent;
import com.monsanto.tps.lexicon.event.EventInfo;
import com.monsanto.tps.lexicon.event.EventSearchService;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.AgencyBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.CropBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.EventAgencyAlignmentBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.LexiconAcceptanceTestCase;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.MonNumberBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber;
import com.monsanto.tps.lexicon.regulatory.DB.TestUtil.TPSTestConstants;
import com.monsanto.tps.lexicon.regulatory.DB.Tests.EventBuilder;
import org.apache.commons.lang.ArrayUtils;
import org.junit.After;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

import static org.junit.Assert.*;
/**
 * rrchak1 - Jul 14, 2009 2:14:20 PM
 */
@Transactional
public class EventSearchServiceImpl_AdditionalTests_AT
   extends LexiconAcceptanceTestCase
{

   @Resource
   private EventSearchService eventSearchService;

   private EventBuilder eventBuilder = new EventBuilder();
   private static final String EVENT_ONE = "AT_EVENT1";
   private static final String EVENT_TWO = "AT_EVENT2";
   private static final String EVENT_MIXED_CASE = "AT_eVeNtNaMe";
   private static final String CANOLA = "OSR-Canola";
   private static final String CANOLA_MIXED_CASE = "osr-caNola";
   private static final String STACKED_EVENT = "AT_EVENT1,AT_EVENT2";
   private static final String EVENT_THREE = "AT_EVENT3";
   private static final String REVERSED_STACKED_EVENT = "AT_EVENT2,AT_EVENT1";


   @Test 
 public void testSearchExactMatchStackedEvent_FindsEvent_MonNumber_AndAlignment()
      throws Exception
   {
      eventBuilder.setupConnections();
      eventBuilder.insertEvent(STACKED_EVENT);
      MonNumber monNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().withMonNumber("MON_1111").withEventName(STACKED_EVENT).withCrop(CropBuilder.canola()).createInDb();
         }
      });

      EventAgencyAlignment eventAgencyAlignment = insert(new AcceptanceTestData<EventAgencyAlignment>()
      {
         public EventAgencyAlignment dataToInsert() {
            return new EventAgencyAlignmentBuilder().
               withEvent(STACKED_EVENT).
               withAgency(AgencyBuilder.epa()).
               regulated().
               withMaxQuantity(10).
               withCrop(CropBuilder.canola()).
               create();
         }
      });

      EventInfo eventInfo = eventSearchService.findByEventAndCrop(STACKED_EVENT, CANOLA);

      assertNotNull(eventInfo);
      assertEquals(CANOLA, eventInfo.getCrop());
      assertFalse(ArrayUtils.isEmpty(eventInfo.getEventComponents()));
      EventComponent[] eventComponents = eventInfo.getEventComponents();
      EventComponent eventComponent = eventComponents[0];
      assertEquals(STACKED_EVENT, eventComponent.getEventName());
      Construct[] constructs = eventComponent.getConstructs();
      assertNotNull(constructs);
      assertEquals(1, constructs.length);
      Construct construct = constructs[0];
      assertEquals(TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_FCM_PVCODE, construct.getPlasmidPMon());
      assertEquals(TPSTestConstants.PV_CODE_FOR_EVENT_SINGLE_PMON_CONSTRUCT, construct.getPlasmidPVCode());
      assertEquals(monNumber.getMonNumber(), eventComponent.getMonNumber());
      assertFalse(ArrayUtils.isEmpty(eventInfo.getEventAgencies()));
      assertEquals(1, eventInfo.getEventAgencies().length);
      EventAgency actual = eventInfo.getEventAgencies()[0];
      assertEquals(eventAgencyAlignment.getEventAgencyAlignmentPubkey(), actual.getPublicKey());
      assertEquals("United States of America", actual.getCountryName());
      assertEquals("EPA", actual.getAgencyAbbr());
      assertTrue(actual.isRegulated());
      assertEquals(eventAgencyAlignment.getDeregulatedEffectiveDate(), actual.getDeregulatedEffectiveDate());
      assertEquals(eventAgencyAlignment.getAgency().getSurfaceAreaUomCode(), actual.getSurfaceAreaUomCode());
      assertEquals((Double)10D, actual.getMaxQuantity());
      eventBuilder.tearDownConnections();
   }

   @Test 
 public void testSearchExactMatchStackedEvent_DoesNotFindEvent_ForNonExistent()
      throws Exception
   {

      EventInfo eventInfo = eventSearchService.findByEventAndCrop(STACKED_EVENT, CANOLA);

      assertNull(eventInfo);
   }

   @Test
   @Ignore
   //Won't work anymore because this test uses the Midas.GERMPLASM_SORTED_EVENTS_MV which will not get updated from the inserted data.
 public void testSearchStackedEvent_EventsBelongToSameGermplasmAndGermplasmHasOnlyTheseEvents_ReturnsEvent_MonNumberAndAlignment()
      throws Exception
   {
      eventBuilder.setupConnections();
      eventBuilder.insertGermplasm(TPSTestConstants.GERMPLASM_ID_ONE);
      eventBuilder.insertEventConstruct(EVENT_ONE, TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_FCM_PVCODE, TPSTestConstants.MIDAS_CANOLA_ID, TPSTestConstants.EVENT_CONSTRUCT_ID_ONE);
      eventBuilder.insertEventConstruct(EVENT_TWO, TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_MULTIPLE_FCM_PVCODES, TPSTestConstants.MIDAS_CANOLA_ID, TPSTestConstants.EVENT_CONSTRUCT_ID_TWO);
      eventBuilder.insertGermplasmEventConstruct(TPSTestConstants.GERMPLASM_ID_ONE, TPSTestConstants.EVENT_CONSTRUCT_ID_ONE, TPSTestConstants.GERMPLASM_EVENT_CONSTRUCT_ID_ONE);
      eventBuilder.insertGermplasmEventConstruct(TPSTestConstants.GERMPLASM_ID_ONE, TPSTestConstants.EVENT_CONSTRUCT_ID_TWO, TPSTestConstants.GERMPLASM_EVENT_CONSTRUCT_ID_TWO);


      MonNumber monNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().withMonNumber("MON_1111").withEventName(EVENT_ONE).withCrop(CropBuilder.canola()).createInDb();
         }
      });

      MonNumber monNumberTwo = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().withMonNumber("MON_1222").withEventName(EVENT_TWO).withCrop(CropBuilder.canola()).withOecdNumber("OECD1111").createInDb();
         }
      });


      EventAgencyAlignment eventAgencyAlignment = insert(new AcceptanceTestData<EventAgencyAlignment>()
      {
         public EventAgencyAlignment dataToInsert() {
            return new EventAgencyAlignmentBuilder().
               withEvent(STACKED_EVENT).
               withAgency(AgencyBuilder.epa()).
               regulated().
               withMaxQuantity(10).
               withCrop(CropBuilder.canola()).
               create();
         }
      });

      EventInfo eventInfo = eventSearchService.findByEventAndCrop(STACKED_EVENT, CANOLA);

      assertNotNull(eventInfo);
      assertEquals(CANOLA, eventInfo.getCrop());

      assertFalse(ArrayUtils.isEmpty(eventInfo.getEventComponents()));
      EventComponent[] eventComponents = eventInfo.getEventComponents();
      assertFalse(ArrayUtils.isEmpty(eventComponents));
      assertEquals(2, eventComponents.length);
      EventComponent eventComponent = eventComponents[0];
      assertEquals(EVENT_ONE, eventComponent.getEventName());
      Construct[] constructs = eventComponent.getConstructs();
      assertNotNull(constructs);
      assertEquals(1, constructs.length);
      Construct construct = constructs[0];
      assertEquals(TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_FCM_PVCODE, construct.getPlasmidPMon());
      assertNull(construct.getPlasmidPVCode());
      assertEquals(monNumber.getMonNumber(), eventComponent.getMonNumber());
      assertFalse(ArrayUtils.isEmpty(eventInfo.getEventAgencies()));

      EventComponent eventComponentTwo = eventComponents[1];
      assertEquals(EVENT_TWO, eventComponentTwo.getEventName());
      Construct[] constructsTwo = eventComponentTwo.getConstructs();
      assertNotNull(constructsTwo);
      assertEquals(1, constructsTwo.length);
      Construct constructTwo = constructsTwo[0];
      assertEquals(TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_MULTIPLE_FCM_PVCODES, constructTwo.getPlasmidPMon());
      assertNull(constructTwo.getPlasmidPVCode());
      assertEquals(monNumberTwo.getMonNumber(), eventComponentTwo.getMonNumber());

      assertFalse(ArrayUtils.isEmpty(eventInfo.getEventAgencies()));
      assertEquals(1, eventInfo.getEventAgencies().length);
      EventAgency actual = eventInfo.getEventAgencies()[0];
      assertEquals(eventAgencyAlignment.getEventAgencyAlignmentPubkey(), actual.getPublicKey());
      assertEquals("United States of America", actual.getCountryName());
      assertEquals("EPA", actual.getAgencyAbbr());
      assertTrue(actual.isRegulated());
      assertEquals(eventAgencyAlignment.getDeregulatedEffectiveDate(), actual.getDeregulatedEffectiveDate());
      assertEquals(eventAgencyAlignment.getAgency().getSurfaceAreaUomCode(), actual.getSurfaceAreaUomCode());
      assertEquals((Double)10D, actual.getMaxQuantity());
      eventBuilder.tearDownConnections();
   }


   @Test 
 public void testStackedEvent_EventsBelongToSameGermplasmAndGermplasmHasMoreEvents_DoesNotReturnEvent()
      throws Exception
   {
      eventBuilder.setupConnections();
      eventBuilder.insertGermplasm(TPSTestConstants.GERMPLASM_ID_ONE);
      eventBuilder.insertEventConstruct(EVENT_ONE, TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_FCM_PVCODE, TPSTestConstants.MIDAS_CANOLA_ID, TPSTestConstants.EVENT_CONSTRUCT_ID_ONE);
      eventBuilder.insertEventConstruct(EVENT_TWO, TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_MULTIPLE_FCM_PVCODES, TPSTestConstants.MIDAS_CANOLA_ID, TPSTestConstants.EVENT_CONSTRUCT_ID_TWO);
      eventBuilder.insertEventConstruct(EVENT_THREE, "CONSTRUCT3", TPSTestConstants.MIDAS_CANOLA_ID, TPSTestConstants.EVENT_CONSTRUCT_ID_THREE);
      eventBuilder.insertGermplasmEventConstruct(TPSTestConstants.GERMPLASM_ID_ONE, TPSTestConstants.EVENT_CONSTRUCT_ID_ONE, TPSTestConstants.GERMPLASM_EVENT_CONSTRUCT_ID_ONE);
      eventBuilder.insertGermplasmEventConstruct(TPSTestConstants.GERMPLASM_ID_ONE, TPSTestConstants.EVENT_CONSTRUCT_ID_TWO, TPSTestConstants.GERMPLASM_EVENT_CONSTRUCT_ID_TWO);
      eventBuilder.insertGermplasmEventConstruct(TPSTestConstants.GERMPLASM_ID_ONE, TPSTestConstants.EVENT_CONSTRUCT_ID_THREE, TPSTestConstants.GERMPLASM_EVENT_CONSTRUCT_ID_THREE);

      EventInfo eventInfo = eventSearchService.findByEventAndCrop(STACKED_EVENT, CANOLA);

      assertNull(eventInfo);
      eventBuilder.tearDownConnections();
   }

   @Test 
 public void testStackedEvent_EventsBelongToSameGermplasmAndGermplasmHasOnlyOneEvent_DoesNotReturnEvent()
      throws Exception
   {
      eventBuilder.setupConnections();
      eventBuilder.insertGermplasm(TPSTestConstants.GERMPLASM_ID_ONE);
      eventBuilder.insertEventConstruct(EVENT_ONE, TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_FCM_PVCODE, TPSTestConstants.MIDAS_CANOLA_ID, TPSTestConstants.EVENT_CONSTRUCT_ID_ONE);
      eventBuilder.insertEventConstruct(EVENT_THREE, TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_MULTIPLE_FCM_PVCODES, TPSTestConstants.MIDAS_CANOLA_ID, TPSTestConstants.EVENT_CONSTRUCT_ID_THREE);
      eventBuilder.insertGermplasmEventConstruct(TPSTestConstants.GERMPLASM_ID_ONE, TPSTestConstants.EVENT_CONSTRUCT_ID_ONE, TPSTestConstants.GERMPLASM_EVENT_CONSTRUCT_ID_ONE);
      eventBuilder.insertGermplasmEventConstruct(TPSTestConstants.GERMPLASM_ID_ONE, TPSTestConstants.EVENT_CONSTRUCT_ID_THREE, TPSTestConstants.GERMPLASM_EVENT_CONSTRUCT_ID_THREE);

      EventInfo eventInfo = eventSearchService.findByEventAndCrop(STACKED_EVENT, CANOLA);

      assertNull(eventInfo);
      eventBuilder.tearDownConnections();
   }

   @Test 
 public void testStackedEvent_EventsBelongToDifferentGermplasms_DoesNotReturnEvent()
      throws Exception
   {
      eventBuilder.setupConnections();
      eventBuilder.insertGermplasm(TPSTestConstants.GERMPLASM_ID_ONE);
      eventBuilder.insertGermplasm(TPSTestConstants.GERMPLASM_ID_TWO);
      eventBuilder.insertEventConstruct(EVENT_ONE, TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_FCM_PVCODE, TPSTestConstants.MIDAS_CANOLA_ID, TPSTestConstants.EVENT_CONSTRUCT_ID_ONE);
      eventBuilder.insertEventConstruct(EVENT_TWO, TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_MULTIPLE_FCM_PVCODES, TPSTestConstants.MIDAS_CANOLA_ID, TPSTestConstants.EVENT_CONSTRUCT_ID_TWO);
      eventBuilder.insertGermplasmEventConstruct(TPSTestConstants.GERMPLASM_ID_ONE, TPSTestConstants.EVENT_CONSTRUCT_ID_ONE, TPSTestConstants.GERMPLASM_EVENT_CONSTRUCT_ID_ONE);
      eventBuilder.insertGermplasmEventConstruct(TPSTestConstants.GERMPLASM_ID_TWO, TPSTestConstants.EVENT_CONSTRUCT_ID_TWO, TPSTestConstants.GERMPLASM_EVENT_CONSTRUCT_ID_TWO);

      EventInfo eventInfo = eventSearchService.findByEventAndCrop(STACKED_EVENT, CANOLA);

      assertNull(eventInfo);
      eventBuilder.tearDownConnections();
   }

   @Test
   @Ignore
   //Won't work anymore because this test uses the Midas.GERMPLASM_SORTED_EVENTS_MV which will not get updated from the inserted data.
 public void testSearchReversedStackedEvent_EventsBelongToSameGermplasmAndGermplasmHasOnlyTheseEvents_ReturnsEvent_MonNumberAndAlignment()
      throws Exception
   {
      eventBuilder.setupConnections();
      eventBuilder.insertGermplasm(TPSTestConstants.GERMPLASM_ID_ONE);
      eventBuilder.insertEventConstruct(EVENT_ONE, TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_FCM_PVCODE, TPSTestConstants.MIDAS_CANOLA_ID, TPSTestConstants.EVENT_CONSTRUCT_ID_ONE);
      eventBuilder.insertEventConstruct(EVENT_TWO, TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_MULTIPLE_FCM_PVCODES, TPSTestConstants.MIDAS_CANOLA_ID, TPSTestConstants.EVENT_CONSTRUCT_ID_TWO);
      eventBuilder.insertGermplasmEventConstruct(TPSTestConstants.GERMPLASM_ID_ONE, TPSTestConstants.EVENT_CONSTRUCT_ID_ONE, TPSTestConstants.GERMPLASM_EVENT_CONSTRUCT_ID_ONE);
      eventBuilder.insertGermplasmEventConstruct(TPSTestConstants.GERMPLASM_ID_ONE, TPSTestConstants.EVENT_CONSTRUCT_ID_TWO, TPSTestConstants.GERMPLASM_EVENT_CONSTRUCT_ID_TWO);


      MonNumber monNumber = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().withMonNumber("MON_1111").withEventName(EVENT_ONE).withCrop(CropBuilder.canola()).createInDb();
         }
      });

      MonNumber monNumberTwo = insert(new AcceptanceTestData<MonNumber>()
      {
         public MonNumber dataToInsert() {
            return new MonNumberBuilder().withMonNumber("MON_1222").withEventName(EVENT_TWO).withCrop(CropBuilder.canola()).withOecdNumber("OECD1111").createInDb();
         }
      });


      EventAgencyAlignment eventAgencyAlignment = insert(new AcceptanceTestData<EventAgencyAlignment>()
      {
         public EventAgencyAlignment dataToInsert() {
            return new EventAgencyAlignmentBuilder().
               withEvent(STACKED_EVENT).
               withAgency(AgencyBuilder.epa()).
               regulated().
               withMaxQuantity(10).
               withCrop(CropBuilder.canola()).
               create();
         }
      });

      EventInfo eventInfo = eventSearchService.findByEventAndCrop(REVERSED_STACKED_EVENT, CANOLA);

      assertNotNull(eventInfo);
      assertEquals(CANOLA, eventInfo.getCrop());

      assertFalse(ArrayUtils.isEmpty(eventInfo.getEventComponents()));
      EventComponent[] eventComponents = eventInfo.getEventComponents();
      assertFalse(ArrayUtils.isEmpty(eventComponents));
      assertEquals(2, eventComponents.length);
      EventComponent eventComponent = eventComponents[0];
      assertEquals(EVENT_ONE, eventComponent.getEventName());
      Construct[] constructs = eventComponent.getConstructs();
      assertNotNull(constructs);
      assertEquals(1, constructs.length);
      Construct construct = constructs[0];
      assertEquals(TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_FCM_PVCODE, construct.getPlasmidPMon());
      assertNull(construct.getPlasmidPVCode());
      assertEquals(monNumber.getMonNumber(), eventComponent.getMonNumber());
      assertFalse(ArrayUtils.isEmpty(eventInfo.getEventAgencies()));

      EventComponent eventComponentTwo = eventComponents[1];
      assertEquals(EVENT_TWO, eventComponentTwo.getEventName());
      Construct[] constructsTwo = eventComponentTwo.getConstructs();
      assertNotNull(constructsTwo);
      assertEquals(1, constructsTwo.length);
      Construct constructTwo = constructsTwo[0];
      assertEquals(TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_MULTIPLE_FCM_PVCODES, constructTwo.getPlasmidPMon());
      assertNull(constructTwo.getPlasmidPVCode());
      assertEquals(monNumberTwo.getMonNumber(), eventComponentTwo.getMonNumber());

      assertFalse(ArrayUtils.isEmpty(eventInfo.getEventAgencies()));
      assertEquals(1, eventInfo.getEventAgencies().length);
      EventAgency actual = eventInfo.getEventAgencies()[0];
      assertEquals(eventAgencyAlignment.getEventAgencyAlignmentPubkey(), actual.getPublicKey());
      assertEquals("United States of America", actual.getCountryName());
      assertEquals("EPA", actual.getAgencyAbbr());
      assertTrue(actual.isRegulated());
      assertEquals(eventAgencyAlignment.getDeregulatedEffectiveDate(), actual.getDeregulatedEffectiveDate());
      assertEquals(eventAgencyAlignment.getAgency().getSurfaceAreaUomCode(), actual.getSurfaceAreaUomCode());
      assertEquals((Double)10D, actual.getMaxQuantity());
      eventBuilder.tearDownConnections();
   }


   @Test
   @Ignore
   //Won't work anymore because this test uses the Midas.GERMPLASM_SORTED_EVENTS_MV which will not get updated from the inserted data.
 public void testSearchStackedEvent_EventsBelongToMoreThanOneGermplasmAndGermplasmHasOnlyTheseEvents_ReturnsEvent()
      throws Exception
   {
      eventBuilder.setupConnections();
      eventBuilder.insertGermplasm(TPSTestConstants.GERMPLASM_ID_ONE);
      eventBuilder.insertGermplasm(TPSTestConstants.GERMPLASM_ID_TWO);
      eventBuilder.insertEventConstruct(EVENT_ONE, TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_FCM_PVCODE, TPSTestConstants.MIDAS_CANOLA_ID, TPSTestConstants.EVENT_CONSTRUCT_ID_ONE);
      eventBuilder.insertEventConstruct(EVENT_TWO, TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_MULTIPLE_FCM_PVCODES, TPSTestConstants.MIDAS_CANOLA_ID, TPSTestConstants.EVENT_CONSTRUCT_ID_TWO);
      eventBuilder.insertEventConstruct(EVENT_THREE, "CONSTRUCT3", TPSTestConstants.MIDAS_CANOLA_ID, TPSTestConstants.EVENT_CONSTRUCT_ID_THREE);

      eventBuilder.insertGermplasmEventConstruct(TPSTestConstants.GERMPLASM_ID_ONE, TPSTestConstants.EVENT_CONSTRUCT_ID_ONE, TPSTestConstants.GERMPLASM_EVENT_CONSTRUCT_ID_ONE);
      eventBuilder.insertGermplasmEventConstruct(TPSTestConstants.GERMPLASM_ID_ONE, TPSTestConstants.EVENT_CONSTRUCT_ID_TWO, TPSTestConstants.GERMPLASM_EVENT_CONSTRUCT_ID_TWO);
      eventBuilder.insertGermplasmEventConstruct(TPSTestConstants.GERMPLASM_ID_ONE, TPSTestConstants.EVENT_CONSTRUCT_ID_THREE, TPSTestConstants.GERMPLASM_EVENT_CONSTRUCT_ID_THREE);

      eventBuilder.insertGermplasmEventConstruct(TPSTestConstants.GERMPLASM_ID_TWO, TPSTestConstants.EVENT_CONSTRUCT_ID_ONE, -1234349);
      eventBuilder.insertGermplasmEventConstruct(TPSTestConstants.GERMPLASM_ID_TWO, TPSTestConstants.EVENT_CONSTRUCT_ID_TWO, -3489554);


      EventInfo eventInfo = eventSearchService.findByEventAndCrop("AT_EVENT1,AT_EVENT2,AT_EVENT3", CANOLA);
      assertFalse(ArrayUtils.isEmpty(eventInfo.getEventComponents()));
      assertNotNull(eventInfo);
      assertEquals(CANOLA, eventInfo.getCrop());
      EventComponent[] eventComponents = eventInfo.getEventComponents();
      assertFalse(ArrayUtils.isEmpty(eventComponents));
      assertEquals(3, eventComponents.length);
      assertTrue(ArrayUtils.isEmpty(eventInfo.getEventAgencies()));

      eventInfo = eventSearchService.findByEventAndCrop(STACKED_EVENT, CANOLA);
      assertNotNull(eventInfo);
      assertEquals(CANOLA, eventInfo.getCrop());
      eventComponents = eventInfo.getEventComponents();
      assertFalse(ArrayUtils.isEmpty(eventComponents));
      assertEquals(2, eventComponents.length);
      assertTrue(ArrayUtils.isEmpty(eventInfo.getEventAgencies()));
      eventBuilder.tearDownConnections();
   }


   @After
   public void onTearDown()
      throws Exception
   {

      if (eventBuilder.getTestManager() != null) {
         eventBuilder.tearDownConnections();
      }
   }
}
