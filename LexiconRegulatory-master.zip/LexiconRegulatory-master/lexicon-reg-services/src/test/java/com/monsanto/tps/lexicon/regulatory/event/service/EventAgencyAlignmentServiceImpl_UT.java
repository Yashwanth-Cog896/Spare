package com.monsanto.tps.lexicon.regulatory.event.service;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tps.lexicon.event.EventAgencyAlignmentRequest;
import com.monsanto.tps.lexicon.event.EventAgencyAlignmentRequestInfo;
import com.monsanto.tps.lexicon.event.EventAgencyAlignmentResponse;
import com.monsanto.tps.lexicon.event.EventAgencyAlignmentUpdateInfo;
import com.monsanto.tps.lexicon.event.EventAgencyAlignmentUpdateRequest;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Agency;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.EventAgencyAlignment;
import com.monsanto.tps.lexicon.regulatory.event.dao.EventAgencyAlignmentDao;
import com.monsanto.tps.lexicon.regulatory.event.delegate.EventAgencyAlignmentRequestParser;
import com.monsanto.tps.lexicon.regulatory.event.validation.EventAgencyAlignmentValidator;
import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;

/**
 * rrchak1 - Feb 3, 2009 2:18:56 PM
 */
public class EventAgencyAlignmentServiceImpl_UT {
    private EventAgencyAlignmentServiceImpl eventAgencyAlignmentService;
    private EventAgencyAlignmentDao eventAgencyAlignmentDao;
    private EventAgencyAlignmentRequest eventAgencyAlignmentRequest;
    private EventAgencyAlignmentRequestParser eventAgencyAlignmentRequestParser;
    private EventAgencyAlignmentValidator eventAgencyAlignmentValidator;
    private static final String EVENT_NAME = "some event";
    private EventAgencyAlignmentRequestInfo eventAgencyAlignmentRequestInfo;
    private EventAgencyAlignment eventAgencyAlignment;
    private EventAgencyAlignmentUpdateRequest updateRequest;
    private EventAgencyAlignmentUpdateInfo[] updates;
    private static final String CROP_NAME = "CORN";

    @Before
    public void before() {
        eventAgencyAlignmentService = new EventAgencyAlignmentServiceImpl();
        eventAgencyAlignmentRequestParser = createMock(EventAgencyAlignmentRequestParser.class);
        eventAgencyAlignmentValidator = createMock(EventAgencyAlignmentValidator.class);
        eventAgencyAlignmentDao = createMock(EventAgencyAlignmentDao.class);
        eventAgencyAlignmentService.setEventAgencyAlignmentDao(eventAgencyAlignmentDao);
        eventAgencyAlignmentService.setEventAgencyAlignmentRequestParser(eventAgencyAlignmentRequestParser);
        eventAgencyAlignmentService.setEventAgencyAlignmentValidator(eventAgencyAlignmentValidator);
        eventAgencyAlignment = new EventAgencyAlignment();
        eventAgencyAlignmentRequest = new EventAgencyAlignmentRequest();
        eventAgencyAlignmentRequestInfo = new EventAgencyAlignmentRequestInfo();
    }

    @Test
    public void saveEventAgencyAlignmentDelegatesToValidatorAndParserAndAlignmentDao()
            throws WrappingException {
        eventAgencyAlignmentRequestInfo = new EventAgencyAlignmentRequestInfo();
        String AGENCY_PUB_KEY = "1111";
        eventAgencyAlignmentRequestInfo.setAgencyPubkey(AGENCY_PUB_KEY);
        eventAgencyAlignmentRequest.setEventAgencyAlignments(new EventAgencyAlignmentRequestInfo[]{eventAgencyAlignmentRequestInfo});
        eventAgencyAlignmentRequest.setEvent(EVENT_NAME);
        eventAgencyAlignmentRequest.setCrop(CROP_NAME);
        eventAgencyAlignment.setEventAgencyAlignmentPubkey("9999");
        eventAgencyAlignment.setMaterialName(EVENT_NAME);
        Agency agency = new Agency();
        agency.setAgencyPubkey(AGENCY_PUB_KEY);
        eventAgencyAlignment.setAgency(agency);
        eventAgencyAlignmentValidator.valiateAgencyAlignedToEventAndCrop(AGENCY_PUB_KEY, eventAgencyAlignmentRequest);
        EasyMock.expect(eventAgencyAlignmentRequestParser.buildEventAgencyAlignmentFromRequest(eventAgencyAlignmentRequestInfo, eventAgencyAlignmentRequest)).andReturn(eventAgencyAlignment);
        EasyMock.expect(eventAgencyAlignmentDao.save(eventAgencyAlignment)).andReturn(eventAgencyAlignment);
        replay(eventAgencyAlignmentValidator, eventAgencyAlignmentRequestParser, eventAgencyAlignmentDao);
        EventAgencyAlignmentResponse[] response = eventAgencyAlignmentService.save(eventAgencyAlignmentRequest);
        verify(eventAgencyAlignmentValidator, eventAgencyAlignmentRequestParser, eventAgencyAlignmentDao);
        Assert.assertNotNull(response);
        Assert.assertEquals(1, response.length);
        EventAgencyAlignmentResponse eventAgencyAlignmentResponse = response[0];
        Assert.assertTrue(eventAgencyAlignmentResponse.isSuccess());
        Assert.assertNotNull(eventAgencyAlignmentResponse.getEventAgencyAlignmentPubkey());
    }

    @Test
    public void saveEventAgencyAlignmentWithEmptyRequestInfoReturnsEmptyResponse() {
        EventAgencyAlignmentResponse[] response = eventAgencyAlignmentService.save(eventAgencyAlignmentRequest);
        Assert.assertEquals(0, response.length);
    }

    @Test
    public void saveEventAgencyAlignmentReturnsNonExistentAgencyErrorMessage()
            throws WrappingException {
        eventAgencyAlignmentRequest.setEventAgencyAlignments(new EventAgencyAlignmentRequestInfo[]{eventAgencyAlignmentRequestInfo});
        eventAgencyAlignmentRequest.setEvent(EVENT_NAME);
        eventAgencyAlignmentRequest.setCrop(CROP_NAME);
        EasyMock.expect(eventAgencyAlignmentRequestParser.buildEventAgencyAlignmentFromRequest(eventAgencyAlignmentRequestInfo, eventAgencyAlignmentRequest)).andThrow(new WrappingException(new Exception("Agency not found for the given pubkey")));
        replay(eventAgencyAlignmentRequestParser);
        EventAgencyAlignmentResponse[] response = eventAgencyAlignmentService.save(eventAgencyAlignmentRequest);
        verify(eventAgencyAlignmentRequestParser);
        Assert.assertNotNull(response);
        Assert.assertEquals(1, response.length);
        EventAgencyAlignmentResponse eventAgencyAlignmentResponse = response[0];
        Assert.assertFalse(eventAgencyAlignmentResponse.isSuccess());
        Assert.assertEquals("Agency not found for the given pubkey", eventAgencyAlignmentResponse.getMessage());
    }

    @Test
    public void saveEventAgencyAlignmentReturnsNonExistentCropErrorMessage()
            throws WrappingException {
        eventAgencyAlignmentRequest.setEventAgencyAlignments(new EventAgencyAlignmentRequestInfo[]{eventAgencyAlignmentRequestInfo});
        eventAgencyAlignmentRequest.setEvent(EVENT_NAME);
        eventAgencyAlignmentRequest.setCrop(CROP_NAME);
        EasyMock.expect(eventAgencyAlignmentRequestParser.buildEventAgencyAlignmentFromRequest(eventAgencyAlignmentRequestInfo, eventAgencyAlignmentRequest)).andThrow(new WrappingException(new Exception("Crop not found for the given cropName")));
        replay(eventAgencyAlignmentRequestParser);
        EventAgencyAlignmentResponse[] response = eventAgencyAlignmentService.save(eventAgencyAlignmentRequest);
        verify(eventAgencyAlignmentRequestParser);
        Assert.assertNotNull(response);
        Assert.assertEquals(1, response.length);
        EventAgencyAlignmentResponse eventAgencyAlignmentResponse = response[0];
        Assert.assertFalse(eventAgencyAlignmentResponse.isSuccess());
        Assert.assertEquals("Crop not found for the given cropName", eventAgencyAlignmentResponse.getMessage());
    }

    @Test
    public void saveEventAgencyAlignmentReturnsAlignmentExistsErrorMessage()
            throws WrappingException {
        eventAgencyAlignmentRequestInfo = new EventAgencyAlignmentRequestInfo();
        eventAgencyAlignmentRequestInfo.setAgencyPubkey("1111");
        eventAgencyAlignmentRequest.setEventAgencyAlignments(new EventAgencyAlignmentRequestInfo[]{eventAgencyAlignmentRequestInfo});
        eventAgencyAlignmentRequest.setEvent(EVENT_NAME);
        eventAgencyAlignmentRequest.setCrop(CROP_NAME);
        eventAgencyAlignmentValidator.valiateAgencyAlignedToEventAndCrop("1111", eventAgencyAlignmentRequest);
        EasyMock.expectLastCall().andThrow(new WrappingException(new Exception("EventAgencyAlignment already exists")));
        replay(eventAgencyAlignmentValidator);
        EventAgencyAlignmentResponse[] response = eventAgencyAlignmentService.save(eventAgencyAlignmentRequest);
        verify(eventAgencyAlignmentValidator);
        Assert.assertNotNull(response);
        Assert.assertEquals(1, response.length);
        EventAgencyAlignmentResponse eventAgencyAlignmentResponse = response[0];
        Assert.assertFalse(eventAgencyAlignmentResponse.isSuccess());
        Assert.assertEquals("EventAgencyAlignment already exists", eventAgencyAlignmentResponse.getMessage());
    }

    @Test
    public void saveEventAgencyAlignmentDoesOnlyValidationBasedOnValidateOnlyFlag()
            throws WrappingException {
        eventAgencyAlignmentRequestInfo = new EventAgencyAlignmentRequestInfo();
        eventAgencyAlignmentRequestInfo.setAgencyPubkey("1111");
        eventAgencyAlignmentRequest.setEventAgencyAlignments(new EventAgencyAlignmentRequestInfo[]{eventAgencyAlignmentRequestInfo});
        eventAgencyAlignmentRequest.setEvent(EVENT_NAME);
        eventAgencyAlignmentRequest.setCrop(CROP_NAME);
        eventAgencyAlignmentRequest.setValidateOnly(true);
        eventAgencyAlignment.setMaterialName(EVENT_NAME);
        Agency agency = new Agency();
        agency.setAgencyPubkey("1111");
        eventAgencyAlignment.setAgency(agency);
        eventAgencyAlignmentValidator.valiateAgencyAlignedToEventAndCrop("1111", eventAgencyAlignmentRequest);
        EasyMock.expect(eventAgencyAlignmentRequestParser.buildEventAgencyAlignmentFromRequest(eventAgencyAlignmentRequestInfo, eventAgencyAlignmentRequest)).andReturn(eventAgencyAlignment);
        replay(eventAgencyAlignmentValidator, eventAgencyAlignmentRequestParser);
        EventAgencyAlignmentResponse[] response = eventAgencyAlignmentService.save(eventAgencyAlignmentRequest);
        verify(eventAgencyAlignmentValidator, eventAgencyAlignmentRequestParser);
        Assert.assertNotNull(response);
        Assert.assertEquals(1, response.length);
        EventAgencyAlignmentResponse eventAgencyAlignmentResponse = response[0];
        Assert.assertTrue(eventAgencyAlignmentResponse.isSuccess());
        Assert.assertNull(eventAgencyAlignmentResponse.getEventAgencyAlignmentPubkey());
    }

    @Test
    public void saveEventAgencyAlignmentGivesErrorMessageForHibernateException()
            throws WrappingException {
        eventAgencyAlignmentRequestInfo = new EventAgencyAlignmentRequestInfo();
        eventAgencyAlignmentRequestInfo.setAgencyPubkey("1111");
        eventAgencyAlignmentRequest.setEventAgencyAlignments(new EventAgencyAlignmentRequestInfo[]{eventAgencyAlignmentRequestInfo});
        eventAgencyAlignmentRequest.setEvent(EVENT_NAME);
        eventAgencyAlignment.setMaterialName(EVENT_NAME);
        eventAgencyAlignmentRequest.setCrop(CROP_NAME);
        Agency agency = new Agency();
        agency.setAgencyPubkey("1111");
        eventAgencyAlignment.setAgency(agency);
        eventAgencyAlignmentValidator.valiateAgencyAlignedToEventAndCrop("1111", eventAgencyAlignmentRequest);
        EasyMock.expect(eventAgencyAlignmentRequestParser.
                buildEventAgencyAlignmentFromRequest(eventAgencyAlignmentRequestInfo, eventAgencyAlignmentRequest)).andReturn(eventAgencyAlignment);
        EasyMock.expect(eventAgencyAlignmentDao.save(eventAgencyAlignment)).andThrow(new WrappingException(new Exception("RUNTIME")));
        replay(eventAgencyAlignmentValidator, eventAgencyAlignmentRequestParser, eventAgencyAlignmentDao);
        EventAgencyAlignmentResponse[] response = eventAgencyAlignmentService.save(eventAgencyAlignmentRequest);
        verify(eventAgencyAlignmentValidator, eventAgencyAlignmentRequestParser, eventAgencyAlignmentDao);
        Assert.assertNotNull(response);
        Assert.assertEquals(1, response.length);
        EventAgencyAlignmentResponse eventAgencyAlignmentResponse = response[0];
        Assert.assertFalse(eventAgencyAlignmentResponse.isSuccess());
        Assert.assertNull(eventAgencyAlignmentResponse.getEventAgencyAlignmentPubkey());
        Assert.assertEquals("RUNTIME", eventAgencyAlignmentResponse.getMessage());
    }

    @Test
    public void updateEventAgencyAlignmentDelegatesToValidatorAndAlignmentDao()
            throws WrappingException {
        eventAgencyAlignment = new EventAgencyAlignment();
        updateRequest = new EventAgencyAlignmentUpdateRequest();
        updates = new EventAgencyAlignmentUpdateInfo[1];
        updates[0] = new EventAgencyAlignmentUpdateInfo();
        String eventAgencyAlignmentPubkey = "some pubkey";
        updates[0].setEventAgencyAlignmentPubkey(eventAgencyAlignmentPubkey);
        updateRequest.setEventAgencyAlignmentUpdates(updates);
        EasyMock.expect(eventAgencyAlignmentValidator.validateAlignmentExists(eventAgencyAlignmentPubkey)).andReturn(eventAgencyAlignment);
        eventAgencyAlignmentDao.update(eventAgencyAlignment);
        replay(eventAgencyAlignmentValidator, eventAgencyAlignmentDao);
        EventAgencyAlignmentResponse[] response = eventAgencyAlignmentService.update(updateRequest);
        verify(eventAgencyAlignmentValidator, eventAgencyAlignmentDao);
        Assert.assertNotNull(response);
        Assert.assertEquals(1, response.length);
        EventAgencyAlignmentResponse eventAgencyAlignmentResponse = response[0];
        Assert.assertTrue(eventAgencyAlignmentResponse.isSuccess());
        Assert.assertEquals(eventAgencyAlignmentPubkey, eventAgencyAlignmentResponse.getEventAgencyAlignmentPubkey());
    }

    @Test
    public void updateEventAgencyAlignmentWithEmptyRequestReturnsEmptyResponse() {
        EventAgencyAlignmentResponse[] response = eventAgencyAlignmentService.update(new EventAgencyAlignmentUpdateRequest());
        Assert.assertEquals(0, response.length);
    }

    @Test
    public void updateEventAgencyAlignmentReturnsAlignmentNotExistsErrorMessage()
            throws WrappingException {
        eventAgencyAlignment = new EventAgencyAlignment();
        updateRequest = new EventAgencyAlignmentUpdateRequest();
        updates = new EventAgencyAlignmentUpdateInfo[1];
        updates[0] = new EventAgencyAlignmentUpdateInfo();
        String eventAgencyAlignmentPubkey = "some pubkey";
        updates[0].setEventAgencyAlignmentPubkey(eventAgencyAlignmentPubkey);
        updateRequest.setEventAgencyAlignmentUpdates(updates);
        EasyMock.expect(eventAgencyAlignmentValidator.validateAlignmentExists(eventAgencyAlignmentPubkey)).andThrow(new WrappingException(new Exception("EventAgencyAlignment does not exist")));
        replay(eventAgencyAlignmentValidator);
        EventAgencyAlignmentResponse[] response = eventAgencyAlignmentService.update(updateRequest);
        verify(eventAgencyAlignmentValidator);
        Assert.assertNotNull(response);
        Assert.assertEquals(1, response.length);
        EventAgencyAlignmentResponse eventAgencyAlignmentResponse = response[0];
        Assert.assertFalse(eventAgencyAlignmentResponse.isSuccess());
        Assert.assertEquals("EventAgencyAlignment does not exist", eventAgencyAlignmentResponse.getMessage());
    }

    @Test
    public void updateEventAgencyAlignmentGivesErrorMessageForHibernateException()
            throws WrappingException {
        eventAgencyAlignment = new EventAgencyAlignment();
        updateRequest = new EventAgencyAlignmentUpdateRequest();
        updates = new EventAgencyAlignmentUpdateInfo[1];
        updates[0] = new EventAgencyAlignmentUpdateInfo();
        String eventAgencyAlignmentPubkey = "some pubkey";
        updates[0].setEventAgencyAlignmentPubkey(eventAgencyAlignmentPubkey);
        updateRequest.setEventAgencyAlignmentUpdates(updates);
        EasyMock.expect(eventAgencyAlignmentValidator.validateAlignmentExists(eventAgencyAlignmentPubkey)).andReturn(eventAgencyAlignment);
        eventAgencyAlignmentDao.update(eventAgencyAlignment);
        EasyMock.expectLastCall().andThrow(new WrappingException(new Exception("RUNTIME")));
        replay(eventAgencyAlignmentValidator, eventAgencyAlignmentDao);
        EventAgencyAlignmentResponse[] response = eventAgencyAlignmentService.update(updateRequest);
        verify(eventAgencyAlignmentValidator, eventAgencyAlignmentDao);
        Assert.assertNotNull(response);
        Assert.assertEquals(1, response.length);
        EventAgencyAlignmentResponse eventAgencyAlignmentResponse = response[0];
        Assert.assertFalse(eventAgencyAlignmentResponse.isSuccess());
        Assert.assertEquals("RUNTIME", eventAgencyAlignmentResponse.getMessage());
        Assert.assertEquals(eventAgencyAlignmentPubkey, eventAgencyAlignmentResponse.getEventAgencyAlignmentPubkey());
    }

    @Test
    public void updateEventAgencyAlignmentOnlyValidatesForValidateOnlyFlag()
            throws WrappingException {
        updateRequest = new EventAgencyAlignmentUpdateRequest();
        updates = new EventAgencyAlignmentUpdateInfo[1];
        updates[0] = new EventAgencyAlignmentUpdateInfo();
        String eventAgencyAlignmentPubkey = "some pubkey";
        updates[0].setEventAgencyAlignmentPubkey(eventAgencyAlignmentPubkey);
        updateRequest.setEventAgencyAlignmentUpdates(updates);
        updateRequest.setValidateOnly(true);
        EasyMock.expect(eventAgencyAlignmentValidator.validateAlignmentExists(eventAgencyAlignmentPubkey)).andReturn(eventAgencyAlignment);
        replay(eventAgencyAlignmentValidator, eventAgencyAlignmentDao);
        EventAgencyAlignmentResponse[] response = eventAgencyAlignmentService.update(updateRequest);
        verify(eventAgencyAlignmentValidator, eventAgencyAlignmentDao);
        Assert.assertNotNull(response);
        Assert.assertEquals(1, response.length);
        EventAgencyAlignmentResponse eventAgencyAlignmentResponse = response[0];
        Assert.assertTrue(eventAgencyAlignmentResponse.isSuccess());
        Assert.assertEquals(eventAgencyAlignmentPubkey, eventAgencyAlignmentResponse.getEventAgencyAlignmentPubkey());
    }
}
