/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.eventtraitservice.business;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import com.monsanto.tps.compliance.referencedata.molecularinfo.ConstructIdentifier;
import com.monsanto.tps.compliance.referencedata.molecularinfo.ConstructPVCodeAssignment;
import com.monsanto.tps.compliance.referencedata.molecularinfo.PvCode;
import com.monsanto.tps.lexicon.eventtraitservice.transfer.GermplasmEventTrait;
import com.monsanto.tps.lexicon.eventtraitservice.transfer.GermplasmEventTraitResponse;
import com.monsanto.tps.lexicon.eventtraitservice.transfer.MidasEventConstruct;
import com.monsanto.tps.lexicon.eventtraitservice.transfer.PVCode;
import com.monsanto.tps.lexicon.monnumber.MonNumberRegulatoryTraitDescription;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber;
import com.monsanto.tps.lexicon.regulatory.DB.midas.model.EventConstructEntity;
import com.monsanto.tps.lexicon.regulatory.DB.midas.model.GermplasmEventConstructEntity;
import com.monsanto.tps.lexicon.regulatory.eventsreginfo.util.dao.lexicon.TempSessionOcdDao;
import com.monsanto.tps.lexicon.regulatory.eventtraitservice.dao.GermplasmEventConstructDao;
import com.monsanto.tps.lexicon.regulatory.monnumber.dao.MonNumberDao;
import com.monsanto.tps.lexicon.regulatory.monnumber.util.MonNumberBeanUtil;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static junit.framework.Assert.*;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.*;

/* vvkalu - 8/15/11 */
public class MonNumberAndPVCodesBusiness_UT {
    private static final long REQUEST_ID = 20110808;
    private static final long GERMPLASM_ID = 58;
    private MonNumberDao monNumberDao;
    private GermplasmEventConstructDao germplasmEventConstructDao;
    private TempSessionOcdDao tempSessionOcdDao;
    private PVCodesBuilder pvCodesBuilder;
    private MonNumberAndPVCodesBusiness monNumberAndPVCodesBusiness;
    private PVCodesTransformer pvCodesTransformer;
    private MonNumberBeanUtil monBeanUtil;
    private MonNumberRegulatoryTraitDescription monNumberRegulatoryTraitDescription;

    @Before
    public void setUp() {
        monNumberDao = mock(MonNumberDao.class);
        germplasmEventConstructDao = mock(GermplasmEventConstructDao.class);
        tempSessionOcdDao = mock(TempSessionOcdDao.class);
        pvCodesBuilder = mock(PVCodesBuilder.class);
        pvCodesTransformer = new PVCodesTransformer();
        monBeanUtil = new MonNumberBeanUtil();
        monNumberRegulatoryTraitDescription = new MonNumberRegulatoryTraitDescription();
        monNumberAndPVCodesBusiness = new MonNumberAndPVCodesBusiness();
        monNumberAndPVCodesBusiness.setGermplasmEventConstructDao(germplasmEventConstructDao);
        monNumberAndPVCodesBusiness.setMonNumberDao(monNumberDao);
        monNumberAndPVCodesBusiness.setPvCodesBuilder(pvCodesBuilder);
        monNumberAndPVCodesBusiness.setTempSessionOcdDao(tempSessionOcdDao);
        monNumberAndPVCodesBusiness.setPvCodesTransformer(pvCodesTransformer);
        monNumberAndPVCodesBusiness.setMonNumberBeanUtil(monBeanUtil);
        monNumberAndPVCodesBusiness.setMonNumberRegulatoryTraitDescription(monNumberRegulatoryTraitDescription);
    }

    @Test
    public void test_No_GermplasmEventConstructs() throws Exception {
        when(germplasmEventConstructDao.findGermplasmEventConstructs(GERMPLASM_ID)).thenReturn(null);
        GermplasmEventTraitResponse monNumberAndPVCodes = monNumberAndPVCodesBusiness
                .findMonNumberAndPVCodes(GERMPLASM_ID, new GermplasmEventTraitResponse());
        assertNotNull(monNumberAndPVCodes);
        assertTrue(monNumberAndPVCodes.getGermplasmEventTraits().isEmpty());
        verifyZeroInteractions(monNumberDao);
        verifyZeroInteractions(tempSessionOcdDao);
        verifyZeroInteractions(pvCodesBuilder);
    }

    @Test
    public void test_No_MonNumbers_One_Event_One_Single_construct() {
        GermplasmEventConstructEntity eventConstruct = new GermplasmEventConstructEntity();
        EventConstructEntity construct = new EventConstructEntity();
        construct.setId(56);
        construct.setConstructName("ECN1");
        construct.setEventName("EN1");
        eventConstruct.setEventConstruct(construct);
        when(germplasmEventConstructDao.findGermplasmEventConstructs(GERMPLASM_ID)).thenReturn(Arrays.asList(eventConstruct));
        when(monNumberDao.getMonNumbersByEventNames(REQUEST_ID)).thenReturn(null);
        Multimap<Long, ConstructPVCodeAssignment> constructIdToPVCodesMap = ArrayListMultimap.create();
        List<PvCode> pvCodes = PVCodeAssignmentBuilder.formPVCodes(Arrays.asList("PVC1", "PVC2"));
        ConstructIdentifier constructIdentifier = new ConstructIdentifier();
        constructIdentifier.setNames(Arrays.asList("ECN1"));
        ConstructPVCodeAssignment pvCodeAssignment = new ConstructPVCodeAssignment(constructIdentifier, pvCodes);
        constructIdToPVCodesMap.put(56L, pvCodeAssignment);
        when(pvCodesBuilder.getConstructIdToPVCodesMap(isA(Multimap.class), isA(Multimap.class))).thenReturn(constructIdToPVCodesMap);
        GermplasmEventTraitResponse eventTraitResponse = monNumberAndPVCodesBusiness
                .findMonNumberAndPVCodes(GERMPLASM_ID, new GermplasmEventTraitResponse());
        assertNotNull(eventTraitResponse);
        assertFalse(eventTraitResponse.getGermplasmEventTraits().isEmpty());
        assertEquals(1, eventTraitResponse.getGermplasmEventTraits().size());
        GermplasmEventTrait germplasmEventTrait = eventTraitResponse.getGermplasmEventTraits().iterator().next();
        assertNull(germplasmEventTrait.getTraitStack());
        assertEquals(GERMPLASM_ID, germplasmEventTrait.getGermplasmId());
        List<MidasEventConstruct> midasEventConstructs = germplasmEventTrait.getEventConstruct();
        assertEquals(1, midasEventConstructs.size());
        MidasEventConstruct midasEventConstruct = midasEventConstructs.iterator().next();
        assertEquals(56L, midasEventConstruct.getEventConstructId());
        assertEquals(0, midasEventConstruct.getEventMonNumbers().size());
        assertEquals(2, midasEventConstruct.getPvCodes().size());
        List<PVCode> lexiconPVCodes = pvCodesTransformer.formLexiconPVCodeList(pvCodes);
        assertTrue(midasEventConstruct.getPvCodes().containsAll(lexiconPVCodes));
    }

    @Test
    public void test_With_MonNumbers_One_Event_One_Single_construct() {
        GermplasmEventConstructEntity eventConstruct = new GermplasmEventConstructEntity();
        EventConstructEntity construct = new EventConstructEntity();
        construct.setId(56);
        construct.setConstructName("ECN1");
        construct.setEventName("EN1");
        eventConstruct.setEventConstruct(construct);
        when(germplasmEventConstructDao.findGermplasmEventConstructs(GERMPLASM_ID)).thenReturn(Arrays.asList(eventConstruct));
        MonNumber monNumber = new MonNumber();
        monNumber.setEvent("EN1");
        monNumber.setMonNumber("MON");
        when(monNumberDao.getMonNumbersByEventNames(REQUEST_ID)).thenReturn(Arrays.asList(monNumber));
        Multimap<Long, ConstructPVCodeAssignment> constructIdToPVCodesMap = ArrayListMultimap.create();
        ConstructIdentifier constructIdentifier = new ConstructIdentifier();
        constructIdentifier.setNames(Arrays.asList("ECN1"));
        List<PvCode> pvCodes = PVCodeAssignmentBuilder.formPVCodes(Arrays.asList("PVC1", "PVC2"));
        ConstructPVCodeAssignment pvCodeAssignment = new ConstructPVCodeAssignment(constructIdentifier, pvCodes);
        constructIdToPVCodesMap.put(56L, pvCodeAssignment);
        when(pvCodesBuilder.getConstructIdToPVCodesMap(isA(Multimap.class), isA(Multimap.class))).thenReturn(constructIdToPVCodesMap);
        GermplasmEventTraitResponse eventTraitResponse = monNumberAndPVCodesBusiness
                .findMonNumberAndPVCodes(GERMPLASM_ID, new GermplasmEventTraitResponse());
        assertNotNull(eventTraitResponse);
        assertFalse(eventTraitResponse.getGermplasmEventTraits().isEmpty());
        assertEquals(1, eventTraitResponse.getGermplasmEventTraits().size());
        GermplasmEventTrait germplasmEventTrait = eventTraitResponse.getGermplasmEventTraits().iterator().next();
        assertNull(germplasmEventTrait.getTraitStack());
        assertEquals(GERMPLASM_ID, germplasmEventTrait.getGermplasmId());
        List<MidasEventConstruct> midasEventConstructs = germplasmEventTrait.getEventConstruct();
        assertEquals(1, midasEventConstructs.size());
        MidasEventConstruct midasEventConstruct = midasEventConstructs.iterator().next();
        assertEquals(56L, midasEventConstruct.getEventConstructId());
        assertEquals("MON", midasEventConstruct.getEventMonNumbers().get(0).getMonNumber());
        assertEquals(2, midasEventConstruct.getPvCodes().size());
        List<PVCode> lexiconPVCodes = pvCodesTransformer.formLexiconPVCodeList(pvCodes);
        assertTrue(midasEventConstruct.getPvCodes().containsAll(lexiconPVCodes));
    }

    @Test
    public void test_No_MonNumbers_One_Event_Combined_construct() {
        GermplasmEventConstructEntity eventConstruct = new GermplasmEventConstructEntity();
        EventConstructEntity construct = new EventConstructEntity();
        construct.setId(56);
        construct.setConstructName("ECN1, ECN2");
        construct.setEventName("EN1");
        eventConstruct.setEventConstruct(construct);
        when(germplasmEventConstructDao.findGermplasmEventConstructs(GERMPLASM_ID)).thenReturn(Arrays.asList(eventConstruct));
        when(monNumberDao.getMonNumbersByEventNames(REQUEST_ID)).thenReturn(null);
        Multimap<Long, ConstructPVCodeAssignment> constructIdToPVCodesMap = ArrayListMultimap.create();

        ConstructIdentifier constructIdentifier = new ConstructIdentifier();
        constructIdentifier.setNames(Arrays.asList("ECN1", "ECN2"));
        List<PvCode> pvCodes1 = PVCodeAssignmentBuilder.formPVCodes(Arrays.asList("PVC1", "PVC2"));
        ConstructPVCodeAssignment pvCodeAssignment = new ConstructPVCodeAssignment(constructIdentifier, pvCodes1);

        ConstructIdentifier constructIdentifier1 = new ConstructIdentifier();
        constructIdentifier1.setNames(Arrays.asList("ECN1", "ECN2"));
        List<PvCode> pvCodes2 = PVCodeAssignmentBuilder.formPVCodes(Arrays.asList("PVC3"));
        ConstructPVCodeAssignment pvCodeAssignment1 = new ConstructPVCodeAssignment(constructIdentifier1, pvCodes2);

        constructIdToPVCodesMap.put(56L, pvCodeAssignment);
        constructIdToPVCodesMap.put(56L, pvCodeAssignment1);

        when(pvCodesBuilder.getConstructIdToPVCodesMap(isA(Multimap.class), isA(Multimap.class))).thenReturn(constructIdToPVCodesMap);
        GermplasmEventTraitResponse eventTraitResponse = monNumberAndPVCodesBusiness
                .findMonNumberAndPVCodes(GERMPLASM_ID, new GermplasmEventTraitResponse());
        assertNotNull(eventTraitResponse);
        assertFalse(eventTraitResponse.getGermplasmEventTraits().isEmpty());
        assertEquals(1, eventTraitResponse.getGermplasmEventTraits().size());
        GermplasmEventTrait germplasmEventTrait = eventTraitResponse.getGermplasmEventTraits().iterator().next();
        assertNull(germplasmEventTrait.getTraitStack());
        assertEquals(GERMPLASM_ID, germplasmEventTrait.getGermplasmId());
        List<MidasEventConstruct> midasEventConstructs = germplasmEventTrait.getEventConstruct();
        assertEquals(1, midasEventConstructs.size());
        MidasEventConstruct midasEventConstruct = midasEventConstructs.iterator().next();
        assertEquals(56L, midasEventConstruct.getEventConstructId());
        assertEquals(0, midasEventConstruct.getEventMonNumbers().size());
        assertEquals(3, midasEventConstruct.getPvCodes().size());
        List<PVCode> lexiconPVCodes1 = pvCodesTransformer.formLexiconPVCodeList(pvCodes1);
        List<PVCode> lexiconPVCodes2 = pvCodesTransformer.formLexiconPVCodeList(pvCodes2);
        assertTrue(midasEventConstruct.getPvCodes().containsAll(lexiconPVCodes1));
        assertTrue(midasEventConstruct.getPvCodes().containsAll(lexiconPVCodes2));
    }

    @Test
    public void test_With_MonNumbers_Two_Events_Two_Single_construct() {
        GermplasmEventConstructEntity eventConstruct = new GermplasmEventConstructEntity();
        EventConstructEntity construct = new EventConstructEntity();
        construct.setId(56);
        construct.setConstructName("ECN1");
        construct.setEventName("EN1");
        eventConstruct.setEventConstruct(construct);
        GermplasmEventConstructEntity eventConstruct1 = new GermplasmEventConstructEntity();
        EventConstructEntity construct1 = new EventConstructEntity();
        construct1.setId(785);
        construct1.setConstructName("ECN2");
        construct1.setEventName("EN2");
        eventConstruct1.setEventConstruct(construct1);
        when(germplasmEventConstructDao.findGermplasmEventConstructs(GERMPLASM_ID)).thenReturn(Arrays.asList(eventConstruct, eventConstruct1));
        MonNumber monNumber = new MonNumber();
        monNumber.setEvent("EN1");
        monNumber.setMonNumber("MON");
        MonNumber monNumber1 = new MonNumber();
        monNumber1.setEvent("EN2");
        monNumber1.setMonNumber("MON1");
        when(monNumberDao.getMonNumbersByEventNames(REQUEST_ID)).thenReturn(Arrays.asList(monNumber, monNumber1));
        Multimap<Long, ConstructPVCodeAssignment> constructIdToPVCodesMap = ArrayListMultimap.create();

        ConstructIdentifier constructIdentifier1 = new ConstructIdentifier();
        constructIdentifier1.setNames(Arrays.asList("ECN1"));
        List<PvCode> pvCodes1 = PVCodeAssignmentBuilder.formPVCodes(Arrays.asList("PVC1", "PVC2"));
        ConstructPVCodeAssignment pvCodeAssignment1 = new ConstructPVCodeAssignment(constructIdentifier1, pvCodes1);

        ConstructIdentifier constructIdentifier2 = new ConstructIdentifier();
        constructIdentifier2.setNames(Arrays.asList("ECN2"));
        List<PvCode> pvCodes2 = PVCodeAssignmentBuilder.formPVCodes(Arrays.asList("PVC3", "PVC4"));
        ConstructPVCodeAssignment pvCodeAssignment2 = new ConstructPVCodeAssignment(constructIdentifier2, pvCodes2);
        constructIdToPVCodesMap.put(56L, pvCodeAssignment1);
        constructIdToPVCodesMap.put(785L, pvCodeAssignment2);
        when(pvCodesBuilder.getConstructIdToPVCodesMap(isA(Multimap.class), isA(Multimap.class))).thenReturn(constructIdToPVCodesMap);
        GermplasmEventTraitResponse eventTraitResponse = monNumberAndPVCodesBusiness.findMonNumberAndPVCodes(GERMPLASM_ID, new GermplasmEventTraitResponse());
        assertNotNull(eventTraitResponse);
        assertFalse(eventTraitResponse.getGermplasmEventTraits().isEmpty());
        assertEquals(1, eventTraitResponse.getGermplasmEventTraits().size());
        GermplasmEventTrait germplasmEventTrait = eventTraitResponse.getGermplasmEventTraits().iterator().next();
        assertNull(germplasmEventTrait.getTraitStack());
        assertEquals(GERMPLASM_ID, germplasmEventTrait.getGermplasmId());
        List<MidasEventConstruct> midasEventConstructs = germplasmEventTrait.getEventConstruct();
        assertEquals(2, midasEventConstructs.size());
        MidasEventConstruct midasEventConstruct = midasEventConstructs.get(0);
        assertEquals(56L, midasEventConstruct.getEventConstructId());
        assertEquals("MON", midasEventConstruct.getEventMonNumbers().get(0).getMonNumber());
        assertEquals(2, midasEventConstruct.getPvCodes().size());
        List<PVCode> lexiconPVCodes1 = pvCodesTransformer.formLexiconPVCodeList(pvCodes1);
        assertTrue(midasEventConstruct.getPvCodes().containsAll(lexiconPVCodes1));
        MidasEventConstruct midasEventConstruct2 = midasEventConstructs.get(1);
        assertEquals(785L, midasEventConstruct2.getEventConstructId());
        assertEquals("MON1", midasEventConstruct2.getEventMonNumbers().get(0).getMonNumber());
        assertEquals(2, midasEventConstruct2.getPvCodes().size());
        List<PVCode> lexiconPVCodes2 = pvCodesTransformer.formLexiconPVCodeList(pvCodes2);
        assertTrue(midasEventConstruct2.getPvCodes().containsAll(lexiconPVCodes2));
    }

    @Test
    public void test_With_MonNumbers_Two_Events_One_Single_And_Other_Combined_construct() {
        GermplasmEventConstructEntity eventConstruct = new GermplasmEventConstructEntity();
        EventConstructEntity construct = new EventConstructEntity();
        construct.setId(56);
        construct.setConstructName("ECN1");
        construct.setEventName("EN1");
        eventConstruct.setEventConstruct(construct);
        GermplasmEventConstructEntity eventConstruct1 = new GermplasmEventConstructEntity();
        EventConstructEntity construct1 = new EventConstructEntity();
        construct1.setId(785);
        construct1.setConstructName("ECN2, ECN3");
        construct1.setEventName("EN2");
        eventConstruct1.setEventConstruct(construct1);
        when(germplasmEventConstructDao.findGermplasmEventConstructs(GERMPLASM_ID)).thenReturn(Arrays.asList(eventConstruct, eventConstruct1));
        MonNumber monNumber = new MonNumber();
        monNumber.setEvent("EN1");
        monNumber.setMonNumber("MON");
        MonNumber monNumber1 = new MonNumber();
        monNumber1.setEvent("EN2");
        monNumber1.setMonNumber("MON1");
        when(monNumberDao.getMonNumbersByEventNames(REQUEST_ID)).thenReturn(Arrays.asList(monNumber, monNumber1));
        Multimap<Long, ConstructPVCodeAssignment> constructIdToPVCodesMap = ArrayListMultimap.create();
        ConstructIdentifier constructIdentifier1 = new ConstructIdentifier();
        constructIdentifier1.setNames(Arrays.asList("ECN1"));
        List<PvCode> pvCodes1 = PVCodeAssignmentBuilder.formPVCodes(Arrays.asList("PVC1", "PVC2"));
        ConstructPVCodeAssignment pvCodeAssignment1 = new ConstructPVCodeAssignment(constructIdentifier1, pvCodes1);
        ConstructIdentifier constructIdentifier2 = new ConstructIdentifier();
        constructIdentifier2.setNames(Arrays.asList("ECN2", "EC3"));
        List<PvCode> pvCodes2 = PVCodeAssignmentBuilder.formPVCodes(Arrays.asList("PVC3", "PVC4", "PVC5"));
        ConstructPVCodeAssignment pvCodeAssignment2 = new ConstructPVCodeAssignment(constructIdentifier2, pvCodes2);
        constructIdToPVCodesMap.put(56L, pvCodeAssignment1);
        constructIdToPVCodesMap.put(785L, pvCodeAssignment2);
        when(pvCodesBuilder.getConstructIdToPVCodesMap(isA(Multimap.class), isA(Multimap.class))).thenReturn(constructIdToPVCodesMap);
        GermplasmEventTraitResponse eventTraitResponse = monNumberAndPVCodesBusiness.findMonNumberAndPVCodes(GERMPLASM_ID, new GermplasmEventTraitResponse());
        assertNotNull(eventTraitResponse);
        assertFalse(eventTraitResponse.getGermplasmEventTraits().isEmpty());
        assertEquals(1, eventTraitResponse.getGermplasmEventTraits().size());
        GermplasmEventTrait germplasmEventTrait = eventTraitResponse.getGermplasmEventTraits().iterator().next();
        assertNull(germplasmEventTrait.getTraitStack());
        assertEquals(GERMPLASM_ID, germplasmEventTrait.getGermplasmId());
        List<MidasEventConstruct> midasEventConstructs = germplasmEventTrait.getEventConstruct();
        assertEquals(2, midasEventConstructs.size());
        MidasEventConstruct midasEventConstruct = midasEventConstructs.get(0);
        assertEquals(56L, midasEventConstruct.getEventConstructId());
        assertEquals("MON", midasEventConstruct.getEventMonNumbers().get(0).getMonNumber());
        assertEquals(2, midasEventConstruct.getPvCodes().size());
        List<PVCode> lexiconPVCodes1 = pvCodesTransformer.formLexiconPVCodeList(pvCodes1);
        assertTrue(midasEventConstruct.getPvCodes().containsAll(lexiconPVCodes1));
        MidasEventConstruct midasEventConstruct2 = midasEventConstructs.get(1);
        assertEquals(785L, midasEventConstruct2.getEventConstructId());
        assertEquals("MON1", midasEventConstruct2.getEventMonNumbers().get(0).getMonNumber());
        assertEquals(3, midasEventConstruct2.getPvCodes().size());
        List<PVCode> lexiconPVCodes2 = pvCodesTransformer.formLexiconPVCodeList(pvCodes2);
        assertTrue(midasEventConstruct2.getPvCodes().containsAll(lexiconPVCodes2));
    }

    @Test
    public void test_StackedEvents_With_Multi_MonNumbers() {
        GermplasmEventConstructEntity eventConstruct1 = new GermplasmEventConstructEntity();
        EventConstructEntity construct1 = new EventConstructEntity();
        construct1.setId(785);
        construct1.setConstructName("ECN2, ECN3");
        construct1.setEventName("EN2, MON3");
        eventConstruct1.setEventConstruct(construct1);
        when(germplasmEventConstructDao.findGermplasmEventConstructs(GERMPLASM_ID)).thenReturn(Arrays.asList(eventConstruct1));
        MonNumber monNumber = new MonNumber();
        monNumber.setEvent("EN1");
        monNumber.setMonNumber("MON1");
        MonNumber monNumber1 = new MonNumber();
        monNumber1.setEvent("EN2");
        monNumber1.setMonNumber("MON2");
        MonNumber monNumber2 = new MonNumber();
        monNumber2.setEvent("EN2");
        monNumber2.setMonNumber("MON3");
        when(monNumberDao.getMonNumbersByEventNames(REQUEST_ID)).thenReturn(Arrays.asList(monNumber, monNumber1, monNumber2));
        Multimap<Long, ConstructPVCodeAssignment> constructIdToPVCodesMap = ArrayListMultimap.create();
        ConstructIdentifier constructIdentifier1 = new ConstructIdentifier();
        constructIdentifier1.setNames(Arrays.asList("ECN2", "EC3"));
        List<PvCode> pvCodes2 = PVCodeAssignmentBuilder.formPVCodes(Arrays.asList("PVC3", "PVC4", "PVC5"));
        ConstructPVCodeAssignment pvCodeAssignment1 = new ConstructPVCodeAssignment(constructIdentifier1, pvCodes2);
        constructIdToPVCodesMap.put(785L, pvCodeAssignment1);
        when(pvCodesBuilder.getConstructIdToPVCodesMap(isA(Multimap.class), isA(Multimap.class))).thenReturn(constructIdToPVCodesMap);
        GermplasmEventTraitResponse eventTraitResponse = monNumberAndPVCodesBusiness.findMonNumberAndPVCodes(GERMPLASM_ID, new GermplasmEventTraitResponse());
        assertNotNull(eventTraitResponse);
        assertFalse(eventTraitResponse.getGermplasmEventTraits().isEmpty());
        assertEquals(1, eventTraitResponse.getGermplasmEventTraits().size());
        GermplasmEventTrait germplasmEventTrait = eventTraitResponse.getGermplasmEventTraits().iterator().next();
        assertNull(germplasmEventTrait.getTraitStack());
        assertEquals(GERMPLASM_ID, germplasmEventTrait.getGermplasmId());
        List<MidasEventConstruct> midasEventConstructs = germplasmEventTrait.getEventConstruct();
        assertEquals(1, midasEventConstructs.size());
        MidasEventConstruct midasEventConstruct = midasEventConstructs.get(0);
        assertEquals(2, midasEventConstruct.getEventMonNumbers().size());

    }

}