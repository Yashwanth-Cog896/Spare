package com.monsanto.tps.lexicon.regulatory.plantname.service;

import com.monsanto.tps.lexicon.plantname.OrionPlantProduct;
import com.monsanto.tps.lexicon.plantname.PlantNameService;
import com.monsanto.tps.lexicon.regulatory.plantname.business.PlantNameBusiness;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/1/12
 * Time: 7:47 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class PlantNameServiceImpl_UT {

    @Mock
    private PlantNameBusiness plantNameBusiness;

    @InjectMocks
    private PlantNameService plantNameService = new PlantNameServiceImpl();

    private static final List<OrionPlantProduct> plantNameList = new ArrayList<OrionPlantProduct>();

    @Before
    public void setup() {
        plantNameList.add(new OrionPlantProduct());
    }

    @Test
    public void findPlantName_success() throws Exception {
        when(plantNameBusiness.findPlantNames("BollGard Cotton")).thenReturn(plantNameList);

        final List<OrionPlantProduct> actualPlantNames = plantNameBusiness.findPlantNames("BollGard Cotton");

        assertEquals(actualPlantNames, plantNameList);
    }
}
