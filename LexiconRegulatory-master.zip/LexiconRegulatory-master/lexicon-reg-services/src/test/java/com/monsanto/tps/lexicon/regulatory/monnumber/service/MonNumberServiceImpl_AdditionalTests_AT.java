package com.monsanto.tps.lexicon.regulatory.monnumber.service;

import com.monsanto.tps.lexicon.commercialtrait.ComlTraitName;
import com.monsanto.tps.lexicon.commercialtrait.ComlTraitType;
import com.monsanto.tps.lexicon.event.Construct;
import com.monsanto.tps.lexicon.monnumber.MonNumber;
import com.monsanto.tps.lexicon.monnumber.MonNumberConstruct;
import com.monsanto.tps.lexicon.monnumber.MonNumberSaveBatchRequest;
import com.monsanto.tps.lexicon.monnumber.MonNumberSaveRequest;
import com.monsanto.tps.lexicon.monnumber.MonNumberSaveResponse;
import com.monsanto.tps.lexicon.monnumber.MonNumberService;
import com.monsanto.tps.lexicon.monnumber.ProteinName;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.ComlTraitNameBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.ComlTraitTypeBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.CropBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.LexiconAcceptanceTestCase;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.MonNumberBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.MonNumberConstructBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.ProteinNameBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.TestUtil.TPSTestConstants;
import com.monsanto.tps.lexicon.regulatory.DB.Tests.EventBuilder;
import org.apache.commons.lang.ArrayUtils;
import org.junit.After;
import org.junit.Test;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.Date;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * rrchak1 - May 5, 2009 12:31:42 PM
 */
@Transactional
public class MonNumberServiceImpl_AdditionalTests_AT
        extends LexiconAcceptanceTestCase {
    @Resource
    private MonNumberService monNumberService;
    private String EVENT = "AT_EVENT";
    private String MON_NUMBER = "MON 00001";
    private String CROP_PUBKEY = "1415";
    private String materialName = "RHS Corn";
    private String LIST_OF_GENES_PRESENT = "genes list";
    private String PROTEIN_PUBKEY = "1111";
    private String OECD_NUMBER = "oecdNumber";
    private String JV_NUMBER = "jvNumber";
    private String AUDIT_COMMENT = "audit comment";
    private String AUDIT_REQESTOR = "lastName";
    private EventBuilder eventBuilder = new EventBuilder();
    private String traitTypeAbbr = "CTRTABBR";
    private String traitNameAbbr = "CTABBR";
    private String regulatoryParentalLine = "RPL";


    @Test
    public void testSaveMonNumber_SavesMonNumber_WithProtein_WithTraitType_WithConstruct_WithTraitName()
            throws Exception {
        eventBuilder.setupConnections();
        eventBuilder.insertEvent(EVENT);
        com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName proteinName = insert(new AcceptanceTestData<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName>() {
            public com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName dataToInsert() {
                return new ProteinNameBuilder().
                        withProteinName("PROT NAME").
                        withProteinNamePubkey(PROTEIN_PUBKEY).
                        withProteinDescription("PROT DESC").
                        withOrigSourceOrganism("ORIG SOURCE ORG").create();
            }
        });

        com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType comlTraitType = insert(new AcceptanceTestData<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType>() {
            public com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType dataToInsert() {
                return new ComlTraitTypeBuilder().
                        withTraitTypeAbbr(traitTypeAbbr).
                        withTraitTypeDesc("CTRT DESC").create();
            }
        });

        com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName comlTraitName = insert(new AcceptanceTestData<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName>() {
            public com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName dataToInsert() {
                return new ComlTraitNameBuilder().
                        withTraitAbbr(traitNameAbbr).
                        withTraitDesc("TNDESC").create();
            }
        });

        MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
        monNumberSaveRequest.setMonNumber(MON_NUMBER);
        monNumberSaveRequest.setCropPubkey(CROP_PUBKEY);
        monNumberSaveRequest.setEvent(EVENT);
        monNumberSaveRequest.setMaterialName(materialName);
        //donot assign construct info
        monNumberSaveRequest.setTraitTypeAbbreviations(new String[]{traitTypeAbbr});
        monNumberSaveRequest.setTraitNameAbbreviations(new String[]{traitNameAbbr});
        monNumberSaveRequest.setRegulatoryGenesPresent(LIST_OF_GENES_PRESENT);
        monNumberSaveRequest.setRegulatoryParentalLine(regulatoryParentalLine);
        monNumberSaveRequest.setProteinNamePubkeys(new String[]{PROTEIN_PUBKEY});
        monNumberSaveRequest.setOecdNumber(OECD_NUMBER);
        monNumberSaveRequest.setOecdNumberCommunicationDate(new Date());
        monNumberSaveRequest.setJvNumber(JV_NUMBER);
        monNumberSaveRequest.setRegulatedStatus(true);
        monNumberSaveRequest.setLocked(true);
        monNumberSaveRequest.setActiveStatus(true);
        monNumberSaveRequest.setAuditComment(AUDIT_COMMENT);
        monNumberSaveRequest.setAuditRequestor(AUDIT_REQESTOR);
        MonNumberSaveBatchRequest monNumberSaveBatchRequest = new MonNumberSaveBatchRequest();
        monNumberSaveBatchRequest.setMonNumberSaveRequests(new MonNumberSaveRequest[]{monNumberSaveRequest});
        MonNumberSaveResponse[] monNumberSaveResponses = monNumberService.save(monNumberSaveBatchRequest);
        assertFalse(ArrayUtils.isEmpty(monNumberSaveResponses));
        MonNumberSaveResponse monNumberSaveResponse = monNumberSaveResponses[0];
        assertTrue(monNumberSaveResponse.isSuccess());
        assertTrue(ArrayUtils.isEmpty(monNumberSaveResponse.getMessages()));
        Construct[] eventConstructs = monNumberSaveResponse.getEventConstructs();
        assertFalse(ArrayUtils.isEmpty(eventConstructs));
        Construct eventConstruct = eventConstructs[0];
        assertNotNull(eventConstruct);
        assertEquals(TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_FCM_PVCODE, eventConstruct.getPlasmidPMon());
        assertNotNull(monNumberSaveResponse.getTransformationBackground());
        MonNumber[] monNumbers = monNumberService.findByCrop(CROP_PUBKEY);
        assertFalse(ArrayUtils.isEmpty(monNumbers));
        MonNumber monNumber = getMonNumber(monNumberSaveRequest.getMonNumber(), monNumbers);
        assertNotNull(monNumber);
        assertEquals(MON_NUMBER, monNumber.getMonNumber());
        assertFalse(monNumber.getProteinNames().isEmpty());
        ProteinName proteinNameReceived = monNumber.getProteinNames().iterator().next();
        assertEquals(proteinName.getProteinNamePubkey(), proteinNameReceived.getProteinNamePubkey());
        assertFalse(monNumber.getComlTraitTypes().isEmpty());
        ComlTraitType traitType = monNumber.getComlTraitTypes().iterator().next();
        assertEquals(traitType.getComlTraitTypeAbbr(), traitType.getComlTraitTypeAbbr());
        assertFalse(monNumber.getComlTraitNames().isEmpty());
        ComlTraitName traitName = monNumber.getComlTraitNames().iterator().next();
        assertEquals(comlTraitName.getTraitAbbr(), traitName.getTraitAbbr());
        assertNotNull(monNumber.getTransformationBackground());
        assertFalse(monNumber.getMonNumberConstructs().isEmpty());
        MonNumberConstruct monNumberConstruct = monNumber.getMonNumberConstructs().iterator().next();
        assertNotNull(monNumberConstruct.getConstructName());
        assertNotNull(monNumberConstruct.getPvCode());
        eventBuilder.tearDownConnections();
    }


    @Test
    public void testSaveMonNumber_ReturnsErrorMessages()
            throws Exception {
        eventBuilder.setupConnections();
        eventBuilder.insertEvent(EVENT);
        MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
        monNumberSaveRequest.setCropPubkey(CROP_PUBKEY);
        monNumberSaveRequest.setEvent(EVENT);
        monNumberSaveRequest.setMaterialName(materialName);
        //donot assign construct info
        monNumberSaveRequest.setProteinNamePubkeys(new String[]{PROTEIN_PUBKEY});
        monNumberSaveRequest.setOecdNumber(OECD_NUMBER);
        monNumberSaveRequest.setOecdNumberCommunicationDate(new Date());
        monNumberSaveRequest.setJvNumber(JV_NUMBER);
        monNumberSaveRequest.setRegulatedStatus(true);
        monNumberSaveRequest.setLocked(true);
        monNumberSaveRequest.setActiveStatus(true);
        MonNumberSaveBatchRequest monNumberSaveBatchRequest = new MonNumberSaveBatchRequest();
        monNumberSaveBatchRequest.setMonNumberSaveRequests(new MonNumberSaveRequest[]{monNumberSaveRequest});
        MonNumberSaveResponse[] monNumberSaveResponses = monNumberService.save(monNumberSaveBatchRequest);
        assertFalse(ArrayUtils.isEmpty(monNumberSaveResponses));
        MonNumberSaveResponse monNumberSaveResponse = monNumberSaveResponses[0];
        assertFalse(monNumberSaveResponse.isSuccess());
        assertFalse(ArrayUtils.isEmpty(monNumberSaveResponse.getMessages()));
        eventBuilder.tearDownConnections();
    }


    @Test
    public void testSaveMonNumber_MultipleRequests_DupliateEvent_ErrorsOut()
            throws Exception {
        eventBuilder.setupConnections();
        eventBuilder.insertEvent(EVENT);

        com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType comlTraitType = insert(new AcceptanceTestData<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType>() {
            public com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType dataToInsert() {
                return new ComlTraitTypeBuilder().
                        withTraitTypeAbbr(traitTypeAbbr).
                        withTraitTypeDesc("CTRT DESC").create();
            }
        });

        MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
        monNumberSaveRequest.setMonNumber(MON_NUMBER);
        monNumberSaveRequest.setCropPubkey(CROP_PUBKEY);
        monNumberSaveRequest.setEvent(EVENT);
        monNumberSaveRequest.setMaterialName(materialName);
        //donot assign construct info
        monNumberSaveRequest.setTraitTypeAbbreviations(new String[]{traitTypeAbbr});
        monNumberSaveRequest.setRegulatoryGenesPresent(LIST_OF_GENES_PRESENT);
        monNumberSaveRequest.setRegulatoryParentalLine(regulatoryParentalLine);
        monNumberSaveRequest.setAuditComment(AUDIT_COMMENT);
        monNumberSaveRequest.setAuditRequestor(AUDIT_REQESTOR);

        MonNumberSaveRequest monNumberSaveRequestTwo = new MonNumberSaveRequest();
        monNumberSaveRequestTwo.setMonNumber("MON 12334");
        monNumberSaveRequestTwo.setCropPubkey(CROP_PUBKEY);
        monNumberSaveRequestTwo.setEvent(EVENT);
        monNumberSaveRequestTwo.setMaterialName(materialName);
        //donot assign construct info
        monNumberSaveRequestTwo.setRegulatoryGenesPresent(LIST_OF_GENES_PRESENT);
        monNumberSaveRequestTwo.setRegulatoryParentalLine(regulatoryParentalLine);
        monNumberSaveRequestTwo.setTraitTypeAbbreviations(new String[]{traitTypeAbbr});
        monNumberSaveRequestTwo.setAuditComment(AUDIT_COMMENT);
        monNumberSaveRequestTwo.setAuditRequestor(AUDIT_REQESTOR);

        MonNumberSaveBatchRequest monNumberSaveBatchRequest = new MonNumberSaveBatchRequest();
        monNumberSaveBatchRequest.setMonNumberSaveRequests(new MonNumberSaveRequest[]{monNumberSaveRequest, monNumberSaveRequestTwo});
        MonNumberSaveResponse[] monNumberSaveResponses = monNumberService.save(monNumberSaveBatchRequest);
        assertFalse(ArrayUtils.isEmpty(monNumberSaveResponses));
        assertEquals(2, monNumberSaveResponses.length);
        MonNumberSaveResponse monNumberSaveResponse = monNumberSaveResponses[0];
        assertTrue(monNumberSaveResponse.isSuccess());
        assertTrue(ArrayUtils.isEmpty(monNumberSaveResponse.getMessages()));
        Construct[] eventConstructs = monNumberSaveResponse.getEventConstructs();
        assertFalse(ArrayUtils.isEmpty(eventConstructs));
        Construct eventConstruct = eventConstructs[0];
        assertNotNull(eventConstruct);
        assertEquals(TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_FCM_PVCODE, eventConstruct.getPlasmidPMon());
        assertNotNull(monNumberSaveResponse.getTransformationBackground());

        MonNumberSaveResponse responseTwo = monNumberSaveResponses[1];
        assertFalse(responseTwo.isSuccess());
        assertFalse(ArrayUtils.isEmpty(responseTwo.getMessages()));
        String[] errorMessages = responseTwo.getMessages();
        assertTrue(containsErrorMessge("Duplicate Event; " + EVENT + " is already defined.", errorMessages));
        eventBuilder.tearDownConnections();
    }

    @Test
    public void testSaveMonNumber_MultipleRequests_DupliateMonNumber_ErrorsOut()
            throws Exception {
        eventBuilder.setupConnections();
        eventBuilder.insertEvent(EVENT);

        com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType comlTraitType = insert(new AcceptanceTestData<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType>() {
            public com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType dataToInsert() {
                return new ComlTraitTypeBuilder().
                        withTraitTypeAbbr(traitTypeAbbr).
                        withTraitTypeDesc("CTRT DESC").create();
            }
        });

        MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
        monNumberSaveRequest.setMonNumber(MON_NUMBER);
        monNumberSaveRequest.setCropPubkey(CROP_PUBKEY);
        monNumberSaveRequest.setEvent(EVENT);
        monNumberSaveRequest.setTraitTypeAbbreviations(new String[]{traitTypeAbbr});
        monNumberSaveRequest.setRegulatoryGenesPresent(LIST_OF_GENES_PRESENT);
        monNumberSaveRequest.setRegulatoryParentalLine(regulatoryParentalLine);
        monNumberSaveRequest.setAuditComment(AUDIT_COMMENT);
        monNumberSaveRequest.setAuditRequestor(AUDIT_REQESTOR);

        MonNumberSaveRequest monNumberSaveRequestTwo = new MonNumberSaveRequest();
        monNumberSaveRequestTwo.setMonNumber(MON_NUMBER);
        monNumberSaveRequestTwo.setRegulatoryGenesPresent(LIST_OF_GENES_PRESENT);
        monNumberSaveRequestTwo.setRegulatoryParentalLine(regulatoryParentalLine);
        monNumberSaveRequestTwo.setTraitTypeAbbreviations(new String[]{traitTypeAbbr});
        monNumberSaveRequestTwo.setAuditComment(AUDIT_COMMENT);
        monNumberSaveRequestTwo.setAuditRequestor(AUDIT_REQESTOR);

        MonNumberSaveBatchRequest monNumberSaveBatchRequest = new MonNumberSaveBatchRequest();
        monNumberSaveBatchRequest.setMonNumberSaveRequests(new MonNumberSaveRequest[]{monNumberSaveRequest, monNumberSaveRequestTwo});
        MonNumberSaveResponse[] monNumberSaveResponses = monNumberService.save(monNumberSaveBatchRequest);
        assertFalse(ArrayUtils.isEmpty(monNumberSaveResponses));
        assertEquals(2, monNumberSaveResponses.length);
        MonNumberSaveResponse monNumberSaveResponse = monNumberSaveResponses[0];
        assertTrue(monNumberSaveResponse.isSuccess());
        assertTrue(ArrayUtils.isEmpty(monNumberSaveResponse.getMessages()));
        Construct[] eventConstructs = monNumberSaveResponse.getEventConstructs();
        assertFalse(ArrayUtils.isEmpty(eventConstructs));
        Construct eventConstruct = eventConstructs[0];
        assertNotNull(eventConstruct);
        assertEquals(TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_FCM_PVCODE, eventConstruct.getPlasmidPMon());
        assertNotNull(monNumberSaveResponse.getTransformationBackground());

        MonNumberSaveResponse responseTwo = monNumberSaveResponses[1];
        assertFalse(responseTwo.isSuccess());
        assertFalse(ArrayUtils.isEmpty(responseTwo.getMessages()));
        String[] errorMessages = responseTwo.getMessages();
        assertTrue(containsErrorMessge("Mon Number is already defined.", errorMessages));
        eventBuilder.tearDownConnections();
    }

    /*  @Test
  public void testSaveMonNumber_MultipleConstructsFound_ErrorsOut_AndReturnsAllConstructs()
       throws Exception
    {
       eventBuilder.setupConnections();
       eventBuilder.insertEvent(EVENT);
       eventBuilder.insertEventConstruct(EVENT, "AT_CONSTRUCT");

       com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType comlTraitType = insert(new AcceptanceTestData<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType>()
       {
          public com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType dataToInsert() {
             return new ComlTraitTypeBuilder().
                withTraitTypeAbbr(traitTypeAbbr).
                withTraitTypeDesc("CTRT DESC").create();
          }
       });

       MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
       monNumberSaveRequest.setMonNumber(MON_NUMBER);
       monNumberSaveRequest.setCropPubkey(CROP_PUBKEY);
       monNumberSaveRequest.setMaterialName(EVENT);
       monNumberSaveRequest.setTraitTypeAbbreviations(new String[]{traitTypeAbbr});
       monNumberSaveRequest.setRegulatoryGenesPresent(LIST_OF_GENES_PRESENT);
       monNumberSaveRequest.setRegulatoryParentalLine(regulatoryParentalLine);
       monNumberSaveRequest.setAuditComment(AUDIT_COMMENT);
       monNumberSaveRequest.setAuditRequestor(AUDIT_REQESTOR);

       MonNumberSaveBatchRequest monNumberSaveBatchRequest = new MonNumberSaveBatchRequest();
       monNumberSaveBatchRequest.setMonNumberSaveRequests(new MonNumberSaveRequest[]{monNumberSaveRequest});
       MonNumberSaveResponse[] monNumberSaveResponses = monNumberService.save(monNumberSaveBatchRequest);
       assertFalse(ArrayUtils.isEmpty(monNumberSaveResponses));
       assertEquals(1, monNumberSaveResponses.length);
       MonNumberSaveResponse monNumberSaveResponse = monNumberSaveResponses[0];
       assertFalse(monNumberSaveResponse.isSuccess());
       assertFalse(ArrayUtils.isEmpty(monNumberSaveResponse.getMessages()));
       assertTrue(containsErrorMessge("Multiple plasmid PMONs found.  Please select one.", monNumberSaveResponse.getMessages()));
       Construct[] eventConstructs = monNumberSaveResponse.getEventConstructs();
       assertFalse(ArrayUtils.isEmpty(eventConstructs));
       Construct eventConstructOne = eventConstructs[0];
       assertNotNull(eventConstructOne);
       assertEquals(TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_FCM_PVCODE, eventConstructOne.getPlasmidPMon());
       Construct eventConstructTwo = eventConstructs[1];
       assertNotNull(eventConstructTwo);
       assertEquals("AT_CONSTRUCT", eventConstructTwo.getPlasmidPMon());
       eventBuilder.tearDownConnections();
    }*/


    @Test
    public void testSaveMonNumber_MultipleRequests_DupliateOecdNumber_ErrorsOut()
            throws Exception {
        eventBuilder.setupConnections();
        eventBuilder.insertEvent(EVENT);

        com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType comlTraitType = insert(new AcceptanceTestData<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType>() {
            public com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType dataToInsert() {
                return new ComlTraitTypeBuilder().
                        withTraitTypeAbbr(traitTypeAbbr).
                        withTraitTypeDesc("CTRT DESC").create();
            }
        });

        MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
        monNumberSaveRequest.setMonNumber(MON_NUMBER);
        monNumberSaveRequest.setCropPubkey(CROP_PUBKEY);
        monNumberSaveRequest.setTraitTypeAbbreviations(new String[]{traitTypeAbbr});
        monNumberSaveRequest.setOecdNumber("OECD1234");
        monNumberSaveRequest.setRegulatoryGenesPresent(LIST_OF_GENES_PRESENT);
        monNumberSaveRequest.setRegulatoryParentalLine(regulatoryParentalLine);
        monNumberSaveRequest.setAuditComment(AUDIT_COMMENT);
        monNumberSaveRequest.setAuditRequestor(AUDIT_REQESTOR);

        MonNumberSaveRequest monNumberSaveRequestTwo = new MonNumberSaveRequest();
        monNumberSaveRequestTwo.setMonNumber("MON 11225");
        monNumberSaveRequestTwo.setRegulatoryGenesPresent(LIST_OF_GENES_PRESENT);
        monNumberSaveRequestTwo.setRegulatoryParentalLine(regulatoryParentalLine);
        monNumberSaveRequestTwo.setOecdNumber("OECD1234");
        monNumberSaveRequestTwo.setTraitTypeAbbreviations(new String[]{traitTypeAbbr});
        monNumberSaveRequestTwo.setAuditComment(AUDIT_COMMENT);
        monNumberSaveRequestTwo.setAuditRequestor(AUDIT_REQESTOR);

        MonNumberSaveBatchRequest monNumberSaveBatchRequest = new MonNumberSaveBatchRequest();
        monNumberSaveBatchRequest.setMonNumberSaveRequests(new MonNumberSaveRequest[]{monNumberSaveRequest, monNumberSaveRequestTwo});
        MonNumberSaveResponse[] monNumberSaveResponses = monNumberService.save(monNumberSaveBatchRequest);
        assertFalse(ArrayUtils.isEmpty(monNumberSaveResponses));
        assertEquals(2, monNumberSaveResponses.length);
        MonNumberSaveResponse monNumberSaveResponse = monNumberSaveResponses[0];
        assertTrue(monNumberSaveResponse.isSuccess());
        assertTrue(ArrayUtils.isEmpty(monNumberSaveResponse.getMessages()));
        Construct[] eventConstructs = monNumberSaveResponse.getEventConstructs();
        assertTrue(ArrayUtils.isEmpty(eventConstructs));

        MonNumberSaveResponse responseTwo = monNumberSaveResponses[1];
        assertFalse(responseTwo.isSuccess());
        assertFalse(ArrayUtils.isEmpty(responseTwo.getMessages()));
        String[] errorMessages = responseTwo.getMessages();
        assertTrue(containsErrorMessge("OECD Number is already defined.", errorMessages));
        eventBuilder.tearDownConnections();
    }


    @Test
    public void testUpdateMonNumber_UpdatesMonNumberAndTriatType() {


        com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber testMonNumber = insert(new AcceptanceTestData<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber>() {
            public com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber dataToInsert() {
                return new MonNumberBuilder().
                        withMonNumber(MON_NUMBER).
                        withEventName("ZM_1111").
                        withCrop(CropBuilder.soybeans()).
                        withComlTraitType(new ComlTraitTypeBuilder().
                                withTraitTypeAbbr(traitTypeAbbr).
                                withTraitTypeDesc("CTRT DESC")
                        ).
                        createInDb();
            }
        });

        com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType traitType = insert(new AcceptanceTestData<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType>() {
            public com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType dataToInsert() {
                return new ComlTraitTypeBuilder().
                        withTraitTypeAbbr("UPDTAbbr").
                        withTraitTypeDesc("CTRT DESC").create();
            }
        });

        MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
        monNumberSaveRequest.setMonNumber(MON_NUMBER);
        monNumberSaveRequest.setTraitTypeAbbreviations(new String[]{"UPDTAbbr"});
        monNumberSaveRequest.setOecdNumber("UpdatedOECD");
        monNumberSaveRequest.setRegulatoryGenesPresent("Updated Genes");
        monNumberSaveRequest.setRegulatoryParentalLine("Updated Regulatory Parental Line");
        monNumberSaveRequest.setMaterialName("updated material");
        monNumberSaveRequest.setJvNumber("updated jv");
        monNumberSaveRequest.setCropPubkey("1415");
        monNumberSaveRequest.setAuditComment(AUDIT_COMMENT);
        monNumberSaveRequest.setAuditRequestor(AUDIT_REQESTOR);
        MonNumberSaveBatchRequest monNumberSaveBatchRequest = new MonNumberSaveBatchRequest();
        monNumberSaveBatchRequest.setMonNumberSaveRequests(new MonNumberSaveRequest[]{monNumberSaveRequest});
        MonNumberSaveResponse[] monNumberSaveResponses = monNumberService.update(monNumberSaveBatchRequest);
        assertFalse(ArrayUtils.isEmpty(monNumberSaveResponses));
        assertEquals(1, monNumberSaveResponses.length);
        MonNumberSaveResponse monNumberSaveResponse = monNumberSaveResponses[0];
        assertTrue(monNumberSaveResponse.isSuccess());
        assertTrue(ArrayUtils.isEmpty(monNumberSaveResponse.getMessages()));
        MonNumber[] monNumbers = monNumberService.findAll();
        MonNumber monNumberUpdated = findByMonNumber(MON_NUMBER, monNumbers);
        assertEquals("updated jv", monNumberUpdated.getJvNumber());
        assertEquals("updated material", monNumberUpdated.getMaterialName());
        assertEquals("UpdatedOECD", monNumberUpdated.getOecdNumber());
        assertEquals("Updated Genes", monNumberUpdated.getRegulatoryGenesPresent());
        assertEquals("1415", monNumberUpdated.getCropPubkey());
        assertEquals("Updated Regulatory Parental Line", monNumberUpdated.getRegulatoryParentalLine());
        Collection<ComlTraitType> comlTraitTypeCollection = monNumberUpdated.getComlTraitTypes();
        assertFalse(comlTraitTypeCollection.isEmpty());
        ComlTraitType comlTraitType = comlTraitTypeCollection.iterator().next();
        assertEquals("UPDTAbbr", comlTraitType.getComlTraitTypeAbbr());
    }

    @Test
    public void testUpdateMonNumber_UpdatesMonNumberAndTriatName() {


        com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber testMonNumber = insert(new AcceptanceTestData<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber>() {
            public com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber dataToInsert() {
                return new MonNumberBuilder().
                        withMonNumber(MON_NUMBER).
                        withEventName("ZM_1111").
                        withCrop(CropBuilder.soybeans()).
                        withComlTraitName(new ComlTraitNameBuilder().
                                withTraitAbbr(traitNameAbbr).
                                withTraitDesc("CTRT DESC")
                        ).
                        createInDb();
            }
        });

        com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName comlTraitName = insert(new AcceptanceTestData<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName>() {
            public com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName dataToInsert() {
                return new ComlTraitNameBuilder().
                        withTraitAbbr("UPDTAbbr").
                        withTraitDesc("TNDESC").create();
            }
        });


        MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
        monNumberSaveRequest.setMonNumber(MON_NUMBER);
        monNumberSaveRequest.setTraitNameAbbreviations(new String[]{"UPDTAbbr"});
        monNumberSaveRequest.setOecdNumber("UpdatedOECD");
        monNumberSaveRequest.setRegulatoryGenesPresent("Updated Genes");
        monNumberSaveRequest.setRegulatoryParentalLine("Updated Regulatory Parental Line");
        monNumberSaveRequest.setMaterialName("updated material");
        monNumberSaveRequest.setJvNumber("updated jv");
        monNumberSaveRequest.setCropPubkey("1415");
        monNumberSaveRequest.setAuditComment(AUDIT_COMMENT);
        monNumberSaveRequest.setAuditRequestor(AUDIT_REQESTOR);
        MonNumberSaveBatchRequest monNumberSaveBatchRequest = new MonNumberSaveBatchRequest();
        monNumberSaveBatchRequest.setMonNumberSaveRequests(new MonNumberSaveRequest[]{monNumberSaveRequest});
        MonNumberSaveResponse[] monNumberSaveResponses = monNumberService.update(monNumberSaveBatchRequest);
        assertFalse(ArrayUtils.isEmpty(monNumberSaveResponses));
        assertEquals(1, monNumberSaveResponses.length);
        MonNumberSaveResponse monNumberSaveResponse = monNumberSaveResponses[0];
        assertTrue(monNumberSaveResponse.isSuccess());
        assertTrue(ArrayUtils.isEmpty(monNumberSaveResponse.getMessages()));
        MonNumber[] monNumbers = monNumberService.findAll();
        MonNumber monNumberUpdated = findByMonNumber(MON_NUMBER, monNumbers);
        assertEquals("updated jv", monNumberUpdated.getJvNumber());
        assertEquals("updated material", monNumberUpdated.getMaterialName());
        assertEquals("UpdatedOECD", monNumberUpdated.getOecdNumber());
        assertEquals("Updated Genes", monNumberUpdated.getRegulatoryGenesPresent());
        assertEquals("Updated Regulatory Parental Line", monNumberUpdated.getRegulatoryParentalLine());
        assertEquals("1415", monNumberUpdated.getCropPubkey());
        Collection<ComlTraitName> comlTraitNameCollection = monNumberUpdated.getComlTraitNames();
        assertFalse(comlTraitNameCollection.isEmpty());
        ComlTraitName traitName = comlTraitNameCollection.iterator().next();
        assertEquals("UPDTAbbr", traitName.getTraitAbbr());
    }


    @Test
    public void testUpdateMonNumber_UpdatesMonNumberProtein() {


        com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber testMonNumber = insert(new AcceptanceTestData<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber>() {
            public com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber dataToInsert() {
                return new MonNumberBuilder().
                        withMonNumber(MON_NUMBER).
                        withEventName("ZM_1111").
                        withCrop(CropBuilder.soybeans()).
                        withProteinName(new ProteinNameBuilder().
                                withProteinName("PROTNAME").
                                withProteinNamePubkey("1234")
                        ).
                        createInDb();
            }
        });

        com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName proteinNameTwo = insert(new AcceptanceTestData<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName>() {
            public com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName dataToInsert() {
                return new ProteinNameBuilder().
                        withProteinName("PROT NAMETWO").
                        withProteinNamePubkey("PROTPKTWO").
                        withProteinDescription("PROT DESC").
                        withOrigSourceOrganism("ORIG SOURCE ORG").create();
            }
        });

        com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType traitType = insert(new AcceptanceTestData<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType>() {
            public com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType dataToInsert() {
                return new ComlTraitTypeBuilder().
                        withTraitTypeAbbr(traitTypeAbbr).
                        withTraitTypeDesc("CTRT DESC").create();
            }
        });

        MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
        monNumberSaveRequest.setMonNumber(MON_NUMBER);
        monNumberSaveRequest.setProteinNamePubkeys(new String[]{"PROTPKTWO"});
        monNumberSaveRequest.setRegulatoryGenesPresent(testMonNumber.getRegulatoryGenesPresent());
        monNumberSaveRequest.setRegulatoryParentalLine(regulatoryParentalLine);
        monNumberSaveRequest.setAuditComment(AUDIT_COMMENT);
        monNumberSaveRequest.setAuditRequestor(AUDIT_REQESTOR);
        monNumberSaveRequest.setCropPubkey(testMonNumber.getCrop().getCropPubkey());
        monNumberSaveRequest.setTraitTypeAbbreviations(new String[]{traitTypeAbbr});
        MonNumberSaveBatchRequest monNumberSaveBatchRequest = new MonNumberSaveBatchRequest();
        monNumberSaveBatchRequest.setMonNumberSaveRequests(new MonNumberSaveRequest[]{monNumberSaveRequest});
        MonNumberSaveResponse[] monNumberSaveResponses = monNumberService.update(monNumberSaveBatchRequest);
        assertFalse(ArrayUtils.isEmpty(monNumberSaveResponses));
        assertEquals(1, monNumberSaveResponses.length);
        MonNumberSaveResponse monNumberSaveResponse = monNumberSaveResponses[0];
        assertTrue(monNumberSaveResponse.isSuccess());
        assertTrue(ArrayUtils.isEmpty(monNumberSaveResponse.getMessages()));
        MonNumber[] monNumbers = monNumberService.findAll();
        MonNumber monNumberUpdated = findByMonNumber(MON_NUMBER, monNumbers);
        Collection<ProteinName> proteinNameCollection = monNumberUpdated.getProteinNames();
        assertFalse(proteinNameCollection.isEmpty());
        ProteinName proteinName = proteinNameCollection.iterator().next();
        assertEquals("PROTPKTWO", proteinName.getProteinNamePubkey());
    }


    @Test
    public void testUpdateMonNumber_DoesNotUpdateMonNumberConstruct_ForUnchangedEvent() {
        com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber testMonNumber = insert(new AcceptanceTestData<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber>() {
            public com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber dataToInsert() {
                return new MonNumberBuilder().
                        withMonNumber(MON_NUMBER).
                        withEventName("ZM_1111").
                        withCrop(CropBuilder.soybeans()).
                        withMonNumberConstruct(new MonNumberConstructBuilder().
                                withConstructName("CONNAME").
                                withPvCode("CONPV")
                        ).
                        createInDb();
            }
        });

        com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType traitType = insert(new AcceptanceTestData<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType>() {
            public com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType dataToInsert() {
                return new ComlTraitTypeBuilder().
                        withTraitTypeAbbr(traitTypeAbbr).
                        withTraitTypeDesc("CTRT DESC").create();
            }
        });
        MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
        monNumberSaveRequest.setMonNumber(MON_NUMBER);
        monNumberSaveRequest.setRegulatoryGenesPresent(testMonNumber.getRegulatoryGenesPresent());
        monNumberSaveRequest.setRegulatoryParentalLine(regulatoryParentalLine);
        monNumberSaveRequest.setTraitTypeAbbreviations(new String[]{traitTypeAbbr});
        monNumberSaveRequest.setAuditComment(AUDIT_COMMENT);
        monNumberSaveRequest.setAuditRequestor(AUDIT_REQESTOR);
        monNumberSaveRequest.setCropPubkey(testMonNumber.getCrop().getCropPubkey());
        monNumberSaveRequest.setEvent(testMonNumber.getEvent());
        MonNumberSaveBatchRequest monNumberSaveBatchRequest = new MonNumberSaveBatchRequest();
        monNumberSaveBatchRequest.setMonNumberSaveRequests(new MonNumberSaveRequest[]{monNumberSaveRequest});
        MonNumberSaveResponse[] monNumberSaveResponses = monNumberService.update(monNumberSaveBatchRequest);
        assertFalse(ArrayUtils.isEmpty(monNumberSaveResponses));
        assertEquals(1, monNumberSaveResponses.length);
        MonNumberSaveResponse monNumberSaveResponse = monNumberSaveResponses[0];
        assertTrue(monNumberSaveResponse.isSuccess());
        assertTrue(ArrayUtils.isEmpty(monNumberSaveResponse.getMessages()));
        MonNumber[] monNumbers = monNumberService.findAll();
        MonNumber monNumberUpdated = findByMonNumber(MON_NUMBER, monNumbers);
        assertFalse(monNumberUpdated.getMonNumberConstructs().isEmpty());
        assertEquals(1, monNumberUpdated.getMonNumberConstructs().size());
        MonNumberConstruct monNumberConstruct = monNumberUpdated.getMonNumberConstructs().iterator().next();
        assertEquals("CONNAME", monNumberConstruct.getConstructName());
        assertEquals("CONPV", monNumberConstruct.getPvCode());
    }

    @Test
    public void testUpdateMonNumber_UpdatesMonNumberConstructAndTransformationBackground_ForChangedEvent()
            throws Exception {

        eventBuilder.setupConnections();
        eventBuilder.insertEvent(EVENT);

        com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber testMonNumber = insert(new AcceptanceTestData<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber>() {
            public com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber dataToInsert() {
                return new MonNumberBuilder().
                        withMonNumber(MON_NUMBER).
                        withEventName("ZM_1111").
                        withCrop(CropBuilder.soybeans()).
                        withMonNumberConstruct(new MonNumberConstructBuilder().
                                withConstructName("CONNAME").
                                withPvCode("CONPV")
                        ).
                        createInDb();
            }
        });

        com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType traitType = insert(new AcceptanceTestData<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType>() {
            public com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType dataToInsert() {
                return new ComlTraitTypeBuilder().
                        withTraitTypeAbbr(traitTypeAbbr).
                        withTraitTypeDesc("CTRT DESC").create();
            }
        });
        MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
        monNumberSaveRequest.setMonNumber(MON_NUMBER);
        monNumberSaveRequest.setRegulatoryGenesPresent(testMonNumber.getRegulatoryGenesPresent());
        monNumberSaveRequest.setRegulatoryParentalLine(regulatoryParentalLine);
        monNumberSaveRequest.setTraitTypeAbbreviations(new String[]{traitTypeAbbr});
        monNumberSaveRequest.setAuditComment(AUDIT_COMMENT);
        monNumberSaveRequest.setAuditRequestor(AUDIT_REQESTOR);
        monNumberSaveRequest.setCropPubkey("1415");
        monNumberSaveRequest.setEvent(EVENT);
        MonNumberSaveBatchRequest monNumberSaveBatchRequest = new MonNumberSaveBatchRequest();
        monNumberSaveBatchRequest.setMonNumberSaveRequests(new MonNumberSaveRequest[]{monNumberSaveRequest});
        MonNumberSaveResponse[] monNumberSaveResponses = monNumberService.update(monNumberSaveBatchRequest);
        assertFalse(ArrayUtils.isEmpty(monNumberSaveResponses));
        assertEquals(1, monNumberSaveResponses.length);
        MonNumberSaveResponse monNumberSaveResponse = monNumberSaveResponses[0];
        assertTrue(monNumberSaveResponse.isSuccess());
        assertTrue(ArrayUtils.isEmpty(monNumberSaveResponse.getMessages()));
        Construct[] eventConstructs = monNumberSaveResponse.getEventConstructs();
        assertFalse(ArrayUtils.isEmpty(eventConstructs));
        Construct eventConstruct = eventConstructs[0];
        assertNotNull(eventConstruct);
        assertEquals(TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_FCM_PVCODE, eventConstruct.getPlasmidPMon());
        assertNotNull(monNumberSaveResponse.getTransformationBackground());

        MonNumber[] monNumbers = monNumberService.findAll();
        MonNumber monNumberUpdated = findByMonNumber(MON_NUMBER, monNumbers);
        assertFalse(monNumberUpdated.getMonNumberConstructs().isEmpty());
        assertEquals(1, monNumberUpdated.getMonNumberConstructs().size());
        MonNumberConstruct monNumberConstruct = monNumberUpdated.getMonNumberConstructs().iterator().next();
        assertEquals(TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_FCM_PVCODE, monNumberConstruct.getConstructName());
        eventBuilder.tearDownConnections();
    }

    @Test
    public void testUpdateMonNumber_RemovesMonNumberConstruct_ForRemovedEvent()
            throws Exception {
        com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber testMonNumber = insert(new AcceptanceTestData<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber>() {
            public com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber dataToInsert() {
                return new MonNumberBuilder().
                        withMonNumber(MON_NUMBER).
                        withEventName("ZM_1111").
                        withCrop(CropBuilder.soybeans()).
                        withMonNumberConstruct(new MonNumberConstructBuilder().
                                withConstructName("CONNAME").
                                withPvCode("CONPV")
                        ).
                        createInDb();
            }
        });

        com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType traitType = insert(new AcceptanceTestData<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType>() {
            public com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType dataToInsert() {
                return new ComlTraitTypeBuilder().
                        withTraitTypeAbbr(traitTypeAbbr).
                        withTraitTypeDesc("CTRT DESC").create();
            }
        });
        MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
        monNumberSaveRequest.setMonNumber(MON_NUMBER);
        monNumberSaveRequest.setRegulatoryGenesPresent(testMonNumber.getRegulatoryGenesPresent());
        monNumberSaveRequest.setRegulatoryParentalLine(regulatoryParentalLine);
        monNumberSaveRequest.setTraitTypeAbbreviations(new String[]{traitTypeAbbr});
        monNumberSaveRequest.setAuditComment(AUDIT_COMMENT);
        monNumberSaveRequest.setAuditRequestor(AUDIT_REQESTOR);
        monNumberSaveRequest.setCropPubkey("1415");
        MonNumberSaveBatchRequest monNumberSaveBatchRequest = new MonNumberSaveBatchRequest();
        monNumberSaveBatchRequest.setMonNumberSaveRequests(new MonNumberSaveRequest[]{monNumberSaveRequest});
        MonNumberSaveResponse[] monNumberSaveResponses = monNumberService.update(monNumberSaveBatchRequest);
        assertFalse(ArrayUtils.isEmpty(monNumberSaveResponses));
        assertEquals(1, monNumberSaveResponses.length);
        MonNumberSaveResponse monNumberSaveResponse = monNumberSaveResponses[0];
        assertTrue(monNumberSaveResponse.isSuccess());
        assertTrue(ArrayUtils.isEmpty(monNumberSaveResponse.getMessages()));
        Construct[] eventConstructs = monNumberSaveResponse.getEventConstructs();
        assertTrue(ArrayUtils.isEmpty(eventConstructs));

        MonNumber[] monNumbers = monNumberService.findAll();
        MonNumber monNumberUpdated = findByMonNumber(MON_NUMBER, monNumbers);
        assertTrue(monNumberUpdated.getMonNumberConstructs().isEmpty());
    }


    @Test
    public void testUpdateMonNumber_DoesNotRemovesMonNumberConstruct_ForRemovedEventAndValidateOnly()
            throws Exception {
        com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber testMonNumber = insert(new AcceptanceTestData<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber>() {
            public com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber dataToInsert() {
                return new MonNumberBuilder().
                        withMonNumber(MON_NUMBER).
                        withEventName("ZM_1111").
                        withCrop(CropBuilder.soybeans()).
                        withMonNumberConstruct(new MonNumberConstructBuilder().
                                withConstructName("CONNAME").
                                withPvCode("CONPV")
                        ).
                        createInDb();
            }
        });

        com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType traitType = insert(new AcceptanceTestData<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType>() {
            public com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType dataToInsert() {
                return new ComlTraitTypeBuilder().
                        withTraitTypeAbbr(traitTypeAbbr).
                        withTraitTypeDesc("CTRT DESC").create();
            }
        });
        MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
        monNumberSaveRequest.setMonNumber(MON_NUMBER);
        monNumberSaveRequest.setRegulatoryGenesPresent(testMonNumber.getRegulatoryGenesPresent());
        monNumberSaveRequest.setRegulatoryParentalLine(regulatoryParentalLine);
        monNumberSaveRequest.setTraitTypeAbbreviations(new String[]{traitTypeAbbr});
        monNumberSaveRequest.setAuditComment(AUDIT_COMMENT);
        monNumberSaveRequest.setAuditRequestor(AUDIT_REQESTOR);
        monNumberSaveRequest.setCropPubkey("1415");
        MonNumberSaveBatchRequest monNumberSaveBatchRequest = new MonNumberSaveBatchRequest();
        monNumberSaveBatchRequest.setValidateOnly(true);
        monNumberSaveBatchRequest.setMonNumberSaveRequests(new MonNumberSaveRequest[]{monNumberSaveRequest});
        MonNumberSaveResponse[] monNumberSaveResponses = monNumberService.update(monNumberSaveBatchRequest);
        assertFalse(ArrayUtils.isEmpty(monNumberSaveResponses));
        assertEquals(1, monNumberSaveResponses.length);
        MonNumberSaveResponse monNumberSaveResponse = monNumberSaveResponses[0];
        assertTrue(monNumberSaveResponse.isSuccess());
        assertTrue(ArrayUtils.isEmpty(monNumberSaveResponse.getMessages()));
        Construct[] eventConstructs = monNumberSaveResponse.getEventConstructs();
        assertTrue(ArrayUtils.isEmpty(eventConstructs));

        MonNumber[] monNumbers = monNumberService.findAll();
        MonNumber monNumberUpdated = findByMonNumber(MON_NUMBER, monNumbers);
        assertFalse(monNumberUpdated.getMonNumberConstructs().isEmpty());
    }

    @Test
    public void testUpdateMonNumber_ReturnsErrorMessges_ForValidationFailure()
            throws Exception {
        MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
        MonNumberSaveBatchRequest monNumberSaveBatchRequest = new MonNumberSaveBatchRequest();
        monNumberSaveBatchRequest.setMonNumberSaveRequests(new MonNumberSaveRequest[]{monNumberSaveRequest});
        MonNumberSaveResponse[] monNumberSaveResponses = monNumberService.update(monNumberSaveBatchRequest);
        assertFalse(ArrayUtils.isEmpty(monNumberSaveResponses));
        assertEquals(1, monNumberSaveResponses.length);
        MonNumberSaveResponse monNumberSaveResponse = monNumberSaveResponses[0];
        assertFalse(monNumberSaveResponse.isSuccess());
        assertFalse(ArrayUtils.isEmpty(monNumberSaveResponse.getMessages()));
        assertTrue(containsErrorMessge("Mon Number format must be MON 99999(-).", monNumberSaveResponse.getMessages()));
        assertTrue(containsErrorMessge("Regulatory Trait Description may not be empty.", monNumberSaveResponse.getMessages()));
        assertTrue(containsErrorMessge("Regulatory Genes Present may not be empty.", monNumberSaveResponse.getMessages()));
        assertTrue(containsErrorMessge("Regulatory Parental Line may not be empty.", monNumberSaveResponse.getMessages()));
        assertTrue(containsErrorMessge("Audit Comment field must not be blank.", monNumberSaveResponse.getMessages()));
        assertTrue(containsErrorMessge("Audit Requestor must not be blank.", monNumberSaveResponse.getMessages()));
    }


    @Test
    public void testUpdateMonNumber_MonNumberNotFound_ErrorsOut()
            throws Exception {
        MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
        monNumberSaveRequest.setMonNumber("MON 99991");
        monNumberSaveRequest.setRegulatoryGenesPresent("genes present");
        monNumberSaveRequest.setRegulatoryParentalLine(regulatoryParentalLine);
        monNumberSaveRequest.setAuditComment(AUDIT_COMMENT);
        monNumberSaveRequest.setAuditRequestor(AUDIT_REQESTOR);
        monNumberSaveRequest.setCropPubkey("1415");
        MonNumberSaveBatchRequest monNumberSaveBatchRequest = new MonNumberSaveBatchRequest();
        monNumberSaveBatchRequest.setMonNumberSaveRequests(new MonNumberSaveRequest[]{monNumberSaveRequest});
        MonNumberSaveResponse[] monNumberSaveResponses = monNumberService.update(monNumberSaveBatchRequest);
        assertFalse(ArrayUtils.isEmpty(monNumberSaveResponses));
        assertEquals(1, monNumberSaveResponses.length);
        MonNumberSaveResponse monNumberSaveResponse = monNumberSaveResponses[0];
        assertFalse(monNumberSaveResponse.isSuccess());
        assertFalse(ArrayUtils.isEmpty(monNumberSaveResponse.getMessages()));
        assertTrue(containsErrorMessge("Mon Number does not exist.", monNumberSaveResponse.getMessages()));
    }


    @Test
    public void testUpdateMonNumber_MultipleRequests_MixedResult()
            throws Exception {
        com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber testMonNumber = insert(new AcceptanceTestData<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber>() {
            public com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber dataToInsert() {
                return new MonNumberBuilder().
                        withMonNumber(MON_NUMBER).
                        withOecdNumber(OECD_NUMBER).
                        withCrop(CropBuilder.soybeans()).
                        createInDb();
            }
        });

        com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber testMonNumberTwo = insert(new AcceptanceTestData<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber>() {
            public com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber dataToInsert() {
                return new MonNumberBuilder().
                        withMonNumber("MON 99993").
                        withCrop(CropBuilder.soybeans()).
                        createInDb();
            }
        });

        com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType traitType = insert(new AcceptanceTestData<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType>() {
            public com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType dataToInsert() {
                return new ComlTraitTypeBuilder().
                        withTraitTypeAbbr(traitTypeAbbr).
                        withTraitTypeDesc("CTRT DESC").create();
            }
        });

        MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
        monNumberSaveRequest.setMonNumber(MON_NUMBER);
        monNumberSaveRequest.setTraitTypeAbbreviations(new String[]{traitTypeAbbr});
        monNumberSaveRequest.setRegulatoryGenesPresent("Updated Genes");
        monNumberSaveRequest.setRegulatoryParentalLine("Updated Regulatory Parental Line");
        monNumberSaveRequest.setMaterialName("updated material");
        monNumberSaveRequest.setCropPubkey("1415");
        monNumberSaveRequest.setAuditComment(AUDIT_COMMENT);
        monNumberSaveRequest.setAuditRequestor(AUDIT_REQESTOR);

        MonNumberSaveRequest monNumberSaveRequestTwo = new MonNumberSaveRequest();
        monNumberSaveRequestTwo.setMonNumber("MON 99993");
        monNumberSaveRequestTwo.setTraitTypeAbbreviations(new String[]{traitTypeAbbr});
        monNumberSaveRequestTwo.setMaterialName("updated material");

        MonNumberSaveBatchRequest monNumberSaveBatchRequest = new MonNumberSaveBatchRequest();
        monNumberSaveBatchRequest.setMonNumberSaveRequests(new MonNumberSaveRequest[]{monNumberSaveRequest, monNumberSaveRequestTwo});
        MonNumberSaveResponse[] monNumberSaveResponses = monNumberService.update(monNumberSaveBatchRequest);
        assertFalse(ArrayUtils.isEmpty(monNumberSaveResponses));
        assertEquals(2, monNumberSaveResponses.length);
        MonNumberSaveResponse monNumberSaveResponse = monNumberSaveResponses[0];
        assertTrue(monNumberSaveResponse.isSuccess());
        assertTrue(ArrayUtils.isEmpty(monNumberSaveResponse.getMessages()));

        MonNumberSaveResponse monNumberSaveResponseTwo = monNumberSaveResponses[1];
        assertFalse(monNumberSaveResponseTwo.isSuccess());
        assertFalse(ArrayUtils.isEmpty(monNumberSaveResponseTwo.getMessages()));
    }

    @Test
    public void testUpdateMonNumber_EventAssociatedWithOtherMonNumber_ErrorsOut()
            throws Exception {
        com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber otherMonNumber = insert(new AcceptanceTestData<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber>() {
            public com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber dataToInsert() {
                return new MonNumberBuilder().
                        withMonNumber(MON_NUMBER).
                        withEventName("ZM_1111").
                        withCrop(CropBuilder.soybeans()).
                        createInDb();
            }
        });

        com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber testMonNumber = insert(new AcceptanceTestData<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber>() {
            public com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber dataToInsert() {
                return new MonNumberBuilder().
                        withMonNumber("MON 99991").
                        withOecdNumber("OECD1111").
                        createInDb();
            }
        });

        MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
        monNumberSaveRequest.setMonNumber("MON 99991");
        monNumberSaveRequest.setEvent(otherMonNumber.getEvent());
        MonNumberSaveBatchRequest monNumberSaveBatchRequest = new MonNumberSaveBatchRequest();
        monNumberSaveBatchRequest.setMonNumberSaveRequests(new MonNumberSaveRequest[]{monNumberSaveRequest});
        MonNumberSaveResponse[] monNumberSaveResponses = monNumberService.update(monNumberSaveBatchRequest);
        assertFalse(ArrayUtils.isEmpty(monNumberSaveResponses));
        assertEquals(1, monNumberSaveResponses.length);
        MonNumberSaveResponse monNumberSaveResponse = monNumberSaveResponses[0];
        assertFalse(monNumberSaveResponse.isSuccess());
        assertFalse(ArrayUtils.isEmpty(monNumberSaveResponse.getMessages()));
        assertTrue(containsErrorMessge("Duplicate Event; " + "ZM_1111" + " is already defined.", monNumberSaveResponse.getMessages()));
    }

    @Test
    public void testUpdateMonNumber_OecdAssociatedWithOtherMonNumber_ErrorsOut()
            throws Exception {
        com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber otherMonNumber = insert(new AcceptanceTestData<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber>() {
            public com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber dataToInsert() {
                return new MonNumberBuilder().
                        withMonNumber(MON_NUMBER).
                        withCrop(CropBuilder.soybeans()).
                        createInDb();
            }
        });

        com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber testMonNumber = insert(new AcceptanceTestData<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber>() {
            public com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber dataToInsert() {
                return new MonNumberBuilder().
                        withMonNumber("MON 99991").
                        withOecdNumber("OECD1111").
                        createInDb();
            }
        });

        MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
        monNumberSaveRequest.setMonNumber("MON 99991");
        monNumberSaveRequest.setOecdNumber(otherMonNumber.getOecdNumber());
        MonNumberSaveBatchRequest monNumberSaveBatchRequest = new MonNumberSaveBatchRequest();
        monNumberSaveBatchRequest.setMonNumberSaveRequests(new MonNumberSaveRequest[]{monNumberSaveRequest});
        MonNumberSaveResponse[] monNumberSaveResponses = monNumberService.update(monNumberSaveBatchRequest);
        assertFalse(ArrayUtils.isEmpty(monNumberSaveResponses));
        assertEquals(1, monNumberSaveResponses.length);
        MonNumberSaveResponse monNumberSaveResponse = monNumberSaveResponses[0];
        assertFalse(monNumberSaveResponse.isSuccess());
        assertFalse(ArrayUtils.isEmpty(monNumberSaveResponse.getMessages()));
        assertTrue(containsErrorMessge("OECD Number is already defined.", monNumberSaveResponse.getMessages()));
    }

    private MonNumber findByMonNumber(String monNumber, MonNumber[] monNumbers) {
        for (MonNumber number : monNumbers) {
            if (monNumber.equals(number.getMonNumber())) {
                return number;
            }
        }
        return null;
    }

    private boolean containsErrorMessge(String errorMessage, String[] errorMessages) {
        for (String message : errorMessages) {
            if (errorMessage.equalsIgnoreCase(message)) {
                return true;
            }
        }
        return false;
    }

    private MonNumber getMonNumber(String monNumber, MonNumber[] monNumbers) {
        for (MonNumber number : monNumbers) {
            if (monNumber.equalsIgnoreCase(number.getMonNumber())) {
                return number;
            }
        }
        return null;
    }

    @After
    public void onTearDown()
            throws Exception {

        if (eventBuilder.getTestManager() != null) {
            eventBuilder.tearDownConnections();
        }
    }
}
