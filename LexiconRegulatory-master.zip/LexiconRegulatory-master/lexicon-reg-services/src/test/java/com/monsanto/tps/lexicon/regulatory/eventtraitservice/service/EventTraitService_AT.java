/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.eventtraitservice.service;

import com.monsanto.tps.compliance.referencedata.molecularinfo.ConstructIdentifier;
import com.monsanto.tps.compliance.referencedata.molecularinfo.ConstructPVCodeAssignment;
import com.monsanto.tps.compliance.referencedata.molecularinfo.PvCode;
import com.monsanto.tps.compliance.referencedata.services.ProductVectorLookupService;
import com.monsanto.tps.lexicon.eventtraitservice.GermplasmEventTraitService;
import com.monsanto.tps.lexicon.eventtraitservice.transfer.*;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.LexiconAcceptanceTestCase;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.MonNumberBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.TestDataBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Crop;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.LexiconProductEntity;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.LexiconProductStageEntity;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.MonNumber;
import com.monsanto.tps.lexicon.regulatory.DB.fbscommon.model.ProductXrefEntity;
import com.monsanto.tps.lexicon.regulatory.DB.midas.model.*;
import com.monsanto.tps.lexicon.regulatory.eventtraitservice.business.PVCodeAssignmentBuilder;
import com.monsanto.tps.lexicon.regulatory.eventtraitservice.business.PVCodesTransformer;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

import static junit.framework.Assert.*;
import static org.mockito.Mockito.when;

/* vvkalu - 8/15/11 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
        "/com/monsanto/tps/lexicon/regulatory/contexts/test-external-services-context.xml"})
@Ignore("temp fix for OOM")
public class EventTraitService_AT extends LexiconAcceptanceTestCase {

    private static final String EVENT = "AT_EVENTNAME_TEST";
    private static final String EVENT_CONSTRUCT = "AT_EVENTCONSTRUCT_NAME";
    private static final String ERROR_STRING = "No Commercial Trait Stack, MonNumbers or PVCodes found for the germplasm";
    @Resource
    private GermplasmEventTraitService germplasmEventTraitService;
    @Resource
    private ProductVectorLookupService productVectorLookupService;
    @Resource
    private PVCodesTransformer pvCodesTransformer;

    @Test
    public void test_Error_When_NothingIsReturned() {
        GermplasmEventTraitRequest germplasmEventTraitRequest = new GermplasmEventTraitRequest();
        long germplasmId = -62252764764L;
        germplasmEventTraitRequest.setGermplasmIds(Arrays.asList(germplasmId));
        GermplasmEventTraitResponse eventTraitResponse = germplasmEventTraitService.getGermplasmTraitEventConstructs(germplasmEventTraitRequest);
        assertNotNull(eventTraitResponse);
        assertTrue(!eventTraitResponse.getGermplasmEventTraits().isEmpty());
        assertEquals(germplasmId, eventTraitResponse.getGermplasmEventTraits().get(0).getGermplasmId());
        assertEquals(ResponseMessageType.ERROR, eventTraitResponse.getGermplasmEventTraits().get(0).getResponseMessage().getResponseType());
        assertEquals(ERROR_STRING, eventTraitResponse.getGermplasmEventTraits().get(0).getResponseMessage().getMessage());
    }

    @Test
    public void test_ComlTrait_of_PreComlProduct() {
        ProductGermplasmEntity entity = new ProductGermplasmEntity();
        entity.setId(TestDataBuilder.generateRandomNegativeLong());
        entity.setPreferred(false);

        MidasProductEntity productEntity = new MidasProductEntity();
        productEntity.setCrop(TestDataBuilder.buildMidasCrop(currentSession));
        productEntity.setId(TestDataBuilder.generateRandomNegativeLong());
        productEntity.setRefActive(true);

        final ProductXrefEntity xrefEntity = new ProductXrefEntity();
        xrefEntity.setProduct(productEntity);

        productEntity.setXref(xrefEntity);
        productEntity.setProductGermplasms(new ArrayList<ProductGermplasmEntity>(Arrays.asList(entity)));

        GermplasmEntity germplasm = createGermplasm();

        entity.setProduct(productEntity);
        entity.setGermplasm(germplasm);

        final LexiconProductEntity dbProduct = insert(new AcceptanceTestData<LexiconProductEntity>() {
            public LexiconProductEntity dataToInsert() {
                LexiconProductEntity lexiconProductEntity = new LexiconProductEntity();
                lexiconProductEntity.setProductPubkey(TestDataBuilder.generateRandomNumberString(20));
                lexiconProductEntity.setPreComlName(TestDataBuilder.generateRandomNumberString(40));
                lexiconProductEntity.setLogicalDelete(false);
                lexiconProductEntity.setParentProduct(false);
                lexiconProductEntity.setCrop(TestDataBuilder.buildLexiconCrop(currentSession, null));
                lexiconProductEntity.setId(TestDataBuilder.generateRandomNegativeLong());

                LexiconProductStageEntity productStageEntity = new LexiconProductStageEntity();
                productStageEntity.setProductStageId(TestDataBuilder.generateRandomNegativeLong());
                productStageEntity.setProductStagePubkey(TestDataBuilder.generateRandomNumberString(20));
                productStageEntity.setActive(true);
                productStageEntity.setLogicalDelete(false);
                productStageEntity.setStage(TestDataBuilder.buildLexiconStage(currentSession));
                productStageEntity.setPreComlProduct(lexiconProductEntity);
                productStageEntity.setBrand(TestDataBuilder.buildLexiconBrand(currentSession));
                productStageEntity.setComlTraitStack(TestDataBuilder.buildComlTraitStack(currentSession));
                productStageEntity.setCountry(TestDataBuilder.buildLexiconCountry(currentSession));
                lexiconProductEntity.setProductStages(new HashSet<LexiconProductStageEntity>(Arrays.asList(productStageEntity)));

                currentSession.save(lexiconProductEntity);
                currentSession.save(productStageEntity);
                return lexiconProductEntity;
            }
        });
        xrefEntity.setLexiconProductPubkey(dbProduct.getProductPubkey());
        dbProduct.setProductXrefs(new HashSet<ProductXrefEntity>(Arrays.asList(xrefEntity)));
        currentSession.saveOrUpdate(dbProduct);
        currentSession.save(productEntity);
        currentSession.save(xrefEntity);
        currentSession.save(germplasm);
        currentSession.save(entity);
        currentSession.flush();
        currentSession.clear();

        GermplasmEventTraitRequest germplasmEventTraitRequest = new GermplasmEventTraitRequest();
        germplasmEventTraitRequest.setGermplasmIds(Arrays.asList(germplasm.getId()));
        GermplasmEventTraitResponse eventTraitResponse = germplasmEventTraitService
                .getGermplasmTraitEventConstructs(germplasmEventTraitRequest);
        assertNotNull(eventTraitResponse);
        assertEquals(1, eventTraitResponse.getGermplasmEventTraits().size());
        assertNotNull(eventTraitResponse.getGermplasmEventTraits().get(0).getTraitStack());
        assertEquals(ResponseMessageType.SUCCESS, eventTraitResponse.getGermplasmEventTraits().get(0).getResponseMessage().getResponseType());
    }

    @Test
    public void test_ComlTrait_of_F1_Generated_Germplasm() {
        GermplasmEventTraitRequest germplasmEventTraitRequest = new GermplasmEventTraitRequest();
        germplasmEventTraitRequest.setGermplasmIds(Arrays.asList(131650L));
        GermplasmEventTraitResponse eventTraitResponse = germplasmEventTraitService
                .getGermplasmTraitEventConstructs(germplasmEventTraitRequest);
        assertNotNull(eventTraitResponse);
        assertEquals(1, eventTraitResponse.getGermplasmEventTraits().size());
        assertNotNull(eventTraitResponse.getGermplasmEventTraits().get(0).getTraitStack());
        assertEquals(ResponseMessageType.SUCCESS, eventTraitResponse.getGermplasmEventTraits().get(0).getResponseMessage().getResponseType());
    }

    @Test
    public void test_ComlTrait_only_MonNumbers() {
        final GermplasmEntity germplasm = createGermplasm();
        EventConstructEntity constructEntity = createEventConstruct();
        GermplasmEventConstructEntity germplasmEventConstructEntity = createGermplasmEventConstruct(constructEntity, germplasm);
        final Crop lexiconCrop = insert(new AcceptanceTestData<Crop>() {
            public Crop dataToInsert() {
                return TestDataBuilder.buildLexiconCrop(currentSession, germplasm.getCrop().getName());
            }
        });

        insert(new AcceptanceTestData<MonNumber>() {
            public MonNumber dataToInsert() {
                return new MonNumberBuilder().
                        withMonNumber("MON_1111").
                        withCrop(lexiconCrop).
                        withEventName(EVENT).createInDb();
            }
        });

        currentSession.save(germplasm);
        currentSession.save(constructEntity);
        currentSession.save(germplasmEventConstructEntity);
        currentSession.flush();
        currentSession.clear();

        ConstructIdentifier constructIdentifier = new ConstructIdentifier();
        constructIdentifier.setNames(Arrays.asList(EVENT_CONSTRUCT));
        when(productVectorLookupService.findProductVectorsByCropIdAndConstructs(
                Long.valueOf(lexiconCrop.getCropPubkey()), Arrays.asList(constructIdentifier))).thenReturn(null);
        GermplasmEventTraitRequest germplasmEventTraitRequest = new GermplasmEventTraitRequest();
        germplasmEventTraitRequest.setGermplasmIds(Arrays.asList(germplasm.getId()));
        GermplasmEventTraitResponse eventTraitResponse = germplasmEventTraitService.getGermplasmTraitEventConstructs(germplasmEventTraitRequest);
        assertNotNull(eventTraitResponse);
        assertEquals(1, eventTraitResponse.getGermplasmEventTraits().size());
        GermplasmEventTrait germplasmEventTrait = eventTraitResponse.getGermplasmEventTraits().get(0);
        assertEquals(germplasm.getId(), germplasmEventTrait.getGermplasmId());
        assertNull(germplasmEventTrait.getTraitStack());
        assertEquals(1, germplasmEventTrait.getEventConstruct().size());
        MidasEventConstruct midasEventConstruct = germplasmEventTrait.getEventConstruct().get(0);
        assertEquals("MON_1111", midasEventConstruct.getEventMonNumbers().get(0).getMonNumber());
        assertEquals(constructEntity.getId(), midasEventConstruct.getEventConstructId());
        assertEquals(ResponseMessageType.SUCCESS, germplasmEventTrait.getResponseMessage().getResponseType());
    }

    @Test
    public void test_ComlTrait_MonNumbers_PVCodes() {
        final GermplasmEntity germplasm = createGermplasm();
        EventConstructEntity constructEntity = createEventConstruct();
        GermplasmEventConstructEntity germplasmEventConstructEntity = createGermplasmEventConstruct(constructEntity, germplasm);
        final Crop lexiconCrop = insert(new AcceptanceTestData<Crop>() {
            public Crop dataToInsert() {
                return TestDataBuilder.buildLexiconCrop(currentSession, germplasm.getCrop().getName());
            }
        });

        insert(new AcceptanceTestData<MonNumber>() {
            public MonNumber dataToInsert() {
                return new MonNumberBuilder().
                        withMonNumber("MON_1111").
                        withCrop(lexiconCrop).
                        withEventName(EVENT).createInDb();
            }
        });

        currentSession.save(germplasm);
        currentSession.save(constructEntity);
        currentSession.save(germplasmEventConstructEntity);
        currentSession.flush();
        currentSession.clear();

        ConstructIdentifier constructIdentifier = new ConstructIdentifier();
        constructIdentifier.setNames(Arrays.asList(EVENT_CONSTRUCT));
        List<PvCode> pvCodes = PVCodeAssignmentBuilder.formPVCodes(Arrays.asList("PVC1", "PVC2"));
        ConstructPVCodeAssignment pvCodeAssignment = new ConstructPVCodeAssignment(constructIdentifier, pvCodes);
        when(productVectorLookupService.findProductVectorsByCropIdAndConstructs(
                Long.valueOf(lexiconCrop.getCropPubkey()), Arrays.asList(constructIdentifier))).thenReturn(Arrays.asList(pvCodeAssignment));
        GermplasmEventTraitRequest germplasmEventTraitRequest = new GermplasmEventTraitRequest();
        germplasmEventTraitRequest.setGermplasmIds(Arrays.asList(germplasm.getId()));
        GermplasmEventTraitResponse eventTraitResponse = germplasmEventTraitService.getGermplasmTraitEventConstructs(germplasmEventTraitRequest);
        assertNotNull(eventTraitResponse);
        assertEquals(1, eventTraitResponse.getGermplasmEventTraits().size());
        GermplasmEventTrait germplasmEventTrait = eventTraitResponse.getGermplasmEventTraits().get(0);
        assertEquals(germplasm.getId(), germplasmEventTrait.getGermplasmId());
        assertNull(germplasmEventTrait.getTraitStack());
        assertEquals(1, germplasmEventTrait.getEventConstruct().size());
        MidasEventConstruct midasEventConstruct = germplasmEventTrait.getEventConstruct().get(0);
        assertEquals("MON_1111", midasEventConstruct.getEventMonNumbers().get(0).getMonNumber());
        assertEquals(constructEntity.getId(), midasEventConstruct.getEventConstructId());
        List<PVCode> lexiconPVCodes = pvCodesTransformer.formLexiconPVCodeList(pvCodes);
        assertTrue(midasEventConstruct.getPvCodes().containsAll(lexiconPVCodes));
        assertEquals(ResponseMessageType.SUCCESS, germplasmEventTrait.getResponseMessage().getResponseType());
    }

    @Test
    public void test_ComlTrait_MultipleGermplasms_MonNumbers_PVCodes() {
        final GermplasmEntity germplasm = createGermplasm();
        EventConstructEntity constructEntity = createEventConstruct();
        GermplasmEventConstructEntity germplasmEventConstructEntity = createGermplasmEventConstruct(constructEntity, germplasm);

        GermplasmEntity germplasm1 = createGermplasm();
        EventConstructEntity constructEntity1 = new EventConstructEntity();
        Long eventConstructId = TestDataBuilder.generateRandomNegativeLong();
        constructEntity1.setId(eventConstructId);
        constructEntity1.setBarcode(TestDataBuilder.generateRandomNumberString(50));
        constructEntity1.setCrop(TestDataBuilder.buildMidasCrop(currentSession));
        constructEntity1.setConstructName(EVENT_CONSTRUCT + ",ECN");
        constructEntity1.setEventName(EVENT + "1");
        constructEntity1.setRefActive(true);
        constructEntity1.setName(TestDataBuilder.generateRandomNumberString(80));
        GermplasmEventConstructEntity germplasmEventConstructEntity1 = createGermplasmEventConstruct(constructEntity1, germplasm1);

        final Crop lexiconCrop = insert(new AcceptanceTestData<Crop>() {
            public Crop dataToInsert() {
                return TestDataBuilder.buildLexiconCrop(currentSession, germplasm.getCrop().getName());
            }
        });

        insert(new AcceptanceTestData<MonNumber>() {
            public MonNumber dataToInsert() {
                return new MonNumberBuilder().
                        withMonNumber("MON_1111").
                        withCrop(lexiconCrop).
                        withEventName(EVENT).createInDb();
            }
        });

        insert(new AcceptanceTestData<MonNumber>() {
            public MonNumber dataToInsert() {
                return new MonNumberBuilder().
                        withMonNumber("MON_6473").
                        withCrop(lexiconCrop).
                        withEventName(EVENT + "1").
                        withOecdNumber("OED8789").createInDb();
            }
        });

        currentSession.save(germplasm);
        currentSession.save(germplasm1);
        currentSession.save(constructEntity);
        currentSession.save(constructEntity1);
        currentSession.save(germplasmEventConstructEntity);
        currentSession.save(germplasmEventConstructEntity1);
        currentSession.flush();
        currentSession.clear();

        ConstructIdentifier constructIdentifier = new ConstructIdentifier();
        constructIdentifier.setNames(Arrays.asList(EVENT_CONSTRUCT));
        when(productVectorLookupService.findProductVectorsByCropIdAndConstructs(
                Long.valueOf(lexiconCrop.getCropPubkey()), Arrays.asList(constructIdentifier))).thenReturn(null);
        ConstructIdentifier constructIdentifier1 = new ConstructIdentifier();
        constructIdentifier1.setNames(Arrays.asList(EVENT_CONSTRUCT, "ECN"));
        List<PvCode> pvCodes = PVCodeAssignmentBuilder.formPVCodes(Arrays.asList("PVC1", "PVC2"));
        ConstructPVCodeAssignment pvCodeAssignment = new ConstructPVCodeAssignment(constructIdentifier, pvCodes);
        when(productVectorLookupService.findProductVectorsByCropIdAndConstructs(
                Long.valueOf(lexiconCrop.getCropPubkey()), Arrays.asList(constructIdentifier1))).thenReturn(Arrays.asList(pvCodeAssignment));

        GermplasmEventTraitRequest germplasmEventTraitRequest = new GermplasmEventTraitRequest();
        germplasmEventTraitRequest.setGermplasmIds(Arrays.asList(germplasm.getId(), germplasm1.getId(), 87498485L));
        GermplasmEventTraitResponse eventTraitResponse = germplasmEventTraitService.getGermplasmTraitEventConstructs(germplasmEventTraitRequest);
        assertNotNull(eventTraitResponse);
        assertEquals(3, eventTraitResponse.getGermplasmEventTraits().size());
        GermplasmEventTrait germplasmEventTrait = eventTraitResponse.getGermplasmEventTraits().get(0);
        assertEquals(germplasm.getId(), germplasmEventTrait.getGermplasmId());
        assertNull(germplasmEventTrait.getTraitStack());
        assertEquals(1, germplasmEventTrait.getEventConstruct().size());
        MidasEventConstruct midasEventConstruct = germplasmEventTrait.getEventConstruct().get(0);
        assertEquals("MON_1111", midasEventConstruct.getEventMonNumbers().get(0).getMonNumber());
        assertEquals(constructEntity.getId(), midasEventConstruct.getEventConstructId());
        assertEquals(ResponseMessageType.SUCCESS, germplasmEventTrait.getResponseMessage().getResponseType());
    }

    private GermplasmEntity createGermplasm() {
        GermplasmEntity germplasm = new GermplasmEntity();
        Long germplasmId = TestDataBuilder.generateRandomNegativeLong();
        germplasm.setId(germplasmId);
        germplasm.setEventDisplay(TestDataBuilder.generateRandomNumberString(20));
        germplasm.setDeleted(false);
        germplasm.setFinished(true);
        germplasm.setLinecode(TestDataBuilder.generateRandomNumberString(50));
        germplasm.setLineType(TestDataBuilder.buildLineType(currentSession));
        final MidasCropEntity midasCropEntity = TestDataBuilder.buildMidasCrop(currentSession);
        germplasm.setCrop(midasCropEntity);
        germplasm.setOrigin(TestDataBuilder.generateRandomNumberString(50));
        germplasm.setOwnerProgram(TestDataBuilder.buildProgramEntity(currentSession));
        germplasm.setPedigree(TestDataBuilder.generateRandomNumberString(100));
        germplasm.setTransgenic(true);
        germplasm.setProductGermplasms(new ArrayList<ProductGermplasmEntity>());
        return germplasm;
    }

    private EventConstructEntity createEventConstruct() {
        EventConstructEntity constructEntity = new EventConstructEntity();
        Long eventConstructId = TestDataBuilder.generateRandomNegativeLong();
        constructEntity.setId(eventConstructId);
        constructEntity.setBarcode(TestDataBuilder.generateRandomNumberString(50));
        constructEntity.setCrop(TestDataBuilder.buildMidasCrop(currentSession));
        constructEntity.setConstructName(EVENT_CONSTRUCT);
        constructEntity.setEventName(EVENT);
        constructEntity.setRefActive(true);
        constructEntity.setName(TestDataBuilder.generateRandomNumberString(80));
        return constructEntity;
    }

    private GermplasmEventConstructEntity createGermplasmEventConstruct(EventConstructEntity constructEntity, GermplasmEntity germplasm) {
        GermplasmEventConstructEntity germplasmEventConstructEntity = new GermplasmEventConstructEntity();
        germplasmEventConstructEntity.setEventConstruct(constructEntity);
        germplasmEventConstructEntity.setGermplasm(germplasm);
        germplasmEventConstructEntity.setId(TestDataBuilder.generateRandomNegativeLong());
        return germplasmEventConstructEntity;
    }
}