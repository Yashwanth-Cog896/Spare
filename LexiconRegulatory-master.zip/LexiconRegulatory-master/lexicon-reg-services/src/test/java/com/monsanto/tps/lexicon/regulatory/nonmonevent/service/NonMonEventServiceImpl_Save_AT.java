package com.monsanto.tps.lexicon.regulatory.nonmonevent.service;

import com.monsanto.tps.lexicon.nonmonevent.NonMonEventPersistBatchRequest;
import com.monsanto.tps.lexicon.nonmonevent.NonMonEventPersistRequest;
import com.monsanto.tps.lexicon.nonmonevent.NonMonEventPersistResponse;
import com.monsanto.tps.lexicon.nonmonevent.NonMonEventService;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.ComlTraitNameBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.ComlTraitTypeBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.CropBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.DataFilterBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.LexiconAcceptanceTestCase;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.ProteinNameBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.TestSessions;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName;
import com.monsanto.tps.lexicon.regulatory.DB.TestUtil.TPSTestConstants;
import com.monsanto.tps.lexicon.regulatory.DB.Tests.LexiconDataServiceATTestCase;
import com.monsanto.tps.lexicon.regulatory.helpers.AuditStagingAspect;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Arrays;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.assertThat;

/**
 * nbwald - May 19, 2009 4:18:21 PM
 */
@Transactional
public class NonMonEventServiceImpl_Save_AT
   extends LexiconAcceptanceTestCase
{
   @Resource
   private NonMonEventService nonMonEventService;

   @Resource
   private AuditStagingAspect auditStagingAspect;
   private final LexiconDataServiceATTestCase lexiconDataServiceATTestCase = new LexiconDataServiceATTestCase();


   @Test
 public void testSave_Commit_PassConstructValue()
      throws Exception
   {
      NonMonEventPersistRequest request = new NonMonEventPersistRequest();
      request.setEventName("EVENTNAMEVALUE");
      request.setConstruct("CONSTRUCTVALUE");
      request.setCropPubkey(CropBuilder.corn().getCropPubkey());
      request.setTraitTypeAbbreviations(createRegulatoryTraitType(), createRegulatoryTraitType(), createRegulatoryTraitType());
      request.setTraitNameAbbreviations(createRegulatoryTraitName(), createRegulatoryTraitName());
      request.setProteinPubkeys(createProtein(), createProtein(), createProtein(), createProtein());
      request.setActive(true);
      request.setAuditComment("AUDITCOMMENTVALUE");
      request.setAuditRequestor("AUDITREQUESTORVALUE");
      request.setMaterialName("MATERIAL NAME");

      NonMonEventPersistBatchRequest batchRequest = new NonMonEventPersistBatchRequest();
      batchRequest.setValidateOnly(false);
      batchRequest.setRequests(request);
      NonMonEventPersistResponse[] responses = nonMonEventService.save(batchRequest);

      assertThat(responses.length, is(1));
      NonMonEventPersistResponse response = responses[0];
      assertThat(response.isSuccess(), is(true));
      assertThat(response.getConstructs().length, is(1));
      assertThat(response.getConstructs()[0], is("CONSTRUCTVALUE"));

      NonMonEvent event = findEvent("EVENTNAMEVALUE");
      assertThat(event, is(not(nullValue())));
      assertThat(event.getEventDescription(), is(request.getEventName()));
      assertThat(event.getNonMonEventConstructs().size(), is(1));
      assertThat(event.isActiveStatus(), is(request.isActive()));
      assertThat(event.getCropPubkey(), is(CropBuilder.corn().getCropPubkey()));
      assertThat(event.getProteinNames().size(), is(4));
      assertThat(event.getComlTraitTypes().size(), is(3));
      assertThat(event.getComlTraitNames().size(), is(2));
      assertThat(event.getMaterialName(), is("MATERIAL NAME"));
   }

   @Test
   @Ignore
 public void testSave_ValidateOnly_DoNotPassConstruct_EventNameExistsInMidas_WithSingleConstruct()
      throws Exception
   {
      try {
      lexiconDataServiceATTestCase.setUp();

      new EventConstructBuilder().
         withEventName("EVENTNAMEVALUE").
         withConstructName("CONSTRUCTVALUE").
         withCrop(TPSTestConstants.MIDAS_CORN_ID).
         create(lexiconDataServiceATTestCase.getMidasConn());

      NonMonEventPersistRequest request = new NonMonEventPersistRequest();
      request.setEventName("EVENTNAMEVALUE");
      request.setCropPubkey(CropBuilder.corn().getCropPubkey());
      request.setTraitTypeAbbreviations(createRegulatoryTraitType());
      request.setProteinPubkeys(createProtein());
      request.setActive(true);
      request.setAuditComment("AUDITCOMMENTVALUE");
      request.setAuditRequestor("AUDITREQUESTORVALUE");

      NonMonEventPersistBatchRequest batchRequest = new NonMonEventPersistBatchRequest();
      batchRequest.setValidateOnly(true);
      batchRequest.setRequests(request);
      NonMonEventPersistResponse[] responses = nonMonEventService.save(batchRequest);

      assertThat(responses.length, is(1));
      NonMonEventPersistResponse response = responses[0];
      assertThat(response.isSuccess(), is(true));
      assertThat(response.getMessages().length, is(0));
      assertThat(response.getConstructs().length, is(1));
      assertThat(response.getConstructs()[0], is("CONSTRUCTVALUE"));

      NonMonEvent event = findEvent("EVENTNAMEVALUE");
      assertThat(event, is(nullValue()));
      }
      finally {
          lexiconDataServiceATTestCase.tearDown();
      }

   }

   @Test 
 public void testSave_ValidateOnly_DoNotPassConstruct_EventDoesNotExistInMidas()
      throws Exception
   {
      NonMonEventPersistRequest request = new NonMonEventPersistRequest();
      request.setEventName("EVENTNAMEVALUE");
      request.setCropPubkey(CropBuilder.corn().getCropPubkey());
      request.setTraitTypeAbbreviations(createRegulatoryTraitType());
      request.setProteinPubkeys(createProtein());
      request.setActive(true);
      request.setAuditComment("AUDITCOMMENTVALUE");
      request.setAuditRequestor("AUDITREQUESTORVALUE");

      NonMonEventPersistBatchRequest batchRequest = new NonMonEventPersistBatchRequest();
      batchRequest.setValidateOnly(true);
      batchRequest.setRequests(request);
      NonMonEventPersistResponse[] responses = nonMonEventService.save(batchRequest);

      assertThat(responses.length, is(1));
      NonMonEventPersistResponse response = responses[0];
      assertThat(response.isSuccess(), is(false));
      assertThat(response.getMessages().length, is(1));
      assertThat(response.getMessages()[0], is("Invalid Event for Selected Crop."));
      assertThat(response.getConstructs().length, is(0));

      NonMonEvent event = findEvent("EVENTNAMEVALUE");
      assertThat(event, is(nullValue()));
   }

   @Test
   @Ignore
   public void testSave_ValidateOnly_DoNotPassConstruct_EventNameExistsInMidas_WithMultipleConstructs()
      throws Exception
   {
      try {
         lexiconDataServiceATTestCase.setUp();
         new EventConstructBuilder().
            withEventName("EVENTNAMEVALUE").
            withConstructName("CONSTRUCTVALUE_A").
            withCrop(TPSTestConstants.MIDAS_CORN_ID).
            create(lexiconDataServiceATTestCase.getMidasConn());
         new EventConstructBuilder().
            withEventName("EVENTNAMEVALUE").
            withConstructName("CONSTRUCTVALUE_B").
            withCrop(TPSTestConstants.MIDAS_CORN_ID).
            create(lexiconDataServiceATTestCase.getMidasConn());

         NonMonEventPersistRequest request = new NonMonEventPersistRequest();
         request.setEventName("EVENTNAMEVALUE");
         request.setCropPubkey(CropBuilder.corn().getCropPubkey());
         request.setTraitTypeAbbreviations(createRegulatoryTraitType());
         request.setProteinPubkeys(createProtein());
         request.setActive(true);
         request.setAuditComment("AUDITCOMMENTVALUE");
         request.setAuditRequestor("AUDITREQUESTORVALUE");

         NonMonEventPersistBatchRequest batchRequest = new NonMonEventPersistBatchRequest();
         batchRequest.setValidateOnly(true);
         batchRequest.setRequests(request);
         NonMonEventPersistResponse[] responses = nonMonEventService.save(batchRequest);

         assertThat(responses.length, is(1));
         NonMonEventPersistResponse response = responses[0];
         assertThat(response.isSuccess(), is(false));
         assertThat(response.getMessages().length, is(1));
         assertThat(response.getMessages()[0], is("Event has multiple constructs."));
         assertThat(response.getConstructs().length, is(2));
         assertThat(Arrays.asList(response.getConstructs()).contains("CONSTRUCTVALUE_A"), is(true));
         assertThat(Arrays.asList(response.getConstructs()).contains("CONSTRUCTVALUE_B"), is(true));

         NonMonEvent event = findEvent("EVENTNAMEVALUE");
         assertThat(event, is(nullValue()));
      }
      finally {
         lexiconDataServiceATTestCase.tearDown();
      }

   }

   @Test 
 public void testSave_ValidateOnly_PassConstruct()
      throws Exception
   {
      NonMonEventPersistRequest request = new NonMonEventPersistRequest();
      request.setEventName("EVENTNAMEVALUE");
      request.setConstruct("CONSTRUCTVALUE");
      request.setCropPubkey(CropBuilder.corn().getCropPubkey());
      request.setTraitTypeAbbreviations(createRegulatoryTraitType());
      request.setProteinPubkeys(createProtein());
      request.setActive(true);
      request.setAuditComment("AUDITCOMMENTVALUE");
      request.setAuditRequestor("AUDITREQUESTORVALUE");
      request.setMaterialName("MATERIAL NAME");

      NonMonEventPersistBatchRequest batchRequest = new NonMonEventPersistBatchRequest();
      batchRequest.setValidateOnly(true);
      batchRequest.setRequests(request);
      NonMonEventPersistResponse[] responses = nonMonEventService.save(batchRequest);

      assertThat(responses.length, is(1));
      NonMonEventPersistResponse response = responses[0];
      assertThat(response.isSuccess(), is(true));
      assertThat(response.getMessages().length, is(0));
      assertThat(response.getConstructs().length, is(1));
      assertThat(response.getConstructs()[0], is("CONSTRUCTVALUE"));

      NonMonEvent event = findEvent("EVENTNAMEVALUE");
      assertThat(event, is(nullValue()));
   }

   private NonMonEvent findEvent(String eventName) {
      Session session = TestSessions.getLexiconSession();
      return (NonMonEvent) session.createCriteria(NonMonEvent.class).add(Restrictions.eq("eventDescription", eventName)).uniqueResult();
   }

   private String createProtein() {
      return insert(new AcceptanceTestData<String>()
      {
         @Override
         public String dataToInsert() {
            ProteinName protein = new ProteinNameBuilder().create();
            return protein.getProteinNamePubkey();
         }
      });
   }

   private String createRegulatoryTraitName() {
      return insert(new AcceptanceTestData<String>()
      {
         @Override
         public String dataToInsert() {
            ComlTraitName traitName = new ComlTraitNameBuilder().
               withDataFilter(DataFilterBuilder.regulatory()).
               create();
            return traitName.getTraitAbbr();
         }
      });
   }

   private String createRegulatoryTraitType() {
      return insert(new AcceptanceTestData<String>()
      {
         @Override
         public String dataToInsert() {
            ComlTraitType traitType = new ComlTraitTypeBuilder().
               withDataFilter(DataFilterBuilder.regulatory()).
               create();
            return traitType.getComlTraitTypeAbbr();
         }
      });
   }
}
