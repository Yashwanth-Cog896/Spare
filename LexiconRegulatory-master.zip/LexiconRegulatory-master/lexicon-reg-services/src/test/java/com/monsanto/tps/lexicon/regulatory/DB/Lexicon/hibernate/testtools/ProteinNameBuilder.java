package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName;
import org.hibernate.Session;

/**
 * Created by IntelliJ IDEA.
 * User: gdleon
 * Date: Apr 21, 2009
 * Time: 2:17:32 PM
 */
public class ProteinNameBuilder
{
   private ProteinName proteinName;

   public ProteinNameBuilder() {
      BuilderID builderID = new BuilderID();
      proteinName = new ProteinName();
      proteinName.setProteinNameId(builderID.id());
      proteinName.setProteinNamePubkey(builderID.sid());
      proteinName.setProteinName(builderID.sid());
      proteinName.setProteinDescription(builderID.sid());
      proteinName.setActiveStatus(true);
      proteinName.setOrigSourceOrganism(builderID.sid());
   }

   public ProteinNameBuilder withProteinName(String protName) {
      this.proteinName.setProteinName(protName);
      return this;
   }

   public ProteinNameBuilder withProteinNamePubkey(String proteinNamePubkey) {
      this.proteinName.setProteinNamePubkey(proteinNamePubkey);
      return this;
   }

   public ProteinNameBuilder withProteinDescription(String proteinDescription) {
      this.proteinName.setProteinDescription(proteinDescription);
      return this;
   }

   public ProteinNameBuilder withOrigSourceOrganism(String origSourceOrganism) {
      this.proteinName.setOrigSourceOrganism(origSourceOrganism);
      return this;
   }

   public ProteinName createObj() {
      return proteinName;
   }

   public ProteinName create() {
      Session session = TestSessions.getLexiconSession();
      session.save(proteinName);
      return proteinName;
   }
}

