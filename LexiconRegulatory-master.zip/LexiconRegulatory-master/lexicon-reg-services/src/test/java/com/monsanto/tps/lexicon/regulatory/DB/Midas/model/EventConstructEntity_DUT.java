/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.DB.Midas.model;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.HibernateAssertTestUtil;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.LexiconAcceptanceTestCase;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.TestDataBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.midas.model.EventConstructEntity;
import org.junit.Test;

import static junit.framework.Assert.assertFalse;

/* vvkalu - 7/26/11 */
public class EventConstructEntity_DUT extends LexiconAcceptanceTestCase {
    @Test
    public void testMapping() throws Exception {
        EventConstructEntity constructEntity = new EventConstructEntity();
        constructEntity.setId(TestDataBuilder.generateRandomNegativeLong());
        constructEntity.setBarcode(TestDataBuilder.generateRandomNumberString(50));
        constructEntity.setCrop(TestDataBuilder.buildMidasCrop(currentSession));
        constructEntity.setConstructName(TestDataBuilder.generateRandomNumberString(200));
        constructEntity.setEventName(TestDataBuilder.generateRandomNumberString(50));
        constructEntity.setRefActive(true);
        constructEntity.setName(TestDataBuilder.generateRandomNumberString(80));
        currentSession.save(constructEntity);
        currentSession.flush();
        currentSession.clear();

        EventConstructEntity dbEntity = (EventConstructEntity) currentSession.load(EventConstructEntity.class, constructEntity.getId());
        assertFalse(constructEntity == dbEntity);
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(constructEntity, dbEntity);
    }
}