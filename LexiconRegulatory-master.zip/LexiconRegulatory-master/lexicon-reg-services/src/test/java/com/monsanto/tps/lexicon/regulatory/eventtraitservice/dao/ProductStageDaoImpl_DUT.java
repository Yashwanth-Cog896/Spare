/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.eventtraitservice.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.LexiconAcceptanceTestCase;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.TestDataBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.LexiconProductEntity;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.LexiconProductStageEntity;
import com.monsanto.tps.lexicon.regulatory.DB.fbscommon.model.ProductXrefEntity;
import com.monsanto.tps.lexicon.regulatory.DB.midas.model.GermplasmEntity;
import com.monsanto.tps.lexicon.regulatory.DB.midas.model.MidasProductEntity;
import com.monsanto.tps.lexicon.regulatory.DB.midas.model.ProductGermplasmEntity;
import org.junit.Test;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

import static junit.framework.Assert.assertNotNull;

/* vvkalu - 7/26/11 */
public class ProductStageDaoImpl_DUT extends LexiconAcceptanceTestCase {

    @Resource
    private ProductStageDao productStageDao;

    @Test
    public void test_getFirstProductStageByGermplasmId() throws Exception {
        ProductGermplasmEntity entity = new ProductGermplasmEntity();
        entity.setId(TestDataBuilder.generateRandomNegativeLong());
        entity.setPreferred(false);

        MidasProductEntity productEntity = new MidasProductEntity();
        productEntity.setCrop(TestDataBuilder.buildMidasCrop(currentSession));
        productEntity.setId(TestDataBuilder.generateRandomNegativeLong());
        productEntity.setRefActive(true);

        final ProductXrefEntity xrefEntity = new ProductXrefEntity();
        xrefEntity.setProduct(productEntity);

        productEntity.setXref(xrefEntity);
        productEntity.setProductGermplasms(new ArrayList<ProductGermplasmEntity>(Arrays.asList(entity)));

        GermplasmEntity germplasm = new GermplasmEntity();
        germplasm.setId(TestDataBuilder.generateRandomNegativeLong());
        germplasm.setEventDisplay(TestDataBuilder.generateRandomNumberString(20));
        germplasm.setDeleted(false);
        germplasm.setFinished(true);
        germplasm.setLinecode(TestDataBuilder.generateRandomNumberString(50));
        germplasm.setLineType(TestDataBuilder.buildLineType(currentSession));
        germplasm.setCrop(TestDataBuilder.buildMidasCrop(currentSession));
        germplasm.setOrigin(TestDataBuilder.generateRandomNumberString(50));
        germplasm.setOwnerProgram(TestDataBuilder.buildProgramEntity(currentSession));
        germplasm.setPedigree(TestDataBuilder.generateRandomNumberString(100));
        germplasm.setTransgenic(true);
        germplasm.setProductGermplasms(new ArrayList<ProductGermplasmEntity>(Arrays.asList(entity)));

        entity.setProduct(productEntity);
        entity.setGermplasm(germplasm);

        final LexiconProductEntity dbProduct = insert(new AcceptanceTestData<LexiconProductEntity>() {
            public LexiconProductEntity dataToInsert() {
                LexiconProductEntity lexiconProductEntity = new LexiconProductEntity();
                lexiconProductEntity.setProductPubkey(TestDataBuilder.generateRandomNumberString(20));
                lexiconProductEntity.setPreComlName(TestDataBuilder.generateRandomNumberString(40));
                lexiconProductEntity.setLogicalDelete(false);
                lexiconProductEntity.setParentProduct(false);
                lexiconProductEntity.setCrop(TestDataBuilder.buildLexiconCrop(currentSession, null));
                lexiconProductEntity.setId(TestDataBuilder.generateRandomNegativeLong());

                LexiconProductStageEntity productStageEntity = new LexiconProductStageEntity();
                productStageEntity.setProductStageId(TestDataBuilder.generateRandomNegativeLong());
                productStageEntity.setProductStagePubkey(TestDataBuilder.generateRandomNumberString(20));
                productStageEntity.setActive(true);
                productStageEntity.setLogicalDelete(false);
                productStageEntity.setStage(TestDataBuilder.buildLexiconStage(currentSession));
                productStageEntity.setPreComlProduct(lexiconProductEntity);
                productStageEntity.setBrand(TestDataBuilder.buildLexiconBrand(currentSession));
                productStageEntity.setComlTraitStack(TestDataBuilder.buildComlTraitStack(currentSession));
                productStageEntity.setCountry(TestDataBuilder.buildLexiconCountry(currentSession));
                lexiconProductEntity.setProductStages(new HashSet<LexiconProductStageEntity>(Arrays.asList(productStageEntity)));

                currentSession.save(lexiconProductEntity);
                currentSession.save(productStageEntity);
                return lexiconProductEntity;
            }
        });
        xrefEntity.setLexiconProductPubkey(dbProduct.getProductPubkey());
        dbProduct.setProductXrefs(new HashSet<ProductXrefEntity>(Arrays.asList(xrefEntity)));
        currentSession.saveOrUpdate(dbProduct);
        currentSession.save(productEntity);
        currentSession.save(xrefEntity);
        currentSession.save(germplasm);
        currentSession.save(entity);
        currentSession.flush();
        currentSession.clear();
        LexiconProductStageEntity productStageEntity = productStageDao.getFirstProductStageByGermplasmId(germplasm.getId());
        assertNotNull(productStageEntity);
    }
}