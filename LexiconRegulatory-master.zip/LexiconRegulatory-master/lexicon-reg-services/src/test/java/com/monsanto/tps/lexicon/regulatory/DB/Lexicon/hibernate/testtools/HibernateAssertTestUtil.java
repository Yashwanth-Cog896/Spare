/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools;

import junit.framework.Assert;
import junit.framework.AssertionFailedError;
import org.springframework.beans.BeanUtils;
import org.springframework.util.ClassUtils;

import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.*;

import static org.hamcrest.core.IsNull.notNullValue;
import static org.junit.Assert.assertThat;

/**
 * Filename:    $RCSfile: TestUtils.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ntdaub $    	 On:	$Date: 2009-05-25 00:08:43 $
 *
 * @author EEHOCH
 * @version $Revision: 1.6 $
 */
@SuppressWarnings({"unchecked"})
public class HibernateAssertTestUtil {

    private static List<Object> comparedObject = new ArrayList<Object>();
    private static Deque<Object> compareDeque = new LinkedList<Object>();
    private static List globalPropertyIgnoreList;

    public synchronized static void assertObjectPropertiesContainSameValues(Object obj1, Object obj2, List<String> propertyIgnoreList) {
        try {
            globalPropertyIgnoreList = propertyIgnoreList;
            boolean compareResult = compare("Main Object", obj1, obj2);
            Assert.assertTrue("Object mismatch found between objects of class" + obj1.getClass().getName(), compareResult);
        } finally {
            comparedObject.clear();
            compareDeque.clear();
        }
    }

    public synchronized static void assertObjectPropertiesContainSameValues(Object obj1, Object obj2) {
        assertObjectPropertiesContainSameValues(obj1, obj2, new ArrayList<String>());
    }

    private static boolean compare(String propName, Object obj1, Object obj2) {
        if (compareDeque.contains(obj1) || comparedObject.contains(obj1)) {
            return true;
        } else {
            //comparedObject.add(obj1);
        }
        compareDeque.push(obj1);
        try {
            if (obj1 == null && obj2 == null) {
                return true;
            }
            if (obj1 == null || obj2 == null) {
                return false;
            }
            if (obj1 == obj2) {
                return true;
            }

            Assert.assertNotSame("Cannot compare the same object instances", obj1, obj2);
            if (!obj1.getClass().isAssignableFrom(obj2.getClass())) {
                Assert.assertEquals("Object classes are not the same for property " + propName, obj1.getClass().getName(), obj2.getClass().getName());
            }

            boolean objectsAreEqual = true;
            PropertyDescriptor[] props = BeanUtils.getPropertyDescriptors(obj1.getClass());
            for (PropertyDescriptor prop : props) {
                if (isBaseDomainProperty(prop) || globalPropertyIgnoreList.contains(prop.getName())) {
                    continue;
                }

                Method readMethod = prop.getReadMethod();

                if (ClassUtils.isAssignable(Boolean.class, prop.getPropertyType()) || ClassUtils.isAssignable(Boolean.TYPE, prop.getPropertyType())) {
                    assertThat("the read method of " + obj1.getClass().getName() + "." + prop.getName() + " appears to be null (did this change from boolean to Boolean recently?  if so check the get (for Boolean) vs. is (for boolean) read method)", readMethod, notNullValue());
                } else {
                    assertThat("the read method of " + obj1.getClass().getName() + "." + prop.getName() + " appears to be null", readMethod, notNullValue());
                }

                Object obj1Value;
                Object obj2Value;
                try {
                    obj1Value = getObjectValue(readMethod, obj1);
                    obj2Value = getObjectValue(readMethod, obj2);
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }
                Class propertyClass = prop.getPropertyType();
                if (propertyClass.isArray()) {
                    objectsAreEqual = compareArray(prop.getName(), (Object[]) obj1Value, (Object[]) obj2Value);
                } else if (ClassUtils.isAssignable(Collection.class, propertyClass)) {
                    objectsAreEqual = compareCollection(prop.getName(), (Collection) obj1Value, (Collection) obj2Value);
                } else if (ClassUtils.isAssignable(Map.class, propertyClass)) {
                    objectsAreEqual = compareMap(prop.getName(), (Map) obj1Value, (Map) obj2Value);
                } else if (propertyClass.isInterface() && propertyClass.getName().equals(java.io.Serializable.class.getName())) {
                    objectsAreEqual = obj1Value.equals(obj2Value);
                } else if (propertyClass.isInstance(new Date())) {
                    if (obj1Value != null && obj2Value != null) {
                        Calendar calendar1 = Calendar.getInstance();
                        calendar1.setTime((Date) obj1Value);
                        Calendar calendar2 = Calendar.getInstance();
                        calendar2.setTime((Date) obj2Value);
                        objectsAreEqual = (calendar1.get(Calendar.YEAR) == calendar2.get(Calendar.YEAR) &&
                                calendar1.get(Calendar.MONTH) == calendar2.get(Calendar.MONTH) &&
                                calendar1.get(Calendar.DAY_OF_MONTH) == calendar2.get(Calendar.DAY_OF_MONTH) &&
                                calendar1.get(Calendar.HOUR_OF_DAY) == calendar2.get(Calendar.HOUR_OF_DAY) &&
                                calendar1.get(Calendar.MINUTE) == calendar2.get(Calendar.MINUTE) &&
                                calendar1.get(Calendar.SECOND) == calendar2.get(Calendar.SECOND));
                    }
                } else if (BeanUtils.isSimpleProperty(propertyClass)) {

                    if (!prop.getName().equals("class")) {
                        objectsAreEqual = comparePrimitive(prop.getName(), obj1Value, obj2Value);
                    } else {
                        obj1Value.getClass().isAssignableFrom(obj2Value.getClass());
                    }
                } else {
                    objectsAreEqual = compare(prop.getName(), obj1Value, obj2Value);
                }
                if (!objectsAreEqual) {
                    System.err.println("Unequal objects found for where prop.getName() = " + prop.getName());
                    break;
                }
            }
            if (objectsAreEqual) {
                comparedObject.add(obj1);
            }
            return objectsAreEqual;
        } finally {
            compareDeque.pop();
        }
    }

    private static boolean compareMap(String propertyName, Map map1, Map map2) {
        if (map1 == null && map2 == null) {
            return true;
        }
        if (map1 == null || map2 == null) {
            Assert.fail("One map is null for property " + propertyName);
        }
        Assert.assertEquals("different sizes for " + propertyName, map1.size(), map2.size());
        for (Object key : map1.keySet()) {
            Assert.assertTrue("different key set for " + propertyName, map2.containsKey(key));
            Assert.assertEquals("different value for " + propertyName + "[" + key.toString() + "]", map1.get(key), map2.get(key));
        }
        return true;
    }

    private static boolean isBaseDomainProperty(PropertyDescriptor prop) {
        return prop.getName().equals("dateCreated") ||
                prop.getName().equals("dateModified") //||
                //prop.getName().equals("lastModifiedUserId") ||
                //prop.getName().equals("creationUserId");
                ;
    }

    private static boolean compareCollection(String propertyName, Collection collection1, Collection collection2) {
        if (collection1 == null && collection2 == null) {
            return true;
        }
        if (collection1 == null || collection2 == null) {
            Assert.fail("One collection is null for property " + propertyName);
        }
        Assert.assertEquals("Collections for property " + propertyName + " not the same size.", collection1.size(), collection2.size());
        List object1List = new ArrayList();
        object1List.addAll(collection1);
        List object2List = new ArrayList();
        object2List.addAll(collection2);
        return compareList(propertyName, object1List, object2List);
    }

    private static boolean compareArray(String propertyName, Object[] obj1Array, Object[] obj2Array) {
        if (obj1Array == null && obj2Array == null) {
            return true;
        }
        if (obj1Array == null || obj2Array == null) {
            Assert.fail("One array is null for property " + propertyName);
        }
        Assert.assertEquals("Collections for property " + propertyName + " not the same size.", obj1Array.length, obj2Array.length);
        List<Object> object1List = new ArrayList<Object>();
        List<Object> object2List = new ArrayList<Object>();
        for (int i = 0; i < obj1Array.length; i++) {
            object1List.add(obj1Array[i]);
            object2List.add(obj2Array[i]);
        }
        return compareList(propertyName, object1List, object2List);
    }

    private static boolean compareList(String propName, List list1, List list2) {
        boolean objectsAreEqual = true;
        if (list1.size() != list2.size()) {
            ListPrinter lp1 = new ListPrinter(list1);
            ListPrinter lp2 = new ListPrinter(list2);
            Assert.fail("Lists are of not the same size for property " + propName + " list values are\n" + lp1 + "\nand\n" + lp2);
        }

        for (Object object1 : list1) {
            boolean foundMatch = false;
            for (int i = 0; i < list2.size(); i++) {
                Object object2 = list2.get(i);
                try {
                    foundMatch = compare(propName, object1, object2);
                } catch (AssertionFailedError afe) {
                    foundMatch = false;
                }
                if (foundMatch) {
                    list2.remove(object2);
                    break;
                }
            }
            if (!foundMatch) {
                ListPrinter lp1 = new ListPrinter(list1);
                ListPrinter lp2 = new ListPrinter(list2);
                Assert.fail("Failed to verify arrays are equal for property " + propName + " with a value of " + object1 +
                        " while comparing list\n" + lp1 + " with list\n" + lp2);
                objectsAreEqual = false;
                break;
            }
        }
        return objectsAreEqual;
    }

    private static boolean comparePrimitive(String propName, Object obj1, Object obj2) {
        if (obj1 == null && obj2 == null) {
            return true;
        }
        if (obj1 == null || obj2 == null) {
            if (comparePrimitiveButTreatEmptyStringAndNullsEqual(obj1, obj2)) {
                return true;
            }
            if (comparePrimitiveButTreatEmptyStringAndNullsEqual(obj2, obj1)) {
                return true;
            }
            Assert.fail("Unexpected primitive value of null for property " + propName + " when comparing objects.");
        }
        if (obj1 == obj2) {
            return true;
        }
        Assert.assertEquals("ValidationProperty values are not equal for property " + propName, obj1, obj2);
        return true;
    }

    private static boolean comparePrimitiveButTreatEmptyStringAndNullsEqual(Object obj1, Object obj2) {
        return obj1 == null && obj2 instanceof String && ((String) obj2).length() == 0;
    }

    private static Object getObjectValue(Method method, Object object) throws InvocationTargetException, IllegalAccessException {
        return method.invoke(object);
    }
}