package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

/**
 * nbwald - Sep 11, 2008 12:40:08 PM
 */
public class TestSessions
{
   private static SessionFactory lexiconSessionFactory;

   public static void setLexiconSessionFactory(SessionFactory lexiconSessionFactory) {
      TestSessions.lexiconSessionFactory = lexiconSessionFactory;
   }

   public static Session getLexiconSession() {
      return lexiconSessionFactory.getCurrentSession();
   }
}
