package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEventConstruct;
import org.hibernate.Session;

/**
 * Created by IntelliJ IDEA.
 * User: gdleon
 * Date: May 7, 2009
 * Time: 9:20:58 AM
 */
public class NonMonEventConstructBuilder
{
   private NonMonEventConstruct nonMonEventConstruct;

   public NonMonEventConstructBuilder() {
      BuilderID builderID = new BuilderID();
      nonMonEventConstruct = new NonMonEventConstruct();
      nonMonEventConstruct.setNonMonEventConstructId(builderID.id());
      nonMonEventConstruct.setConstructName("NME CON");
   }

   public NonMonEventConstructBuilder withConstructName(String constructName) {
      this.nonMonEventConstruct.setConstructName(constructName);
      return this;
   }

   public NonMonEventConstruct create(NonMonEvent nonMonEvent) {
      nonMonEventConstruct.setNonMonEvent(nonMonEvent);
      Session session = TestSessions.getLexiconSession();
      session.save(nonMonEventConstruct);
      return nonMonEventConstruct;
   }

   public NonMonEventConstruct createObj(NonMonEvent nonMonEvent) {
      nonMonEventConstruct.setNonMonEvent(nonMonEvent);
      return nonMonEventConstruct;
   }
}
