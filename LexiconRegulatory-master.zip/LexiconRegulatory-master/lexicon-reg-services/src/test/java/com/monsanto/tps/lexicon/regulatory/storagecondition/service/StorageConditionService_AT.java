package com.monsanto.tps.lexicon.regulatory.storagecondition.service;

import com.monsanto.tps.lexicon.storagecondition.OrionStorageCondition;
import com.monsanto.tps.lexicon.storagecondition.StorageConditionService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/2/12
 * Time: 7:40 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:/com/monsanto/tps/lexicon/regulatory/contexts/lexicon-test-service-at-context.xml"})
@Transactional
public class StorageConditionService_AT {

    @Resource
    StorageConditionService storageConditionServiceImpl;

    @Test
    public void findStorageCondition_results_wildcard() throws Exception {
        final List<OrionStorageCondition> StorageConditions = storageConditionServiceImpl.findStorageConditions("Ambient*");
        assertNotNull(StorageConditions);
        assertFalse(StorageConditions.isEmpty());
    }

    @Test
    public void findStorageCondition_results_exactMatch() throws Exception {
        final List<OrionStorageCondition> StorageConditions = storageConditionServiceImpl.findStorageConditions("dry ice");
        assertNotNull(StorageConditions);
        assertFalse(StorageConditions.isEmpty());
    }

    @Test
    public void findStorageCondition_noResults() throws Exception {
        final List<OrionStorageCondition> StorageConditions = storageConditionServiceImpl.findStorageConditions("asdf");
        assertNotNull(StorageConditions);
        assertTrue(StorageConditions.isEmpty());
    }
}
