package com.monsanto.tps.lexicon.regulatory.plantname.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.PlantProduct;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

import static junit.framework.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 6/22/12
 * Time: 12:12 PM
*/
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:/com/monsanto/tps/lexicon/regulatory/contexts/lexicon-test-service-at-context.xml"})
@Transactional
public class RegulatorySeedMaterialDaoImpl_DUT {
    @Resource
    RegulatorySeedMaterialDAO dao;

    @Test
    public void testGetCompetitorPlantProducts() {
        List<PlantProduct> list = dao.findCompetitorProductNames("rou%");
        assertTrue(list.size()>0);
    }
    @Test
    public void testGetMonsantoPlantProducts() {
        List<PlantProduct> list = dao.findMonsantoProductNames("R%");
        assertTrue(list.size()>0);
    }
}
