package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.PlantName;
import org.hibernate.Session;

// nbwald 4/26/13 12:58 PM
public class PlantNameBuilder
{
    private PlantName plantName;

    public PlantNameBuilder() {
        this.plantName = new PlantName();
        this.plantName.setCountry("USA");
        this.plantName.setMaterialClassification("Other");
        this.plantName.setCrop(CropBuilder.corn());
    }

    public PlantNameBuilder withMaterialName(String materialName) {
        plantName.setMaterialName(materialName);
        return this;
    }

    public PlantNameBuilder thatIsActive() {
        plantName.setActiveStatus(true);
        return this;
    }

    public PlantNameBuilder thatIsInactive() {
        plantName.setActiveStatus(false);
        return this;
    }

    public void create() {
        Session session = TestSessions.getLexiconSession();
        session.save(plantName);
    }
}
