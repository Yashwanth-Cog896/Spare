package com.monsanto.tps.lexicon.regulatory.DB.Tests;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.lexiconcommon.db.monitor.test.TestFixtureTransactionMonitorManager;
import com.monsanto.tcc.lexiconcommon.db.test.MidasTestTools;
import com.monsanto.tps.lexicon.regulatory.DB.TestUtil.TPSTestConstants;
import com.monsanto.tps.lexicon.regulatory.TPS.LineType.LineTypeRef;

/**
 * rrchak1 - Feb 9, 2009 6:19:38 PM
 */
public class EventBuilder
{

   private LexiconDataServiceATTestCase lexiconDataServiceATTestCase = new LexiconDataServiceATTestCase();

   public void setupConnections()
      throws Exception
   {
      lexiconDataServiceATTestCase.setUp();
   }

   public void insertEvent(String ... eventNames)
      throws WrappingException
   {
      insertGermplasm(TPSTestConstants.GERMPLASM_ID_ONE);

      MidasTestTools.insertFakeGeneticMaterialWithGeneration(
         lexiconDataServiceATTestCase.getMidasConn(), TPSTestConstants.GENETIC_MATERIAL_ID_ONE, "source",
         "lineage", TPSTestConstants.GERMPLASM_ID_ONE, "srcOpertaion", TPSTestConstants.GENERATION_R0);
      int i = 0;
      for(String eventName:eventNames){
          insertEventConstruct(eventName, TPSTestConstants.SINGLE_PMON_CONSTRUCT_FOR_FCM_PVCODE+(i==0?"":Integer.toString(i)), TPSTestConstants.MIDAS_CANOLA_ID, TPSTestConstants.EVENT_CONSTRUCT_ID_ONE+i);
          insertGermplasmEventConstruct(TPSTestConstants.GERMPLASM_ID_ONE, TPSTestConstants.EVENT_CONSTRUCT_ID_ONE+i, TPSTestConstants.GERMPLASM_EVENT_CONSTRUCT_ID_ONE+i);
          i--;
      }
   }

   public void insertGermplasmEventConstruct(int germplasmId, int eventConstructId, int germplasmEventConstructId)
      throws WrappingException
   {
      MidasTestTools.insertFakeGermplasmEventConstruct(lexiconDataServiceATTestCase.getMidasConn(), germplasmEventConstructId, eventConstructId, germplasmId);
   }

   public void insertGermplasm(int germplasmId)
      throws WrappingException
   {
      MidasTestTools.insertFakeGermplasm(
         lexiconDataServiceATTestCase.getMidasConn(), germplasmId, "pedigree",
         LineTypeRef.HYBRID, TPSTestConstants.TRANSFORMATION_GENOTYPE, TPSTestConstants.MIDAS_CANOLA_ID, false, true, false
      );
   }

   public void insertEventConstruct(String eventName, String constructName)
      throws WrappingException
   {
      insertEventConstruct(eventName, constructName, TPSTestConstants.MIDAS_CORN_ID, TPSTestConstants.EVENT_CONSTRUCT_ID_ONE);
   }

   public void tearDownConnections()
      throws Exception
   {
      lexiconDataServiceATTestCase.tearDown();
   }

   public TestFixtureTransactionMonitorManager getTestManager() {
      return lexiconDataServiceATTestCase.getTestManager();
   }

   public void insertEventConstruct(String eventName, String constructName, long cropId, int eventConstructId)
      throws WrappingException
   {
      MidasTestTools.insertFakeEventConstruct(
         lexiconDataServiceATTestCase.getMidasConn(),
         eventConstructId,
         eventName,
         constructName,
         cropId);
   }
}
