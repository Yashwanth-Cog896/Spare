package com.monsanto.tps.lexicon.regulatory.nonmonevent.validation;

import com.monsanto.tcc.lexiconcommon.validation.validator.Rule;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import org.junit.Test;

/**
 * nbwald - May 21, 2009 5:44:34 PM
 */
public class AuditCommentExistsRule_UT
{
   @Test
   public void testViolated_False()
      throws Exception
   {
      String auditComment = "COMMENT";
      Rule<String> rule = new AuditCommentExistsRule(auditComment);

      assertThat(rule.violated(), is(false));
   }

   @Test
   public void testViolated_Null_True()
      throws Exception
   {
      String auditComment = null;
      Rule<String> rule = new AuditCommentExistsRule(auditComment);

      assertThat(rule.violated(), is(true));
   }

   @Test
   public void testViolated_Empty_True()
      throws Exception
   {
      String auditComment = "";
      Rule<String> rule = new AuditCommentExistsRule(auditComment);

      assertThat(rule.violated(), is(true));
   }

   @Test
   public void testGetViolation()
      throws Exception
   {
      assertThat(new AuditCommentExistsRule(null).getViolation(), is("Audit comment is required."));
   }

}
