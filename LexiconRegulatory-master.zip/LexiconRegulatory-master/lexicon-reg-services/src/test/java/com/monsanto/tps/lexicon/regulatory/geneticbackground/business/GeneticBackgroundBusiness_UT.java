package com.monsanto.tps.lexicon.regulatory.geneticbackground.business;

import com.monsanto.tps.lexicon.geneticbackground.OrionGeneticBackground;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.GeneticBackground;
import com.monsanto.tps.lexicon.regulatory.geneticbackground.dao.GeneticBackgroundDAO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/1/12
 * Time: 7:47 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class GeneticBackgroundBusiness_UT {

    @Mock
    private GeneticBackgroundDAO geneticBackgroundDAO;

    @InjectMocks
    private GeneticBackgroundBusiness geneticBackgroundBusiness = new GeneticBackgroundBusiness();

    private final List<GeneticBackground> singleGeneticBackgroundListFromDAO;
    private final List<GeneticBackground> multiGeneticBackgroundListFromDAO;
    private static final List<GeneticBackground> emptyListFromDAO = new ArrayList<GeneticBackground>();

    private final List<OrionGeneticBackground> singleGeneticBackgroundListFromBusiness;
    private final List<OrionGeneticBackground> multiGeneticBackgroundListFromBusiness;
    private static final List<OrionGeneticBackground> emptyListFromBusiness = new ArrayList<OrionGeneticBackground>();

    public GeneticBackgroundBusiness_UT() {
        singleGeneticBackgroundListFromDAO = new ArrayList<GeneticBackground>();
        singleGeneticBackgroundListFromDAO.add(new GeneticBackground("type", true));

        multiGeneticBackgroundListFromDAO = new ArrayList<GeneticBackground>();
        multiGeneticBackgroundListFromDAO.add(new GeneticBackground("type1", true));
        multiGeneticBackgroundListFromDAO.add(new GeneticBackground("type2", false));

        singleGeneticBackgroundListFromBusiness = new ArrayList<OrionGeneticBackground>();
        singleGeneticBackgroundListFromBusiness.add(new OrionGeneticBackground("type", true));

        multiGeneticBackgroundListFromBusiness = new ArrayList<OrionGeneticBackground>();
        multiGeneticBackgroundListFromBusiness.add(new OrionGeneticBackground("type1", true));
        multiGeneticBackgroundListFromBusiness.add(new OrionGeneticBackground("type2", false));
    }

    @Test
    public void findGeneticBackground_findNone() throws Exception {

        when(geneticBackgroundDAO.findGeneticBackgrounds("asdf")).thenReturn(emptyListFromDAO);

        final List<OrionGeneticBackground> actualGeneticBackgrounds = geneticBackgroundBusiness.findGeneticBackgrounds("asdf");

        checkGeneticBackgroundLists(actualGeneticBackgrounds, emptyListFromBusiness);
    }

    @Test
    public void findGeneticBackground_findSingle() throws Exception {

        when(geneticBackgroundDAO.findGeneticBackgrounds("Jar")).thenReturn(singleGeneticBackgroundListFromDAO);

        final List<OrionGeneticBackground> actualGeneticBackgrounds = geneticBackgroundBusiness.findGeneticBackgrounds("Jar");

        checkGeneticBackgroundLists(actualGeneticBackgrounds, singleGeneticBackgroundListFromBusiness);
    }

    @Test
    public void findGeneticBackground_findByWildcard() throws Exception {

        when(geneticBackgroundDAO.findGeneticBackgrounds("Glass%")).thenReturn(multiGeneticBackgroundListFromDAO);

        final List<OrionGeneticBackground> actualGeneticBackgrounds = geneticBackgroundBusiness.findGeneticBackgrounds("Glass*");

        checkGeneticBackgroundLists(actualGeneticBackgrounds, multiGeneticBackgroundListFromBusiness);
    }

    @Test
    public void findGeneticBackground_findAll() throws Exception {

        when(geneticBackgroundDAO.findGeneticBackgrounds("%")).thenReturn(multiGeneticBackgroundListFromDAO);

        final List<OrionGeneticBackground> actualGeneticBackgrounds = geneticBackgroundBusiness.findGeneticBackgrounds("");

        checkGeneticBackgroundLists(actualGeneticBackgrounds, multiGeneticBackgroundListFromBusiness);
    }

    private void checkGeneticBackgroundLists(final List<OrionGeneticBackground> actualGeneticBackgrounds, final List<OrionGeneticBackground> singleGeneticBackgroundListFromBusiness) {
        assertNotNull(actualGeneticBackgrounds);

        for(int i=0; i<singleGeneticBackgroundListFromBusiness.size(); i++) {
            final OrionGeneticBackground geneticBackground = actualGeneticBackgrounds.get(i);
            assertEquals(geneticBackground.getGeneticBackground(), singleGeneticBackgroundListFromBusiness.get(i).getGeneticBackground());
            assertEquals(geneticBackground.getActiveStatus(), singleGeneticBackgroundListFromBusiness.get(i).getActiveStatus());
        }
    }
}
