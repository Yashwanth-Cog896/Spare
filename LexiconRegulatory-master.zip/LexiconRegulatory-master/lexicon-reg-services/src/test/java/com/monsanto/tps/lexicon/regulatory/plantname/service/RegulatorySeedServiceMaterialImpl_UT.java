package com.monsanto.tps.lexicon.regulatory.plantname.service;

import com.monsanto.tps.lexicon.plantname.OrionPlantProduct;
import com.monsanto.tps.lexicon.plantname.RegulatorySeedMaterialService;
import com.monsanto.tps.lexicon.regulatory.plantname.business.RegulatorySeedMaterialBusiness;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 6/22/12
 * Time: 12:13 PM
 */
@RunWith(MockitoJUnitRunner.class)
public class RegulatorySeedServiceMaterialImpl_UT {
    @Mock
    private RegulatorySeedMaterialBusiness regulatorySeedMaterialBusiness;

    @InjectMocks
    private RegulatorySeedMaterialService regulatorySeedMaterialService = new RegulatorySeedMaterialServiceImpl();

    private static final List<OrionPlantProduct> plantNameList = new ArrayList<OrionPlantProduct>();

    @Before
    public void setup() {
        plantNameList.add(new OrionPlantProduct());
    }

    @Test
    public void findPlantName_success() throws Exception {
        when(regulatorySeedMaterialBusiness.findPlantNames("BollGard Cotton")).thenReturn(plantNameList);

        final List<OrionPlantProduct> actualPlantNames = regulatorySeedMaterialBusiness.findPlantNames("BollGard Cotton");

        assertEquals(actualPlantNames, plantNameList);
    }
}