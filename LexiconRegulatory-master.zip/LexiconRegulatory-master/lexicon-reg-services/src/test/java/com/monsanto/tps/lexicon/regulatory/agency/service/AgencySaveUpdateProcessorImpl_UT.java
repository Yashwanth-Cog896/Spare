package com.monsanto.tps.lexicon.regulatory.agency.service;

import com.monsanto.tps.lexicon.agency.AgencySaveUpdateRequest;
import com.monsanto.tps.lexicon.agency.AgencySaveUpdateResponse;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Agency;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.AgencyDepartment;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.AuditStaging;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Country;
import com.monsanto.tps.lexicon.regulatory.agency.dao.AgencyDao;
import com.monsanto.tps.lexicon.regulatory.agency.util.AgencyBeanUtil;
import com.monsanto.tps.lexicon.regulatory.agency.validation.AgencySaveUpdateValidator;
import com.monsanto.tps.lexicon.regulatory.audit.dao.AuditStagingDao;
import com.monsanto.tps.lexicon.regulatory.util.validationresults.ValidationResults;
import static org.easymock.EasyMock.*;
import static org.hamcrest.core.Is.is;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import static org.junit.Assert.assertThat;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * aagosw - Mar 10, 2009 3:11:28 PM
 */
public class AgencySaveUpdateProcessorImpl_UT
{

   @Test
   public void testSave_DoesNotDoAnythingForEmptyRequest() {
      AgencySaveUpdateProcessor agencySaveUpdateProcessor = new AgencySaveUpdateProcessorImpl();
      List<AgencySaveUpdateResponse> responseList = new ArrayList<AgencySaveUpdateResponse>();
      agencySaveUpdateProcessor.save(new AgencySaveUpdateRequest[0], null, null, responseList, false);
      assertThat(responseList.size(), is(0));
   }

   @Test
   public void testSave_DoesNotSaveForCommitFalseAndNoErrors() {
      AgencySaveUpdateProcessorImpl agencySaveUpdateProcessor = new AgencySaveUpdateProcessorImpl();
      List<AgencySaveUpdateResponse> responseList = new ArrayList<AgencySaveUpdateResponse>();
      AgencySaveUpdateRequest request = new AgencySaveUpdateRequest();

      AgencySaveUpdateValidator validator = createMock(AgencySaveUpdateValidator.class);
      expect(validator.validate(request)).andReturn(new ValidationResults(new String[0]));
      agencySaveUpdateProcessor.setValidator(validator);
      replay(validator);

      AgencyDao agencyDao = createMock(AgencyDao.class);
      replay(agencyDao);

      agencySaveUpdateProcessor.save(new AgencySaveUpdateRequest[]{request}, agencyDao, null, responseList, false);
      assertThat(responseList.size(), is(1));
      assertThat(responseList.get(0).isSuccessful(), is(true));
      verify(validator);
      verify(agencyDao);
   }

   @Test
   public void testSave_DoesNotSaveForCommitFalseAndHasErrors() {
      AgencySaveUpdateProcessorImpl agencySaveUpdateProcessor = new AgencySaveUpdateProcessorImpl();
      List<AgencySaveUpdateResponse> responseList = new ArrayList<AgencySaveUpdateResponse>();
      AgencySaveUpdateRequest request = new AgencySaveUpdateRequest();

      AgencySaveUpdateValidator validator = createMock(AgencySaveUpdateValidator.class);
      expect(validator.validate(request)).andReturn(new ValidationResults(new String[]{"error1"}));
      agencySaveUpdateProcessor.setValidator(validator);
      replay(validator);

      AgencyDao agencyDao = createMock(AgencyDao.class);
      replay(agencyDao);

      agencySaveUpdateProcessor.save(new AgencySaveUpdateRequest[]{request}, agencyDao, null, responseList, false);
      assertThat(responseList.size(), is(1));
      assertThat(responseList.get(0).isSuccessful(), is(false));
      assertThat(responseList.get(0).getMessages()[0], is("Error: error1"));
      verify(validator);
      verify(agencyDao);
   }

   @Test
   public void testSave_DoesNotSaveForCommitTrueAndHasErrors() {
      AgencySaveUpdateProcessorImpl agencySaveUpdateProcessor = new AgencySaveUpdateProcessorImpl();
      List<AgencySaveUpdateResponse> responseList = new ArrayList<AgencySaveUpdateResponse>();
      AgencySaveUpdateRequest request = new AgencySaveUpdateRequest();

      AgencySaveUpdateValidator validator = createMock(AgencySaveUpdateValidator.class);
      expect(validator.validate(request)).andReturn(new ValidationResults(new String[]{"error1"}));
      agencySaveUpdateProcessor.setValidator(validator);
      replay(validator);

      AgencyDao agencyDao = createMock(AgencyDao.class);
      replay(agencyDao);

      agencySaveUpdateProcessor.save(new AgencySaveUpdateRequest[]{request}, agencyDao, null, responseList, true);
      assertThat(responseList.size(), is(1));
      assertThat(responseList.get(0).isSuccessful(), is(false));
      assertThat(responseList.get(0).getMessages()[0], is("Error: error1"));
      verify(validator);
      verify(agencyDao);
   }

   @Test
   public void testUpdate_DoesNotDoAnythingForEmptyRequest() {
      AgencySaveUpdateProcessor agencySaveUpdateProcessor = new AgencySaveUpdateProcessorImpl();
      List<AgencySaveUpdateResponse> responseList = new ArrayList<AgencySaveUpdateResponse>();
      agencySaveUpdateProcessor.update(new AgencySaveUpdateRequest[0], null, null, responseList, false);
      assertThat(responseList.size(), is(0));
   }

   @Test
   public void testUpdate_DoesNotSaveForCommitFalseAndNoErrors() {
      AgencySaveUpdateProcessorImpl agencySaveUpdateProcessor = new AgencySaveUpdateProcessorImpl();
      List<AgencySaveUpdateResponse> responseList = new ArrayList<AgencySaveUpdateResponse>();
      AgencySaveUpdateRequest request = new AgencySaveUpdateRequest();

      AgencySaveUpdateValidator validator = createMock(AgencySaveUpdateValidator.class);
      expect(validator.validate(request)).andReturn(new ValidationResults(new String[0]));
      agencySaveUpdateProcessor.setValidator(validator);
      replay(validator);

      AgencyDao agencyDao = createMock(AgencyDao.class);
      replay(agencyDao);

      agencySaveUpdateProcessor.update(new AgencySaveUpdateRequest[]{request}, agencyDao, null, responseList, false);
      assertThat(responseList.size(), is(1));
      assertThat(responseList.get(0).isSuccessful(), is(true));
      verify(validator);
      verify(agencyDao);
   }

   @Test
   public void testUpdate_DoesNotSaveForCommitFalseAndHasErrors() {
      AgencySaveUpdateProcessorImpl agencySaveUpdateProcessor = new AgencySaveUpdateProcessorImpl();
      List<AgencySaveUpdateResponse> responseList = new ArrayList<AgencySaveUpdateResponse>();
      AgencySaveUpdateRequest request = new AgencySaveUpdateRequest();

      AgencySaveUpdateValidator validator = createMock(AgencySaveUpdateValidator.class);
      expect(validator.validate(request)).andReturn(new ValidationResults(new String[]{"error1"}));
      agencySaveUpdateProcessor.setValidator(validator);
      replay(validator);

      AgencyDao agencyDao = createMock(AgencyDao.class);
      replay(agencyDao);

      agencySaveUpdateProcessor.update(new AgencySaveUpdateRequest[]{request}, agencyDao, null, responseList, false);
      assertThat(responseList.size(), is(1));
      assertThat(responseList.get(0).isSuccessful(), is(false));
      assertThat(responseList.get(0).getMessages()[0], is("Error: error1"));
      verify(validator);
      verify(agencyDao);
   }

   @Test
   public void testUpdate_DoesNotSaveForCommitTrueAndHasErrors() {
      AgencySaveUpdateProcessorImpl agencySaveUpdateProcessor = new AgencySaveUpdateProcessorImpl();
      List<AgencySaveUpdateResponse> responseList = new ArrayList<AgencySaveUpdateResponse>();
      AgencySaveUpdateRequest request = new AgencySaveUpdateRequest();

      AgencySaveUpdateValidator validator = createMock(AgencySaveUpdateValidator.class);
      expect(validator.validate(request)).andReturn(new ValidationResults(new String[]{"error1"}));
      agencySaveUpdateProcessor.setValidator(validator);
      replay(validator);

      AgencyDao agencyDao = createMock(AgencyDao.class);
      replay(agencyDao);

      agencySaveUpdateProcessor.update(new AgencySaveUpdateRequest[]{request}, agencyDao, null, responseList, true);
      assertThat(responseList.size(), is(1));
      assertThat(responseList.get(0).isSuccessful(), is(false));
      assertThat(responseList.get(0).getMessages()[0], is("Error: error1"));
      verify(validator);
      verify(agencyDao);
   }


   @Test
   public void testSave_DoesNotSaveAgencyOrDepartmentForAgencyDepartmentExistsForCommitTrueAndNoErrors() {
      AgencySaveUpdateProcessorImpl agencySaveUpdateProcessor = new AgencySaveUpdateProcessorImpl();
      List<AgencySaveUpdateResponse> responseList = new ArrayList<AgencySaveUpdateResponse>();
      AgencySaveUpdateRequest request = new AgencySaveUpdateRequest();

      AgencySaveUpdateValidator validator = createMock(AgencySaveUpdateValidator.class);
      expect(validator.validate(request)).andReturn(new ValidationResults(new String[0]));
      agencySaveUpdateProcessor.setValidator(validator);
      replay(validator);

      AuditStagingDao auditStagingDao = createMock(AuditStagingDao.class);
      agencySaveUpdateProcessor.setAuditStagingDao(auditStagingDao);
      AgencyDepartment department = getAgencyDepartment();
      MockAgencyBeanUtil beanUtil = new MockAgencyBeanUtil();
      beanUtil.department = department;
      AgencyDao agencyDao = createMock(AgencyDao.class);

      AuditStaging auditStaging = new AuditStaging();
      expect(auditStagingDao.create("UNKNOWNCXFSERVICEUSER", "SAVE AGENCY", request.getAuditComment(), "LEXICON")).andReturn(auditStaging);
      expect(agencyDao.getAgencyByAbbvAndCountry(department.getAgency().getAgencyAbbr(), department.getAgency().getCountry())).andReturn(department.getAgency());
      expect(agencyDao.getAgencyDepartmentByAgencyAndAbbr(department.getAgency(), department.getAgencyDeptAbbr())).andReturn(department);
      auditStagingDao.delete(auditStaging);

      replay(auditStagingDao);
      replay(agencyDao);

      agencySaveUpdateProcessor.save(new AgencySaveUpdateRequest[]{request}, agencyDao, beanUtil, responseList, true);
      assertThat(responseList.size(), is(1));
      assertThat(responseList.get(0).isSuccessful(), is(true));
      verify(validator);
      verify(agencyDao);
      verify(auditStagingDao);
   }

   @Test
   public void testSave_SavesAgencyAndDepartmentForAgencyDepartmentNotExistsForCommitTrueAndNoErrors() {
      AgencySaveUpdateProcessorImpl agencySaveUpdateProcessor = new AgencySaveUpdateProcessorImpl();
      List<AgencySaveUpdateResponse> responseList = new ArrayList<AgencySaveUpdateResponse>();
      AgencySaveUpdateRequest request = new AgencySaveUpdateRequest();

      AgencySaveUpdateValidator validator = createMock(AgencySaveUpdateValidator.class);
      expect(validator.validate(request)).andReturn(new ValidationResults(new String[0]));
      agencySaveUpdateProcessor.setValidator(validator);
      replay(validator);

      AuditStagingDao auditStagingDao = createMock(AuditStagingDao.class);
      agencySaveUpdateProcessor.setAuditStagingDao(auditStagingDao);
      AgencyDepartment department = getAgencyDepartment();
      MockAgencyBeanUtil beanUtil = new MockAgencyBeanUtil();
      beanUtil.department = department;
      AgencyDao agencyDao = createMock(AgencyDao.class);

      AuditStaging auditStaging = new AuditStaging();
      expect(auditStagingDao.create("UNKNOWNCXFSERVICEUSER", "SAVE AGENCY", request.getAuditComment(), "LEXICON")).andReturn(auditStaging);
      expect(agencyDao.getAgencyByAbbvAndCountry(department.getAgency().getAgencyAbbr(), department.getAgency().getCountry())).andReturn(null);
      agencyDao.saveAgency(department.getAgency());
      expect(agencyDao.getAgencyDepartmentByAgencyAndAbbr(department.getAgency(), department.getAgencyDeptAbbr())).andReturn(null);
      agencyDao.saveAgencyDepartment(department);
      auditStagingDao.delete(auditStaging);

      replay(auditStagingDao);
      replay(agencyDao);

      agencySaveUpdateProcessor.save(new AgencySaveUpdateRequest[]{request}, agencyDao, beanUtil, responseList, true);
      assertThat(responseList.size(), is(1));
      assertThat(responseList.get(0).isSuccessful(), is(true));
      verify(validator);
      verify(agencyDao);
      verify(auditStagingDao);
   }

   @Test
   public void testSave_SavesAgencyAndDepartmentHandlesExceptionForSaveAgency() {
      AgencySaveUpdateProcessorImpl agencySaveUpdateProcessor = new AgencySaveUpdateProcessorImpl();
      List<AgencySaveUpdateResponse> responseList = new ArrayList<AgencySaveUpdateResponse>();
      AgencySaveUpdateRequest request = new AgencySaveUpdateRequest();

      AgencySaveUpdateValidator validator = createMock(AgencySaveUpdateValidator.class);
      expect(validator.validate(request)).andReturn(new ValidationResults(new String[0]));
      agencySaveUpdateProcessor.setValidator(validator);
      replay(validator);

      AuditStagingDao auditStagingDao = createMock(AuditStagingDao.class);
      agencySaveUpdateProcessor.setAuditStagingDao(auditStagingDao);
      AgencyDepartment department = getAgencyDepartment();
      MockAgencyBeanUtil beanUtil = new MockAgencyBeanUtil();
      beanUtil.department = department;
      AgencyDao agencyDao = createMock(AgencyDao.class);

      AuditStaging auditStaging = new AuditStaging();
      expect(auditStagingDao.create("UNKNOWNCXFSERVICEUSER", "SAVE AGENCY", request.getAuditComment(), "LEXICON")).andReturn(auditStaging);
      expect(agencyDao.getAgencyByAbbvAndCountry(department.getAgency().getAgencyAbbr(), department.getAgency().getCountry())).andThrow(new RuntimeException("exception"));
      auditStagingDao.delete(auditStaging);

      SessionFactory sessionFactory = createMock(SessionFactory.class);
      Session session = createMock(Session.class);
      expect(sessionFactory.getCurrentSession()).andReturn(session);
      session.clear();

      replay(auditStagingDao);
      replay(agencyDao);
      replay(sessionFactory);
      replay(session);

      agencySaveUpdateProcessor.setSessionFactory(sessionFactory);
      agencySaveUpdateProcessor.save(new AgencySaveUpdateRequest[]{request}, agencyDao, beanUtil, responseList, true);
      assertThat(responseList.size(), is(1));
      assertThat(responseList.get(0).isSuccessful(), is(false));
      assertThat(responseList.get(0).getMessages().length, is(1));
      verify(validator);
      verify(agencyDao);
      verify(auditStagingDao);
      verify(sessionFactory);
      verify(session);
   }

   @Test
   public void testUpdate_UpdatesAgencyOrDepartmentForCommitTrueAndNoErrors() {
      AgencySaveUpdateProcessorImpl agencySaveUpdateProcessor = new AgencySaveUpdateProcessorImpl();
      List<AgencySaveUpdateResponse> responseList = new ArrayList<AgencySaveUpdateResponse>();
      AgencySaveUpdateRequest request = new AgencySaveUpdateRequest();

      AgencySaveUpdateValidator validator = createMock(AgencySaveUpdateValidator.class);
      expect(validator.validate(request)).andReturn(new ValidationResults(new String[0]));
      agencySaveUpdateProcessor.setValidator(validator);
      replay(validator);

      AuditStagingDao auditStagingDao = createMock(AuditStagingDao.class);
      agencySaveUpdateProcessor.setAuditStagingDao(auditStagingDao);
      AgencyDepartment department = getAgencyDepartment();
      MockAgencyBeanUtil beanUtil = new MockAgencyBeanUtil();
      beanUtil.department = department;
      AgencyDao agencyDao = createMock(AgencyDao.class);

      AuditStaging auditStaging = new AuditStaging();
      expect(auditStagingDao.create("UNKNOWNCXFSERVICEUSER", "UPATE AGENCY", request.getAuditComment(), "LEXICON")).andReturn(auditStaging);
      Agency returnedAgency = new Agency();
      expect(agencyDao.getAgencyByPubkey(department.getAgency().getAgencyPubkey())).andReturn(returnedAgency);
      agencyDao.mergeAgency(department.getAgency(), returnedAgency);
      AgencyDepartment returnedDepartment = new AgencyDepartment();
      expect(agencyDao.getAgencyDepartmentByPubkey(department.getAgencyDeptPubkey())).andReturn(returnedDepartment);
      agencyDao.mergeAgencyDepartment(department, returnedDepartment);
      auditStagingDao.delete(auditStaging);

      replay(auditStagingDao);
      replay(agencyDao);

      agencySaveUpdateProcessor.update(new AgencySaveUpdateRequest[]{request}, agencyDao, beanUtil, responseList, true);
      assertThat(responseList.size(), is(1));
      assertThat(responseList.get(0).isSuccessful(), is(true));
      verify(validator);
      verify(agencyDao);
      verify(auditStagingDao);
   }

   @Test
   public void testUpdate_AgencyAndDepartmentHandlesException() {
      AgencySaveUpdateProcessorImpl agencySaveUpdateProcessor = new AgencySaveUpdateProcessorImpl();
      List<AgencySaveUpdateResponse> responseList = new ArrayList<AgencySaveUpdateResponse>();
      AgencySaveUpdateRequest request = new AgencySaveUpdateRequest();

      AgencySaveUpdateValidator validator = createMock(AgencySaveUpdateValidator.class);
      expect(validator.validate(request)).andReturn(new ValidationResults(new String[0]));
      agencySaveUpdateProcessor.setValidator(validator);
      replay(validator);

      AuditStagingDao auditStagingDao = createMock(AuditStagingDao.class);
      agencySaveUpdateProcessor.setAuditStagingDao(auditStagingDao);
      AgencyDepartment department = getAgencyDepartment();
      MockAgencyBeanUtil beanUtil = new MockAgencyBeanUtil();
      beanUtil.department = department;
      AgencyDao agencyDao = createMock(AgencyDao.class);

      AuditStaging auditStaging = new AuditStaging();
      expect(auditStagingDao.create("UNKNOWNCXFSERVICEUSER", "UPATE AGENCY", request.getAuditComment(), "LEXICON")).andReturn(auditStaging);
      expect(agencyDao.getAgencyByPubkey(department.getAgency().getAgencyPubkey())).andThrow(new RuntimeException("exception"));
      auditStagingDao.delete(auditStaging);

      SessionFactory sessionFactory = createMock(SessionFactory.class);
      Session session = createMock(Session.class);
      expect(sessionFactory.getCurrentSession()).andReturn(session);
      session.clear();

      replay(auditStagingDao);
      replay(agencyDao);
      replay(sessionFactory);
      replay(session);

      agencySaveUpdateProcessor.setSessionFactory(sessionFactory);
      agencySaveUpdateProcessor.update(new AgencySaveUpdateRequest[]{request}, agencyDao, beanUtil, responseList, true);
      assertThat(responseList.size(), is(1));
      assertThat(responseList.get(0).isSuccessful(), is(false));
      assertThat(responseList.get(0).getMessages().length, is(1));
      verify(validator);
      verify(agencyDao);
      verify(auditStagingDao);
      verify(sessionFactory);
      verify(session);
   }


   private AgencyDepartment getAgencyDepartment() {
      Agency agency = new Agency();
      agency.setActive("y");
      agency.setAgencyAbbr("abbr1");
      Country country = new Country();
      country.setIsoCode("US");
      agency.setCountry(country);
      agency.setAgencyName("name1");
      agency.setSurfaceAreaUomCode("uom");
      agency.setAgencyPubkey("apub1");

      AgencyDepartment department = new AgencyDepartment();
      department.setActive("y");
      department.setAddress1("addr1");
      department.setAddress2("addr2");
      department.setAgency(agency);
      department.setAgencyDeptAbbr("deptabbr1");
      department.setAgencyDeptName("deptname1");
      department.setCity("city1");
      department.setPostalCode("12345");
      department.setSubCountryAbbr("s1");
      department.setSubSubCountryName("s2");
      agency.getDepartments().add(department);
      department.setAgency(agency);
      department.setAgencyDeptPubkey("deptpub1");
      return department;
   }

   private class MockAgencyBeanUtil
      extends AgencyBeanUtil
   {
      public AgencyDepartment department;

      public AgencyDepartment buildAgencyDepartmentDBObject(AgencySaveUpdateRequest agencySaveUpdateRequest) {
         return department;
      }
   }

}
