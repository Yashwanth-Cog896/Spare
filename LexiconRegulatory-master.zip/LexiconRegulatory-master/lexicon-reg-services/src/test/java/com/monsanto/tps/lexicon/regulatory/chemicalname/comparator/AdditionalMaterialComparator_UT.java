package com.monsanto.tps.lexicon.regulatory.chemicalname.comparator;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.AdditionalMaterial;
import com.monsanto.tps.lexicon.regulatory.comparator.ComparatorTestCase;

import java.util.Comparator;

/**
 * Created by IntelliJ IDEA.
 * User: etherma
 * Date: Dec 13, 2006
 * Time: 1:24:03 PM
 * To change this template use File | Settings | File Templates.
 */
public class AdditionalMaterialComparator_UT extends ComparatorTestCase {

    protected Comparator getNewComparator() {
        return new AdditionalMaterialComparator();
    }

    protected Object getNewInfoSmaller() {
        AdditionalMaterial additionalMaterialInfo = new AdditionalMaterial();
        additionalMaterialInfo.setMaterialName("name 1");
        return additionalMaterialInfo;
    }

    protected Object getNewInfoLarger() {
        AdditionalMaterial additionalMaterialInfo = new AdditionalMaterial();
        additionalMaterialInfo.setMaterialName("name 2");
        return additionalMaterialInfo;
    }
}
