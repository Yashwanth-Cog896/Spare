/*
 Copyright:  Copyright &copy; 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.DB.Midas.model;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.HibernateAssertTestUtil;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.LexiconAcceptanceTestCase;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.TestDataBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.fbscommon.model.ProductXrefEntity;
import com.monsanto.tps.lexicon.regulatory.DB.midas.model.GermplasmEntity;
import com.monsanto.tps.lexicon.regulatory.DB.midas.model.MidasProductEntity;
import com.monsanto.tps.lexicon.regulatory.DB.midas.model.ProductGermplasmEntity;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;

import static junit.framework.Assert.assertFalse;

/* vvkalu - 7/25/11 */
public class ProductGermplasmEntity_DUT extends LexiconAcceptanceTestCase {

    @Test
    public void testMapping() throws Exception {
        ProductGermplasmEntity entity = new ProductGermplasmEntity();
        entity.setId(TestDataBuilder.generateRandomNegativeLong());
        entity.setPreferred(false);

        MidasProductEntity productEntity = new MidasProductEntity();
        productEntity.setCrop(TestDataBuilder.buildMidasCrop(currentSession));
        productEntity.setId(TestDataBuilder.generateRandomNegativeLong());
        productEntity.setRefActive(true);

        ProductXrefEntity xrefEntity = new ProductXrefEntity();
        xrefEntity.setLexiconProductPubkey("LEXICON_PUBKEY_DUT");
        xrefEntity.setProduct(productEntity);

        productEntity.setXref(xrefEntity);
        productEntity.setProductGermplasms(new ArrayList<ProductGermplasmEntity>(Arrays.asList(entity)));
        currentSession.save(productEntity);
        currentSession.save(xrefEntity);

        GermplasmEntity germplasm = new GermplasmEntity();
        germplasm.setId(TestDataBuilder.generateRandomNegativeLong());
        germplasm.setEventDisplay(TestDataBuilder.generateRandomNumberString(20));
        germplasm.setDeleted(false);
        germplasm.setFinished(true);
        germplasm.setLinecode(TestDataBuilder.generateRandomNumberString(50));
        germplasm.setLineType(TestDataBuilder.buildLineType(currentSession));
        germplasm.setCrop(TestDataBuilder.buildMidasCrop(currentSession));
        germplasm.setOrigin(TestDataBuilder.generateRandomNumberString(50));
        germplasm.setOwnerProgram(TestDataBuilder.buildProgramEntity(currentSession));
        germplasm.setPedigree(TestDataBuilder.generateRandomNumberString(100));
        germplasm.setTransgenic(true);
        germplasm.setProductGermplasms(new ArrayList<ProductGermplasmEntity>(Arrays.asList(entity)));
        currentSession.save(germplasm);

        entity.setProduct(productEntity);
        entity.setGermplasm(germplasm);

        currentSession.save(entity);
        currentSession.flush();
        currentSession.clear();

        ProductGermplasmEntity productGermplasmEntity = (ProductGermplasmEntity) currentSession.load(ProductGermplasmEntity.class, entity.getId());
        assertFalse(entity == productGermplasmEntity);
        HibernateAssertTestUtil.assertObjectPropertiesContainSameValues(entity, productGermplasmEntity);
    }

}