package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools;

import com.monsanto.dbdataservices.SQLUtil;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Agency;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.AgencyDepartment;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Country;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.CountryBuilder.usa;

/**
 * rrchak1 - Oct 10, 2008 12:39:35 PM
 */
public class AgencyBuilder
{
   private Agency agency;
   private final BuilderID builderID = new BuilderID();
   private final List<AgencyDepartmentBuilder> agencyDepartmentBuilders = new ArrayList<AgencyDepartmentBuilder>();

   public AgencyBuilder() {
      agency = new Agency();
      agency.setAgencyPubkey(builderID.sid());
      agency.setAgencyName("United States Department of Agriculture");
      agency.setActive(SQLUtil.booleanToString(true));
      agency.setCountry(usa());
      agency.setSurfaceAreaUomCode("FT2");
   }

   public AgencyBuilder withPubKey(String pubkey) {
      agency.setAgencyPubkey(pubkey);
      return this;
   }

   public Agency create() {
      Session session = TestSessions.getLexiconSession();
      session.save(agency);
      agency.setDepartments(createDepartments());
      return agency;
   }

   public AgencyBuilder withAgencyAbbr(String abbreviation) {
      agency.setAgencyAbbr(abbreviation);
      return this;
   }

   public AgencyBuilder withCountry(Country country) {
      agency.setCountry(country);
      return this;
   }

   public AgencyBuilder withActiveStatus(boolean activeStatus) {
      agency.setActive(SQLUtil.booleanToString(activeStatus));
      return this;
   }

   public AgencyBuilder withAgencyDepartment(AgencyDepartmentBuilder agencyDepartmentBuilder) {
      agencyDepartmentBuilders.add(agencyDepartmentBuilder);
      return this;
   }

   private Set<AgencyDepartment> createDepartments() {
      Set<AgencyDepartment> departments = new HashSet<AgencyDepartment>();
      for (AgencyDepartmentBuilder agencyDepartmentBuilder : agencyDepartmentBuilders) {
         departments.add(agencyDepartmentBuilder.create(agency));
      }
      return departments;
   }

   public static Agency epa() {
      return findAgencyByAbbreviationAndCountry("EPA", usa());
   }

   public static Agency usda() {
      return findAgencyByAbbreviationAndCountry("USDA", usa());
   }

   public static Agency stewardship() {
      return findAgencyByAbbreviationAndCountry("STWRDSH", usa());
   }

   private static Agency findAgencyByAbbreviationAndCountry(String agencyAbbr, Country country) {
      Criteria criteria = TestSessions.
          getLexiconSession().
          createCriteria(Agency.class).
          add(Restrictions.eq("agencyAbbr", agencyAbbr)).
          add(Restrictions.eq("country", country));
      return (Agency) criteria.uniqueResult();
   }
}
