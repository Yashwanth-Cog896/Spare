package com.monsanto.tps.lexicon.regulatory.agency.dao;

import com.monsanto.dbdataservices.SQLUtil;
import com.monsanto.tps.lexicon.agency.AgencySearchCriteria;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.AgencyBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.AgencyDepartmentBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.CountryBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.LexiconDataUnitTestCase;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.TestSessions;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Agency;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.AgencyDepartment;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Country;
import org.apache.commons.lang.ArrayUtils;
import org.junit.Test;

import javax.annotation.Resource;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.*;

/**
 * rrchak1 - Oct 10, 2008 3:57:50 PM
 */
public class AgencyDaoImpl_DUT
   extends LexiconDataUnitTestCase
{
   @Resource
   private AgencyDao agencyDao;

   @Test
 public void testReturnsMatchingAgencyForValidAgencyPubkey()
      throws Exception
   {
      Agency testAgencyOne = new AgencyBuilder()
         .withAgencyDepartment(new AgencyDepartmentBuilder().withName("XYZ"))
         .withPubKey("1111")
         .withAgencyAbbr("USQA")
         .create();
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setAgencyPubkey(new String[]{testAgencyOne.getAgencyPubkey()});
      AgencyDepartment[] departments = agencyDao.findDepartmentsBySearchCriteria(agencySearchCriteria);
      assertFalse(ArrayUtils.isEmpty(departments));
      AgencyDepartment agencyDepartment = departments[0];
      assertNotNull(agencyDepartment);
      Agency agency = agencyDepartment.getAgency();
      assertNotNull(agency);
      assertEquals("1111", agency.getAgencyPubkey());
   }

   @Test
 public void testReturnsMatchingAgencyForValidAgencyAcronym()
      throws Exception
   {
      AgencyDepartmentBuilder builderOne = new AgencyDepartmentBuilder().
         withAgencyDepartmentAbbr("USWER").
         withName("XYZ");
      AgencyDepartmentBuilder builderTwo = new AgencyDepartmentBuilder().
         withAgencyDepartmentAbbr("USYAS").
         withName("AAA");
      new AgencyBuilder()
         .withAgencyDepartment(builderOne)
         .withAgencyDepartment(builderTwo)
         .withAgencyAbbr("USQA")
         .create();
      new AgencyBuilder()
         .withAgencyDepartment(new AgencyDepartmentBuilder().withName("UZS"))
         .withAgencyAbbr("EPI")
         .create();
      new AgencyBuilder()
         .withAgencyDepartment(new AgencyDepartmentBuilder().withName("RWS"))
         .withAgencyAbbr("FDE")
         .create();

      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setAgencyAbbr(new String[]{"USQA", "FDE"});
      AgencyDepartment[] departments = agencyDao.findDepartmentsBySearchCriteria(agencySearchCriteria);
      assertFalse(ArrayUtils.isEmpty(departments));
      assertTrue(hasAbbreviation("USQA", departments));
      assertTrue(hasAbbreviation("FDE", departments));
   }

   private boolean hasAbbreviation(String agencyAbbr, AgencyDepartment[] departments) {
      for (AgencyDepartment department : departments) {
         Agency agency = department.getAgency();
         if (agencyAbbr.equals(agency.getAgencyAbbr())) {
            return true;
         }
      }
      return false;
   }

   @Test
 public void testReturnsMatchingAgenciesForWildcardedAgencyAcronym()
      throws Exception
   {
      AgencyDepartmentBuilder builderOne = new AgencyDepartmentBuilder().
         withAgencyDepartmentAbbr("USWER").
         withName("XYZ");
      AgencyDepartmentBuilder builderTwo = new AgencyDepartmentBuilder().
         withAgencyDepartmentAbbr("USYAS").
         withName("AAA");
      new AgencyBuilder()
         .withAgencyDepartment(builderOne)
         .withAgencyDepartment(builderTwo)
         .withAgencyAbbr("USDA_DUT")
         .create();
      new AgencyBuilder()
         .withAgencyDepartment(new AgencyDepartmentBuilder().withName("UZS"))
         .withAgencyAbbr("EPI")
         .create();
      new AgencyBuilder()
         .withAgencyDepartment(new AgencyDepartmentBuilder().withName("RWS"))
         .withAgencyAbbr("FDA_DUT")
         .create();

      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setAgencyAbbr(new String[]{"*DUT"});
      AgencyDepartment[] departments = agencyDao.findDepartmentsBySearchCriteria(agencySearchCriteria);
      assertFalse(ArrayUtils.isEmpty(departments));
      assertTrue(hasAbbreviation("USDA_DUT", departments));
      assertTrue(hasAbbreviation("FDA_DUT", departments));
   }

   @Test
 public void testReturnsMatchingAgencyForCountryIsoCode()
      throws Exception
   {
      new AgencyBuilder().
         withAgencyAbbr("USQA").
         withCountry(CountryBuilder.usa()).
         withAgencyDepartment(new AgencyDepartmentBuilder().
            withName("XYZ")).
         create();

      new AgencyBuilder().
         withAgencyAbbr("EPI").
         withCountry(CountryBuilder.usa()).
         withAgencyDepartment(
            new AgencyDepartmentBuilder().
               withAgencyDepartmentAbbr("USWER").
               withName("UUZ")
         ).
         withAgencyDepartment(
            new AgencyDepartmentBuilder().
               withAgencyDepartmentAbbr("USYAS").
               withName("AAA")).
         create();

      new AgencyBuilder().
         withAgencyAbbr("XZA").
         withCountry(CountryBuilder.japan()).
         withAgencyDepartment(new AgencyDepartmentBuilder().
            withName("AAY"))
         .create();

      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setAgencyCountryIsoCode(new String[]{"US"});
      AgencyDepartment[] departments = agencyDao.findDepartmentsBySearchCriteria(agencySearchCriteria);
      assertFalse(ArrayUtils.isEmpty(departments));
      assertTrue(belongToCountry("US", departments));
   }

   private boolean belongToCountry(String countryIsoCode, AgencyDepartment[] departments) {
      for (AgencyDepartment department : departments) {
         Agency agency = department.getAgency();
         assertNotNull(agency);
         assertEquals(countryIsoCode, agency.getCountry().getIsoCode());
      }
      return true;
   }

   @Test
 public void testReturnsMatchingDepartmentWithDepartmentName()
      throws Exception
   {
      new AgencyBuilder().
         withAgencyAbbr("USQA").
         withCountry(CountryBuilder.usa()).
         withAgencyDepartment(new AgencyDepartmentBuilder().
            withName("XYZ")).
         create();

      new AgencyBuilder().
         withAgencyAbbr("USQA").
         withCountry(CountryBuilder.japan()).
         withAgencyDepartment(new AgencyDepartmentBuilder().
            withName("AAA")).
         create();

      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setDepartmentNames(new String[]{"XYZ"});
      AgencyDepartment[] departments = agencyDao.findDepartmentsBySearchCriteria(agencySearchCriteria);
      assertFalse(ArrayUtils.isEmpty(departments));
      AgencyDepartment agencyDepartment = departments[0];
      assertNotNull(agencyDepartment);
      assertEquals("XYZ", agencyDepartment.getAgencyDeptName());
   }

   @Test
 public void testReturnsMatchingDepartmentsWithWildcardableDepartmentNames()
      throws Exception
   {
      new AgencyBuilder().
         withAgencyAbbr("USQA").
         withCountry(CountryBuilder.usa()).
         withAgencyDepartment(
            new AgencyDepartmentBuilder().
               withAgencyDepartmentAbbr("USWER").
               withName("XYZ")
         ).
         withAgencyDepartment(
            new AgencyDepartmentBuilder().
               withAgencyDepartmentAbbr("USYAS").
               withName("AAA")
         ).create();

      new AgencyBuilder().
         withAgencyAbbr("USQA").
         withCountry(CountryBuilder.japan()).
         withAgencyDepartment(new AgencyDepartmentBuilder().
            withName("XAA")).
         create();

      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setDepartmentNames(new String[]{"*AA"});
      AgencyDepartment[] departments = agencyDao.findDepartmentsBySearchCriteria(agencySearchCriteria);
      assertFalse(ArrayUtils.isEmpty(departments));
      hasDepartmentName("AAA", departments);
      hasDepartmentName("XAA", departments);
   }

   @Test
 public void testReturnsActiveAgencies_WithoutSpecifyingAnyCriteria()
      throws Exception
   {
      AgencyDepartmentBuilder builderOne = new AgencyDepartmentBuilder().
         withAgencyDepartmentAbbr("USWER").
         withName("XYZ");
      AgencyDepartmentBuilder builderTwo = new AgencyDepartmentBuilder().
         withAgencyDepartmentAbbr("USYAS").
         withName("AAA");
      new AgencyBuilder()
         .withAgencyDepartment(builderOne)
         .withAgencyDepartment(builderTwo)
         .withAgencyAbbr("USQA").withActiveStatus(true).create();
      new AgencyBuilder()
         .withAgencyDepartment(new AgencyDepartmentBuilder().withName("XYZ").withActiveStatus(true))
         .withAgencyAbbr("EPI").withActiveStatus(true).create();
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      AgencyDepartment[] departments = agencyDao.findDepartmentsBySearchCriteria(agencySearchCriteria);
      assertFalse(ArrayUtils.isEmpty(departments));
      AgencyDepartment agencyDepartment = departments[0];
      assertNotNull(agencyDepartment);
      Agency agency = agencyDepartment.getAgency();
      assertNotNull(agency);
      assertTrue(SQLUtil.stringToBoolean(agency.getActive()));
   }

   @Test

 public void testReturnsAllAgencies_WithIncludeInactiveAgenciesCriteria()
      throws Exception
   {
      AgencyDepartmentBuilder builderOne = new AgencyDepartmentBuilder().
         withAgencyDepartmentAbbr("USWER").
         withName("XYZ");
      AgencyDepartmentBuilder builderTwo = new AgencyDepartmentBuilder().
         withAgencyDepartmentAbbr("USYAS").
         withName("AAA");
      new AgencyBuilder()
         .withAgencyDepartment(builderOne)
         .withAgencyDepartment(builderTwo)
         .withAgencyAbbr("USQA").withActiveStatus(true).create();
      new AgencyBuilder()
         .withAgencyDepartment(new AgencyDepartmentBuilder().withName("XYZ").withActiveStatus(true))
         .withAgencyAbbr("EPI").withActiveStatus(false).create();
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setIncludeInactive(true);
      AgencyDepartment[] departments = agencyDao.findDepartmentsBySearchCriteria(agencySearchCriteria);
      assertFalse(ArrayUtils.isEmpty(departments));
      assertTrue(hasAbbreviation("USQA", departments));
      assertTrue(hasAbbreviation("EPI", departments));
   }

   @Test

 public void testReturnsOnlyActiveAgenciesAndDepartments()
      throws Exception
   {
      AgencyDepartmentBuilder builderOne = new AgencyDepartmentBuilder().
         withAgencyDepartmentAbbr("USWER").
         withName("XYZ").
         withActiveStatus(true);
      AgencyDepartmentBuilder builderTwo = new AgencyDepartmentBuilder().
         withAgencyDepartmentAbbr("USYAS").
         withName("AAA").
         withActiveStatus(false);
      AgencyDepartmentBuilder builderThree = new AgencyDepartmentBuilder().withName("UUU").withActiveStatus(true);
      new AgencyBuilder()
         .withAgencyDepartment(builderOne)
         .withAgencyDepartment(builderTwo)
         .withAgencyAbbr("USQA").withActiveStatus(true).create();
      new AgencyBuilder()
         .withAgencyDepartment(builderThree)
         .withAgencyAbbr("EPI").withActiveStatus(true).create();
      new AgencyBuilder()
         .withAgencyAbbr("DMV").withActiveStatus(false).create();
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      AgencyDepartment[] departments = agencyDao.findDepartmentsBySearchCriteria(agencySearchCriteria);
      assertFalse(ArrayUtils.isEmpty(departments));
      /*Not asserting count because of unknown existing records in database*/
      assertTrue(hasAbbreviation("USQA", departments));
      assertTrue(hasAbbreviation("EPI", departments));
      assertFalse(hasDepartmentName("AAA", departments));
      assertTrue(hasDepartmentName("XYZ", departments));
      assertFalse(hasAbbreviation("DMV", departments));
   }


   private boolean hasDepartmentName(String departmentName, AgencyDepartment[] departments) {
      for (AgencyDepartment department : departments) {
         if (departmentName.equals(department.getAgencyDeptName())) {
            return true;
         }
      }
      return false;
   }



   @Test

 public void testGetAgencyByAbbrAndCountry_ReturnsSuccess() {
      Agency sampleAgencyInDb = AgencyBuilder.epa();
      TestSessions.getLexiconSession().evict(sampleAgencyInDb);
      Country country = new Country();
      country.setIsoCode(sampleAgencyInDb.getCountry().getIsoCode());
      Agency agency = agencyDao.getAgencyByAbbvAndCountry(sampleAgencyInDb.getAgencyAbbr(), country);
      assertNotNull(agency);
      assertEquals(sampleAgencyInDb.getAgencyId(), agency.getAgencyId());
   }

   @Test

 public void testGetAgencyByAbbrAndCountry_ReturnsNullIfAbbrDoesnotExist() {
      Agency sampleAgencyInDb = AgencyBuilder.epa();
      TestSessions.getLexiconSession().evict(sampleAgencyInDb);
      Country country = new Country();
      country.setIsoCode(sampleAgencyInDb.getCountry().getIsoCode());
      Agency agency = agencyDao.getAgencyByAbbvAndCountry("DoesNOtexist", country);
      assertNull(agency);
   }

   @Test

 public void testGetAgencyByPubKey_ReturnsSuccess() {
      Agency agency = new AgencyBuilder().withAgencyAbbr("abbr1").create();
      TestSessions.getLexiconSession().evict(agency);
      Agency returnedAgency = agencyDao.getAgencyByPubkey(agency.getAgencyPubkey());
      assertThat(returnedAgency.getAgencyAbbr(), is(agency.getAgencyAbbr()));
   }

   @Test

 public void testGetAgencyDepartmentByPubkey_ReturnsSuccess() {
      Agency agency = new AgencyBuilder().withAgencyAbbr("abbr1").create();
      AgencyDepartment agencyDepartment = new AgencyDepartmentBuilder().create(agency);
      TestSessions.getLexiconSession().evict(agencyDepartment);
      AgencyDepartment returnedAgencyDepartment = agencyDao.getAgencyDepartmentByPubkey(agencyDepartment.getAgencyDeptPubkey());
      assertThat(returnedAgencyDepartment.getAgencyDeptAbbr(), is(agencyDepartment.getAgencyDeptAbbr()));
   }

   @Test

 public void testGetAgencyByAbbrAndCountry_ReturnsNullIfCountryDoesnotExist() {
      Agency sampleAgencyInDb = AgencyBuilder.epa();
      Country country = new Country();
      country.setIsoCode("doesnotexist");
      Agency agency = agencyDao.getAgencyByAbbvAndCountry(sampleAgencyInDb.getAgencyAbbr(), country);
      assertNull(agency);
   }

   @Test

 public void testGetAgencyDepartmentByAgencyAndAbbr_ReturnsSuccess() {
      Agency sampleAgencyInDb = AgencyBuilder.epa();
      AgencyDepartment sampleDepartment = sampleAgencyInDb.getDepartments().iterator().next();
      TestSessions.getLexiconSession().evict(sampleAgencyInDb);
      Agency agency = new Agency();
      agency.setAgencyId(sampleAgencyInDb.getAgencyId());
      AgencyDepartment agencyDepartment = agencyDao.getAgencyDepartmentByAgencyAndAbbr(agency, sampleDepartment.getAgencyDeptAbbr());
      assertNotNull(agencyDepartment);
      assertEquals(sampleDepartment.getAgencyDeptId(), agencyDepartment.getAgencyDeptId());
   }

   @Test
 public void testSaveAgency_IsSuccessful() {
      Agency agency = new Agency();
      agency.setActive("y");
      agency.setAgencyAbbr("abbr1");
      Country country = new Country();
      country.setIsoCode("US");
      agency.setCountry(country);
      agency.setAgencyName("name1");
      agency.setSurfaceAreaUomCode("uom");
      agencyDao.saveAgency(agency);
      Agency savedAgency = agencyDao.getAgencyByAbbvAndCountry("abbr1", country);
      assertEquals("name1", savedAgency.getAgencyName());

   }

   @Test
 public void testMergeAgency_IsSuccessful() {
      Agency agency = new Agency();
      agency.setActive("y");
      agency.setAgencyAbbr("abbr1");
      Country country = new Country();
      country.setIsoCode("US");
      agency.setCountry(country);
      agency.setAgencyName("name1");
      agency.setSurfaceAreaUomCode("uom");
      agencyDao.saveAgency(agency);
      Agency savedAgency = agencyDao.getAgencyByAbbvAndCountry("abbr1", country);
      TestSessions.getLexiconSession().evict(agency);

      assertEquals("name1", savedAgency.getAgencyName());

      Agency agency2 = new Agency();
      agency2.setActive("y");
      agency2.setAgencyAbbr("abbr1");
      Country country1 = new Country();
      country1.setIsoCode("US");
      agency2.setCountry(country);
      agency2.setAgencyName("name2");
      agency2.setSurfaceAreaUomCode("uom");

      agencyDao.mergeAgency(agency2, agency);
      Agency savedAgency1 = agencyDao.getAgencyByAbbvAndCountry("abbr1", country);
      assertEquals("name2", savedAgency1.getAgencyName());
   }


   @Test
 public void testSaveAgencyDepartment_IsSuccessful() {
      Agency agency = new Agency();
      agency.setActive("y");
      agency.setAgencyAbbr("abbr1");
      Country country = new Country();
      country.setIsoCode("US");
      agency.setCountry(country);
      agency.setAgencyName("name1");
      agency.setSurfaceAreaUomCode("uom");

      AgencyDepartment department = new AgencyDepartment();
      department.setActive("y");
      department.setAddress1("addr1");
      department.setAddress2("addr2");
      department.setAgency(agency);
      department.setAgencyDeptAbbr("deptabbr1");
      department.setAgencyDeptName("deptname1");
      department.setCity("city1");
      department.setPostalCode("12345");
      department.setSubCountryAbbr("s1");
      department.setSubSubCountryName("s2");
      agency.getDepartments().add(department);

      agencyDao.saveAgency(agency);
      agencyDao.saveAgencyDepartment(department);

      Agency savedAgency = agencyDao.getAgencyByAbbvAndCountry("abbr1", country);
      AgencyDepartment savedDepartment = agencyDao.getAgencyDepartmentByAgencyAndAbbr(savedAgency, "deptabbr1");
      assertEquals("name1", savedAgency.getAgencyName());
      assertEquals("deptname1", savedDepartment.getAgencyDeptName());
   }

   @Test
 public void testSaveAgencyDepartmentWithAgencyAlreadyExists_IsSuccessful() {
      Agency agency = new Agency();
      agency.setActive("y");
      agency.setAgencyAbbr("abbr1");
      Country country = new Country();
      country.setIsoCode("US");
      agency.setCountry(country);
      agency.setAgencyName("name1");
      agency.setSurfaceAreaUomCode("uom");
      agencyDao.saveAgency(agency);
      TestSessions.getLexiconSession().evict(agency);

      AgencyDepartment department = new AgencyDepartment();
      department.setActive("y");
      department.setAddress1("addr1");
      department.setAddress2("addr2");
      department.setAgency(agency);
      department.setAgencyDeptAbbr("deptabbr1");
      department.setAgencyDeptName("deptname1");
      department.setCity("city1");
      department.setPostalCode("12345");
      department.setSubCountryAbbr("s1");
      department.setSubSubCountryName("s2");
      Agency savedAgency = agencyDao.getAgencyByAbbvAndCountry("abbr1", country);
      savedAgency.getDepartments().add(department);
      department.setAgency(savedAgency);

      agencyDao.saveAgencyDepartment(department);


      AgencyDepartment savedDepartment = agencyDao.getAgencyDepartmentByAgencyAndAbbr(savedAgency, "deptabbr1");
      assertEquals("name1", savedAgency.getAgencyName());
      assertEquals("deptname1", savedDepartment.getAgencyDeptName());
   }

   @Test
 public void testMergeAgency_DoesNotAffectDepartments() {
      Agency agency = new Agency();
      agency.setActive("y");
      agency.setAgencyAbbr("abbr1");
      Country country = new Country();
      country.setIsoCode("US");
      agency.setCountry(country);
      agency.setAgencyName("name1");
      agency.setSurfaceAreaUomCode("uom");

      AgencyDepartment department = new AgencyDepartment();
      department.setActive("y");
      department.setAddress1("addr1");
      department.setAddress2("addr2");
      department.setAgency(agency);
      department.setAgencyDeptAbbr("deptabbr1");
      department.setAgencyDeptName("deptname1");
      department.setCity("city1");
      department.setPostalCode("12345");
      department.setSubCountryAbbr("s1");
      department.setSubSubCountryName("s2");
      agency.getDepartments().add(department);

      agencyDao.saveAgency(agency);
      agencyDao.saveAgencyDepartment(department);

      Agency savedAgency = agencyDao.getAgencyByAbbvAndCountry("abbr1", country);
      AgencyDepartment savedDepartment = agencyDao.getAgencyDepartmentByAgencyAndAbbr(savedAgency, "deptabbr1");
      assertEquals("name1", savedAgency.getAgencyName());
      assertEquals("deptname1", savedDepartment.getAgencyDeptName());

      AgencyDepartment department2 = new AgencyDepartment();
      department2.setActive("y");
      department2.setAddress1("addr1");
      department2.setAddress2("addr2");
      department2.setAgency(savedAgency);
      department2.setAgencyDeptAbbr("deptabbr1");
      department2.setAgencyDeptName("deptname2");
      department2.setCity("city1");
      department2.setPostalCode("12345");
      department2.setSubCountryAbbr("s1");
      department2.setSubSubCountryName("s2");

      Agency agency2 = new Agency();
      agency2.setActive("y");
      agency2.setAgencyAbbr("abbr1");
      Country country1 = new Country();
      country1.setIsoCode("US");
      agency2.setCountry(country);
      agency2.setAgencyName("name2");
      agency2.setSurfaceAreaUomCode("uom");
      agency2.getDepartments().add(department2);

      agencyDao.mergeAgency(agency2, savedAgency);

      AgencyDepartment savedDepartment1 = agencyDao.getAgencyDepartmentByAgencyAndAbbr(savedAgency, "deptabbr1");
      assertEquals("deptname1", savedDepartment1.getAgencyDeptName());
      Agency savedAgency1 = agencyDao.getAgencyByAbbvAndCountry("abbr1", country);
      assertEquals("name2", savedAgency1.getAgencyName());
   }

   @Test
 public void testMergeAgencyDepartment_isSuccessful() {
      Agency agency = new Agency();
      agency.setActive("y");
      agency.setAgencyAbbr("abbr1");
      Country country = new Country();
      country.setIsoCode("US");
      agency.setCountry(country);
      agency.setAgencyName("name1");
      agency.setSurfaceAreaUomCode("uom");

      AgencyDepartment department = new AgencyDepartment();
      department.setActive("y");
      department.setAddress1("addr1");
      department.setAddress2("addr2");
      department.setAgency(agency);
      department.setAgencyDeptAbbr("deptabbr1");
      department.setAgencyDeptName("deptname1");
      department.setCity("city1");
      department.setPostalCode("12345");
      department.setSubCountryAbbr("s1");
      department.setSubSubCountryName("s2");
      agency.getDepartments().add(department);

      agencyDao.saveAgency(agency);
      agencyDao.saveAgencyDepartment(department);

      Agency savedAgency = agencyDao.getAgencyByAbbvAndCountry("abbr1", country);
      AgencyDepartment savedDepartment = agencyDao.getAgencyDepartmentByAgencyAndAbbr(savedAgency, "deptabbr1");
      assertEquals("name1", savedAgency.getAgencyName());
      assertEquals("deptname1", savedDepartment.getAgencyDeptName());

      AgencyDepartment department2 = new AgencyDepartment();
      department2.setActive("y");
      department2.setAddress1("addr1");
      department2.setAddress2("addr2");
      department2.setAgency(savedAgency);
      department2.setAgencyDeptAbbr("deptabbr1");
      department2.setAgencyDeptName("deptname2");
      department2.setCity("city1");
      department2.setPostalCode("12345");
      department2.setSubCountryAbbr("s1");
      department2.setSubSubCountryName("s2");

      Agency agency2 = new Agency();
      agency2.setActive("y");
      agency2.setAgencyAbbr("abbr1");
      Country country1 = new Country();
      country1.setIsoCode("US");
      agency2.setCountry(country);
      agency2.setAgencyName("name2");
      agency2.setSurfaceAreaUomCode("uom");
      agency2.getDepartments().add(department2);

      agencyDao.mergeAgencyDepartment(department2, savedDepartment);

      AgencyDepartment savedDepartment1 = agencyDao.getAgencyDepartmentByAgencyAndAbbr(savedAgency, "deptabbr1");
      assertEquals("deptname2", savedDepartment1.getAgencyDeptName());
      Agency savedAgency1 = agencyDao.getAgencyByAbbvAndCountry("abbr1", country);
      assertEquals("name1", savedAgency1.getAgencyName());
   }
}
