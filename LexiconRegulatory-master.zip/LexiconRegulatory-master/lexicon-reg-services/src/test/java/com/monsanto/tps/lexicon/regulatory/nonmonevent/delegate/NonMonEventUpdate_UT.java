package com.monsanto.tps.lexicon.regulatory.nonmonevent.delegate;

import com.monsanto.tps.lexicon.nonmonevent.NonMonEventPersistRequest;
import com.monsanto.tps.lexicon.nonmonevent.NonMonEventPersistResponse;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.dao.NonMonEventDao;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.dao.NonMonEventPersistQuerySet;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.dao.StubNonMonEventPersistQuerySet;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.model.NonMonEventPersistRichRequest;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.validation.NonMonEventUpdateValidation;
import com.monsanto.tps.lexicon.regulatory.nonmonevent.validation.ValidationResults;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.expectLastCall;
import org.easymock.classextension.EasyMock;
import static org.easymock.classextension.EasyMock.*;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;

/**
 * nbwald - May 26, 2009 10:23:02 AM
 */
public class NonMonEventUpdate_UT
{
   private NonMonEventDao dao;
   private NonMonEventUpdateValidation validation;
   private ValidationResults success;
   private ValidationResults failure;
   private NonMonEventPersistRequest request;
   private NonMonEventUpdate update;

   @Before
   public void before()
      throws Exception
   {
      dao = createMock(NonMonEventDao.class);
      NonMonEventPersistQuerySet querySet = new StubNonMonEventPersistQuerySet();
      validation = createNiceMock(NonMonEventUpdateValidation.class);
      success = new ValidationResults(Collections.<String>emptyList(), Collections.<String>emptyList());
      failure = new ValidationResults(Arrays.asList("some error"), Collections.<String>emptyList());
      request = new NonMonEventPersistRequest();
      update = new NonMonEventUpdate();
      update.setDao(dao);
      update.setQuerySet(querySet);
      update.setValidation(validation);
   }

   @Test
   public void testUpdate_ValidateOnly_PassesValidation()
      throws Exception
   {
      expect(validation.validate(EasyMock.<NonMonEventPersistRichRequest>anyObject())).andReturn(success);
      replay(dao, validation);

      NonMonEventPersistResponse response = update.update(request, true);

      verify(dao, validation);
      assertThat(response.isSuccess(), is(true));
   }

   @Test
   public void testUpdate_ValidateOnly_FailsValidation()
      throws Exception
   {
      expect(validation.validate(EasyMock.<NonMonEventPersistRichRequest>anyObject())).andReturn(failure);
      replay(dao, validation);

      NonMonEventPersistResponse response = update.update(request, true);

      verify(dao, validation);
      assertThat(response.isSuccess(), is(false));
   }

   @Test
   public void testUpdate_Commit_FailsValidation()
      throws Exception
   {
      expect(validation.validate(EasyMock.<NonMonEventPersistRichRequest>anyObject())).andReturn(failure);
      replay(dao, validation);

      NonMonEventPersistResponse response = update.update(request, false);

      verify(dao, validation);
      assertThat(response.isSuccess(), is(false));
   }

   @Test
   public void testUpdate_Commit_PassesValidation()
      throws Exception
   {
      expect(validation.validate(EasyMock.<NonMonEventPersistRichRequest>anyObject())).andReturn(success);
      dao.update(EasyMock.<NonMonEvent>anyObject());
      expectLastCall();
      replay(dao, validation);

      NonMonEventPersistResponse response = update.update(request, false);

      verify(dao, validation);
      assertThat(response.isSuccess(), is(true));
   }
}
