package com.monsanto.tps.lexicon.regulatory.plantname.comparator;

import com.monsanto.tps.lexicon.plantname.OrionPlantProduct;
import com.monsanto.tps.lexicon.regulatory.comparator.ComparatorTestCase;

import java.util.Comparator;

/**
 * Created by IntelliJ IDEA.
 * User: etherma
 * Date: Dec 13, 2006
 * Time: 3:35:13 PM
 * To change this template use File | Settings | File Templates.
 */
public class OrionPlantProductComparator_UT extends ComparatorTestCase {
    protected Comparator getNewComparator() {
        return new OrionPlantProductComparator();
    }

    protected Object getNewInfoSmaller() {
        OrionPlantProduct plantName = new OrionPlantProduct();
        plantName.setName("plant 1");
        return plantName;
    }
    protected Object getNewInfoLarger() {
        OrionPlantProduct plantName = new OrionPlantProduct();
        plantName.setName("plant 2");
        return plantName;
    }
}
