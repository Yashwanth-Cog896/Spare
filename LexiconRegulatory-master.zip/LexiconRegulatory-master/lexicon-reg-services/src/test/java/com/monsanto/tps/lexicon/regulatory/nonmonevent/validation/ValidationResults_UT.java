package com.monsanto.tps.lexicon.regulatory.nonmonevent.validation;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * nbwald - May 28, 2009 4:46:46 PM
 */
public class ValidationResults_UT
{
   private List<String> errors;
   private List<String> warnings;

   @Before
   public void before()
      throws Exception
   {
      errors = new ArrayList<String>();
      warnings = new ArrayList<String>();
   }

   @Test
   public void testValidation_NoWarnings_NoErrors()
      throws Exception
   {
      ValidationResults results = new ValidationResults(errors, warnings);

      assertThat(results.isSuccess(), is(true));
      assertThat(results.getMessages().length, is(0));
   }

   @Test
   public void testValidation_Warnings_NoErrors()
      throws Exception
   {
      warnings.add("some warning");
      ValidationResults results = new ValidationResults(errors, warnings);

      assertThat(results.isSuccess(), is(true));
      assertThat(results.getMessages().length, is(1));
      assertThat(results.getMessages()[0], is("some warning"));
   }

   @Test
   public void testValidation_Warnings_Errors()
      throws Exception
   {
      errors.add("some error");
      warnings.add("some warning");
      ValidationResults results = new ValidationResults(errors, warnings);

      assertThat(results.isSuccess(), is(false));
      assertThat(results.getMessages().length, is(1));
      assertThat(results.getMessages()[0], is("some error"));
   }

   @Test
   public void testValidation_NoWarnings_Errors()
      throws Exception
   {
      errors.add("some error");
      ValidationResults results = new ValidationResults(errors, warnings);

      assertThat(results.isSuccess(), is(false));
      assertThat(results.getMessages().length, is(1));
      assertThat(results.getMessages()[0], is("some error"));
   }
}
