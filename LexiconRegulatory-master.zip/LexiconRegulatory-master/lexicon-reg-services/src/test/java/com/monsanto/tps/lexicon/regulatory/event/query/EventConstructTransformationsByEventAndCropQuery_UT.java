package com.monsanto.tps.lexicon.regulatory.event.query;

import com.monsanto.tps.lexicon.regulatory.event.model.MockRegulatoryEventConstructTransformation;
import com.monsanto.tps.lexicon.regulatory.event.model.RegulatoryEventConstructTransformation;
import static org.easymock.EasyMock.expect;
import org.easymock.classextension.EasyMock;
import static org.easymock.classextension.EasyMock.replay;
import static org.easymock.classextension.EasyMock.verify;
import static org.junit.Assert.assertNotNull;
import org.junit.Test;

/**
 * rrchak1 - Jul 13, 2009 4:40:20 PM
 */
public class EventConstructTransformationsByEventAndCropQuery_UT
{
   @Test
   public void testUsesMidasRegulatoryEventConstructTransformationsByEventAndCropQuery_GetsExactMatch_DoesNotCallStackedQuery() {
      EventConstructTransformationsByEventAndCropQuery exactMatchQuery = EasyMock.createMock(EventConstructTransformationsByEventAndCropQuery.class);
      EventConstructTransformationsByEventAndCropQuery stackedEventQuery = EasyMock.createMock(EventConstructTransformationsByEventAndCropQuery.class);
      EventConstructTransformationsByEventAndCropQuery eventConstructTransformationsByEventAndCropQuery
         = new CompositeEventConstructTransformationsByEventAndCropQuery(exactMatchQuery, stackedEventQuery);
      expect(exactMatchQuery.find("event,event2", "cropGenusSpecies")).andReturn(new RegulatoryEventConstructTransformation[]{new MockRegulatoryEventConstructTransformation("event,event2", "construct", "transformationBkg")});
      replay(exactMatchQuery);
      replay(stackedEventQuery);
      RegulatoryEventConstructTransformation[] eventConstructTransformations =
         eventConstructTransformationsByEventAndCropQuery.find("event,event2", "cropGenusSpecies");
      assertNotNull(eventConstructTransformations);
      verify(exactMatchQuery);
      verify(stackedEventQuery);
   }

   @Test
   public void testSwitchFromMidasRegulatoryEventConstructTransformationsByEventAndCropQueryToMidasEventConstructsByStackedEventAndCropQuery() {

      EventConstructTransformationsByEventAndCropQuery exactMatchQuery = EasyMock.createMock(EventConstructTransformationsByEventAndCropQuery.class);
      EventConstructTransformationsByEventAndCropQuery stackedEventQuery = EasyMock.createMock(EventConstructTransformationsByEventAndCropQuery.class);
      EventConstructTransformationsByEventAndCropQuery eventConstructTransformationsByEventAndCropQuery
         = new CompositeEventConstructTransformationsByEventAndCropQuery(exactMatchQuery, stackedEventQuery);
      expect(exactMatchQuery.find("event,event2", "cropGenusSpecies")).andReturn(new RegulatoryEventConstructTransformation[0]);
      expect(stackedEventQuery.find("event,event2", "cropGenusSpecies")).andReturn(new RegulatoryEventConstructTransformation[0]);
      replay(exactMatchQuery);
      replay(stackedEventQuery);
      RegulatoryEventConstructTransformation[] eventConstructTransformations =
         eventConstructTransformationsByEventAndCropQuery.find("event,event2", "cropGenusSpecies");
      assertNotNull(eventConstructTransformations);
      verify(exactMatchQuery);
      verify(stackedEventQuery);
   }

   @Test
   public void testUsesMidasRegulatoryEventConstructTransformationsByEventAndCropQuery_NoResults_DoesNotCallStackedQuery_EventIsNotStack() {

      EventConstructTransformationsByEventAndCropQuery exactMatchQuery = EasyMock.createMock(EventConstructTransformationsByEventAndCropQuery.class);
      EventConstructTransformationsByEventAndCropQuery stackedEventQuery = EasyMock.createMock(EventConstructTransformationsByEventAndCropQuery.class);
      EventConstructTransformationsByEventAndCropQuery eventConstructTransformationsByEventAndCropQuery
         = new CompositeEventConstructTransformationsByEventAndCropQuery(exactMatchQuery, stackedEventQuery);
      expect(exactMatchQuery.find("event", "cropGenusSpecies")).andReturn(new RegulatoryEventConstructTransformation[0]);
      replay(exactMatchQuery);
      replay(stackedEventQuery);
      RegulatoryEventConstructTransformation[] eventConstructTransformations =
         eventConstructTransformationsByEventAndCropQuery.find("event", "cropGenusSpecies");
      assertNotNull(eventConstructTransformations);
      verify(exactMatchQuery);
      verify(stackedEventQuery);
   }
}
