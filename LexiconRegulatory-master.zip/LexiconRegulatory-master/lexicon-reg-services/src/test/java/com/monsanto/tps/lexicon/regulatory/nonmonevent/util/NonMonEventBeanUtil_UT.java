package com.monsanto.tps.lexicon.regulatory.nonmonevent.util;

import com.monsanto.dbdataservices.SQLUtil;
import com.monsanto.tps.lexicon.commercialtrait.ComlTraitName;
import com.monsanto.tps.lexicon.commercialtrait.ComlTraitType;
import com.monsanto.tps.lexicon.commercialtrait.Company;
import com.monsanto.tps.lexicon.monnumber.ProteinName;
import com.monsanto.tps.lexicon.nonmonevent.NonMonEvent;
import com.monsanto.tps.lexicon.nonmonevent.NonMonEventConstruct;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import org.junit.Before;
import org.junit.Test;

import java.util.HashSet;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: gdleon
 * Date: May 6, 2009
 * Time: 1:34:02 PM
 */
public class NonMonEventBeanUtil_UT
{
   private NonMonEventBeanUtil nonMonEventBeanUtil;

   @Before
   public void before() {
      nonMonEventBeanUtil = new NonMonEventBeanUtil();
   }

   @Test
   public void testBuildNonMonEvent_BuildsCorrectly() {
      com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent nonMonEvent =
         new com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent();
      nonMonEvent.setEventDescription("EVENT DESC");
      nonMonEvent.setCropPubkey("1015");
      nonMonEvent.setActiveStatus(true);
      nonMonEvent.setMaterialName("MAT NAME");

      com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName proteinName = new com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName();
      proteinName.setActiveStatus(true);
      proteinName.setOrigSourceOrganism("OSO");
      proteinName.setProteinDescription("PROTDESC");
      proteinName.setProteinName("PROTNAME");
      proteinName.setProteinNameId(1111);
      proteinName.setProteinNamePubkey("PROTPUBKEY");
      Set<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName> proteinNames = new HashSet<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ProteinName>();
      proteinNames.add(proteinName);
      nonMonEvent.setProteinNames(proteinNames);

      com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType comlTraitType =
         new com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType();
      Set<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType> comlTraitTypes =
         new HashSet<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitType>();
      comlTraitTypes.add(comlTraitType);
      comlTraitType.setComlTraitTypeAbbr("CTTABBR");
      comlTraitType.setComlTraitTypeDesc("CTTDESC");
      comlTraitType.setComlTraitTypeId(321);
      nonMonEvent.setComlTraitTypes(comlTraitTypes);

      com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName comlTraitName =
         new com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName();
      Set<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName> comlTraitNames =
         new HashSet<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName>();
      comlTraitNames.add(comlTraitName);
      comlTraitName.setTraitAbbr("CTNABBR");
      comlTraitName.setTraitDesc("CTNDESC");
      comlTraitName.setComlTraitNameId(987);
      com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Company company =
         new com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Company();
      company.setCompanyName("COMPNAME");
      company.setCompanyPubkey("CPUB");
      company.setCompetitor("COMPETITOR");
      company.setCompanyId(1212);
      company.setActive("y");
      comlTraitName.setCompany(company);
      comlTraitName.setActive(true);
      nonMonEvent.setComlTraitNames(comlTraitNames);

      com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEventConstruct construct =
         new com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEventConstruct();
      Set<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEventConstruct> constructs =
         new HashSet<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEventConstruct>();
      constructs.add(construct);
      construct.setConstructName("CON NAME");
      construct.setNonMonEvent(nonMonEvent);
      nonMonEvent.setNonMonEventConstructs(constructs);

      NonMonEvent resultNonMonEvent = nonMonEventBeanUtil.buildNonMonEvent(nonMonEvent);

      assertEquals(resultNonMonEvent.getEventDescription(), nonMonEvent.getEventDescription());
      assertEquals(resultNonMonEvent.getCropPubkey(), nonMonEvent.getCropPubkey());
      assertEquals(resultNonMonEvent.isActive(), nonMonEvent.isActiveStatus());
      assertEquals("MAT NAME", nonMonEvent.getMaterialName());

      assertEquals(1, resultNonMonEvent.getProteinNames().size());
      ProteinName resultProteinName = resultNonMonEvent.getProteinNames().iterator().next();
      assertEquals(resultProteinName.getProteinName(), proteinName.getProteinName());
      assertEquals(resultProteinName.getProteinNamePubkey(), proteinName.getProteinNamePubkey());

      assertEquals(1, resultNonMonEvent.getComlTraitTypes().size());
      ComlTraitType resultComlTraitType = resultNonMonEvent.getComlTraitTypes().iterator().next();
      assertEquals(resultComlTraitType.getComlTraitTypeAbbr(), comlTraitType.getComlTraitTypeAbbr());
      assertEquals(resultComlTraitType.getComlTraitTypeDesc(), comlTraitType.getComlTraitTypeDesc());

      assertEquals(1, resultNonMonEvent.getComlTraitNames().size());
      ComlTraitName resultComlTraitName = resultNonMonEvent.getComlTraitNames().iterator().next();
      assertEquals(resultComlTraitName.getTraitAbbr(), comlTraitName.getTraitAbbr());
      assertEquals(resultComlTraitName.getTraitDesc(), comlTraitName.getTraitDesc());
      assertEquals(resultComlTraitName.isActive(), comlTraitName.isActive());
      Company resultCompany = resultComlTraitName.getCompany();
      assertEquals(resultCompany.getCompanyName(), company.getCompanyName());
      assertEquals(resultCompany.getCompanyPubkey(), company.getCompanyPubkey());
      assertEquals(resultCompany.getCompetitor(), company.getCompetitor());
      assertEquals(resultCompany.isActive(), SQLUtil.stringToBoolean(company.getActive()));

      assertEquals(1, resultNonMonEvent.getNonMonEventConstructs().size());
      NonMonEventConstruct resultConstruct = resultNonMonEvent.getNonMonEventConstructs().iterator().next();
      assertEquals(resultConstruct.getConstructName(), construct.getConstructName());
   }

   @Test
   public void testBuildNonMonEvent_EmptyChildrenHandledProperly() {
      com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent nonMonEvent =
         new com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent();
      nonMonEvent.setEventDescription("EVENT DESC");
      nonMonEvent.setCropPubkey("1015");
      nonMonEvent.setActiveStatus(true);
      nonMonEvent.setMaterialName("MAT NAME");

      NonMonEvent resultNonMonEvent = nonMonEventBeanUtil.buildNonMonEvent(nonMonEvent);

      assertEquals(resultNonMonEvent.getEventDescription(), nonMonEvent.getEventDescription());
      assertEquals(resultNonMonEvent.getCropPubkey(), nonMonEvent.getCropPubkey());
      assertEquals(resultNonMonEvent.isActive(), nonMonEvent.isActiveStatus());
      assertEquals("MAT NAME", nonMonEvent.getMaterialName());

      assertEquals(0, resultNonMonEvent.getProteinNames().size());
      assertEquals(0, resultNonMonEvent.getComlTraitTypes().size());
      assertEquals(0, resultNonMonEvent.getComlTraitNames().size());
      assertEquals(0, resultNonMonEvent.getNonMonEventConstructs().size());
   }

   @Test
   public void testBuildNonMonEvent_NullCompanyForComlTraitNameHandledProperly() {
      com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent nonMonEvent =
         new com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent();
      nonMonEvent.setEventDescription("EVENT DESC");
      nonMonEvent.setCropPubkey("1015");
      nonMonEvent.setActiveStatus(true);
      nonMonEvent.setMaterialName("MAT NAME");

      com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName comlTraitName =
         new com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName();
      Set<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName> comlTraitNames =
         new HashSet<com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitName>();
      comlTraitNames.add(comlTraitName);
      comlTraitName.setTraitAbbr("CTNABBR");
      comlTraitName.setTraitDesc("CTNDESC");
      comlTraitName.setComlTraitNameId(987);
      comlTraitName.setActive(true);
      nonMonEvent.setComlTraitNames(comlTraitNames);

      NonMonEvent resultNonMonEvent = nonMonEventBeanUtil.buildNonMonEvent(nonMonEvent);

      assertEquals(resultNonMonEvent.getEventDescription(), nonMonEvent.getEventDescription());
      assertEquals(resultNonMonEvent.getCropPubkey(), nonMonEvent.getCropPubkey());
      assertEquals(resultNonMonEvent.isActive(), nonMonEvent.isActiveStatus());
      assertEquals("MAT NAME", nonMonEvent.getMaterialName());

      assertEquals(0, resultNonMonEvent.getProteinNames().size());
      assertEquals(0, resultNonMonEvent.getComlTraitTypes().size());
      assertEquals(1, resultNonMonEvent.getComlTraitNames().size());
      ComlTraitName resultComlTraitName = resultNonMonEvent.getComlTraitNames().iterator().next();
      assertEquals(resultComlTraitName.getTraitAbbr(), comlTraitName.getTraitAbbr());
      assertEquals(resultComlTraitName.getTraitDesc(), comlTraitName.getTraitDesc());
      assertEquals(resultComlTraitName.isActive(), comlTraitName.isActive());
      assertNull(resultComlTraitName.getCompany());
      assertEquals(0, resultNonMonEvent.getNonMonEventConstructs().size());
   }

   @Test
   public void testBuildNonMonEvents_BuildCorrectly() {
      com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent nonMonEvent1 =
         new com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent();
      nonMonEvent1.setEventDescription("EVENT DESC 1");
      nonMonEvent1.setCropPubkey("1015");
      nonMonEvent1.setActiveStatus(true);
      nonMonEvent1.setMaterialName("MAT NAME1");

      com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent nonMonEvent2 =
         new com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent();
      nonMonEvent2.setEventDescription("EVENT DESC 2");
      nonMonEvent2.setCropPubkey("1115");
      nonMonEvent2.setActiveStatus(false);
      nonMonEvent2.setMaterialName("MAT NAME1");

      com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent[] nonMonEvents =
         new com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.NonMonEvent[2];
      nonMonEvents[0] = nonMonEvent1;
      nonMonEvents[1] = nonMonEvent2;

      NonMonEvent[] resultNonMonEvents = nonMonEventBeanUtil.buildNonMonEvents(nonMonEvents);

      assertEquals(resultNonMonEvents[0].getEventDescription(), nonMonEvents[0].getEventDescription());
      assertEquals(resultNonMonEvents[0].getCropPubkey(), nonMonEvents[0].getCropPubkey());
      assertEquals(resultNonMonEvents[0].isActive(), nonMonEvents[0].isActiveStatus());
      assertEquals(resultNonMonEvents[0].getMaterialName(), nonMonEvents[0].getMaterialName());

      assertEquals(0, resultNonMonEvents[0].getProteinNames().size());
      assertEquals(0, resultNonMonEvents[0].getComlTraitTypes().size());
      assertEquals(0, resultNonMonEvents[0].getComlTraitNames().size());
      assertEquals(0, resultNonMonEvents[0].getNonMonEventConstructs().size());

      assertEquals(resultNonMonEvents[1].getEventDescription(), nonMonEvents[1].getEventDescription());
      assertEquals(resultNonMonEvents[1].getCropPubkey(), nonMonEvents[1].getCropPubkey());
      assertEquals(resultNonMonEvents[1].isActive(), nonMonEvents[1].isActiveStatus());
      assertEquals(resultNonMonEvents[1].getMaterialName(), nonMonEvents[1].getMaterialName());

      assertEquals(0, resultNonMonEvents[1].getProteinNames().size());
      assertEquals(0, resultNonMonEvents[1].getComlTraitTypes().size());
      assertEquals(0, resultNonMonEvents[1].getComlTraitNames().size());
      assertEquals(0, resultNonMonEvents[1].getNonMonEventConstructs().size());
   }
}
