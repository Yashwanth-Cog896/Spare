package com.monsanto.tps.lexicon.regulatory.proteinname.service;

import com.monsanto.tps.lexicon.proteinname.ProteinNameService;
import com.monsanto.tps.lexicon.proteinname.OrionProteinName;
import com.monsanto.tps.lexicon.regulatory.proteinname.business.ProteinNameBusiness;
import com.monsanto.tps.lexicon.regulatory.proteinname.service.ProteinNameServiceImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/1/12
 * Time: 7:47 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class ProteinNameServiceImpl_UT {

    @Mock
    private ProteinNameBusiness proteinNameBusiness;

    @InjectMocks
    private ProteinNameService proteinNameService = new ProteinNameServiceImpl();

    private static final List<OrionProteinName> proteinNameList = new ArrayList<OrionProteinName>();

    @Test
    public void findProteinName_success() throws Exception {
        when(proteinNameBusiness.findProteinNames("Cre")).thenReturn(proteinNameList);

        final List<OrionProteinName> actualProteinNames = proteinNameBusiness.findProteinNames("Cre");

        assertEquals(actualProteinNames, proteinNameList);
    }
}
