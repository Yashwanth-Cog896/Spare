package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools;

import com.monsanto.tps.springframework.test.listener.dbunit.DBUnitTestExecutionListener;
import com.monsanto.tps.springframework.test.listener.dbunit.Datasource;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.support.DirtiesContextTestExecutionListener;
import org.springframework.test.context.transaction.TransactionalTestExecutionListener;
import org.springframework.transaction.annotation.Transactional;

/**
 * Created by IntelliJ IDEA.
 * User: drmans
 * Date: 3/7/12
 * Time: 11:39 AM
 */

@RunWith(SpringJUnit4ClassRunner.class)
@Transactional
@TestExecutionListeners({
        DependencyInjectionTestExecutionListener.class, DirtiesContextTestExecutionListener.class,
        TransactionalTestExecutionListener.class, DBUnitTestExecutionListener.class})
@Datasource(value = "dataSource")
@ContextConfiguration(locations = {"classpath:/com/monsanto/tps/lexicon/regulatory/contexts/lexicon-test-dao-dut-context.xml"})
public class DBUnitTest extends AbstractTransactionalJUnit4SpringContextTests {
}
