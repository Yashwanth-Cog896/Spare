package com.monsanto.tps.lexicon.regulatory.agency.validation;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import org.junit.Test;

/**
 * aagosw - Mar 10, 2009 8:11:00 AM
 */
public class AgencySaveUpdateValidatorImpl_UT
{

   @Test
   public void testValidate_ReturnsResultWithNoErrors() {
      AgencySaveUpdateValidator validator = new AgencySaveUpdateValidatorImpl();
      assertThat(validator.validate(null).hasErrors(), is(false));
   }
}
