/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.monnumber.service;

import com.monsanto.tps.lexicon.regulatory.event.model.EventConstruct;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.validation.BindException;
import org.springframework.validation.ObjectError;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

/* nbwald - 6/7/12 */
@RunWith(MockitoJUnitRunner.class)
public class SelectConstruct_UT
{
    @Mock private EventConstruct eventConstructA;
    @Mock private EventConstruct eventConstructB;
    @Mock private EventConstruct eventConstructC;
    @Mock private BindException bindException;

    @Before
    public void before()
       throws Exception
    {
        when(eventConstructA.getConstruct()).thenReturn("A");
        when(eventConstructB.getConstruct()).thenReturn("B");
        when(eventConstructC.getConstruct()).thenReturn("C");
    }

    @Test
    public void testHasEventConstruct()
       throws Exception 
    {
        SelectConstruct selectConstruct = new SelectConstruct(new EventConstruct[] {
            eventConstructA,
            eventConstructB,
            eventConstructC,
        });

        assertThat(selectConstruct.hasEventConstruct("A"), is(true));
        assertThat(selectConstruct.hasEventConstruct("a"), is(true));
        assertThat(selectConstruct.hasEventConstruct("B"), is(true));
        assertThat(selectConstruct.hasEventConstruct("b"), is(true));
        assertThat(selectConstruct.hasEventConstruct("C"), is(true));
        assertThat(selectConstruct.hasEventConstruct("c"), is(true));
        assertThat(selectConstruct.hasEventConstruct("D"), is(false));
        assertThat(selectConstruct.hasEventConstruct("d"), is(false));
    }

    @Test
    public void testGetEventConstruct()
       throws Exception
    {
        SelectConstruct selectConstruct = new SelectConstruct(new EventConstruct[] {
            eventConstructA,
            eventConstructB,
            eventConstructC,
        });

        assertThat(selectConstruct.getEventConstruct("A"), is(eventConstructA));
        assertThat(selectConstruct.getEventConstruct("a"), is(eventConstructA));
        assertThat(selectConstruct.getEventConstruct("B"), is(eventConstructB));
        assertThat(selectConstruct.getEventConstruct("b"), is(eventConstructB));
        assertThat(selectConstruct.getEventConstruct("C"), is(eventConstructC));
        assertThat(selectConstruct.getEventConstruct("c"), is(eventConstructC));
        assertThat(selectConstruct.getEventConstruct("d"), is(nullValue()));
        assertThat(selectConstruct.getEventConstruct("D"), is(nullValue()));
    }

    @Test
    public void testGetEventConstructs_OneEventConstruct()
       throws Exception
    {
        SelectConstruct selectConstruct = new SelectConstruct(new EventConstruct[] {
            eventConstructA
        });

        EventConstruct[] eventConstructs = selectConstruct.getEventConstructs(bindException, "objectName", "A");

        assertThat(eventConstructs.length, is(1));
        assertThat(eventConstructs[0], is(eventConstructA));
        verifyZeroInteractions(bindException);
    }

    @Test
    public void testGetEventConstructs_MultipleEventConstructs_NotMatching()
       throws Exception
    {
        EventConstruct[] originalEventConstructs = {
            eventConstructA,
            eventConstructB,
            eventConstructC,
        };
        SelectConstruct selectConstruct = new SelectConstruct(originalEventConstructs);

        EventConstruct[] resultEventConstructs = selectConstruct.getEventConstructs(bindException, "objectName", "D");

        assertThat(resultEventConstructs, is(originalEventConstructs));
        verify(bindException).addError(any(ObjectError.class));
    }

    @Test
    public void testGetEventConstructs_MultipleEventConstructs_Matches()
       throws Exception
    {
        EventConstruct[] originalEventConstructs = {
            eventConstructA,
            eventConstructB,
            eventConstructC,
        };
        SelectConstruct selectConstruct = new SelectConstruct(originalEventConstructs);

        EventConstruct[] resultEventConstructs = selectConstruct.getEventConstructs(bindException, "objectName", "B");

        assertThat(resultEventConstructs.length, is(1));
        assertThat(resultEventConstructs[0], is(eventConstructB));
        verifyZeroInteractions(bindException);
    }
}