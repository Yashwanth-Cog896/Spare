package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ComlTraitStack;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

/**
 * Created by IntelliJ IDEA.
 * User: gdleon
 * Date: Apr 30, 2009
 * Time: 2:48:48 PM
 * To change this template use File | Settings | File Templates.
 */
public class ComlTraitStackBuilder
{
   public static ComlTraitStack bt() {
      return findByPubkey("37423");
   }

   public static ComlTraitStack gl() {
      return findByPubkey("38723");
   }

   private static ComlTraitStack findByPubkey(String comlTraitStackPubkey) {
      Criteria comlTraitStackByPubkeyCriteria = TestSessions.getLexiconSession()
         .createCriteria(ComlTraitStack.class).add(Restrictions.eq("comlTraitStackPubkey", comlTraitStackPubkey));
      return (ComlTraitStack) comlTraitStackByPubkeyCriteria.uniqueResult();
   }
}
