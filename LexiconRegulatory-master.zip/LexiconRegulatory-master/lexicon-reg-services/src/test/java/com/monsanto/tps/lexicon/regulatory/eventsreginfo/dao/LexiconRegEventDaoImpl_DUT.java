package com.monsanto.tps.lexicon.regulatory.eventsreginfo.dao;

import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.*;
import com.monsanto.tps.lexicon.regulatory.eventsreginfo.domain.lexicon.LexiconRegEvent;
import com.monsanto.tps.lexicon.regulatory.eventsreginfo.util.dao.lexicon.TempSessionOcdDao;
import org.junit.Before;
import org.junit.Test;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 * Created by IntelliJ IDEA.
 * User: VVKALU
 * Date: Oct 5, 2010
 * Time: 2:29:57 PM
 * To change this template use File | Settings | File Templates.
 */
public class LexiconRegEventDaoImpl_DUT
        extends LexiconDataUnitTestCase {

    @Resource
    private LexiconRegEventDaoImpl monNumberArgotDao;

    @Resource
    private TempSessionOcdDao tempSessionOcdDao;

    @Before
    public void setUp() {
        System.out.println("I am here");
        new MonNumberBuilder().
                withMonNumber("MON_1111").withEventName("ZM_1111").withMonNumberConstruct(
                new MonNumberConstructBuilder().
                        withConstructName("CON_111").
                        withPvCode("PV_111")
        ).withComlTraitType(
                new ComlTraitTypeBuilder().
                        withTraitTypeAbbr("TRTABBR").
                        withTraitTypeDesc("TRT TYPE DESC")
        ).withProteinName(
                new ProteinNameBuilder().
                        withProteinName("PROT NAME").
                        withProteinNamePubkey("1234").
                        withProteinDescription("PROT DESC").
                        withOrigSourceOrganism("ORIG SOURCE ORG")
        ).withComlTraitName(
                new ComlTraitNameBuilder().
                        withTraitAbbr("TRTNABBR")
                        .withTraitDesc("TRTNMDESC")
        ).createInDb();

        new NonMonEventBuilder().
                withEventDescription("ZM_1111").
                withCropPubkey(CropBuilder.soybeans().getCropPubkey()).
                withNonMonEventConstruct(new NonMonEventConstructBuilder().
                        withConstructName("CON_111")).
                withComlTraitType(new ComlTraitTypeBuilder().
                        withTraitTypeAbbr("TRTABBRN").
                        withTraitTypeDesc("TRTTYPEDESC")).
                withComlTraitName(new ComlTraitNameBuilder().
                        withTraitAbbr("TNABBRNON").
                        withTraitDesc("TRT NAME DESC")).
                withProteinName(new ProteinNameBuilder().
                        withProteinName("PROT NAME NON").
                        withProteinNamePubkey("12345").
                        withProteinDescription("PROT DESC NON").
                        withOrigSourceOrganism("ORIG SOURCE ORG NON").
                        create()).
                create();
    }

    @Test
    public void testFindMonNumbersByEvent_wildcard() {
        LexiconRegEvent info = new LexiconRegEvent();
        info.setEvent("z%");
        List<LexiconRegEvent> lexiconRegEvents = monNumberArgotDao.findMonNumbers(info);
        assertNotNull(lexiconRegEvents);
    }

    @Test
    public void findByCollectionCriteria() {
        tempSessionOcdDao.insertText1Values(2010113L, Arrays.asList("MON 15985"));
        List<LexiconRegEvent> lexiconRegEvents = monNumberArgotDao.findMonNumbersByCollectionCriteria();
        assertNotNull(lexiconRegEvents);
        assertEquals(1, lexiconRegEvents.size());
        assertEquals("MON 15985", lexiconRegEvents.get(0).getMonNumber());
        assertEquals("PV-GHBK11", lexiconRegEvents.get(0).getPlasmIdPvCode());
    }

    @Test
    public void findMonNumbers_with_crop_And_monNumber() {
        TestSessions.getLexiconSession().flush();
        LexiconRegEvent info = new LexiconRegEvent();
        info.setMonNumber("MON 15985");
        info.setCrop("COTTON");
        List<LexiconRegEvent> lexiconRegEvents = monNumberArgotDao.findMonNumbers(info);
        assertNotNull(lexiconRegEvents);
        assertEquals(1, lexiconRegEvents.size());
        assertEquals("MON 15985", lexiconRegEvents.get(0).getMonNumber());
        assertEquals("PV-GHBK11", lexiconRegEvents.get(0).getPlasmIdPvCode());
    }
}
