package com.monsanto.tps.lexicon.regulatory.shippingcondition.business;

import com.monsanto.tps.lexicon.shippingcondition.OrionShippingCondition;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.ShippingCondition;
import com.monsanto.tps.lexicon.regulatory.shippingcondition.dao.ShippingConditionDAO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: 3/1/12
 * Time: 7:47 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(MockitoJUnitRunner.class)
public class ShippingConditionBusiness_UT {

    @Mock
    private ShippingConditionDAO shippingConditionDAO;

    @InjectMocks
    private ShippingConditionBusiness shippingConditionBusiness = new ShippingConditionBusiness();

    private final List<ShippingCondition> singleShippingConditionListFromDAO;
    private final List<ShippingCondition> multiShippingConditionListFromDAO;
    private static final List<ShippingCondition> emptyListFromDAO = new ArrayList<ShippingCondition>();

    private final List<OrionShippingCondition> singleShippingConditionListFromBusiness;
    private final List<OrionShippingCondition> multiShippingConditionListFromBusiness;
    private static final List<OrionShippingCondition> emptyListFromBusiness = new ArrayList<OrionShippingCondition>();

    public ShippingConditionBusiness_UT() {
        singleShippingConditionListFromDAO = new ArrayList<ShippingCondition>();
        singleShippingConditionListFromDAO.add(new ShippingCondition("type", true));

        multiShippingConditionListFromDAO = new ArrayList<ShippingCondition>();
        multiShippingConditionListFromDAO.add(new ShippingCondition("type1", true));
        multiShippingConditionListFromDAO.add(new ShippingCondition("type2", false));

        singleShippingConditionListFromBusiness = new ArrayList<OrionShippingCondition>();
        singleShippingConditionListFromBusiness.add(new OrionShippingCondition("type", true));

        multiShippingConditionListFromBusiness = new ArrayList<OrionShippingCondition>();
        multiShippingConditionListFromBusiness.add(new OrionShippingCondition("type1", true));
        multiShippingConditionListFromBusiness.add(new OrionShippingCondition("type2", false));
    }

    @Test
    public void findShippingCondition_findNone() throws Exception {

        when(shippingConditionDAO.findShippingConditions("asdf")).thenReturn(emptyListFromDAO);

        final List<OrionShippingCondition> actualShippingConditions = shippingConditionBusiness.findShippingConditions("asdf");

        checkShippingConditionLists(actualShippingConditions, emptyListFromBusiness);
    }

    @Test
    public void findShippingCondition_findSingle() throws Exception {

        when(shippingConditionDAO.findShippingConditions("Cool on Ice")).thenReturn(singleShippingConditionListFromDAO);

        final List<OrionShippingCondition> actualShippingConditions = shippingConditionBusiness.findShippingConditions("Cool on Ice");

        checkShippingConditionLists(actualShippingConditions, singleShippingConditionListFromBusiness);
    }

    @Test
    public void findShippingCondition_findByWildcard() throws Exception {

        when(shippingConditionDAO.findShippingConditions("F%")).thenReturn(multiShippingConditionListFromDAO);

        final List<OrionShippingCondition> actualShippingConditions = shippingConditionBusiness.findShippingConditions("F*");

        checkShippingConditionLists(actualShippingConditions, multiShippingConditionListFromBusiness);
    }

    @Test
    public void findShippingCondition_findAll() throws Exception {

        when(shippingConditionDAO.findShippingConditions("%")).thenReturn(multiShippingConditionListFromDAO);

        final List<OrionShippingCondition> actualShippingConditions = shippingConditionBusiness.findShippingConditions("");

        checkShippingConditionLists(actualShippingConditions, multiShippingConditionListFromBusiness);
    }

    private void checkShippingConditionLists(final List<OrionShippingCondition> actualShippingConditions, final List<OrionShippingCondition> singleShippingConditionListFromBusiness) {
        assertNotNull(actualShippingConditions);

        for(int i=0; i<singleShippingConditionListFromBusiness.size(); i++) {
            final OrionShippingCondition shippingCondition = actualShippingConditions.get(i);
            assertEquals(shippingCondition.getShippingCondition(), singleShippingConditionListFromBusiness.get(i).getShippingCondition());
            assertEquals(shippingCondition.getActiveStatus(), singleShippingConditionListFromBusiness.get(i).getActiveStatus());
        }
    }
}
