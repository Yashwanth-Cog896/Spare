/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tps.lexicon.regulatory.plantname.business;

import com.monsanto.tps.lexicon.commercialtrait.CommercialTraitService;
import com.monsanto.tps.lexicon.plantname.OrionPlantProduct;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static junit.framework.Assert.assertEquals;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

/* NBWALD - 5/10/12 */
@RunWith(MockitoJUnitRunner.class)
public class OrionPlantNameBusiness_UT {
    @Mock
    private PlantNameBusiness plantNameBusiness;
    @Mock
    private RegulatorySeedMaterialBusiness regulatorySeedMaterialBusiness;
    @Mock
    private CommercialTraitService commercialTraitService;

    @InjectMocks
    private OrionPlantNameBusiness OrionPlantProductBusiness = new OrionPlantNameBusiness();

    @Before
    public void setUp()
            throws Exception {
        List<OrionPlantProduct> plantNameResults = new ArrayList<OrionPlantProduct>();
        plantNameResults.add(new OrionPlantProduct("name1", "crop"));
        plantNameResults.add(new OrionPlantProduct("name4", "crop"));
        plantNameResults.add(new OrionPlantProduct("name6", "crop"));
        plantNameResults.add(new OrionPlantProduct("name7", "brand"));
        plantNameResults.add(new OrionPlantProduct("Material name is longer than 80 characters. It should not be returned. Material name is longer than 80 characters. It should not be returned", "crop"));

        List<OrionPlantProduct> lexiconProductResults = new ArrayList<OrionPlantProduct>();
        lexiconProductResults.add(new OrionPlantProduct("name2", "crop"));
        lexiconProductResults.add(new OrionPlantProduct("name5", "crop"));
        lexiconProductResults.add(new OrionPlantProduct("Material name is longer than 80 characters. It should not be returned.Material name is longer than 80 characters. It should not be returned", "crop"));

        List<OrionPlantProduct> lexiconTraitResults = new ArrayList<OrionPlantProduct>();
        lexiconTraitResults.add(new OrionPlantProduct("name3", "crop"));
        lexiconTraitResults.add(new OrionPlantProduct("Material name is longer than 80 characters. It should not be returned.Material name is longer than 80 characters. It should not be returned", "crop"));

        when(plantNameBusiness.findPlantNames("*")).thenReturn(new ArrayList<OrionPlantProduct>(plantNameResults)).thenReturn(new ArrayList<OrionPlantProduct>(plantNameResults));
        when(commercialTraitService.findCommercialTraitStacksByDesc("*")).thenReturn(new ArrayList<OrionPlantProduct>(lexiconTraitResults));
        when(regulatorySeedMaterialBusiness.findPlantNames("*")).thenReturn(new ArrayList<OrionPlantProduct>(lexiconProductResults));
    }

    @Test
    public final void testPlantNameService()
            throws Exception {
        List<OrionPlantProduct> combinedResults = OrionPlantProductBusiness.findPlantNames("*");

        List<OrionPlantProduct> plantNameResults = plantNameBusiness.findPlantNames("*");
        List<OrionPlantProduct> lexiconProductResults = regulatorySeedMaterialBusiness.findPlantNames("*");
        List<OrionPlantProduct> lexiconTraitResults = commercialTraitService.findCommercialTraitStacksByDesc("*");

        //there is one in each that has too long of a name and should be excluded.
        int expectedResultSize = plantNameResults.size() - 1 + lexiconProductResults.size() - 1 + lexiconTraitResults.size() - 1;

        assertEquals("Expected different number of results", expectedResultSize, combinedResults.size());
        assertEquals("Results were not sorted correctly", "name1", combinedResults.get(0).getName());
        assertEquals("Results were not sorted correctly", "name3", combinedResults.get(2).getName());
    }

    @Test
    public void testFindPlantNames_PlantNameServiceReturnsNull()
            throws Exception {
        when(commercialTraitService.findCommercialTraitStacksByDesc("*")).thenReturn(null);

        List<OrionPlantProduct> combinedResults = OrionPlantProductBusiness.findPlantNames("*");

        assertThat(combinedResults.isEmpty(), is(false));
    }
}