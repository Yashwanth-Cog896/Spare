package com.monsanto.tps.lexicon.regulatory.DB.Tests;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jul 3, 2007
 * Time: 10:19:32 AM
 */
public interface TestDataFunctor
{
   void insertTestData()
      throws Exception;
}
