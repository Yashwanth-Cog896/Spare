package com.monsanto.tps.lexicon.regulatory.agency.service;

import com.monsanto.tps.lexicon.agency.AgencyDepartment;
import com.monsanto.tps.lexicon.agency.AgencySaveUpdateBatchRequest;
import com.monsanto.tps.lexicon.agency.AgencySaveUpdateRequest;
import com.monsanto.tps.lexicon.agency.AgencySaveUpdateResponse;
import com.monsanto.tps.lexicon.agency.AgencySearchCriteria;
import com.monsanto.tps.lexicon.agency.AgencyService;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.AgencyBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.AgencyDepartmentBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.CountryBuilder;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.hibernate.testtools.LexiconAcceptanceTestCase;
import com.monsanto.tps.lexicon.regulatory.DB.Lexicon.model.Agency;
import org.junit.Test;

import javax.annotation.Resource;

import static org.junit.Assert.*;

/**
 * rrchak1 - Oct 9, 2008 2:34:42 PM
 */
public class AgencyServiceImpl_AT
   extends LexiconAcceptanceTestCase
{
   @Resource
   private AgencyService agencyService;

   @Test
 public void testReturnsMatchingAgencyForValidAgencyPubkey()
      throws Exception
   {
      Agency testAgency = insert(new AcceptanceTestData<Agency>()
      {
         public Agency dataToInsert() {
            return new AgencyBuilder().
               withAgencyDepartment(new AgencyDepartmentBuilder().
                  withName("XYZ")).
               withPubKey("1111").
               withAgencyAbbr("USQA").
               create();
         }
      });
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setAgencyPubkey(new String[]{testAgency.getAgencyPubkey()});
      com.monsanto.tps.lexicon.agency.Agency[] agencies = agencyService.findBySearchCriteria(agencySearchCriteria);
      assertNotNull(agencies);
      assertTrue(agencies.length > 0);
      com.monsanto.tps.lexicon.agency.Agency agency = extractAgencyByAbbr("USQA", agencies);
      assertNotNull(agency);
      assertTrue(agency.getDepartments().size() > 0);
      assertEquals(testAgency.getAgencyPubkey(), agency.getAgencyPubkey());
   }

   @Test 
 public void testThrowsIllegalArgumentExceptionForNonAlphaNumericAgencyPubkey()
      throws Exception
   {
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setAgencyPubkey(new String[]{"$uy778"});
      try {
         agencyService.findBySearchCriteria(agencySearchCriteria);
         fail("Should have thrown IllegalArgumentException");
      }
      catch (IllegalArgumentException e) {
         assertEquals("Agency Pubkey must contain only AlphaNumeric characters.", e.getMessage());
      }
   }

   @Test 
 public void testReturnsMatchingAgencyForValidAgencyAbbreviation()
      throws Exception
   {
      Agency testAgency = insert(new AcceptanceTestData<Agency>()
      {
         public Agency dataToInsert() {
            return new AgencyBuilder()
               .withAgencyDepartment(
                  new AgencyDepartmentBuilder()
                     .withName("XYZ")
               )
               .withAgencyAbbr("USQA")
               .create();
         }
      });
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setAgencyAbbr(new String[]{testAgency.getAgencyAbbr()});
      com.monsanto.tps.lexicon.agency.Agency[] agencies = agencyService.findBySearchCriteria(agencySearchCriteria);
      assertNotNull(agencies);
      assertTrue(agencies.length > 0);
      com.monsanto.tps.lexicon.agency.Agency agency = extractAgencyByAbbr("USQA", agencies);
      assertNotNull(agency);
      assertEquals(testAgency.getAgencyAbbr(), agency.getAgencyAbbr());
   }

   @Test 
 public void testThrowsIllegalArgumentExceptionForNonAlphaNumericAgencyAbbreviations()
      throws Exception
   {
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setAgencyAbbr(new String[]{"%USD"});
      try {
         agencyService.findBySearchCriteria(agencySearchCriteria);
         fail("Should have thrown IllegalArgumentException");
      }
      catch (IllegalArgumentException e) {
         assertEquals("Agency Abbreviation must contain alphanumeric characters; is wildcardable for a single request.", e.getMessage());
      }
   }

   @Test 
 public void testReturnsMatchingAgencyforWildcardableAgencyAbbreviation()
      throws Exception
   {
      Agency testAgency = insert(new AcceptanceTestData<Agency>()
      {
         public Agency dataToInsert() {
            return new AgencyBuilder()
               .withAgencyDepartment(
                  new AgencyDepartmentBuilder()
                     .withName("XYZ")
               )
               .withAgencyAbbr("USQA")
               .create();
         }
      });
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setAgencyAbbr(new String[]{"USQ*"});
      com.monsanto.tps.lexicon.agency.Agency[] agencies = agencyService.findBySearchCriteria(agencySearchCriteria);
      assertNotNull(agencies);
      assertTrue(agencies.length > 0);
      com.monsanto.tps.lexicon.agency.Agency agency = extractAgencyByAbbr("USQA", agencies);
      assertNotNull(agency);
      assertEquals(testAgency.getAgencyAbbr(), agency.getAgencyAbbr());
   }

   @Test 
 public void testThrowsIllegalArgumentExceptionForMultipleWildcardableAgencyAbbreviations()
      throws Exception
   {
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setAgencyAbbr(new String[]{"*US", "EP*"});
      try {
         agencyService.findBySearchCriteria(agencySearchCriteria);
         fail("Should have thrown IllegalArgumentException");
      }
      catch (IllegalArgumentException e) {
         assertEquals("Agency Abbreviation must contain alphanumeric characters; is wildcardable for a single request.", e.getMessage());
      }
   }


   @Test 
 public void testReturnsMatchingAgenciesForValidCountryCode()
      throws Exception
   {
      Agency testAgency = insert(new AcceptanceTestData<Agency>()
      {
         public Agency dataToInsert() {
            return new AgencyBuilder()
               .withAgencyDepartment(
                  new AgencyDepartmentBuilder()
                     .withName("XYZ")
               )
               .withAgencyAbbr("USQA")
               .withCountry(CountryBuilder.japan())
               .create();
         }
      });
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setAgencyCountryIsoCode(new String[]{testAgency.getCountry().getIsoCode()});
      com.monsanto.tps.lexicon.agency.Agency[] agencies = agencyService.findBySearchCriteria(agencySearchCriteria);
      assertNotNull(agencies);
      assertTrue(agencies.length > 0);
      com.monsanto.tps.lexicon.agency.Agency agency = extractAgencyByAbbr("USQA", agencies);
      assertNotNull(agency);
      assertEquals(testAgency.getCountry().getIsoCode(), agency.getCountryIsoCode());
   }

   @Test 
 public void testThrowsIllegalArgumentExceptionForInvalidCountryCode()
      throws Exception
   {
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setAgencyCountryIsoCode(new String[]{"USA"});
      try {
         agencyService.findBySearchCriteria(agencySearchCriteria);
         fail("Should have thrown IllegalArgumentException");
      }
      catch (IllegalArgumentException e) {
         assertEquals("Country ISO Code must contain only two alphabetic characters.", e.getMessage());
      }
   }

   @Test 
 public void testReturnsMatchingAgencyForValidAgencyAbbreviationAndCountryCode()
      throws Exception
   {
      Agency testAgency = insert(new AcceptanceTestData<Agency>()
      {
         public Agency dataToInsert() {
            return new AgencyBuilder()
               .withAgencyDepartment(
                  new AgencyDepartmentBuilder()
                     .withName("XYZ")
               )
               .withAgencyAbbr("USQA")
               .withCountry(CountryBuilder.usa())
               .create();
         }
      });

      insert(new AcceptanceTestData<Agency>()
      {
         public Agency dataToInsert() {
            return new AgencyBuilder()
               .withAgencyDepartment(
                  new AgencyDepartmentBuilder()
                     .withName("XYZ")
               )
               .withAgencyAbbr("EPI")
               .withCountry(CountryBuilder.usa())
               .create();
         }
      });
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setAgencyCountryIsoCode(new String[]{testAgency.getCountry().getIsoCode()});
      agencySearchCriteria.setAgencyAbbr(new String[]{"USQA"});
      com.monsanto.tps.lexicon.agency.Agency[] agencies = agencyService.findBySearchCriteria(agencySearchCriteria);
      assertNotNull(agencies);
      assertTrue(agencies.length > 0);
      com.monsanto.tps.lexicon.agency.Agency agency = extractAgencyByAbbr("USQA", agencies);
      assertNotNull(agency);
      assertEquals(testAgency.getCountry().getIsoCode(), agency.getCountryIsoCode());
   }

   @Test 
 public void testReturnsMatchingAgencyforAgencyDepartmentName()
      throws Exception
   {
      insert(new AcceptanceTestData<Agency>()
      {
         public Agency dataToInsert() {
            AgencyDepartmentBuilder builderOne = new AgencyDepartmentBuilder()
               .withAgencyDepartmentAbbr("USWER")
               .withName("XYZ");
            AgencyDepartmentBuilder builderTwo = new AgencyDepartmentBuilder()
               .withAgencyDepartmentAbbr("USYAS")
               .withName("AAA");
            return new AgencyBuilder()
               .withAgencyDepartment(builderOne)
               .withAgencyDepartment(builderTwo)
               .withPubKey("1111")
               .withAgencyAbbr("USQA")
               .create();
         }
      });

      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setDepartmentNames(new String[]{"XYZ"});
      com.monsanto.tps.lexicon.agency.Agency[] agencies = agencyService.findBySearchCriteria(agencySearchCriteria);
      assertNotNull(agencies);
      assertTrue(agencies.length > 0);
      com.monsanto.tps.lexicon.agency.Agency agency = extractAgencyByAbbr("USQA", agencies);
      assertNotNull(agency);
      assertTrue(agency.getDepartments().size() > 0);
   }

   @Test 
 public void testReturnsMatchingAgenciesForWildcardedDepartmentName()
      throws Exception
   {
      insert(new AcceptanceTestData<Agency>()
      {
         public Agency dataToInsert() {
            AgencyDepartmentBuilder builderOne = new AgencyDepartmentBuilder()
               .withAgencyDepartmentAbbr("USWER")
               .withName("XYZ");
            AgencyDepartmentBuilder builderTwo = new AgencyDepartmentBuilder()
               .withAgencyDepartmentAbbr("USYAS")
               .withName("TESTDEPT2");
            return new AgencyBuilder()
               .withAgencyDepartment(builderOne)
               .withAgencyDepartment(builderTwo)
               .withPubKey("1111")
               .withAgencyAbbr("USQA")
               .create();
         }
      });

      insert(new AcceptanceTestData<Agency>()
      {
         public Agency dataToInsert() {
            AgencyDepartmentBuilder builderOne = new AgencyDepartmentBuilder()
               .withAgencyDepartmentAbbr("USORP")
               .withName("TESTDEPT1");
            AgencyDepartmentBuilder builderTwo = new AgencyDepartmentBuilder()
               .withAgencyDepartmentAbbr("USNWZ")
               .withName("SOMETHINGELSE");
            return new AgencyBuilder()
               .withAgencyDepartment(builderOne)
               .withAgencyDepartment(builderTwo)
               .withPubKey("1222")
               .withAgencyAbbr("EPI")
               .create();
         }
      });

      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setDepartmentNames(new String[]{"TESTDEPT*"});
      com.monsanto.tps.lexicon.agency.Agency[] agencies = agencyService.findBySearchCriteria(agencySearchCriteria);
      assertNotNull(agencies);
      assertTrue(agencies.length > 0);
      assertTrue(hasAbbreviation("EPI", agencies));
      com.monsanto.tps.lexicon.agency.Agency agency = extractAgencyByAbbr("EPI", agencies);
      assertNotNull(agency);
      assertTrue(agency.getDepartments().size() > 0);
   }

   @Test 
 public void testReturnsEmptyResultsForGivenAgencyAbbrAndNonExistentWildCardedAgencyDepartmentName()
      throws Exception
   {

      insert(new AcceptanceTestData<Agency>()
      {
         public Agency dataToInsert() {
            AgencyDepartmentBuilder builderOne = new AgencyDepartmentBuilder()
               .withAgencyDepartmentAbbr("USWER")
               .withName("XYZ");
            AgencyDepartmentBuilder builderTwo = new AgencyDepartmentBuilder()
               .withAgencyDepartmentAbbr("USYAS")
               .withName("AAA");
            return new AgencyBuilder()
               .withAgencyDepartment(builderOne)
               .withAgencyDepartment(builderTwo)
               .withPubKey("1111")
               .withAgencyAbbr("USQA")
               .create();
         }
      });

      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setDepartmentNames(new String[]{"T*"});
      agencySearchCriteria.setAgencyAbbr(new String[]{"USQA"});
      com.monsanto.tps.lexicon.agency.Agency[] agencies = agencyService.findBySearchCriteria(agencySearchCriteria);
      assertNotNull(agencies);
      assertEquals(0, agencies.length);
   }

   @Test 
 public void testThrowsIllegalArgumentExceptionForMultipleWildcardableAgencyDeptNames()
      throws Exception
   {
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setDepartmentNames(new String[]{"*US", "EP*"});
      try {
         agencyService.findBySearchCriteria(agencySearchCriteria);
         fail("Should have thrown IllegalArgumentException");
      }
      catch (IllegalArgumentException e) {
         assertEquals("Agency Department must contain only Alpha characters, comma and space; is wildcardable for a single request.", e.getMessage());
      }
   }

   @Test 
 public void testReturnsEmptyResultsForNonExistentAgencyAbbreviation()
      throws Exception
   {
      insert(new AcceptanceTestData<Agency>()
      {
         public Agency dataToInsert() {
            return new AgencyBuilder()
               .withAgencyDepartment(
                  new AgencyDepartmentBuilder()
                     .withName("XYZ")
               )
               .withPubKey("1111")
               .withAgencyAbbr("USQA")
               .create();
         }
      });
      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setAgencyAbbr(new String[]{"NONEXISTENT"});
      com.monsanto.tps.lexicon.agency.Agency[] agencies = agencyService.findBySearchCriteria(agencySearchCriteria);
      assertNotNull(agencies);
      assertEquals(0, agencies.length);
   }

   @Test 
 public void testReturnsAllActiveAgencies()
      throws Exception
   {
      insert(new AcceptanceTestData<Agency>()
      {
         public Agency dataToInsert() {
            return new AgencyBuilder()
               .withAgencyDepartment(
                  new AgencyDepartmentBuilder()
                     .withName("XYZ")
               )
               .withPubKey("1111")
               .withAgencyAbbr("USQA")
               .withActiveStatus(true)
               .create();
         }
      });

      insert(new AcceptanceTestData<Agency>()
      {
         public Agency dataToInsert() {
            return new AgencyBuilder()
               .withAgencyDepartment(
                  new AgencyDepartmentBuilder()
                     .withName("AAA")
               )
               .withPubKey("2222")
               .withAgencyAbbr("DMV")
               .withActiveStatus(false)
               .create();
         }
      });

      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      com.monsanto.tps.lexicon.agency.Agency[] agencies = agencyService.findBySearchCriteria(agencySearchCriteria);
      assertNotNull(agencies);
      assertTrue(hasAbbreviation("USQA", agencies));
      assertFalse(hasAbbreviation("DMV", agencies));
   }


   public void setAgencyService(AgencyService agencyService) {
      this.agencyService = agencyService;
   }

   @Test 
 public void testSaveOrValidate_SavesAgenciesSuccessfully()
      throws Exception
   {
      AgencySaveUpdateRequest request = new AgencySaveUpdateRequest();
      request.setActive(true);
      request.setAgencyAbbr("testAgencyAbbvr");
      request.setAgencyName("testAgencyName");
      request.setCountryIsoCode("US");
      request.setSurfaceAreaUomCode("UM");
      request.setAddress1("addr1");
      request.setAddress2("addr2");
      request.setAgencyDeptAbbr("testDeptAbbr");
      request.setAgencyDeptName("testDeptName");
      request.setCity("city");
      request.setPostalCode("12345");
      request.setSubCountryAbbr("S1");
      request.setSubSubCountryName("S2");
      request.setAuditComment("TestAuditComment");

      AgencySaveUpdateBatchRequest batchRequest = new AgencySaveUpdateBatchRequest();
      batchRequest.setAgencySaveUpdateRequests(new AgencySaveUpdateRequest[]{request});
      batchRequest.setCommit(true);
      AgencySaveUpdateResponse[] responses = agencyService.saveOrValidate(batchRequest);
      assertEquals(1, responses.length);
      assertTrue(responses[0].isSuccessful());

      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setAgencyAbbr(new String[]{"testAgencyAbbvr"});
      com.monsanto.tps.lexicon.agency.Agency[] results = agencyService.findBySearchCriteria(agencySearchCriteria);

      assertEquals(1, results.length);
      assertEquals("testAgencyName", results[0].getAgencyName());
   }

   @Test 
 public void testSaveOrValidate_ValidatesAgenciesSuccessfully()
      throws Exception
   {
      AgencySaveUpdateRequest request = new AgencySaveUpdateRequest();
      request.setActive(true);
      request.setAgencyAbbr("testAgencyAbbvr");
      request.setAgencyName("testAgencyName");
      request.setCountryIsoCode("US");
      request.setSurfaceAreaUomCode("UM");
      request.setAddress1("addr1");
      request.setAddress2("addr2");
      request.setAgencyDeptAbbr("testDeptAbbr");
      request.setAgencyDeptName("testDeptName");
      request.setCity("city");
      request.setPostalCode("12345");
      request.setSubCountryAbbr("S1");
      request.setSubSubCountryName("S2");
      request.setAuditComment("TestAuditComment");

      AgencySaveUpdateBatchRequest batchRequest = new AgencySaveUpdateBatchRequest();
      batchRequest.setAgencySaveUpdateRequests(new AgencySaveUpdateRequest[]{request});
      batchRequest.setCommit(false);
      AgencySaveUpdateResponse[] responses = agencyService.saveOrValidate(batchRequest);
      assertEquals(1, responses.length);
      assertTrue(responses[0].isSuccessful());

      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setAgencyAbbr(new String[]{"testAgencyAbbvr"});
      com.monsanto.tps.lexicon.agency.Agency[] results = agencyService.findBySearchCriteria(agencySearchCriteria);

      assertEquals(0, results.length);
   }

   @Test 
 public void testUpdateOrValidate_UpdateAgenciesSuccessfully()
      throws Exception
   {

      AgencySaveUpdateRequest request = new AgencySaveUpdateRequest();
      request.setActive(true);
      request.setAgencyAbbr("testAgencyAbbvr");
      request.setAgencyName("testAgencyName");
      request.setCountryIsoCode("US");
      request.setSurfaceAreaUomCode("UM");
      request.setAddress1("addr1");
      request.setAddress2("addr2");
      request.setAgencyDeptAbbr("testDeptAbbr");
      request.setAgencyDeptName("testDeptName");
      request.setCity("city");
      request.setPostalCode("12345");
      request.setSubCountryAbbr("S1");
      request.setSubSubCountryName("S2");
      request.setAuditComment("TestAuditComment");

      AgencySaveUpdateBatchRequest batchRequest = new AgencySaveUpdateBatchRequest();
      batchRequest.setAgencySaveUpdateRequests(new AgencySaveUpdateRequest[]{request});
      batchRequest.setCommit(true);
      AgencySaveUpdateResponse[] responses = agencyService.saveOrValidate(batchRequest);
      assertEquals(1, responses.length);
      assertTrue(responses[0].isSuccessful());

      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setAgencyAbbr(new String[]{"testAgencyAbbvr"});
      com.monsanto.tps.lexicon.agency.Agency[] results = agencyService.findBySearchCriteria(agencySearchCriteria);

      assertEquals(1, results.length);
      com.monsanto.tps.lexicon.agency.Agency agency = results[0];
      AgencyDepartment agencyDepartment = agency.getDepartments().iterator().next();
      assertEquals("testAgencyName", agency.getAgencyName());
      assertEquals("testDeptName", agencyDepartment.getAgencyDeptName());

      AgencySaveUpdateRequest request2 = new AgencySaveUpdateRequest();
      request2.setActive(true);
      request2.setAgencyAbbr("testAgencyAbbvr");
      request2.setAgencyName("testAgencyName2");
      request2.setCountryIsoCode("US");
      request2.setSurfaceAreaUomCode("UM");
      request2.setAddress1("addr1");
      request2.setAddress2("addr2");
      request2.setAgencyDeptAbbr("testDeptAbbr");
      request2.setAgencyDeptName("testDeptName2");
      request2.setCity("city");
      request2.setPostalCode("12345");
      request2.setSubCountryAbbr("S1");
      request2.setSubSubCountryName("S2");
      request2.setAuditComment("TestAuditComment2");
      request2.setAgencyPubkey(agency.getAgencyPubkey());
      request2.setAgencyDeptPubkey(agencyDepartment.getAgencyDeptPubkey());

      AgencySaveUpdateBatchRequest batchRequest2 = new AgencySaveUpdateBatchRequest();
      batchRequest2.setAgencySaveUpdateRequests(new AgencySaveUpdateRequest[]{request2});
      batchRequest2.setCommit(true);
      AgencySaveUpdateResponse[] responses2 = agencyService.updateOrValidate(batchRequest2);
      assertEquals(1, responses2.length);
      assertTrue(responses2[0].isSuccessful());

      com.monsanto.tps.lexicon.agency.Agency[] results2 = agencyService.findBySearchCriteria(agencySearchCriteria);

      assertEquals(1, results2.length);
      com.monsanto.tps.lexicon.agency.Agency agency2 = results2[0];
      AgencyDepartment agencyDepartment2 = agency2.getDepartments().iterator().next();
      assertEquals("testAgencyName2", agency2.getAgencyName());
      assertEquals("testDeptName2", agencyDepartment2.getAgencyDeptName());

   }

   @Test 
 public void testUpdateOrValidate_ValidatesAgenciesSuccessfully()
      throws Exception
   {

      AgencySaveUpdateRequest request = new AgencySaveUpdateRequest();
      request.setActive(true);
      request.setAgencyAbbr("testAgencyAbbvr");
      request.setAgencyName("testAgencyName");
      request.setCountryIsoCode("US");
      request.setSurfaceAreaUomCode("UM");
      request.setAddress1("addr1");
      request.setAddress2("addr2");
      request.setAgencyDeptAbbr("testDeptAbbr");
      request.setAgencyDeptName("testDeptName");
      request.setCity("city");
      request.setPostalCode("12345");
      request.setSubCountryAbbr("S1");
      request.setSubSubCountryName("S2");
      request.setAuditComment("TestAuditComment");

      AgencySaveUpdateBatchRequest batchRequest = new AgencySaveUpdateBatchRequest();
      batchRequest.setAgencySaveUpdateRequests(new AgencySaveUpdateRequest[]{request});
      batchRequest.setCommit(true);
      AgencySaveUpdateResponse[] responses = agencyService.saveOrValidate(batchRequest);
      assertEquals(1, responses.length);
      assertTrue(responses[0].isSuccessful());

      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setAgencyAbbr(new String[]{"testAgencyAbbvr"});
      com.monsanto.tps.lexicon.agency.Agency[] results = agencyService.findBySearchCriteria(agencySearchCriteria);

      assertEquals(1, results.length);
      com.monsanto.tps.lexicon.agency.Agency agency = results[0];
      AgencyDepartment agencyDepartment = agency.getDepartments().iterator().next();
      assertEquals("testAgencyName", agency.getAgencyName());
      assertEquals("testDeptName", agencyDepartment.getAgencyDeptName());

      AgencySaveUpdateRequest request2 = new AgencySaveUpdateRequest();
      request2.setAgencyPubkey(agency.getAgencyPubkey());
      request2.setAgencyDeptPubkey(agencyDepartment.getAgencyDeptPubkey());
      request2.setActive(true);
      request2.setAgencyAbbr("testAgencyAbbvr");
      request2.setAgencyName("testAgencyName2");
      request2.setCountryIsoCode("US");
      request2.setSurfaceAreaUomCode("UM");
      request2.setAddress1("addr1");
      request2.setAddress2("addr2");
      request2.setAgencyDeptAbbr("testDeptAbbr");
      request2.setAgencyDeptName("testDeptName");
      request2.setCity("city");
      request2.setPostalCode("12345");
      request2.setSubCountryAbbr("S1");
      request2.setSubSubCountryName("S2");
      request2.setAuditComment("TestAuditComment2");

      AgencySaveUpdateBatchRequest batchRequest2 = new AgencySaveUpdateBatchRequest();
      batchRequest2.setAgencySaveUpdateRequests(new AgencySaveUpdateRequest[]{request2});
      batchRequest2.setCommit(false);
      AgencySaveUpdateResponse[] responses2 = agencyService.updateOrValidate(batchRequest2);
      assertEquals(1, responses2.length);

      com.monsanto.tps.lexicon.agency.Agency[] results2 = agencyService.findBySearchCriteria(agencySearchCriteria);

      assertEquals(1, results.length);
      assertEquals("testAgencyName", results2[0].getAgencyName());
   }

   private com.monsanto.tps.lexicon.agency.Agency extractAgencyByAbbr(String agencyAbbr, com.monsanto.tps.lexicon.agency.Agency[] agencies) {
      for (com.monsanto.tps.lexicon.agency.Agency agency : agencies) {
         if (agencyAbbr.equalsIgnoreCase(agency.getAgencyAbbr())) {
            return agency;
         }
      }
      return null;
   }

   private boolean hasAbbreviation(String abbreviation, com.monsanto.tps.lexicon.agency.Agency[] agencies) {
      for (com.monsanto.tps.lexicon.agency.Agency agency : agencies) {
         if (abbreviation.equals(agency.getAgencyAbbr())) {
            return true;
         }
      }
      return false;
   }
}
