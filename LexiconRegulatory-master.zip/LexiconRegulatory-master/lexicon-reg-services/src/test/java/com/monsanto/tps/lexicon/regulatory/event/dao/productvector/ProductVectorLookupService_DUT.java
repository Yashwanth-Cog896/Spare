package com.monsanto.tps.lexicon.regulatory.event.dao.productvector;

import com.monsanto.tps.compliance.referencedata.services.ProductVectorLookupService;
import com.monsanto.tps.lexicon.regulatory.util.service.test.MonsantoCxfServiceProvider;
import org.junit.Ignore;
import org.junit.Test;

/**
 * nbwald - Jun 15, 2009 3:52:05 PM
 */
public class ProductVectorLookupService_DUT
{

   @Ignore
   @Test
 public void testFCMService_FindProductVectorsByCropIdAndConstructNameForSingleConstructs_IsWorking()
      throws Exception
   {
      ProductVectorLookupService service = MonsantoCxfServiceProvider.getService("FCM_ProductVectorLookup", ProductVectorLookupService.class);
      service.findProductVectorsByCropIdAndConstructNameForSingleConstructs(-1, "someconstructname");
   }
}
