/*
 IDGenerator was created on Nov 20, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tps.lexicon.regulatory.DB.Lexicon.Tests.fluentmodel;

import java.util.Random;

/**
 * 
 * nbwald Nov 20, 2007 5:04:28 PM
 */
public class TestIDGenerator
{

   private static long id = -Math.abs(new Random().nextLong());
   public long generateId() {
      return id-- ;
   }
}