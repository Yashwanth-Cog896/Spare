package com.monsanto.tps.lexicon.regulatory.nonmonevent.service;

import com.monsanto.tps.lexicon.nonmonevent.*;
import org.apache.commons.lang.ArrayUtils;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: gdleon
 * Date: May 6, 2009
 * Time: 1:34:21 PM
 */
public class NonMonEventService_AT {
    private NonMonEventService service;

    @Before
    public void setUp() {
        String configLocation = "/com/monsanto/tps/lexicon/regulatory/nonmonevent/service/nonmonevent-service-test-client.xml";
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(configLocation);
        service = (NonMonEventService) context.getBean("nonMonEventService");
    }

    @Test
    public void testReturnsNonMonEventsForValidCrop() {
        NonMonEvent[] results = service.findByCrop("1015");

        assertTrue(results.length > 0);
        for (NonMonEvent nonMonEvent : results) {
            assertTrue(nonMonEvent.isActive());
        }
    }

    @Test
    public void testReturnsNonMonEventsForValidNonMonEvent() {
        NonMonEvent[] results = service.findByNonMonEvent("DAS59122-7");

        assertTrue(results.length > 0);
        for (NonMonEvent nonMonEvent : results) {
            assertTrue(nonMonEvent.isActive());
        }
    }

    @Test
    public void testReturnsNonMonEventsForValidCropAndNonMonEvent() {
        NonMonEvent[] results = service.findByNonMonEventAndCrop("DAS59122-7", "1015");

        assertTrue(results.length > 0);
        for (NonMonEvent nonMonEvent : results) {
            assertTrue(nonMonEvent.isActive());
        }
    }

    @Test
    public void testReturnsAllNonMonEvents() {
        NonMonEvent[] results = service.findAll();
        assertFalse(ArrayUtils.isEmpty(results));
        assertTrue(results.length > 0);
    }

    @Test
    public void testSave()
            throws Exception {
        NonMonEventPersistBatchRequest batchRequest = new NonMonEventPersistBatchRequest();
        batchRequest.setRequests(new NonMonEventPersistRequest());
        batchRequest.setValidateOnly(true);
        NonMonEventPersistResponse[] responses = service.save(batchRequest);

        assertThat(responses.length, is(1));
    }

    @Test
    public void testUpdate()
            throws Exception {
        NonMonEventPersistBatchRequest batchRequest = new NonMonEventPersistBatchRequest();
        NonMonEventPersistRequest request = new NonMonEventPersistRequest();
        request.setEventName("ZZZ");
        request.setCropPubkey("1015");
        batchRequest.setRequests(request);
        batchRequest.setValidateOnly(true);
        NonMonEventPersistResponse[] responses = service.update(batchRequest);

        assertThat(responses.length, is(1));
    }
}