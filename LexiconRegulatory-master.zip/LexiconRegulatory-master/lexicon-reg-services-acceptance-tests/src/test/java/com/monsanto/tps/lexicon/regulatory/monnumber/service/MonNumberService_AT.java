package com.monsanto.tps.lexicon.regulatory.monnumber.service;

import com.monsanto.tps.lexicon.commercialtrait.ComlTraitType;
import com.monsanto.tps.lexicon.monnumber.*;
import org.apache.commons.lang.ArrayUtils;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: gdleon
 * Date: Apr 22, 2009
 * Time: 2:32:56 PM
 * To change this template use File | Settings | File Templates.
 */
public class MonNumberService_AT {
    private MonNumberService monNumberService;

    @Before
    public void setUp() {
        String configLocation = "/com/monsanto/tps/lexicon/regulatory/monnumber/service/monnumber-service-test-client.xml";
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(configLocation);
        monNumberService = (MonNumberService) context.getBean("monNumberService");
    }

    @Ignore @Test
    public void testReturnsMonNumbersForValidCrop() {
        MonNumber[] results = monNumberService.findByCrop("1015");

        assertTrue(results.length > 0);
        for (MonNumber monNumber : results) {
            assertEquals(true, monNumber.isActiveStatus());
        }
    }

    @Ignore @Test
    public void testReturnsMonNumbersForValidMonNumber() {
        MonNumber[] results = monNumberService.findByMonNumber("MON 89201");

        assertTrue(results.length > 0);
        for (MonNumber monNumber : results) {
            assertEquals(true, monNumber.isActiveStatus());
        }
    }

    @Ignore @Test
    public void testReturnsMonNumbersForValidMonNumberAndCrop() {
        MonNumber[] results = monNumberService.findByMonNumberAndCrop("MON 89201", "1015");

        assertTrue(results.length > 0);
        for (MonNumber monNumber : results) {
            assertEquals(true, monNumber.isActiveStatus());
        }
    }

    @Ignore @Test
    public void testReturnsMonNumbersForValidConstruct() {
        MonNumber[] results = monNumberService.findByConstruct(new String[]{"pMON38850"});

        assertTrue(results.length > 0);
        for (MonNumber monNumber : results) {
            assertEquals(true, monNumber.isActiveStatus());
        }
    }

    @Ignore @Test
    public void testReturnsMonNumbersForValidPvCode() {
        MonNumber[] results = monNumberService.findByPvCode(new String[]{"PV-ZMIR245"});

        assertTrue(results.length > 0);
        for (MonNumber monNumber : results) {
            assertEquals(true, monNumber.isActiveStatus());
        }
    }

    @Ignore @Test
    public void testReturnsAllMonNumbers() {
        MonNumber[] results = monNumberService.findAll();
        assertFalse(ArrayUtils.isEmpty(results));
    }

    @Ignore @Test
    public void saveMonNumber_HasErrors()
            throws Exception {
        MonNumberSaveBatchRequest monNumberSaveBatchRequest = new MonNumberSaveBatchRequest();
        MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
        monNumberSaveBatchRequest.setMonNumberSaveRequests(new MonNumberSaveRequest[]{monNumberSaveRequest});
        MonNumberSaveResponse[] responses = monNumberService.save(monNumberSaveBatchRequest);
        assertFalse(ArrayUtils.isEmpty(responses));
        assertEquals(1, responses.length);
        MonNumberSaveResponse response = responses[0];
        assertFalse(response.isSuccess());
        assertTrue(ArrayUtils.isEmpty(response.getEventConstructs()));
        assertFalse(ArrayUtils.isEmpty(response.getMessages()));
    }

    @Test
    @Ignore
    public void saveMonNumber_PassesAllValidations_ValidateOnlyTrue()
            throws Exception {
        MonNumberSaveBatchRequest monNumberSaveBatchRequest = new MonNumberSaveBatchRequest();
        MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
        monNumberSaveRequest.setMonNumber(getRandomMonNumber());
        monNumberSaveRequest.setCropPubkey("1015");
        monNumberSaveRequest.setMaterialName("materialName");
        //donot assign construct info
        monNumberSaveRequest.setTraitTypeAbbreviations(new String[]{"abbr"});
        monNumberSaveRequest.setTraitNameAbbreviations(new String[]{"traitNameAbbr"});
        monNumberSaveRequest.setRegulatoryGenesPresent("genes present");
        monNumberSaveRequest.setRegulatoryParentalLine("regulatory parental line");
        monNumberSaveRequest.setProteinNamePubkeys(new String[]{"1144"});
        monNumberSaveRequest.setOecdNumber("OECD122");
        //monNumberSaveRequest.setOecdNumberCommunicationDate(new Date());
        monNumberSaveRequest.setJvNumber("JV122");
        monNumberSaveRequest.setRegulatedStatus(true);
        monNumberSaveRequest.setLocked(true);
        monNumberSaveRequest.setActiveStatus(true);
        monNumberSaveRequest.setAuditComment("AC");
        monNumberSaveRequest.setAuditRequestor("AR");
        monNumberSaveBatchRequest.setMonNumberSaveRequests(new MonNumberSaveRequest[]{monNumberSaveRequest});
        monNumberSaveBatchRequest.setValidateOnly(true);
        MonNumberSaveResponse[] responses = monNumberService.save(monNumberSaveBatchRequest);
        assertFalse(ArrayUtils.isEmpty(responses));
        assertEquals(1, responses.length);
        MonNumberSaveResponse response = responses[0];
        assertTrue(response.isSuccess());
        assertTrue(ArrayUtils.isEmpty(response.getMessages()));
    }


    @Test
    @Ignore("run only in local for testing true commit")
    public void saveMonNumber_CommitTrue()
            throws Exception {
        MonNumberSaveBatchRequest monNumberSaveBatchRequest = new MonNumberSaveBatchRequest();
        MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
        monNumberSaveRequest.setMonNumber(getRandomMonNumber());
        monNumberSaveRequest.setCropPubkey("1015");
        monNumberSaveRequest.setTraitTypeAbbreviations(new String[]{"DROUGHT"});
        monNumberSaveRequest.setTraitNameAbbreviations(new String[]{"CONV"});
        monNumberSaveRequest.setRegulatoryGenesPresent("genes present");
        monNumberSaveRequest.setRegulatoryParentalLine("regulatory parental line");
        monNumberSaveRequest.setProteinNamePubkeys(new String[]{"2700"});
        monNumberSaveRequest.setActiveStatus(true);
        monNumberSaveRequest.setAuditComment("AC");
        monNumberSaveRequest.setAuditRequestor("AR");
        monNumberSaveBatchRequest.setMonNumberSaveRequests(new MonNumberSaveRequest[]{monNumberSaveRequest});
        MonNumberSaveResponse[] responses = monNumberService.save(monNumberSaveBatchRequest);
        assertFalse(ArrayUtils.isEmpty(responses));
        assertEquals(1, responses.length);
        MonNumberSaveResponse response = responses[0];
        assertTrue(response.isSuccess());
        assertTrue(ArrayUtils.isEmpty(response.getMessages()));
        MonNumber[] monNumbers = monNumberService.findByCrop("1015");
        MonNumber monNumber = findMyMonNumber(monNumberSaveRequest.getMonNumber(), monNumbers);
        assertNotNull(monNumber);
        assertFalse(monNumber.getProteinNames().isEmpty());
        ProteinName proteinName = monNumber.getProteinNames().iterator().next();
        assertEquals("2700", proteinName.getProteinNamePubkey());
        assertFalse(monNumber.getComlTraitTypes().isEmpty());
        ComlTraitType comlTraitType = monNumber.getComlTraitTypes().iterator().next();
        assertEquals("DROUGHT", comlTraitType.getComlTraitTypeAbbr());
    }

    @Test
    @Ignore("run only in local for testing true update")
    public void updateMonNumber_CommitTrue()
            throws Exception {
        MonNumber[] results = monNumberService.findByMonNumber("MON 89201");
        assertFalse(ArrayUtils.isEmpty(results));
        MonNumber monNumber = results[0];
        MonNumberSaveBatchRequest monNumberSaveBatchRequest = new MonNumberSaveBatchRequest();
        MonNumberSaveRequest monNumberSaveRequest = new MonNumberSaveRequest();
        monNumberSaveRequest.setMonNumber(monNumber.getMonNumber());
        monNumberSaveRequest.setCropPubkey("1015");
        monNumberSaveRequest.setTraitTypeAbbreviations(new String[]{"DROUGHT"});
        monNumberSaveRequest.setTraitNameAbbreviations(new String[]{"CONV"});
        monNumberSaveRequest.setRegulatoryGenesPresent("genes present");
        monNumberSaveRequest.setRegulatoryParentalLine("regulatory parental line");
        monNumberSaveRequest.setProteinNamePubkeys(new String[]{"2700"});
        monNumberSaveRequest.setActiveStatus(true);
        monNumberSaveRequest.setAuditComment("AC");
        monNumberSaveRequest.setAuditRequestor("AR");
        //monNumberSaveRequest.setEvent("ZM_M1152");
        monNumberSaveBatchRequest.setMonNumberSaveRequests(new MonNumberSaveRequest[]{monNumberSaveRequest});
        MonNumberSaveResponse[] responses = monNumberService.update(monNumberSaveBatchRequest);
        assertFalse(ArrayUtils.isEmpty(responses));
        assertEquals(1, responses.length);
        MonNumberSaveResponse response = responses[0];
        assertTrue(response.isSuccess());
        assertTrue(ArrayUtils.isEmpty(response.getMessages()));
        MonNumber[] updatedResults = monNumberService.findByMonNumber("MON 89201");
        assertFalse(ArrayUtils.isEmpty(updatedResults));
        MonNumber monNumberUpdated = updatedResults[0];
        assertNotNull(monNumberUpdated);
        assertFalse(monNumberUpdated.getProteinNames().isEmpty());
        ProteinName proteinName = monNumberUpdated.getProteinNames().iterator().next();
        assertEquals("2700", proteinName.getProteinNamePubkey());
        assertFalse(null == monNumberUpdated.getComlTraitTypes());
        ComlTraitType comlTraitType = monNumberUpdated.getComlTraitTypes().iterator().next();
        assertEquals("DROUGHT", comlTraitType.getComlTraitTypeAbbr());
    }

    private MonNumber findMyMonNumber(String monNumber, MonNumber[] monNumbers) {
        for (MonNumber number : monNumbers) {
            if (monNumber.equalsIgnoreCase(number.getMonNumber())) {
                return number;
            }
        }
        return null;
    }

    private String getRandomMonNumber() {
        StringBuilder monNumber = new StringBuilder();
        monNumber.append("MON");
        monNumber.append(" ");
        monNumber.append(String.valueOf(new Double(Math.random() * 100000).intValue()));
        return monNumber.toString();
    }
}