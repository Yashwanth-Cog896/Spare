package com.monsanto.tps.lexicon.regulatory.event.service;

import com.monsanto.tps.lexicon.event.EventDeregulationStatus;
import com.monsanto.tps.lexicon.event.EventDeregulationStatusWithMonNumber;
import com.monsanto.tps.lexicon.event.EventInfo;
import com.monsanto.tps.lexicon.event.EventSearchService;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import static junit.framework.Assert.assertEquals;
import static org.hamcrest.core.Is.is;
import static org.hamcrest.core.IsNot.not;
import static org.hamcrest.core.IsNull.nullValue;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;

/**
 * rrchak1 - Dec 23, 2008 10:37:46 AM
 */
public class EventSearchService_AT {
    private EventSearchService eventSearchService;

    @Before
    public void setUp() {
        String configLocation = "/com/monsanto/tps/lexicon/regulatory/event/service/event-service-test-client.xml";
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(configLocation);
        eventSearchService = (EventSearchService) context.getBean("eventSearchService");
    }

    @Ignore
    @Test
    public void testGivenEventAndCropReturnsEventInfo()
            throws Exception {
        EventInfo eventInfo = eventSearchService.findByEventAndCrop("ZM_M1147", "Corn");

        assertThat(eventInfo, is(not(nullValue())));
    }

    @Ignore
    @Test
    public void testGivenEventsAndCropReturnsEventInfo()
            throws Exception {
        EventInfo[] eventInfos = eventSearchService.findByEventsAndCrop(new String[]{"ZM_M1146", "ZM_M1147"}, "Corn");

        assertThat(eventInfos.length, is(2));
    }

    @Test
    public void testGivenEventsAndCropReturnsEventInfo_EmptyEventsArray()
            throws Exception {
        EventInfo[] eventInfos = eventSearchService.findByEventsAndCrop(new String[0], "Corn");

        assertThat(eventInfos, is(nullValue()));
    }

    @Ignore
    @Test
    public void testGivenMonNumberReturnsEventInfo()
            throws Exception {
        EventInfo eventInfo = eventSearchService.findByMonNumber("MON 00115");

        assertThat(eventInfo, is(not(nullValue())));
    }

    @Ignore
    @Test
    public void testGivenEventAgencyAlignmentPubkeyReturnEventInfo()
            throws Exception {
        EventInfo[] eventInfo = eventSearchService.findByEventAgencyAlignmentPubkey(new String[]{"135"});

        assertEquals(1, eventInfo.length);
    }

    @Test
    public void testGivenEventAgencyAlignmentPubkeyReturnEventInfo_EmptyPubkeyArray()
            throws Exception {
        EventInfo[] eventInfo = eventSearchService.findByEventAgencyAlignmentPubkey(new String[0]);

        assertThat(eventInfo, is(nullValue()));
    }

    @Ignore
    @Test
    public void testGivenAgencyAbbrReturnsEventInfo()
            throws Exception {
        EventInfo[] eventInfo = eventSearchService.findByAgencyAbbr(new String[]{"USDA"});

        assertEquals(1, eventInfo.length);
    }

    @Test
    public void testGivenAgencyAbbrReturnsEventInfo_EmptyAgencyAbbr()
            throws Exception {
        EventInfo[] eventInfo = eventSearchService.findByAgencyAbbr(new String[0]);

        assertThat(eventInfo, is(nullValue()));
    }

    @Ignore
    @Test
    public void testGetEventDeregulationStatus()
            throws Exception {
        EventDeregulationStatus[] eventDeregulationStatuses = eventSearchService.getEventDeregulationStatus(new String[]{"ZM_M1147"}, "Corn", new String[]{"USDA"});

        assertThat(eventDeregulationStatuses.length, is(1));
    }

    @Test
    public void testGetEventDeregulationStatus_EmptyEventArray()
            throws Exception {
        EventDeregulationStatus[] eventDeregulationStatuses = eventSearchService.getEventDeregulationStatus(new String[0], "Corn", new String[]{"USDA"});

        assertThat(eventDeregulationStatuses, is(nullValue()));
    }

    @Test
    public void testGetEventDeregulationStatus_EmptyAgencyArray()
            throws Exception {
        EventDeregulationStatus[] eventDeregulationStatuses = eventSearchService.getEventDeregulationStatus(new String[]{"ZM_M1147"}, "Corn", new String[0]);

        assertThat(eventDeregulationStatuses, is(nullValue()));
    }


    @Ignore("AT referencing instance data that doesn't exist anymore")
    @Test
    public void testGetEventDeregulationStatusWithMonNumber()
            throws Exception {
        EventDeregulationStatusWithMonNumber[] eventDeregulationStatuses = eventSearchService.getEventDeregulationStatusWithMonNumber(new String[]{"ZM_M335163"}, "Corn", new String[]{"USDA"});

        assertThat(eventDeregulationStatuses.length, is(1));
        assertEquals("MON 66666", eventDeregulationStatuses[0].getMonNumber());
    }

    @Test
    public void testGetEventDeregulationStatusWithMonNumber_ExistingMonNumberNoEventAgency()
            throws Exception {
        EventDeregulationStatusWithMonNumber[] eventDeregulationStatuses = eventSearchService.getEventDeregulationStatusWithMonNumber(new String[]{"LAP141"}, "Corn", new String[]{"USDA"});

        assertThat(eventDeregulationStatuses.length, is(1));
        assertEquals("MON 89597", eventDeregulationStatuses[0].getMonNumber());
        assertNull(eventDeregulationStatuses[0].getEventAgencies());
    }

    @Ignore("AT referencing instance data that doesn't exist anymore")
    @Test
    public void testGetEventDeregulationStatusWithMonNumber_EmptyMonNumber()
            throws Exception {
        EventDeregulationStatusWithMonNumber[] eventDeregulationStatuses = eventSearchService.getEventDeregulationStatusWithMonNumber(new String[]{"ZM_M229190"}, "Corn", new String[]{"USDA"});

        assertThat(eventDeregulationStatuses.length, is(1));
        assertNull(eventDeregulationStatuses[0].getMonNumber());
    }

    @Test
    public void testGetEventDeregulationStatusWithMonNumber_EmptyEventArray()
            throws Exception {
        EventDeregulationStatusWithMonNumber[] eventDeregulationStatuses = eventSearchService.getEventDeregulationStatusWithMonNumber(new String[0], "Corn", new String[]{"USDA"});

        assertThat(eventDeregulationStatuses, is(nullValue()));
    }

    @Test
    public void testGetEventDeregulationStatusWithMonNumber_EmptyAgencyArray()
            throws Exception {
        EventDeregulationStatusWithMonNumber[] eventDeregulationStatuses = eventSearchService.getEventDeregulationStatusWithMonNumber(new String[]{"ZM_M1147"}, "Corn", new String[0]);

        assertThat(eventDeregulationStatuses, is(nullValue()));
    }
}
   

