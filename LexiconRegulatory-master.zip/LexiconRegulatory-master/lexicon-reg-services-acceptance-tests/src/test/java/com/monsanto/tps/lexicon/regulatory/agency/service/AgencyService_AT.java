package com.monsanto.tps.lexicon.regulatory.agency.service;

import com.monsanto.tps.lexicon.agency.Agency;
import com.monsanto.tps.lexicon.agency.AgencySearchCriteria;
import com.monsanto.tps.lexicon.agency.AgencyService;
import junit.framework.TestCase;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * rrchak1 - Oct 9, 2008 2:34:26 PM
 */
public class AgencyService_AT
   extends TestCase
{
   public void testReturnsAgencyForValidAgencyAcronym()
      throws Exception
   {
      String configLocation = "/com/monsanto/tps/lexicon/regulatory/agency/service/agency-service-test-client.xml";
      ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(configLocation);
      AgencyService agencyService = (AgencyService) context.getBean("agencyService");

      AgencySearchCriteria agencySearchCriteria = new AgencySearchCriteria();
      agencySearchCriteria.setAgencyAbbr(new String[]{"USDA"});
      Agency[] results = agencyService.findBySearchCriteria(agencySearchCriteria);

      assertEquals(1, results.length);
   }
}
