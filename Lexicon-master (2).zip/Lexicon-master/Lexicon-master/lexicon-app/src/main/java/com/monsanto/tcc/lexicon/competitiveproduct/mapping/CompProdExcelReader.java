package com.monsanto.tcc.lexicon.competitiveproduct.mapping;

import com.monsanto.tcc.lexicon.templates.reader.ExcelGridReader;

import java.io.IOException;
import java.io.InputStream;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Mar 29, 2005
 * Time: 11:02:58 AM
 * To change this template use File | Settings | File Templates.
 */
public class CompProdExcelReader
   extends ExcelGridReader
   implements CompProdGridReader,
              ICompProdColDefs
{
   public CompProdExcelReader(InputStream in)
      throws IOException
   {
      super(in);
   }
   
   protected String[] getTemplateColumns() {
      return TEMPLATE_COLUMNS;
   }

   public boolean isElementRequired(int colIdx) {
      return ELEMENT_REQUIRED[colIdx];
   }

   public String getPublicKey(int iRowNum) {
      return "";
   }
   public String getProductPublicKey(int iRowNum) {
      return "";
   }
}
