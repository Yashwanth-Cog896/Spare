/*
 BaseProductTemplate was created on Oct 2, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.model;

import com.monsanto.tcc.lexicon.baseproduct.excel.BaseProductTemplateRow;
import com.monsanto.tcc.lexicon.baseproduct.queryset.query.ManufacturingFamiliesByBaseNamesQuery;
import com.monsanto.tcc.lexiconcommon.file.excel.ExcelRow;
import com.monsanto.tcc.lexiconcommon.file.excel.ExcelSheet;
import com.monsanto.tcc.lexiconcommon.service.manufacturingfamily.search.model.ManufacturingFamily;
import java.util.ArrayList;
import java.util.List;

/**
 * nbwald Oct 2, 2007 2:42:55 PM
 */
public class BaseProductTemplateParser
{
   private final ExcelRow[] dataRows;
   private final ManufacturingFamiliesByBaseNamesQuery manfFamilyQuery;

   public BaseProductTemplateParser(ExcelSheet excelSheet, ManufacturingFamiliesByBaseNamesQuery manfFamilyQuery) {
      this.dataRows = excelSheet.getData();
      this.manfFamilyQuery = manfFamilyQuery;
   }

   public BaseProductPageBean getBaseProductPageBean() {
      BaseProductPageBean bean = createBeanFromExistingData();
      addNewBaseProducts(bean);
      return bean;
   }

   private void addNewBaseProducts(BaseProductPageBean bean) {
      for (ExcelRow row : dataRows) {
         BaseProductTemplateRow templateRow = new BaseProductTemplateRow(row);
         bean.createBaseProduct(templateRow);
      }
   }

   private BaseProductPageBean createBeanFromExistingData() {
      String[] baseManfNames = getBaseManufacturingNames();
      ManufacturingFamily[] families = manfFamilyQuery.getManufacturingFamilies(baseManfNames);
      return new BaseProductPageBean(families);
   }

   private String[] getBaseManufacturingNames() {
      List<String> baseManufacturingNames = new ArrayList<String>();
      for (ExcelRow row : dataRows) {
         baseManufacturingNames.add(new BaseProductTemplateRow(row).getBaseManufacturingName());
      }
      return baseManufacturingNames.toArray(new String[baseManufacturingNames.size()]);
   }
}