package com.monsanto.tcc.lexicon.competitiveproduct;

import com.monsanto.tcc.lexicon.typedata.trait.TraitStackDTO;
import com.monsanto.tcc.lexiconcommon.validation.validator.PreconditionedRule;

/**
 * nbwald - Oct 13, 2009 4:11:38 PM
 */
public class CompProdTraitsMayNotBePrecommercialRule
   extends PreconditionedRule<String>
{
   private final TraitStackDTO traitStack;

   public CompProdTraitsMayNotBePrecommercialRule(TraitStackDTO traitStack) {
      this.traitStack = traitStack;
   }

   @Override
   public boolean preconditionsMet() {
      return traitStack != null;
   }

   @Override
   public boolean postconditionViolated() {
      return traitStack.isPrecommercial();
   }

   @Override
   public String getViolation() {
      return "Traits may not be precommercial.";
   }
}
