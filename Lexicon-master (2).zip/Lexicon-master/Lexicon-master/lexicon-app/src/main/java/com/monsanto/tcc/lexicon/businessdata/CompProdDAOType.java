package com.monsanto.tcc.lexicon.businessdata;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Feb 15, 2005
 * Time: 12:53:33 PM
 * To change this template use File | Settings | File Templates.
 */
public interface CompProdDAOType {
   public static final int ORACLE_DAO      = 1;
   public static final int MOCK_ORACLE_DAO = 2;
}
