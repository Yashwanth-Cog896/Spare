package com.monsanto.tcc.lexicon.businessdata;

import com.monsanto.tcc.lexicon.typedata.bayer.BayerDAO;
import com.monsanto.tcc.lexicon.typedata.bayer.BayerDTO;
import com.monsanto.tcc.lexicon.typedata.brand.BrandDAO;
import com.monsanto.tcc.lexicon.typedata.brand.BrandDTO;
import com.monsanto.tcc.lexicon.typedata.country.CountryDAO;
import com.monsanto.tcc.lexicon.typedata.country.CountryDTO;
import com.monsanto.tcc.lexicon.typedata.trait.TraitStackDAO;
import com.monsanto.tcc.lexicon.typedata.trait.TraitStackDTO;
import com.monsanto.tcc.lexicon.utils.db.LexiconConnectionHelper;
import com.monsanto.tcc.lexicon.utils.db.dao.SequenceGrabber;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.dataservices.EmptyResultSetException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.dataservices.PersistentStoreResultSetSingleResult;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.dbdataservices.SQLUtil;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: adcox
 * Date: Oct 25, 2004
 * Time: 2:24:05 PM
 */
public class OraCompProdDAO
   extends CompProdDAO
{
   private TraitStackDAO traitStackDao;

   public OraCompProdDAO() {
      this(TraitStackDAO.newInstance());
   }

   public OraCompProdDAO(TraitStackDAO traitStackDao) {
      this.traitStackDao = traitStackDao;
   }

   public String newPublicKey(
      PersistentStoreConnection conn)
      throws WrappingException
   {
      return Integer.toString(new SequenceGrabber(CompProdSQL.NAME_PUBKEY_SEQ).getNextID(conn));
   }

   public String newProductPublicKey(
      PersistentStoreConnection conn)
      throws WrappingException
   {
      return Integer.toString(new SequenceGrabber(CompProdSQL.PROD_PUBKEY_SEQ).getNextID(conn));
   }

   public int newProductId(
      PersistentStoreConnection conn)
      throws WrappingException
   {
      return new SequenceGrabber(CompProdSQL.PROD_ID_SEQ).getNextID(conn);
   }

   public int newProdNameId(
      PersistentStoreConnection conn)
      throws WrappingException
   {
      return new SequenceGrabber(CompProdSQL.NAME_ID_SEQ).getNextID(conn);
   }


   public CompProdDTO loadByProdNamePubkey(
      PersistentStoreConnection conn,
      String publicKey)
      throws WrappingException,
             EmptyResultSetException
   {
      String sql = getSQL(CompProdSQL.CP_SELECT_BY_PUBKEY);
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, publicKey);
         PersistentStoreResultSetSingleResult rs = stmt.executeQuery().getSingleResult();
         return createDTO(rs);
      }
      catch (EmptyResultSetException e) {
         throw new EmptyResultSetException("public key not found: " + publicKey);
      }
      finally {
         LexiconConnectionHelper.closeStatement(stmt, _log);
      }
   }

   public List loadByProductPubkey(
      PersistentStoreConnection conn,
      String publicKey)
      throws WrappingException
   {
      String sql = getSQL(CompProdSQL.CP_SELECT_BY_PROD_PUBKEY);
      List listProd = new ArrayList();
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, publicKey);
         PersistentStoreResultSetFwdIterator iter = stmt.executeQuery().getForwardIterator();
         while (iter.next()) {
            listProd.add(createDTO(iter));
         }
         return listProd;
      }
      finally {
         LexiconConnectionHelper.closeStatement(stmt);
      }
   }

   public CompProdDTO loadByMatchingAK(
      PersistentStoreConnection conn,
      String productName,
      String bayerCode,
      String brandName,
      String countryName)
      throws WrappingException
   {
      String sql = getSQL(CompProdSQL.CP_SELECT_BY_ALTKEYS);
      PersistentStoreStatement stmt = conn.prepareStatement(sql);

      try {
         stmt.setParam(1, productName);
         stmt.setParam(2, bayerCode);
         stmt.setParam(3, brandName);
         stmt.setParam(4, countryName);

         PersistentStoreResultSetSingleResult rs = stmt.executeQuery().getSingleResult();
         return createDTO(rs);
      }
      catch (EmptyResultSetException e) {
         return null;
      }
      finally {
         LexiconConnectionHelper.closeStatement(stmt, _log);
      }
   }

   public List loadByProductLevel(
      PersistentStoreConnection conn,
      String productName,
      String bayerCode,
      String brandPubkey)
      throws WrappingException
   {
      List list = new ArrayList();
      String sql = getSQL(CompProdSQL.CP_SELECT_BY_NAME_CROP_BRAND);
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, productName);
         stmt.setParam(2, bayerCode);
         stmt.setParam(3, brandPubkey);

         PersistentStoreResultSetFwdIterator iter = stmt.executeQuery().getForwardIterator();
         while (iter.next()) {
            list.add(createDTO(iter));
         }
         return list;
      }
      finally {
         LexiconConnectionHelper.closeStatement(stmt, _log);
      }
   }

   public CompProdDTO createDTO(
      PersistentStoreResultSetRow rs)
      throws WrappingException
   {
      CompProdDTOImpl compProd = new CompProdDTOImpl();

      compProd.setPublicKey(rs.getString(NAME_PUBKEY_ALIAS));
      compProd.setProductPublicKey(rs.getString(PROD_PUBKEY_ALIAS));
      compProd.setProductName(rs.getString(PROD_NAME_ALIAS));
      compProd.setBayerCode(rs.getString(BAYER_CODE_ALIAS));
      compProd.setCountryName(rs.getString(CNTRY_NAME_ALIAS));
      compProd.setBrandName(rs.getString(BRAND_NAME_ALIAS));
      compProd.setCommercialMaturity(rs.getString(COM_MAT_ALIAS));
      compProd.setSourceVerified(rs.getString(DS_VERIFY_ALIAS));
      compProd.setSourceYear(rs.getString(DS_YEAR_ALIAS));
      compProd.setComments(rs.getString(COMMENTS_ALIAS));
      compProd.setActive(SQLUtil.stringToBoolean(rs.getString(IS_ACTIVE_ALIAS)));
      compProd.setLogicalDelete(SQLUtil.stringToBoolean(rs.getString(LOGICAL_DELETE_ALIAS)));
      compProd.setCharacteristicTraits(rs.getString(STACK_RPTG_NAME_ALIAS));
      return compProd;
   }

   public void save(
      PersistentStoreConnection conn,
      CompProdDTO compProd)
      throws WrappingException
   {
      if (isNewProductName(conn, compProd)) {
         insert(conn, compProd);
      }
      else {
         update(conn, compProd);
      }
   }

   private void insert(
      PersistentStoreConnection conn,
      CompProdDTO compProd)
      throws WrappingException
   {
      String key = compProd.getProductPublicKey();
      int iProductId = prodIdFromPublicKey(conn, key);
      int iNameId = newProdNameId(conn);

      if (iProductId == -1) {
         iProductId = newProductId(conn);
         insertProduct(conn, compProd, iProductId);
      }
      insertProductName(conn, compProd, iProductId, iNameId);
   }
   
   private void insertProduct(
      PersistentStoreConnection conn,
      CompProdDTO compProd,
      int iProductId)
      throws WrappingException
   {
      String sql = getSQL(CompProdSQL.CP_INSERT_PROD);
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, iProductId);
         stmt.setParam(2, compProd.getProductPublicKey());
         stmt.setParam(3, getBayer(conn, compProd).getId());
         stmt.executeInsert();
      }
      finally {
         LexiconConnectionHelper.closeStatement(stmt);
      }
   }

   private void insertProductName(
      PersistentStoreConnection conn,
      CompProdDTO compProd,
      int iProductId,
      int iNameId)
      throws WrappingException
   {
      String sql = getSQL(CompProdSQL.CP_INSERT_NAME);
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, iNameId);
         stmt.setParam(2, compProd.getPublicKey());
         stmt.setParam(3, iProductId);
         stmt.setParam(4, compProd.getProductName());
         stmt.setParam(5, getCountry(conn, compProd).getId());
         stmt.setParam(6, getBrand(conn, compProd).getId());
         stmt.setParam(7, compProd.getCommercialMaturity());
         stmt.setParam(8, compProd.getSourceVerified());
         stmt.setParam(9, compProd.getSourceYear());
         //stmt.setParam(10, compProd.getRequestor());
         stmt.setParam(10, compProd.getComments());
         stmt.setParam(11, SQLUtil.booleanToString(compProd.isActive()));
         stmt.setParam(12, getTraitStackId(conn, compProd));
         stmt.executeInsert();
      }
      finally {
         LexiconConnectionHelper.closeStatement(stmt, _log);
      }
   }


   private void update(
      PersistentStoreConnection conn,
      CompProdDTO compProd)
      throws WrappingException
   {
      int iProductId = prodIdFromPublicKey(conn, compProd.getProductPublicKey());
      int iNameId = nameIdFromPublicKey(conn, compProd.getPublicKey());

		// Make Certain our product level is not logically deleted
      setProductToUndeleted(conn, compProd.getProductPublicKey());
      updateProductName(conn, compProd, iProductId, iNameId);
   }
	
	private void setProductToUndeleted(
		PersistentStoreConnection conn,
		String  productPublicKey)
		throws WrappingException
	{
		String sql = getSQL(CompProdSQL.CP_SET_PRODUCT_LEVEL_UNDELETED);
		PersistentStoreStatement stmt = conn.prepareStatement(sql);
		try {
			stmt.setParam(1, productPublicKey);
			stmt.executeUpdate();
		}
		finally {
         LexiconConnectionHelper.closeStatement(stmt, _log);
      }
	}

   private void updateProductName(
      PersistentStoreConnection conn,
      CompProdDTO compProd,
      int iProductId,
      int iNameId)
      throws WrappingException
   {
      String sql = getSQL(CompProdSQL.CP_UPDATE_NAME);
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, iProductId);
         stmt.setParam(2, compProd.getProductName());
         stmt.setParam(3, getCountry(conn, compProd).getId());
         stmt.setParam(4, getBrand(conn, compProd).getId());
         stmt.setParam(5, compProd.getCommercialMaturity());
         stmt.setParam(6, compProd.getSourceVerified());
         stmt.setParam(7, compProd.getSourceYear());
         //mt.setParam(7, compProd.getRequestor());
         stmt.setParam(8, compProd.getComments());
         stmt.setParam(9, SQLUtil.booleanToString(compProd.isActive()));
         stmt.setParam(10, getTraitStackId(conn, compProd));
         stmt.setParam(11, iNameId);
         stmt.executeUpdate();
      }
      finally {
         LexiconConnectionHelper.closeStatement(stmt, _log);
      }
   }

   public BrandDTO getBrand(
      PersistentStoreConnection conn,
      CompProdDTO compProd)
      throws WrappingException
   {
      BrandDTO brand = BrandDAO.newInstance().loadByName(conn, compProd.getBrandName());
      if (brand == null) {
         throw new WrappingException(new Exception("Invalid brand name: " + compProd.getBrandName()));
      }
      return brand;
   }

   public CountryDTO getCountry(
      PersistentStoreConnection conn,
      CompProdDTO compProd)
      throws WrappingException
   {
      CountryDTO country = CountryDAO.newInstance().loadByAbbr(conn, compProd.getCountryName());
      if (country == null) {
         country = CountryDAO.newInstance().loadByName(conn, compProd.getCountryName());
         if (country == null) {
            throw new WrappingException(new Exception("Invalid country name: " + compProd.getCountryName()));
         }
      }
      return country;
   }

   public BayerDTO getBayer(
      PersistentStoreConnection conn,
      CompProdDTO compProd)
      throws WrappingException
   {
      BayerDTO bayer = BayerDAO.newInstance().loadByCode(conn, compProd.getBayerCode());
      if (bayer == null) {
         throw new WrappingException(new Exception("Invalid bayer code: " + compProd.getBayerCode()));
      }
      return bayer;
   }
   
   public TraitStackDTO getExistingTraitStack(PersistentStoreConnection conn, CompProdDTO compProd)
      throws WrappingException
   {
      String characteristicTraits = compProd.getCharacteristicTraits();
      if(StringUtils.isNullOrEmpty(characteristicTraits)) {
         return null;
      }
      TraitStackDTO traitStack = getTraitStack(conn, compProd);
      if(traitStack == null) {
         throw new WrappingException(new Exception("Invalid trait stack: " + characteristicTraits + " for the bayer code " + compProd.getBayerCode() + " in " + compProd.getCountryName()));
      }
      return traitStack;
   }

   public TraitStackDTO getTraitStack(PersistentStoreConnection conn, CompProdDTO compProd)
      throws WrappingException
   {
      String characteristicTraits = compProd.getCharacteristicTraits();
      String bayerCode = compProd.getBayerCode();
      TraitStackDTO baseTraitStack = traitStackDao.findBaseStackName(conn, characteristicTraits, bayerCode);
      TraitStackDTO alternateTraitStack = traitStackDao.findAlternateReportingName(conn, characteristicTraits, bayerCode, compProd.getCountryName());
      return preferAlternateTraitStack(baseTraitStack, alternateTraitStack);
   }

   private TraitStackDTO preferAlternateTraitStack(TraitStackDTO baseTraitStack, TraitStackDTO alternateTraitStack) {
      return alternateTraitStack != null ? alternateTraitStack : baseTraitStack;
   }

   private Integer getTraitStackId(PersistentStoreConnection conn, CompProdDTO compProd)
      throws WrappingException
   {
      TraitStackDTO traitStack = getTraitStack(conn, compProd);
      return traitStack == null ? null : new Integer(traitStack.getId());
   }

   private boolean isNewProductName(
      PersistentStoreConnection conn,
      CompProdDTO compProd)
      throws WrappingException
   {
      String key = compProd.getPublicKey();
      return (nameIdFromPublicKey(conn, key) <= 0);
   }
   
   public int nameIdFromPublicKey(
      PersistentStoreConnection conn,
      String key)
      throws WrappingException
   {
      String sql = getSQL(CompProdSQL.CP_NAME_ID_FROM_PUBKEY);
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, key);
         PersistentStoreResultSetSingleResult rs = stmt.executeQuery().getSingleResult();
         return rs.getInt(NAME_ID_ALIAS);
      }
      catch (EmptyResultSetException e) {
         return -1;
      }
      finally {
         stmt.close();
      }
   }

   public int prodIdFromPublicKey(
      PersistentStoreConnection conn,
      String key)
      throws WrappingException
   {
      String sql = getSQL(CompProdSQL.CP_PROD_ID_FROM_PUBKEY);
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, key);
         PersistentStoreResultSetSingleResult rs = stmt.executeQuery().getSingleResult();
         return rs.getInt(PROD_ID_ALIAS);
      }
      catch (EmptyResultSetException e) {
         return -1;
      }
      finally {
         stmt.close();
      }
   }

   private String getSQL(String propName)
      throws WrappingException
   {
      return new SQLPropFile(CompProdSQL.class).getSQL(propName);
   }
}
