package com.monsanto.tcc.lexicon.controllers.model;

/**
 * User: pjberry
 * Date: Jun 18, 2007
 * Time: 9:52:09 AM
 */
public interface PubkeyPagination
{
   public boolean isOnFirstGroup();                   //isFirstPage
   public boolean isOnLastGroup();                    //isLastPage
   public int getPreviousGroupNumber();               // go away
   public int getNextGroupNumber();                   // go away
   public boolean isPopulated();
   public String[] getPubkeyGroup(int groupNumber);   //getNextPage, getPreviousPage
   public String getCurrentGroupStatement();          // getPageDescription
   public String[] getAllPubkeys();
}
