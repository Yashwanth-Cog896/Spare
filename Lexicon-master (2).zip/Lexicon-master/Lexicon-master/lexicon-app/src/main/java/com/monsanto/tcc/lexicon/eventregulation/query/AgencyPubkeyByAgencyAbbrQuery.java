package com.monsanto.tcc.lexicon.eventregulation.query;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.tcc.lexiconcommon.exception.RuntimeWrappingException;

/**
 * nbwald - Feb 10, 2009 9:40:36 PM
 */
public class AgencyPubkeyByAgencyAbbrQuery
   extends AbstractPersistentStoreSingleResultQuery
{
   private String agencyAbbr;

   public AgencyPubkeyByAgencyAbbrQuery(String agencyAbbr) {
      this.agencyAbbr = agencyAbbr;
   }

   public String find() {
      try {
         return (String) execute();
      }
      catch (WrappingException e) {
         throw new RuntimeWrappingException(e);
      }
   }

   @Override
   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return row.getString(1);
   }

   @Override
   protected Object createObjectWhenNoRowsFound()
      throws WrappingException
   {
      throw new AgencyNotFoundException(agencyAbbr);
   }

   @Override
   protected String getSQL()
      throws WrappingException
   {
      return
         "SELECT agency_pubkey " +
         "  FROM Lexicon.Agency " +
         " WHERE agency_abbr = ? ";
   }

   @Override
   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { agencyAbbr };
   }

   @Override
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
}
