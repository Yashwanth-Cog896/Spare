package com.monsanto.tcc.lexicon.competitiveproduct.selectlistgen;

import com.monsanto.tcc.lexicon.typedata.country.CountryDAO;
import com.monsanto.tcc.lexicon.typedata.country.CountryDTO;
import com.monsanto.tcc.lexicon.utils.db.LexiconConnectionHelper;
import com.monsanto.tcc.lexicon.utils.gui.HtmlCell;
import com.monsanto.tcc.lexicon.utils.gui.SelectDisplayValueList;
import com.monsanto.tcc.lexicon.utils.gui.SelectDisplayValuePair;
import com.monsanto.tcc.lexicon.utils.gui.TypeTableListGenerator;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: adcox
 * Date: Jan 11, 2005
 * Time: 11:53:16 AM
 * To change this template use File | Settings | File Templates.
 */
public class CountryGenerator
implements TypeTableListGenerator
{
   public SelectDisplayValueList getSelectList(HtmlCell cell) throws WrappingException {
      SelectDisplayValueList list = new SelectDisplayValueList();
		List Countries = getDTOList();
		for (Iterator iterator = Countries.iterator(); iterator.hasNext();) {
			CountryDTO dto = (CountryDTO) iterator.next();
			String name = dto.getName();
			name = name.substring(0, Math.min(14, name.length()));
			SelectDisplayValuePair pair = new SelectDisplayValuePair(dto.getAbbr() + " (" + name + ")", dto.getAbbr());
			list.add(pair);
		}
		Collections.sort(list);
      return list;
   }

	private List getDTOList() throws WrappingException {
		PersistentStoreConnection conn = null;
		List dtoList = new ArrayList();
      try {
         conn = LexiconConnectionHelper.getDefaultConnection();
         CountryDAO dao = CountryDAO.newInstance();
         dtoList = dao.loadAll(conn);
      }
      finally {
         if (conn != null) {
            conn.close();
         }
      }
		return dtoList;
	}
}
