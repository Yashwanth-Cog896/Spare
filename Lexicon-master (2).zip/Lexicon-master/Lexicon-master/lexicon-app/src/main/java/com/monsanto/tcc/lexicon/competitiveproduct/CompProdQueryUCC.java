package com.monsanto.tcc.lexicon.competitiveproduct;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.tcc.lexicon.LexiconServlet.LexiconUseCaseController;
import com.monsanto.tcc.lexicon.LexiconServlet.beans.ToolBar;
import com.monsanto.tcc.lexicon.applicationroles.AppRoles;
import com.monsanto.tcc.lexicon.competitiveproduct.beans.CompProdQuery;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.RowObjectList;
import com.monsanto.tcc.lexicon.utils.LogWriter;
import com.monsanto.tcc.lexicon.utils.PropertyTool;
import com.monsanto.tcc.lexicon.utils.db.LexiconConnectionHelper;
import org.w3c.dom.Document;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

/**
 * Created by IntelliJ IDEA.
 * User: adcox
 * Date: Oct 12, 2004
 * Time: 1:44:46 PM
 */
public class CompProdQueryUCC
   extends LexiconUseCaseController
{
   // Form input keys
   public static final String CROPS = "crops";
   public static final String COUNTRIES = "countries";
   public static final String BRANDS = "brands";
   public static final String TRAITS = "traits";
   public static final String PRODUCT_NAME = "productNames";
   public static final String TRAIT_AND = "traitAnd";
   public static final String SUBMIT_BTN = "querySubmitBtn";
   private static final String ACTION_FIELD = "actionField";
   public static final String PROD_NAME_PUB_KEY = "prodNamePubKey";
   public static final String ROW_COUNT = "rowCount";

   // Form input expected values
   public static final String RUN = "Run";

   // Session Keys
   private static final String COMP_PROD_QUERY_MAX_ROW_LIMIT = "CompProdQueryMaxRowLimit";
   private static final String COMP_PROD_QUERY_DEFAULT_ROW_LIMIT = "CompProdQueryDefaultRowLimit";

   public static final String SUBMIT_NAME = "submitBtn";
   private static final String TABLE_ID = "edit_competitive_product";

   public void doService(UCCHelper helper)
      throws IOException
   {
      EditCompProdUCC editUcc = new EditCompProdUCC();

      //CompProdQuery bean = editUcc.getSessionBean(helper);
      CompProdQuery bean = new CompProdQuery();
      updateBeanFromRequest(helper, bean);

      StringBuffer sb = new StringBuffer();

      String submitBtn = bean.getSubmitBtn();

      try {
         if (StringUtils.isNullOrEmpty(submitBtn)) {
         }
         else if (submitBtn.equals(RUN)) {
            bean = editUcc.getSessionBean(helper);
            updateBeanFromRequest(helper, bean);

            QueryBuilder qb = buildQueryBuilder(bean);
            RowObjectList list = getRowObjectListFromQueryBuilder(qb);
            bean.setRowObjectList(list);
            bean.setOrigRowObjectList((RowObjectList) list.clone());
            int actualCount = getActualCountFromQueryBuilder(qb);
            if (list.size() == Integer.parseInt(bean.getRowCount())) {
               bean.setRowCountMsg(list.size() + " (of " + actualCount + ") rows retrieved<BR>Refine query or change row count.");
            }
            else if (list.size() == getMaxRowCount()) {
               bean.setRowCountMsg("Maximum of " + list.size() + "(of " + actualCount + ") rows retrieved<BR>Refine query.");
            }
            else {
               bean.setRowCountMsg(list.size() + " row" + (list.size() == 1 ? "" : "s") + " retrieved");
            }
            editUcc.buildGrid(helper, sb);
         }
         else {
            throw new IOException("Unhandled submit value: " + submitBtn);
         }

      }
      catch (WrappingException e) {
         sb.append(e.getMessage());
         LogWriter.logWrappingException(_log, e);
      }
      catch (Exception e) {
         sb.append(e.getMessage());
         _log.error(e.getMessage(), e);
      }
      if (sb.length() > 0) {
         int lastChar = Math.min(100, sb.length());
         bean.setErrorMessage("Error: " + sb.toString().substring(0, lastChar));
      }

      String fwd = getSuccessForward();
      helper.forward(fwd);
   }

   protected RowObjectList getRowObjectListFromQueryBuilder(QueryBuilder qb)
      throws WrappingException, NoSuchMethodException, IllegalAccessException, InvocationTargetException
   {
      PersistentStoreConnection conn = LexiconConnectionHelper.getDefaultConnection();
      try {
         Document doc = qb.getDocument(conn);
         return new RowObjectList(doc);
      }
      finally {
         conn.close();
      }
   }

   protected int getActualCountFromQueryBuilder(
      QueryBuilder qb)
      throws WrappingException
   {
      PersistentStoreConnection conn = LexiconConnectionHelper.getDefaultConnection();
      try {
         return qb.getActualCount(conn);
      }
      finally {
         conn.close();
      }
   }

   private QueryBuilder buildQueryBuilder(CompProdQuery bean) {
      QueryBuilder qb = new QueryBuilder();

      String str = bean.getCrops();
      if (!StringUtils.isNullOrEmpty(str)) {
         qb.addParam(QueryBuilderParameter.BAYER_CODE_NAME, str);
      }

      str = bean.getBrands();
      if (!StringUtils.isNullOrEmpty(str)) {
         qb.addParam(QueryBuilderParameter.BRAND_NAME, str);
      }

      str = bean.getTraits();
      if (!StringUtils.isNullOrEmpty(str)) {
         QueryBuilderParameter param = bean.isTraitAnd() ? QueryBuilderParameter.AND_TRAITS : QueryBuilderParameter.OR_TRAITS;
         qb.addParam(param, str);
      }

      str = bean.getCountries();
      if (!StringUtils.isNullOrEmpty(str)) {
         qb.addParam(QueryBuilderParameter.CNTRY_ABBR, str);
      }

      str = bean.getProductNames();
      if (!StringUtils.isNullOrEmpty(str)) {
         qb.addParam(QueryBuilderParameter.PROD_NAME, str);
      }

      str = bean.getProdNamePubKey();
      if (!StringUtils.isNullOrEmpty(str)) {
         qb.addParam(QueryBuilderParameter.PROD_NAME_PUBLIC_KEY, str);
      }

      qb.setRowLimit(Integer.parseInt(bean.getRowCount()));

      return qb;
   }

   public int getDefaultRowCount()
      throws IOException
   {
      String str = getProperty(COMP_PROD_QUERY_DEFAULT_ROW_LIMIT, true);
      return Integer.parseInt(str);
   }

   public int getMaxRowCount()
      throws IOException
   {
      String str = getProperty(COMP_PROD_QUERY_MAX_ROW_LIMIT, true);
      return Integer.parseInt(str);
   }

   private CompProdQuery updateBeanFromRequest(UCCHelper helper, CompProdQuery bean)
      throws IOException
   {
      bean.setErrorMessage(null);

      bean.setCrops(helper.getRequestParameterValue(CROPS));
      bean.setCountries(helper.getRequestParameterValue(COUNTRIES));
      bean.setBrands(helper.getRequestParameterValue(BRANDS));
      bean.setTraits(helper.getRequestParameterValue(TRAITS));
      bean.setProductNames(helper.getRequestParameterValue(PRODUCT_NAME));
      bean.setProdNamePubKey(helper.getRequestParameterValue(PROD_NAME_PUB_KEY));

      String str = helper.getRequestParameterValue(ROW_COUNT);
      int i = getDefaultRowCount();
      try {
         i = Integer.parseInt(str);
         if (i <= 0) {
            i = getDefaultRowCount();
         }

         i = Math.min(i, getMaxRowCount());
      }
      catch (Exception e) {
         _log.error(e.getMessage(), e);
      }
      bean.setRowCount(Integer.toString(i));

      bean.setSubmitBtn(helper.getRequestParameterValue(SUBMIT_BTN));
      if (StringUtils.isNullOrEmpty(bean.getSubmitBtn())) {
         bean.setSubmitBtn(helper.getRequestParameterValue(ACTION_FIELD));
      }

      str = helper.getRequestParameterValue(TRAIT_AND);
      if (str != null) {
         bean.setTraitAnd(PropertyTool.calcBoolean(str));
      }

      return bean;
   }

   public ToolBar getToolBar(UCCHelper helper) {
      ToolBar tb = new ToolBar();

      tb.setNestedFormName("SubmitChanges");
      tb.setNestedInputName(SUBMIT_NAME);

      AppRoles appRolesBean = null;
      try {
         appRolesBean = loadUserAppRoles(helper);
      }
      catch (Exception e) {
         _log.error(e.getMessage(), e);
         throw new RuntimeException(e);
      }

      if (appRolesBean != null && appRolesBean.isUserInAppRole(AppRoles.ROLE_CP_EDIT)) {
         tb.setValidateDisabled(false);
         tb.setCommitDisabled(false);
         tb.setResetRowDisabled(false);
         tb.setCopyDisabled(false);
         tb.setEditDisabled(false);
      }

      tb.setExcelDisabled(false);
      tb.setExcelId(getId());
      tb.setSeparatorDisabled(false);
      tb.setAuditDisabled(false);

      return tb;
   }

   public String getId() {
      return TABLE_ID;
   }

   public CompProdQuery getSessionBean(UCCHelper helper) {
      return (CompProdQuery) helper.getSessionParameter(CompProdQuery.NAME);
   }

   // Override this function to make a determination if the request is valid
   protected boolean isValidRequest(UCCHelper helper)
      throws Throwable
   {
      AppRoles appRolesBean = loadUserAppRoles(helper);

      return appRolesBean.isUserInAppRole(AppRoles.ROLE_CP_ACCESS);
   }
}
