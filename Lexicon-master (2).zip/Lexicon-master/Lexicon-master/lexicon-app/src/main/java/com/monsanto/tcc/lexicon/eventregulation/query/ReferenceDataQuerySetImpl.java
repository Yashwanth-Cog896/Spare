package com.monsanto.tcc.lexicon.eventregulation.query;

import com.monsanto.tcc.lexicon.typedata.country.CountryDTO;

/**
 * nbwald - Feb 6, 2009 1:41:08 PM
 */
public class ReferenceDataQuerySetImpl
   implements ReferenceDataQuerySet
{
   @Override
   public CountryDTO findCountryByIsoCode(String isoCode) {
      CountryByISOCodeQuery query = new CountryByISOCodeQuery(isoCode);
      return query.find();
   }

   @Override
   public String findAgencyPubkeyByAgencyAbbr(String agencyAbbr) {
      AgencyPubkeyByAgencyAbbrQuery query = new AgencyPubkeyByAgencyAbbrQuery(agencyAbbr);
      return query.find();
   }
}
