package com.monsanto.tcc.lexicon.eventregulation.query;

/**
 * nbwald - Feb 10, 2009 9:44:32 PM
 */
public class AgencyNotFoundException
   extends RuntimeException
{
   public AgencyNotFoundException(String agencyAbbr) {
      super("No agency pubkey found for agency with abbreviation '" + agencyAbbr + "'.");
   }
}
