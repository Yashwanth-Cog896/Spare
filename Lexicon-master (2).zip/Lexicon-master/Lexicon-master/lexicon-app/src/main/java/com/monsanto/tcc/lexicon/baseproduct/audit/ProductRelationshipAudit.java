/*
 Copyright:  Copyright � 2009 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.lexicon.baseproduct.audit;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.tcc.lexicon.baseproduct.dao.BaseProductDAO;
import com.monsanto.tcc.lexicon.baseproduct.model.ProductRelationship;
import com.monsanto.tcc.lexicon.utils.audit.AuditDAO;
import com.monsanto.tcc.lexicon.utils.audit.AuditInfo;
import com.monsanto.tcc.lexicon.utils.audit.AuditUtil;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RLCASW
 * @version $Revision$
 */
public class ProductRelationshipAudit
{

   public static final String PRODUCT_RELATIONSHIP_TABLE_NAME = "PRODUCT_RELATIONSHIP";
   public static final String PRODUCT_RELATIONSHIP_TABLE_DESCRIP = "Product Relationship";
   public static final String PRODUCT_RELATIONSHIP_LEADER = "PR_";


   private final BaseProductDAO baseProductDAO;
   private final AuditDAO auditDAO;

   private final AuditUtil auditUtil;

   public ProductRelationshipAudit() {
      this(BaseProductDAO.newInstance(), AuditDAO.newInstance(), new AuditUtil());
   }

   public ProductRelationshipAudit(BaseProductDAO baseProductDAO, AuditDAO auditDAO, AuditUtil auditUtil) {

      this.baseProductDAO = baseProductDAO;
      this.auditDAO = auditDAO;
      this.auditUtil = auditUtil;
   }

   public Map getProductRelationshipAuditInfoMap(PersistentStoreConnection conn, String baseManufactureName)
      throws WrappingException
   {
      Map entries = new LinkedHashMap();
      List<ProductRelationship> relationships = baseProductDAO.getProductRelationshipsForBaseManufactureName(conn, baseManufactureName);
      for (ProductRelationship relationship : relationships) {
         entries.put(PRODUCT_RELATIONSHIP_LEADER + relationship.getManufacturingName(), getProductRelationshipAuditInfo(conn, relationship));
      }
      return entries;
   }

   public AuditInfo getProductRelationshipAuditInfo(PersistentStoreConnection conn, ProductRelationship relationship)
      throws WrappingException
   {

      return relationship == null ? null : buildAuditInfo(conn, relationship);
   }

   public AuditInfo buildAuditInfo(PersistentStoreConnection conn, ProductRelationship relationship)
      throws WrappingException
   {
      AuditInfo auditInfo = getAuditInfo(conn, relationship.getId());
      auditInfo.setDescription(auditUtil.getDescription(conn, PRODUCT_RELATIONSHIP_TABLE_NAME, relationship.getId()));
      auditInfo.setTableDescription(PRODUCT_RELATIONSHIP_TABLE_DESCRIP);
      return auditInfo;
   }


   protected AuditInfo getAuditInfo(PersistentStoreConnection conn, String productRelationshipId)
      throws WrappingException
   {
      return auditDAO.getAuditInfo(conn, PRODUCT_RELATIONSHIP_TABLE_NAME, productRelationshipId);
   }

}