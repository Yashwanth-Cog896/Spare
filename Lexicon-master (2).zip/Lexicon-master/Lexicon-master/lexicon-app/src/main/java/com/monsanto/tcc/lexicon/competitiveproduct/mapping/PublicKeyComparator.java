package com.monsanto.tcc.lexicon.competitiveproduct.mapping;

import com.monsanto.tcc.lexicon.competitiveproduct.mapping.RowObject;

/**
 * nbwald - Nov 12, 2009 1:40:03 PM
 */
public class PublicKeyComparator
   extends StringMethodComparator
{
   @Override
   public String eval(RowObject rowObject) {
      return rowObject.getPublicKey();
   }
}
