package com.monsanto.tcc.lexicon.baseproduct.controller;

import com.monsanto.tcc.lexicon.LexiconServlet.LexiconUseCaseController;
import com.monsanto.tcc.lexicon.baseproduct.action.BaseProductAction;
import com.monsanto.tcc.lexicon.baseproduct.action.factory.BaseProductActionFactory;
import com.monsanto.tcc.lexicon.baseproduct.action.locator.BaseProductBeanLocator;
import com.monsanto.tcc.lexicon.baseproduct.action.locator.BaseProductBeanLocatorImpl;
import com.monsanto.tcc.lexicon.baseproduct.model.BaseProductPageBean;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.Exceptions.WrappingException;
import java.io.IOException;

/**
 * User: pjberry
 * Date: Jun 25, 2007
 * Time: 12:25:08 PM
 */
public class BaseProductUCC
   extends LexiconUseCaseController
{
   public static final String SUBMIT_ACTION = "submitAction";
   public static final String TARGET = "target";

   public void doService(UCCHelper helper)
      throws Throwable
   {
      BaseProductPageBean pageBean = getPageBean(helper);
      pageBean.syncWithPage(helper);
      handleRequestAction(helper, pageBean);
      helper.forward(getSuccessForward());
   }

   private void handleRequestAction(UCCHelper helper, BaseProductPageBean pageBean)
      throws WrappingException, IOException
   {
      BaseProductAction action = getAction(helper, pageBean);
      action.handle();
   }

   private BaseProductAction getAction(UCCHelper helper, BaseProductPageBean pageBean)
      throws IOException
   {
      String actionName = helper.getRequestParameterValue(SUBMIT_ACTION);
      BaseProductBeanLocator beanLocator = getBeanLocator(helper, pageBean);
      BaseProductActionFactory actionFactory = new BaseProductActionFactory(actionName, beanLocator);
      return actionFactory.getAction();
   }

   private BaseProductBeanLocator getBeanLocator(UCCHelper helper, BaseProductPageBean pageBean)
      throws IOException
   {
      String target = helper.getRequestParameterValue(TARGET);
      return new BaseProductBeanLocatorImpl(pageBean, target);
   }

   private BaseProductPageBean getPageBean(UCCHelper helper) {
      BaseProductPageBean pageBean = (BaseProductPageBean)helper.getSessionParameter(BaseProductPageBean.BEAN_ID);
      if(pageBean == null) {
         pageBean = new BaseProductPageBean();
         helper.setSessionParameter(BaseProductPageBean.BEAN_ID, pageBean);
      }
      return pageBean;
   }

   protected boolean requiresPreferenceBean() {
      return true;
   }
}
