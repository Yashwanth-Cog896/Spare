/*
 BaseProductTemplateFileValidation was created on Oct 9, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.validation.file;

import com.monsanto.tcc.lexicon.LexiconServlet.upload.UploadedFiles;
import com.monsanto.tcc.lexicon.baseproduct.validation.BaseProductTemplateRule;
import com.monsanto.tcc.lexicon.baseproduct.validation.InvalidTemplateException;

/**
 * nbwald Oct 9, 2007 2:55:17 PM
 */
public class BaseProductTemplateFileValidation
{
   private final UploadedFiles uploadedFiles;

   public BaseProductTemplateFileValidation(UploadedFiles uploadedFiles) {
      this.uploadedFiles = uploadedFiles;
   }

   public void validate()
      throws InvalidTemplateException
   {
      BaseProductTemplateRule[] rules = getOrderedRules();
      for (BaseProductTemplateRule rule : rules) {
         if(rule.violated()) {
            throw new InvalidTemplateException(rule.getViolation());
         }
      }
   }

   private BaseProductTemplateRule[] getOrderedRules() {
      return new BaseProductTemplateRule[] {
         new FileUploadedRule(uploadedFiles),
         new FileIsExcelRule(uploadedFiles),
      };
   }
}