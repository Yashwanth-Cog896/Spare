/*
 ExistingBaseProductsParentFlagMatchesTemplateRule was created on Oct 22, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.validation.intrarow;

import com.monsanto.tcc.lexicon.baseproduct.queryset.model.BaseProduct;
import com.monsanto.tcc.lexicon.baseproduct.queryset.query.BaseProductByBaseNameQuery;
import com.monsanto.tcc.lexicon.baseproduct.validation.BaseProductTemplateError;

/**
 * nbwald Oct 22, 2007 10:29:25 AM
 */
public class ExistingBaseProductsParentFlagMatchesTemplateRule
   extends ExistingBaseProductRule
{
   private final boolean templateParentProduct;

   public ExistingBaseProductsParentFlagMatchesTemplateRule(BaseProductByBaseNameQuery baseProductQuery, String baseManfName, boolean templateParentProduct) {
      super(baseProductQuery, baseManfName);
      this.templateParentProduct = templateParentProduct;
   }

   protected boolean violated(BaseProduct existingBaseProduct) {
      return parentFlagsDoNotMatch(existingBaseProduct.isParentProduct(), templateParentProduct);
   }

   private boolean parentFlagsDoNotMatch(boolean existingParentFlag, boolean templateParentFlag) {
      return existingParentFlag != templateParentFlag;
   }

   public BaseProductTemplateError getViolation() {
      return BaseProductTemplateError.EXISTING_PARENT_FLAG_DIFF_THAN_TEMPLATES;
   }
}