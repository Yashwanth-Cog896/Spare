package com.monsanto.tcc.lexicon.comments.ucc;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.tcc.lexicon.LexiconServlet.LexiconBlockingUseCaseController;
import com.monsanto.tcc.lexicon.comments.bean.CommentsProductSearchBean;
import com.monsanto.tcc.lexicon.comments.excel.AdditionalCommentsExcelSheet;
import com.monsanto.tcc.lexicon.spring.ThreadLocalApplicationContext;
import com.monsanto.tcc.lexiconcommon.file.excel.ExcelFileWriter;
import com.monsanto.tps.productstewardship.comments.service.ProductAdditionalCommentsSearchResult;
import com.monsanto.tps.productstewardship.comments.service.ProductAdditionalCommentsService;
import org.apache.commons.lang.StringUtils;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Oct 19, 2011
 * Time: 10:18:27 AM
 * To change this template use File | Settings | File Templates.
 */
public class AdditionalCommentsExcelExportUCC   extends LexiconBlockingUseCaseController {
    @Override
    public void doService(UCCHelper helper) throws Throwable {
        CommentsProductSearchBean searchBean = (CommentsProductSearchBean)helper.getSessionParameter(AdditionalCommentsConstants.COMMENTS_PRODUCT_SEARCH_BEAN);
        List<String> crops = splitParameter(searchBean.getCrops());
        List<String> productNames = splitParameter(searchBean.getProductName());
        ProductAdditionalCommentsService productAdditionalCommentsService = (ProductAdditionalCommentsService) ThreadLocalApplicationContext.getApplicationContext().getBean("productAdditionalCommentsService");
        List<ProductAdditionalCommentsSearchResult> results = productAdditionalCommentsService.findProductAdditionalComments(productNames,searchBean.getNameType(),crops);
        AdditionalCommentsExcelSheet sheet = new AdditionalCommentsExcelSheet(results);
        ExcelFileWriter writer = new ExcelFileWriter();
        File file = getScratchFile(helper);
        writer.writeToFile(file,sheet);
        writeFileContentsToResponseStream(helper,file);
        deleteScratchFile(file);
    }

   private File getScratchFile(UCCHelper helper) {
      String scratchFolder = helper.getScratchFolder();
      String userID = helper.getSystemSecurityProxy().getUserID();
      String pathname = scratchFolder + "AddnlCmntsScratchFile_" + userID + ".xls";
      return new File(pathname);
   }



   private void writeFileContentsToResponseStream(UCCHelper helper,File file)
      throws IOException
   {
      int read;
      InputStream is = new FileInputStream(file);
      OutputStream os = helper.getBinaryStream();
      helper.setContentType("application/vnd.ms-excel");
      try {
         while ((read = is.read()) != -1) {
            os.write(read);
         }
      }
      finally {
         is.close();
         os.flush();
         os.close();
      }
   }

   private void deleteScratchFile(File file) {
      file.delete();
   }    

     private List<String> splitParameter(String parameter) {
        List<String> parameters = new ArrayList<String>();
        if(StringUtils.isNotBlank(parameter)){
            if(parameter.contains(",")){
                for(String singleParameter : Arrays.asList(parameter!=null?parameter.toUpperCase().split(","):null)){
                    parameters.add(singleParameter.trim());
                }
            }
            else {
                parameters.add(parameter.trim().toUpperCase());
            }
        }
        return parameters;
    }
}
