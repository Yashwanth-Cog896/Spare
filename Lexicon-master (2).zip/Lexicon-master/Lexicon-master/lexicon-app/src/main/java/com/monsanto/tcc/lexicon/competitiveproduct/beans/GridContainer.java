package com.monsanto.tcc.lexicon.competitiveproduct.beans;

import com.monsanto.tcc.lexicon.competitiveproduct.mapping.RowObjectList;
import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.lexicon.utils.gui.I_HtmlKeys;

import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: adcox
 * Date: Oct 19, 2004
 * Time: 11:09:07 AM
 * To change this template use File | Settings | File Templates.
 */
public class GridContainer implements Serializable {
   private RowObjectList rowObjectList;
   private RowObjectList origRowObjectList;
   private String sortByColumn;
   private int sortType;
   private String errorMessage;
   private String grid;
   private boolean hideCommitted;
   private boolean fixedRowNumbers;
   protected String rowSelection;
   private String defaultAuditComment;

   public RowObjectList getRowObjectList() {
      return rowObjectList;
   }

   public void setRowObjectList(RowObjectList rowObjectList) {
      this.rowObjectList = rowObjectList;
   }

   public RowObjectList getOrigRowObjectList() {
      return origRowObjectList;
   }

   public void setOrigRowObjectList(RowObjectList origRowObjectList) {
      this.origRowObjectList = origRowObjectList;
   }

   public String getSortByColumn() {
      return sortByColumn;
   }

   public void setSortByColumn(String sortByColumn) {
      this.sortByColumn = sortByColumn;
   }

   public int getSortType() {
      return sortType;
   }

   public void setSortType(int sortType) {
      this.sortType = sortType;
   }

   public String getErrorMessage() {
      return errorMessage;
   }

   public void setErrorMessage(String errorMessage) {
      this.errorMessage = errorMessage;
   }

   public String getGrid() {
      return grid;
   }

   public void setGrid(String grid) {
      this.grid = grid;
   }

   public boolean isHideCommitted() {
      return hideCommitted;
   }

   public void setHideCommitted(boolean hideCommitted) {
      this.hideCommitted = hideCommitted;
   }

   public boolean isFixedRowNumbers() {
      return fixedRowNumbers;
   }

   public void setFixedRowNumbers(boolean fixedRowNumbers) {
      this.fixedRowNumbers = fixedRowNumbers;
   }

   public void toggleSortRequest(String sortColumn, String sortType)
   {
      if (! StringUtils.isNullOrEmpty(sortColumn)) {
         int iSortType = I_HtmlKeys.SORTED_ASC;

         if (!StringUtils.isNullOrEmpty(sortType)) {
            if (sortColumn.equals(getSortByColumn())) {
               if (getSortType() == I_HtmlKeys.SORTED_ASC) {
                  iSortType = I_HtmlKeys.SORTED_DESC;
               }
            }
         }

         setSortByColumn(sortColumn);
         setSortType(iSortType);
      }
   }

   public String getRowSelection() {
      return rowSelection;
   }

   public void setRowSelection(String rowSelection) {
      this.rowSelection = rowSelection;
   }

   public String getDefaultAuditComment() {
      return defaultAuditComment;
   }
   public void setDefaultAuditComment(String defaultAuditComment) {
      this.defaultAuditComment = defaultAuditComment;
   }
}
