package com.monsanto.tcc.lexicon.eventregulation.service;

import com.monsanto.tcc.lexicon.spring.ThreadLocalApplicationContext;
import com.monsanto.tps.lexicon.event.*;
import org.springframework.context.ApplicationContext;

import javax.jws.WebParam;

/**
 * nbwald - Dec 22, 2008 7:02:10 PM
 */
public class EventSearchServiceImpl
        implements EventSearchService {
    private final EventSearchService delegate;


    public EventSearchServiceImpl() {
        ApplicationContext context = ThreadLocalApplicationContext.getApplicationContext();
        this.delegate = (EventSearchService) context.getBean("eventSearchService");
    }

    public EventInfo findByEventAndCrop(String eventName, String crop) {
        return delegate.findByEventAndCrop(eventName, crop);
    }

    public EventInfo[] findByEventsAndCrop(String[] eventNames, String cropName) {
        return delegate.findByEventsAndCrop(eventNames, cropName);
    }

    public EventInfo findByMonNumber(String monNumberValue) {
        return delegate.findByMonNumber(monNumberValue);
    }

    public EventInfo[] findByMonNumbers(String[] monNumberValues) {
        return delegate.findByMonNumbers(monNumberValues);
    }

    public EventInfo[] findByEventAgencyAlignmentPubkey(String[] eventAgencyAlignmentPubkey) {
        return delegate.findByEventAgencyAlignmentPubkey(eventAgencyAlignmentPubkey);
    }

    @Override
    public EventInfo[] findByAgencyAbbr(String[] agencyAbbr) {
        return delegate.findByEventAgencyAlignmentPubkey(agencyAbbr);
    }

    @Override
    public EventDeregulationStatus[] getEventDeregulationStatus(String[] eventNames, String cropName, String[] agencyAbbrs) {
        return delegate.getEventDeregulationStatus(eventNames, cropName, agencyAbbrs);
    }

    @Override
    public EventDeregulationStatusWithMonNumber[] getEventDeregulationStatusWithMonNumber(@WebParam(name = "eventNames") String[] eventNames, @WebParam(name = "cropName") String cropName, @WebParam(name = "agencyAbbrs") String[] agencyAbbrs) {
        return delegate.getEventDeregulationStatusWithMonNumber(eventNames, cropName, agencyAbbrs);
    }

    @Override
    public EventDeregulationStatus[] getEventDeregulationStatus(@WebParam(name = "eventNames") String[] eventNames, @WebParam(name = "cropName") String cropName) {
        return delegate.getEventDeregulationStatus(eventNames, cropName);
    }

    @Override
    public AgencyMaterialDeregulationStatus[] getAgencyMaterialDeregulationStatus(@WebParam(name = "materialNames") String[] materialNames, @WebParam(name = "cropName") String cropName) {
        return new AgencyMaterialDeregulationStatus[0];  //To change body of implemented methods use File | Settings | File Templates.
    }
}
