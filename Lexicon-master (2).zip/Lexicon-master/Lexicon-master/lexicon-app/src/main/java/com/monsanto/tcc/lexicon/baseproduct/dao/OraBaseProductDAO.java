/*
 Copyright:  Copyright � 2009 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.lexicon.baseproduct.dao;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.*;
import com.monsanto.tcc.lexicon.baseproduct.model.ProductRelationship;

import java.util.List;
import java.util.ArrayList;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RLCASW
 * @version $Revision$
 */
public class OraBaseProductDAO
   extends BaseProductDAO
{
   public static final String PRODUCT_RELATIONSHIP_ID = "product_relationship_id";
   public static final String MANUFACTURING_NAME = "manufacturing_name";
   public static final String PRODUCT_RELATIONSHIP_PUBKEY = "product_relationship_pubkey";
   public static final String BASE_PRODUCT_ID = "base_product_id";
   public static final String LOGICAL_DELETE = "logical_delete";
   public static final String VARIETY_NAME = "variety_name";

   @Override
   public String getPrimaryKeyFromBaseManufacturingName(PersistentStoreConnection conn, String manufacturingName)
      throws
      WrappingException
   {
      String query = getSQL(BaseProductDAOSQL.SELECT_PRIMARY_KEY_BY_MANF_NAME);
      PersistentStoreStatement stmt = conn.prepareStatement(query);
      try {
         stmt.setParam(1, manufacturingName);
         PersistentStoreResultSetRow rs = stmt.executeQuery().getSingleResult();
         return rs.getString(1);
      }
      catch (EmptyResultSetException e) {
         return null;
      }
      finally {
         stmt.close();
      }

   }

   private String getSQL(String propName)
      throws WrappingException
   {
      return new BaseProductDAOSQL().getSQL(propName);
   }

   @Override
   public List<ProductRelationship> getProductRelationshipsForBaseManufactureName(PersistentStoreConnection conn, String baseManufactureName)
      throws
      WrappingException
   {
      List<ProductRelationship> relationships = new ArrayList<ProductRelationship>();
      String query = getSQL(BaseProductDAOSQL.SELECT_PRODUCT_RELATIONSHIPS_BY_MANF_NAME);

      PersistentStoreStatement stmt = conn.prepareStatement(query);
      try {
         stmt.setParam(1, baseManufactureName);
         PersistentStoreResultSet resultSet = stmt.executeQuery();
         PersistentStoreResultSetFwdIterator iterator = resultSet.getForwardIterator();
         while (iterator.next()) {
            ProductRelationship pr = buildProductRelationship(iterator);
            relationships.add(pr);
         }
      }
      finally {
         stmt.close();
      }
      return relationships;
   }

   private ProductRelationship buildProductRelationship(PersistentStoreResultSetFwdIterator iterator)
      throws
      WrappingException
   {
      ProductRelationship pr = new ProductRelationship();
      pr.setId(iterator.getString(PRODUCT_RELATIONSHIP_ID));
      pr.setManufacturingName(iterator.getString(MANUFACTURING_NAME));
      pr.setPubkey(iterator.getString(PRODUCT_RELATIONSHIP_PUBKEY));
      pr.setBaseProductId(iterator.getString(BASE_PRODUCT_ID));
      pr.setLogicalDelete("y".equalsIgnoreCase(iterator.getString(LOGICAL_DELETE)));
      pr.setVarietyName(iterator.getString(VARIETY_NAME));
      return pr;
   }

}