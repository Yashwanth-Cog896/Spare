package com.monsanto.tcc.lexicon.competitiveproduct.mapping;

import com.monsanto.tcc.lexicon.competitiveproduct.mapping.RowObject;

import java.util.Comparator;

/**
 * nbwald - Nov 12, 2009 2:08:25 PM
 */
public class CommercialMaturityComparator
   implements Comparator<RowObject>
{
   @Override
   public int compare(RowObject a, RowObject b) {
      return parseCommercialMaturity(a.getCommercialMaturity()) - parseCommercialMaturity(b.getCommercialMaturity());
   }

   private int parseCommercialMaturity(String commercialMaturity) {
      try {
         return commercialMaturity == null ? 0 : (int) Double.parseDouble(commercialMaturity);
      }
      catch (NumberFormatException e) {
         return 0;
      }
   }
}
