package com.monsanto.tcc.lexicon.comments.bean;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Oct 12, 2011
 * Time: 4:50:25 PM
 * To change this template use File | Settings | File Templates.
 */
public enum RowStatus {
    ERRED,
    COMMITTED,
    VALIDATED,
    EDITING,
    READY
}
