package com.monsanto.tcc.lexicon.artemis;

import com.monsanto.KerberosPOSSecurity.KerberosSPNEGOClient;
import com.monsanto.KerberosPOSSecurity.OSBasedGSSManagerFactory;
import com.monsanto.securityinterfaces.ClientSecurityProxy;
import com.monsanto.securityinterfaces.SystemSecurityProxy;
import com.monsanto.services.domain.common.envelope.RequestEnvelope;
import com.monsanto.services.domain.common.envelope.RequestOperation;
import com.monsanto.services.domain.common.envelope.ResponseEnvelope;
import com.monsanto.tcc.constellation.serviceconnection.DefaultXmlServiceConnectionInterpreter;
import com.monsanto.tcc.constellation.serviceconnection.KerberosXmlServiceRequest;
import com.monsanto.tcc.constellation.serviceconnection.ServiceConnection;
import com.monsanto.tcc.constellation.serviceconnection.ServiceUrlResolver;
import com.monsanto.tcc.constellation.serviceconnection.XmlServiceConnection;
import com.monsanto.tcc.constellation.serviceconnection.XmlServiceConnectionInterpreter;
import com.monsanto.tcc.constellation.serviceconnection.XmlServiceRequest;
import com.monsanto.tcc.lexiconcommon.pos.SecurityProxyFactory;
import com.monsanto.tcc.lexiconcommon.service.artemis.LexiconArtemisServiceXmlSerializerProvider;
import com.monsanto.tcc.lexiconcommon.service.artemis.LexiconServiceUrlResolver;
import com.monsanto.xmlserialization.XmlSerializer;
import com.monsanto.xmlserialization.XmlSerializerProvider;

/**
 * nbwald - Mar 18, 2008 2:24:28 PM
 */
public class LexiconArtemisServiceInvoker
{
   private final String operationName;
   private final XmlSerializerProvider serializerProvider;
   private final String serviceName;
   private final ServiceUrlResolver urlResolver;

   public LexiconArtemisServiceInvoker(String operationName) {
      this.operationName = operationName;
      this.serializerProvider = new LexiconArtemisServiceXmlSerializerProvider();
      this.serviceName = "Lex_LexiconArtemisServices";
      this.urlResolver = new LexiconServiceUrlResolver();
   }

   public ResponseEnvelope call() {
      return call(null);
   }

   public ResponseEnvelope call(Object payload) {
      RequestEnvelope requestEnvelope = getRequestEnvelope(payload);
      XmlServiceConnectionInterpreter connectionInterpreter = getConnectionInterpreter();
      XmlServiceRequest serviceRequest = getServiceRequest();
      ServiceConnection conn = new XmlServiceConnection(serviceName, urlResolver, connectionInterpreter, serviceRequest);
      return (ResponseEnvelope) conn.call(requestEnvelope);
   }

   private RequestEnvelope getRequestEnvelope(Object payload) {
      RequestOperation operation = new RequestOperation(operationName);
      return new RequestEnvelope(operation, payload);
   }

   private XmlServiceConnectionInterpreter getConnectionInterpreter() {
      XmlSerializer serializer = serializerProvider.getXmlSerializer();
      return new DefaultXmlServiceConnectionInterpreter(serializer);
   }

   private XmlServiceRequest getServiceRequest() {
      ClientSecurityProxy clientSecurityProxy = new KerberosSPNEGOClient(new OSBasedGSSManagerFactory());
      SystemSecurityProxy systemSecurityProxy = SecurityProxyFactory.getInstance().getThreadProxy();
      return new KerberosXmlServiceRequest(clientSecurityProxy, systemSecurityProxy);
   }
}
