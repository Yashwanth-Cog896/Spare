/*
 EditManufacturingLineDAO was created on Jan 18, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.dao.manufacturingline.edit;

import com.monsanto.tcc.lexiconcommon.pos.ModelServiceCall;
import com.monsanto.tcc.lexiconcommon.service.manufacturingline.edit.EditManufacturingLineRequest;
import com.monsanto.tcc.lexiconcommon.service.manufacturingline.edit.EditManufacturingLineResponse;
import java.util.List;

/**
 * nbwald Jan 18, 2008 12:42:17 PM
 */
public interface EditManufacturingLineDAO
   extends ModelServiceCall<List<EditManufacturingLineRequest>, List<EditManufacturingLineResponse>>
{
}