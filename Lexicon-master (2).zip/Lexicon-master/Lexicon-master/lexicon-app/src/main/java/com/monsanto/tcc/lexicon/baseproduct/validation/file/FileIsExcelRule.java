/*
 FileIsExcelRule was created on Oct 9, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.validation.file;

import com.monsanto.tcc.lexicon.LexiconServlet.upload.UploadedFiles;
import com.monsanto.tcc.lexicon.baseproduct.validation.BaseProductTemplateError;
import com.monsanto.tcc.lexicon.baseproduct.validation.BaseProductTemplateRule;

/**
 * nbwald Oct 9, 2007 11:38:43 AM
 */
public class FileIsExcelRule
   implements BaseProductTemplateRule
{
   private final UploadedFiles uploadedFiles;

   public FileIsExcelRule(UploadedFiles uploadedFiles) {
      this.uploadedFiles = uploadedFiles;
   }

   public boolean violated() {
      return !uploadedFiles.isExcelFormat();
   }

   public BaseProductTemplateError getViolation() {
      return BaseProductTemplateError.NOT_EXCEL_FILE;
   }
}