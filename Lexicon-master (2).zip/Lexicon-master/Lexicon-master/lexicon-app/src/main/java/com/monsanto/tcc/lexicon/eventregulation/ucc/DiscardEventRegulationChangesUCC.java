package com.monsanto.tcc.lexicon.eventregulation.ucc;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.tcc.lexicon.LexiconServlet.SimpleLexiconUCC;
import com.monsanto.tcc.lexicon.eventregulation.view.EventRegulationsBean;

/**
 * nbwald - Feb 6, 2009 2:21:50 PM
 */
public class DiscardEventRegulationChangesUCC
   extends SimpleLexiconUCC
{
   @Override
   protected void executeAction(UCCHelper helper)
      throws Exception
   {
      EventRegulationsBean eventRegulationsBean = (EventRegulationsBean) helper.getSessionParameter(EventRegulationsBean.NAME);
      eventRegulationsBean.syncValuesFromRequest(helper);
      int targetIndex = Integer.valueOf(helper.getRequestParameterValue(EventRegulationConstants.TARGET));
      eventRegulationsBean.discardChanges(targetIndex);
   }
}
