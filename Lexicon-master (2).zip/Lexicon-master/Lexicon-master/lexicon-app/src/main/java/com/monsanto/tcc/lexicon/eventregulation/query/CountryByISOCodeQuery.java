package com.monsanto.tcc.lexicon.eventregulation.query;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexicon.productflow.query.psrowimpl.CountryDTOPSRowImpl;
import com.monsanto.tcc.lexicon.typedata.TypeDataDAOUtil;
import com.monsanto.tcc.lexicon.typedata.country.CountryDTO;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.tcc.lexiconcommon.exception.RuntimeWrappingException;

/**
 * nbwald - Feb 6, 2009 1:08:04 PM
 */
public class CountryByISOCodeQuery
   extends AbstractPersistentStoreSingleResultQuery
{
   private String countryIsoCode;

   public CountryByISOCodeQuery(String countryIsoCode) {
      this.countryIsoCode = countryIsoCode;
   }

   public CountryDTO find() {
      try {
         return (CountryDTO) execute();
      }
      catch (WrappingException e) {
         throw new RuntimeWrappingException(e);
      }
   }

   @Override
   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return new CountryDTOPSRowImpl(row);
   }

   @Override
   protected String getSQL()
      throws WrappingException
   {
      return TypeDataDAOUtil.getInstance().getSQL(TypeDataDAOUtil.COUNTRY_SELECT_BY_ISO_CODE);
   }

   @Override
   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { countryIsoCode };
   }

   @Override
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
}
