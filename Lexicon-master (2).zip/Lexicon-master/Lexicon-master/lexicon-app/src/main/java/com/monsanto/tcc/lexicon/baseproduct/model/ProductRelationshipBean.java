/*
 ProductRelationshipBean was created on Aug 2, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.model;

import com.monsanto.tcc.lexicon.genericbean.model.BeanState;
import com.monsanto.tcc.lexicon.genericbean.model.HierarchicalBean;
import com.monsanto.tcc.lexicon.utils.messages.TextList;
import com.monsanto.tcc.lexiconcommon.ArrayUtils;
import com.monsanto.tcc.lexiconcommon.service.manufacturingfamily.search.model.ManufacturingLineLevelResponse;
import com.monsanto.tcc.lexiconcommon.service.productrelationship.create.CreateProductRelationshipResponse;

/**
 * nbwald Aug 2, 2007 2:55:21 PM
 */
public class ProductRelationshipBean
   implements HierarchicalBean
{
   private ProductRelationshipModel currentModel;
   private ProductRelationshipModel committedModel;
   
   private BeanState state;
   private String[] errors;

   public static final String PARENT_ERRED_MESSAGE = "There were errors for the base manufacturing name.";

   public ProductRelationshipBean() {
      currentModel = new ProductRelationshipModel();
      state = BeanState.EDITING;
   }

   public ProductRelationshipBean(ManufacturingLineLevelResponse manufacturingLineLevel) {
      currentModel = new ProductRelationshipModel(manufacturingLineLevel);
      committedModel = new ProductRelationshipModel(manufacturingLineLevel);
      state = BeanState.UNMODIFIABLE;
   }

   public ProductRelationshipBean(String manufacturingName) {
      currentModel = new ProductRelationshipModel(manufacturingName);
      state = BeanState.EDITING;
   }

    public ProductRelationshipBean(String manufacturingName, boolean blend) {
        currentModel = new ProductRelationshipModel(manufacturingName,blend);
        state = BeanState.EDITING;
    }

   public String getManufacturingName() {
      return currentModel.getManufacturingName();
   }

   public void setManufacturingName(String manufacturingName) {
      currentModel.setManufacturingName(manufacturingName);
   }

   public String getVarietyName() {
      return currentModel.getVarietyName();
   }

   public void setVarietyName(String varietyName) {
      currentModel.setVarietyName(varietyName);
   }

   public HierarchicalBean getChild(int i) {
      return null;
   }

   public BeanState getState() {
      return state;
   }

   public void update(CreateProductRelationshipResponse response)
   {
      errors = response.getErrors();
      currentModel.setVarietyName(response.getVarietyName());
      if(ArrayUtils.hasItems(response.getErrors())) {
         state = BeanState.ERRED;
      }
      else {
         state = BeanState.COMMITTED;
         committedModel = currentModel.copy();
      }

   }

   public String getErrors() {
      return new TextList(errors).toString();
   }

   public boolean isEditing() {
      return BeanState.EDITING.equals(state);
   }

   public boolean isCommitted() {
      return BeanState.COMMITTED.equals(state);
   }

   public boolean isErred() {
      return BeanState.ERRED.equals(state);
   }

   public boolean isUnmodifiable() {
      return BeanState.UNMODIFIABLE.equals(state);
   }

   public boolean isCommitable() {
      return state.isCommitable();
   }

   public void parentErred() {
      this.state = BeanState.ERRED;
      this.errors = new String[] { PARENT_ERRED_MESSAGE }; 
   }

   public void setState(BeanState state) {
      this.state = state;
   }

   public void edit() {
      this.state = BeanState.EDITING;
   }

    public boolean isBlend() {
        return currentModel.isBlend();
    }

    public void setBlend(boolean blend) {
        currentModel.setBlend(blend);
    }

   public String getCommittedManufacturingName() {
      return committedModel == null ? null : committedModel.getManufacturingName();
   }

   public boolean isEntityCommitted()    {
      return committedModel != null;
   }

   public void updateOnSuccessfulEdit() {
      this.state = BeanState.COMMITTED;
      this.errors = new String[0];
      this.committedModel = currentModel.copy();
   }

   public void updateOnFailedEdit(String[] errors) {
      this.state = BeanState.ERRED;
      this.errors = errors;
   }

   public void revert() {
      this.state = BeanState.UNMODIFIABLE;
      this.currentModel = committedModel.copy();
   }
}