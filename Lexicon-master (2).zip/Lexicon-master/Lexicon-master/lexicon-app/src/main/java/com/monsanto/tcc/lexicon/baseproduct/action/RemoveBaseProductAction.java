/*
 RemoveBaseProductAction was created on Aug 2, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.action;

import com.monsanto.tcc.lexicon.baseproduct.action.locator.BaseProductBeanLocator;

/**
 * nbwald Aug 2, 2007 10:40:37 AM
 */
public class RemoveBaseProductAction
   extends BeanLocatingBaseProductAction
{
   public static final String ACTION_NAME = "RemoveBaseProductAction";

   public RemoveBaseProductAction(BaseProductBeanLocator beanLocator) {
      super(beanLocator);
   }

   public String getActionName() {
      return ACTION_NAME;
   }

   public void handle() {
      getPageBean().removeBaseProduct(getBaseProductBean());
   }
}