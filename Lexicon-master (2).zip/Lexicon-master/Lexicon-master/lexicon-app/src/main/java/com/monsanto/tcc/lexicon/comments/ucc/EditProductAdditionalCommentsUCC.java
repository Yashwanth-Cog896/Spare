package com.monsanto.tcc.lexicon.comments.ucc;


import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.tcc.lexicon.LexiconServlet.SimpleLexiconUCC;
import com.monsanto.tcc.lexicon.comments.bean.CommentsProductSearchBean;
import com.monsanto.tcc.lexicon.comments.bean.ProductAdditionalCommentsBean;
import com.monsanto.tcc.lexicon.comments.bean.RowStatus;
import com.monsanto.tcc.lexicon.spring.ThreadLocalApplicationContext;
import com.monsanto.tps.productstewardship.comments.service.ProductAdditionalComments;
import com.monsanto.tps.productstewardship.comments.service.ProductAdditionalCommentsService;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Oct 14, 2011
 * Time: 11:39:11 AM
 * To change this template use File | Settings | File Templates.
 */
public class EditProductAdditionalCommentsUCC extends SimpleLexiconUCC {
    private static  Logger log = Logger.getLogger(EditProductAdditionalCommentsUCC.class);
    private FormScraper formScraper = new FormScraper();
    @Override
    protected void executeAction(UCCHelper helper) throws Exception {
        CommentsProductSearchBean searchBean =  (CommentsProductSearchBean)helper.getSessionParameter(AdditionalCommentsConstants.COMMENTS_PRODUCT_SEARCH_BEAN);
        searchBean.setRownum(null);
        formScraper.scrapeForm(helper,searchBean);
        if(searchBean.getActionField().equals(AdditionalCommentsConstants.EDIT)){
            enableEdit(helper,searchBean);
        }
        else if(searchBean.getActionField().equals(AdditionalCommentsConstants.DISCARD)){
            discard(helper,searchBean);
        }
        else if(searchBean.getActionField().equals(AdditionalCommentsConstants.COMMIT)){
            commit(helper,searchBean);
        }
    }

    private void commit(UCCHelper helper, CommentsProductSearchBean searchBean) throws UnsupportedEncodingException {
        boolean valid = true;
        valid = validateAdditionalComments(searchBean, valid);
        if(valid){
            saveAdditionalComments(searchBean);
            for(ProductAdditionalCommentsBean additionalComments: searchBean.getProductAdditionalComments()){
                additionalComments.setRowStatus(RowStatus.READY);
            }

        }
        helper.setSessionParameter(AdditionalCommentsConstants.COMMENTS_PRODUCT_SEARCH_BEAN,searchBean);
    }

    private boolean validateAdditionalComments(CommentsProductSearchBean searchBean, boolean valid) throws UnsupportedEncodingException {
        for(ProductAdditionalCommentsBean additionalComments: searchBean.getProductAdditionalComments()){
            if(additionalComments.isEditing()){
                int bytelength=0;
                if(StringUtils.isNotBlank(additionalComments.getProductPubkey())){
                    bytelength = additionalComments.getAdditionalComments().trim().getBytes("UTF-8").length;
                }
                if(bytelength>4000){
                    additionalComments.setRowStatus(RowStatus.ERRED);
                    additionalComments.setMessage(AdditionalCommentsConstants.COMMENTS_TOO_LONG);
                    valid=false;
                }
                else {
                    additionalComments.setRowStatus(RowStatus.VALIDATED);
                }
            }
        }
        return valid;
    }

    private void saveAdditionalComments(CommentsProductSearchBean searchBean) {
        ProductAdditionalCommentsService productAdditionalCommentsService = (ProductAdditionalCommentsService) ThreadLocalApplicationContext.getApplicationContext().getBean("productAdditionalCommentsService");
        ArrayList<ProductAdditionalComments> comments = new ArrayList<ProductAdditionalComments>();
        for(ProductAdditionalCommentsBean additionalComments: searchBean.getProductAdditionalComments()){
            if(additionalComments.isEditing()){
                ProductAdditionalComments comment = new ProductAdditionalComments();
                comment.setAdditionalComments(additionalComments.getAdditionalComments().trim());
                comment.setProductPubkey(additionalComments.getProductPubkey());
                comments.add(comment);
            }
        }
        productAdditionalCommentsService.saveProductAdditionalComments(comments);
    }

    private void enableEdit(UCCHelper helper, CommentsProductSearchBean searchBean) throws IOException {

        if(StringUtils.isNotBlank(searchBean.getRownum())){
            try{
               int rowNum= Integer.parseInt(searchBean.getRownum());
                if(searchBean!=null){
                    ProductAdditionalCommentsBean commentsBean = searchBean.getProductAdditionalComments().get(rowNum);
                    commentsBean.setRowStatus(RowStatus.EDITING);
                    commentsBean.setUnmodifiedAdditionalComments(commentsBean.getAdditionalComments());
                    helper.setSessionParameter(AdditionalCommentsConstants.COMMENTS_PRODUCT_SEARCH_BEAN,searchBean);
                }
            }
            catch (NumberFormatException nfe){
                log.warn(nfe.getMessage(),nfe);
            }
        }
    }
    private void discard(UCCHelper helper, CommentsProductSearchBean searchBean) throws IOException {
        String rownumParam = helper.getRequestParameterValue(AdditionalCommentsConstants.ROWNUM);
        if(StringUtils.isNotBlank(rownumParam)){
            try{
               int rowNum= Integer.parseInt(rownumParam);

                if(searchBean!=null){
                    ProductAdditionalCommentsBean commentsBean = searchBean.getProductAdditionalComments().get(rowNum);
                    commentsBean.setRowStatus(RowStatus.READY);
                    commentsBean.setAdditionalComments(commentsBean.getUnmodifiedAdditionalComments());
                    helper.setSessionParameter(AdditionalCommentsConstants.COMMENTS_PRODUCT_SEARCH_BEAN,searchBean);
                }
            }
            catch (NumberFormatException nfe){
                log.warn(nfe.getMessage(),nfe);
            }
        }
    }
}
