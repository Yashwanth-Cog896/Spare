/*
 BaseProductTemplateRowRule was created on Oct 8, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.validation;

/**
 * nbwald Oct 8, 2007 2:55:38 PM
 */
public interface BaseProductTemplateRule
{
   boolean violated();
   BaseProductTemplateError getViolation();
}