package com.monsanto.tcc.lexicon.controllers;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.tcc.lexicon.LexiconServlet.LexiconUseCaseController;
import com.monsanto.tcc.lexicon.monsantoproduct.edit.model.QueryPaneToggle;

import java.io.IOException;

/**
 * User: pjberry
 * Date: May 18, 2007
 * Time: 8:05:07 AM
 */
public class QueryPaneDisplayToggleUCC
   extends LexiconUseCaseController
{
   public static final String FORWARD_TO = "forwardTo";
   public static final String QUERY_PANE_TO_TOGGLE = "queryPaneName";

   public void doService(UCCHelper helper)
      throws Throwable
   {
      String nameOfQueryPaneToToggle = helper.getRequestParameterValue(QUERY_PANE_TO_TOGGLE);

      QueryPaneToggle queryPaneToggle = getQueryPaneToggle(helper, nameOfQueryPaneToToggle);
      queryPaneToggle.toggle();

      helper.setSessionParameter(nameOfQueryPaneToToggle, queryPaneToggle);
      forward(helper);
   }

   private void forward(UCCHelper helper)
      throws IOException
   {
      String forwardTo = helper.getRequestParameterValue(FORWARD_TO);
      helper.forward(forwardTo);
   }

   private QueryPaneToggle getQueryPaneToggle(UCCHelper helper, String nameOfQueryPaneToToggle) {
      QueryPaneToggle queryPaneToggle = (QueryPaneToggle)helper.getSessionParameter(nameOfQueryPaneToToggle);
      return queryPaneToggle == null ? new QueryPaneToggle() : queryPaneToggle;
   }
}
