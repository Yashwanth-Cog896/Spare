/*
 CellValueOverrides was created on Apr 23, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.competitiveproduct.tablebuilder;

import java.util.HashMap;
import java.util.Map;

/**
 * nbwald Apr 23, 2007 2:27:40 PM
 */
public class CellDisplayOverrides {
   private Map map = new HashMap();

   public String getCellDisplayValue(String name, String value) {
      String displayValue = getMapping(name, value);
      return (displayValue != null ? displayValue : value);
   }

   public void addDisplayMapping(String name, String value, String displayValue) {
      saveMapping(name, value, displayValue);
   }

   private String getMapping(String name, String value) {
      return (String) map.get(getKey(name, value));
   }

   private void saveMapping(String name, String value, String displayValue) {
      map.put(getKey(name, value), displayValue);
   }

   private Object getKey(String name, String value) {
      return name + "|" + value;
   }
}