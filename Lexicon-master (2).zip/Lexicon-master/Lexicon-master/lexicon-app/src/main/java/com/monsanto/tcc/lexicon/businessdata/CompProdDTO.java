package com.monsanto.tcc.lexicon.businessdata;

/**
 * Created by IntelliJ IDEA.
 * User: adcox
 * Date: Oct 25, 2004
 * Time: 3:12:18 PM
 * To change this template use File | Settings | File Templates.
 */
public interface CompProdDTO {
   public String getPublicKey();
   public String getProductPublicKey();
   public boolean isActive();
   public String getBayerCode();
   public String getProductName();
   public String getBrandName();
   public String getCountryName();
   public String getCommercialMaturity();
   public String getCharacteristicTraits();
   public String getTraitAttributes();
   public String getSourceVerified();
   public String getSourceYear();
   public String getComments();
   public void setPublicKey(String publicKey);
   public void setProductPublicKey(String publicKey);
}
