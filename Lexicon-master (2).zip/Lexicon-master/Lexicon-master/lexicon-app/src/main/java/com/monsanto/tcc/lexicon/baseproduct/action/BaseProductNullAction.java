/*
 BaseProductNullAction was created on Aug 2, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.action;

/**
 * nbwald Aug 2, 2007 10:06:42 AM
 */
public class BaseProductNullAction
   implements BaseProductAction
{
   public String getActionName() {
      return null;
   }

   public void handle() {
      // Do nothing
   }
}