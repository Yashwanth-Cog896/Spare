package com.monsanto.tcc.lexicon.controllers;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.tcc.lexicon.LexiconServlet.LexiconUseCaseController;

/**
 * nbwald - Mar 27, 2008 3:44:31 PM
 */
public class GenericGatewayUCC
   extends LexiconUseCaseController
{
   public static final String DESTINATION = "destination";

   public void doService(UCCHelper helper)
      throws Throwable
   {
      helper.forward(helper.getRequestParameterValue(DESTINATION));
   }

   protected boolean requiresPreferenceBean() {
      return true;
   }
}
