/*
 BaseProduct was created on Oct 19, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.queryset.model;

/**
 * nbwald Oct 19, 2007 3:56:20 PM
 */
public interface BaseProduct
{
   String getBaseManufacturingName();
   String getCropName();
   boolean isParentProduct();
}