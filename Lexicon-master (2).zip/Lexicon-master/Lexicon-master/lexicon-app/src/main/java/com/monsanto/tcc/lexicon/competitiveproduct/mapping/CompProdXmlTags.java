package com.monsanto.tcc.lexicon.competitiveproduct.mapping;

import com.monsanto.tcc.lexicon.templates.dom.TemplateXmlTags;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Aug 19, 2004
 * Time: 4:51:12 PM
 * To change this template use File | Settings | File Templates.
 */
public interface CompProdXmlTags
   extends TemplateXmlTags
{
   public static final String NS_URI = "http://www.monsanto.com/lexicon/cp";
   public static final String NS_PREFIX = "lxcp";

   public static final String ROOT_ELEM = "BatchStorage";
   public static final String REQUEST_ROOT_ELEM = "BatchRequest";
   public static final String RESPONSE_ROOT_ELEM = "BatchResponse";
   public static final String ROW_ELEM = "BatchRow";

   public static final String BAYER_ELEM = "BayerCode";
   public static final String PROD_ELEM = "ProductName";
   public static final String BRAND_ELEM = "BrandName";
   public static final String COUNTRY_ELEM = "CountryName";
   public static final String LINE_TYPE_ELEM = "LineType";
   public static final String COM_MAT_ELEM = "CommercialMaturity";
   public static final String TRAITS_ELEM = "CharacteristicTraits";
   public static final String OTHER_TRAITS_ELEM = "TraitAttributes";
   public static final String OTHER_TRAIT_ELEM = "TraitAttribute";
   public static final String PROG_CODE_ELEM = "ProgramOwner";
   public static final String VERIF_DS_ELEM = "SourceVerified";
   public static final String DS_YEAR_ELEM = "SourceYear";
   public static final String COMMENT_ELEM = "Comments";
   public static final String IS_TRANSG_ELEM = "IsTransgenic";

   public static final String BRAND_PUBKEY_ELEM = "BrandPublicKey";
   public static final String COUNTRY_PUBKEY_ELEM = "CountryPublicKey";
}
