package com.monsanto.tcc.lexicon.competitiveproduct.types;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Mar 31, 2005
 * Time: 4:32:01 PM
 * To change this template use File | Settings | File Templates.
 */
public class CompProdLineType
{
   public static final CompProdLineType HYBRID_LT_TYPE = new CompProdLineType("HYBRID");
   public static final CompProdLineType FINISHED_LT_TYPE = new CompProdLineType("FINISHED");

   public static final CompProdLineType[] TYPES = new CompProdLineType[]
      { HYBRID_LT_TYPE, FINISHED_LT_TYPE};


   public static CompProdLineType fromName(String name)
   {
      for (int i = 0; i < TYPES.length; i++) {
         if (TYPES[i].equals(name)) {
            return TYPES[i];
         }
      }
      return null;
   }

   private String name;

   protected CompProdLineType(String name)
   {
      if (name == null) {
         throw new NullPointerException();
      }
      this.name = name;
   }

   public String getName() {
      return name;
   }

   public String toString() {
      return getName();
   }

   public boolean equals(String str) {
      return (str == null) ? false : this.name.toUpperCase().equals(str.toUpperCase());
   }

   public boolean equals(Object o)
   {
      if (this == o) {
         return true;
      }
      if (o == null || !(o instanceof CompProdLineType)) {
         return false;
      }
      final CompProdLineType type = (CompProdLineType)o;
      return equals(type.getName());
   }

   public int hashCode() {
      return name.hashCode();
   }
}
