package com.monsanto.tcc.lexicon.baseproduct.dao.manufacturingfamily;

import com.monsanto.tcc.lexiconcommon.service.manufacturingfamily.search.model.ManufacturingFamily;
import com.monsanto.tcc.lexiconcommon.service.manufacturingfamily.search.model.ManufacturingFamilySearchRequest;
import com.monsanto.tcc.lexiconcommon.service.manufacturingfamily.search.model.ManufacturingFamilySearchResponse;
import com.monsanto.tcc.lexiconcommon.service.manufacturingfamily.search.model.ManufacturingFamilySearchType;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * User: pjberry
 * Date: Aug 22, 2007
 * Time: 10:13:40 AM
 */
public class ManufacturingFamilyDAOServiceImpl
   implements ManufacturingFamilyDAO
{
   public ManufacturingFamily[] findMatchingManufacturingFamilies(String[] names, String nameType)
      throws WrappingException
   {
      ManufacturingFamilySearchRequest searchServiceRequest = buildServiceSearchRequest(names, nameType);
      ManufacturingFamilySearchServiceCall serviceCall = new ManufacturingFamilySearchServiceCall();
      ManufacturingFamilySearchResponse response = serviceCall.execute(searchServiceRequest);
      return response.getManufacturingFamilies();
   }

   private ManufacturingFamilySearchRequest buildServiceSearchRequest(String[] names, String nameType) {
      return new ManufacturingFamilySearchRequest(names, ManufacturingFamilySearchType.valueOf(nameType));
   }
}
