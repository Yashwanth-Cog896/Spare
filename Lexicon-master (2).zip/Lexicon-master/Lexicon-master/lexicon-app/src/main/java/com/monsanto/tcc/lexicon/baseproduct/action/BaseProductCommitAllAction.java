/*
 BaseProductCommitAllAction was created on Aug 2, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.action;

import com.monsanto.tcc.lexicon.baseproduct.action.locator.BaseProductBeanLocator;
import com.monsanto.tcc.lexicon.baseproduct.dao.baseproduct.create.CreateBaseProduct;
import com.monsanto.tcc.lexicon.baseproduct.dao.baseproduct.create.CreateBaseProductServiceCall;
import com.monsanto.tcc.lexicon.baseproduct.dao.manufacturingline.create.CreateProductRelationshipDAO;
import com.monsanto.tcc.lexicon.baseproduct.dao.manufacturingline.create.CreateProductRelationshipDAOServiceImpl;
import com.monsanto.tcc.lexicon.baseproduct.dao.manufacturingline.edit.EditManufacturingLineDAO;
import com.monsanto.tcc.lexicon.baseproduct.dao.manufacturingline.edit.EditManufacturingLineDAOServiceImpl;
import com.monsanto.tcc.lexicon.baseproduct.model.BaseProductBean;
import com.monsanto.tcc.lexicon.baseproduct.model.CreateableProductRelationship;
import com.monsanto.tcc.lexicon.baseproduct.model.EditableProductRelationship;
import com.monsanto.tcc.lexicon.baseproduct.process.baseproduct.create.CreateBaseProductProcessor;
import com.monsanto.tcc.lexicon.baseproduct.process.manufacturingline.create.CreateProductRelationshipProcessor;
import com.monsanto.tcc.lexicon.baseproduct.process.manufacturingline.edit.EditManufacturingLineProcessor;
import com.monsanto.tcc.lexicon.typedata.queryset.ReferenceDataQuerySet;
import com.monsanto.tcc.lexicon.typedata.queryset.ReferenceDataQuerySetImpl;
import com.monsanto.Util.Exceptions.WrappingException;
import java.util.List;

/**
 * nbwald Aug 2, 2007 11:44:44 AM
 */
public class BaseProductCommitAllAction
   extends BeanLocatingBaseProductAction
{
   public static final String ACTION_NAME = "BaseProductCommitAllAction";

   private final CreateBaseProduct baseProductCreator;
   private final CreateProductRelationshipDAO productRelationshipCreator;
   private final EditManufacturingLineDAO manufacturingLineEditor;
   private final ReferenceDataQuerySet refLookup;

   public BaseProductCommitAllAction(BaseProductBeanLocator beanLocator) {
      this(beanLocator,
         new CreateBaseProductServiceCall(),
         new CreateProductRelationshipDAOServiceImpl(),
         new EditManufacturingLineDAOServiceImpl(),
         new ReferenceDataQuerySetImpl());
   }

   public BaseProductCommitAllAction(BaseProductBeanLocator beanLocator,
      CreateBaseProduct baseProductCreator,
      CreateProductRelationshipDAO productRelationshipCreator,
      EditManufacturingLineDAO manufacturingLineEditor,
      ReferenceDataQuerySet referenceDataQuerySet)
   {
      super(beanLocator);
      this.baseProductCreator = baseProductCreator;
      this.productRelationshipCreator = productRelationshipCreator;
      this.manufacturingLineEditor = manufacturingLineEditor;
      this.refLookup = referenceDataQuerySet;
   }

   public String getActionName() {
      return ACTION_NAME;
   }

   public void handle()
      throws WrappingException
   {
      commitBaseProductLevel();
      commitProductRelationshipLevel();
   }

   private void commitBaseProductLevel()
      throws WrappingException
   {
      CreateBaseProductProcessor processor = new CreateBaseProductProcessor(baseProductCreator, refLookup);
      processor.process(getBaseProductBeans());
   }

   private void commitProductRelationshipLevel()
      throws WrappingException
   {
      createNewRelationships();
      editExistingManufacturingLines();
   }

   private void createNewRelationships()
      throws WrappingException
   {
      CreateProductRelationshipProcessor processor = new CreateProductRelationshipProcessor(productRelationshipCreator);
      processor.process(getCreateableProductRelationships());
   }

   private void editExistingManufacturingLines()
      throws WrappingException
   {
      EditManufacturingLineProcessor processor = new EditManufacturingLineProcessor(manufacturingLineEditor);
      processor.process(getAllEditableProductRelationships());
   }

   private List<BaseProductBean> getBaseProductBeans() {
      return getPageBean().getBaseProducts();
   }

   private List<CreateableProductRelationship> getCreateableProductRelationships() {
      return getPageBean().getAllCreateableProductRelationships();
   }

   private List<EditableProductRelationship> getAllEditableProductRelationships() {
      return getPageBean().getAllEditableProductRelationships();
   }
}