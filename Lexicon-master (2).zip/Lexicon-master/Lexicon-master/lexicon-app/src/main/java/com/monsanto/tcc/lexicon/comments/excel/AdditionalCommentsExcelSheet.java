package com.monsanto.tcc.lexicon.comments.excel;

import com.monsanto.tcc.lexicon.comments.bean.ProductAdditionalCommentsBean;
import com.monsanto.tcc.lexiconcommon.file.excel.ExcelRow;
import com.monsanto.tcc.lexiconcommon.file.excel.ExcelSheet;
import com.monsanto.tps.productstewardship.comments.service.ProductAdditionalCommentsSearchResult;

import java.util.ArrayList;
import java.util.List;
/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Oct 19, 2011
 * Time: 9:56:05 AM
 * To change this template use File | Settings | File Templates.
 */
public class AdditionalCommentsExcelSheet implements ExcelSheet {
    private List<ProductAdditionalCommentsSearchResult>  productAdditionalComments;
    public AdditionalCommentsExcelSheet(List<ProductAdditionalCommentsSearchResult> productAdditionalComments){
        this.productAdditionalComments=productAdditionalComments;
    }
    @Override
    public ExcelRow[] getData() {
        if(productAdditionalComments==null){
            return new ExcelRow[0];
        }
        else {
           List<ExcelRow> rows = new ArrayList<ExcelRow>(productAdditionalComments.size());
           for(ProductAdditionalCommentsSearchResult productComment : productAdditionalComments){
                rows.add(new AdditionalCommentsExcelRow(productComment));
           }
            return rows.toArray(new ExcelRow[rows.size()]);
        }
    }

    @Override
    public ExcelRow getHeader() {
        return new AdditionalCommentsHeaderRow();
    }
}
