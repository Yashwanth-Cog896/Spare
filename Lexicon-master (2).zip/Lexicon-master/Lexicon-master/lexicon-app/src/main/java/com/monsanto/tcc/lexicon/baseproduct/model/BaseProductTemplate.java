/*
 BaseProductTemplate was created on Oct 8, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.model;

import com.monsanto.tcc.lexicon.LexiconServlet.upload.UploadedFiles;
import com.monsanto.tcc.lexicon.baseproduct.queryset.UploadBaseProductTemplateQuerySet;
import com.monsanto.tcc.lexicon.baseproduct.validation.InvalidTemplateException;
import com.monsanto.tcc.lexicon.baseproduct.validation.file.BaseProductTemplateFileValidation;
import com.monsanto.tcc.lexicon.baseproduct.validation.sheet.BaseProductTemplateSheetValidation;
import com.monsanto.tcc.lexiconcommon.file.excel.ExcelSheet;

/**
 * nbwald Oct 8, 2007 3:28:18 PM
 */
public class BaseProductTemplate
{
   private final UploadedFiles uploadedFiles;
   private final UploadBaseProductTemplateQuerySet querySet;

   public BaseProductTemplate(UploadedFiles uploadedFiles, UploadBaseProductTemplateQuerySet querySet) {
      this.uploadedFiles = uploadedFiles;
      this.querySet = querySet;
   }

   public BaseProductPageBean getBaseProductPageBean()
      throws InvalidTemplateException
   {
      ExcelSheet excelSheet = loadTemplate();
      return new BaseProductTemplateParser(excelSheet, querySet).getBaseProductPageBean();
   }

   private ExcelSheet loadTemplate()
      throws InvalidTemplateException
   {
      validateFile();
      ExcelSheet excelSheet = uploadedFiles.readExcelSheet();
      validateSheet(excelSheet);
      return excelSheet;
   }

   private void validateFile()
      throws InvalidTemplateException
   {
      BaseProductTemplateFileValidation fileValidation = new BaseProductTemplateFileValidation(uploadedFiles);
      fileValidation.validate();
   }

   private void validateSheet(ExcelSheet excelSheet)
      throws InvalidTemplateException
   {
      BaseProductTemplateSheetValidation sheetValidation = new BaseProductTemplateSheetValidation(excelSheet, querySet);
      sheetValidation.validate();
   }

   public void deleteTemplate() {
      uploadedFiles.delete();
   }
}