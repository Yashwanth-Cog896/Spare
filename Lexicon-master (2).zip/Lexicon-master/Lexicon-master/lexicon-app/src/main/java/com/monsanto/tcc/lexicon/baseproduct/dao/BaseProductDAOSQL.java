/*
 Copyright:  Copyright � 2009 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.lexicon.baseproduct.dao;

import com.monsanto.tcc.lexicon.utils.db.dao.DAOUtil;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RLCASW
 * @version $Revision$
 */
public class BaseProductDAOSQL
   extends DAOUtil
{
   private static final String BASE_PRODUCT_DAOSQL_PROPERTIES = "BaseProductDAOSQL.properties";
   public static final String SELECT_PRIMARY_KEY_BY_MANF_NAME = "BaseProduct.SelectPrimaryKeyFromManufacturingName";
   public static final String SELECT_PRODUCT_RELATIONSHIPS_BY_MANF_NAME = "BaseProduct.SelectProductRelationshipsByManufacturingName";

   @Override
   protected String getPropfileName() {
      return BASE_PRODUCT_DAOSQL_PROPERTIES;
   }

}