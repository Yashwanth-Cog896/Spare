/*
 RemoveProductRelationshipAction was created on Aug 3, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.action;

import com.monsanto.tcc.lexicon.baseproduct.action.locator.BaseProductBeanLocator;
import com.monsanto.tcc.lexicon.baseproduct.model.ProductRelationshipBean;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald Aug 3, 2007 1:21:46 PM
 */
public class DiscardProductRelationshipChangesAction
   extends BeanLocatingBaseProductAction
{
   public static final String ACTION_NAME = "RemoveProductRelationshipAction";

   public DiscardProductRelationshipChangesAction(BaseProductBeanLocator beanLocator) {
      super(beanLocator);
   }

   public String getActionName() {
      return ACTION_NAME;
   }

   public void handle()
      throws WrappingException
   {
      ProductRelationshipBean relationship = getProductRelationshipBean();
      if(relationship.isEntityCommitted()) {
         relationship.revert();
      }
      else {
         getBaseProductBean().removeProductRelationship(relationship);
      }
   }
}