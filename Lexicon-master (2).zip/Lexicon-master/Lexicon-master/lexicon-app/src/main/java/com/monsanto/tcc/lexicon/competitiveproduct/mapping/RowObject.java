package com.monsanto.tcc.lexicon.competitiveproduct.mapping;

import com.monsanto.tcc.lexicon.businessdata.CompProdDTOImpl;
import com.monsanto.tcc.lexicon.templates.type.RowStatusType;


/**
 * Created by IntelliJ IDEA.
 * User: adcox
 * Date: Aug 30, 2004
 * Time: 11:41:24 AM
 */
public class RowObject
   extends CompProdDTOImpl
   implements Cloneable
{
   private int rowNumber;
   private String lineType;
   private String programOwner;

   private String status;
   private String errors;
   private String notes;

   private String auditRequestor;
   private String auditComment;

   private boolean commitFlag;
   private boolean copied;
   private boolean editing;
   //private boolean active;
   public static final int UNASSIGNED = -1;

   public RowObject(
      String namePublicKey,
      String productPublicKey)
   {
      setPublicKey(namePublicKey);
      setProductPublicKey(productPublicKey);
      copied = false;
      editing = false;
//      active = true;
      rowNumber = UNASSIGNED;
   }

   public RowObject()
   {
//      active = true;
      rowNumber = UNASSIGNED;
      copied = false;
   }


   public void setBayerCode(String bayerCode) {
      super.setBayerCode(bayerCode);
   }
   public void setBrandName(String brandName) {
      super.setBrandName(brandName);
   }
   public void setCharacteristicTraits(String traits) {
      super.setCharacteristicTraits(traits);
   }
   public void setComments(String comments) {
      super.setComments(comments);
   }
   public void setCommercialMaturity(String commercialName) {
      super.setCommercialMaturity(commercialName);
   }
   public void setCountryName(String countryName) {
      super.setCountryName(countryName);
   }
   public void setProductName(String productName) {
      super.setProductName(productName);
   }
//   public void setRequestor(String requester) {
//      super.setRequestor(requester);
//   }
   public void setSourceVerified(String sourceVerified) {
      super.setSourceVerified(sourceVerified);
   }
   public void setSourceYear(String sourceYear) {
      super.setSourceYear(sourceYear);
   }
   public void setTraitAttributes(String traitAttributes) {
      super.setTraitAttributes(traitAttributes);
   }


   public int getRowNumber() {
      return rowNumber;
   }
   public void setRowNumber(int rowNumber) {
      this.rowNumber = rowNumber;
   }
   public void setRowNumber(String rowNumber) {
      this.rowNumber = Integer.parseInt(rowNumber);
   }

   public String getLineType() {
      return lineType;
   }
   public void setLineType(String lineType) {
      this.lineType = lineType;
   }

   public String getProgramOwner() {
      return programOwner;
   }
   public void setProgramOwner(String programOwner) {
      this.programOwner = programOwner;
   }

   public String getStatus() {
      return status;
   }
   public void setStatus(String status) {
      this.status = status;
   }
   public void setStatus(RowStatusType status) {
      setStatus(status.getName());
   }

   public String getErrors() {
      return errors;
   }
   public void setErrors(String errors) {
      this.errors = errors;
   }

   public String getNotes() {
      return notes;
   }
   public void setNotes(String notes) {
      this.notes = notes;
   }

   public boolean isCommitFlag() {
      return commitFlag;
   }
   public void setCommitFlag(boolean commitFlag) {
      this.commitFlag = commitFlag;
   }

   public void setActive(boolean activeFlag) {
      super.setActive(activeFlag); }


   public void copy(RowObject src)
   {
      setPublicKey(src.getPublicKey());
      setProductPublicKey(src.getProductPublicKey());
      setActive(src.isActive());
      setBayerCode(src.getBayerCode());
      setProductName(src.getProductName());
      setBrandName(src.getBrandName());
      setCountryName(src.getCountryName());
      setCommercialMaturity(src.getCommercialMaturity());
      setCharacteristicTraits(src.getCharacteristicTraits());
      setTraitAttributes(src.getTraitAttributes());
      setSourceVerified(src.getSourceVerified());
      setSourceYear(src.getSourceYear());
      //setRequestor(src.getRequestor());
      setComments(src.getComments());

      setRowNumber(src.getRowNumber());
      setLineType(src.getLineType());
      setProgramOwner(src.getProgramOwner());
      setStatus(src.getStatus());
      setErrors(src.getErrors());
      setNotes(src.getNotes());
      setCommitFlag(src.isCommitFlag());
      setCopied(src.isCopied());
      setEditing(src.isEditing());

      setAuditComment(src.getAuditComment());
      setAuditRequestor(src.getAuditRequestor());
   }

   public Object clone()
   {
      RowObject ret = new RowObject();
      ret.copy(this);
      return ret;
   }

   public int rankStatus()
   {
      String status = getStatus();
      RowStatusType type = RowStatusType.fromName(status);
      return (type != null) ? type.getRank() : Integer.MAX_VALUE;
   }

   public boolean isCopied() {
      return copied;
   }

   public void setCopied(boolean copied) {
      this.copied = copied;
   }

   public boolean isEditing() {
      return editing;
   }

   public void setEditing(boolean editing) {
      this.editing = editing;
   }

   public String getAuditRequestor() {
      return auditRequestor;
   }

   public void setAuditRequestor(String auditRequestor) {
      this.auditRequestor = auditRequestor;
   }

   public String getAuditComment() {
      return auditComment;
   }

   public void setAuditComment(String auditComment) {
      this.auditComment = auditComment;
   }

   public String getAuditDescription() {
      return getPublicKey() + " " + getBayerCode() + " " + getBrandName() + " " + getProductName() + " " + getCountryName();
   }
}
