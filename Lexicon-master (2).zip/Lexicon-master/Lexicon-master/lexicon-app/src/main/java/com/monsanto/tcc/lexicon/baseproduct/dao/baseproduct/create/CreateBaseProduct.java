/*
 CreateBaseProduct was created on Jun 26, 2007 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.dao.baseproduct.create;

import com.monsanto.tcc.lexiconcommon.pos.ModelServiceCall;
import com.monsanto.tcc.lexiconcommon.service.baseproduct.CreateBaseProductRequest;
import com.monsanto.tcc.lexiconcommon.service.baseproduct.CreateBaseProductResponse;
import com.monsanto.Util.Exceptions.WrappingException;
import java.util.List;

/**
 * nbwald Jun 26, 2007 6:24:51 PM
 */
public interface CreateBaseProduct
   extends ModelServiceCall<List<CreateBaseProductRequest>, List<CreateBaseProductResponse>>
{
   List<CreateBaseProductResponse> execute(List<CreateBaseProductRequest> batchRequest)
      throws WrappingException;
}