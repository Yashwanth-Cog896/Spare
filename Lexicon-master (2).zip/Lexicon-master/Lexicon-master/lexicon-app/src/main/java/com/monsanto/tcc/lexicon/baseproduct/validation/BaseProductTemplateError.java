package com.monsanto.tcc.lexicon.baseproduct.validation;

/**
 * nbwald Oct 8, 2007 10:44:45 AM
 */
public enum BaseProductTemplateError
{
   NO_FILE_UPLOADED ("Please select a manufacturing name Excel file to import."),
   NOT_EXCEL_FILE ("Imported file is not readable or not an Excel file."),
   INVALID_PARENT_FLAG ("Parent flag must be either 'Yes' or 'No'."),
   INVALID_CROP_NAME ("Invalid crop name specified."),
   INVALID_BASE_MANF_NAME ("Missing base manufacturing name."),
   DUPLICATE_ROWS ("Rows are duplicate."),
   INCONSISTENT_PARENT_FLAG ("May not have the same base manufacturing name as a parent and a non-parent."),
   INCONSISTENT_CROP ("May not have the same base manufacturing name with different crops."),
   DUPLICATE_MANF_NAME ("May not have duplicate manufacturing names."),
   NO_DATA ("File does not contain any data."),
   INCONSISTENT_MANF_NAMES ("Base manufacturing names must have either all manufacturing names specified or no manufacturing name."),
   EXISTING_PARENT_FLAG_DIFF_THAN_TEMPLATES ("Base manufacturing name exists with a different parent flag."),
   EXISTING_CROP_DIFF_THAN_TEMPLATES ("Base manufacturing name exists for a different crop."),
   TOO_MANY_ROWS ("Too many rows in template.  Please limit the template to 500 rows."),
   IS_BLEND_CANT_BE_TRUE("Can't create blend manufacturing name for non blend workflow crop");

   private final String asString;
   private BaseProductTemplateError(String asString) {
      this.asString = asString;
   }
   public String toString() {
      return asString;
   }
}
