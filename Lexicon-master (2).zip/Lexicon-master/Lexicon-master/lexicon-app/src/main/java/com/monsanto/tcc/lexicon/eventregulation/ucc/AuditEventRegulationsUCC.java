package com.monsanto.tcc.lexicon.eventregulation.ucc;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.tcc.lexicon.LexiconServlet.LexiconUseCaseController;
import com.monsanto.tcc.lexicon.eventregulation.query.EventRegulationAuditQuerySet;
import com.monsanto.tcc.lexicon.eventregulation.query.EventRegulationAuditQuerySetImpl;
import com.monsanto.tcc.lexicon.utils.audit.AuditConstants;
import com.monsanto.tcc.lexicon.utils.audit.AuditInfo;
import com.monsanto.tcc.lexiconcommon.ArrayUtils;

import java.util.HashMap;
import java.util.Map;

/**
 * nbwald - Feb 10, 2009 10:36:08 PM
 */
public class AuditEventRegulationsUCC
   extends LexiconUseCaseController
{
   public static String EVENT_NAME = "eventName";
   private final EventRegulationAuditQuerySet querySet;

   public AuditEventRegulationsUCC() {
      this(new EventRegulationAuditQuerySetImpl());
   }

   public AuditEventRegulationsUCC(EventRegulationAuditQuerySet querySet) {
      this.querySet = querySet;
   }

   @Override
   public void doService(UCCHelper helper)
      throws Throwable
   {
      String eventName = helper.getRequestParameterValue(EVENT_NAME);
      String[] eventRegulationPrimaryKeys = querySet.findEventRegulationPrimaryKeysByEventName(eventName);
      Map<String, AuditInfo> auditInfoByPrimaryKey = new HashMap<String, AuditInfo>();
      if(ArrayUtils.hasItems(eventRegulationPrimaryKeys)) {
         for (String eventRegulationPrimaryKey : eventRegulationPrimaryKeys) {
            auditInfoByPrimaryKey.put(eventRegulationPrimaryKey, querySet.findEventRegulationAuditInfoByPrimaryKey(eventRegulationPrimaryKey));
         }
      }
      helper.setRequestAttributeValue(AuditConstants.AUDIT_INFO_ENTRIES, auditInfoByPrimaryKey);
      helper.forward(AuditConstants.AUDIT_FORWARD);
   }
}
