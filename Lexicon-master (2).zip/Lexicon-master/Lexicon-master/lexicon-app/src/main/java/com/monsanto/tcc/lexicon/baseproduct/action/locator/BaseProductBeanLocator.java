/*
 BaseProductBeanLocator was created on Aug 2, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.action.locator;

import com.monsanto.tcc.lexicon.baseproduct.model.BaseProductBean;
import com.monsanto.tcc.lexicon.baseproduct.model.BaseProductPageBean;
import com.monsanto.tcc.lexicon.baseproduct.model.ProductRelationshipBean;

/**
 * nbwald Aug 2, 2007 5:02:10 PM
 */
public interface BaseProductBeanLocator
{
   BaseProductPageBean getPageBean();
   BaseProductBean getBaseProductBean();
   ProductRelationshipBean getProductRelationshipBean();
}