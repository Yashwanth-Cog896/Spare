/*
 BaseProductPageBean was created on Aug 1, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.model;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.lexicon.baseproduct.excel.BaseProductTemplateRow;
import com.monsanto.tcc.lexicon.genericbean.model.HierarchicalBean;
import com.monsanto.tcc.lexicon.genericbean.util.HierarchicalBeanSyncer;
import com.monsanto.tcc.lexicon.genericbean.util.HierarchicalBeanSyncerImpl;
import com.monsanto.tcc.lexiconcommon.service.manufacturingfamily.search.model.ManufacturingFamily;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * nbwald Aug 1, 2007 4:34:50 PM
 */
public class BaseProductPageBean
   implements HierarchicalBean
{
   public static final String BEAN_ID = "BaseProductPageBean";

   private LinkedList<BaseProductBean> baseProducts = new LinkedList<BaseProductBean>();

   public BaseProductPageBean() { }

   public BaseProductPageBean(ManufacturingFamily[] manufacturingFamilies) {
      for (ManufacturingFamily manufacturingFamily : manufacturingFamilies) {
         baseProducts.add(new BaseProductBean(manufacturingFamily));
      }
   }

   public void createBaseProduct() {
      baseProducts.addFirst(new BaseProductBean());
   }

   public void createBaseProduct(BaseProductTemplateRow templateRow) {
      BaseProductBean baseProduct = findBaseProduct(templateRow.getBaseManufacturingName());
      if(baseProduct == null) {
         baseProduct = new BaseProductBean(templateRow, false);
         baseProducts.addFirst(baseProduct);
      }
      baseProduct.createProductRelationship(templateRow);
   }

   private BaseProductBean findBaseProduct(String baseManufacturingName) {
      for (BaseProductBean baseProduct : baseProducts) {
         if(StringUtils.areEqual(baseProduct.getBaseManufacturingName(), baseManufacturingName)) {
            return baseProduct;
         }
      }
      return null;
   }

   public List<BaseProductBean> getBaseProducts() {
      return baseProducts;
   }

   public void removeBaseProduct(BaseProductBean baseProduct) {
      baseProducts.remove(baseProduct);
   }

   public void syncWithPage(UCCHelper helper) {
      HierarchicalBeanSyncer beanSyncer = new HierarchicalBeanSyncerImpl();
      beanSyncer.sync(this, helper);
   }

   public HierarchicalBean getChild(int i) {
      return baseProducts.get(i);
   }

   public List<CreateableProductRelationship> getAllCreateableProductRelationships() {
      List<CreateableProductRelationship> createableProductRelationships = new ArrayList<CreateableProductRelationship>();
      for (BaseProductBean baseProduct : baseProducts) {
         createableProductRelationships.addAll(baseProduct.getCreateableProductRelationships());
      }
      return createableProductRelationships;
   }

   public List<EditableProductRelationship> getAllEditableProductRelationships() {
      List<EditableProductRelationship> editableProductRelationships = new ArrayList<EditableProductRelationship>();
      for (BaseProductBean baseProduct : baseProducts) {
         editableProductRelationships.addAll(baseProduct.getEditableProductRelationships());
      }
      return editableProductRelationships;
   }
}