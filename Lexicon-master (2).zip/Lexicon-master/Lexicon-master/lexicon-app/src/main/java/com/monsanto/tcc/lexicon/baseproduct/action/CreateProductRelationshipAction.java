/*
 CreateProductRelationshipAction was created on Aug 2, 2007 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.action;

import com.monsanto.tcc.lexicon.baseproduct.action.locator.BaseProductBeanLocator;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald Aug 2, 2007 2:44:35 PM
 */
public class CreateProductRelationshipAction
   extends BeanLocatingBaseProductAction
{
   public static final String ACTION_NAME = "CreateProductRelationshipAction";
   
   public CreateProductRelationshipAction(BaseProductBeanLocator beanLocator) {
      super(beanLocator);
   }

   public String getActionName() {
      return ACTION_NAME;
   }

   public void handle()
      throws WrappingException
   {
      getBaseProductBean().createProductRelationship();
   }
}