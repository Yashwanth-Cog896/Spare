package com.monsanto.tcc.lexicon.croproles;

/**
 * rrchak1 - Feb 25, 2009 1:23:51 PM
 */
public interface CropAuthorization
{
   public String[] getAuthorizedCrops();
}
