/*
 BaseProductAlwaysOrNeverHasManfNamesRule was created on Oct 12, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.validation.interrow;

import com.monsanto.tcc.lexicon.baseproduct.excel.BaseProductTemplateRow;
import com.monsanto.tcc.lexicon.baseproduct.validation.BaseProductTemplateError;
import com.monsanto.tcc.lexicon.baseproduct.validation.BaseProductTemplateRule;
import com.monsanto.Util.StringUtils;

/**
 * nbwald Oct 12, 2007 3:13:00 PM
 */
public class BaseProductAlwaysOrNeverHasManfNamesRule
   implements BaseProductTemplateRule
{
   private final BaseProductTemplateRow rowA;
   private final BaseProductTemplateRow rowB;

   public BaseProductAlwaysOrNeverHasManfNamesRule(BaseProductTemplateRow rowA, BaseProductTemplateRow rowB) {
      this.rowA = rowA;
      this.rowB = rowB;
   }

   public boolean violated() {
      return sameBaseProduct() && manufacturingNamesAreInconsistent();
   }

   private boolean sameBaseProduct() {
      return StringUtils.areEqual(rowA.getBaseManufacturingName(), rowB.getBaseManufacturingName());
   }

   private boolean manufacturingNamesAreInconsistent() {
      return StringUtils.isNullOrEmpty(rowA.getManufacturingName()) != StringUtils.isNullOrEmpty(rowB.getManufacturingName());
   }

   public BaseProductTemplateError getViolation() {
      return BaseProductTemplateError.INCONSISTENT_MANF_NAMES;
   }
}