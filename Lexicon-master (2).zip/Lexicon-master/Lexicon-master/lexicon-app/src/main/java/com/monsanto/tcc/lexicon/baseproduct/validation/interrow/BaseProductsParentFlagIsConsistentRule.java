/*
 BaseProductsParentFlagIsConsistentRule was created on Oct 11, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.validation.interrow;

import com.monsanto.tcc.lexicon.baseproduct.excel.BaseProductTemplateRow;
import com.monsanto.tcc.lexicon.baseproduct.validation.BaseProductTemplateError;
import com.monsanto.tcc.lexicon.baseproduct.validation.BaseProductTemplateRule;
import com.monsanto.Util.StringUtils;

/**
 * nbwald Oct 11, 2007 2:40:51 PM
 */
public class BaseProductsParentFlagIsConsistentRule
   implements BaseProductTemplateRule
{
   private final BaseProductTemplateRow rowA;
   private final BaseProductTemplateRow rowB;

   public BaseProductsParentFlagIsConsistentRule(BaseProductTemplateRow rowA, BaseProductTemplateRow rowB) {
      this.rowA = rowA;
      this.rowB = rowB;
   }

   public boolean violated() {
      return StringUtils.areEqual(rowA.getBaseManufacturingName(), rowB.getBaseManufacturingName())
         && rowA.isParentProduct() != rowB.isParentProduct();
   }

   public BaseProductTemplateError getViolation() {
      return BaseProductTemplateError.INCONSISTENT_PARENT_FLAG;
   }
}