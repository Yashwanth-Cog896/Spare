package com.monsanto.tcc.lexicon.baseproduct.queryset.query;

import com.monsanto.tcc.lexicon.croproles.CropAuthorization;
import com.monsanto.tcc.lexicon.croproles.CropAuthorizationImpl;
import com.monsanto.tcc.lexicon.productflow.query.AuthorizedCropByNameQuery;
import com.monsanto.tcc.lexiconcommon.pos.SecurityProxyFactory;

/**
 * rrchak1 - Mar 12, 2009 11:57:18 AM
 */
public class AuthorizedCropNameQueryImpl
   implements CropNameQuery
{
   @Override
   public boolean isValid(String cropName) {
      AuthorizedCropByNameQuery delegateQuery = new AuthorizedCropByNameQuery(cropName, getCropAuthorization());
      return null != delegateQuery.find();
   }

   protected CropAuthorization getCropAuthorization() {
      return new CropAuthorizationImpl(getUserLoginId());
   }

   private String getUserLoginId() {
      return SecurityProxyFactory.getInstance().getThreadProxy().getUserID();
   }
}
