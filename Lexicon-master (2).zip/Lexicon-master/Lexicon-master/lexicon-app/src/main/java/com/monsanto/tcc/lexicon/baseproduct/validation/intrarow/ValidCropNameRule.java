/*
 ValidCropNameRule was created on Oct 8, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.validation.intrarow;

import com.monsanto.tcc.lexicon.baseproduct.queryset.query.CropNameQuery;
import com.monsanto.tcc.lexicon.baseproduct.validation.BaseProductTemplateError;
import com.monsanto.tcc.lexicon.baseproduct.validation.BaseProductTemplateRule;

/**
 * nbwald Oct 8, 2007 2:36:07 PM
 */
public class ValidCropNameRule
   implements BaseProductTemplateRule
{
   private final CropNameQuery validator;
   private final String cropName;

   public ValidCropNameRule(CropNameQuery validator, String cropName) {
      this.validator = validator;
      this.cropName = cropName;
   }

   public boolean violated() {
      return !validator.isValid(cropName);
   }

   public BaseProductTemplateError getViolation() {
      return BaseProductTemplateError.INVALID_CROP_NAME;
   }
}