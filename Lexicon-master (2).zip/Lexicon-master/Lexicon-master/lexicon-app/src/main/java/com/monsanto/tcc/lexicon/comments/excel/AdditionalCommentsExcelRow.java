package com.monsanto.tcc.lexicon.comments.excel;

import com.monsanto.tcc.lexicon.comments.bean.ProductAdditionalCommentsBean;
import com.monsanto.tcc.lexiconcommon.file.excel.ExcelRow;
import com.monsanto.tps.productstewardship.comments.service.ProductAdditionalCommentsSearchResult;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Oct 19, 2011
 * Time: 9:15:43 AM
 * To change this template use File | Settings | File Templates.
 */
public class AdditionalCommentsExcelRow implements ExcelRow {
    private ProductAdditionalCommentsSearchResult productAdditionalComments;
    public AdditionalCommentsExcelRow( ProductAdditionalCommentsSearchResult productAdditionalComments){
        this.productAdditionalComments=productAdditionalComments;
    }
    @Override
    public Object[] getExcelRowValues() {
        return new Object[]{
                productAdditionalComments.getProductPubkey(),
                productAdditionalComments.getCrop(),
                productAdditionalComments.getPreCommercialName(),
                productAdditionalComments.getVarietyName()==null?"":productAdditionalComments.getVarietyName(),
                productAdditionalComments.getAdditionalComments()==null?"":productAdditionalComments.getAdditionalComments()
        };
    }
}
