package com.monsanto.tcc.lexicon.competitiveproduct.repository;

import com.monsanto.tcc.lexicon.utils.xml.XmlRepositoryItemHeader;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Sep 21, 2004
 * Time: 10:57:23 AM
 * To change this template use File | Settings | File Templates.
 */
public class CompProdXmlRepositoryHeader
   implements XmlRepositoryItemHeader, Serializable
{
   private int _iBatchID;
   private String _strName;
   private int _numTotal;
   private int _numCommit;
   private int _numValid;
   private int _numError;
   private int _numAband;
   private int _numUnproc;
   private String _strUserId;
   private Date _dateEntry;

   protected CompProdXmlRepositoryHeader() {

   }
   CompProdXmlRepositoryHeader(
      CompProdBatchDAO dao)
   {
      _iBatchID  = dao.getID();
      _strName   = dao.getName();
      _numTotal  = dao.numTotal();
      _numCommit = dao.numCommitted();
      _numValid  = dao.numValid();
      _numError  = dao.numErrored();
      _numAband  = dao.numAbandoned();
      _numUnproc = dao.numUnprocessed();
      _strUserId = dao.getUserId();
      _dateEntry = dao.getEntryDate();
   }

   public int getBatchID() {
      return _iBatchID;
   }
   public String getName() {
      return _strName;
   }
   public int numTotal() {
      return _numTotal;
   }
   public int numCommitted() {
      return _numCommit;
   }
   public int numValidated() {
      return _numValid;
   }
   public int numErrored() {
      return _numError;
   }
   public int numAbandoned() {
      return _numAband;
   }
   public int numUnprocessed() {
      return _numUnproc;
   }
   public String getUserId() {
      return _strUserId;
   }
   public Date getEntryDate() {
      return _dateEntry;
   }

/*
   public CompProdBatchDAO getDAO()
   {
      return new CompProdBatchDAO(_iBatchID, _strName,
         _numTotal, _numCommit, _numValid, _numError, _numAband, _numUnproc, _dateEntry);
   }
*/
}
