/*
 Copyright:  Copyright � 2009 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.lexicon.baseproduct.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.tcc.lexicon.LexiconServlet.LexiconUseCaseController;
import com.monsanto.tcc.lexicon.baseproduct.audit.BaseProductWithProductRelationshipAudit;
import com.monsanto.tcc.lexicon.monsantoproduct.edit.controller.EditMonsantoProductPageConstants;
import com.monsanto.tcc.lexicon.utils.LexiconAppVersion;
import com.monsanto.tcc.lexicon.utils.audit.AuditConstants;
import com.monsanto.tcc.lexicon.utils.db.LexiconConnectionHelper;
import com.monsanto.tcc.lexiconcommon.metrics.Metrics;
import com.monsanto.tcc.lexiconcommon.metrics.SystemEKGMetrics;
import com.monsanto.tcc.lexiconcommon.user.LexSecureUserHelperImpl;

import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RLCASW
 * @version $Revision$
 */
public class BaseProductAuditUCC
   extends LexiconUseCaseController
{
   private final BaseProductWithProductRelationshipAudit audit;

   public BaseProductAuditUCC() {
      this(new BaseProductWithProductRelationshipAudit());
   }

   public BaseProductAuditUCC(BaseProductWithProductRelationshipAudit audit) {
      this.audit = audit;
   }

   @Override
   public void doService(UCCHelper helper)
      throws Throwable
   {
      Metrics metrics = new SystemEKGMetrics("ManufacturingName_Audit", (String)helper.getContextAttribute(LexiconAppVersion.VERSION),
         new LexSecureUserHelperImpl(helper));
      metrics.begin();
      try {
         PersistentStoreConnection conn = getConn();
         String baseManufactureName = helper.getRequestParameterValue(EditMonsantoProductPageConstants.BASE_MANF_NAME);

         try {
            Map entries = getProductWithAliasesAuditInfo(conn, baseManufactureName);
            helper.setRequestAttributeValue(AuditConstants.AUDIT_INFO_ENTRIES, entries);
         }
         finally {
            closeConn(conn);
         }


         helper.forward(AuditConstants.AUDIT_FORWARD);
      }
      finally {
         metrics.end();
      }
   }

   private Map getProductWithAliasesAuditInfo(PersistentStoreConnection conn, String baseManufacturingName)
      throws
      WrappingException
   {
      return audit.getBaseProductWithRelationshipsAuditInfo(conn, baseManufacturingName);
   }

   protected PersistentStoreConnection getConn()
      throws WrappingException
   {
      return LexiconConnectionHelper.getDefaultConnection();
   }

   protected void closeConn(PersistentStoreConnection conn)
      throws WrappingException
   {
      conn.close();
   }
}