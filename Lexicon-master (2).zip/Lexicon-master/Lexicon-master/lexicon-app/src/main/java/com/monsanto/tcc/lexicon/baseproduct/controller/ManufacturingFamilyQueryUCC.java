package com.monsanto.tcc.lexicon.baseproduct.controller;

import com.monsanto.tcc.lexicon.LexiconServlet.LexiconUseCaseController;
import com.monsanto.tcc.lexicon.baseproduct.dao.manufacturingfamily.ManufacturingFamilyDAO;
import com.monsanto.tcc.lexicon.baseproduct.dao.manufacturingfamily.ManufacturingFamilyDAOServiceImpl;
import com.monsanto.tcc.lexicon.baseproduct.model.BaseProductPageBean;
import com.monsanto.tcc.lexicon.baseproduct.model.ManufacturingFamilySearchRequest;
import com.monsanto.tcc.lexiconcommon.service.manufacturingfamily.search.model.ManufacturingFamily;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * User: pjberry
 * Date: Aug 21, 2007
 * Time: 4:01:18 PM
 */
public class ManufacturingFamilyQueryUCC
   extends LexiconUseCaseController
{
   private final ManufacturingFamilyDAO manufacturingFamilyDAO;

   public ManufacturingFamilyQueryUCC() {
      this( new ManufacturingFamilyDAOServiceImpl() );
   }

   public ManufacturingFamilyQueryUCC(ManufacturingFamilyDAO manufacturingFamilyDAO) {
      this.manufacturingFamilyDAO = manufacturingFamilyDAO;
   }

   public void doService(UCCHelper helper)
      throws Throwable
   {
      ManufacturingFamilySearchRequest searchRequest = (ManufacturingFamilySearchRequest)helper.getFormRequestData();
      ManufacturingFamily[] manufacturingFamilies = findMatchingProductFamilies(searchRequest);
      BaseProductPageBean pageBean = new BaseProductPageBean(manufacturingFamilies);

      helper.setSessionParameter(BaseProductPageBean.BEAN_ID, pageBean);
      helper.setSessionParameter(ManufacturingFamilySearchRequest.MANUFACTURING_FAMILY_SEARCH_REQUEST, searchRequest);
      helper.forward(getSuccessForward());
   }

   private ManufacturingFamily[] findMatchingProductFamilies(ManufacturingFamilySearchRequest searchRequest)
      throws WrappingException
   {
      return manufacturingFamilyDAO.findMatchingManufacturingFamilies(searchRequest.getNames(), searchRequest.getNameType());
   }
}
