/*
 EditManufacturingLineDAOServiceImpl was created on Jan 18, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.dao.manufacturingline.edit;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.lexicon.spring.ThreadLocalApplicationContext;
import com.monsanto.tcc.lexicon.utils.LogWriter;
import com.monsanto.tcc.lexiconcommon.service.manufacturingline.edit.EditManufacturingLineRequest;
import com.monsanto.tcc.lexiconcommon.service.manufacturingline.edit.EditManufacturingLineResponse;
import com.monsanto.tps.lexiconservices.manufacturing.line.edit.exceptions.EditManufacturingLineException;
import com.monsanto.tps.lexiconservices.manufacturing.line.edit.services.EditManufacturingLineService;
import org.apache.log4j.Category;
import org.springframework.context.ApplicationContext;

import java.util.*;

/**
 * nbwald Jan 18, 2008 12:42:27 PM
 */
public class EditManufacturingLineDAOServiceImpl
        implements EditManufacturingLineDAO {
    protected Category _log;

    public EditManufacturingLineDAOServiceImpl() {
        _log = LogWriter.getCategory(this);
    }

    public List<EditManufacturingLineResponse> execute(List<EditManufacturingLineRequest> batchRequest)
            throws WrappingException {
//      EditManufacturingLineServiceCall serviceCall = new EditManufacturingLineServiceCall();
//      return serviceCall.execute(batchRequest);
        _log.info("Before calling Lexicon_EditManufacturingLineService");
        List<EditManufacturingLineResponse> editManufacturingLineResponses = null;
        EditManufacturingLineService editManufacturingLineService = getEditManufacturingLineServiceBean();

        List<com.monsanto.tps.lexiconservices.manufacturing.line.edit.services.domain.EditManufacturingLineRequest> editManufacturingLineRequestList = new ArrayList<com.monsanto.tps.lexiconservices.manufacturing.line.edit.services.domain.EditManufacturingLineRequest>();
        editManufacturingLineRequestList = createEditManufacturingLineRequest(batchRequest);
        List<com.monsanto.tps.lexiconservices.manufacturing.line.edit.services.domain.EditManufacturingLineResponse> editManufacturingLineResponseList = new ArrayList<com.monsanto.tps.lexiconservices.manufacturing.line.edit.services.domain.EditManufacturingLineResponse>();
        try {
            if (null != editManufacturingLineRequestList && editManufacturingLineRequestList.size() > 0) {
                editManufacturingLineResponseList = editManufacturingLineService.processEditManufacturingLine(editManufacturingLineRequestList);
            }
            editManufacturingLineResponses = createEditManufacturingLineResponse(editManufacturingLineResponseList);

        } catch (EditManufacturingLineException ex) {
            _log.error("Error calling Lexicon_EditManufacturingLineService = " + ex.getMessage());
        }
        _log.info("Call to Lexicon_EditManufacturingLineService completed");
        return editManufacturingLineResponses;
    }

    private EditManufacturingLineService getEditManufacturingLineServiceBean() {
        ApplicationContext context = ThreadLocalApplicationContext.getApplicationContext();
        return (EditManufacturingLineService) context.getBean("editManufacturingLineService");
    }

    public List<EditManufacturingLineResponse> createEditManufacturingLineResponse(List<com.monsanto.tps.lexiconservices.manufacturing.line.edit.services.domain.EditManufacturingLineResponse> editManufacturingLineResponseList) {
        List<EditManufacturingLineResponse> editManufacturingLineResponses = new ArrayList<EditManufacturingLineResponse>();
        for (com.monsanto.tps.lexiconservices.manufacturing.line.edit.services.domain.EditManufacturingLineResponse editManufacturingLineResponse : editManufacturingLineResponseList) {
            EditManufacturingLineResponse editManufacturingLineRes = new EditManufacturingLineResponse(editManufacturingLineResponse.getMessages().toArray(new String[editManufacturingLineResponse.getMessages().size()]));
            editManufacturingLineResponses.add(editManufacturingLineRes);
        }
        return editManufacturingLineResponses;
    }

    public List<com.monsanto.tps.lexiconservices.manufacturing.line.edit.services.domain.EditManufacturingLineRequest> createEditManufacturingLineRequest(List<EditManufacturingLineRequest> batchRequest) {
        List<com.monsanto.tps.lexiconservices.manufacturing.line.edit.services.domain.EditManufacturingLineRequest> editManufacturingLineRequestList = new ArrayList<com.monsanto.tps.lexiconservices.manufacturing.line.edit.services.domain.EditManufacturingLineRequest>();
        for (EditManufacturingLineRequest editManufacturingLineRequest : batchRequest) {
            com.monsanto.tps.lexiconservices.manufacturing.line.edit.services.domain.EditManufacturingLineRequest editManufacturingLineReq = new com.monsanto.tps.lexiconservices.manufacturing.line.edit.services.domain.EditManufacturingLineRequest();
            editManufacturingLineReq.setNewManufacturingName(editManufacturingLineRequest.getNewManufacturingName());
            editManufacturingLineReq.setNewVarietyName(editManufacturingLineRequest.getNewVarietyName());
            editManufacturingLineReq.setTargetManufacturingName(editManufacturingLineRequest.getTargetManufacturingName());
            editManufacturingLineRequestList.add(editManufacturingLineReq);
        }
        return editManufacturingLineRequestList;
    }
}