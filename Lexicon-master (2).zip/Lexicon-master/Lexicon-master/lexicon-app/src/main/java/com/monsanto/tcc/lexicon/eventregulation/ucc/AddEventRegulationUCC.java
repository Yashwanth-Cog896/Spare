package com.monsanto.tcc.lexicon.eventregulation.ucc;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.tcc.lexicon.LexiconServlet.SimpleLexiconUCC;
import com.monsanto.tcc.lexicon.eventregulation.view.EventRegulationsBean;

/**
 * nbwald - Feb 2, 2009 5:05:33 PM
 */
public class AddEventRegulationUCC
   extends SimpleLexiconUCC
{
   @Override
   protected void executeAction(UCCHelper helper)
      throws Exception
   {
      EventRegulationsBean eventRegulationsBean = (EventRegulationsBean) helper.getSessionParameter(EventRegulationsBean.NAME);
      eventRegulationsBean.syncValuesFromRequest(helper);
      eventRegulationsBean.addEventRegulation();
   }
}
