package com.monsanto.tcc.lexicon.competitiveproduct.selectlistgen;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.tcc.lexicon.traitstack.model.TraitStackAlternateNameBean;
import com.monsanto.tcc.lexicon.typedata.bayer.BayerDAO;
import com.monsanto.tcc.lexicon.typedata.bayer.BayerDTO;
import com.monsanto.tcc.lexicon.typedata.trait.TraitStackDTO;
import com.monsanto.tcc.lexicon.utils.db.LexiconConnectionHelper;
import com.monsanto.tcc.lexicon.utils.gui.HtmlCell;
import com.monsanto.tcc.lexicon.utils.gui.HtmlRow;
import com.monsanto.tcc.lexicon.utils.gui.SelectDisplayValueList;
import com.monsanto.tcc.lexicon.utils.gui.SelectDisplayValuePair;
import com.monsanto.tcc.lexicon.utils.gui.TypeTableListGenerator;
import com.monsanto.tcc.lexicon.utils.gui.selectbuilder.TraitStackDisplayVisitor;
import com.monsanto.tcc.lexicon.utils.gui.selectbuilder.TraitStackSelectBuilderQuerySet;

/**
 * Created by IntelliJ IDEA.
 * User: adcox
 * Date: Jan 24, 2005
 * Time: 3:00:40 PM
 */
public class TraitGenerator
   implements TypeTableListGenerator
{
   public SelectDisplayValueList getSelectList(HtmlCell cell)
      throws WrappingException
   {
      SelectDisplayValueList selectList = new SelectDisplayValueList();
      PersistentStoreConnection conn = LexiconConnectionHelper.getDefaultConnection();
      try {
         HtmlRow row = cell.getParentRow();
         String countryAbbr = getRowsCountryAbbr(row);
         String bayerCode = getRowsBayerCode(row);
         BayerDAO daoBayer = BayerDAO.newInstance();
         BayerDTO dtoBayer = daoBayer.loadByCode(conn, bayerCode);
         if (dtoBayer != null) {
            String cropName = dtoBayer.getCropName();
            selectList = buildTraitStackSelectList(cropName, countryAbbr);
         }
      }
      finally {
         if (conn != null) {
            conn.close();
         }
      }
      return selectList;
   }

   private String getRowsCountryAbbr(HtmlRow row) {
      return row.getCell("countryName").getSelectedValue();
   }

   private String getRowsBayerCode(HtmlRow row) {
      return row.getCell("bayerCode").getContent();
   }

   public SelectDisplayValueList buildTraitStackSelectList(String cropName, final String countryAbbr)
      throws WrappingException
   {
      final SelectDisplayValueList selectList = new SelectDisplayValueList();
      new TraitStackDisplayVisitor(new TraitStackSelectBuilderQuerySet()) {
         @Override
         protected void beforeVisitingStacks()
            throws Exception
         {
            addSeparator();
         }

         @Override
         protected void visitStack(TraitStackDTO traitStack)
            throws Exception
         {
            addDisplayValuePair(traitStack.getName(), traitStack.getName());
         }

        protected void betweenVisitingStacks() throws Exception {
          addSeparator();
        }

        @Override
         protected void afterVisitedStacks()
            throws Exception
         {
            addSeparator();
         }

         @Override
         protected void visitAlternateName(TraitStackAlternateNameBean alternateName, String alternateNameDisplay)
            throws Exception
         {
            if(alternateName.hasCountry(countryAbbr)) {
               addDisplayValuePair(alternateNameDisplay, alternateName.getReportingName());
            }
         }

         private void addSeparator() {
            addDisplayValuePair("-----", "");
         }

         private void addDisplayValuePair(String display, String value) {
            selectList.add(new SelectDisplayValuePair(display, value));
         }
      }.visit(cropName);
      return selectList;
   }
}
