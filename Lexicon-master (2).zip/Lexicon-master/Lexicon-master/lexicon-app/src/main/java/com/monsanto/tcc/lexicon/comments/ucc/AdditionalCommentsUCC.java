package com.monsanto.tcc.lexicon.comments.ucc;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.tcc.lexicon.LexiconServlet.LexiconBlockingUseCaseController;
import com.monsanto.tcc.lexicon.comments.bean.CommentsProductSearchBean;
import com.monsanto.tcc.lexicon.comments.bean.ProductAdditionalCommentsBean;
import com.monsanto.tps.productstewardship.comments.service.ProductAdditionalCommentsNameType;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Oct 10, 2011
 * Time: 3:36:05 PM
 * To change this template use File | Settings | File Templates.
 */
public class AdditionalCommentsUCC   extends LexiconBlockingUseCaseController {
   @Override
   public void doService(UCCHelper helper)
      throws Throwable
   {
       
       CommentsProductSearchBean searchBean = (CommentsProductSearchBean)helper.getSessionParameter( "commentsProductSearchBean");
       if(searchBean==null){
            searchBean =  new CommentsProductSearchBean();
            searchBean.setNameTypes(Arrays.asList(ProductAdditionalCommentsNameType.values()));
            helper.setSessionParameter(AdditionalCommentsConstants.COMMENTS_PRODUCT_SEARCH_BEAN,searchBean);
       }

       helper.forward(getSuccessForward());
   }    
}
