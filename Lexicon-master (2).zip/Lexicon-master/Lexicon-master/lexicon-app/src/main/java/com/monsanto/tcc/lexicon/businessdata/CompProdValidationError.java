package com.monsanto.tcc.lexicon.businessdata;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Nov 2, 2004
 * Time: 11:27:15 AM
 * To change this template use File | Settings | File Templates.
 */
public class CompProdValidationError 
{
   private String msg;
   private Exception e;

   public CompProdValidationError(
      String msg)
   {
      this(msg, null);
   }
   
   public CompProdValidationError(
      String msg,
      Exception e)
   {
      this.msg = msg;
      this.e = e;
   }

   public String getMessage() {
      return msg;
   }
   public Exception getException() {
      return e;
   }
}
