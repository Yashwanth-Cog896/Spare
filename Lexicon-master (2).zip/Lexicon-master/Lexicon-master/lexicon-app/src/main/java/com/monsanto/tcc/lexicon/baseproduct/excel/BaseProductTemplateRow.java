/*
 BaseProductTemplateRow was created on Oct 2, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.excel;

import com.monsanto.tcc.lexiconcommon.file.excel.ExcelRow;
import com.monsanto.Util.StringUtils;

/**
 * nbwald Oct 2, 2007 12:52:38 PM
 */
public class BaseProductTemplateRow {
    private final String baseManufacturingName;
    private final String cropName;
    private final boolean parentProduct;
    private final String manufacturingName;
    private final String parentFlag;
    private final boolean blend;

    public BaseProductTemplateRow(ExcelRow row) {
        Object[] rowValues = normalize(row.getExcelRowValues());
        baseManufacturingName = getValue(rowValues, 0);
        cropName = getValue(rowValues, 1);
        parentFlag = getValue(rowValues, 2);
        parentProduct = parseBooleanFromYesNo(getValue(rowValues, 2));
        manufacturingName = getValue(rowValues, 3);
        blend = parseBooleanFromYesNo(getValue(rowValues, 4));
    }

    public String getBaseManufacturingName() {
        return baseManufacturingName;
    }

    public String getCropName() {
        return cropName;
    }

    public boolean isParentProduct() {
        return parentProduct;
    }

    public String getManufacturingName() {
        return manufacturingName;
    }

    public boolean isBlend() {
        return blend;
    }

    private String[] normalize(Object[] values) {
        String[] normalizedValues = new String[values.length];
        for (int i = 0; i < values.length; i++) {
            normalizedValues[i] = normalize(values[i]);
        }
        return normalizedValues;
    }

    private String getValue(Object[] values, int i) {
        Object value = i < values.length ? values[i] : null;
        return value == null ? null : value.toString();
    }

    private String normalize(Object s) {
        return s == null ? null : StringUtils.trimNullable(StringUtils.toUpperCaseNull(s.toString()));
    }

    private boolean parseBooleanFromYesNo(String value) {
        return "YES".equals(value);
    }

    public String getParentFlag() {
        return parentFlag;
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        BaseProductTemplateRow row = (BaseProductTemplateRow) o;
        return StringUtils.areEqual(getBaseManufacturingName(), row.getBaseManufacturingName())
                && StringUtils.areEqual(getCropName(), row.getCropName())
                && StringUtils.areEqual(getParentFlag(), row.getParentFlag())
                && StringUtils.areEqual(getManufacturingName(), row.getManufacturingName());
    }

    public int hashCode() {
        int result;
        result = hash(getBaseManufacturingName());
        result = 31 * result + hash(getCropName());
        result = 31 * result + hash(getParentFlag());
        result = 31 * result + hash(getManufacturingName());
        return result;
    }

    private int hash(String a) {
        return a == null ? 0 : a.hashCode();
    }
}