/*
 Copyright:  Copyright � 2009 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.lexicon.baseproduct.audit;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.tcc.lexicon.baseproduct.dao.BaseProductDAO;
import com.monsanto.tcc.lexicon.baseproduct.queryset.model.BaseProduct;
import com.monsanto.tcc.lexicon.baseproduct.queryset.query.BaseProductByBaseNameQuery;
import com.monsanto.tcc.lexicon.baseproduct.queryset.query.BaseProductByBaseNameQueryImpl;
import com.monsanto.tcc.lexicon.utils.audit.AuditDAO;
import com.monsanto.tcc.lexicon.utils.audit.AuditInfo;
import com.monsanto.tcc.lexicon.utils.audit.AuditUtil;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RLCASW
 * @version $Revision$
 */
public class BaseProductAudit
{

   public static final String PRODUCT_TABLE_NAME = "BASE_PRODUCT";
   public static final String PRODUCT_TABLE_DESCRIP = "Base Product";
   public static final String PRODUCT_LEADER = "BP_";


   private final BaseProductDAO baseProductDAO;
   private final AuditDAO auditDAO;
   private final BaseProductByBaseNameQuery query;
   private final AuditUtil auditUtil;

   public BaseProductAudit() {
      this(BaseProductDAO.newInstance(), AuditDAO.newInstance(), new AuditUtil(), new BaseProductByBaseNameQueryImpl());
   }

   public BaseProductAudit(BaseProductDAO baseProductDAO, AuditDAO auditDAO, AuditUtil auditUtil, BaseProductByBaseNameQuery query) {

      this.baseProductDAO = baseProductDAO;
      this.auditDAO = auditDAO;
      this.auditUtil = auditUtil;
      this.query = query;
   }

   public Map getBaseProductAuditInfoMap(PersistentStoreConnection conn, String baseManufactureName)
      throws WrappingException
   {
      Map entries = new LinkedHashMap();
      entries.put(PRODUCT_LEADER + baseManufactureName, getBaseProductAuditInfo(conn, baseManufactureName));
      return entries;
   }

   public AuditInfo getBaseProductAuditInfo(PersistentStoreConnection conn, String baseManufactureName)
      throws WrappingException
   {
      BaseProduct product = getBaseProduct(baseManufactureName);
      return product == null ? null : getProductAuditInfo(conn, product);
   }

   public AuditInfo getProductAuditInfo(PersistentStoreConnection conn, BaseProduct product)
      throws WrappingException
   {
      String primaryKey = getPrimarykeyFromBaseManufactureName(conn, product.getBaseManufacturingName());
      AuditInfo auditInfo = getAuditInfo(conn, primaryKey);
      auditInfo.setDescription(auditUtil.getDescription(conn, PRODUCT_TABLE_NAME, primaryKey));
      auditInfo.setTableDescription(PRODUCT_TABLE_DESCRIP);
      return auditInfo;
   }

   protected BaseProduct getBaseProduct(String baseManufacturingName)
      throws WrappingException
   {
      return query.getBaseProduct(baseManufacturingName);
   }

   protected AuditInfo getAuditInfo(PersistentStoreConnection conn, String primaryKey)
      throws WrappingException
   {
      return auditDAO.getAuditInfo(conn, PRODUCT_TABLE_NAME, primaryKey);
   }

   private String getPrimarykeyFromBaseManufactureName(PersistentStoreConnection conn, String baseManufacturingName)
      throws WrappingException
   {
      return baseProductDAO.getPrimaryKeyFromBaseManufacturingName(conn, baseManufacturingName);
   }
}