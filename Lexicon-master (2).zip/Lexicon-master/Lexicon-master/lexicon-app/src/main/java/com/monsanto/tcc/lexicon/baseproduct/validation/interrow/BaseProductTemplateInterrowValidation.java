/*
 BaseProductTemplateInterrowValidation was created on Oct 11, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.validation.interrow;

import com.monsanto.tcc.lexicon.baseproduct.excel.BaseProductTemplateRow;
import com.monsanto.tcc.lexicon.baseproduct.validation.AbstractBaseProductTemplateErrorCollector;
import com.monsanto.tcc.lexicon.baseproduct.validation.BaseProductTemplateRule;

/**
 * nbwald Oct 11, 2007 4:27:47 PM
 */
public class BaseProductTemplateInterrowValidation
   extends AbstractBaseProductTemplateErrorCollector
{
   private final BaseProductTemplateRow rowA;
   private final BaseProductTemplateRow rowB;

   public BaseProductTemplateInterrowValidation(BaseProductTemplateRow rowA, BaseProductTemplateRow rowB) {
      this.rowA = rowA;
      this.rowB = rowB;
   }

   protected BaseProductTemplateRule[] getRules() {
      return new BaseProductTemplateRule[] {
         new NoDuplicateRowsRule(rowA, rowB),
         new BaseProductsParentFlagIsConsistentRule(rowA, rowB),
         new BaseProductsCropIsConsistentRule(rowA, rowB),
         new NoDuplicateManfNameRule(rowA, rowB),
         new BaseProductAlwaysOrNeverHasManfNamesRule(rowA, rowB),
      };
   }
}