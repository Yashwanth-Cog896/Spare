package com.monsanto.tcc.lexicon.controllers;

//import com.monsanto.AbstractLogging.LoggableError;
//import com.monsanto.AbstractLogging.Logger;
import com.monsanto.tcc.lexicon.LexiconServlet.LexiconUseCaseController;
import com.monsanto.tcc.lexicon.controllers.beans.FileLister;
import com.monsanto.tcc.lexicon.utils.LogWriter;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;
import org.apache.log4j.Logger;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: JASKIDI
 * Date: Jul 12, 2004
 * Time: 10:15:12 AM
 * To change this template use File | Settings | File Templates.
 */
public class FileListerUCC
   extends LexiconUseCaseController
{
   private static final String LEADER = " (";

   public void doService(UCCHelper helper) throws Throwable {
      FileLister vpf = loadFileListerFromRequest(helper);

      try {
         vpf.setStatus(null);
         helper.removeRequestAttribute(PATHLIST);
         helper.removeRequestAttribute(FILELIST);

         if ("Save".equals(vpf.getSubmit())) {
            save(vpf);
            vpf.setStatus("Saved file: " + vpf.getFileName());
         }
         else if("Create Directory".equals(vpf.getSubmit())) {
            createDirectory(vpf);
         }
         vpf.setContent(null);

         // Get filename, set to root if empty, create file
         String strFile    = vpf.getFileName();
         if (strFile == null) {
            strFile = "/";
            vpf.setFileName(strFile);
         }

         File file = new File(strFile);

         // If file not found, try to find property file & back into fully
         // qualified filename.
         if (!file.exists()) {
            log_.debug("file not found, checking url.");
            String str = strFile;
            if (! str.startsWith("/")) {
               str = "/" + strFile;
            }
            URL url = this.getClass().getResource(str);
            if (url != null) {
               log_.debug("search url for file: " + url.getFile());
               file = new File(url.getFile());
               if (file.exists()) {
                  strFile = file.getAbsolutePath();
                  vpf.setFileName(strFile);
               }
            }
         }

         if (file.isDirectory()) {
            loadPathLists(file, helper);
            vpf.setViewPaths("true");
         }
         else {
            vpf.setViewPaths(null);
            vpf.setContent(getFileContents(file).toString());
         }
      }
      catch (Throwable t) {
         log_.error(t.getMessage(), t);
         vpf.setStatus(t.getMessage() + " (" + t.getClass().getName() + ")");
      }


      helper.forward("/FileLister.jsp");
   }

   private FileLister loadFileListerFromRequest(UCCHelper helper) throws IOException {
      FileLister lister = new FileLister();
      String fileName = helper.getRequestParameterValue("fileName");

      // trim off inbound file size
      if (!StringUtils.isNullOrEmpty(fileName)) {
         int i = fileName.indexOf(LEADER);
         if (i >= 0) {
            fileName = fileName.substring(0, i);
         }
      }

      lister.setFileName(fileName);
      lister.setContent(helper.getRequestParameterValue("content"));
      lister.setSubmit(helper.getRequestParameterValue("submitBtn"));

      if ("yes".equals(helper.getRequestParameterValue("deleteFile"))) {
         lister.setDeleteFile(true);
      }

      helper.setRequestAttributeValue("FileLister", lister);

      return lister;
   }


   class CaseInsensitive implements Comparator {
      public int compare (Object o1, Object o2) {
         return o1.toString().compareToIgnoreCase(o2.toString());
      }
   }

   private static final String FILELIST = "filelist";
	private static final String PATHLIST = "pathlist";

	private Logger log_;

   public FileListerUCC() {
      log_ = LogWriter.getCategory(this);
   }

	/**
    * @param helper
    */
   private void loadPathLists(File fileIn, UCCHelper helper) {
      String strParentDir = null;
      if (fileIn.getParent () != null) {
         strParentDir = fileIn.getParent();
      }

      String [] astr = fileIn.list();

      List lstDirs  = new ArrayList();
      List lstFiles = new ArrayList();

      File file;
      String strPath = fileIn.getAbsolutePath();
      if (! (strPath.endsWith("/") || strPath.endsWith(File.separator))) {
         strPath = strPath + "/";
      }

      for (int i = 0; i < astr.length; i++) {
         file = new File(strPath + astr [i]);

         if (file.isDirectory ()) {
            lstDirs.add(file.getAbsoluteFile());
         } else {
            lstFiles.add(file.getAbsoluteFile() + LEADER + file.length() + ")");
         }
      }

      Comparator comp = new CaseInsensitive();
      Collections.sort (lstDirs, comp);
      Collections.sort (lstFiles, comp);

      if (strParentDir != null) {
         lstDirs.add(0, strParentDir);
      }

      helper.setRequestAttributeValue(PATHLIST, lstDirs);
      helper.setRequestAttributeValue(FILELIST, lstFiles);
   }

	/**
	 * @param file
	 */
	private StringBuffer getFileContents(File file)
   throws IOException
   {
      StringBuffer sb = new StringBuffer();

      BufferedReader in = new BufferedReader(new FileReader(file));

      String strLine;

      while ((strLine = in.readLine ()) != null) {
         sb.append (strLine);
         sb.append ("\n");
      }

      in.close ();

      return sb;
	}

	/**
	 * @param vpf
    */
	private void save(FileLister vpf) throws IOException {
      FileWriter out = new FileWriter(vpf.getFileName());
      out.write (vpf.getContent(), 0, vpf.getContentLength());
      out.close ();

      if (vpf.isDeleteFile() && vpf.getContent().length() == 0) {
         File file = new File(vpf.getFileName());
         file.delete();
      }
	}

   private void createDirectory(FileLister vpf) {
      File file = new File(vpf.getFileName());
      if(file.exists()) {
         vpf.setStatus("Cannot create directory.  File or directory already exists.");
      }
      else {
         file.mkdir();
         vpf.setStatus("Created directory.");
      }
   }
}
