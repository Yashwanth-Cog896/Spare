package com.monsanto.tcc.lexicon.competitiveproduct.repository;

import com.monsanto.tcc.lexicon.utils.LogWriter;
import com.monsanto.tcc.lexicon.utils.db.LexiconConnectionHelper;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.EmptyResultSetException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.dataservices.PersistentStoreResultSetSingleResult;
import com.monsanto.dataservices.PersistentStoreStatement;
import org.apache.log4j.Category;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Sep 9, 2004
 * Time: 12:57:33 PM
 * To change this template use File | Settings | File Templates.
 */
public class CompProdBatchDAOFinder
{
   private Category _log = LogWriter.getCategory(getClass());

   public List findAll(
      PersistentStoreConnection conn)
      throws WrappingException
   {
      List list = new ArrayList();
      String strSql = CompProdBatchDAOUtil.getInstance().getSQL(
         CompProdBatchDAOUtil.SELECT_ALL, _log);

      PersistentStoreStatement stmt = null;
      try {
         stmt = conn.prepareStatement(strSql);
         PersistentStoreResultSetFwdIterator iter = stmt.executeQuery().getForwardIterator();
         while(iter.next()) {
            list.add(new CompProdBatchDAO(iter));
         }
      }
      finally {
         LexiconConnectionHelper.closeStatement(stmt, _log);
      }
      return list;
   }
   
   public List findAllByUser(
      PersistentStoreConnection conn,
      String strUserId)
      throws WrappingException
   {
      List list = new ArrayList();
      String strSql = CompProdBatchDAOUtil.getInstance().getSQL(
         CompProdBatchDAOUtil.SELECT_ALL_BYUSER, _log);

      PersistentStoreStatement stmt = null;
      try {
         stmt = conn.prepareStatement(strSql);
         stmt.setParam(1, strUserId);
         PersistentStoreResultSetFwdIterator iter = stmt.executeQuery().getForwardIterator();
         while(iter.next()) {
            list.add(new CompProdBatchDAO(iter));
         }
      }
      finally {
         LexiconConnectionHelper.closeStatement(stmt, _log);
      }
      return list;
   }

   public CompProdBatchDAO findByPrimaryKey(
      PersistentStoreConnection conn,
      int iBatchId)
      throws WrappingException
   {
      String strSql = CompProdBatchDAOUtil.getInstance().getSQL(
         CompProdBatchDAOUtil.SELECT_BY_PK, _log);

      PersistentStoreStatement stmt = null;
      try {
         stmt = conn.prepareStatement(strSql);
         stmt.setParam(1, iBatchId);

         PersistentStoreResultSetSingleResult rs = stmt.executeQuery().getSingleResult();
         return new CompProdBatchDAO(rs);
      }
      catch (EmptyResultSetException e) {
         return null;
      }
      finally {
         LexiconConnectionHelper.closeStatement(stmt, _log);
      }
   }

   public CompProdBatchDAO findByName(
      PersistentStoreConnection conn,
      String name)
      throws WrappingException
   {
      String strSql = CompProdBatchDAOUtil.getInstance().getSQL(
         CompProdBatchDAOUtil.SELECT_BY_NAME, _log);

      PersistentStoreStatement stmt = null;
      try {
         stmt = conn.prepareStatement(strSql);
         stmt.setParam(1, name);

         PersistentStoreResultSetSingleResult rs = stmt.executeQuery().getSingleResult();
         return new CompProdBatchDAO(rs);
      }
      catch (EmptyResultSetException e) {
         return null;
      }
      finally {
         LexiconConnectionHelper.closeStatement(stmt, _log);
      }
   }
}
