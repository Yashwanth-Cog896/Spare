/*
 BaseProductBeanLocator was created on Aug 2, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.action.locator;

import com.monsanto.tcc.lexicon.baseproduct.model.BaseProductBean;
import com.monsanto.tcc.lexicon.baseproduct.model.BaseProductPageBean;
import com.monsanto.tcc.lexicon.baseproduct.model.ProductRelationshipBean;

/**
 * nbwald Aug 2, 2007 3:54:23 PM
 */
public class BaseProductBeanLocatorImpl
   implements BaseProductBeanLocator
{
   private final BaseProductPageBean pageBean;
   private final String target;

   private static final int BASE_PRODUCT_LEVEL = 0;
   private static final int PRODUCT_RELATIONSHIP_LEVEL = 1;

   public BaseProductBeanLocatorImpl(BaseProductPageBean pageBean, String target) {
      this.pageBean = pageBean;
      this.target = target;
   }

   public BaseProductPageBean getPageBean() {
      return pageBean;
   }

   public BaseProductBean getBaseProductBean() {
      int currentTarget = getTarget(BASE_PRODUCT_LEVEL);
      return getPageBean().getBaseProducts().get(currentTarget);
   }

   public ProductRelationshipBean getProductRelationshipBean() {
      int currentTarget = getTarget(PRODUCT_RELATIONSHIP_LEVEL);
      return getBaseProductBean().getProductRelationshipBeans().get(currentTarget);
   }

   private int getTarget(int level) {
      return Integer.parseInt(target.split(":")[level]);
   }
}