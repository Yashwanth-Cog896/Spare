/*
 BeanLocatingBaseProductAction was created on Aug 6, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.action;

import com.monsanto.tcc.lexicon.baseproduct.action.locator.BaseProductBeanLocator;
import com.monsanto.tcc.lexicon.baseproduct.model.BaseProductBean;
import com.monsanto.tcc.lexicon.baseproduct.model.BaseProductPageBean;
import com.monsanto.tcc.lexicon.baseproduct.model.ProductRelationshipBean;

/**
 * nbwald Aug 6, 2007 10:16:58 AM
 */
public abstract class BeanLocatingBaseProductAction
   implements BaseProductAction
{
   private final BaseProductBeanLocator beanLocator;

   protected BeanLocatingBaseProductAction(BaseProductBeanLocator beanLocator) {
      this.beanLocator = beanLocator;
   }

   public BaseProductPageBean getPageBean() {
      return beanLocator.getPageBean();
   }

   public BaseProductBean getBaseProductBean() {
      return beanLocator.getBaseProductBean();
   }

   public ProductRelationshipBean getProductRelationshipBean() {
      return beanLocator.getProductRelationshipBean();
   }
}