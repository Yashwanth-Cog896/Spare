package com.monsanto.tcc.lexicon.baseproduct.dao.manufacturingline.create;

import com.monsanto.tcc.lexiconcommon.pos.LexiconServiceInvoker;
import com.monsanto.tcc.lexiconcommon.pos.ServiceInvoker;
import com.monsanto.tcc.lexiconcommon.pos.batch.BatchModelServiceCall;
import com.monsanto.tcc.lexiconcommon.service.productrelationship.create.CreateProductRelationshipRequest;
import com.monsanto.tcc.lexiconcommon.service.productrelationship.create.CreateProductRelationshipRequestSerializer;
import com.monsanto.tcc.lexiconcommon.service.productrelationship.create.CreateProductRelationshipResponse;
import com.monsanto.tcc.lexiconcommon.service.productrelationship.create.CreateProductRelationshipResponseSerializer;

/**
 * User: pjberry
 * Date: Aug 10, 2007
 * Time: 11:18:35 AM
 */
public class CreateProductRelationshipServiceCall
   extends BatchModelServiceCall<CreateProductRelationshipRequest, CreateProductRelationshipResponse>
{
   protected CreateProductRelationshipRequestSerializer getRequestSerializer() {
      return new CreateProductRelationshipRequestSerializer();
   }

   protected ServiceInvoker getServiceInvoker() {
     return new LexiconServiceInvoker("Lex_CreateProductRelationships");
   }

   protected CreateProductRelationshipResponseSerializer getResponseSerializer() {
      return new CreateProductRelationshipResponseSerializer();
   }
}
