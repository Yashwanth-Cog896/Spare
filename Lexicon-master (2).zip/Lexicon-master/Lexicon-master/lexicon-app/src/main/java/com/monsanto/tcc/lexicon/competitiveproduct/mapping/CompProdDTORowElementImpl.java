package com.monsanto.tcc.lexicon.competitiveproduct.mapping;

import com.monsanto.tcc.lexicon.businessdata.CompProdDTO;
import com.monsanto.tcc.lexicon.templates.type.RowStatusType;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Nov 3, 2004
 * Time: 4:02:43 PM
 * To change this template use File | Settings | File Templates.
 */
public class CompProdDTORowElementImpl
   implements CompProdDTO
{
   private Element row;
   private static CompProdXmlUtils cpXmlUtil = new CompProdXmlUtils();

   public static Element constructRowFromDTO(
      Document doc,
      CompProdDTO dto,
      int rownum)
   {
      Element elemRow =cpXmlUtil.createRowNode(
         doc.getDocumentElement(), rownum,
         dto.isActive(), false, false, dto.getPublicKey(), dto.getProductPublicKey());

      cpXmlUtil.createBayerCodeNode(elemRow, dto.getBayerCode());
      cpXmlUtil.createProductNameNode(elemRow, dto.getProductName());
      cpXmlUtil.createBrandNode(elemRow, dto.getBrandName());
      cpXmlUtil.createCountryNode(elemRow, dto.getCountryName());
      cpXmlUtil.createComlMatNode(elemRow, dto.getCommercialMaturity());
      cpXmlUtil.createCharacteristicTraits(elemRow, dto.getCharacteristicTraits());
      cpXmlUtil.createSourceVerifiedNode(elemRow, dto.getSourceVerified());
      cpXmlUtil.createSourceYearNode(elemRow, dto.getSourceYear());

      cpXmlUtil.createCommentNode(elemRow, dto.getComments());

      // TODO: Get User Id/Logon Name from resultset once dust settles on auditing mechanism
      cpXmlUtil.createAuditNode(elemRow, "Change Me");//iter.getString(CompProdDAO.USER_ID_ALIAS));
      cpXmlUtil.createStatusNode(elemRow, RowStatusType.EXISTS.getName(), null, null);

      return elemRow;
   }

   public CompProdDTORowElementImpl(
      Element elemRow)
   {
      row = elemRow;
   }

   public String getPublicKey() {
      return cpXmlUtil.getPublicKey(row);
   }
   public String getProductPublicKey() {
      return cpXmlUtil.getProductPublicKey(row);
   }
   public void setPublicKey(String publicKey) {
      cpXmlUtil.setPublicKey(row, publicKey);
   }
   public void setProductPublicKey(String publicKey) {
      cpXmlUtil.setProductPublicKey(row, publicKey);
   }

   public boolean isActive() {
      return cpXmlUtil.isActive(row);
   }
   public String getBayerCode() {
      return cpXmlUtil.getBayerCode(row);
   }
   public String getProductName() {
      return cpXmlUtil.getProductName(row);
   }
   public String getBrandName()    {
      return cpXmlUtil.getBrand(row);
   }
   public String getCountryName() {
      return cpXmlUtil.getCountry(row);
   }
   public String getCommercialMaturity() {
      return cpXmlUtil.getComlMatString(row);
   }
   public String getCharacteristicTraits() {
      return cpXmlUtil.getCharacteristicTraits(row);
   }
   public String getTraitAttributes() {
      return cpXmlUtil.getTraitAttributes(row);
   }
   public String getSourceVerified() {
      return cpXmlUtil.getSourceVerified(row);
   }
   public String getSourceYear() {
      return cpXmlUtil.getSourceYear(row);
   }
   public String getRequestor() {
      return cpXmlUtil.getRequestor(row);

   }
   public String getComments() {
       return cpXmlUtil.getComments(row);
   }
}
