/*
 Copyright:  Copyright � 2009 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.lexicon.baseproduct.dao;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.tcc.lexicon.baseproduct.model.ProductRelationship;

import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RLCASW
 * @version $Revision$
 */
public abstract class BaseProductDAO
{

   public static BaseProductDAO newInstance() {
      return new OraBaseProductDAO();
   }

   public abstract String getPrimaryKeyFromBaseManufacturingName(PersistentStoreConnection conn, String manufacturingName)
      throws WrappingException;

   public abstract List<ProductRelationship> getProductRelationshipsForBaseManufactureName(PersistentStoreConnection conn, String baseManufactureName)
      throws
      WrappingException;
}