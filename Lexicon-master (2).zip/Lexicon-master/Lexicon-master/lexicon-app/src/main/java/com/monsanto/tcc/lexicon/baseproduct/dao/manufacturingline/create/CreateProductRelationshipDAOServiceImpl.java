/*
 CreateProductRelationshipDAOServiceImpl was created on Aug 7, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.dao.manufacturingline.create;

import com.monsanto.tcc.lexiconcommon.service.productrelationship.create.CreateProductRelationshipRequest;
import com.monsanto.tcc.lexiconcommon.service.productrelationship.create.CreateProductRelationshipResponse;
import com.monsanto.Util.Exceptions.WrappingException;
import java.util.List;

/**
 * nbwald Aug 7, 2007 5:45:43 PM
 */
public class CreateProductRelationshipDAOServiceImpl
   implements CreateProductRelationshipDAO
{
   public List<CreateProductRelationshipResponse> execute(
      List<CreateProductRelationshipRequest> request)
      throws WrappingException
   {
      CreateProductRelationshipServiceCall serviceCall = new CreateProductRelationshipServiceCall();
      return serviceCall.execute(request);
   }
}