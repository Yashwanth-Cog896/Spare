package com.monsanto.tcc.lexicon.competitiveproduct.mapping;



/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Aug 26, 2004
 * Time: 10:31:46 AM
 * To change this template use File | Settings | File Templates.
 */
public interface ICompProdColDefs
   extends CompProdXmlTags
{
   String[] ELEMENT_NAMES = new String[]
   {
      BAYER_ELEM, PROD_ELEM, BRAND_ELEM, COUNTRY_ELEM,
      LINE_TYPE_ELEM, COM_MAT_ELEM, TRAITS_ELEM, PROG_CODE_ELEM,
      VERIF_DS_ELEM, DS_YEAR_ELEM, REQUESTOR_ELEM, COMMENT_ELEM,
      AUDIT_COMMENT_ELEM
   };

   // template columns used for template validation
   String[] TEMPLATE_COLUMNS = new String[]
   {
      "Bayer Code", "Product Name", "Brand", "Country",
      "Line Type", "CM", "Traits", "GP Owner",
      "Source Verified", "Source Year", "Requester", "Comments",
      null
   };

   boolean[] ELEMENT_REQUIRED = {
      true, true, true, true,
      true, true, true, true,
      true, true, true, true,
      false
   };

   boolean[] COLUMNS_TO_UPPER = new boolean[]
   {
      true, true, true, true,
      true, false, true, true,
      true, true, false, false,
      false
   };
}
