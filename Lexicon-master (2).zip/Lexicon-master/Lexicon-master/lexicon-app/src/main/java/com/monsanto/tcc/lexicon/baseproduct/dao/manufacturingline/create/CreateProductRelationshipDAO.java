/*
 CreateProductRelationshipDAO was created on Aug 7, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.dao.manufacturingline.create;

import com.monsanto.tcc.lexiconcommon.pos.ModelServiceCall;
import com.monsanto.tcc.lexiconcommon.service.productrelationship.create.CreateProductRelationshipRequest;
import com.monsanto.tcc.lexiconcommon.service.productrelationship.create.CreateProductRelationshipResponse;
import java.util.List;

/**
 * nbwald Aug 7, 2007 3:37:17 PM
 */
public interface CreateProductRelationshipDAO
   extends ModelServiceCall<List<CreateProductRelationshipRequest>, List<CreateProductRelationshipResponse>>
{
}