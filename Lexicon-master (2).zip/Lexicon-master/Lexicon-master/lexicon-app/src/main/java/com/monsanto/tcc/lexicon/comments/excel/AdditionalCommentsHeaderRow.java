package com.monsanto.tcc.lexicon.comments.excel;

import com.monsanto.tcc.lexiconcommon.file.excel.ExcelRow;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Oct 19, 2011
 * Time: 9:42:35 AM
 * To change this template use File | Settings | File Templates.
 */
public class AdditionalCommentsHeaderRow  implements ExcelRow {
    public static final String PRODUCT_KEY = "Product Key";
    public static final String PRE_COML_NAME = "Pre Coml Name";
    public static final String VARIETY_NAME = "Variety Name";
    public static final String CROP = "Crop";
    public static final String ADDITIONAL_COMMENTS = "Additional Comments";

    @Override
    public Object[] getExcelRowValues() {
        return new Object[]{
                PRODUCT_KEY,
                CROP,
                PRE_COML_NAME,
                VARIETY_NAME,
                ADDITIONAL_COMMENTS
        };
    }
}
