package com.monsanto.tcc.lexicon.competitiveproduct.mapping;

import com.monsanto.tcc.lexicon.competitiveproduct.mapping.RowObject;

/**
 * nbwald - Nov 12, 2009 1:30:27 PM
 */
public class ProgramOwnerComparator
   extends StringMethodComparator
{
   @Override
   public String eval(RowObject rowObject) {
      return rowObject.getProgramOwner();
   }
}
