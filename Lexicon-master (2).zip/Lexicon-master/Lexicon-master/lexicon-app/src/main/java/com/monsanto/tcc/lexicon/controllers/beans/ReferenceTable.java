package com.monsanto.tcc.lexicon.controllers.beans;

import com.monsanto.tcc.lexicon.competitiveproduct.beans.GridContainer;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: adcox
 * Date: Nov 5, 2004
 * Time: 11:55:42 AM
 * To change this template use File | Settings | File Templates.
 */
public class ReferenceTable
   extends GridContainer
   implements Serializable
{
   public static final String NAME = "ReferenceTable";

   private String id;
   private String title;
   private String entityName;
   private String loadedCount;
   private String action;
   private String publicKey;
   private boolean canModify;

   public String getTitle() {
      return title;
   }

   public void setTitle(String title) {
      this.title = title;
   }

   public String getId() {
      return id;
   }

   public void setId(String id) {
      this.id = id;
   }

   public String getEntityName() {
      return entityName;
   }

   public void setEntityName(String entityName) {
      this.entityName = entityName;
   }

   public String getLoadedCount() {
      return loadedCount;
   }

   public void setLoadedCount(String loadedCount) {
      this.loadedCount = loadedCount;
   }

   public String getAction() {
      return action;
   }

   public void setAction(String action) {
      this.action = action;
   }

   public String getPublicKey() {
      return publicKey;
   }

   public void setPublicKey(String publicKey) {
      this.publicKey = publicKey;
   }

   public boolean getCanModify() {
      return canModify;
   }

   public void setCanModify(boolean userInReqdAppRole) {
      this.canModify = userInReqdAppRole;
   }
}
