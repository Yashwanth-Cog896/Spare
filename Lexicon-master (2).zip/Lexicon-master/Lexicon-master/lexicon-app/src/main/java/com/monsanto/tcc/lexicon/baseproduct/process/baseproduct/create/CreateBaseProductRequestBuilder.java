/*
 CreateBaseProductRequestBuilder was created on Jul 2, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.process.baseproduct.create;

import com.monsanto.tcc.lexicon.baseproduct.model.BaseProductBean;
import com.monsanto.tcc.lexicon.typedata.queryset.ReferenceDataQuerySet;
import com.monsanto.tcc.lexiconcommon.pos.batch.ServiceRequestBuilder;
import com.monsanto.tcc.lexiconcommon.service.baseproduct.CreateBaseProductRequest;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald Jul 2, 2007 10:54:34 AM
 */
public class CreateBaseProductRequestBuilder
   implements ServiceRequestBuilder<BaseProductBean, CreateBaseProductRequest>
{
   private final ReferenceDataQuerySet querySet;

   public CreateBaseProductRequestBuilder(ReferenceDataQuerySet querySet) {
      this.querySet = querySet;
   }

   public CreateBaseProductRequest buildRequest(final BaseProductBean baseProduct)
      throws WrappingException
   {
      String cropPubkey = querySet.getCropPubkeyByName(baseProduct.getCrop());
      return new CreateBaseProductRequest(
         baseProduct.getBaseManufacturingName(), cropPubkey, baseProduct.isParentProduct());
   }
}