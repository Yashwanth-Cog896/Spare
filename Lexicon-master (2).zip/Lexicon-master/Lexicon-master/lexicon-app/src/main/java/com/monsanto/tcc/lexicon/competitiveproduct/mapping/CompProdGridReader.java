package com.monsanto.tcc.lexicon.competitiveproduct.mapping;

import com.monsanto.tcc.lexicon.templates.reader.GridReader;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Mar 29, 2005
 * Time: 11:00:45 AM
 * To change this template use File | Settings | File Templates.
 */
public interface CompProdGridReader
   extends GridReader
{
   String getPublicKey(int iRowNum);
   String getProductPublicKey(int iRowNum);
}
