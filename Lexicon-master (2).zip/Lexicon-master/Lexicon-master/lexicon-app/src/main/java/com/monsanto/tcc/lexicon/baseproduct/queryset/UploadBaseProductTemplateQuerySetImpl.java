/*
 UploadBaseProductTemplateQuerySetImpl was created on Oct 22, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.queryset;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.lexicon.baseproduct.dao.manufacturingfamily.ManufacturingFamilyDAO;
import com.monsanto.tcc.lexicon.baseproduct.dao.manufacturingfamily.ManufacturingFamilyDAOServiceImpl;
import com.monsanto.tcc.lexicon.baseproduct.queryset.model.BaseProduct;
import com.monsanto.tcc.lexicon.baseproduct.queryset.query.AuthorizedCropNameQueryImpl;
import com.monsanto.tcc.lexicon.baseproduct.queryset.query.BaseProductByBaseNameQuery;
import com.monsanto.tcc.lexicon.baseproduct.queryset.query.BaseProductByBaseNameQueryImpl;
import com.monsanto.tcc.lexicon.baseproduct.queryset.query.CropNameQuery;
import com.monsanto.tcc.lexiconcommon.service.manufacturingfamily.search.model.ManufacturingFamily;
import com.monsanto.tcc.lexiconcommon.service.manufacturingfamily.search.model.ManufacturingFamilySearchType;

/**
 * nbwald Oct 22, 2007 12:33:53 PM
 */
public class UploadBaseProductTemplateQuerySetImpl
   implements UploadBaseProductTemplateQuerySet
{
   private final BaseProductByBaseNameQuery baseProductQuery;
   private final CropNameQuery cropNameQuery;
   private final ManufacturingFamilyDAO manfFamilyDAO;

   public UploadBaseProductTemplateQuerySetImpl() {
      this(new BaseProductByBaseNameQueryImpl(), new AuthorizedCropNameQueryImpl(), new ManufacturingFamilyDAOServiceImpl());
   }

   public UploadBaseProductTemplateQuerySetImpl(BaseProductByBaseNameQuery baseProductQuery, CropNameQuery cropNameQuery, ManufacturingFamilyDAO manfFamilyDAO) {
      this.baseProductQuery = baseProductQuery;
      this.cropNameQuery = cropNameQuery;
      this.manfFamilyDAO = manfFamilyDAO;
   }

   public BaseProduct getBaseProduct(String baseManufacturingName) {
      return baseProductQuery.getBaseProduct(baseManufacturingName);
   }

   public boolean isValid(String cropName) {
      return cropNameQuery.isValid(cropName);
   }

   public ManufacturingFamily[] getManufacturingFamilies(String[] baseManfNames) {
      String baseManfNamesType = ManufacturingFamilySearchType.BASE_MANF_NAMES.toString();
      try {
         return manfFamilyDAO.findMatchingManufacturingFamilies(baseManfNames, baseManfNamesType);
      }
      catch (WrappingException e) {
         throw new RuntimeException(e);
      }
   }
}