/*
 EditManufacturingLineBatchFilter was created on Jan 22, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.process.manufacturingline.edit;

import com.monsanto.tcc.lexicon.baseproduct.model.EditableProductRelationship;
import com.monsanto.tcc.lexiconcommon.pos.batch.InputModelBatchFilter;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald Jan 22, 2008 11:05:50 AM
 */
public class EditManufacturingLineBatchFilter
   implements InputModelBatchFilter<EditableProductRelationship>
{
   public boolean includeModel(EditableProductRelationship inputModel)
      throws WrappingException
   {
      return inputModel.isEditable();
   }
}