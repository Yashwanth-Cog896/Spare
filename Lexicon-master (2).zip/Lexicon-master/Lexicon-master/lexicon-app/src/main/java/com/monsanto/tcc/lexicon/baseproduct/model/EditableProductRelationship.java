/*
 EditableProductRelationship was created on Jan 18, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.model;

import com.monsanto.tcc.lexiconcommon.service.manufacturingline.edit.EditManufacturingLineResponse;

/**
 * nbwald Jan 18, 2008 2:54:15 PM
 */
public interface EditableProductRelationship
{
   String getTargetManufacturingName();
   String getNewManufacturingName();
   String getNewVarietyName();
   boolean isEditable();
   void update(EditManufacturingLineResponse response);
}