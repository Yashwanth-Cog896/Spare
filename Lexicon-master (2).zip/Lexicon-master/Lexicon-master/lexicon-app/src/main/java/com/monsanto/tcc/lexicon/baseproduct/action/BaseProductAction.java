/*
 BaseProductAction was created on Aug 2, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.action;

import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald Aug 2, 2007 10:11:05 AM
 */
public interface BaseProductAction {
   String getActionName();
   void handle()
      throws WrappingException;
}