package com.monsanto.tcc.lexicon.eventregulation.query;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;

import java.util.List;

/**
 * nbwald - Feb 10, 2009 11:16:43 PM
 */
public class EventRegulationPrimaryKeysByEventNameQuery
   extends AbstractPersistentStoreMultiRowQuery
{
   private String eventName;

   public EventRegulationPrimaryKeysByEventNameQuery(String eventName) {
      this.eventName = eventName;
   }

   public String[] find()
      throws WrappingException
   {
      List<String> list = getList();
      return list.toArray(new String[list.size()]);
   }

   @Override
   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return row.getString(1);
   }

   @Override
   protected String getSQL()
      throws WrappingException
   {
      return "SELECT event_agency_alignment_id FROM Lexicon.Event_Agency_Alignment WHERE event = ?";
   }

   @Override
   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { eventName };
   }

   @Override
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
}
