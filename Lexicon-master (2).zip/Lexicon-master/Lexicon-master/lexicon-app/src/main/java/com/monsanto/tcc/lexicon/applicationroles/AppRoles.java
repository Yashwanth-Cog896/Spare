package com.monsanto.tcc.lexicon.applicationroles;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.lexicon.spring.ThreadLocalApplicationContext;
import com.monsanto.tps.lexicon.user.UserPrivilegesService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.ServletContext;
import java.io.Serializable;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Apr 14, 2005
 * Time: 9:50:45 AM
 */
public class AppRoles
   implements Serializable
{
   public static final String NAME = "AppRoles";

   public static final String ROLE_CP_ACCESS = "CPAccess";
   public static final String ROLE_CP_EDIT = "CPEdit";
   public static final String ROLE_LEX_REF_TABLE_ACCESS = "LexRefTableAccess";
   public static final String ROLE_LEX_REF_TABLE_EDIT = "LexRefTableEdit";
   public static final String ROLE_PRECOML_ACCESS = "PreComlAccess";
   public static final String ROLE_PRECOML_EDIT = "PreComlEdit";
   public static final String ROLE_PRECOML_NAME_EDIT = "PreComlNameEdit";
   public static final String ROLE_GERMPLASM_ACCESS = "GermplasmAccess";
   public static final String ROLE_SHOW_ALL_GP_FIELDS = "ShowAllGPFields";
   public static final String ROLE_COML_ACCESS = "ComlAccess";
   public static final String ROLE_COML_EDIT = "ComlEdit";
   public static final String ROLE_MON_PROD_EQUIV_MAINT = "MonProdEquivMaint";
   public static final String ROLE_MON_PROD_EQUIV_ACCESS = "MonProdEquivAccess";
   public static final String ROLE_IT_ADMIN = "ITAdmin";
   public static final String ROLE_PRODUCT_COLLAPSE = "ProductCollapse";
   public static final String ROLE_PRODUCT_COLLAPSE_AUDIT = "ProductCollapseAudit";
// TODO nbwald REMOVE WHEN WE FIND A NEW HEALTH CHECK MECHANISM
//   public static final String ROLE_HEALTHCHECK_ACCESS = "HealthCheck";
   public static final String ROLE_TRAIT_STACK_ACCESS = "TraitStackAccess";
   public static final String ROLE_TRAIT_STACK_EDIT = "TraitStackEdit";
   public static final String ROLE_UNASSIGN_COML_NAME = "UnassignComlName";
   public static final String ROLE_AUDIT_REPORT_ACCESS = "AuditReportAccess";
   public static final String ROLE_REG_REF_TABLE_EDIT = "RegRefTableEdit";
   public static final String ROLE_VARIETY_NAME_EDIT = "VarietyNameEdit";
   public static final String ROLE_PROD_BULK_LOAD_ACCESS = "ProdBulkLoadAccess";
   public static final String ROLE_ADDITIONAL_COMMENTS_EDIT = "AdditionalCommentsEdit";
    public static final String ROLE_ADDITIONAL_COMMENTS_VIEW = "AdditionalCommentsView";
   public static final String INBRED_ACCESS = "InbredAccess";

   protected Set<String> roles;

   protected AppRoles() {
   }

   public AppRoles(UCCHelper helper)
      throws WrappingException
   {

      ApplicationContext context = ThreadLocalApplicationContext.getApplicationContext();
      UserPrivilegesService userPrivilegesService = (UserPrivilegesService) context.getBean("userPrivilegesService");
      String[] roles = userPrivilegesService.getRoles(helper.getAuthenticatedUserID());
      this.roles = new HashSet<String>(roles == null ? Arrays.<String>asList() : Arrays.asList(roles));
   }

   public Set<String> getRoles() {
      return roles;
   }

   public boolean isUserInAppRole(String ... roles) {
      boolean inRole = false;
      for(String role: roles){
         inRole = this.roles.contains(role);
         if(inRole){
            break;
         }
      }
      return inRole;
   }

}
