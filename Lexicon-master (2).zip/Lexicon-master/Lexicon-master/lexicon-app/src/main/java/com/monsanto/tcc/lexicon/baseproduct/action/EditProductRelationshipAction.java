/*
 EditProductRelationshipAction was created on Jan 17, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.action;

import com.monsanto.tcc.lexicon.baseproduct.action.locator.BaseProductBeanLocator;
import com.monsanto.tcc.lexicon.baseproduct.model.ProductRelationshipBean;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald Jan 17, 2008 2:57:36 PM
 */
public class EditProductRelationshipAction
   extends BeanLocatingBaseProductAction
{
   public static final String ACTION_NAME = "EditProductRelationshipAction";

   public EditProductRelationshipAction(BaseProductBeanLocator beanLocator) {
      super(beanLocator);
   }

   public String getActionName() {
      return ACTION_NAME;
   }

   public void handle()
      throws WrappingException
   {
      ProductRelationshipBean relationship = getProductRelationshipBean();
      relationship.edit();
   }
}