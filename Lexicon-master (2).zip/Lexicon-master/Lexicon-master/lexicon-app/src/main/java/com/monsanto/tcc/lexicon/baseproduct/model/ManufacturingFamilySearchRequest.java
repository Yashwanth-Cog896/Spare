package com.monsanto.tcc.lexicon.baseproduct.model;

import com.monsanto.tcc.lexiconcommon.service.manufacturingfamily.search.model.ManufacturingFamilySearchType;
import com.monsanto.ServletFramework.FormRequestData;
import com.monsanto.Util.StringUtils;

/**
 * User: pjberry
 * Date: Aug 22, 2007
 * Time: 11:49:46 AM
 */
public class ManufacturingFamilySearchRequest
   implements FormRequestData
{
   public static final String MANUFACTURING_FAMILY_SEARCH_REQUEST = "ManufacturingFamilySearchRequest";

   private String namesCSV;
   private String nameType;
   
   public String[] getNames() {
      return StringUtils.isNullOrEmpty(namesCSV) ? new String[0] : StringUtils.splitCsv(namesCSV, true);
   }

   public String getNamesCSV() {
      return namesCSV;
   }

   public void setNamesCSV(String namesCSV) {
      this.namesCSV = StringUtils.trimNullable(StringUtils.toUpperCaseNull(namesCSV));
   }

   public String getNameType() {
      return nameType;
   }

   public void setNameType(String nameType) {
      this.nameType = nameType;
   }

   public boolean isBaseManufacturingNameType() {
      return nameType != null && nameType.equals(ManufacturingFamilySearchType.BASE_MANF_NAMES.toString());
   }

   public boolean isManufacturingNameType() {
      return nameType != null && nameType.equals(ManufacturingFamilySearchType.MANF_NAMES.toString());
   }
}
