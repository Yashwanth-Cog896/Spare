/*
 CropNameValidator was created on Oct 8, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.queryset.query;

/**
 * nbwald Oct 8, 2007 2:19:22 PM
 */
public interface CropNameQuery
{
   boolean isValid(String cropName);
}