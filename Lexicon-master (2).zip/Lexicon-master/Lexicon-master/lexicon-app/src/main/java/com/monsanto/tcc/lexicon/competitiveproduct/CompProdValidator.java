package com.monsanto.tcc.lexicon.competitiveproduct;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.tcc.lexicon.businessdata.CompProdBO;
import com.monsanto.tcc.lexicon.businessdata.CompProdDAO;
import com.monsanto.tcc.lexicon.businessdata.CompProdDTO;
import com.monsanto.tcc.lexicon.businessdata.CompProdValidationError;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.CompProdDTORowElementImpl;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.CompProdXmlTags;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.CompProdXmlUtils;
import com.monsanto.tcc.lexicon.competitiveproduct.types.CompProdLineType;
import com.monsanto.tcc.lexicon.templates.dom.TemplateRowStatistics;
import com.monsanto.tcc.lexicon.templates.type.RowStatusType;
import com.monsanto.tcc.lexicon.typedata.trait.TraitStackDTO;
import com.monsanto.tcc.lexicon.utils.LogWriter;
import com.monsanto.tcc.lexiconcommon.exception.RuntimeWrappingException;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.util.HashSet;
import java.util.List;


/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Aug 25, 2004
 * Time: 11:42:18 AM
 */
public class CompProdValidator
   implements CompProdXmlTags
{
   public static final String BATCH_MATCH_NAME_ERROR = "The batch already contains a matching product name";
   public static final String GEN_PROD_KEY_ERROR = "An unexpected error occurred while attempting to validate the product key";
   public static final String PROD_REPARENT_ERROR = "This change would cause the association between Product and Product Name to change, which is not allowed.";

   private HashSet setTuples;
   private CompProdXmlUtils cpXmlUtil = new CompProdXmlUtils();
   private Logger log;

   public CompProdValidator() {
      log = LogWriter.getCategory(this);
   }

   public void validateAndSetStatus(
      Document doc,
      PersistentStoreConnection conn)
   {
      validateAndSetStatus(doc, conn, false);
   }
   
   public void validateCommitsAndSetStatus(
      Document doc,
      PersistentStoreConnection conn)
   {
      validateAndSetStatus(doc, conn, true);
   }

   public void validateAndSetStatus(
      Document doc,
      PersistentStoreConnection conn,
      boolean isCommitOnly)
   {
      NodeList nodeList = doc.getDocumentElement().getElementsByTagName(ROW_ELEM);
      setTuples = new HashSet(nodeList.getLength());

      Element elemRow;
      String strStatus = null;
      TemplateRowStatistics stats = new TemplateRowStatistics();

      for (int i = 0; i < nodeList.getLength(); i++) {
         elemRow = (Element)nodeList.item(i);
         strStatus = cpXmlUtil.getStatusString(elemRow);

         if (
             (!isCommitOnly && RowStatusType.UNPROCESSED.equals(strStatus)) ||
             ( isCommitOnly && RowStatusType.VALIDATED.equals(strStatus))
            )
         {
            //_log.info("process row: " + i);
            cpXmlUtil.cleanStatusNode(elemRow);
            processRow(elemRow, conn);
         }

         strStatus = cpXmlUtil.getStatusString(elemRow);
         stats.incrementStatusCount(strStatus);
      }
      cpXmlUtil.createStatsNode(doc.getDocumentElement(), stats);
   }

   private void processRow(
      Element elemRow,
      PersistentStoreConnection conn)
   {
      //TODO: Look at removing these checks
      validateLineType(elemRow);
      validateCM(elemRow);
      validateCharacteristicTraits(elemRow, conn);

      CompProdBO bo = new CompProdBO(new CompProdDTORowElementImpl(elemRow));
      List listError = bo.validate(conn);

      for (int i = 0; i < listError.size(); i++) {
         cpXmlUtil.addError(elemRow,
            ((CompProdValidationError)listError.get(i)).getMessage());
      }

      if (0 == cpXmlUtil.getErrorNodes(elemRow).getLength()) {
         validateDuplicateProductNameInBatch(elemRow, conn);
//         if (cpXmlUtil.isEditing(elemRow) && 0 == cpXmlUtil.getErrorNodes(elemRow).getLength()) {
//               validateProductPublicKey(elemRow, conn);
//         }
      }
   }

   private void validateDuplicateProductNameInBatch(
      Element elemRow,
      PersistentStoreConnection conn)
   {
      UniquenessTuple tuple = new UniquenessTuple(elemRow);
      if (!tuple.hasNulls()) {
         if (setTuples.contains(tuple)) {
            cpXmlUtil.addError(elemRow, BATCH_MATCH_NAME_ERROR);
         }
         else {
            setTuples.add(tuple);
         }
      }
   }


/*
   private void validateDuplicateProductLevelInBatch(
      Element elemRow)
   {
      UniquenessTuple setTuple;
      UniquenessTuple tuple = new UniquenessTuple(elemRow);
      Iterator iter = setTuples.iterator();

      while (iter.hasNext()) {
         setTuple = (UniquenessTuple)iter.next();
         if (setTuple.isMatchingProduct(tuple) && !setTuple.equals(tuple) &&
             !setTuple.getProductPubKey().equals(cpXmlUtil.getProductPublicKey(elemRow)))
         {
            cpXmlUtil.addError(elemRow, PROD_REPARENT_ERROR);
            setTuples.remove(new UniquenessTuple(elemRow));
            break;
         }
      }
   }
*/


/*
   protected void validateProductPublicKey(
      Element elemRow,
      PersistentStoreConnection conn)
   {
      try {
         List listMatching = getMatchingProductLevelProducts(elemRow, conn);
         if (listMatching != null && listMatching.size() > 0) {
            validateMatchingProductsAreSameProduct(elemRow, listMatching);
         }
         else {
//            validateNoSiblingProducts(elemRow, conn);
         }

         if (0 == cpXmlUtil.getErrorNodes(elemRow).getLength()) {
            validateDuplicateProductLevelInBatch(elemRow);
         }
      }
      catch (WrappingException e) {
         log.error(GEN_PROD_KEY_ERROR, e);
         cpXmlUtil.addError(elemRow, GEN_PROD_KEY_ERROR);
      }
   }

   private List getMatchingProductLevelProducts(
      Element elemRow,
      PersistentStoreConnection conn)
      throws WrappingException
   {
      CompProdDAO dao = CompProdDAO.newInstance();
      return dao.loadByProductLevel(conn,
         cpXmlUtil.getPreComlName(elemRow),
         cpXmlUtil.getBayerCode(elemRow),
         cpXmlUtil.getBrand(elemRow));
   }

   private void validateMatchingProductsAreSameProduct(
      Element elemRow,
      List listMatching)
   {
      CompProdDTO dto;
      for (int i = 0; i < listMatching.size(); i++) {
         dto = (CompProdDTO)listMatching.get(i);
         if (!dto.getProductPublicKey().equals(cpXmlUtil.getProductPublicKey(elemRow))) {
            cpXmlUtil.addError(elemRow, PROD_REPARENT_ERROR);
            setTuples.remove(new UniquenessTuple(elemRow));
            break;
         }
      }
   }

   private void validateNoSiblingProducts(
      Element elemRow,
      PersistentStoreConnection conn)
      throws WrappingException
   {
      CompProdDAO dao = CompProdDAO.newInstance();
      List listMatching = dao.loadByProductPubkey(conn, cpXmlUtil.getProductPublicKey(elemRow));
      if (listMatching.size() > 1) {
         cpXmlUtil.addError(elemRow, PROD_REPARENT_ERROR);
         setTuples.remove(new UniquenessTuple(elemRow));
      }
   }
*/

   private void validateLineType(Element elemRow)
   {
      String strLineType = cpXmlUtil.getLineType(elemRow);
      if (!StringUtils.isNullOrEmpty(strLineType)) {
         CompProdLineType lineType = CompProdLineType.fromName(strLineType);
         if(lineType == null) {
            cpXmlUtil.addError(elemRow, strLineType + " is not an accepted line type for competitive products");
         }
      }
   }

   private void validateCM(Element elemRow)
   {
      String str = cpXmlUtil.getComlMatString(elemRow);
      if (!StringUtils.isNullOrEmpty(str)) {
         try {
            Double d = new Double(cpXmlUtil.getComlMatString(elemRow));
         }
         catch (NumberFormatException e) {
            cpXmlUtil.addError(elemRow, "Commercial maturity must be numeric.");
         }
      }
   }

   private void validateCharacteristicTraits(Element elemRow, PersistentStoreConnection conn) {
      CompProdDTO compProd = new CompProdDTORowElementImpl(elemRow);
      try {
         TraitStackDTO traitStack = CompProdDAO.newInstance().getTraitStack(conn, compProd);
         CompProdTraitsMayNotBePrecommercialRule rule = new CompProdTraitsMayNotBePrecommercialRule(traitStack);
         if(rule.violated()) {
            cpXmlUtil.addError(elemRow, rule.getViolation());
         }
      }
      catch (WrappingException e) {
         throw new RuntimeWrappingException(e);
      }
   }

   class UniquenessTuple
      implements CompProdXmlTags

   {
      private String productName;
      private String bayerCode;
      private String countryName;
      private String brandName;
      private String productPubKey;
      private boolean hasNulls;

      UniquenessTuple(Element elemRow)
      {
         productName = cpXmlUtil.getProductName(elemRow);
         bayerCode = cpXmlUtil.getBayerCode(elemRow);
         countryName = cpXmlUtil.getCountry(elemRow);
         brandName = cpXmlUtil.getBrand(elemRow);
         productPubKey = cpXmlUtil.getProductPublicKey(elemRow);

         hasNulls =
            StringUtils.isNullOrEmpty(productName) ||
            StringUtils.isNullOrEmpty(bayerCode) ||
            StringUtils.isNullOrEmpty(countryName) ||
            StringUtils.isNullOrEmpty(brandName);
      }

      public String getProductName() {
         return productName;
      }
      public String getBayerCode() {
         return bayerCode;
      }
      public String getCountry() {
         return countryName;
      }
      public String getBrand() {
         return brandName;
      }
      public String getProductPubKey() {
         return productPubKey;
      }
      public boolean hasNulls() {
         return hasNulls;
      }

      public int hashCode()
      {
         return productName.hashCode() +
                bayerCode.hashCode() +
                countryName.hashCode() +
                brandName.hashCode();
      }

      public boolean isMatchingProduct(UniquenessTuple tuple)
      {
         if (hasNulls() || tuple.hasNulls()) {
            return false;
         }
         else {
            return (productName.equals(tuple.productName) &&
                    bayerCode.equals(tuple.bayerCode) &&
                    brandName.equals(tuple.brandName));
         }
      }

      public boolean equals(Object obj)
      {
         if (obj instanceof UniquenessTuple) {
            UniquenessTuple tuple = (UniquenessTuple)obj;
            if (hasNulls() || tuple.hasNulls()) {
               return false;
            }
            else {
               return (productName.equals(tuple.productName) &&
                       bayerCode.equals(tuple.bayerCode) &&
                       countryName.equals(tuple.countryName) &&
                       brandName.equals(tuple.brandName));
            }
         }
         else {
            return false;
         }
      }
   }
}

