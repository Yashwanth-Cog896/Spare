/*
 BaseProductByBaseNameQueryImpl was created on Oct 24, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.queryset.query;

import com.monsanto.tcc.lexicon.baseproduct.queryset.model.BaseProduct;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * nbwald Oct 24, 2007 5:04:53 PM
 */
public class BaseProductByBaseNameQueryImpl
   implements BaseProductByBaseNameQuery
{
   public BaseProduct getBaseProduct(String baseManufacturingName)
   {
      Query query = new Query(baseManufacturingName);
      try {
         return query.getBaseProduct();
      }
      catch (WrappingException e) {
         throw new RuntimeException(e);
      }
   }

   private class Query
      extends AbstractPersistentStoreSingleResultQuery
   {
      private final String baseManufacturingName;

      Query(String baseManufacturingName) {
         this.baseManufacturingName = baseManufacturingName;
      }

      public BaseProduct getBaseProduct()
         throws WrappingException
      {
         return (BaseProduct) execute();
      }

      protected Object createObjectFromRow(PersistentStoreResultSetRow row)
         throws WrappingException
      {
         return new BaseProductPSRowImpl(row);
      }

      protected String getSQL()
         throws WrappingException
      {
         return new SQLPropFile(BaseProductByBaseNameQuerySQL.class).getSQL(BaseProductByBaseNameQuerySQL.SELECT_BY_BASE_NAME);
      }

      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[] { baseManufacturingName };
      }

      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new LexiconConnectionFactoryProperties();
      }
   }

   
}