package com.monsanto.tcc.lexicon.competitiveproduct.beans;

import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: adcox
 * Date: Oct 12, 2004
 * Time: 1:36:41 PM
 * To change this template use File | Settings | File Templates.
 */
public class CompProdQuery
   extends GridContainer
   implements Serializable
{
   private String crops;
   private String countries;
   private String brands;
   private String traits;
   private String productNames;
   private String submitBtn;
   private String rowCountMsg;
   private String prodNamePubKey;
   private String rowCount;
   private boolean traitAnd;
   private boolean fromSrcJsp;

   public static final String NAME = "CompProdQuery";

   public String getCrops() {
      return crops;
   }

   public void setCrops(String crops) {
      this.crops = crops;
   }

   public String getCountries() {
      return countries;
   }

   public void setCountries(String countries) {
      this.countries = countries;
   }

   public String getBrands() {
      return brands;
   }

   public void setBrands(String brands) {
      this.brands = brands;
   }

   public String getTraits() {
      return traits;
   }

   public void setTraits(String traits) {
      this.traits = traits;
   }

   public String getProductNames() {
      return productNames;
   }

   public void setProductNames(String productNames) {
      this.productNames = productNames;
   }

   public boolean isTraitAnd() {
      return traitAnd;
   }

   public void setTraitAnd(boolean traitAnd) {
      this.traitAnd = traitAnd;
   }

   public String getSubmitBtn() {
      return submitBtn;
   }

   public void setSubmitBtn(String submitBtn) {
      this.submitBtn = submitBtn;
   }

   public String getRowCountMsg() {
      return rowCountMsg;
   }

   public void setRowCountMsg(String rowCountMsg) {
      this.rowCountMsg = rowCountMsg;
   }

   public String getProdNamePubKey() {
      return prodNamePubKey;
   }

   public void setProdNamePubKey(String prodNamePubKey) {
      this.prodNamePubKey = prodNamePubKey;
   }

   public String getRowCount() {
      return rowCount;
   }

   public void setRowCount(String rowCount) {
      this.rowCount = rowCount;
   }

   public boolean isFromSrcJsp() {
      return fromSrcJsp;
   }

   public void setFromSrcJsp(boolean fromSrcJsp) {
      this.fromSrcJsp = fromSrcJsp;
   }
}
