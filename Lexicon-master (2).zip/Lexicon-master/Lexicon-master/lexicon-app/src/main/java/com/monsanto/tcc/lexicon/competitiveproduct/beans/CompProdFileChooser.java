package com.monsanto.tcc.lexicon.competitiveproduct.beans;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Aug 18, 2004
 * Time: 11:33:48 AM
 * To change this template use File | Settings | File Templates.
 */
public class CompProdFileChooser
{
   public static final String ATTR_NAME = "CompProdFileChooser";

   private String errorMessage;
   private String associatedName;
   private List   fileList;

   public CompProdFileChooser() {
      fileList = new ArrayList();
   }

   public String getErrorMessage() {
      return errorMessage;
   }
   public void setErrorMessage(String errorMessage) {
      this.errorMessage = errorMessage;
   }

   public String getAssociatedName() {
      return associatedName;
   }
   public void setAssociatedName(String associatedName) {
      this.associatedName = associatedName;
   }

   public List getFileList() {
      return fileList;
   }
   public void setFileList(List fileList) {
      this.fileList = fileList;
   }
}
