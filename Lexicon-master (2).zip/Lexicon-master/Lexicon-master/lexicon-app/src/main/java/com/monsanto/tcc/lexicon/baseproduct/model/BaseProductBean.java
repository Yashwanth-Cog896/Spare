package com.monsanto.tcc.lexicon.baseproduct.model;

import com.monsanto.tcc.lexicon.baseproduct.excel.BaseProductTemplateRow;
import com.monsanto.tcc.lexicon.genericbean.model.BeanState;
import com.monsanto.tcc.lexicon.genericbean.model.HierarchicalBean;
import com.monsanto.tcc.lexicon.utils.messages.TextList;
import com.monsanto.tcc.lexiconcommon.ArrayUtils;
import com.monsanto.tcc.lexiconcommon.service.manufacturingfamily.search.model.ManufacturingFamily;
import com.monsanto.tcc.lexiconcommon.service.manufacturingfamily.search.model.ManufacturingLineLevelResponse;
import com.monsanto.Util.StringUtils;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * User: pjberry
 * Date: Jun 27, 2007
 * Time: 5:55:48 PM
 */
public class BaseProductBean
   implements HierarchicalBean
{
   private String baseManufacturingName;
   private String crop;
   private boolean parentProduct;
   private String[] errors = new String[0];
   private BeanState state;
   private LinkedList<ProductRelationshipBean> productRelationshipBeans = new LinkedList<ProductRelationshipBean>();

   public BaseProductBean() {
      this.state = BeanState.EDITING;
   }

   public BaseProductBean(ManufacturingFamily manufacturingFamily) {
      this.baseManufacturingName = manufacturingFamily.getBaseProduct().getBaseManufacturingName();
      this.crop = manufacturingFamily.getBaseProduct().getCropName();
      this.parentProduct = manufacturingFamily.getBaseProduct().isParentProduct();
      setProductRelationshipBeans(manufacturingFamily.getManufacturingLines());
      this.state = BeanState.UNMODIFIABLE;
   }

   public BaseProductBean(BaseProductTemplateRow templateRow, boolean existing) {
      this.baseManufacturingName = templateRow.getBaseManufacturingName();
      this.crop = templateRow.getCropName();
      this.parentProduct = templateRow.isParentProduct();
      this.state = existing ? BeanState.UNMODIFIABLE : BeanState.EDITING;
   }

   private void setProductRelationshipBeans(ManufacturingLineLevelResponse[] manufacturingLines) {
      for (ManufacturingLineLevelResponse manufacturingLine : manufacturingLines) {
         productRelationshipBeans.add(new ProductRelationshipBean(manufacturingLine));
      }
   }

   public String getBaseManufacturingName() {
      return baseManufacturingName;
   }

   public void setBaseManufacturingName(String baseManufacturingName) {
      this.baseManufacturingName = baseManufacturingName;
   }

   public String getCrop() {
      return crop;
   }

   public void setCrop(String crop) {
      this.crop = crop;
   }

   public boolean isParentProduct() {
      return parentProduct;
   }

   public void setParentProduct(boolean parentProduct) {
      this.parentProduct = parentProduct;
   }

   public void update(String[] errors) {
      if(ArrayUtils.hasItems(errors)) {
         this.state = BeanState.ERRED;
         for (ProductRelationshipBean productRelationshipBean : productRelationshipBeans) {
            productRelationshipBean.parentErred();
         }
      }
      else {
         this.state = BeanState.COMMITTED;
      }
      this.errors = errors;
   }

   public BeanState getState() {
      return state;
   }

   public String getErrors() {
      return new TextList(errors).toString();
   }

   public void setState(BeanState state) {
      this.state = state;
   }

   public boolean isCommitable() {
      return state.isCommitable();
   }

   public boolean isEditing() {
      return BeanState.EDITING.equals(state);
   }

   public boolean isCommitted() {
      return BeanState.COMMITTED.equals(state);
   }

   public boolean isErred() {
      return BeanState.ERRED.equals(state);
   }

   public boolean isUnmodifiable() {
      return BeanState.UNMODIFIABLE.equals(state);
   }

   public void createProductRelationship() {
      productRelationshipBeans.addFirst(new ProductRelationshipBean());
   }

   public void createProductRelationship(BaseProductTemplateRow templateRow) {
      String manfName = templateRow.getManufacturingName();
      ProductRelationshipBean relationship = findRelationship(manfName);
      if(relationship == null && !StringUtils.isNullOrEmpty(manfName)) {
         productRelationshipBeans.addFirst(new ProductRelationshipBean(manfName,templateRow.isBlend()));
      }
   }

   private ProductRelationshipBean findRelationship(String manufacturingName) {
      for (ProductRelationshipBean relationship : productRelationshipBeans) {
         if(StringUtils.areEqual(relationship.getManufacturingName(), manufacturingName)) {
            return relationship;
         }
      }
      return null;
   }

   public ProductRelationshipBean appendProductRelationship(String manufacturingName) {
      ProductRelationshipBean relationship = new ProductRelationshipBean();
      relationship.setManufacturingName(manufacturingName);
      productRelationshipBeans.add(relationship);
      return relationship;
   }

   public List<ProductRelationshipBean> getProductRelationshipBeans() {
      return productRelationshipBeans;
   }

   public void removeProductRelationship(ProductRelationshipBean productRelationship) {
      productRelationshipBeans.remove(productRelationship);
   }

   public HierarchicalBean getChild(int i) {
      return productRelationshipBeans.get(i);
   }

   public List<CreateableProductRelationship> getCreateableProductRelationships() {
      List<CreateableProductRelationship> createableProductRelationships = new ArrayList<CreateableProductRelationship>();
      for (ProductRelationshipBean productRelationshipBean : productRelationshipBeans) {
         createableProductRelationships.add(new CreateableProductRelationshipImpl(this, productRelationshipBean));
      }
      return createableProductRelationships;
   }

   public List<EditableProductRelationship> getEditableProductRelationships() {
      List<EditableProductRelationship> editableProductRelationships = new ArrayList<EditableProductRelationship>();
      for (ProductRelationshipBean productRelationshipBean : productRelationshipBeans) {
         editableProductRelationships.add(new EditableProductRelationshipImpl(this, productRelationshipBean));
      }
      return editableProductRelationships;
   }
}
