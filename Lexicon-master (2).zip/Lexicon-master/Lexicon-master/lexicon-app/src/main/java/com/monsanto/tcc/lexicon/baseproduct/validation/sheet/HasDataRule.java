/*
 HasDataRule was created on Oct 12, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.validation.sheet;

import com.monsanto.tcc.lexicon.baseproduct.validation.BaseProductTemplateError;
import com.monsanto.tcc.lexicon.baseproduct.validation.BaseProductTemplateRule;
import com.monsanto.tcc.lexiconcommon.ArrayUtils;
import com.monsanto.tcc.lexiconcommon.file.excel.ExcelSheet;

/**
 * nbwald Oct 12, 2007 2:35:09 PM
 */
public class HasDataRule
   implements BaseProductTemplateRule
{
   private final ExcelSheet excelSheet;

   public HasDataRule(ExcelSheet excelSheet) {
      this.excelSheet = excelSheet;
   }

   public boolean violated() {
      return ArrayUtils.isNullOrEmpty(excelSheet.getData());
   }

   public BaseProductTemplateError getViolation() {
      return BaseProductTemplateError.NO_DATA;
   }
}