package com.monsanto.tcc.lexicon.controllers;

import com.monsanto.tcc.lexicon.LexiconServlet.LexiconUseCaseController;
import com.monsanto.tcc.lexicon.exception.LexiconException;
import com.monsanto.tcc.lexicon.utils.PropertyTool;
import com.monsanto.tcc.lexicon.utils.gui.HtmlTable;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Properties;

/**
 * Created by IntelliJ IDEA.
 * User: adcox
 * Date: Oct 8, 2004
 * Time: 10:31:03 AM
 * To change this template use File | Settings | File Templates.
 */
public class GridToExcelUCC
extends LexiconUseCaseController
{
   public static final String ID = "id";
   public static final String SERVLET_PATH = "/lexicon-app/servlet/GridToExcel";
   public static final String IMAGE_LINK   = "<IMG BORDER=\"0\" SRC=\"/lexicon-app/images/xl_16.gif\" HEIGHT=\"16\" WIDTH=\"16\" TITLE=\"Download to Excel\" ALT=\"Download to Excel\">";

   private static final String PROP_FILENAME = "GridToExcelUCC.properties";

   public String getLink(String id)
      throws IOException, LexiconException
   {
      HtmlTableLoader loader = loadClassById(id);
      return "<A HREF=\"" + SERVLET_PATH + "?id=" +
              loader.getId() + "\" TARGET=\"_blank\" TYPE=\"application/vnd.ms-excel\">" +
              IMAGE_LINK +
              "</A>";
   }

   public void doService(UCCHelper helper) throws IOException {
      try {
         String id = getIdFromRequest(helper);
         HtmlTableLoader loader = loadClassById(id);
         HtmlTable table = loader.getTable(helper);

         helper.setContentType("application/vnd.ms-excel");
         OutputStream os = null;
         try {
            os = helper.getBinaryStream();
            table.writeExcel(os);
         }
         catch (Exception e) {
            _log.error(e.getMessage(), e);
            // We've already opened an output stream, so we cannot redirect to the
            // error page.
         }
         finally {
            if (os != null) {
               os.flush();
            }
         }
      }
      catch (Exception e) {
         _log.error(e.getMessage(), e);
         reportError(helper, e);
      }
   }

   protected HtmlTableLoader loadClassById(String id)
      throws IOException, LexiconException
   {
      Properties props = PropertyTool.loadProperties(GridToExcelUCC.class, PROP_FILENAME, false);
      String className = PropertyTool.getProperty(props, id, false);
      if (StringUtils.isNullOrEmpty(className)) {
         throw new LexiconException("Invalid id: " + id);
      }

      Class cls = null;
      Object inst = null;
      try {
         cls = Class.forName(className);
         inst = cls.newInstance();
      } catch (ClassNotFoundException e) {
         _log.error(e.getMessage(), e);
         throw new LexiconException("Invalid id: " + id);
      } catch (IllegalAccessException e) {
         _log.error(e.getMessage(), e);
         throw new LexiconException("Invalid id: " + id);
      } catch (InstantiationException e) {
         _log.error(e.getMessage(), e);
         throw new LexiconException("Invalid id: " + id);
      }

      if (! (inst instanceof HtmlTableLoader)) {
         _log.error("id " + id + " retrieved class named " + className + "; which is not an instance of HtmlTableLoader!");
         throw new LexiconException("Invalid id: " + id);
      }

      return (HtmlTableLoader) inst;
   }

   private String getIdFromRequest(UCCHelper helper) throws Exception {
      String id = helper.getRequestParameterValue(ID);

      if (StringUtils.isNullOrEmpty(id)) {
         throw new Exception(ID + " is a required parameter.");
      }

      return id;
   }
}
