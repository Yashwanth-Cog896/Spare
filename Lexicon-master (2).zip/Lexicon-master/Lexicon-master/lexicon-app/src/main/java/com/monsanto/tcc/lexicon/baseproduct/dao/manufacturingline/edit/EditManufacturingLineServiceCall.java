/*
 EditManufacturingLineServiceCall was created on Jan 18, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.dao.manufacturingline.edit;

import com.monsanto.tcc.lexiconcommon.pos.LexiconServiceInvoker;
import com.monsanto.tcc.lexiconcommon.pos.ServiceInvoker;
import com.monsanto.tcc.lexiconcommon.pos.batch.BatchModelServiceCall;
import com.monsanto.tcc.lexiconcommon.service.manufacturingline.edit.EditManufacturingLineRequest;
import com.monsanto.tcc.lexiconcommon.service.manufacturingline.edit.EditManufacturingLineResponse;
import com.monsanto.tcc.lexiconcommon.service.manufacturingline.edit.dom.EditManufacturingLineRequestSerializer;
import com.monsanto.tcc.lexiconcommon.service.manufacturingline.edit.dom.EditManufacturingLineResponseSerializer;
import com.monsanto.tcc.lexiconcommon.service.serialize.EmbeddableSerializer;

/**
 * nbwald Jan 18, 2008 12:43:51 PM
 */
public class EditManufacturingLineServiceCall
   extends BatchModelServiceCall<EditManufacturingLineRequest, EditManufacturingLineResponse>
{
   protected EmbeddableSerializer<EditManufacturingLineRequest> getRequestSerializer() {
      return new EditManufacturingLineRequestSerializer();
   }

   protected ServiceInvoker getServiceInvoker() {
      return new LexiconServiceInvoker("Lex_EditManufacturingLine");
   }

   protected EmbeddableSerializer<EditManufacturingLineResponse> getResponseSerializer() {
      return new EditManufacturingLineResponseSerializer();
   }
}