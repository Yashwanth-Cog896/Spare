package com.monsanto.tcc.lexicon.competitiveproduct.selectlistgen;

import com.monsanto.tcc.lexicon.typedata.brand.BrandDAO;
import com.monsanto.tcc.lexicon.typedata.brand.BrandDTO;
import com.monsanto.tcc.lexicon.utils.db.LexiconConnectionHelper;
import com.monsanto.tcc.lexicon.utils.gui.HtmlCell;
import com.monsanto.tcc.lexicon.utils.gui.SelectDisplayValueList;
import com.monsanto.tcc.lexicon.utils.gui.SelectDisplayValuePair;
import com.monsanto.tcc.lexicon.utils.gui.TypeTableListGenerator;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: adcox
 * Date: Jan 11, 2005
 * Time: 11:01:01 AM
 * To change this template use File | Settings | File Templates.
 */
public class BrandNameGenerator
        implements TypeTableListGenerator
{
   public SelectDisplayValueList getSelectList(HtmlCell cell) throws WrappingException {
      SelectDisplayValueList list = new SelectDisplayValueList();
		List listBrands = getDTOList();
		for (Iterator iterator = listBrands.iterator(); iterator.hasNext();) {
			BrandDTO dto = (BrandDTO) iterator.next();
			String shortName = dto.getName();
			shortName = shortName.substring(0, Math.min(14, shortName.length()));
			SelectDisplayValuePair pair = new SelectDisplayValuePair(shortName, dto.getName());
			list.add(pair);
		}

      return list;
   }

	private List getDTOList() throws WrappingException {
		PersistentStoreConnection conn = null;
		List dtoList = new ArrayList();
      try {
         conn = LexiconConnectionHelper.getDefaultConnection();
         BrandDAO dao = BrandDAO.newInstance();
         dtoList = dao.loadCompetitive(conn);
      }
      finally {
         if (conn != null) {
            conn.close();
         }
      }
		return dtoList;
	}

}
