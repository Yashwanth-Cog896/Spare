package com.monsanto.tcc.lexicon.controllers.beans;

/**
 * Created by IntelliJ IDEA.
 * User: adcox
 * Date: Jan 5, 2005
 * Time: 4:27:42 PM
 * To change this template use File | Settings | File Templates.
 */
public class FileLister {
   private String status;
   private String content;
   private String viewPaths;
   private String fileName;
   private String submit;
   private boolean deleteFile = false;

	/**
	 * @return
	 */
	public String getContent() {
		return content;
	}

	/**
	 * @return
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * @return
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @return
	 */
	public String getViewPaths() {
		return viewPaths;
	}

	/**
	 * @param string
	 */
	public void setContent(String string) {
		content = string;
	}

	/**
	 * @param string
	 */
	public void setFileName(String string) {
		fileName = string;
	}

	/**
	 * @param string
	 */
	public void setStatus(String string) {
		status = string;
	}

	/**
	 * @param string
	 */
	public void setViewPaths(String string) {
		viewPaths = string;
	}

	/**
	 * @return
	 */
	public String getSubmit() {
		return submit;
	}

	/**
	 * @param string
	 */
	public void setSubmit(String string) {
		submit = string;
	}

	/**
	 *
	 */
	public int getContentLength() {
      return (content == null ? 0 : content.length());
	}

   public boolean isDeleteFile() {
      return deleteFile;
   }

   public void setDeleteFile(boolean deleteFile) {
      this.deleteFile = deleteFile;
   }


}
