/*
 CreateProductRelationshipProcessor was created on Aug 7, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.process.manufacturingline.create;

import com.monsanto.tcc.lexicon.baseproduct.dao.manufacturingline.create.CreateProductRelationshipDAO;
import com.monsanto.tcc.lexicon.baseproduct.model.CreateableProductRelationship;
import com.monsanto.tcc.lexiconcommon.pos.ModelServiceCall;
import com.monsanto.tcc.lexiconcommon.pos.batch.BatchModelServiceProcessor;
import com.monsanto.tcc.lexiconcommon.pos.batch.InputModelBatchFilter;
import com.monsanto.tcc.lexiconcommon.pos.batch.ServiceRequestBuilder;
import com.monsanto.tcc.lexiconcommon.pos.batch.ServiceResponseMerger;
import com.monsanto.tcc.lexiconcommon.service.productrelationship.create.CreateProductRelationshipRequest;
import com.monsanto.tcc.lexiconcommon.service.productrelationship.create.CreateProductRelationshipResponse;
import java.util.List;

/**
 * nbwald Aug 7, 2007 3:18:15 PM
 */
public class CreateProductRelationshipProcessor
   extends BatchModelServiceProcessor<CreateableProductRelationship, CreateProductRelationshipRequest, CreateProductRelationshipResponse>
{
   private final CreateProductRelationshipDAO creatorDAO;

   public CreateProductRelationshipProcessor(CreateProductRelationshipDAO dao) {
      this.creatorDAO = dao;
   }

   protected InputModelBatchFilter<CreateableProductRelationship> getBatchFilter() {
      return new CreateProductRelationshipBatchFilter();
   }

   protected ServiceRequestBuilder<CreateableProductRelationship, CreateProductRelationshipRequest> getRequestBuilder() {
      return new CreateProductRelationshipRequestBuilder();
   }

   protected ServiceResponseMerger<CreateableProductRelationship, CreateProductRelationshipResponse> getResponseMerger() {
      return new CreateProductRelationshipResponseMerger();
   }

   protected ModelServiceCall<List<CreateProductRelationshipRequest>, List<CreateProductRelationshipResponse>> getServiceCaller() {
      return creatorDAO;
   }
}