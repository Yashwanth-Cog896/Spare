/*
 NoDuplicateRowsRule was created on Oct 9, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.validation.interrow;

import com.monsanto.tcc.lexicon.baseproduct.excel.BaseProductTemplateRow;
import com.monsanto.tcc.lexicon.baseproduct.validation.BaseProductTemplateError;
import com.monsanto.tcc.lexicon.baseproduct.validation.BaseProductTemplateRule;

/**
 * nbwald Oct 9, 2007 3:39:11 PM
 */
public class NoDuplicateRowsRule
   implements BaseProductTemplateRule
{
   private final BaseProductTemplateRow rowA;
   private final BaseProductTemplateRow rowB;

   public NoDuplicateRowsRule(BaseProductTemplateRow rowA, BaseProductTemplateRow rowB) {
      this.rowA = rowA;
      this.rowB = rowB;
   }

   public boolean violated() {
      return rowA.equals(rowB);
   }

   public BaseProductTemplateError getViolation() {
      return BaseProductTemplateError.DUPLICATE_ROWS;
   }
}