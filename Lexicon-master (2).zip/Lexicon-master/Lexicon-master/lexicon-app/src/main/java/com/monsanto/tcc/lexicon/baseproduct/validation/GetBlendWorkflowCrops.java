package com.monsanto.tcc.lexicon.baseproduct.validation;

import com.monsanto.tcc.lexicon.spring.ThreadLocalApplicationContext;
import com.monsanto.tps.lexiconservices.crop.service.BlendWorkflowCropService;
import org.springframework.context.ApplicationContext;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 6/6/14
 * Time: 12:22 PM
 */
public class GetBlendWorkflowCrops {


    private static List<String> blendWorkflowCrops = null;

    private static List<String> blendWorkflowCropPubKeys = null;


    public List<String> getBlendWorkflowCrops() {
        if (null == blendWorkflowCrops) {
            BlendWorkflowCropService blendWorkflowCropService = getBlendWorkflowCropServiceBean();
            blendWorkflowCrops = blendWorkflowCropService.getBlendWorkflowCropNames();
        }
        return blendWorkflowCrops;
    }

    public List<String> getBlendWorkflowCropPubKeys() {
        if (null == blendWorkflowCropPubKeys) {
            BlendWorkflowCropService blendWorkflowCropService = getBlendWorkflowCropServiceBean();
            blendWorkflowCropPubKeys = blendWorkflowCropService.getBlendWorkflowCropPubKeys();
        }
        return blendWorkflowCropPubKeys;
    }

    private BlendWorkflowCropService getBlendWorkflowCropServiceBean() {
        ApplicationContext context = ThreadLocalApplicationContext.getApplicationContext();
        return (BlendWorkflowCropService) context.getBean("blendWorkflowCropService");
    }
}
