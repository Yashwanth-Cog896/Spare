package com.monsanto.tcc.lexicon.businessdata;



/**
 * Created by IntelliJ IDEA.
 * User: adcox
 * Date: Oct 25, 2004
 * Time: 3:34:16 PM
 * To change this template use File | Settings | File Templates.
 */
public class MockOraCompProdDAO
   extends OraCompProdDAO
{
}

