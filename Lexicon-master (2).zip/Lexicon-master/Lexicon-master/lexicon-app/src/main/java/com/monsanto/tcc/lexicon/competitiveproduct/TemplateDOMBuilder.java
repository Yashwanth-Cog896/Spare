package com.monsanto.tcc.lexicon.competitiveproduct;

import com.monsanto.tcc.lexicon.businessdata.CompProdDAO;
import com.monsanto.tcc.lexicon.businessdata.CompProdDTO;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.CompProdDTORowElementImpl;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.CompProdGridReader;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.CompProdXmlUtils;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.ICompProdColDefs;
import com.monsanto.tcc.lexicon.templates.dom.TemplateXmlBuilder;
import com.monsanto.tcc.lexicon.templates.dom.TemplateXmlUtils;
import com.monsanto.tcc.lexicon.templates.reader.GridReader;
import com.monsanto.tcc.lexicon.templates.type.RowStatusType;
import com.monsanto.tcc.lexicon.typedata.brand.BrandDTO;
import com.monsanto.tcc.lexicon.typedata.country.CountryDTO;
import com.monsanto.tcc.lexicon.typedata.trait.TraitStackBO;
import com.monsanto.tcc.lexicon.typedata.trait.TraitStackDTO;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.dataservices.PersistentStoreConnection;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Aug 20, 2004
 * Time: 10:21:42 AM
 */
public class TemplateDOMBuilder
   extends TemplateXmlBuilder
   implements ICompProdColDefs
{
   public static final int ADD_FROM_TEMPLATE = 0;
   public static final int ADD_BY_COPY_FLAG = 1;
   public static final int UPDATE_BY_EDIT_FLAG = 2;

   private CompProdGridReader reader;
   private CompProdXmlUtils cpXMLUtil = new CompProdXmlUtils();

   public TemplateDOMBuilder(
      CompProdGridReader reader)
   {
      this.reader = reader;
   }

   protected GridReader getGridReader() {
      return reader;
   }
   protected TemplateXmlUtils getXmlUtils() {
      return cpXMLUtil;
   }

   protected String[] getElementNames() {
      return ELEMENT_NAMES;
   }
   public boolean isElementRequired(int colIdx) {
      return ELEMENT_REQUIRED[colIdx];
   }
   public boolean isColumnForcedUpper(int colIdx) {
      return COLUMNS_TO_UPPER[colIdx];
   }
   public boolean isColumnInteger(int colIdx) {
      return false;
   }

   protected void postCreateRootHook(
      Element elemRoot,
      String strName,
      String strUserID)
   {
      // Nothing to do
   }

   protected void postCreateRowHook(
      Element elemRow,
      String strUserID,
      int rowIdx,
      List valuesList)
   {
      cpXMLUtil.setPublicKey(elemRow, reader.getPublicKey(rowIdx));
      cpXMLUtil.setProductPublicKey(elemRow, reader.getProductPublicKey(rowIdx));
      cpXMLUtil.createTransgenicFlag(elemRow, getTransgenicFlag(elemRow));
      cpXMLUtil.createAuditNode(elemRow, strUserID);
   }

   protected String postListRetrievalHook(
      String elementName,
      String strValue)
   {
      if (elementName.equals(COM_MAT_ELEM)) {
         int len = strValue.length();
         if (strValue.length() >= 4 && strValue.endsWith(".0")) {
            strValue = strValue.substring(0, len -2);
         }
      }
      return strValue;
   }

   private boolean getTransgenicFlag(Element elemRow) {
     return true;
   }

   public Document buildRequestDocument(
      Document docStorage,
      PersistentStoreConnection connection,
      boolean isValidationRequest)
      throws IOException,
             WrappingException
   {
      return buildRequestDocument(docStorage, connection, ADD_FROM_TEMPLATE, isValidationRequest);
   }


   public Document buildRequestDocument(
      Document docStorage,
      PersistentStoreConnection connection,
      int actionType,
      boolean isValidationRequest)
      throws IOException,
             WrappingException
   {
      String strName = getXmlUtils().getBatchName(docStorage);
      NodeList nlRows = getXmlUtils().getRowElements(docStorage);

      Document doc = DOMUtil.newDocument();
      Element elemRoot = cpXMLUtil.createRequestRootElement(doc, strName);

      boolean doSendRow, doCommit;
      String strStatus;
      Element elemRowReq, elemRowStor;

      for (int i = 0; i < nlRows.getLength(); i++) {
         elemRowStor = (Element)nlRows.item(i);
         strStatus = getXmlUtils().getStatusString(elemRowStor);
         doCommit = getXmlUtils().getCommitFlag(elemRowStor);
         doSendRow = false;

         if (doCommit && !isValidationRequest) {
            if (RowStatusType.VALIDATED.equals(strStatus)) {
               doSendRow = shouldSendRowByAction(actionType, elemRowStor);
            }
         }
         else if (isValidationRequest && !doCommit) {
            if (RowStatusType.VALIDATED.equals(strStatus) ||
                RowStatusType.UNPROCESSED.equals(strStatus))
            {
               doSendRow = shouldSendRowByAction(actionType, elemRowStor);
            }
         }

         if (doSendRow) {
            elemRowReq = cpXMLUtil.createRequestRowNode(elemRoot,
               reader.getRowID(i+1), reader.getActiveFlag(i+1),
               reader.getPublicKey(i+1), reader.getProductPublicKey(i+1));
            fillRequestRow(connection, elemRowReq, elemRowStor, strStatus);
         }
      }

      return doc;
   }

   private void fillRequestRow(
      PersistentStoreConnection connection,
      Element elemRowReq,
      Element elemRowStor,
      String strStatus)
      throws WrappingException
   {
      CompProdDAO daoImpl = CompProdDAO.newInstance();
      CompProdDTO compProd = new CompProdDTORowElementImpl(elemRowStor);
      String strComMat = cpXMLUtil.getComlMatString(elemRowStor);

      cpXMLUtil.createStatusNode(elemRowReq, strStatus, null, null);
      cpXMLUtil.createProductNameNode(elemRowReq, cpXMLUtil.getProductName(elemRowStor));

      BrandDTO brand = daoImpl.getBrand(connection, compProd);
      cpXMLUtil.createBrandNode(elemRowReq, brand.getName());
      cpXMLUtil.createBrandPubkeyNode(elemRowReq, brand.getPublicKey());

      cpXMLUtil.createBayerCodeNode(elemRowReq, cpXMLUtil.getBayerCode(elemRowStor));

      CountryDTO country = daoImpl.getCountry(connection, compProd);
      cpXMLUtil.createCountryNode(elemRowReq, country.getName());
      cpXMLUtil.createCountryPubkeyNode(elemRowReq, country.getPublicKey());

      cpXMLUtil.createComlMatNode(elemRowReq, strComMat);

      TraitStackDTO traitStack = daoImpl.getExistingTraitStack(connection, compProd);
      TraitStackBO bo = new TraitStackBO(traitStack, connection);

      String stackNameForPOSRequest =  bo.getStackNameForPOSRequest();
      if(!StringUtils.isNullOrEmpty(stackNameForPOSRequest)) {
         cpXMLUtil.createCharacteristicTraits(elemRowReq, stackNameForPOSRequest);
      }

      cpXMLUtil.createLineTypeNode(elemRowReq, cpXMLUtil.getLineType(elemRowStor));
      cpXMLUtil.createProgramCodeNode(elemRowReq, cpXMLUtil.getProgramCode(elemRowStor));

      cpXMLUtil.createTransgenicFlag(elemRowReq, bo.isTransgenic());
   }

   private boolean shouldSendRowByAction(
      int actionType,
      Element elemRowStor)
      throws WrappingException
   {
      switch (actionType) {
         case ADD_FROM_TEMPLATE:   return true;
         case ADD_BY_COPY_FLAG:    return cpXMLUtil.isCopied(elemRowStor);
         case UPDATE_BY_EDIT_FLAG: return cpXMLUtil.isEditing(elemRowStor);
         default:
            throw new WrappingException(new RuntimeException("ASSERT: Invalid action type: " + actionType));
      }
   }
}

