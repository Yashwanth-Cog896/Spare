package com.monsanto.tcc.lexicon.eventregulation.ucc;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.tcc.lexicon.LexiconServlet.SimpleLexiconUCC;
import com.monsanto.tcc.lexicon.eventregulation.view.EventRegulationsBean;

/**
 * nbwald - Feb 6, 2009 3:20:26 PM
 */
public class EditEventRegulationUCC
   extends SimpleLexiconUCC
{
   @Override
   protected void executeAction(UCCHelper helper)
      throws Exception
   {
      EventRegulationsBean eventRegulationsBean = (EventRegulationsBean) helper.getSessionParameter(EventRegulationsBean.NAME);
      eventRegulationsBean.syncValuesFromRequest(helper);
      int targetIndex = Integer.valueOf(helper.getRequestParameterValue(EventRegulationConstants.TARGET));
      eventRegulationsBean.edit(targetIndex);
   }
}
