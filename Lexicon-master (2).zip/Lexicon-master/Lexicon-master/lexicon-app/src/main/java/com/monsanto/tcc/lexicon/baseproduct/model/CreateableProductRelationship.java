/*
 ProductRelationship was created on Aug 7, 2007 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.model;

import com.monsanto.tcc.lexiconcommon.service.productrelationship.create.CreateProductRelationshipResponse;

/**
 * nbwald Aug 7, 2007 2:34:59 PM
 */
public interface CreateableProductRelationship
{
   boolean isCreateable();
   String getBaseManufacturingName();
   String getManufacturingName();
   void update(CreateProductRelationshipResponse responseModel);
    boolean isBlend();
}