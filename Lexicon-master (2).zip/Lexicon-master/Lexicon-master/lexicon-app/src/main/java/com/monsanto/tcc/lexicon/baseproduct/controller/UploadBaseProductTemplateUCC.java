/*
 UploadBaseProductTemplateUCC was created on Oct 1, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.controller;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.tcc.lexicon.LexiconServlet.LexiconBlockingUseCaseController;
import com.monsanto.tcc.lexicon.LexiconServlet.upload.UploadedFiles;
import com.monsanto.tcc.lexicon.LexiconServlet.upload.UploadedFilesImpl;
import com.monsanto.tcc.lexicon.applicationroles.AppRoles;
import com.monsanto.tcc.lexicon.baseproduct.model.BaseProductPageBean;
import com.monsanto.tcc.lexicon.baseproduct.model.BaseProductTemplate;
import com.monsanto.tcc.lexicon.baseproduct.queryset.CachingUploadBaseProductTemplateQuerySet;
import com.monsanto.tcc.lexicon.baseproduct.queryset.UploadBaseProductTemplateQuerySet;
import com.monsanto.tcc.lexicon.baseproduct.queryset.UploadBaseProductTemplateQuerySetImpl;
import com.monsanto.tcc.lexicon.baseproduct.validation.GetBlendWorkflowCrops;
import com.monsanto.tcc.lexicon.baseproduct.validation.InvalidTemplateException;
import com.monsanto.tcc.lexicon.croproles.CropAuthorizationImpl;

import java.util.Arrays;
import java.util.List;

/**
 * nbwald Oct 1, 2007 12:44:24 PM
 */
public class UploadBaseProductTemplateUCC
        extends LexiconBlockingUseCaseController {
    public static final String MESSAGES = "BaseProductTemplateMessages";
    private final UploadBaseProductTemplateQuerySet querySet;
    private static final String BLEND_CROPS = "blendCrops";
    private static final String NON_BLEND_CROPS = "nonBlendCrops";


    public UploadBaseProductTemplateUCC() {
        this.querySet = new CachingUploadBaseProductTemplateQuerySet(new UploadBaseProductTemplateQuerySetImpl());
    }

    public UploadBaseProductTemplateUCC(UploadBaseProductTemplateQuerySet querySet) {
        this.querySet = querySet;
    }

    public void doService(UCCHelper helper)
            throws Throwable {

        List<String> blendWorkflowCrops = getBlendWorkflowCrops();
        List<String> authorizedCrops = getAuthorizedCrops(helper);
        setBlendCropAccessStatusOfUser(helper, blendWorkflowCrops, authorizedCrops);
        setNonBlendCropAccessStatusOfUser(helper, blendWorkflowCrops, authorizedCrops);

        UploadedFiles uploadedFiles = new UploadedFilesImpl(helper.getClientFiles());
        BaseProductTemplate template = new BaseProductTemplate(uploadedFiles, querySet);
        try {
            BaseProductPageBean pageBean = template.getBaseProductPageBean();
            helper.setSessionParameter(BaseProductPageBean.BEAN_ID, pageBean);
            helper.forward(getSuccessForward());
        } catch (InvalidTemplateException e) {
            helper.setRequestAttributeValue(MESSAGES, e.getMessages());
            helper.forward(getFailedForward());
        } finally {
            template.deleteTemplate();
        }
    }

    private void setNonBlendCropAccessStatusOfUser(UCCHelper helper, List<String> blendWorkflowCrops, List<String> authorizedCrops) {
        for (String authorizedCrop : authorizedCrops) {
            if (!blendWorkflowCrops.contains(authorizedCrop)) {
                helper.setRequestAttributeValue(NON_BLEND_CROPS, Boolean.TRUE);
                break;
            }
        }
    }

    private void setBlendCropAccessStatusOfUser(UCCHelper helper, List<String> blendWorkflowCrops, List<String> authorizedCrops) {
        for (String blendWorkflowCrop : blendWorkflowCrops) {
            if (authorizedCrops.contains(blendWorkflowCrop)) {
                helper.setRequestAttributeValue(BLEND_CROPS, Boolean.TRUE);
                break;
            }
        }
    }

    private List<String> getBlendWorkflowCrops() {
        GetBlendWorkflowCrops blendWorkflowCrop = new GetBlendWorkflowCrops();
        return blendWorkflowCrop.getBlendWorkflowCropPubKeys();
    }

    private List<String> getAuthorizedCrops(UCCHelper helper) {
        CropAuthorizationImpl cropAuthorization = new CropAuthorizationImpl(helper.getAuthenticatedUserID());
        return Arrays.asList(cropAuthorization.getAuthorizedCrops());
    }

    protected boolean isValidRequest(UCCHelper helper)
            throws Throwable {
        AppRoles appRoles = loadUserAppRoles(helper);
        return appRoles.isUserInAppRole(AppRoles.ROLE_MON_PROD_EQUIV_MAINT);
    }
}