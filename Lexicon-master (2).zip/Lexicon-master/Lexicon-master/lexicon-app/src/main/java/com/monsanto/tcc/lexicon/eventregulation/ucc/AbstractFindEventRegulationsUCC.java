package com.monsanto.tcc.lexicon.eventregulation.ucc;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.tcc.lexicon.LexiconServlet.SimpleLexiconUCC;
import com.monsanto.tcc.lexicon.eventregulation.view.EventRegulationsBean;
import com.monsanto.tcc.lexicon.eventregulation.view.EventRegulationsSearchBean;
import com.monsanto.tps.lexicon.event.EventInfo;

/**
 * nbwald - Jan 9, 2009 11:15:28 AM
 */
public abstract class AbstractFindEventRegulationsUCC
   extends SimpleLexiconUCC
{
   protected void executeAction(UCCHelper helper)
      throws Exception
   {
      EventRegulationsSearchBean search = new EventRegulationsSearchBean(helper);
      EventInfo eventInfo = find(search);
      EventRegulationsBean eventRegulations = new EventRegulationsBean(eventInfo);
      helper.setSessionParameter(EventRegulationsBean.NAME, eventRegulations);
      helper.setSessionParameter(EventRegulationsSearchBean.NAME, search);
   }

   protected abstract EventInfo find(EventRegulationsSearchBean search);
}
