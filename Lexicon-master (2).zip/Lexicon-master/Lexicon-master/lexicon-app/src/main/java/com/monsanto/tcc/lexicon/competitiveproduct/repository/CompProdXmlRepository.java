package com.monsanto.tcc.lexicon.competitiveproduct.repository;

import com.monsanto.tcc.lexicon.competitiveproduct.mapping.CompProdXmlUtils;
import com.monsanto.tcc.lexicon.templates.dom.TemplateRowStatistics;
import com.monsanto.tcc.lexicon.utils.xml.XmlRepository;
import com.monsanto.tcc.lexicon.utils.xml.XmlRepositoryContext;
import com.monsanto.tcc.lexicon.utils.xml.XmlRepositoryItemHeader;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.dataservices.PersistentStoreConnection;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Sep 7, 2004
 * Time: 4:25:25 PM
 */
public class CompProdXmlRepository
   implements XmlRepository
{
   private XmlRepositoryContext _context;
   private CompProdXmlUtils _cpXmlUtil = new CompProdXmlUtils();
   private static final String ENCODING = "UTF-8";

   public CompProdXmlRepository()
   {
   }

   public void setContextProvider(
      XmlRepositoryContext context)
      throws WrappingException
   {
      if (!PersistentStoreConnection.class.equals(context.getContextObjectClass())) {
         throw new RuntimeException("Invalid Context for " + getClass().getName());
      }
      _context = context;
   }

   public List getHeaderList()
      throws WrappingException
   {
      return getHeaderList(null);
   }

   public List getHeaderList(String strUserId)
      throws WrappingException
   {
      List list = new ArrayList();
      PersistentStoreConnection connection = null;
      CompProdBatchDAOFinder finder = new CompProdBatchDAOFinder();
      try
      {
         CompProdBatchDAO dao = null;
         connection = getConnection();
         List listDAO = (StringUtils.isNullOrEmpty(strUserId)) ?
            finder.findAll(connection) : finder.findAllByUser(connection, strUserId);

         for (int i = 0; i < listDAO.size(); i++) {
            dao = (CompProdBatchDAO)listDAO.get(i);
            list.add(new CompProdXmlRepositoryHeader(dao));
         }
         return list;
      }
      finally {
         releaseConnection(connection);
      }
   }

   public XmlRepositoryItemHeader getHeader(
      String strName)
      throws WrappingException
   {
      CompProdBatchDAO dao = getBatchDAO(strName);
      return (null == dao) ? null : new CompProdXmlRepositoryHeader(dao);
   }

   public Document loadDocument(
      XmlRepositoryItemHeader header)
      throws WrappingException,
             SAXException,
             WrappingException
   {
      Document doc = createDocument((CompProdXmlRepositoryHeader)header);
      CompProdBatchDAO dao = getBatchDAO((CompProdXmlRepositoryHeader)header);

      PersistentStoreConnection connection = null;
      try {
         connection = getConnection();
         appendBatchRows(doc, dao, connection);
      }
      finally {
         releaseConnection(connection);
      }
      return doc;
   }

   public XmlRepositoryItemHeader saveDocument(
      Document doc)
      throws WrappingException
   {
      CompProdBatchDAO dao = getBatchDAO(_cpXmlUtil.getBatchName(doc));

      PersistentStoreConnection connection = null;
      //boolean wasCommitted = false;
      try {
         connection = getConnection();
         connection.beginTransaction();

         if (null == dao) {
            dao = insertBatch(doc, connection);
         }
         else {
            deleteBatchRows(dao, connection);
            updateBatch(doc, dao, connection);
         }

         NodeList nodeList = _cpXmlUtil.getRowElements(doc);
         for (int i = 0; i < nodeList.getLength(); i++) {
            insertBatchRow(dao, (Element)nodeList.item(i), connection);
         }

         //wasCommitted = true;
         connection.endTransaction();
         return new CompProdXmlRepositoryHeader(dao);
      }
      finally {
         try {
            connection.rollbackTransaction();
         }
         catch(Throwable t) {
            //log error
         }
         releaseConnection(connection);
      }
   }

   public boolean removeDocument(
      XmlRepositoryItemHeader header)
      throws WrappingException
   {
      CompProdBatchDAO dao = getBatchDAO(header.getName());
      if (null == dao) {
         return false;
      }

      boolean wasCommitted = false;
      PersistentStoreConnection connection = null;
      try {
         connection = getConnection();
         connection.beginTransaction();
         deleteBatchRows(dao, connection);
         deleteBatch(dao, connection);
         connection.endTransaction();
         wasCommitted = true;
      }
      finally {
         if (!wasCommitted) {
            try {
               connection.rollbackTransaction();
            }
            catch(Throwable t) {
               //log error
            }
         }
         releaseConnection(connection);
      }

      return true;
   }

   private CompProdBatchDAO getBatchDAO(
      String name)
      throws WrappingException
   {
      PersistentStoreConnection connection = null;
      CompProdBatchDAOFinder finder = new CompProdBatchDAOFinder();
      try
      {
         connection = getConnection();
         return finder.findByName(connection, name);
      }
      finally {
         releaseConnection(connection);
      }
   }

   private CompProdBatchDAO getBatchDAO(
      CompProdXmlRepositoryHeader header)
   {
      return new CompProdBatchDAO(header.getBatchID(), header.getName(), header.numTotal(),
         header.numCommitted(), header.numValidated(), header.numErrored(), header.numAbandoned(),
         header.numUnprocessed(), header.getUserId() ,header.getEntryDate());
   }

   private Document createDocument(
      CompProdXmlRepositoryHeader header)
   {
      Document doc = DOMUtil.newDocument();
      Element elemRoot = _cpXmlUtil.createRootElement(doc, header.getName());
      _cpXmlUtil.createEntryDateNode(elemRoot, header.getEntryDate());
      _cpXmlUtil.createUserIdNode(elemRoot, header.getUserId());

      TemplateRowStatistics stats = new TemplateRowStatistics(
              header.numCommitted(),
              header.numValidated(),
              header.numErrored(),
              header.numAbandoned(),
              header.numUnprocessed(),
              0);
      _cpXmlUtil.createStatsNode(elemRoot, stats);

      return doc;
   }
   
   private void appendBatchRows(
      Document doc,
      CompProdBatchDAO dao,
      PersistentStoreConnection connection)
      throws WrappingException
   {
      CompProdBatchRowDAO rowDAO = null;
      List list = dao.findChildRows(connection);

      try {
         for (int i = 0; i < list.size(); i++) {
            //LogWriter.getCategory(this).debug("row " + i);
            rowDAO = (CompProdBatchRowDAO)list.get(i);
            appendBatchRow(doc, rowDAO);
         }
      }
      catch (IOException e) {
         throw new WrappingException(e);
      }
      catch (SAXException e) {
         throw new WrappingException(e);
      }
   }

   private void appendBatchRow(
      Document doc,
      CompProdBatchRowDAO dao)
      throws IOException,
             SAXException
   {
      String strXML = dao.getXML();
      //LogWriter.getCategory(this).debug("xml: " + strXML);

      Document docTemp = DOMUtil.newDocument(new ByteArrayInputStream(strXML.getBytes(ENCODING)));
      _cpXmlUtil.removeNamespaceAttributes(docTemp.getDocumentElement());

      Node node = doc.importNode(docTemp.getDocumentElement(), true);
      doc.getDocumentElement().appendChild(node);
   }

   private void updateBatch(
      Document doc,
      CompProdBatchDAO dao,
      PersistentStoreConnection connection)
      throws WrappingException
   {
      fillDAO(doc, dao);
      dao.updatePersistentStore(connection);
   }

   private CompProdBatchDAO insertBatch(
      Document doc,
      PersistentStoreConnection connection)
      throws WrappingException
   {
      CompProdBatchDAO dao = new CompProdBatchDAO(connection);
      fillDAO(doc, dao);
      dao.updatePersistentStore(connection);
      return dao;
   }
   
   private void deleteBatch(
      CompProdBatchDAO dao, 
      PersistentStoreConnection connection)
      throws WrappingException
   {
      dao.markForDelete();
      dao.updatePersistentStore(connection);
   }

   private void fillDAO(
      Document doc,
      CompProdBatchDAO dao)
      throws WrappingException
   {
      CompProdXmlUtils cpXmlUtil = new CompProdXmlUtils();
      Element elemStats = _cpXmlUtil.getStatsNode(doc);
      dao.setValues(
         cpXmlUtil.getBatchName(doc),
         cpXmlUtil.getNumTotal(doc),
         cpXmlUtil.getNumCommitted(doc),
         cpXmlUtil.getNumValidated(doc),
         cpXmlUtil.getNumErrored(doc),
         cpXmlUtil.getNumAbandoned(doc),
         cpXmlUtil.getNumUnprocessed(doc),
         cpXmlUtil.getUserId(doc),
         cpXmlUtil.getEntryDate(doc));
   }
   
   private void insertBatchRow(
      CompProdBatchDAO dao,
      Element elemRow,
      PersistentStoreConnection connection)
      throws WrappingException
   {
      Document docTemp = DOMUtil.newDocument();
      Node node = docTemp.importNode(elemRow, true);
      _cpXmlUtil.setNamespaceAttributes((Element)node);
      docTemp.appendChild(node);

      String strXml = DOMUtil.getXMLString(docTemp);

      CompProdBatchRowDAO rowDAO = new CompProdBatchRowDAO(
         dao.getID(), _cpXmlUtil.getRownum(elemRow), _cpXmlUtil.getStatusString(elemRow), strXml);

      rowDAO.updatePersistenceStore(connection);
   }

   private void deleteBatchRows(
      CompProdBatchDAO dao,
      PersistentStoreConnection connection)
      throws WrappingException
   {
      dao.deleteChildRows(connection);
   }

   private PersistentStoreConnection getConnection()
      throws WrappingException
   {
      try {
         if (null == _context) {
            throw new RuntimeException("Context must be set first");
         }
         else {
            return (PersistentStoreConnection)_context.getContextObject();
         }
      }
      catch (WrappingException e) {
         throw e;
      }
   }
   
   private void releaseConnection(
      PersistentStoreConnection connection)
   {
       _context.releaseContextObject(connection);
   }
   

}
