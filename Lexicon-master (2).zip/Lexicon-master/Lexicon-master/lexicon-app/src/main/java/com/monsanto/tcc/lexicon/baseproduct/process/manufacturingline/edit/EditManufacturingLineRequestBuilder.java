/*
 EditManufacturingLineRequestBuilder was created on Jan 22, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.process.manufacturingline.edit;

import com.monsanto.tcc.lexicon.baseproduct.model.EditableProductRelationship;
import com.monsanto.tcc.lexiconcommon.pos.batch.ServiceRequestBuilder;
import com.monsanto.tcc.lexiconcommon.service.manufacturingline.edit.EditManufacturingLineRequest;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald Jan 22, 2008 11:19:07 AM
 */
public class EditManufacturingLineRequestBuilder
   implements ServiceRequestBuilder<EditableProductRelationship, EditManufacturingLineRequest>
{
   public EditManufacturingLineRequest buildRequest(EditableProductRelationship inputModel)
      throws WrappingException
   {
      EditManufacturingLineRequest request = new EditManufacturingLineRequest();
      request.setTargetManufacturingName(inputModel.getTargetManufacturingName());
      request.setNewManufacturingName(inputModel.getNewManufacturingName());
      request.setNewVarietyName(inputModel.getNewVarietyName());
      return request;
   }
}