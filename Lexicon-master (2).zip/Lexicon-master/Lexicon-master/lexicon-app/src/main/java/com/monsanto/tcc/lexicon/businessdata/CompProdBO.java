package com.monsanto.tcc.lexicon.businessdata;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.tcc.lexicon.competitiveproduct.types.CompProdSourceType;
import com.monsanto.tcc.lexicon.typedata.bayer.BayerDAO;
import com.monsanto.tcc.lexicon.typedata.bayer.BayerDTO;
import com.monsanto.tcc.lexicon.typedata.brand.BrandDAO;
import com.monsanto.tcc.lexicon.typedata.brand.BrandDTO;
import com.monsanto.tcc.lexicon.typedata.country.CountryDAO;
import com.monsanto.tcc.lexicon.typedata.country.CountryDTO;
import com.monsanto.tcc.lexicon.typedata.trait.TraitStackDTO;
import com.monsanto.tcc.lexicon.utils.LogWriter;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Nov 2, 2004
 * Time: 11:17:45 AM
 */
public class CompProdBO
   extends CompProdDTOImpl
{
   public static final int MAX_PROD_NAME_LENGTH = 30;
   public static final String PROD_NAME_TOO_LONG_ERROR = "The product name must not be longer than " + MAX_PROD_NAME_LENGTH  + " characters.";
   public static final String PROD_NAME_NOT_BLANK_ERROR = "Product name must not be blank.";
   public static final String PROD_EXISTS_ERROR = "A product with the same Name, Bayer Code, Brand, and Country already exists.";
   public static final String INVALID_BAYER_CODE_ERROR = " is not a valid Bayer Code";
   public static final String INVALID_BRAND_ERROR = " is not a valid Brand Name";
   public static final String NON_COMPETITOR_BRAND_ERROR = " is not a competitor Brand Name";
   public static final String INVALID_COUNTRY_ERROR = " is not a valid Country Abbreviation";
   public static final String INVALID_TRAIT_STACK_ERROR = " is not a valid Trait Stack for the bayer code ";
   public static final String INVALID_SOURCE_VERIFY_ERROR = " is not a valid Source Verified Type";
   public static final String SOURCE_ONE_OR_OTHER_NOT_BLANK_ERROR = "If Source Verified is not blank, Source Year must also be not blank.";
   public static final String UNEXPECTED_ERROR = "An unexpected error occurred while validating product";

   private Logger log = LogWriter.getCategory(this);
   private final CompProdDTO dto;

   protected CompProdBO()
   {
		this.dto = null;
   }

   public CompProdBO(CompProdDTO dto)
   {
		this.dto = dto;
      setProductPublicKey(dto.getProductPublicKey());
      setPublicKey(dto.getPublicKey());
      setActive(dto.isActive());
      setProductName(dto.getProductName());
      setBayerCode(dto.getBayerCode());
      setBrandName(dto.getBrandName());
      setCountryName(dto.getCountryName());
      setCommercialMaturity(dto.getCommercialMaturity());
      setCharacteristicTraits(dto.getCharacteristicTraits());
      setTraitAttributes(dto.getTraitAttributes());
      setSourceVerified(dto.getSourceVerified());
      setSourceYear(dto.getSourceYear());
      setComments(dto.getComments());
   }

   public List validate(PersistentStoreConnection connection)
   {
      List listErrors = new ArrayList();

      addErrorToList(validateProductName(connection), listErrors);
      addErrorToList(validateBayerCode(connection), listErrors);
      addErrorToList(validateBrandName(connection), listErrors);
      addErrorToList(validateCountryName(connection), listErrors);
      addErrorToList(validateTraits(connection), listErrors);
      addErrorToList(validateSource(), listErrors);

      return listErrors;
   }
   
   private void addErrorToList(
      CompProdValidationError error,
      List listErrors)
   {
      if (null != error) {
         listErrors.add(error);
      }
   }

   protected CompProdValidationError validateProductName(PersistentStoreConnection connection)
   {
		CompProdValidationError error = null;
      if (StringUtils.isNullOrEmpty(getProductName())) {
         error = new CompProdValidationError(PROD_NAME_NOT_BLANK_ERROR);
      }
      else if (getProductName().length() > MAX_PROD_NAME_LENGTH) {
         error = new CompProdValidationError(PROD_NAME_TOO_LONG_ERROR);
      }
      else {
         CompProdDAO dao = CompProdDAO.newInstance();
         try {
            // Cast to CompProdDTOImpl to get isDeleted information. Otherwise, we have some serious changes to the
				// object model.  See BusinessDataDAO.properties.
            CompProdDTOImpl compProd = (CompProdDTOImpl)dao.loadByMatchingAK(connection, getProductName(), getBayerCode(), getBrandName(), getCountryName());
				if(compProd != null) {
					if(!compProd.getPublicKey().equals(getPublicKey()) && !compProd.isDeleted()) {
						error = new CompProdValidationError(PROD_EXISTS_ERROR);
					}
					else if(compProd.isDeleted()) {
						dto.setPublicKey(compProd.getPublicKey());   // REUSE the deleted product name entry
					}
				}
         }
         catch (WrappingException e) {
            LogWriter.logWrappingException(log, e);
            error = new CompProdValidationError(UNEXPECTED_ERROR, e);
         }
      }

		return error;
   }

   protected CompProdValidationError validateBayerCode(PersistentStoreConnection connection)
   {
      try {
         BayerDTO bayer = BayerDAO.newInstance().loadByCode(connection, getBayerCode());
         return (null != bayer)  ? null :
            new CompProdValidationError(getBayerCode() + INVALID_BAYER_CODE_ERROR);
      }
      catch (WrappingException e) {
         LogWriter.logWrappingException(log, e);
         return new CompProdValidationError(UNEXPECTED_ERROR, e);
      }
   }
   
   protected CompProdValidationError validateBrandName(PersistentStoreConnection connection)
   {
      try {
         BrandDTO dto = BrandDAO.newInstance().loadByName(connection, getBrandName());
         if (null == dto) {
            return new CompProdValidationError(getBrandName() + INVALID_BRAND_ERROR);
         }
         else if (!dto.isCompetitor()) {
            return new CompProdValidationError(getBrandName() + NON_COMPETITOR_BRAND_ERROR);
         }
         else {
            return null;
         }
      }
      catch (WrappingException e) {
         LogWriter.logWrappingException(log, e);
         return new CompProdValidationError(UNEXPECTED_ERROR, e);
      }
   }

   protected CompProdValidationError validateCountryName(PersistentStoreConnection connection)
   {
      try {
         CountryDTO country = CountryDAO.newInstance().loadByAbbr(connection, getCountryName());
         return (null != country) ? null :
            new CompProdValidationError(getCountryName() + INVALID_COUNTRY_ERROR);
      }
      catch (WrappingException e) {
         LogWriter.logWrappingException(log, e);
         return new CompProdValidationError(UNEXPECTED_ERROR, e);
      }
   }

   protected CompProdValidationError validateTraits(PersistentStoreConnection connection)
   {
      if (!StringUtils.isNullOrEmpty(getCharacteristicTraits())) {
         try {
            TraitStackDTO traitStackDTO = CompProdDAO.newInstance().getTraitStack(connection, this);
            return (null != traitStackDTO) ? null :
               new CompProdValidationError(getCharacteristicTraits() + INVALID_TRAIT_STACK_ERROR + getBayerCode());
         }
         catch (WrappingException e) {
            LogWriter.logWrappingException(log, e);
            return new CompProdValidationError(UNEXPECTED_ERROR, e);
         }
      }
      else {
         return null;
      }
   }

   protected CompProdValidationError validateSource()
   {
      String source = getSourceVerified();
      if (!StringUtils.isNullOrEmpty(source)) {
         CompProdSourceType type = CompProdSourceType.fromName(source);
         if (null == type) {
            return new CompProdValidationError(getSourceVerified() + INVALID_SOURCE_VERIFY_ERROR);
         }
         else if(StringUtils.isNullOrEmpty(getSourceYear())) {
            return new CompProdValidationError(SOURCE_ONE_OR_OTHER_NOT_BLANK_ERROR);
         }
         else {
            return null;
         }
      }
      else if(!StringUtils.isNullOrEmpty(getSourceYear())) {
         return new CompProdValidationError(SOURCE_ONE_OR_OTHER_NOT_BLANK_ERROR);
      }
      else {
         return null;
      }
   }

}
