/*
 Copyright:  Copyright � 2009 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.lexicon.baseproduct.audit;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RLCASW
 * @version $Revision$
 */
public class BaseProductWithProductRelationshipAudit
{
   private final ProductRelationshipAudit productRelationshipAudit;
   private final BaseProductAudit baseProductAudit;

   public BaseProductWithProductRelationshipAudit() {
      this(new BaseProductAudit(), new ProductRelationshipAudit());

   }

   public BaseProductWithProductRelationshipAudit(BaseProductAudit baseProductAudit,
                                                  ProductRelationshipAudit productRelationshipAudit)
   {
      this.productRelationshipAudit = productRelationshipAudit;
      this.baseProductAudit = baseProductAudit;
   }

   public Map getBaseProductWithRelationshipsAuditInfo(PersistentStoreConnection conn, String baseManufacturingName)
      throws WrappingException
   {
      Map entries = new LinkedHashMap();
      addBaseProductAuditInfoToMap(conn, baseManufacturingName, entries);
      addProductRelationshipAuditInfoToMap(conn, baseManufacturingName, entries);
      return entries;
   }

   private void addBaseProductAuditInfoToMap(PersistentStoreConnection conn, String baseManufacturingName, Map entries)
      throws WrappingException
   {
      entries.putAll(baseProductAudit.getBaseProductAuditInfoMap(conn, baseManufacturingName));
   }

   private void addProductRelationshipAuditInfoToMap(PersistentStoreConnection conn, String baseManufacturingName, Map entries)
      throws WrappingException
   {
      entries.putAll(productRelationshipAudit.getProductRelationshipAuditInfoMap(conn, baseManufacturingName));
   }
}