/*
 AbstractBaseProductTemplateValidation was created on Oct 11, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.validation;

import java.util.ArrayList;
import java.util.List;

/**
 * nbwald Oct 11, 2007 5:17:52 PM
 */
public abstract class AbstractBaseProductTemplateErrorCollector
{
   public BaseProductTemplateError[] validate() {
      return collectErrors(getRules());
   }

   private BaseProductTemplateError[] collectErrors(BaseProductTemplateRule[] rules) {
      List<BaseProductTemplateError> errors = new ArrayList<BaseProductTemplateError>();
      for (BaseProductTemplateRule rule : rules) {
         if(rule.violated()) {
            errors.add(rule.getViolation());
         }
      }
      return errors.toArray(new BaseProductTemplateError[errors.size()]);
   }

   protected abstract BaseProductTemplateRule[] getRules();
}