/*
 CreateProductRelationshipResponseMerger was created on Aug 7, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.process.manufacturingline.create;

import com.monsanto.tcc.lexicon.baseproduct.model.CreateableProductRelationship;
import com.monsanto.tcc.lexiconcommon.pos.batch.ServiceResponseMerger;
import com.monsanto.tcc.lexiconcommon.service.productrelationship.create.CreateProductRelationshipResponse;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald Aug 7, 2007 2:50:54 PM
 */
public class CreateProductRelationshipResponseMerger
   implements ServiceResponseMerger<CreateableProductRelationship, CreateProductRelationshipResponse>
{
   public void mergeResponse(CreateableProductRelationship inputModel, CreateProductRelationshipResponse responseModel)
      throws WrappingException
   {
      inputModel.update(responseModel);
   }
}