package com.monsanto.tcc.lexicon.competitiveproduct.mapping;

import com.monsanto.tcc.lexicon.competitiveproduct.mapping.RowObject;

/**
 * nbwald - Nov 12, 2009 2:44:46 PM
 */
public class ErrorsComparator
   extends StringMethodComparator
{
   @Override
   public String eval(RowObject rowObject) {
      return rowObject.getErrors();
   }
}
