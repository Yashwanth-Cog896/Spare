/*
 BaseProductActionFactory was created on Aug 2, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.action.factory;

import com.monsanto.tcc.lexicon.baseproduct.action.BaseProductAction;
import com.monsanto.tcc.lexicon.baseproduct.action.BaseProductCommitAllAction;
import com.monsanto.tcc.lexicon.baseproduct.action.BaseProductNullAction;
import com.monsanto.tcc.lexicon.baseproduct.action.CreateBaseProductAction;
import com.monsanto.tcc.lexicon.baseproduct.action.CreateProductRelationshipAction;
import com.monsanto.tcc.lexicon.baseproduct.action.DiscardProductRelationshipChangesAction;
import com.monsanto.tcc.lexicon.baseproduct.action.EditProductRelationshipAction;
import com.monsanto.tcc.lexicon.baseproduct.action.RemoveBaseProductAction;
import com.monsanto.tcc.lexicon.baseproduct.action.locator.BaseProductBeanLocator;
import com.monsanto.Util.StringUtils;

/**
 * nbwald Aug 2, 2007 10:03:59 AM
 */
public class BaseProductActionFactory
{
   private final String actionName;
   private final BaseProductBeanLocator beanLocator;

   public BaseProductActionFactory(String actionName, BaseProductBeanLocator beanLocator) {
      this.actionName = actionName;
      this.beanLocator = beanLocator;
   }

   public BaseProductAction getAction() {
      for (BaseProductAction action : getAllActions()) {
         if(StringUtils.areEqual(actionName, action.getActionName())) {
            return action;
         }
      }
      return new BaseProductNullAction();
   }

   private BaseProductAction[] getAllActions() {
      return new BaseProductAction[] {
         new CreateBaseProductAction(beanLocator),
         new RemoveBaseProductAction(beanLocator),
         new BaseProductCommitAllAction(beanLocator),
         new CreateProductRelationshipAction(beanLocator),
         new DiscardProductRelationshipChangesAction(beanLocator),
         new EditProductRelationshipAction(beanLocator),
      };
   }
}