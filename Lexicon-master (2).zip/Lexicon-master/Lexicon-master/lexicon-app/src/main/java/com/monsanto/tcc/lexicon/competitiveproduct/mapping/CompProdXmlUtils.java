package com.monsanto.tcc.lexicon.competitiveproduct.mapping;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tcc.lexicon.templates.dom.TemplateXmlUtils;
import com.monsanto.Util.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Sep 2, 2004
 * Time: 11:07:35 AM
 * To change this template use File | Settings | File Templates.
 */
public class CompProdXmlUtils
   extends TemplateXmlUtils
   implements CompProdXmlTags
{
   protected String getNamespaceURI() {
      return NS_URI;
   }
   protected String getRootElementName() {
      return ROOT_ELEM;
   }
   protected String getRowElementName() {
      return ROW_ELEM;
   }

   public Element createRootElement(Document doc, String name)
   {
      return super.createRootElement(doc, name);
   }

   public Element createRowNode(
      Element elemRoot,
      int rownum,
      boolean isActive,
      boolean isEditing,
      boolean isCopied,
      String namePublicKey,
      String productPublicKey)
   {
      Element elemRow = super.createRowNode(elemRoot, rownum, isActive, isEditing, isCopied);
      setPublicKey(elemRow, namePublicKey);
      setProductPublicKey(elemRow, productPublicKey);
      return elemRow;
   }

   // Row Values methods
   public Element createProductNameNode(Element elemRow, String str) {
      return DOMUtil.addChildElementWithNS(NS_URI, elemRow, PROD_ELEM, str);
   }
   public String getProductName(Element elemRow) {
      return DOMUtil.getChildValue(elemRow, PROD_ELEM);
   }

   public Element createBrandNode(Element elemRow, String str) {
      return DOMUtil.addChildElementWithNS(NS_URI, elemRow, BRAND_ELEM, str);
   }
   public Element createBrandPubkeyNode(Element elemRow, String str) {
      return DOMUtil.addChildElementWithNS(NS_URI, elemRow, BRAND_PUBKEY_ELEM, str);
   }
   public String getBrand(Element elemRow) {
      return DOMUtil.getChildValue(elemRow, BRAND_ELEM);
   }
   public String getBrandPubkey(Element elemRow) {
      return DOMUtil.getChildValue(elemRow, BRAND_PUBKEY_ELEM);
   }

   public Element createBayerCodeNode(Element elemRow, String str) {
      return DOMUtil.addChildElementWithNS(NS_URI, elemRow, BAYER_ELEM, str);
   }
   public String getBayerCode(Element elemRow) {
      return DOMUtil.getChildValue(elemRow, BAYER_ELEM);
   }

   public Element createCountryNode(Element elemRow, String str) {
      return DOMUtil.addChildElementWithNS(NS_URI, elemRow, COUNTRY_ELEM, str);
   }
   public Element createCountryPubkeyNode(Element elemRow, String str) {
      return DOMUtil.addChildElementWithNS(NS_URI, elemRow, COUNTRY_PUBKEY_ELEM, str);
   }
   public String getCountry(Element elemRow) {
      return DOMUtil.getChildValue(elemRow, COUNTRY_ELEM);
   }

   public Element createLineTypeNode(Element elemRow, String str) {
      return (StringUtils.isNullOrEmpty(str)) ? null :
         DOMUtil.addChildElementWithNS(NS_URI, elemRow, LINE_TYPE_ELEM, str);
   }
   public String getLineType(Element elemRow) {
      return DOMUtil.getChildValue(elemRow, LINE_TYPE_ELEM);
   }

   public Element createComlMatNode(Element elemRow, String str) {
      return (StringUtils.isNullOrEmpty(str)) ? null :
         DOMUtil.addChildElementWithNS(NS_URI, elemRow, COM_MAT_ELEM, str);
   }
   public String getComlMatString(Element elemRow) {
      return DOMUtil.getChildValue(elemRow, COM_MAT_ELEM);
   }

   public Element createCharacteristicTraits(Element elemRow, String str) {
      return (StringUtils.isNullOrEmpty(str)) ? null :
         DOMUtil.addChildElementWithNS(NS_URI, elemRow, TRAITS_ELEM, str);
   }
   public String getCharacteristicTraits(Element elemRow) {
      return DOMUtil.getChildValue(elemRow, TRAITS_ELEM);
   }

   public String getTraitAttributes(Element elemRow) {
      return DOMUtil.getChildValue(elemRow, OTHER_TRAITS_ELEM);
   }
   public void createSplitAttributeTraitsNode(Element elemRowReq, String str) {
      String[] aTraits = StringUtils.splitCsv(str, false);
      if (0 != aTraits.length) {
         Element elemTrait = DOMUtil.addChildElementWithNS(NS_URI, elemRowReq, OTHER_TRAITS_ELEM);
         for (int i = 0; i < aTraits.length; i++) {
            DOMUtil.addChildElementWithNS(NS_URI, elemTrait, OTHER_TRAIT_ELEM, aTraits[i]);
         }
      }
   }

   public Element createProgramCodeNode(Element elemRow, String str) {
      return (StringUtils.isNullOrEmpty(str)) ? null :
         DOMUtil.addChildElementWithNS(NS_URI, elemRow, PROG_CODE_ELEM, str);
   }
   public String getProgramCode(Element elemRow) {
      return DOMUtil.getChildValue(elemRow, PROG_CODE_ELEM);
   }

   public boolean getTransgengicFlag(Element elemRow) {
      String str = DOMUtil.getChildValue(elemRow, IS_TRANSG_ELEM);
      return Boolean.TRUE.toString().equals(str);
   }
   public Element createTransgenicFlag(Element elemRow, boolean isTransgenic) {
      return DOMUtil.addChildElementWithNS(
         NS_URI, elemRow, IS_TRANSG_ELEM, Boolean.toString(isTransgenic));
   }

   public String getSourceVerified(Element elemRow) {
      return DOMUtil.getChildValue(elemRow, VERIF_DS_ELEM);
   }
   public Element createSourceVerifiedNode(Element elemRow, String strVerifiedBy) {
      return DOMUtil.addChildElementWithNS(NS_URI, elemRow, VERIF_DS_ELEM, strVerifiedBy);
   }

   public String getSourceYear(Element elemRow) {
      return DOMUtil.getChildValue(elemRow, DS_YEAR_ELEM);
   }
   public Element createSourceYearNode(Element elemRow, String strYear) {
      return DOMUtil.addChildElementWithNS(NS_URI, elemRow, DS_YEAR_ELEM, strYear);
   }

   public Element createCommentNode(Element elemRow, String str) {
      return DOMUtil.addChildElementWithNS(NS_URI, elemRow, COMMENT_ELEM, str);
   }
   public String getComments(Element elemRow) {
      return DOMUtil.getChildValue(elemRow, COMMENT_ELEM);
   }

   public void setPublicKey(Element elemRow, String publicKey) {
      elemRow.setAttribute(NAME_PUBLIC_KEY_ATTR,
         (StringUtils.isNullOrEmpty(publicKey) ? "" : publicKey));
   }
   public String getPublicKey(Element elemRow) {
      return elemRow.getAttribute(NAME_PUBLIC_KEY_ATTR);
   }

   public void setProductPublicKey(Element elemRow, String publicKey) {
      elemRow.setAttribute(PROD_PUBLIC_KEY_ATTR,
         (StringUtils.isNullOrEmpty(publicKey) ? "" : publicKey));
   }
   public String getProductPublicKey(Element elemRow) {
      return elemRow.getAttribute(PROD_PUBLIC_KEY_ATTR);
   }

   public Element createRequestRootElement(Document doc, String name)
   {
      Element elemRoot = DOMUtil.addChildElementWithNS(NS_URI, doc, REQUEST_ROOT_ELEM);
      elemRoot.setAttribute(BATCH_NAME_ATTR, name);
      setNamespaceAttributes(elemRoot);
      return elemRoot;
   }

   // Used for testing purpose, to simulate a response for the MIDAS POS
   public Element createResponseRootElement(Document doc, String name)
   {
      Element elemRoot = DOMUtil.addChildElementWithNS(NS_URI, doc, RESPONSE_ROOT_ELEM);
      elemRoot.setAttribute(BATCH_NAME_ATTR, name);
      setNamespaceAttributes(elemRoot);
      return elemRoot;
   }

   public Element createRequestRowNode(
      Element elemRoot,
      int rownum,
      boolean isActive,
      String namePublicKey,
      String productPublicKey)
   {
      Element elemRow = DOMUtil.addChildElementWithNS(NS_URI, elemRoot, ROW_ELEM);
      elemRow.setAttribute(ROWNUM_ATTR, Integer.toString(rownum));

      setActiveFlag(elemRow, isActive);
      setPublicKey(elemRow, namePublicKey);
      setProductPublicKey(elemRow, productPublicKey);

      return elemRow;
   }

   public Element createResponseRowNode(
      Element elemRoot,
      int rownum)
   {
      Element elemRow = DOMUtil.addChildElementWithNS(NS_URI, elemRoot, ROW_ELEM);
      elemRow.setAttribute(ROWNUM_ATTR, Integer.toString(rownum));
      return elemRow;
   }
}
