package com.monsanto.tcc.lexicon.competitiveproduct.repository;

import com.monsanto.tcc.lexicon.utils.LogWriter;
import com.monsanto.tcc.lexicon.utils.db.LexiconConnectionHelper;
import com.monsanto.tcc.lexicon.utils.xml.XmlRepositoryContext;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import org.apache.log4j.Logger;

/**
 * Created by IntelliJ IDEA.
 * User: adcox
 * Date: Sep 14, 2004
 * Time: 2:26:14 PM
 * To change this template use File | Settings | File Templates.
 */
public class XmlRepositoryDBContext
implements XmlRepositoryContext
{
   public Object getContextObject()
      throws WrappingException
   {
      return LexiconConnectionHelper.getDefaultConnection();
   }

   public void releaseContextObject(
      Object contextObject)
   {
      PersistentStoreConnection conn = (PersistentStoreConnection) contextObject;
      Logger log = LogWriter.getCategory(this);
      LexiconConnectionHelper.closeConnection(conn, log);
   }

   public Class getContextObjectClass() {
      return PersistentStoreConnection.class;
   }
}
