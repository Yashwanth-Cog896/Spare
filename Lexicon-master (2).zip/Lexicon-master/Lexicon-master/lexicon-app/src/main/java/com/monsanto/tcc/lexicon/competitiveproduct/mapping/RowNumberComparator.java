package com.monsanto.tcc.lexicon.competitiveproduct.mapping;

import com.monsanto.tcc.lexicon.competitiveproduct.mapping.RowObject;

import java.util.Comparator;

/**
 * nbwald - Nov 12, 2009 1:43:33 PM
 */
public class RowNumberComparator
   implements Comparator<RowObject>
{
   @Override
   public int compare(RowObject a, RowObject b) {
      return a.getRowNumber() - b.getRowNumber();
   }
}
