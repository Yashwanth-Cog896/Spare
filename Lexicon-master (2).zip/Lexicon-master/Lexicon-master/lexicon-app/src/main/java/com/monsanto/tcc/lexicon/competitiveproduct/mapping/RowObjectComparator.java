package com.monsanto.tcc.lexicon.competitiveproduct.mapping;

import com.monsanto.tcc.lexicon.competitiveproduct.mapping.AuditRequestorComparator;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.BayerCodeComparator;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.BrandNameComparator;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.CharacteristicTraitsComparator;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.CommentsComparator;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.CommercialMaturityComparator;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.CountryNameComparator;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.ErrorsAndStatusComparator;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.LineTypeComparator;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.ProductNameComparator;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.ProgramOwnerComparator;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.PublicKeyComparator;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.RankStatusComparator;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.RowNumberComparator;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.SourceVerifiedComparator;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.SourceYearComparator;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.TraitAttributesComparator;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.TwoStageProductPublicKeyComparator;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: adcox
 * Date: Sep 30, 2004
 * Time: 11:58:18 AM
 */
public class RowObjectComparator
   implements Comparator
{
   public static final int UNDEFINED = -1;
   public static final int SORT_BY_STATUS = 0;
   public static final int SORT_BY_PROD_NAME = 1;
   public static final int SORT_BY_ROW_NUM = 2;
   public static final int SORT_BY_BAYER_CODE = 3;
   public static final int SORT_BY_BRAND = 4;
   public static final int SORT_BY_COUNTRY = 5;
   public static final int SORT_BY_LINE_TYPE = 6;
   public static final int SORT_BY_COML_MAT = 7;
   public static final int SORT_BY_CHAR_TRAIT = 8;
   public static final int SORT_BY_TRAIT_ATTRIB = 9;
   public static final int SORT_BY_PROGRAM_OWNER = 10;
   public static final int SORT_BY_SRC_VERIFIED = 11;
   public static final int SORT_BY_SRC_YEAR = 12;
   public static final int SORT_BY_REQUESTOR = 13;
   public static final int SORT_BY_COMMENTS = 14;
   public static final int SORT_BY_MESSAGE = 15;
   public static final int SORT_BY_PUBLICKEY = 16;
   public static final int SORT_BY_PRODPUBLICKEY = 17;

   // Used by validateSortType() to validate the passed in sort type at runtime.  If you add a new sort type, also
   // adjust the value of SORT_BY_HIGHEST_KEY.
   public static final int SORT_BY_HIGHEST_KEY = 17;

   private final int sortType;
   private final int sortDirection;

   // Sort directions
   public static final int SORTED_NONE = 0;
   public static final int SORTED_ASC = 1;
   public static final int SORTED_DESC = 2;

   public RowObjectComparator(int sortType, int sortDirection) {
      validateSortType(sortType);
      this.sortType = sortType;
      this.sortDirection = sortDirection;
   }

   public int compare(Object o1, Object o2) {
      RowObject ro1 = (RowObject) o1;
      RowObject ro2 = (RowObject) o2;
      int returnValue = compareBySortType(ro1, ro2);
      returnValue = useRowNumberToBreakTies(returnValue, ro1, ro2);
      returnValue = invertDescendingSorts(returnValue);
      return returnValue;
   }

   private int compareBySortType(RowObject a, RowObject b) {
      Map<Integer, Comparator<RowObject>> comparatorsBySortType = gatherRowObjectComparatorsBySortType();
      for (Map.Entry<Integer, Comparator<RowObject>> comparatorBySortType : comparatorsBySortType.entrySet()) {
         if(sortType == comparatorBySortType.getKey()) {
            Comparator<RowObject> comparator = comparatorBySortType.getValue();
            return comparator.compare(a, b);
         }
      }
      throw new IllegalArgumentException("Unknown sort type " + sortType + ".  Bug in " + RowObjectComparator.class.getSimpleName() + "?");
   }

   private Map<Integer, Comparator<RowObject>> gatherRowObjectComparatorsBySortType() {
      Map<Integer, Comparator<RowObject>> comparatorsBySortType = new HashMap<Integer, Comparator<RowObject>>();
      comparatorsBySortType.put(SORT_BY_PROD_NAME, new ProductNameComparator());
      comparatorsBySortType.put(SORT_BY_BAYER_CODE, new BayerCodeComparator());
      comparatorsBySortType.put(SORT_BY_BRAND, new BrandNameComparator());
      comparatorsBySortType.put(SORT_BY_COUNTRY, new CountryNameComparator());
      comparatorsBySortType.put(SORT_BY_LINE_TYPE, new LineTypeComparator());
      comparatorsBySortType.put(SORT_BY_CHAR_TRAIT, new CharacteristicTraitsComparator());
      comparatorsBySortType.put(SORT_BY_TRAIT_ATTRIB, new TraitAttributesComparator());
      comparatorsBySortType.put(SORT_BY_PROGRAM_OWNER, new ProgramOwnerComparator());
      comparatorsBySortType.put(SORT_BY_SRC_VERIFIED, new SourceVerifiedComparator());
      comparatorsBySortType.put(SORT_BY_SRC_YEAR, new SourceYearComparator());
      comparatorsBySortType.put(SORT_BY_REQUESTOR, new AuditRequestorComparator());
      comparatorsBySortType.put(SORT_BY_COMMENTS, new CommentsComparator());
      comparatorsBySortType.put(SORT_BY_PUBLICKEY, new PublicKeyComparator());
      comparatorsBySortType.put(SORT_BY_ROW_NUM, new RowNumberComparator());
      comparatorsBySortType.put(SORT_BY_STATUS, new RankStatusComparator());
      comparatorsBySortType.put(SORT_BY_COML_MAT, new CommercialMaturityComparator());
      comparatorsBySortType.put(SORT_BY_MESSAGE, new ErrorsAndStatusComparator());
      comparatorsBySortType.put(SORT_BY_PRODPUBLICKEY, new TwoStageProductPublicKeyComparator());
      return comparatorsBySortType;
   }

   private int useRowNumberToBreakTies(int returnValue, RowObject ro1, RowObject ro2) {
      if (returnValue == 0) {
         return new RowNumberComparator().compare(ro1, ro2);
      }
      return returnValue;
   }

   private int invertDescendingSorts(int returnValue) {
      if (getSortDirection() == SORTED_DESC) {
         return -returnValue;
      }
      return returnValue;
   }

   public int getSortType() {
      return sortType;
   }

   public int getSortDirection() {
      return sortDirection;
   }

   private void validateSortType(int sortType) {
      if (sortType < 0 || sortType > SORT_BY_HIGHEST_KEY) {
         throw new RuntimeException("Invalid sort type: " + sortType);
      }
   }
}
