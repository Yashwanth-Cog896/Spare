/*
 ProductRelationshipImpl was created on Aug 7, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.model;

import com.monsanto.tcc.lexicon.genericbean.model.BeanState;
import com.monsanto.tcc.lexiconcommon.service.productrelationship.create.CreateProductRelationshipResponse;

/**
 * nbwald Aug 7, 2007 4:42:15 PM
 */
public class CreateableProductRelationshipImpl
   implements CreateableProductRelationship
{
   private final BaseProductBean baseProductBean;
   private final ProductRelationshipBean productRelationshipBean;

   public CreateableProductRelationshipImpl(BaseProductBean baseProductBean, ProductRelationshipBean productRelationshipBean) {
      this.baseProductBean = baseProductBean;
      this.productRelationshipBean = productRelationshipBean;
   }

   public boolean isCreateable() {
      return !BeanState.ERRED.equals(baseProductBean.getState())
         && productRelationshipBean.getState().isCommitable()
         && !productRelationshipBean.isEntityCommitted();
   }

   public String getBaseManufacturingName() {
      return baseProductBean.getBaseManufacturingName();
   }

   public String getManufacturingName() {
      return productRelationshipBean.getManufacturingName();
   }

   public void update(CreateProductRelationshipResponse response) {
      productRelationshipBean.update(response);
   }

    @Override
    public boolean isBlend() {
        return productRelationshipBean.isBlend();
    }
}