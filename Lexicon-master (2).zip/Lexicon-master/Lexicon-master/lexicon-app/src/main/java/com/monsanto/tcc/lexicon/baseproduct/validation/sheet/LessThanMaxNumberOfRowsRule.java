/*
 LessThanMaxNumberOfRowsRule was created on Oct 24, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.validation.sheet;

import com.monsanto.tcc.lexicon.baseproduct.validation.BaseProductTemplateError;
import com.monsanto.tcc.lexicon.baseproduct.validation.BaseProductTemplateRule;
import com.monsanto.tcc.lexiconcommon.file.excel.ExcelSheet;

/**
 * nbwald Oct 24, 2007 6:17:21 PM
 */
public class LessThanMaxNumberOfRowsRule
   implements BaseProductTemplateRule
{
   private static final int MAX_ROWS = 500;
   private ExcelSheet excelSheet;

   public LessThanMaxNumberOfRowsRule(ExcelSheet excelSheet) {
      this.excelSheet = excelSheet;
   }

   public boolean violated() {
      return excelSheet.getData().length > MAX_ROWS;
   }

   public BaseProductTemplateError getViolation() {
      return BaseProductTemplateError.TOO_MANY_ROWS;
   }
}