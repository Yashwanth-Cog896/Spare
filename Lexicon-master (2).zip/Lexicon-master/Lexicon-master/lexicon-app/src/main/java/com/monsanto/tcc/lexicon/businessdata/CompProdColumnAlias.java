package com.monsanto.tcc.lexicon.businessdata;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Feb 14, 2005
 * Time: 4:26:01 PM
 * To change this template use File | Settings | File Templates.
 */
public interface CompProdColumnAlias
{
   public static final String NAME_ID_ALIAS     = "ProductNameId";
   public static final String PROD_ID_ALIAS     = "ProductId";
   public static final String NAME_PUBKEY_ALIAS = "NamePubKey";
   public static final String PROD_PUBKEY_ALIAS = "ProductPubKey";
   public static final String PROD_NAME_ALIAS   = "ProductName";
   public static final String BAYER_CODE_ALIAS  = "BayerCodeName";
   public static final String CNTRY_NAME_ALIAS  = "CountryName";
   public static final String BRAND_NAME_ALIAS  = "BrandName";
   public static final String COM_MAT_ALIAS     = "CM";
   public static final String DS_VERIFY_ALIAS   = "SourceVerified";
   public static final String DS_YEAR_ALIAS     = "SourceYear";
   public static final String LOGICAL_DELETE_ALIAS = "LogicalDelete";
   public static final String COMMENTS_ALIAS       = "Comments";
   public static final String IS_ACTIVE_ALIAS      = "IsActive";
   public static final String STACK_RPTG_NAME_ALIAS = "ReportingStackName";

}
