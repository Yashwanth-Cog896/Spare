package com.monsanto.tcc.lexicon.comments.bean;

import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Oct 12, 2011
 * Time: 1:13:23 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProductAdditionalCommentsBean implements Serializable {
    private String productPubkey;
    private String preCommercialName;
    private String crop;
    private String varietyName;
    private String additionalComments;
    private String unmodifiedAdditionalComments;
    private RowStatus rowStatus=RowStatus.READY;
    private String message;

    public String getAdditionalComments() {
        return additionalComments;
    }

    public void setAdditionalComments(String additionalComments) {
        this.additionalComments = additionalComments;
    }

    public String getUnmodifiedAdditionalComments() {
        return unmodifiedAdditionalComments;
    }

    public void setUnmodifiedAdditionalComments(String unmodifiedAdditionalComments) {
        this.unmodifiedAdditionalComments = unmodifiedAdditionalComments;
    }

    public String getCrop() {
        return crop;
    }

    public void setCrop(String crop) {
        this.crop = crop;
    }

    public String getPreCommercialName() {
        return preCommercialName;
    }

    public void setPreCommercialName(String preCommercialName) {
        this.preCommercialName = preCommercialName;
    }

    public String getProductPubkey() {
        return productPubkey;
    }

    public void setProductPubkey(String productPubkey) {
        this.productPubkey = productPubkey;
    }

    public String getVarietyName() {
        return varietyName;
    }

    public void setVarietyName(String varietyName) {
        this.varietyName = varietyName;
    }

    public RowStatus getRowStatus() {
        return rowStatus;
    }
    public void setRowStatus(RowStatus rowStatus) {
        this.rowStatus = rowStatus;
    }
    public boolean isErred(){
        return rowStatus==RowStatus.ERRED;
    }
    public boolean isEditing(){
        return rowStatus==RowStatus.EDITING||isErred()||isValidated();
    }
    public boolean isReady(){
        return rowStatus==RowStatus.READY;
    }
    public boolean isCommitted(){
        return rowStatus==RowStatus.COMMITTED;
    }
    public boolean isValidated(){
        return rowStatus==RowStatus.VALIDATED;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
