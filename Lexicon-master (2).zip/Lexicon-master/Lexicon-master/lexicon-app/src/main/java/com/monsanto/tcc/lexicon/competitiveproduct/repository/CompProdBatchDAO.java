package com.monsanto.tcc.lexicon.competitiveproduct.repository;

import com.monsanto.tcc.lexicon.utils.LogWriter;
import com.monsanto.tcc.lexicon.utils.db.LexiconConnectionHelper;
import com.monsanto.tcc.lexicon.utils.db.dao.LexiconMutableIntKeyedDAO;
import com.monsanto.tcc.lexicon.utils.db.dao.SequenceGrabber;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.dataservices.PersistentStoreStatement;
import org.apache.log4j.Category;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Sep 9, 2004
 * Time: 11:19:29 AM
 * To change this template use File | Settings | File Templates.
 */
public class CompProdBatchDAO
   extends LexiconMutableIntKeyedDAO
{
   public static final String BATCH_ID = "comp_prod_batch_id";
   public static final String BATCH_NAME = "comp_prod_batch_name";
   public static final String NUM_TOTAL = "num_total";
   public static final String NUM_COMMIT = "num_committed";
   public static final String NUM_VALID = "num_validated";
   public static final String NUM_ERROR = "num_errored";
   public static final String NUM_ABAND = "num_abandoned";
   public static final String NUM_UNPROC = "num_unprocessed";
   public static final String ENTRY_DATE = "entry_date";
   public static final String USER_ID    = "user_id";

   private static final String SEQ_NAME = "Comp_Prod_Batch_Id_Seq";
   private static SequenceGrabber s_grabber = new SequenceGrabber(SEQ_NAME);

   private String _strName;
   private int _numTotal;
   private int _numCommit;
   private int _numValid;
   private int _numError;
   private int _numAband;
   private int _numUnproc;
   private String _strUserId;
   private Date _dateEntry;

   private Category _log = LogWriter.getCategory(getClass());

   /**
    * Constructs an DAO object for a new batch record
    * @param conn Connection to the persistance store
    * @throws WrappingException
    */
   public CompProdBatchDAO(
      PersistentStoreConnection conn)
      throws WrappingException
   {
      super(conn, s_grabber);
   }

   /**
    * Constructs an DAO object for an existing batch record
    * @param iBatchID id of the batch
    * @param strName name of the batch
    * @param numTotal Total Rows
    * @param numCommit Committed Rows
    * @param numValid Valid Rows
    * @param numError Errored Rows
    * @param numAband Abandoned Rows
    * @param numUnproc Unprocessed Rows
    * @param dateEntry Entry date for the batch
    */
   public CompProdBatchDAO(
      int iBatchID,
      String strName,
      int numTotal,
      int numCommit,
      int numValid,
      int numError,
      int numAband,
      int numUnproc,
      String strUserId,
      Date dateEntry)
   {
      super(iBatchID);
      _strName   = strName;
      _numTotal  = numTotal;
      _numCommit = numCommit;
      _numValid  = numValid;
      _numError  = numError;
      _numAband  = numAband;
      _numUnproc = numUnproc;
      _strUserId = strUserId;
      _dateEntry = dateEntry;
   }

   public CompProdBatchDAO(
      PersistentStoreResultSetRow rsRow)
      throws WrappingException
   {
      super();
      fill(rsRow);
   }


   public String getName() {
      return _strName;
   }
   public int numTotal() {
      return _numTotal;
   }
   public int numCommitted() {
      return _numCommit;
   }
   public int numValid() {
      return _numValid;
   }
   public int numErrored() {
      return _numError;
   }
   public int numAbandoned() {
      return _numAband;
   }
   public int numUnprocessed() {
      return _numUnproc;
   }
   public String getUserId() {
      return _strUserId;
   }
   public Date getEntryDate() {
      return _dateEntry;
   }


   public void setValues(
      String strName,
      int numTotal,
      int numCommit,
      int numValid,
      int numError,
      int numAband,
      int numUnproc,
      String strUserId,
      Date dateEntry)
   {
      _strName   = strName;
      _numTotal  = numTotal;
      _numCommit = numCommit;
      _numValid  = numValid;
      _numError  = numError;
      _numAband  = numAband;
      _numUnproc = numUnproc;
      _dateEntry = dateEntry;
      _strUserId = strUserId;
      markDirty();
   }

   /**
    * Inserts data to the persistent store.
    *
    * @param conn A connection to the persistent store.
    *          - When there is an error accessing the persistent store.
    */
   public void insert(
      PersistentStoreConnection conn)
      throws WrappingException
   {
      String strSq1 = CompProdBatchDAOUtil.getInstance().getSQL(
         CompProdBatchDAOUtil.INSERT_BATCH, _log);

      PersistentStoreStatement stmt = null;
      try {
         stmt = conn.prepareStatement(strSq1);
         stmt.setParam(1, getID());
         stmt.setParam(2, _strName);
         stmt.setParam(3, _numTotal);
         stmt.setParam(4, _numCommit);
         stmt.setParam(5, _numValid);
         stmt.setParam(6, _numError);
         stmt.setParam(7, _numAband);
         stmt.setParam(8, _numUnproc);
         stmt.setParam(9, _strUserId);
         //stmt.setParam(9, _dateEntry);
         stmt.executeInsert();
      }
      finally {
         LexiconConnectionHelper.closeStatement(stmt, _log);
      }
   }

   /**
    * Updates an existing record in the persistnet store.
    *
    * @param conn A connection to the persistent store.
    * @return The number of records updated.
    *          - When there is an error accessing the persistent store.
    */
   public int update(
      PersistentStoreConnection conn)
      throws WrappingException
   {
      String strSq1 = CompProdBatchDAOUtil.getInstance().getSQL(
         CompProdBatchDAOUtil.UPDATE_BATCH, _log);

      PersistentStoreStatement stmt = null;
      try {
         stmt = conn.prepareStatement(strSq1);
         stmt.setParam(1, _strName);
         stmt.setParam(2, _numTotal);
         stmt.setParam(3, _numCommit);
         stmt.setParam(4, _numValid);
         stmt.setParam(5, _numError);
         stmt.setParam(6, _numAband);
         stmt.setParam(7, _numUnproc);
         stmt.setParam(8, _strUserId);
         stmt.setParam(9, _dateEntry);
         stmt.setParam(10, getID());
         return stmt.executeUpdate();
      }
      finally {
         LexiconConnectionHelper.closeStatement(stmt, _log);
      }
   }

   /**
    * Deletes a record from the persistent store.
    *
    * @param conn A connection to the persistent store.
    *          - When there is an error accessing the persistent store.
    */
   public void delete(
      PersistentStoreConnection conn)
      throws WrappingException
   {
      String strSq1 = CompProdBatchDAOUtil.getInstance().getSQL(
         CompProdBatchDAOUtil.DELETE_BATCH, _log);

      PersistentStoreStatement stmt = null;
      try {
         stmt = conn.prepareStatement(strSq1);
         stmt.setParam(1, getID());
         stmt.executeDelete();
      }
      finally {
         LexiconConnectionHelper.closeStatement(stmt, _log);
      }
   }

   public List findChildRows(
      PersistentStoreConnection conn)
      throws WrappingException
   {
      String strSql = CompProdBatchDAOUtil.getInstance().getSQL(
         CompProdBatchDAOUtil.SELECT_BATCH_ROWS, _log);
      _log.debug("id: " + getID());

      List list = new ArrayList();
      PersistentStoreStatement stmt = null;
      try {
         stmt = conn.prepareStatement(strSql);
         stmt.setParam(1, getID());

         PersistentStoreResultSetFwdIterator iter = stmt.executeQuery().getForwardIterator();
         while(iter.next()) {
            list.add(new CompProdBatchRowDAO(iter));
         }
      }
      finally {
         LexiconConnectionHelper.closeStatement(stmt, _log);
      }
      return list;
   }

   public void deleteChildRows(
      PersistentStoreConnection conn)
      throws WrappingException
   {
      String strSql = CompProdBatchDAOUtil.getInstance().getSQL(
         CompProdBatchDAOUtil.DELETE_BATCH_ROWS, _log);

      PersistentStoreStatement stmt = null;
      try {
         stmt = conn.prepareStatement(strSql);
         stmt.setParam(1, getID());
         stmt.executeDelete();
      }
      finally {
         LexiconConnectionHelper.closeStatement(stmt, _log);
      }
   }

   private void fill(
      PersistentStoreResultSetRow rsRow)
      throws WrappingException
   {
      setID(rsRow.getInt(BATCH_ID));
      _strName    = rsRow.getString(BATCH_NAME);
      _numTotal   = rsRow.getInt(NUM_TOTAL);
      _numCommit  = rsRow.getInt(NUM_COMMIT);
      _numValid   = rsRow.getInt(NUM_VALID);
      _numError   = rsRow.getInt(NUM_ERROR);
      _numAband   = rsRow.getInt(NUM_ABAND);
      _numUnproc  = rsRow.getInt(NUM_UNPROC);
      _strUserId  = rsRow.getString(USER_ID);
      _dateEntry  = rsRow.getDate(ENTRY_DATE);
   }
}
