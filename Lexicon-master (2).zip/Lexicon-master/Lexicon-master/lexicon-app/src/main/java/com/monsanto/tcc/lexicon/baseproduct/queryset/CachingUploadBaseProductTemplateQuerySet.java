/*
 CachingUploadBaseProductTemplateQuerySet was created on Oct 24, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.queryset;

import com.monsanto.tcc.lexicon.baseproduct.queryset.model.BaseProduct;
import com.monsanto.tcc.lexiconcommon.service.manufacturingfamily.search.model.ManufacturingFamily;
import java.util.HashMap;
import java.util.Map;

/**
 * nbwald Oct 24, 2007 3:39:49 PM
 */
public class CachingUploadBaseProductTemplateQuerySet
   implements UploadBaseProductTemplateQuerySet
{
   private UploadBaseProductTemplateQuerySet delegate;
   private Map<String, BaseProduct> baseProductsByBaseManfName = new HashMap<String, BaseProduct>();
   private Map<String, Boolean> validCropName = new HashMap<String, Boolean>();

   public CachingUploadBaseProductTemplateQuerySet(UploadBaseProductTemplateQuerySet delegate) {
      this.delegate = delegate;
   }

   public BaseProduct getBaseProduct(String baseManufacturingName) {
      if(baseProductsByBaseManfName.containsKey(baseManufacturingName)) {
         return baseProductsByBaseManfName.get(baseManufacturingName);
      }
      else {
         BaseProduct baseProduct = delegate.getBaseProduct(baseManufacturingName);
         baseProductsByBaseManfName.put(baseManufacturingName, baseProduct);
         return baseProduct;
      }
   }

   public boolean isValid(String cropName) {
      if(validCropName.containsKey(cropName)) {
         return validCropName.get(cropName);
      }
      else {
         boolean valid = delegate.isValid(cropName);
         validCropName.put(cropName, valid);
         return valid;
      }
   }

   public ManufacturingFamily[] getManufacturingFamilies(String[] baseManfNames) {
      return delegate.getManufacturingFamilies(baseManfNames);
   }
}