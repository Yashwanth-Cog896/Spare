package com.monsanto.tcc.lexicon.competitiveproduct;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Oct 13, 2004
 * Time: 9:55:29 AM
 * To change this template use File | Settings | File Templates.
 */
public class QueryBuilderParameter
{
   public static final int PROD_NAME_NUM  = 1;
   public static final int BAYER_CODE_NUM = 2;
   public static final int BRAND_NAME_NUM = 3;
   public static final int CNTRY_ABBR_NUM = 4;
   public static final int OR_TRIATS_NUM  = 5;
   public static final int AND_TRAITS_NUM = 6;
   public static final int PROD_NAME_PUBLIC_KEY_NUM = 7;
   public static final int PROD_PUBLIC_KEY_NUM = 8;

   public static final QueryBuilderParameter PROD_NAME  = new QueryBuilderParameter(PROD_NAME_NUM);
   public static final QueryBuilderParameter BAYER_CODE_NAME = new QueryBuilderParameter(BAYER_CODE_NUM);
   public static final QueryBuilderParameter BRAND_NAME = new QueryBuilderParameter(BRAND_NAME_NUM);
   public static final QueryBuilderParameter CNTRY_ABBR = new QueryBuilderParameter(CNTRY_ABBR_NUM);
   public static final QueryBuilderParameter OR_TRAITS  = new QueryBuilderParameter(OR_TRIATS_NUM);
   public static final QueryBuilderParameter AND_TRAITS = new QueryBuilderParameter(AND_TRAITS_NUM);
   public static final QueryBuilderParameter PROD_NAME_PUBLIC_KEY = new QueryBuilderParameter(PROD_NAME_PUBLIC_KEY_NUM);
   public static final QueryBuilderParameter PROD_PUBLIC_KEY = new QueryBuilderParameter(PROD_PUBLIC_KEY_NUM);

   private Integer _paramNum;

   protected QueryBuilderParameter(int paramNum) {
      _paramNum = new Integer(paramNum);
   }

   public int getParamNum() {
      return _paramNum.intValue();
   }

   public String toString() {
      return _paramNum.toString();
   }

   public int hashCode() {
      return _paramNum.hashCode();
   }
}
