package com.monsanto.tcc.lexicon.eventregulation.service;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.lexicon.spring.ThreadLocalApplicationContext;
import com.monsanto.tcc.lexiconcommon.exception.RuntimeWrappingException;
import com.monsanto.tps.lexicon.agency.Agency;
import com.monsanto.tps.lexicon.agency.AgencySearchCriteria;
import com.monsanto.tps.lexicon.agency.AgencyService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * nbwald - Feb 10, 2009 8:48:21 PM
 */
public class AgencyServiceImpl
   implements AgencyServiceFacade
{
   private final AgencyService agencyService;

   public AgencyServiceImpl() {
      ApplicationContext context =  ThreadLocalApplicationContext.getApplicationContext();
      agencyService = (AgencyService) context.getBean("agencyService");
   }

   @Override
   public Agency[] findAllAgencies() {
      try {
         return agencyService.findBySearchCriteria(new AgencySearchCriteria());
      }
      catch (WrappingException e) {
         throw new RuntimeWrappingException(e);
      }
   }
}
