package com.monsanto.tcc.lexicon.competitiveproduct;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.tcc.lexicon.businessdata.CompProdDAO;
import com.monsanto.tcc.lexicon.competitiveproduct.beans.CompProdQuery;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.RowObject;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.RowObjectList;
import com.monsanto.tcc.lexicon.utils.audit.AuditConstants;
import com.monsanto.tcc.lexicon.utils.audit.AuditDAO;
import com.monsanto.tcc.lexicon.utils.audit.AuditInfo;
import com.monsanto.tcc.lexicon.utils.db.LexiconConnectionHelper;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Jul 19, 2005
 * Time: 12:52:07 PM
 */
public class CompProdAuditHandler
{
	public static final String PRODUCT_NAME_TABLE = "PRODUCT_NAME";
	public static final String TABLE_DESCRIPTION = "Product Name";

   private final AuditDAO auditDAO;

   public CompProdAuditHandler(AuditDAO auditDAO) {
      this.auditDAO = auditDAO;
   }
   public CompProdAuditHandler() {
      this(AuditDAO.newInstance());
   }

   public void handleAudit(UCCHelper helper, CompProdQuery bean)
		throws IOException, WrappingException
	{
		PersistentStoreConnection conn = LexiconConnectionHelper.getDefaultConnection();
		Map<String, AuditInfo> entries = null;
		try {
			entries = getCompProdAuditInfo(conn, bean);
		}
		finally {
			conn.close();
		}
		helper.setRequestAttributeValue(AuditConstants.AUDIT_INFO_ENTRIES, entries);
	}

	public Map<String, AuditInfo> getCompProdAuditInfo(PersistentStoreConnection conn, CompProdQuery bean)
		throws WrappingException
	{
		Map<String, AuditInfo> entries = new HashMap<String, AuditInfo>();
		String[] rows = StringUtils.splitCsv(bean.getRowSelection(), false);
		CompProdDAO compProdDAO = CompProdDAO.newInstance();

		RowObjectList list = bean.getRowObjectList();
      for (String row : rows) {
         RowObject ro = (RowObject) list.get(Integer.parseInt(row));
         String pubkey = ro.getPublicKey();
         int primaryKey = compProdDAO.nameIdFromPublicKey(conn, pubkey);
         AuditInfo auditInfo = auditDAO.getAuditInfo(conn, PRODUCT_NAME_TABLE, Integer.toString(primaryKey));
         auditInfo.setTableDescription(TABLE_DESCRIPTION);
         auditInfo.setDescription(ro.getAuditDescription());
         entries.put(pubkey, auditInfo);
      }
		return entries;
	}
}
