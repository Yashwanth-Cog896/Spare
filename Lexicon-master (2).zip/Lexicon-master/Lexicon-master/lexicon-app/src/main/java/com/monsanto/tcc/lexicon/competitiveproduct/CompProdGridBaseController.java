package com.monsanto.tcc.lexicon.competitiveproduct;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.EnvironmentHelper;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.tcc.lexicon.LexiconServlet.LexiconUseCaseController;
import com.monsanto.tcc.lexicon.businessdata.CompProdDAO;
import com.monsanto.tcc.lexicon.competitiveproduct.beans.GridContainer;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.CompProdXmlUtils;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.RowObject;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.RowObjectList;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.RowObjectListReader;
import com.monsanto.tcc.lexicon.competitiveproduct.tablebuilder.GridPropertyMatrix;
import com.monsanto.tcc.lexicon.competitiveproduct.tablebuilder.HtmlTableBuilder;
import com.monsanto.tcc.lexicon.templates.type.RowStatusType;
import com.monsanto.tcc.lexicon.utils.ATCommentWriter;
import com.monsanto.tcc.lexicon.utils.LogWriter;
import com.monsanto.tcc.lexicon.utils.audit.AuditProcessNames;
import com.monsanto.tcc.lexicon.utils.db.LexiconConnectionHelper;
import com.monsanto.tcc.lexicon.utils.notification.EmailManager;
import com.monsanto.tcc.lexicon.utils.notification.NotificationType;
import com.monsanto.tcc.lexicon.utils.xml.XmlRepository;
import com.monsanto.tcc.lexiconcommon.db.audit.LexiconAuditor;
import com.monsanto.tcc.lexiconcommon.pos.LexiconServiceInvoker;
import com.monsanto.tcc.lexiconcommon.user.LexSecureUser;
import org.apache.regexp.RE;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: ADCOX
 * Date: Nov 2, 2004
 * Time: 4:31:51 PM
 */
public abstract class CompProdGridBaseController
   extends LexiconUseCaseController
{
   public static final String REQUEST_SORT = "requestSort";
   public static final String SORT_COLUMN = "sortByColumn";

   protected static final String ADD_VALIDATE_POSNAME = "FBS_ValidateCompetitiveProduct";
   protected static final String ADD_COMMIT_POSNAME = "FBS_AddCompetitiveProduct";
   protected static final String UPDATE_VALIDATE_POSNAME = "FBS_ValidateUpdateCompetitiveProduct";
   protected static final String UPDATE_COMMIT_POSNAME = "FBS_UpdateCompetitiveProduct";

   private void uncheckAllCommits(RowObjectList list) {
      Iterator iter = list.iterator();
      while (iter.hasNext()) {
         RowObject ro = (RowObject) iter.next();
         ro.setCommitFlag(false);
      }
   }

   protected void updateListFromRequest(RowObjectList list, UCCHelper helper, boolean bContainsActiveFlag)
      throws IOException,
             NoSuchMethodException,
             IllegalAccessException,
             InvocationTargetException
   {
      if (list == null) {
         return;
      }

      uncheckAllCommits(list);

      if (bContainsActiveFlag) {
         updateActiveFlags(helper, list);
      }

      RE re = new RE("^N(\\d+)_(.+)");

      Class[] acls = new Class[1];
      acls[0] = String.class;

      Object[] aobject = new Object[1];

      Enumeration num = helper.getParameterNames();
      while (num.hasMoreElements()) {
         String paramName = (String) num.nextElement();
         if (re.match(paramName)) {
            int index = Integer.parseInt(re.getParen(1));
            String baseMethodName = re.getParen(2);
            RowObject ro = (RowObject) list.get(index);
            if (canUpdateRowObjectFromRequest(ro)) {
               updateRowObjectFromRequest(helper, acls, aobject, paramName, baseMethodName, ro);
            }
         }
      }
   }

   private void updateRowObjectFromRequest(UCCHelper helper, Class[] acls, Object[] aobject, String paramName, String baseMethodName, RowObject ro)
      throws IOException, NoSuchMethodException, IllegalAccessException, InvocationTargetException
   {
      if (HtmlTableBuilder.COMMIT.equals(baseMethodName)) {
         setCommitFlag(helper, paramName, ro);
      }
      else if  (HtmlTableBuilder.ACTIVE.equals(baseMethodName)){ //NOPMD: ignore is active, handled in updateActiveFlags()

      }
      else {
         setValueOnRowObject(helper, acls, aobject, paramName, baseMethodName, ro);
      }
   }

   private void setCommitFlag(UCCHelper helper, String paramName, RowObject ro)
      throws IOException
   {
      String checked = helper.getRequestParameterValue(paramName);
      if ((!StringUtils.isNullOrEmpty(checked))&&(RowStatusType.VALIDATED.equals(ro.getStatus()))) {
            ro.setCommitFlag(true);
      }
   }

   private void setValueOnRowObject(UCCHelper helper, Class[] acls, Object[] aobject, String paramName, String baseMethodName, RowObject ro)
      throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, IOException
   {

      String camelBaseMethodName = baseMethodName.substring(0, 1).toUpperCase() +
         baseMethodName.substring(1);

      Method getter = ro.getClass().getMethod("get" + camelBaseMethodName, ((Class[]) null));
      String curVal = (String) getter.invoke(ro, ((Object[]) null));

      String newVal = helper.getRequestParameterValue(paramName);

      if (!areValuesEqual(curVal, newVal)) {
         Method setter = ro.getClass().getMethod("set" + camelBaseMethodName, acls);
         aobject[0] = newVal;
         setter.invoke(ro, aobject);
         ro.setStatus(RowStatusType.UNPROCESSED);
         ro.setCommitFlag(false);

         //_log.debug("found: " + baseMethodName + "(" + curVal + ") (" + newVal + ")");
      }
   }

   private boolean canUpdateRowObjectFromRequest(RowObject ro) {
      String status = ro.getStatus();
      return RowStatusType.ERRORED.equals(status) || RowStatusType.UNPROCESSED.equals(status) || RowStatusType.VALIDATED.equals(status);
   }

   private void updateActiveFlags(UCCHelper helper, RowObjectList list)
      throws IOException
   {
      for (int i = 0; i < list.size(); i++) {
         RowObject ro = (RowObject) list.get(i);
         if (canUpdateRowObjectFromRequest(ro)) {
            String checked = helper.getRequestParameterValue("N" + i + "_" + HtmlTableBuilder.ACTIVE);
            boolean inbound = !StringUtils.isNullOrEmpty(checked);
            if (inbound != ro.isActive()) {
               ro.setActive(inbound);
               ro.setStatus(RowStatusType.UNPROCESSED);
               ro.setCommitFlag(false);
               //_log.debug("found active flg: index " + i);
            }
         }
      }
   }

   private boolean areValuesEqual(String curVal, String newVal) {
      return StringUtils.isNullOrEmpty(curVal) ? StringUtils.isNullOrEmpty(newVal) : curVal.equals(newVal);
   }

   protected void resetRows(GridContainer bean, StringBuffer sbError, boolean bUsePubKey)
   {
      //_log.debug("inbound reset row list: " + bean.getResetRows());
      String[] astr = StringUtils.splitCsv(bean.getRowSelection(), false);
      if (astr.length == 0) {
         sbError.append("You must select a row to reset.");
      }
      else {
         Map<Integer, Integer> mapSrcXref = buildMapSrcXref(bean, bUsePubKey);

         List<Integer> listDeletions = new ArrayList<Integer>();
         RowObjectList listSrc = bean.getOrigRowObjectList();
         RowObjectList listDst = bean.getRowObjectList();
         for (String anAstr : astr) {
            int indexSrc = Integer.parseInt(anAstr);
            RowObject roDst = (RowObject) listDst.get(indexSrc);
            if (roDst.isCopied()) {
               listDeletions.add(indexSrc);
            }
            else {
               copyRow(sbError, bUsePubKey, mapSrcXref, listSrc, roDst);
            }
         }

         performDeletions(listDeletions, listDst);
      }
   }

   private Map<Integer, Integer> buildMapSrcXref(GridContainer bean, boolean bUsePubKey) {
      RowObject roSrc;
      Map<Integer, Integer> mapSrcXref = new HashMap<Integer, Integer>();
      Iterator iter = bean.getOrigRowObjectList().iterator();
      for (int index = 0; iter.hasNext(); index++) {
         roSrc = (RowObject) iter.next();
         String str = bUsePubKey ? roSrc.getPublicKey() : Integer.toString(roSrc.getRowNumber());
         if (!StringUtils.isNullOrEmpty(str)) {
            Integer i =  Integer.valueOf(str);
            mapSrcXref.put(i, index);
         }
      }
      return mapSrcXref;
   }

   private void performDeletions(List<Integer> listDeletions, RowObjectList listDst) {
      if (!listDeletions.isEmpty()) {
         Collections.sort(listDeletions, Collections.reverseOrder());
         for (Iterator iterator = listDeletions.iterator(); iterator.hasNext();) {
            Integer i = (Integer) iterator.next();
            listDst.remove(i.intValue());
         }
      }
   }

   private void copyRow(StringBuffer sbError, boolean bUsePubKey, Map<Integer, Integer> mapSrcXref, RowObjectList listSrc, RowObject roDst) {
      RowObject roSrc;
      Integer iLookup = null;
      String str = bUsePubKey ? roDst.getPublicKey() : Integer.toString(roDst.getRowNumber());
      if (!StringUtils.isNullOrEmpty(str)) {
         iLookup = Integer.valueOf(str);
      }

      Integer iIndex = mapSrcXref.get(iLookup);
      if (iIndex == null) {
         sbError.append("destination target not found: ").append(iLookup).append(". ");
      }
      else {
         roSrc = (RowObject) listSrc.get(iIndex);

         roDst.copy(roSrc);
      }
   }

   protected abstract GridPropertyMatrix buildGridPropertyMatrix(RowObjectList list)
      throws IOException;

   protected abstract Document[] getResponseDocsFromMidas(PersistentStoreConnection conn, TemplateDOMBuilder builder,
      Document docStorage, GridContainer bean, boolean bSendCommits)
      throws IOException, WrappingException;

   protected void callMidasPosAndSave(String fileName, LexSecureUser user, GridContainer bean, boolean bSaveXmlDocument, boolean bSendCommits)
      throws IOException, WrappingException, InvocationTargetException, NoSuchMethodException, IllegalAccessException
   {

      if (bean.getRowObjectList() == null) {
         return;
      }

      clearErrorsForUnprocessedRows(bean.getRowObjectList());

      TemplateDOMBuilder builder = new TemplateDOMBuilder(new RowObjectListReader(bean.getRowObjectList()));
      Document docStorage = builder.buildDocument(fileName, user.getLoginName());
      _log.info("ts: built storage doc");

      PersistentStoreConnection conn = getDatabaseConnection();
      try {
         Document[] responseDocs = getResponseDocsFromMidas(conn, builder, docStorage, bean, bSendCommits);
         _log.info("ts: response back from service");

         for (Document responseDoc : responseDocs) {
            saveResponseDoc(user, bean, bSendCommits, responseDoc);
            integrateResponseDocument(docStorage, responseDoc);
         }

         new CompProdXmlUtils().updateStatsNode(docStorage);
         if (bSaveXmlDocument) {
            saveDocument(docStorage);
         }
         _log.info("ts: saved data in lexicon");

         RowObjectList list = new RowObjectList(docStorage);
         bean.setRowObjectList(list);
         if (bSendCommits) {
            bean.setOrigRowObjectList((RowObjectList) list.clone());
         }
      }
      finally {
         LexiconConnectionHelper.closeConnection(conn, _log);
      }
   }

   private void saveResponseDoc(LexSecureUser user, GridContainer bean, boolean bSendCommits, Document responseDoc)
      throws WrappingException
   {
      if ((bSendCommits) &&(responseDoc != null)) {
         List exceptions = saveLexiconSchema(bean.getRowObjectList(), user, responseDoc, bean.getDefaultAuditComment());
         if (!exceptions.isEmpty()) {
            try {
               new EmailManager().sendExceptions(NotificationType.midasPosError,
                  "Error saving CP info in Lexicon; env=" + EnvironmentHelper.getFunction(),
                  exceptions);
            }
            catch (IOException ioe) {
               _log.error("error sending email: " + ioe.getMessage(), ioe);
            }
         }
      }
   }

   protected void clearErrorsForUnprocessedRows(RowObjectList roList) {
      for (int i = 0; i < roList.size(); i++) {
         String status = ((RowObject) roList.get(i)).getStatus();
         if (status.equals(RowStatusType.UNPROCESSED.getName())) {
            ((RowObject) roList.get(i)).setErrors(null);
         }
      }
   }

   private void integrateResponseDocument(Document docStorage, Document docResponse) {
      if (null != docResponse) {
         CompProdXmlUtils cpXmlUtil = new CompProdXmlUtils();
         NodeList listRows = cpXmlUtil.getRowElements(docResponse);

         for (int i = 0; i < listRows.getLength(); i++) {
            Element elemRow = (Element) listRows.item(i);
            Element elemStatus = cpXmlUtil.getStatusNode(elemRow);
            int rownum = cpXmlUtil.getRownum(elemRow);
            cpXmlUtil.replaceStatusNode(docStorage, rownum, elemStatus);
         }
      }
   }

   protected List<Exception> saveLexiconSchema(RowObjectList listSrc, LexSecureUser user, Document docResponseCommit, String defaultAuditComment)
      throws WrappingException
   {
      List<Exception> exceptions = new ArrayList<Exception>();
      CompProdXmlUtils util = new CompProdXmlUtils();

      int index = 0;
      CompProdDAO dao = CompProdDAO.newInstance();
      PersistentStoreConnection conn = getDatabaseConnection();
      try {
         NodeList nl = util.getRowElements(docResponseCommit);
         for (index = 0; index < nl.getLength(); index++) {
            Element elem = (Element) nl.item(index);
            if (RowStatusType.COMMITTED.equals(util.getStatus(elem))) {
               saveRowObject(listSrc, user, docResponseCommit, defaultAuditComment, exceptions, util, index, dao, conn, elem);
            }
         }
      }
      catch (WrappingException e) {
         LogWriter.logWrappingException(_log, e);

         // set the status for remaining rows not saved
         NodeList nl = util.getRowElements(docResponseCommit);
         for (; index < nl.getLength(); index++) {
            setLexiconAddErrorStatusToNode(docResponseCommit, index, e.getMessage());
         }
      }
      finally {
         conn.close();
      }

      return exceptions;
   }

   private void saveRowObject(RowObjectList listSrc, LexSecureUser user, Document docResponseCommit, String defaultAuditComment, List<Exception> exceptions, CompProdXmlUtils util, int index, CompProdDAO dao, PersistentStoreConnection conn, Element elem)
      throws WrappingException
   {
      RowObject ro = listSrc.getByRowNum(util.getRownum(elem));
      conn.beginTransaction();
      try {
         String comment = StringUtils.isNullOrEmpty(ro.getAuditComment()) ? defaultAuditComment : ro.getAuditComment();
         LexiconAuditor auditor = new LexiconAuditor(user.getLoginName(), getProcessName(ro), comment, ro.getAuditRequestor());
         auditor.initializeStaging(conn);
         dao.save(conn, ro);
         auditor.removeStaging(conn);
         conn.endTransaction();
      }
      catch (WrappingException e) {
         LogWriter.logWrappingException(_log, e);
         exceptions.add(e);
         setLexiconAddErrorStatusToNode(docResponseCommit, index, e.getMessage());
         conn.rollbackTransaction();
      }
   }

   private void setLexiconAddErrorStatusToNode(Document docResponseCommit, int nodeIndex, String errorDetail) {
      CompProdXmlUtils util = new CompProdXmlUtils();
      NodeList nl = util.getRowElements(docResponseCommit);
      Element row = (Element) nl.item(nodeIndex);
      util.addError(row, "Error saving transaction in Lexicon" + (errorDetail == null ? "" : ": " + errorDetail));
   }

   private void saveDocument(Document doc)
      throws WrappingException
   {
      XmlRepository repo = getXmlRepository();
      repo.saveDocument(doc);
   }

   protected void generateATComment(GridContainer bean, String testName, Document doc) {
      StringBuilder sb = new StringBuilder();
      if (!StringUtils.isNullOrEmpty(bean.getErrorMessage())) {
         sb.append(bean.getErrorMessage());
      }
      sb.append(ATCommentWriter.generateATComment(testName, doc, -1));
   }

   protected Document callPOS(Document docRequest, String posName)
      throws WrappingException
   {
      return new CompProdXmlUtils().hasRowElements(docRequest) ? new LexiconServiceInvoker(posName).call(docRequest) : null;
   }

   protected void assignKeys(Document commitAdds, PersistentStoreConnection conn, Document docStorage, GridContainer bean)
      throws WrappingException
   {
      CompProdKeyAssigner assigner = new CompProdKeyAssigner(commitAdds);
      assigner.assignKeys(conn);
      assigner.assignToStorageDoc(docStorage);
      assigner.assignToRowObjectList(bean.getRowObjectList());
   }

   protected String getProcessName(RowObject ro) {
      String processName;
      if (ro.isCopied()) {
         processName = AuditProcessNames.COPY_COMP_PROD;
      }
      else if (ro.isEditing()) {
         processName = AuditProcessNames.EDIT_COMP_PROD;
      }
      else {
         processName = AuditProcessNames.ADD_COMP_PROD;
      }
      return processName;
   }

   protected PersistentStoreConnection getDatabaseConnection()
      throws WrappingException
   {
      return LexiconConnectionHelper.getDefaultConnection();
   }
}
