/*
 EditManufacturingLineProcessor was created on Jan 22, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.process.manufacturingline.edit;

import com.monsanto.tcc.lexicon.baseproduct.dao.manufacturingline.edit.EditManufacturingLineDAO;
import com.monsanto.tcc.lexicon.baseproduct.model.EditableProductRelationship;
import com.monsanto.tcc.lexiconcommon.pos.ModelServiceCall;
import com.monsanto.tcc.lexiconcommon.pos.batch.BatchModelServiceProcessor;
import com.monsanto.tcc.lexiconcommon.pos.batch.InputModelBatchFilter;
import com.monsanto.tcc.lexiconcommon.pos.batch.ServiceRequestBuilder;
import com.monsanto.tcc.lexiconcommon.pos.batch.ServiceResponseMerger;
import com.monsanto.tcc.lexiconcommon.service.manufacturingline.edit.EditManufacturingLineRequest;
import com.monsanto.tcc.lexiconcommon.service.manufacturingline.edit.EditManufacturingLineResponse;
import java.util.List;

/**
 * nbwald Jan 22, 2008 2:04:53 PM
 */
public class EditManufacturingLineProcessor
   extends BatchModelServiceProcessor<EditableProductRelationship, EditManufacturingLineRequest, EditManufacturingLineResponse>
{
   private final EditManufacturingLineDAO dao;

   public EditManufacturingLineProcessor(EditManufacturingLineDAO dao) {
      this.dao = dao;
   }

   protected InputModelBatchFilter<EditableProductRelationship> getBatchFilter() {
      return new EditManufacturingLineBatchFilter();
   }

   protected ServiceRequestBuilder<EditableProductRelationship, EditManufacturingLineRequest> getRequestBuilder() {
      return new EditManufacturingLineRequestBuilder();
   }

   protected ServiceResponseMerger<EditableProductRelationship, EditManufacturingLineResponse> getResponseMerger() {
      return new EditManufacturingLineResponseMerger();
   }

   protected ModelServiceCall<List<EditManufacturingLineRequest>, List<EditManufacturingLineResponse>> getServiceCaller() {
      return dao;
   }
}