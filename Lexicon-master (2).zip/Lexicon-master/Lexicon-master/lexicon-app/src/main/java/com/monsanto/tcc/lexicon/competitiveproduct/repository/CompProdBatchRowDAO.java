package com.monsanto.tcc.lexicon.competitiveproduct.repository;

import com.monsanto.tcc.lexicon.utils.LogWriter;
import com.monsanto.tcc.lexicon.utils.db.LexiconConnectionHelper;
import com.monsanto.tcc.lexicon.utils.db.dao.SequenceGrabber;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.dataservices.PersistentStoreStatement;
import org.apache.log4j.Category;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Sep 13, 2004
 * Time: 3:54:12 PM
 * To change this template use File | Settings | File Templates.
 */
public class CompProdBatchRowDAO
{
   public static final String ROW_ID = "comp_prod_batch_row_id";
   public static final String BATCH_ID = "comp_prod_batch_id";
   public static final String ROWNUM = "comp_prod_batch_row_num";
   public static final String STATUS = "comp_prod_batch_row_status";
   public static final String XML_REP = "xml_representation";

   private static final String SEQ_NAME = "Comp_Prod_Batch_Row_Id_Seq";
   private static final SequenceGrabber s_grabber = new SequenceGrabber(SEQ_NAME);

   private int _iID;
   private int _iBatchID;
   private int _iRownum;
   private String _strStatus;
   private String _strXML;

   private Category _log = LogWriter.getCategory(getClass());

   public CompProdBatchRowDAO(
      PersistentStoreResultSetRow rsRow)
      throws WrappingException
   {
      super();
      fill(rsRow);
   }

   /**
    * Constructs an DAO object representing a new UserPreferenceValue enitity.
    * When/If a call to updatePersistenceStore is made the new record is added to the persistence store.
    */
   public CompProdBatchRowDAO(
      int iBatchID,
      int iRownum,
      String strStatus,
      String strXML)
   {
      _iID = -1;
      _iBatchID = iBatchID;
      _iRownum = iRownum;
      _strStatus = strStatus;
      _strXML = strXML;
   }

   public int getID() {
      return _iID;
   }
   public int getBatchID() {
      return _iBatchID;
   }
   public int getRownum() {
      return _iRownum;
   }
   public String getStatus() {
      return _strStatus;
   }
   public String getXML() {
      return _strXML;
   }

   public void updatePersistenceStore(
      PersistentStoreConnection conn)
      throws WrappingException
   {
      // If DAO object is new object(id < 0), perform insert
      if(_iID < 0)
      {
         // Get next object id
         _iID = s_grabber.getNextID(conn);

         String strSq1 = CompProdBatchDAOUtil.getInstance().getSQL(
            CompProdBatchDAOUtil.INSERT_BATCH_ROW, _log);
         _log.debug("values( " + _iID + "," + _iBatchID + "," + _iRownum + "," + _strStatus.substring(0, 1) + "," + "__xml__" + ")");

         PersistentStoreStatement stmt = null;
         try {
            stmt = conn.prepareStatement(strSq1);
            stmt.setParam(1, _iID);
            stmt.setParam(2, _iBatchID);
            stmt.setParam(3, _iRownum);
            stmt.setParam(4, _strStatus.substring(0, 1));
            stmt.setParam(5, _strXML);
            stmt.executeInsert();
         }
         finally {
            LexiconConnectionHelper.closeStatement(stmt, _log);
         }
      }
   }

   private void fill(
      PersistentStoreResultSetRow rsRow)
      throws WrappingException
   {
      _iID        = rsRow.getInt(ROW_ID);
      _iBatchID   = rsRow.getInt(BATCH_ID);
      _iRownum    = rsRow.getInt(ROWNUM);
      _strStatus  = rsRow.getString(STATUS);
      _strXML     = rsRow.getString(XML_REP);
   }
}
