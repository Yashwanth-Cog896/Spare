package com.monsanto.tcc.lexicon.comments.ucc;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.tcc.lexicon.LexiconServlet.SimpleLexiconUCC;
import com.monsanto.tcc.lexicon.comments.bean.CommentsProductSearchBean;
import com.monsanto.tcc.lexicon.comments.bean.ProductAdditionalCommentsBean;
import com.monsanto.tcc.lexicon.spring.ThreadLocalApplicationContext;
import com.monsanto.tps.productstewardship.comments.service.ProductAdditionalCommentsNameType;
import com.monsanto.tps.productstewardship.comments.service.ProductAdditionalCommentsSearchResult;
import com.monsanto.tps.productstewardship.comments.service.ProductAdditionalCommentsService;
import org.apache.commons.lang.StringUtils;

import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Oct 10, 2011
 * Time: 2:18:02 PM
 * To change this template use File | Settings | File Templates.
 */
public class SearchProductAdditionalCommentsUCC extends SimpleLexiconUCC {
    private FormScraper formScraper = new FormScraper();
    @Override
    protected void executeAction(UCCHelper helper) throws Exception {

        CommentsProductSearchBean searchBean = (CommentsProductSearchBean)helper.getSessionParameter(AdditionalCommentsConstants.COMMENTS_PRODUCT_SEARCH_BEAN);
        formScraper.scrapeForm(helper,searchBean);
        List<String> crops = splitParameter(searchBean.getCrops());
        List<String> productNames = splitParameter(searchBean.getProductName());
        ProductAdditionalCommentsService productAdditionalCommentsService = (ProductAdditionalCommentsService) ThreadLocalApplicationContext.getApplicationContext().getBean("productAdditionalCommentsService");
        searchBean.setRowCount(getRowCount(searchBean, crops, productNames, searchBean.getNameType(),productAdditionalCommentsService));
        searchBean.setProductAdditionalComments(findProductAdditionalComments(searchBean, crops, productNames , searchBean.getNameType(), productAdditionalCommentsService));

        helper.setSessionParameter(AdditionalCommentsConstants.COMMENTS_PRODUCT_SEARCH_BEAN,searchBean);
    }

    private List<ProductAdditionalCommentsBean> findProductAdditionalComments(CommentsProductSearchBean searchBean, List<String> crops, List<String> productNames, ProductAdditionalCommentsNameType nameType, ProductAdditionalCommentsService productAdditionalCommentsService) {
        List<ProductAdditionalCommentsBean> products =  new ArrayList<ProductAdditionalCommentsBean>();
        if(!productNames.isEmpty()){
            List<ProductAdditionalCommentsSearchResult> searchResults = productAdditionalCommentsService.findPagedProductAdditionalComments(productNames, nameType, crops,10,searchBean.getPageNumber()-1);
            if(searchResults!=null){
                buildProductAdditionalCommentsBeans(products, searchResults);
            }
        }
        return products;
    }

    private void buildProductAdditionalCommentsBeans(List<ProductAdditionalCommentsBean> products, List<ProductAdditionalCommentsSearchResult> searchResults) {
        for(ProductAdditionalCommentsSearchResult searchResult: searchResults){
            ProductAdditionalCommentsBean product = new ProductAdditionalCommentsBean();
            product.setCrop(searchResult.getCrop());
            product.setPreCommercialName(searchResult.getPreCommercialName());
            product.setProductPubkey(searchResult.getProductPubkey());
            product.setVarietyName(searchResult.getVarietyName());
            product.setAdditionalComments(searchResult.getAdditionalComments());
            product.setUnmodifiedAdditionalComments(searchResult.getAdditionalComments());
            products.add(product);
        }
    }

    private int  getRowCount(CommentsProductSearchBean searchBean, List<String> crops, List<String> productNames, ProductAdditionalCommentsNameType nameType, ProductAdditionalCommentsService productAdditionalCommentsService) {
        long rowCount = searchBean.getRowCount();
        if((!productNames.isEmpty())&&(searchBean.getPageNumber()==1)){
             rowCount =  productAdditionalCommentsService.countProductAdditionalComments(productNames,nameType, crops);
        }
        return (int)rowCount;
    }

    private List<String> splitParameter(String parameter) {

        List<String> parameters = new ArrayList<String>();
        if(StringUtils.isNotBlank(parameter)){
            if(parameter.contains(",")){
                for(String singleParameter :Arrays.asList(parameter!=null?parameter.toUpperCase().split(","):null)){
                    parameters.add(singleParameter.trim());
                }
            }
            else {
                parameters.add(parameter.trim().toUpperCase());
            }
        }
        return parameters;
    }


}
