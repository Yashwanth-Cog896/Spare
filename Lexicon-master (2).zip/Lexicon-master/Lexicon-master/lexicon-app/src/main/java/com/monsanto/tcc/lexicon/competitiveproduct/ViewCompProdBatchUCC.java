package com.monsanto.tcc.lexicon.competitiveproduct;

import com.monsanto.POSClient.POSCommunicationException;
import com.monsanto.POSClient.POSException;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.tcc.lexicon.LexiconServlet.beans.ToolBar;
import com.monsanto.tcc.lexicon.competitiveproduct.beans.FileDisplayItem;
import com.monsanto.tcc.lexicon.competitiveproduct.beans.GridContainer;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.RowObject;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.RowObjectList;
import com.monsanto.tcc.lexicon.competitiveproduct.repository.CompProdXmlRepositoryHeader;
import com.monsanto.tcc.lexicon.competitiveproduct.tablebuilder.GridPropertyMatrix;
import com.monsanto.tcc.lexicon.competitiveproduct.tablebuilder.HtmlTableBuilder;
import com.monsanto.tcc.lexicon.controllers.GridToExcelUCC;
import com.monsanto.tcc.lexicon.controllers.HtmlTableLoader;
import com.monsanto.tcc.lexicon.exception.LexiconException;
import com.monsanto.tcc.lexicon.exception.LexiconRuntimeException;
import com.monsanto.tcc.lexicon.preference.Preference;
import com.monsanto.tcc.lexicon.preference.PreferenceBean;
import com.monsanto.tcc.lexicon.preference.value.HideCommittedRowsValue;
import com.monsanto.tcc.lexicon.preference.value.PreferenceValue;
import com.monsanto.tcc.lexicon.templates.type.RowStatusType;
import com.monsanto.tcc.lexicon.utils.LogWriter;
import com.monsanto.tcc.lexicon.utils.PropertyTool;
import com.monsanto.tcc.lexicon.utils.gui.HtmlCell;
import com.monsanto.tcc.lexicon.utils.gui.HtmlRow;
import com.monsanto.tcc.lexicon.utils.gui.HtmlTable;
import com.monsanto.tcc.lexicon.utils.resourcelock.ResourceLock;
import com.monsanto.tcc.lexicon.utils.xml.XmlRepository;
import com.monsanto.tcc.lexiconcommon.PreferenceNames;
import com.monsanto.tcc.lexiconcommon.exception.RuntimeWrappingException;
import com.monsanto.tcc.lexiconcommon.user.LexSecureUser;
import com.monsanto.tcc.lexiconcommon.user.LexSecureUserHelperImpl;
import org.apache.regexp.RE;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Comparator;
import java.util.List;
import java.util.Properties;

/**
 * Created by IntelliJ IDEA.
 * User: adcox
 * Date: Aug 30, 2004
 * Time: 1:54:16 PM
 */
public class ViewCompProdBatchUCC
   extends CompProdGridBaseController
   implements HtmlTableLoader
{
   public static final String PROP_FILENAME = "CompProdGrid.properties";

   public static final String FILENAME    = "fileName";
   public static final String SUBMIT      = "submitBtn";

   public static final String DELETE_ROW  = "deleteRow";
   public static final String SHOW_HIDE   = "showHide";
   public static final String RESET_ROWS  = "resetRows";
   public static final String DEFAULT_AUDIT_COMMENT = "defaultAuditComment";

   private static final String DELETE_FILE    = "Delete File";
   private static final String TABLE_ID = "add_competitive_product";
//   private static final String VALIDATE_POSNAME = "FBS_ValidateCompetitiveProduct";
//   private static final String COMMIT_POSNAME = "FBS_AddCompetitiveProduct";

   protected boolean requiresPreferenceBean() {
      return true;
   }

   protected boolean unlockResources(UCCHelper helper) {
      return false;
   }

   public void doService(UCCHelper helper)
      throws IOException
   {
      _log.info("ts: enter ViewCompProdBatchUCC.doService()");

      boolean bBuildGrid = true;
      String fwd = getSuccessForward();
      StringBuffer sbError = new StringBuffer();

      LexSecureUser user = new LexSecureUserHelperImpl(helper);
      try {
         FileDisplayItem bean = loadBeanFromSessionAndValidate(user, helper);

         ResourceLock lock = getResourceLock();
         if (lock.lock(bean.getFileName(), user.getLoginName())) {
            String deleteRow = bean.getDeleteRow();
            //String showHide = helper.getRequestParameterValue(SHOW_HIDE);
            String submit = helper.getRequestParameterValue(SUBMIT);

            updateListFromRequest(bean.getRowObjectList(), helper, false);

            fwd = performAction(helper, bBuildGrid, fwd, sbError, user, bean, deleteRow, submit);
         }
         else {
            fwd = getFailedForward();
            bBuildGrid = false;
            String str =
                    "That file (" + bean.getFileName() + ") is currently in use by userid: " +
                    lock.getLockingUser(bean.getFileName()) + ".";

            helper.setRequestAttributeValue(CompProdUCC.STATUS_ATTRIB, str);
         }
      }
      catch (FileNotFoundException fnf) {
         fwd = getFailedForward();
         bBuildGrid = false;
         helper.setRequestAttributeValue(CompProdUCC.STATUS_ATTRIB, fnf.getMessage());
      }
      catch (InvocationTargetException e) {
         throw new RuntimeWrappingException(e);
      }
      catch (NoSuchMethodException e) {
         throw new RuntimeWrappingException(e);
      }
      catch (POSCommunicationException e) {
         throw new RuntimeWrappingException(e);
      }
      catch (IllegalAccessException e) {
         throw new RuntimeWrappingException(e);
      }
      catch (POSException e) {
         throw new RuntimeWrappingException(e);
      }
      catch (SAXException e) {
         throw new RuntimeWrappingException(e);
      }
      catch (LexiconException e) {
         throw new RuntimeWrappingException(e);
      }
      catch (WrappingException e) {
         throw new RuntimeWrappingException(e);
      }

      _log.info("ts: exit ViewCompProdBatchUCC.doService()");
      helper.forward(fwd);
   }

   private String performAction(UCCHelper helper, boolean bBuildGrid, String fwd, StringBuffer sbError, LexSecureUser user, FileDisplayItem bean, String deleteRow, String submit)
      throws IOException, WrappingException, InvocationTargetException, NoSuchMethodException, IllegalAccessException
   {
      //TODO: the logic for what action will be taken is complicated.  Take some time to simplify it.(Maybe we should write tests for this first)
      _log.debug("submit: " + submit);
      if (!StringUtils.isNullOrEmpty(deleteRow) &&
              StringUtils.isNullOrEmpty(submit))
      {
         logicalDeleteRow(bean);
      }
      else {
         if (ToolBar.VALIDATE_SUBMIT.equals(submit)) {
            callMidasPosAndSave(bean.getFileName(), user, bean, true, false);
         }
         else if (ToolBar.COMMIT_SUBMIT.equals(submit)) {
            callMidasPosAndSave(bean.getFileName(), user, bean, true, true);
         }
         else if (ToolBar.RESET_SUBMIT.equals(submit)) {
            resetRows(bean, sbError, false);
         }
         else if (DELETE_FILE.equals(submit)) {
            bBuildGrid = false;
            fwd = getFailedForward();
            deleteFile(bean, helper);
         }
         else if(!StringUtils.isNullOrEmpty(submit)) {
            stringBuilderAppend(sbError,"Unhandled submit value: " , submit);
            _log.error("Unhandled submit value: " + submit);
         }
      }

      if (bBuildGrid) {
         buildDisplayGrid(bean, sbError);
      }
      return fwd;
   }

   private void stringBuilderAppend(StringBuffer sb,String ... strings){
      for(String string:strings){
         sb.append(string);
      }
   }
   private HtmlTable buildDisplayGrid(
      FileDisplayItem bean,
      StringBuffer sbError)
           throws IllegalAccessException,
           NoSuchMethodException,
           IOException,
           InvocationTargetException, WrappingException
   {
      Properties props = PropertyTool.loadProperties(this, PROP_FILENAME);
      HtmlTableBuilder builder = new HtmlTableBuilder();
      Comparator comparator = builder.getComparator(bean, props, sbError);
      GridPropertyMatrix matrix = buildGridPropertyMatrix(bean.getRowObjectList());
      return builder.buildDisplayGrid(comparator, bean, matrix, sbError, true, true);

   }

   protected void deleteFile(
      FileDisplayItem bean,
      UCCHelper helper)
      throws WrappingException
   {
      String str = null;
      XmlRepository repo = getXmlRepository();
      try {
         CompProdXmlRepositoryHeader hdr = bean.getHeader();
         if (hdr.numCommitted() > 0) {
            str = "Cannot remove file with committed rows.";
         }
         else {
            if (repo.removeDocument(hdr)) {
               str = "Removed file: " + bean.getFileName();
            }
            else {
               str = "FAILED to remove file; no message given";
            }
         }
      }
      catch (WrappingException e) {
         LogWriter.logWrappingException(_log, e);
         str = "FAILED to remove file: " + e.getMessage();
      }

      helper.setRequestAttributeValue(CompProdUCC.STATUS_ATTRIB, str);
      helper.removeSessionParameter(FileDisplayItem.ATTR_NAME);
   }

   private FileDisplayItem loadBeanFromSessionAndValidate(LexSecureUser user, UCCHelper helper)
      throws WrappingException, InvocationTargetException, SAXException, POSException, POSCommunicationException, IOException, NoSuchMethodException, IllegalAccessException, LexiconException
   {
      //SecureUser user = (SecureUser) helper.getSessionParameter(I_SessionParams.sf_cstrCURRENT_USER);
      if (user == null) {
         throw new LexiconRuntimeException("Expecting SecureUser in the session");
      }

      // grab inbound name from request.  Check both param and attribute.  This
      // request may have been chained from CompProdUCC
      String name = helper.getRequestParameterValue(FILENAME);

      // get existing bean
      FileDisplayItem bean =
         (FileDisplayItem) helper.getSessionParameter(FileDisplayItem.ATTR_NAME);

      // if bean is defined and name is not, assign name from bean.  This allows
      // user to jump back to this screen from menu
      if (bean != null && StringUtils.isNullOrEmpty(name)) {
         name = bean.getFileName();
      }

      // Name needs to come from somewhere.
      if (StringUtils.isNullOrEmpty(name)) {
         throw new LexiconRuntimeException("Expecting passed in name.");
      }

      // It's possible that the file has been deleted.  Make sure that the file
      // does exists.
      XmlRepository repo = getXmlRepository();
      CompProdXmlRepositoryHeader header = (CompProdXmlRepositoryHeader)repo.getHeader(name);
      if (header == null) {
         throw new FileNotFoundException("File not found: " + name);
      }

      // If bean is not defined or bean does not represent the file associated with name
      // Load the file represented by name and set the bean accordingly
      if (bean == null || !name.equals(bean.getFileName())) {
         //CompProdXmlRepositoryHeader header = (CompProdXmlRepositoryHeader)repo.getHeader(name);
         bean = new FileDisplayItem();
         bean.setHeader(header);
         bean.setDefaultAuditComment("template add: " + bean.getFileName());
         helper.setSessionParameter(FileDisplayItem.ATTR_NAME, bean);
      }

      if (bean.getRowObjectList() == null) {
         Document doc = loadDocument(bean.getHeader());
         RowObjectList list = new RowObjectList(doc);
         bean.setRowObjectList(list);
         bean.setOrigRowObjectList((RowObjectList)list.clone());
      }

      if (bean.isForcePosCall()) {
         bean.setForcePosCall(false);
         callMidasPosAndSave(bean.getFileName(), user, bean, true, false);
      }
      else {
         bean.setDefaultAuditComment(helper.getRequestParameterValue(DEFAULT_AUDIT_COMMENT));
         bean.setErrorMessage(null);
      }

      bean.setDeleteRow(helper.getRequestParameterValue(DELETE_ROW));
      bean.setRowSelection(helper.getRequestParameterValue(RESET_ROWS));

      String sortColumn = helper.getRequestParameterValue(CompProdGridBaseController.SORT_COLUMN);
      if (StringUtils.isNullOrEmpty(sortColumn)) {
         sortColumn = HtmlTableBuilder.ROW_NUMBER;
      }
      bean.toggleSortRequest(sortColumn,
                             helper.getRequestParameterValue(CompProdGridBaseController.REQUEST_SORT));

      String showHide = helper.getRequestParameterValue(SHOW_HIDE);
      if (!StringUtils.isNullOrEmpty(showHide)) {
         //PreferenceBean prefBean = (PreferenceBean)helper.getSessionParameter(PreferenceBean.BEAN_NAME);
         PreferenceBean prefBean = PreferenceBean.getFromSession(helper);
         Preference pref = prefBean.getPreference(PreferenceNames.HIDE_COMMIT_CPROWS_PREF_NAME);
         pref.setPrimaryValue(new HideCommittedRowsValue(showHide));
      }
      bean.setHideCommitted(doHideCommitted(helper));

      if (StringUtils.isNullOrEmpty(bean.getExcelLink())) {
         String link = new GridToExcelUCC().getLink(this.getId());
         bean.setExcelLink(link);
      }
      return bean;
   }

   private boolean doHideCommitted(
      UCCHelper helper)
   {
      //PreferenceBean prefBean = (PreferenceBean)helper.getSessionParameter(PreferenceBean.BEAN_NAME);
      PreferenceBean prefBean = PreferenceBean.getFromSession(helper);
      Preference pref = prefBean.getPreference(PreferenceNames.HIDE_COMMIT_CPROWS_PREF_NAME);
      PreferenceValue value = pref.getPrimaryValue();
      return (null == value) ? false : ((Boolean)value.getObject()).booleanValue();
   }

   private void logicalDeleteRow(
      FileDisplayItem bean) 
   {
      String rowNum = bean.getDeleteRow();
      bean.setDeleteRow(null);

      List list = bean.getRowObjectList();
      RowObject ro = (RowObject)list.get(Integer.parseInt(rowNum));

      if (RowStatusType.COMMITTED.equals(ro.getStatus())) {
         throw new LexiconRuntimeException("Cannot delete completed transaction.");
      }

      if (RowStatusType.ABANDONED.equals(ro.getStatus())) {
         ro.setStatus(RowStatusType.UNPROCESSED);
      }
      else {
         ro.setStatus(RowStatusType.ABANDONED);
      }
   }

   private Document loadDocument(
      CompProdXmlRepositoryHeader header)
      throws WrappingException,
             SAXException
   {
      XmlRepository repo = getXmlRepository();
      return repo.loadDocument(header);
   }

   public String getId() {
      return TABLE_ID;
   }

   public HtmlTable getTable(UCCHelper helper)
      throws IOException, InvocationTargetException, NoSuchMethodException, WrappingException, IllegalAccessException
   {
      HtmlTable table = new HtmlTable();

      FileDisplayItem bean =
         (FileDisplayItem) helper.getSessionParameter(FileDisplayItem.ATTR_NAME);

      if (bean == null) {
         _log.warn("Anomally: getTable() called without bean in session.");
      }
      else {
         StringBuffer sb = new StringBuffer();
         table = buildDisplayGrid(bean, sb);
         table.stripNBSP();

         RE re = new RE("TITLE=\"(.*?)\"");

         // Extract title from status column
         for (int r = 0; r < table.size(); r++) {
            HtmlRow row = table.getRow(r);
            if (!row.isHidden()) {
               HtmlCell cell = row.getCell(HtmlTableBuilder.STATUS);

               String content = cell.getContent();
               if (re.match(content)) {
                  cell.setContent(parseTitle(re));
               }
            }
         }
      }
      return table;
   }

   private String parseTitle(RE re) {
      String content;
      content = re.getParen(1);
      int i = content.indexOf(" ");
      if (i > 0) {
         content = content.substring(0, i);
      }
      return content;
   }

   public ToolBar getToolBar(UCCHelper helper)
   {
      ToolBar tb = new ToolBar();
      tb.setExcelDisabled(false);
      tb.setResetRowDisabled(false);
      tb.setCommitDisabled(false);
      tb.setValidateDisabled(false);
      tb.setExcelId(getId());
      tb.setSeparatorDisabled(false);

      tb.setNestedFormName("SubmitChanges");
      tb.setNestedInputName(SUBMIT);

      return tb;
   }

   protected GridPropertyMatrix buildGridPropertyMatrix(RowObjectList list)
      throws IOException
   {
      return new GridPropertyMatrix(
              list,
              PropertyTool.loadProperties(this, PROP_FILENAME));
   }

   protected Document[] getResponseDocsFromMidas(
      PersistentStoreConnection conn,
      TemplateDOMBuilder builder,
      Document docStorage,
      GridContainer bean,
      boolean bSendCommits)
      throws IOException, WrappingException

   {
      _log.info("ts: calling services...");

      Document[] responseDocs = new Document[1];
      CompProdValidator validator = new CompProdValidator();

      if (bSendCommits) {
         validator.validateCommitsAndSetStatus(docStorage, conn);
         Document docRequestCommit = builder.buildRequestDocument(docStorage, conn, false);
         assignKeys(docRequestCommit, conn, docStorage, bean);
         responseDocs[0] = callPOS(docRequestCommit, ADD_COMMIT_POSNAME);
         if (responseDocs[0] != null) {
            _log.info("ts: response back from " + ADD_COMMIT_POSNAME);
         }
         generateATComment(bean, "TEST1", docRequestCommit);
      }
      else {
         validator.validateAndSetStatus(docStorage, conn);
         Document docRequestValidate = builder.buildRequestDocument(docStorage, conn, true);
         //_log.info("ts: request xml: " + DOMUtil.dumpToString(docRequestValidate));
         responseDocs[0] = callPOS(docRequestValidate, ADD_VALIDATE_POSNAME);
         if (responseDocs[0] != null) {
            _log.info("ts: response back from " + ADD_VALIDATE_POSNAME);
         }
         generateATComment(bean, "TEST2", docRequestValidate);
      }

      return responseDocs;
   }
}
