package com.monsanto.tcc.lexicon.baseproduct.process.baseproduct.create;

import com.monsanto.tcc.lexicon.baseproduct.dao.baseproduct.create.CreateBaseProduct;
import com.monsanto.tcc.lexicon.baseproduct.model.BaseProductBean;
import com.monsanto.tcc.lexicon.typedata.queryset.ReferenceDataQuerySet;
import com.monsanto.tcc.lexiconcommon.pos.batch.BatchModelServiceProcessor;
import com.monsanto.tcc.lexiconcommon.pos.batch.InputModelBatchFilter;
import com.monsanto.tcc.lexiconcommon.pos.batch.ServiceRequestBuilder;
import com.monsanto.tcc.lexiconcommon.pos.batch.ServiceResponseMerger;
import com.monsanto.tcc.lexiconcommon.service.baseproduct.CreateBaseProductRequest;
import com.monsanto.tcc.lexiconcommon.service.baseproduct.CreateBaseProductResponse;

/**
 * nbwald Jul 5, 2007 2:07:33 PM
 */
public class CreateBaseProductProcessor
   extends BatchModelServiceProcessor<BaseProductBean, CreateBaseProductRequest, CreateBaseProductResponse>
{
   private final CreateBaseProduct creator;
   private final ReferenceDataQuerySet refLookup;

   public CreateBaseProductProcessor(CreateBaseProduct creator, ReferenceDataQuerySet refLookup) {
      this.creator = creator;
      this.refLookup = refLookup;
   }

   protected InputModelBatchFilter<BaseProductBean> getBatchFilter() {
      return new CreateBaseProductBatchFilter();
   }
   protected ServiceRequestBuilder<BaseProductBean, CreateBaseProductRequest> getRequestBuilder() {
      return new CreateBaseProductRequestBuilder(refLookup);
   }
   protected ServiceResponseMerger<BaseProductBean, CreateBaseProductResponse> getResponseMerger() {
      return new CreateBaseProductResponseMerger();
   }
   protected CreateBaseProduct getServiceCaller() {
      return creator;
   }
}
