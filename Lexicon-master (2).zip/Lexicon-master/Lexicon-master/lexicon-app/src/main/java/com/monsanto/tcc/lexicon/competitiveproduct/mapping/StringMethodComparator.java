package com.monsanto.tcc.lexicon.competitiveproduct.mapping;

import com.monsanto.tcc.lexicon.competitiveproduct.mapping.RowObject;
import org.springframework.util.comparator.NullSafeComparator;

import java.util.Comparator;

/**
 * nbwald - Nov 12, 2009 12:35:56 PM
*/
public abstract class StringMethodComparator
   implements Comparator<RowObject>
{
   @Override
   public int compare(RowObject a, RowObject b) {
      NullSafeComparator nullSafeComparator = new NullSafeComparator(new CaseIgnoringComparator(), true);
      return nullSafeComparator.compare(eval(a), eval(b));
   }

   public abstract String eval(RowObject rowObject);

   private class CaseIgnoringComparator
      implements Comparator<String>
   {
      @Override
      public int compare(String a, String b) {
         return a.compareToIgnoreCase(b);
      }
   }

}
