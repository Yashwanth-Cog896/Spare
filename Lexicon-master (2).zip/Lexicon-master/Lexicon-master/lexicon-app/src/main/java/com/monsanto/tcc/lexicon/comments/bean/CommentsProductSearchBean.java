package com.monsanto.tcc.lexicon.comments.bean;


import com.monsanto.tps.productstewardship.comments.service.ProductAdditionalCommentsNameType;
import org.apache.commons.lang.StringUtils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Oct 10, 2011
 * Time: 2:05:06 PM
 * To change this template use File | Settings | File Templates.
 */
public class CommentsProductSearchBean implements Serializable{
     

    private String productName;
    private ProductAdditionalCommentsNameType nameType=ProductAdditionalCommentsNameType.PRE_COMMERCIAL;
    private List<ProductAdditionalCommentsNameType> nameTypes;
    private List<ProductAdditionalCommentsBean> productAdditionalComments = new ArrayList<ProductAdditionalCommentsBean>();
    private Integer pageNumber =1;
    private Integer rowCount =0;
    private String rownum;
    private String actionField;
    
    private String crops;



    public boolean isEditing(){
        boolean editing = false;
        if(productAdditionalComments!=null){
           for(ProductAdditionalCommentsBean comments: productAdditionalComments){
               editing |= comments.isEditing();
           }
        }
        return editing;
    }
    public String getCrops() {
        return crops;
    }

    public void setCrops(String crops) {
        this.crops = crops;
    }

    public ProductAdditionalCommentsNameType getNameType() {
        return nameType;
    }

    public void setNameType(ProductAdditionalCommentsNameType nameType) {
        this.nameType = nameType;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public List<ProductAdditionalCommentsNameType> getNameTypes() {
        return nameTypes;
    }

    public void setNameTypes(List<ProductAdditionalCommentsNameType> nameTypes) {
        this.nameTypes = nameTypes;
    }

    public List<ProductAdditionalCommentsBean> getProductAdditionalComments() {
        return productAdditionalComments;
    }

    public void setProductAdditionalComments(List<ProductAdditionalCommentsBean> productAdditionalComments) {
        this.productAdditionalComments = productAdditionalComments;
    }

    public String getActionField() {
        return actionField;
    }

    public void setActionField(String actionField) {
        this.actionField = actionField;
    }

    public String getRownum() {
        return rownum;
    }

    public void setRownum(String rownum) {
        this.rownum = rownum;
    }

    public Integer getPageNumber() {
        return pageNumber;
    }

    public void setPageNumber(Integer pageNumber) {
        this.pageNumber = pageNumber;
    }

    public Integer getRowCount() {
        return rowCount;
    }

    public void setRowCount(Integer rowCount) {
        this.rowCount = rowCount;
    }
    public boolean isCriteriaSet(){
        return StringUtils.isNotBlank(crops)||StringUtils.isNotBlank(productName);
    }
}
