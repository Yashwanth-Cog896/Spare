package com.monsanto.tcc.lexicon.controllers;

import com.monsanto.tcc.lexicon.LexiconServlet.LexiconUseCaseController;
import com.monsanto.tcc.lexicon.controllers.beans.DetailSelection;
import com.monsanto.tcc.lexicon.preference.PreferenceBean;
import com.monsanto.tcc.lexicon.preference.util.PreferenceCountry;
import com.monsanto.tcc.lexicon.preference.util.PreferenceCountryCollection;
import com.monsanto.tcc.lexicon.referencetable.lookups.DetailSelectionClient;
import com.monsanto.tcc.lexicon.utils.PropertyTool;
import com.monsanto.tcc.lexicon.utils.gui.HtmlOption;
import com.monsanto.tcc.lexicon.utils.gui.HtmlSelect;
import com.monsanto.tcc.lexicon.applicationroles.AppRoles;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.StringUtils;

import java.io.IOException;
import java.util.Map;
import java.util.Properties;

/**
 * Created by IntelliJ IDEA.
 * User: adcox
 * Date: Oct 13, 2004
 * Time: 2:21:27 PM
 * To change this template use File | Settings | File Templates.
 */
public class DetailSelectionUCC
        extends LexiconUseCaseController {
    public static final String KEY = "key";
    public static final String INITIAL_VALUE = "initialValue";
    public static final String ROWNUM = "rownum";
    public static final String PARAMETER = "parameter";
    public static final String SUBMIT_BUTTON = "submitBtn";
    public static final String SRC_FIELD = "srcFieldName";
    public static final String SOURCE_PAGE = "sourcePage";
    public static final String ADD_TEMPLATE = "addTemplate";
    public static final String SOURCE_ROW_SELECTIONS = "sourceRowSelections";

    private static final String PROP_FILENAME = "DetailSelection.properties";
    private static final String MONSANTO_PRODUCT_COUNTRY = "mp_country";

    private static final String DOT_TITLE = ".TITLE";
    private static final String DOT_LIST_TITLE = ".LIST_TITLE";
    private static final String DOT_CLIENT_CLASS = ".CLIENT_CLASS";
    private static final String DOT_ENTITY_NAME = ".ENTITY_NAME";
    private static final String DOT_NO_SELECT_TEXT = ".NO_SELECT_TEXT";

    // additions to apply to select HTML
    private static final String SELECT_NAME = "detailSelectName";
    private static final String JAVASCRIPT = "ondblclick=\"detailOkClicked();\"";


    public void doService(UCCHelper helper)
            throws Exception {
        AppRoles appRoles = new AppRoles(helper);
        DetailSelection bean = loadBeanFromRequest(helper);
        String fwd = getSuccessForward();

        String btn = bean.getSubmitBtn();
        if (StringUtils.isNullOrEmpty(btn)) {
            DetailSelectionClient client = getDetailSelectionClient(bean.getKey());

            boolean allowMultiple = isMultipleAllowed(bean.getSourcePage());
            HtmlSelect select = client.buildHtmlSelect(bean.getKey(), bean.getParameter(), allowMultiple, appRoles);

            if (bean.getKey().equals(MONSANTO_PRODUCT_COUNTRY)) {
                insertCountryPreferenceValues(helper, select);
            }

            if (select.getOptionCount() > 0) {
                select.setName(SELECT_NAME);
                select.setJavascript(JAVASCRIPT);
                if (!StringUtils.isNullOrEmpty(bean.getInitialValue())) {
                    Map map = StringUtils.CsvToMap(bean.getInitialValue(), true);
                    select.setSelectedByValue(map);
                }
                bean.setSelectHtml(select.toHtml().toString());
                if (!StringUtils.isNullOrEmpty(client.getSrcFieldName())) {
                    bean.setSrcFieldName(client.getSrcFieldName());
                }
            } else {
                bean.setNoSelections(true);
            }
        } else {
            String str = "Unexpected submit value:" + btn;
            _log.error(str);
            throw new RuntimeException(str);
        }


        helper.forward(fwd);
    }

    private boolean isMultipleAllowed(String sourcePage) {
        boolean allowMultiple = true;
        if (!StringUtils.isNullOrEmpty(sourcePage) && sourcePage.equalsIgnoreCase(ADD_TEMPLATE)) {
            allowMultiple = false;
        }
        return allowMultiple;
    }

    private DetailSelection loadBeanFromRequest(UCCHelper helper) throws IOException {

        String key = helper.getRequestParameterValue(KEY);
        if (key == null) {
            throw new RuntimeException("Expecting passed in key");
        }

        String btn = helper.getRequestParameterValue(SUBMIT_BUTTON);

        //DetailSelection bean = (DetailSelection) helper.getRequestAttributeValue(DetailSelection.NAME);
        DetailSelection bean = null;
        if (StringUtils.isNullOrEmpty(btn)) {
            bean = loadBeanFromProperties(key);
        } else {
            bean = new DetailSelection();
        }
        bean.setKey(key);
        bean.setSubmitBtn(btn);
        bean.setInitialValue(helper.getRequestParameterValue(INITIAL_VALUE));
        bean.setRownum(helper.getRequestParameterValue(ROWNUM));
        bean.setParameter(helper.getRequestParameterValue(PARAMETER));
        bean.setSrcFieldName(helper.getRequestParameterValue(SRC_FIELD));
        bean.setSourcePage(helper.getRequestParameterValue(SOURCE_PAGE));
        bean.setSourceRowSelections(helper.getRequestParameterValue(SOURCE_ROW_SELECTIONS));

        helper.setRequestAttributeValue(DetailSelection.NAME, bean);

        return bean;
    }

    private DetailSelection loadBeanFromProperties(
            String id)
            throws IOException {
        DetailSelection bean = new DetailSelection();
        Properties props = PropertyTool.loadProperties(this, PROP_FILENAME, false);

        String strTitle = PropertyTool.getProperty(props, id + DOT_TITLE, false);
        String strListTitle = PropertyTool.getProperty(props, id + DOT_LIST_TITLE, false);
        String strNoSelectText = PropertyTool.getProperty(props, id + DOT_NO_SELECT_TEXT, false);
        String strEntity = PropertyTool.getProperty(props, id + DOT_ENTITY_NAME, false);

        if (!StringUtils.isNullOrEmpty(strEntity)) {
            bean.setEntityName(strEntity);
        }
        if (!StringUtils.isNullOrEmpty(strTitle)) {
            bean.setTitle(strTitle);
        }
        if (!StringUtils.isNullOrEmpty(strListTitle)) {
            bean.setListTitle(strListTitle);
        }
        if (!StringUtils.isNullOrEmpty(strNoSelectText)) {
            bean.setNoSelectText(strNoSelectText);
        }

        return bean;
    }

    public DetailSelectionClient getDetailSelectionClient(String key) throws Exception {
        Properties props = PropertyTool.loadProperties(this, PROP_FILENAME, false);

        String className = PropertyTool.getProperty(props, key + DOT_CLIENT_CLASS, true);

        Class cls = null;
        Object inst = null;
        try {
            cls = Class.forName(className);
            inst = cls.newInstance();
        } catch (ClassNotFoundException e) {
            _log.error(e.getMessage(), e);
            throw new Exception("Invalid id: " + key);
        } catch (IllegalAccessException e) {
            _log.error(e.getMessage(), e);
            throw new Exception("Invalid id: " + key);
        } catch (InstantiationException e) {
            _log.error(e.getMessage(), e);
            throw new Exception("Invalid id: " + key);
        }

        if (!(inst instanceof DetailSelectionClient)) {
            _log.error("id " + key + " retrieved class named " + className + "; which is not an instance of DetailSelectionClient!");
            throw new Exception("Invalid id: " + key);
        }

        return (DetailSelectionClient) inst;
    }

    public void insertCountryPreferenceValues(
            UCCHelper helper,
            HtmlSelect select) {
        PreferenceBean userPrefs = PreferenceBean.getFromSession(helper);
        PreferenceCountryCollection collection = new PreferenceCountryCollection(userPrefs);
        PreferenceCountry[] countries = collection.getPreferenceCountries();

        for (int i = 0; i < countries.length; i++) {
            PreferenceCountry country = countries[i];
            select.add(i, new HtmlOption(country.getAbbreviation(), country.getDescription()));
        }

        if (countries.length > 0) {
            select.add(countries.length, new HtmlOption("---"));
        }
    }

}
