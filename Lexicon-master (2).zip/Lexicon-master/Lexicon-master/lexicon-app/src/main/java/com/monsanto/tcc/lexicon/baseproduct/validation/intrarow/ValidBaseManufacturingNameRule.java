/*
 ValidBaseManufacturingNameRule was created on Oct 8, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.validation.intrarow;

import com.monsanto.tcc.lexicon.baseproduct.validation.BaseProductTemplateError;
import com.monsanto.tcc.lexicon.baseproduct.validation.BaseProductTemplateRule;
import com.monsanto.tcc.lexiconcommon.db.StdWildcardableCriteria;
import com.monsanto.Util.StringUtils;

/**
 * nbwald Oct 8, 2007 2:11:35 PM
 */
public class ValidBaseManufacturingNameRule
   implements BaseProductTemplateRule
{
   private final String baseManufacturingName;

   public ValidBaseManufacturingNameRule(String baseManufacturingName) {
      this.baseManufacturingName = baseManufacturingName;
   }

   public boolean violated() {
      return noValue() || hasWildcard();
   }

   private boolean noValue() {
      return StringUtils.isNullOrEmpty(baseManufacturingName);
   }

   private boolean hasWildcard() {
      return new StdWildcardableCriteria(baseManufacturingName).hasWildcard();
   }

   public BaseProductTemplateError getViolation() {
      return BaseProductTemplateError.INVALID_BASE_MANF_NAME;
   }
}