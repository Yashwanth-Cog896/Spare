package com.monsanto.tcc.lexicon.competitiveproduct;

import com.monsanto.tcc.lexiconcommon.db.StdWildcardableCriteria;
import com.monsanto.tcc.lexicon.businessdata.CompProdColumnAlias;
import com.monsanto.tcc.lexicon.businessdata.CompProdDAO;
import com.monsanto.tcc.lexicon.businessdata.CompProdDTO;
import com.monsanto.tcc.lexicon.businessdata.CompProdSQL;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.CompProdDTORowElementImpl;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.CompProdXmlUtils;
import com.monsanto.tcc.lexicon.utils.LogWriter;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.dataservices.EmptyResultSetException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSet;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.dataservices.PersistentStoreResultSetSingleResult;
import com.monsanto.dbdataservices.SQLUtil;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;


/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Oct 12, 2004
 * Time: 12:54:35 PM
 * To change this template use File | Settings | File Templates.
 */
public class QueryBuilder {
    public static final String RESULT_QUERY = "CompetitiveProduct.QueryBuilder.ResultsQuery";
    public static final String COUNT_SELECT_CLAUSE = "CompetitiveProduct.QueryBuilder.CountSelectClause";
    public static final String BASE_SELECT_CLAUSE = "CompetitiveProduct.QueryBuilder.SelectClause";
    public static final String BASE_FROM_CLAUSE = "CompetitiveProduct.QueryBuilder.FromClause";
    public static final String BASE_WHERE_CLAUSE = "CompetitiveProduct.QueryBuilder.WhereClause";
    public static final String PROD_NAME_PUBKEY_CRIT = "CompetitiveProduct.QueryBuilder.ProductNamePubKey.Criteria";
    public static final String SINGLE_PROD_NAME_CRT = "CompetitiveProduct.QueryBuilder.ProductName.Criteria";
    public static final String MULTIPLE_PROD_NAME_CRT = "CompetitiveProduct.QueryBuilder.ProductNames.Criteria";

    public static final String BAYER_TABLES = "CompetitiveProduct.QueryBuilder.BayerCode.Tables";
    public static final String BAYER_JOINS = "CompetitiveProduct.QueryBuilder.BayerCode.Joins";
    public static final String BAYER_CRIT = "CompetitiveProduct.QueryBuilder.BayerCode.Criteria";
    public static final String BRAND_TABLES = "CompetitiveProduct.QueryBuilder.Brand.Tables";
    public static final String BRAND_JOINS = "CompetitiveProduct.QueryBuilder.Brand.Joins";
    public static final String BRAND_CRIT = "CompetitiveProduct.QueryBuilder.Brand.Criteria";
    public static final String COUNTRY_TABLES = "CompetitiveProduct.QueryBuilder.Country.Tables";
    public static final String COUNTRY_JOINS = "CompetitiveProduct.QueryBuilder.Country.Joins";
    public static final String COUNTRY_CRIT = "CompetitiveProduct.QueryBuilder.Country.Criteria";
    public static final String TRAIT_TABLES = "CompetitiveProduct.QueryBuilder.Trait.Tables";
    public static final String TRAIT_JOINS = "CompetitiveProduct.QueryBuilder.Traits.Joins";
    public static final String OR_TRAIT_CRIT = "CompetitiveProduct.QueryBuilder.Traits.OrCriteria";
    public static final String AND_TRAIT_TABLES = "CompetitiveProduct.QueryBuilder.Traits.AndTables";
    public static final String AND_TRAIT_JOINS = "CompetitiveProduct.QueryBuilder.Traits.AndJoins";
    public static final String AND_TRAIT_CRIT = "CompetitiveProduct.QueryBuilder.Traits.AndCriteria";
    public static final String STACKS_WITH_TRAIT_NAME = "CompetitiveProduct.QueryBuilder.Traits.StacksAndTraitAssoc";

    private Map paramMap = new HashMap();

    private static String countSelectClause;
    private static String baseSelectClause;
    private static String baseFromClause;
    private static String baseWhereClause;

    private StringBuffer criteriaFromClause;
    private StringBuffer criteriaWhereClause;

    private List idList = null;
    private List dtoList = null;
    private int actualCount = -1;
    private int rowLimit = -1;


    public void addParam(
            QueryBuilderParameter param,
            String strValue) {
        if (strValue == null) {
            paramMap.remove(param);
        } else {
            if (param.equals(QueryBuilderParameter.AND_TRAITS)) {
                paramMap.remove(QueryBuilderParameter.OR_TRAITS);
            } else if (param.equals(QueryBuilderParameter.OR_TRAITS)) {
                paramMap.remove(QueryBuilderParameter.AND_TRAITS);
            }
            paramMap.put(param, strValue);
        }
        clearState();
    }

    public void clearParams() {
        paramMap.clear();
        clearState();
    }

    protected String getParam(QueryBuilderParameter param) {
        return (String) paramMap.get(param);
    }

    public void setRowLimit(int nRowLimit) {
        rowLimit = nRowLimit;
        clearState();
    }

    protected void clearState() {
        idList = null;
        dtoList = null;
        actualCount = -1;
        criteriaFromClause = null;
        criteriaWhereClause = null;
    }

    public int getCount(
            PersistentStoreConnection connection)
            throws WrappingException {
        List idList = retrieveCPNameIdList(connection);
        return idList.size();
    }

    public int getActualCount(
            PersistentStoreConnection connection)
            throws WrappingException {
        return retrieveAcutalCount(connection);
    }

    public Document getDocument(
            PersistentStoreConnection connection)
            throws WrappingException {
        CompProdXmlUtils cpXmlUtils = new CompProdXmlUtils();

        Document doc = DOMUtil.newDocument();
        Element elemRow = cpXmlUtils.createRootElement(doc, "LexiconInternal");
        cpXmlUtils.createStatsNode(elemRow);

        retrieveDTOs(connection);
        if (dtoList.size() > 0) {
            CompProdDTO dto;
            for (int i = 0; i < dtoList.size(); i++) {
                dto = (CompProdDTO) dtoList.get(i);
                CompProdDTORowElementImpl.constructRowFromDTO(doc, dto, i);
            }
        }
        cpXmlUtils.updateStatsNode(doc);
        return doc;
    }

    protected List retrieveCPNameIdList(
            PersistentStoreConnection connection)
            throws WrappingException {
        if (null == idList) {
            String strSql = generateSearchQuery();
            LogWriter.getCategory(this).debug("sql: " + strSql);

            PersistentStoreResultSet rs = connection.executeQuery(strSql);
            try {
                String id;
                idList = new ArrayList();
                PersistentStoreResultSetFwdIterator iter = rs.getForwardIterator();

                int limit = rowLimit;
                if (limit <= 0) {
                    limit = Integer.MAX_VALUE;
                }

                for (int i = 0; i < limit && iter.next(); i++) {
                    id = iter.getString(CompProdColumnAlias.NAME_ID_ALIAS);
                    idList.add(id);
                }
            }
            finally {
                rs.close();
            }
        }
        return idList;
    }

    protected int retrieveAcutalCount(
            PersistentStoreConnection conn)
            throws WrappingException {
        if (actualCount < 0) {
            String strSql = generateCountQuery();
            LogWriter.getCategory(this).debug("sql: " + strSql);

            PersistentStoreResultSet rs = conn.executeQuery(strSql);
            try {
                PersistentStoreResultSetSingleResult result = rs.getSingleResult();
                actualCount = result.getInt(1);
            }
            catch (EmptyResultSetException e) {
                throw new WrappingException(e);
            }
            finally {
                rs.close();
            }
        }
        return actualCount;
    }

    protected List retrieveDTOs(
            PersistentStoreConnection conn)
            throws WrappingException {
        if (dtoList == null) {
            dtoList = new ArrayList();

            retrieveCPNameIdList(conn);
            if (idList.size() > 0) {
                String strSql = generateResultsQuery();
                LogWriter.getCategory(this).debug("sql: " + strSql);

                CompProdDAO daoImpl = CompProdDAO.newInstance();
                PersistentStoreResultSet rs = conn.executeQuery(strSql);
                try {
                    CompProdDTO dto;
                    PersistentStoreResultSetFwdIterator iter = rs.getForwardIterator();

                    while (iter.next()) {
                        dto = daoImpl.createDTO(iter);
                        dtoList.add(dto);
                    }
                }
                finally {
                    rs.close();
                }
            }
        }
        return dtoList;
    }

    protected String generateSearchQuery()
            throws WrappingException {
        return getBaseSelectClause() +
                getBaseFromClause() + getCriteriaFromClause() +
                getBaseWhereClause() + getCriteriaWhereClause();
    }

    protected String generateCountQuery()
            throws WrappingException {
        return getCountSelectClause() +
                getBaseFromClause() + getCriteriaFromClause() +
                getBaseWhereClause() + getCriteriaWhereClause();
    }

    protected String generateResultsQuery()
            throws WrappingException {
        String strTokens = repackageTokens(idList);
        String strSql = getSQL(RESULT_QUERY);
        strSql = strSql.replaceAll("\\$\\{IdList\\}", strTokens);
        return strSql;
    }

    private static String getCountSelectClause()
            throws WrappingException {
        if (countSelectClause == null) {
            countSelectClause = getSQL(COUNT_SELECT_CLAUSE);
        }
        return countSelectClause;
    }

    private static String getBaseSelectClause()
            throws WrappingException {
        if (baseSelectClause == null) {
            baseSelectClause = getSQL(BASE_SELECT_CLAUSE);
        }
        return baseSelectClause;
    }

    private static String getBaseFromClause()
            throws WrappingException {
        if (baseFromClause == null) {
            baseFromClause = " " + getSQL(BASE_FROM_CLAUSE);
        }
        return baseFromClause;
    }

    private static String getBaseWhereClause()
            throws WrappingException {
        if (baseWhereClause == null) {
            baseWhereClause = " " + getSQL(BASE_WHERE_CLAUSE);
        }
        return baseWhereClause;
    }

    private String getCriteriaFromClause()
            throws WrappingException {
        if (criteriaFromClause == null) {
            generateCriteriaClauses();
        }
        return criteriaFromClause.toString();
    }

    private String getCriteriaWhereClause()
            throws WrappingException {
        if (criteriaWhereClause == null) {
            generateCriteriaClauses();
        }
        return criteriaWhereClause.toString();
    }


    private void generateCriteriaClauses()
            throws WrappingException {
        QueryBuilderParameter param;
        criteriaFromClause = new StringBuffer();
        criteriaWhereClause = new StringBuffer();

        Iterator iter = paramMap.keySet().iterator();
        while (iter.hasNext()) {
            param = (QueryBuilderParameter) iter.next();

            switch (param.getParamNum()) {
                case QueryBuilderParameter.PROD_NAME_PUBLIC_KEY_NUM:
                    addProductNamePublicKeyCriteria((String) paramMap.get(param));
                    break;
                case QueryBuilderParameter.PROD_NAME_NUM:
                    addProductNameCriteria((String) paramMap.get(param));
                    break;
                case QueryBuilderParameter.BAYER_CODE_NUM:
                    addBayerCodeCriteria((String) paramMap.get(param));
                    break;
                case QueryBuilderParameter.BRAND_NAME_NUM:
                    addBrandNameCriteria((String) paramMap.get(param));
                    break;
                case QueryBuilderParameter.CNTRY_ABBR_NUM:
                    addCountryAbbrCriteria((String) paramMap.get(param));
                    break;
                case QueryBuilderParameter.OR_TRIATS_NUM:
                    addOrTraitsCriteria((String) paramMap.get(param));
                    break;
                case QueryBuilderParameter.AND_TRAITS_NUM:
                    addAndTraitsCriteria((String) paramMap.get(param));
                    break;
                default:
                    throw new RuntimeException("ASSERT: Unimplemented Query Parameter");
            }
        }
    }

    private void addToFromClause(String strTable) {
        criteriaFromClause.append(", ");
        criteriaFromClause.append(strTable);
    }

    private void addToWhereClause(String strCondiditon) {
//      criteriaWhereClause.append((0 == criteriaWhereClause.length()) ? " WHERE " : " AND ");
        criteriaWhereClause.append(" AND ");
        criteriaWhereClause.append(strCondiditon);
    }

    private void addProductNamePublicKeyCriteria(String strCriteria)
            throws WrappingException {
        if (!StringUtils.isNullOrEmpty(strCriteria)) {
            String strSql = getSQL(PROD_NAME_PUBKEY_CRIT);
            strSql = strSql.replaceAll("\\$\\{Criteria\\}", strCriteria.trim());
            addToWhereClause(strSql);
        }
    }

    private void addProductNameCriteria(String strCriteria)
            throws WrappingException {
        if (!StringUtils.isNullOrEmpty(strCriteria)) {
            String strSql;
            if (strCriteria.contains(",")) {
                String strTokenized = repackageTokens(tokenizeCriteria(strCriteria));
                strSql = getSQL(MULTIPLE_PROD_NAME_CRT);
                strSql = strSql.replaceAll("\\$\\{Criteria\\}", strTokenized.toUpperCase());
            } else {
                strCriteria = handleSearchString(strCriteria);
                strSql = getSQL(SINGLE_PROD_NAME_CRT);
                strSql = strSql.replaceAll("\\$\\{Criteria\\}", strCriteria);
            }
            addToWhereClause(strSql);
        }
    }

    private String handleSearchString(String strCriteria) {
        StringBuffer stringBuffer = new StringBuffer();
        strCriteria = strCriteria.trim().toUpperCase();
        if (!strCriteria.contains(StdWildcardableCriteria.USER_WILDCARD)) {
            stringBuffer.append(StdWildcardableCriteria.USER_WILDCARD);
            stringBuffer.append(strCriteria);
            stringBuffer.append(StdWildcardableCriteria.USER_WILDCARD);
            strCriteria = stringBuffer.toString();
        }
        StdWildcardableCriteria stdWildcardableCriteria = new StdWildcardableCriteria(strCriteria);
        return stdWildcardableCriteria.oracleVersion();
    }

    private void addBayerCodeCriteria(String strCriteria)
            throws WrappingException {
        String strTokenized = repackageTokens(tokenizeCriteria(strCriteria));
        if (!StringUtils.isNullOrEmpty(strTokenized)) {
            addToFromClause(getSQL(BAYER_TABLES));
            addToWhereClause(getSQL(BAYER_JOINS));

            String strSql = getSQL(BAYER_CRIT);
            strSql = strSql.replaceAll("\\$\\{Criteria\\}", strTokenized);
            addToWhereClause(strSql);
        }
    }

    private void addBrandNameCriteria(String strCriteria)
            throws WrappingException {
        String strTokenized = repackageTokens(tokenizeCriteria(strCriteria));
        if (!StringUtils.isNullOrEmpty(strTokenized)) {
            addToFromClause(getSQL(BRAND_TABLES));
            addToWhereClause(getSQL(BRAND_JOINS));

            String strSql = getSQL(BRAND_CRIT);
            strSql = strSql.replaceAll("\\$\\{Criteria\\}", strTokenized);
            addToWhereClause(strSql);
        }
    }

    private void addCountryAbbrCriteria(String strCriteria)
            throws WrappingException {
        String strTokenized = repackageTokens(tokenizeCriteria(strCriteria));
        if (!StringUtils.isNullOrEmpty(strTokenized)) {
            addToFromClause(getSQL(COUNTRY_TABLES));
            addToWhereClause(getSQL(COUNTRY_JOINS));

            String strSql = getSQL(COUNTRY_CRIT);
            strSql = strSql.replaceAll("\\$\\{Criteria\\}", strTokenized);
            addToWhereClause(strSql);
        }
    }

    private void addOrTraitsCriteria(String strCriteria)
            throws WrappingException {
        String strTokenized = repackageTokens(tokenizeCriteria(strCriteria));
        if (!StringUtils.isNullOrEmpty(strTokenized)) {
            addToFromClause(getSQL(TRAIT_TABLES));
            addToWhereClause(getSQL(TRAIT_JOINS));

            String strSql = getSQL(OR_TRAIT_CRIT);
            strSql = strSql.replaceAll("\\$\\{Criteria\\}", strTokenized);
            addToWhereClause(strSql);
        }
    }

    private void addAndTraitsCriteria(String strCriteria)
            throws WrappingException {
        List tokens = tokenizeCriteria(strCriteria);
        if (0 != tokens.size()) {
            String stacksWithTraitNameSelect = createStacksWithTraitNameSelectSQL(tokens);
            String strSql = getSQL(AND_TRAIT_CRIT);
            addToWhereClause(strSql.replaceAll("\\$\\{Criteria\\}", stacksWithTraitNameSelect));
        }
    }

    public String createStacksWithTraitNameSelectSQL(List tokens)
            throws WrappingException {
        String stacksWithTraitNameSql = getSQL(STACKS_WITH_TRAIT_NAME);
        StringBuffer stacksWithTraitNameSelect = new StringBuffer();
        for (int i = 0; i < tokens.size(); i++) {
            String currentSelect =
                    stacksWithTraitNameSql.replaceAll("\\$\\{Criteria\\}", wrapWithSingleQuotes((String) tokens.get(i)));
            stacksWithTraitNameSelect.append(currentSelect);
            if (i < tokens.size() - 1) {
                stacksWithTraitNameSelect.append(" INTERSECT ");
            }
        }

        return stacksWithTraitNameSelect.toString();
    }

    private String wrapWithSingleQuotes(String token) {
        return "'" + token + "'";
    }

    private String repackageTokens(List tokens) {
        StringBuffer buffer = new StringBuffer();
        for (int i = 0; i < tokens.size(); i++) {
            if (0 != i) {
                buffer.append(",");
            }
            if (tokens.get(i) instanceof Integer) {
                buffer.append(tokens.get(i).toString());
            } else {
                buffer.append("'");
                buffer.append(tokens.get(i).toString());
                buffer.append("'");
            }
        }
        return buffer.toString();
    }

    private List tokenizeCriteria(String strCriteria) {
        List lTokens = new ArrayList();
        String[] aTokens = StringUtils.splitCsv(strCriteria, true);
        for (int i = 0; i < aTokens.length; i++) {
            aTokens[i] = SQLUtil.escapeString(aTokens[i].trim());
            if (!StringUtils.isNullOrEmpty(aTokens[i])) {
                lTokens.add(aTokens[i]);
            }
        }
        return lTokens;
    }


    private static String getSQL(String propName)
            throws WrappingException {
        return new SQLPropFile(CompProdSQL.class).getSQL(propName);
    }

/*
   private void addRowLimitClause()
   {
      if (rowLimit > 0) {
         addToWhereClause("ROWNUM <= " + rowLimit);
      }
   }
*/
}


