package com.monsanto.tcc.lexicon.comments.ucc;

import com.monsanto.ServletFramework.UCCHelper;
import org.apache.commons.beanutils.BeanUtilsBean;
import org.apache.commons.beanutils.ConvertUtilsBean;
import org.apache.commons.lang.StringUtils;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Oct 14, 2011
 * Time: 2:21:14 PM
 * To change this template use File | Settings | File Templates.
 */
public class FormScraper {
   private static final BeanUtilsBean beanUtilsBean = buildBeanUtilsBean();

   public  void scrapeForm(UCCHelper helper, Object bean) throws IOException, InvocationTargetException, IllegalAccessException {
       beanUtilsBean.populate(bean,buildParametersMap(helper));
   }
   private static  BeanUtilsBean buildBeanUtilsBean() {
        BeanUtilsBean beanUtilsBean = new BeanUtilsBean(new ConvertUtilsBean(){
            @Override
            public Object convert(String value, Class clazz) {

                  if (clazz.isEnum()){
                      if(StringUtils.isBlank(value)){
                         return null;
                      }
                      else {
                         return Enum.valueOf(clazz, value);
                      }
                  }else{
                       return super.convert(value, clazz);
                  }
           }
        });
        return beanUtilsBean;
    }

    private  Map<String, Object> buildParametersMap(UCCHelper helper) throws IOException {
        Map<String,Object> parameters = new HashMap<String, Object>();
        Enumeration<String> paramNameEnum = helper.getParameterNames();
        while(paramNameEnum.hasMoreElements()){
            String paramName = paramNameEnum.nextElement();
            parameters.put(paramName,helper.getRequestParameterValue(paramName));
        }
        return parameters;
    }
}
