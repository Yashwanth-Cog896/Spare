package com.monsanto.tcc.lexicon.controllers;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Feb 1, 2005
 * Time: 2:37:35 PM
 * To change this template use File | Settings | File Templates.
 */
public class UserInfoException extends Exception {
   
   public UserInfoException(String message, Throwable cause) {
      super(message, cause);
   }

   public UserInfoException(String description) {
      super(description);
   }
}
