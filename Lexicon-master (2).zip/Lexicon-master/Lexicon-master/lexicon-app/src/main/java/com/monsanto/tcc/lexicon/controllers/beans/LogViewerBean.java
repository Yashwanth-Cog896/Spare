package com.monsanto.tcc.lexicon.controllers.beans;

/**
 * Created by IntelliJ IDEA.
 * User: adcox
 * Date: Jul 23, 2004
 * Time: 4:41:02 PM
 * To change this template use File | Settings | File Templates.
 */
public class LogViewerBean
{
   public static final String NAME = "LogViewer";

   private String status;
   private String content;

   private String fileName;
   private String startLine;
   private String lineCount;
   private String submit;
   // values: View Log,Next, Previous

   private String regexp;
   private String reverse;
   private String wrap;
   private String searchOnly;
   private String absolutePath;

   public String getAbsolutePath() {
      return absolutePath;
   }
   public void setAbsolutePath(String absolutePath) {
      this.absolutePath = absolutePath;
   }

   public String getStatus() {
      return status;
   }
   public void setStatus(String status) {
      this.status = status;
   }

   public String getContent() {
      return content;
   }
   public void setContent(String content) {
      this.content = content;
   }

   public String getFileName() {
      return fileName;
   }
   public void setFileName(String fileName) {
      this.fileName = fileName;
   }

   public String getStartLine() {
      return startLine;
   }
   public void setStartLine(String startLine) {
      this.startLine = startLine;
   }

   public String getWrap() {
      return wrap;
   }
   public void setWrap(String wrap) {
      this.wrap = wrap;
   }

   public String getLineCount() {
      return lineCount;
   }
   public void setLineCount(String lineCount) {
      this.lineCount = lineCount;
   }

   public String getSubmit() {
      return submit;
   }
   public void setSubmit(String submit) {
      this.submit = submit;
   }

   public String getReverse() {
      return reverse;
   }
   public void setReverse(String reverse) {
      this.reverse = reverse;
   }

   public String getRegexp() {
      return regexp;
   }
   public void setRegexp(String regexp) {
      this.regexp = regexp;
   }

   public String getSearchOnly() {
      return searchOnly;
   }
   public void setSearchOnly(String searchOnly) {
      this.searchOnly = searchOnly;
   }
}
