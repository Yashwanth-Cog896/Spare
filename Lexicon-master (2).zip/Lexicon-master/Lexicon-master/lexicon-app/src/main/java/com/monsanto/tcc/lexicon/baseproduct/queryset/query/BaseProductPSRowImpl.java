/*
 BaseProductPSRowImpl was created on Oct 24, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.queryset.query;

import com.monsanto.tcc.lexicon.baseproduct.queryset.model.BaseProduct;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.dbdataservices.SQLUtil;

/**
 * nbwald Oct 24, 2007 5:51:05 PM
 */
public class BaseProductPSRowImpl
   implements BaseProduct
{
   private final String baseManufacturingName;
   private final String cropName;
   private final boolean parentProduct;

   BaseProductPSRowImpl(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      this.baseManufacturingName = row.getString(getAlias(BaseProductByBaseNameQuerySQL.BASE_MANF_NAME_ALIAS));
      this.cropName = row.getString(getAlias(BaseProductByBaseNameQuerySQL.CROP_NAME_ALIAS));
      this.parentProduct = SQLUtil.stringToBoolean(row.getString(getAlias(BaseProductByBaseNameQuerySQL.PARENT_PRODUCT_ALIAS)));
   }

   private String getAlias(String aliasName)
      throws WrappingException
   {
      return new SQLPropFile(BaseProductByBaseNameQuerySQL.class).getAlias(aliasName);
   }

   public String getBaseManufacturingName() {
      return baseManufacturingName;
   }

   public String getCropName() {
      return cropName;
   }

   public boolean isParentProduct() {
      return parentProduct;
   }
}