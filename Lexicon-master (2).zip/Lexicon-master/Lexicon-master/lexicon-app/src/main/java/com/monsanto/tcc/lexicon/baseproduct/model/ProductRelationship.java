/*
 Copyright:  Copyright � 2009 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.lexicon.baseproduct.model;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RLCASW
 * @version $Revision$
 */
public class ProductRelationship {
  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getManufacturingName() {
    return manufacturingName;
  }

  public void setManufacturingName(String manufacturingName) {
    this.manufacturingName = manufacturingName;
  }

  public String getPubkey() {
    return pubkey;
  }

  public void setPubkey(String pubkey) {
    this.pubkey = pubkey;
  }

  public String getBaseProductId() {
    return baseProductId;
  }

  public void setBaseProductId(String baseProductId) {
    this.baseProductId = baseProductId;
  }

  public boolean isLogicalDelete() {
    return logicalDelete;
  }

  public void setLogicalDelete(boolean logicalDelete) {
    this.logicalDelete = logicalDelete;
  }

  public String getVarietyName() {
    return varietyName;
  }

  public void setVarietyName(String varietyName) {
    this.varietyName = varietyName;
  }

  private String id;
  private String manufacturingName;
  private String pubkey;
  private String baseProductId;
  private boolean logicalDelete;
  private String varietyName;
}