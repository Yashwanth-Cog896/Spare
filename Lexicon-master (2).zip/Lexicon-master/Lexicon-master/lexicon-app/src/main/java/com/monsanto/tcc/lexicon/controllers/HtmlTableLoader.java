package com.monsanto.tcc.lexicon.controllers;

import com.monsanto.tcc.lexicon.utils.gui.HtmlTable;
import com.monsanto.ServletFramework.UCCHelper;

/**
 * Created by IntelliJ IDEA.
 * User: adcox
 * Date: Oct 8, 2004
 * Time: 11:13:09 AM
 * To change this template use File | Settings | File Templates.
 */
public interface HtmlTableLoader {
   public String getId();

   public HtmlTable getTable(UCCHelper helper) throws Exception;
}
