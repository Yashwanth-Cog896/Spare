package com.monsanto.tcc.lexicon.controllers.beans;

/**
 * Created by IntelliJ IDEA.
 * User: adcox
 * Date: Oct 13, 2004
 * Time: 2:10:44 PM
 * To change this template use File | Settings | File Templates.
 */
public class DetailSelection {
   public static final String NAME = "DetailSelection";

   private String entityName;
   private String title;
   private String errorMessage;
   private String selectHtml;
   private String listTitle;
   private String submitBtn;
   private String key;
   private String initialValue;
   private String rownum;
   private String parameter;
   private String noSelectText;
   private String srcFieldName;
   private boolean noSelections;
	private String sourcePage;
	private String sourceRowSelections;


   public String getEntityName() {
      return entityName;
   }

   public void setEntityName(String entityName) {
      this.entityName = entityName;
      this.title = "Select " + entityName;
      this.listTitle = "Available " + entityName + ":";
      this.noSelectText = "No " + entityName + " Available";
   }

	public String getSourceRowSelections() {
		return sourceRowSelections;
	}

	public void setSourceRowSelections(String sourceRowSelections) {
		this.sourceRowSelections = sourceRowSelections;
	}

	public String getSourcePage() {
		return sourcePage;
	}

	public void setSourcePage(String sourcePage) {
		this.sourcePage = sourcePage;
	}

   public String getTitle() {
      return title;
   }

   public void setTitle(String title) {
      this.title = title;
   }

   public String getErrorMessage() {
      return errorMessage;
   }

   public void setErrorMessage(String errorMessage) {
      this.errorMessage = errorMessage;
   }

   public String getSelectHtml() {
      return selectHtml;
   }

   public void setSelectHtml(String selectHtml) {
      this.selectHtml = selectHtml;
   }

   public String getListTitle() {
      return listTitle;
   }

   public void setListTitle(String listTitle) {
      this.listTitle = listTitle;
   }

   public String getSubmitBtn() {
      return submitBtn;
   }

   public void setSubmitBtn(String submitBtn) {
      this.submitBtn = submitBtn;
   }

   public String getKey() {
      return key;
   }

   public void setKey(String key) {
      this.key = key;
   }

   public String getInitialValue() {
      return initialValue;
   }

   public void setInitialValue(String initialValue) {
      this.initialValue = initialValue;
   }

   public String getRownum() {
      return rownum;
   }

   public void setRownum(String rownum) {
      this.rownum = rownum;
   }

   public String getParameter() {
      return parameter;
   }

   public void setParameter(String parameter) {
      this.parameter = parameter;
   }

   public String getNoSelectText() {
      return noSelectText;
   }

   public void setNoSelectText(String noSelectText) {
      this.noSelectText = noSelectText;
   }

   public boolean isNoSelections() {
      return noSelections;
   }

   public void setNoSelections(boolean noSelections) {
      this.noSelections = noSelections;
   }

   public String getSrcFieldName() {
      return srcFieldName;
   }

   public void setSrcFieldName(String srcFieldName) {
      this.srcFieldName = srcFieldName;
   }
}
