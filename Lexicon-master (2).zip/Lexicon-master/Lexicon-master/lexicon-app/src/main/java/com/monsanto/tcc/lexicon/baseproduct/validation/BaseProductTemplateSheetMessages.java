/*
 BaseProductTemplateSheetMessages was created on Oct 9, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.validation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * nbwald Oct 9, 2007 12:52:38 PM
 */
public class BaseProductTemplateSheetMessages
{
   private Map<BaseProductTemplateError, String> rowsByError = new HashMap<BaseProductTemplateError, String>();

   public void addErrors(int row, BaseProductTemplateError[] errors) {
      addErrors(errors, String.valueOf(row));
   }

   public void addErrors(int i, int j, BaseProductTemplateError[] errors) {
      addErrors(errors, "[" + i + ", " + j + "]");
   }

   private void addErrors(BaseProductTemplateError[] errors, String rowValue) {
      for (BaseProductTemplateError error : errors) {
         addError(error, rowValue);
      }
   }

   private void addError(BaseProductTemplateError error, String rowValue) {
      rowsByError.put(error, createCSV(rowsByError.get(error), rowValue));
   }

   private String createCSV(String currentRows, String rowValue) {
      return currentRows == null ? rowValue : currentRows + ", " + rowValue;
   }

   public String[] getMessageTexts() {
      List<String> messageTexts = new ArrayList<String>();
      for (BaseProductTemplateError error : rowsByError.keySet()) {
         messageTexts.add(getRowText(rowsByError.get(error), error));
      }
      return messageTexts.toArray(new String[messageTexts.size()]);
   }

   private String getRowText(String rowCSV, BaseProductTemplateError error) {
      return "Row " + rowCSV + ": " + error.toString();
   }

   public boolean hasMessages() {
      return !rowsByError.isEmpty();
   }
}