package com.monsanto.tcc.lexicon.eventregulation.service;

import com.monsanto.tcc.lexicon.spring.ThreadLocalApplicationContext;
import com.monsanto.tps.lexicon.event.EventAgencyAlignmentRequest;
import com.monsanto.tps.lexicon.event.EventAgencyAlignmentResponse;
import com.monsanto.tps.lexicon.event.EventAgencyAlignmentService;
import com.monsanto.tps.lexicon.event.EventAgencyAlignmentUpdateRequest;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import javax.annotation.Resource;

/**
 * nbwald - Feb 9, 2009 9:58:14 PM
 */
public class EventAgencyAlignmentServiceImpl
   implements EventAgencyAlignmentService
{
   @Resource
   private EventAgencyAlignmentService eventAgencyAlignmentService;

   @Override
   public EventAgencyAlignmentResponse[] save(EventAgencyAlignmentRequest request) {
      return eventAgencyAlignmentService.save(request);
   }

   @Override
   public EventAgencyAlignmentResponse[] update(EventAgencyAlignmentUpdateRequest updateRequest) {
      return eventAgencyAlignmentService.update(updateRequest);
   }
}
