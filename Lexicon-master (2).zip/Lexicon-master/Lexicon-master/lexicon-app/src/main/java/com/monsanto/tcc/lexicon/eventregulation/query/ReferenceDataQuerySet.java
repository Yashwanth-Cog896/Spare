package com.monsanto.tcc.lexicon.eventregulation.query;

import com.monsanto.tcc.lexicon.typedata.country.CountryDTO;

/**
 * nbwald - Feb 6, 2009 1:40:33 PM
 */
public interface ReferenceDataQuerySet
{
   CountryDTO findCountryByIsoCode(String isoCode);

   String findAgencyPubkeyByAgencyAbbr(String agencyAbbr);
}
