package com.monsanto.tcc.lexicon.competitiveproduct.repository;

import com.monsanto.tcc.lexicon.utils.db.dao.DAOUtil;
import com.monsanto.Util.Exceptions.WrappingException;
import org.apache.log4j.Category;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Sep 7, 2004
 * Time: 4:18:10 PM
 * To change this template use File | Settings | File Templates.
 */
public class CompProdBatchDAOUtil
   extends DAOUtil
{
   public static final String PROP_FILE = "CompProdDAO.properties";

   public static final String GET_BATCH_COUNT = "CompProdBatch.GetCount";
   public static final String SELECT_ALL = "CompProdBatch.SelectAll";
   public static final String SELECT_ALL_BYUSER = "CompProdBatch.SelectAllByUser";
   public static final String SELECT_BY_PK = "CompProdBatch.SelectById";
   public static final String SELECT_BY_NAME = "CompProdBatch.SelectByName";
   public static final String INSERT_BATCH = "CompProdBatch.Insert";
   public static final String UPDATE_BATCH = "CompProdBatch.Update";
   public static final String DELETE_BATCH = "CompProdBatch.Delete";

   public static final String GET_ROW_COUNT = "CompProdBatchRow.GetCount";
   public static final String SELECT_BATCH_ROWS = "CompProdBatchRow.SelectByBatch";
   public static final String INSERT_BATCH_ROW = "CompProdBatchRow.Insert";
   public static final String DELETE_BATCH_ROWS = "CompProdBatchRow.DeleteAllInBatch";

   public static final String NEXT_ID = "ID";

   private static CompProdBatchDAOUtil s_singleton = new CompProdBatchDAOUtil();

   public static CompProdBatchDAOUtil getInstance() {
      return s_singleton;
   }

   protected String getPropfileName() {
      return PROP_FILE;
   }

   public String getSQL(String strPropName, Category log)
      throws WrappingException
   {
      return super.getSQL(strPropName);
   }
}
