/*
 EditManufacturingLineResponseMerger was created on Jan 22, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.process.manufacturingline.edit;

import com.monsanto.tcc.lexicon.baseproduct.model.EditableProductRelationship;
import com.monsanto.tcc.lexiconcommon.pos.batch.ServiceResponseMerger;
import com.monsanto.tcc.lexiconcommon.service.manufacturingline.edit.EditManufacturingLineResponse;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald Jan 22, 2008 1:56:38 PM
 */
public class EditManufacturingLineResponseMerger
   implements ServiceResponseMerger<EditableProductRelationship, EditManufacturingLineResponse>
{
   public void mergeResponse(EditableProductRelationship inputModel, EditManufacturingLineResponse responseModel)
      throws WrappingException
   {
      inputModel.update(responseModel);
   }
}