package com.monsanto.tcc.lexicon.businessdata;

import com.monsanto.tcc.lexicon.typedata.bayer.BayerDTO;
import com.monsanto.tcc.lexicon.typedata.brand.BrandDTO;
import com.monsanto.tcc.lexicon.typedata.country.CountryDTO;
import com.monsanto.tcc.lexicon.typedata.trait.TraitStackDTO;
import com.monsanto.tcc.lexicon.utils.LogWriter;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.EmptyResultSetException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import org.apache.log4j.Logger;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: adcox
 * Date: Oct 25, 2004
 * Time: 2:21:46 PM
 */
public abstract class CompProdDAO
   implements CompProdColumnAlias, CompProdDAOType
{
   protected Logger _log;

   public CompProdDAO()
   {
      _log = LogWriter.getCategory(this);
   }

   public static CompProdDAO newInstance()
   {
      return new OraCompProdDAO();
   }

   public abstract String newPublicKey(
      PersistentStoreConnection conn)
      throws WrappingException;

   public abstract String newProductPublicKey(
      PersistentStoreConnection conn)
      throws WrappingException;

   public abstract CompProdDTO loadByProdNamePubkey(
      PersistentStoreConnection conn,
      String publicKey)
      throws WrappingException,
             EmptyResultSetException;
   
   public abstract List loadByProductPubkey(
      PersistentStoreConnection conn,
      String publicKey)
      throws WrappingException;

   public abstract CompProdDTO loadByMatchingAK(
      PersistentStoreConnection conn,
      String productName,
      String bayerCode,
      String brandName,
      String countryName)
      throws WrappingException;

   public abstract List loadByProductLevel(
      PersistentStoreConnection conn,
      String productName,
      String bayerCode,
      String brandPubkey)
      throws WrappingException;

   public abstract void save(
      PersistentStoreConnection conn,
      CompProdDTO dto)
      throws WrappingException;

   public abstract CompProdDTO createDTO(
      PersistentStoreResultSetRow rs)
      throws WrappingException;

   public abstract BrandDTO getBrand(
      PersistentStoreConnection conn,
      CompProdDTO compProd)
      throws WrappingException;

   public abstract CountryDTO getCountry(
      PersistentStoreConnection conn,
      CompProdDTO compProd)
      throws WrappingException;

   public abstract BayerDTO getBayer(
      PersistentStoreConnection conn,
      CompProdDTO compProd)
      throws WrappingException;

   public abstract TraitStackDTO getExistingTraitStack(
      PersistentStoreConnection conn,
      CompProdDTO compProd)
      throws WrappingException;

   public abstract TraitStackDTO getTraitStack(
      PersistentStoreConnection conn,
      CompProdDTO compProd)
      throws WrappingException;

   public abstract int nameIdFromPublicKey(
      PersistentStoreConnection conn,
      String key)
      throws WrappingException;

   public abstract int prodIdFromPublicKey(
      PersistentStoreConnection conn,
      String key)
      throws WrappingException;
}
