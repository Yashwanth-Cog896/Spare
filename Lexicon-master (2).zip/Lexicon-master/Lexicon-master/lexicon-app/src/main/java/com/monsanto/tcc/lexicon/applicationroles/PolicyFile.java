package com.monsanto.tcc.lexicon.applicationroles;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.XMLUtil.DOMUtil;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Collection;
import java.util.HashSet;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jun 5, 2007
 * Time: 3:47:02 PM
 */
public class PolicyFile
{
   private final URL policyFileURL;

   private static final String POLICY_ROLE_PATH = "/policy/role";
   private static final String POLICY_GROUP_PATH = "/policy/role/include/group";

   public PolicyFile(final URL policyFileURL) {
      this.policyFileURL = policyFileURL;
   }

   public Collection<String> getRoles()
      throws WrappingException, IOException
   {
      final InputStream policyFileStream = getPolicyFileStream();
      try {
         NodeList nodes = getNodes(policyFileStream, POLICY_ROLE_PATH);
         return getNameAttributes(nodes);
      }
      finally {
         policyFileStream.close();
      }
   }

   public Collection<String> getGroups()
      throws WrappingException, IOException
   {
      final InputStream policyFileStream = getPolicyFileStream();
      try {
         NodeList nodes = getNodes(policyFileStream, POLICY_GROUP_PATH);
         return getNameAttributes(nodes);
      }
      finally {
         policyFileStream.close();
      }
   }

   private InputStream getPolicyFileStream() throws IOException {
      return policyFileURL.openStream();
   }

   private Collection<String> getNameAttributes(final NodeList nodes) {
      final Collection<String> names = new HashSet<String>();
      for (int i = 0; i < nodes.getLength(); i++) {
         Node node = nodes.item(i);
         String value = DOMUtil.getAttribute((Element) node, "name");
         names.add(value);
      }
      return names;
   }

   private NodeList getNodes(final InputStream policyFileStream, String xpath)
      throws WrappingException
   {
      try {
         Document doc = DOMUtil.newDocument(policyFileStream);
         return XPathAPI.selectNodeList(doc, xpath);
      }
      catch (Exception e) {
         throw new WrappingException(e);
      }
   }
}
