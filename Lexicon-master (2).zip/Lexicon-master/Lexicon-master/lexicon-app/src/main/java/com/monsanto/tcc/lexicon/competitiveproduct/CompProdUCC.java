package com.monsanto.tcc.lexicon.competitiveproduct;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.lexicon.LexiconServlet.LexiconUseCaseController;
import com.monsanto.tcc.lexicon.applicationroles.AppRoles;
import com.monsanto.tcc.lexicon.competitiveproduct.beans.CompProdFileChooser;
import com.monsanto.tcc.lexicon.competitiveproduct.beans.FileDisplayItem;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.CompProdExcelReader;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.CompProdXmlUtils;
import com.monsanto.tcc.lexicon.competitiveproduct.repository.CompProdXmlRepositoryHeader;
import com.monsanto.tcc.lexicon.competitiveproduct.tablebuilder.StatusImageTag;
import com.monsanto.tcc.lexicon.preference.Preference;
import com.monsanto.tcc.lexicon.preference.PreferenceBean;
import com.monsanto.tcc.lexicon.preference.value.ListAllBatchesValue;
import com.monsanto.tcc.lexicon.templates.dom.TemplateNotValidException;
import com.monsanto.tcc.lexicon.templates.type.RowStatusType;
import com.monsanto.tcc.lexicon.utils.ATCommentWriter;
import com.monsanto.tcc.lexicon.utils.LogWriter;
import com.monsanto.tcc.lexicon.utils.db.LexiconConnectionHelper;
import com.monsanto.tcc.lexicon.utils.xml.XmlRepository;
import com.monsanto.tcc.lexiconcommon.PreferenceNames;
import com.monsanto.tcc.lexiconcommon.user.LexSecureUser;
import com.monsanto.tcc.lexiconcommon.user.LexSecureUserHelperImpl;
import org.w3c.dom.Document;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Aug 17, 2004
 * Time: 5:03:18 PM
 */
public class CompProdUCC
   extends LexiconUseCaseController
{
   public static final String ASSOCIATED_NAME = "associatedName";
   public static final String STATUS_ATTRIB   = "statusAttrib";
   public static final String LIST_ALL_BATCHES = "listAllBatches";

   public static final int MAX_FILENAME_LENGTH = 50;
   public static final String FILENAME_TOO_LONG_ERROR = "The file name must not exceed " + MAX_FILENAME_LENGTH + " characters";
   public static final String NO_NAME_GIVEN_ERROR = "The 'name for this file' field is required.";
   public static final String MULTIPLE_FILES_SELECTED_ERROR = "Please choose a single input file.  Only one may be loaded at a time.";
   public static final String NO_FILE_SELECTED_ERROR = "Please Select an input file";
   public static final String XMLFILE_ALREADY_EXISTS_ERROR = "A file already exists with the name of '";
   public static final String FILE_NOT_SAVED_ERROR = " Generated file could not be saved.";
   public static final String FILE_NOT_EXCEL_ERROR = "Cannot read this file as an Excel file.";

   protected boolean requiresPreferenceBean() {
      return true;
   }

   public void doService(UCCHelper helper)
      throws Throwable
   {
      String fwd = getSuccessForward();
      StringBuffer sbError = new StringBuffer();
      CompProdFileChooser bean = loadBeanFromRequest(helper);
      helper.setRequestAttributeValue(CompProdFileChooser.ATTR_NAME, bean);

      String strListAll = helper.getRequestParameterValue(LIST_ALL_BATCHES);
      if (!StringUtils.isNullOrEmpty(strListAll)) {
         PreferenceBean prefBean = PreferenceBean.getFromSession(helper);
         Preference pref = prefBean.getPreference(PreferenceNames.LIST_ALL_CPBATCHES_PREF_NAME);
         pref.setPrimaryValue(new ListAllBatchesValue(strListAll));
         updateFileDisplayList(bean, getUserNameFilter(helper));
         helper.forward(fwd);
         return;
      }

      ArrayList listFiles = helper.getClientFiles();
      boolean bRedirect = false;
      if (isValidFormInput(helper, bean, listFiles, sbError)) {
         File file = new File((String)listFiles.get(0));
         FileInputStream in = new FileInputStream(file);
         try {
            TemplateDOMBuilder builder = new TemplateDOMBuilder(new CompProdExcelReader(in));
            CompProdValidator validator = new CompProdValidator();
            CompProdXmlUtils cpXmlUtils = new CompProdXmlUtils();

            String strATComment1 = ATCommentWriter.generateATComment("CompProdXLSUploadFile_AT", "Comp Prod Upload Successful");

            Document doc = builder.buildDocument(bean.getAssociatedName(), getUserLoginId(helper));

            String strATComment2 = ATCommentWriter.generateATComment("CompProdXMLGeneration_AT", doc);

            validator.validateAndSetStatus(doc, LexiconConnectionHelper.getDefaultConnection());
            cpXmlUtils.updateStatsNode(doc);

            String strATComment3 = ATCommentWriter.generateATComment("CompProdValidation_AT", doc);

            CompProdXmlRepositoryHeader header = saveXmlResource(doc, sbError);
            if (null != header) {
               fwd = "/lexicon-app/servlet/ViewCompProdBatch";
               bRedirect = true;
               FileDisplayItem fdi = new FileDisplayItem();
               fdi.setHeader(header);
               fdi.setErrorMessage(strATComment1 + strATComment2 + strATComment3);
               fdi.setForcePosCall(true);
               fdi.setDefaultAuditComment("template add: " + fdi.getFileName());
               helper.setSessionParameter(FileDisplayItem.ATTR_NAME, fdi);
            }
            else {
               sbError.append(FILE_NOT_SAVED_ERROR);
            }
         }
         catch (TemplateNotValidException e) {
            sbError.append(e.getMessage());
         }
         catch (IOException ioe) {
            sbError.append(FILE_NOT_EXCEL_ERROR);
         }
         finally {
            in.close();
         }
      }

      if (sbError.length() > 0) {
         bean.setErrorMessage(sbError.toString());
      }
      updateFileDisplayList(bean, getUserNameFilter(helper));

      if (bRedirect) {
         helper.redirect(fwd);
      }
      else {
         helper.forward(fwd);
      }
   }

   private String getUserLoginId(UCCHelper helper) {
      LexSecureUser user = new LexSecureUserHelperImpl(helper);
      return user.getLoginName();
   }

   private CompProdFileChooser loadBeanFromRequest(UCCHelper helper)
      throws IOException
   {
      CompProdFileChooser bean = new CompProdFileChooser();
      bean.setAssociatedName(helper.getRequestParameterValue(ASSOCIATED_NAME));

      // If user reaches CompProdUCC, then should not be editing a
      // specific file yet.  Clear the session parameter just to
      // ensure that no apparent 'caching' occurs.
      helper.removeSessionParameter(FileDisplayItem.ATTR_NAME);

      return bean;
   }

   private boolean isValidFormInput(UCCHelper helper, CompProdFileChooser bean, ArrayList listFiles, StringBuffer sbError)
      throws WrappingException
   {
      String str = (String) helper.getRequestAttributeValue(STATUS_ATTRIB);

      String name = bean.getAssociatedName();
      XmlRepository repo = getXmlRepository();

      boolean isValid = false;

      // Another servlet (ViewCompProdBatchUCC) may have chained to this one.
      // If so, just set the error/status message
      if (!StringUtils.isNullOrEmpty(str)) {
         sbError.append(str);
      }
      else if (1 == listFiles.size() &&
         StringUtils.isNullOrEmpty(bean.getAssociatedName())) {
         sbError.append(NO_NAME_GIVEN_ERROR);
      }
      else if (listFiles.size() > 1) {
         sbError.append(MULTIPLE_FILES_SELECTED_ERROR);
      }
      else if (listFiles.isEmpty())  {
         sbError.append(NO_FILE_SELECTED_ERROR);
      }
      else if (null != repo.getHeader(name)) {
         sbError.append(XMLFILE_ALREADY_EXISTS_ERROR).append(name).append(".'");
      }
      else if (name != null && name.length() > MAX_FILENAME_LENGTH) {
         sbError.append(FILENAME_TOO_LONG_ERROR);
      }
      else {
         isValid = true;
      }
      return isValid;
   }
   
   private String getUserNameFilter(UCCHelper helper) {
      PreferenceBean prefBean = PreferenceBean.getFromSession(helper);
      Preference pref = prefBean.getPreference(PreferenceNames.LIST_ALL_CPBATCHES_PREF_NAME);
      return pref.getPrimaryValue().getObject().equals(Boolean.TRUE) ? null : getUserLoginId(helper);
   }

   private void updateFileDisplayList(CompProdFileChooser bean, String strUserName)
      throws IOException, WrappingException
   {
      List listDisplay = bean.getFileList();
      listDisplay.clear();

      XmlRepository repo = getXmlRepository();
      List listHeaders = repo.getHeaderList(strUserName);
      StatusImageTag sit = new StatusImageTag();

      int iRowNum = 0;
      Iterator iter = listHeaders.iterator();
      while(iter.hasNext()) {
         CompProdXmlRepositoryHeader header = (CompProdXmlRepositoryHeader)iter.next();

         FileDisplayItem fdi = new FileDisplayItem();
         listDisplay.add(fdi);
         fdi.setHeader(header);
         fdi.setDefaultAuditComment("template add: " + fdi.getFileName());

         RowStatusType status;
         if (header.numErrored() > 0) {
            status = RowStatusType.ERRORED;
            fdi.setRowClass(this.getProperty(CLASS_REDBACK, true));
         }
         else if (header.numUnprocessed() > 0) {
            status = RowStatusType.UNPROCESSED;
            fdi.setRowClass(this.getProperty(CLASS_CYANBACK, true));
         }
         else if (header.numValidated() > 0) {
            status = RowStatusType.VALIDATED;
            fdi.setRowClass(this.getProperty(CLASS_YELLOWBACK, true));
         }
         else {
            status = RowStatusType.COMMITTED;
            fdi.setRowClass(this.getProperty(CLASS_GREENBACK, true));
         }

         fdi.setImage(sit.getImageTag(iRowNum++, status.getName(), null, null, false, false));

         if (!StringUtils.isNullOrEmpty(fdi.getAdded())) {
            if (Integer.parseInt(fdi.getAdded()) == 0) {
               fdi.setDeleteLink(buildDeleteLink(fdi));
            }
         }

      }
   }

   private String buildDeleteLink(FileDisplayItem fdi)  {
      StringBuilder sb = new StringBuilder("<A HREF=\"javascript:document.ViewCompProdBatch.submit();\"");
      sb.append(" onclick=\"return setDeleteName('").append(fdi.getFileName()).append("')\"");
      sb.append(" title=\"delete file: ").append(fdi.getFileName()).append("\"");
      sb.append(">");
      sb.append("<IMG BORDER=\"0\" WIDTH=\"16\" HEIGHT=\"16\" SRC=\"/lexicon-app/images/delete.gif\" >");      
      sb.append("</A>");

      return sb.toString();
   }

   private CompProdXmlRepositoryHeader saveXmlResource(Document doc, StringBuffer sbError)
      throws WrappingException
   {
      XmlRepository repo = getXmlRepository();

      try {
         return (CompProdXmlRepositoryHeader)repo.saveDocument(doc);
      }
      catch (WrappingException e) {
         LogWriter.logWrappingException(_log, e);
         sbError.append("Save failed: ").append(e.getMessage());
         return null;
      }
   }

   // Override this function to make a determination if the request is valid
   protected boolean isValidRequest(UCCHelper helper) throws Throwable {
      AppRoles appRolesBean = loadUserAppRoles(helper);

      return appRolesBean.isUserInAppRole(AppRoles.ROLE_CP_EDIT);
   }
}
