/*
 BaseProductByBaseNameQuerySQL was created on Oct 24, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.queryset.query;

/**
 * nbwald Oct 24, 2007 5:53:05 PM
 */
public interface BaseProductByBaseNameQuerySQL
{
   String SELECT_BY_BASE_NAME = "BaseProduct.SelectByBaseName";
   String BASE_MANF_NAME_ALIAS = "BaseProduct.BaseManufacturingName";
   String CROP_NAME_ALIAS = "Crop.CropName";
   String PARENT_PRODUCT_ALIAS = "BaseProduct.ParentProduct";
}