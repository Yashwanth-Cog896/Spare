package com.monsanto.tcc.lexicon.competitiveproduct.mapping;

import com.monsanto.tcc.lexicon.competitiveproduct.mapping.RowObject;

/**
 * nbwald - Nov 12, 2009 1:32:17 PM
 */
public class SourceVerifiedComparator
   extends StringMethodComparator
{
   @Override
   public String eval(RowObject rowObject) {
      return rowObject.getSourceVerified();
   }
}
