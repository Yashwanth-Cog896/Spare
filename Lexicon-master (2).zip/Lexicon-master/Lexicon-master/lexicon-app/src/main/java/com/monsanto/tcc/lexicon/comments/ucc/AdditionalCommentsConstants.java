package com.monsanto.tcc.lexicon.comments.ucc;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rlcasw
 * Date: Oct 14, 2011
 * Time: 12:57:30 PM
 * To change this template use File | Settings | File Templates.
 */
public class AdditionalCommentsConstants {
    public static final String EDIT="edit";
    public static final String DISCARD="discard";
    public static final String COMMIT="commit";
    public static  final String COMMENTS_PRODUCT_SEARCH_BEAN = "commentsProductSearchBean";
    public static final String ROWNUM="rownum";
    public static final String COMMENTS_TOO_LONG="Additional comments length is greater than 4000";

}
