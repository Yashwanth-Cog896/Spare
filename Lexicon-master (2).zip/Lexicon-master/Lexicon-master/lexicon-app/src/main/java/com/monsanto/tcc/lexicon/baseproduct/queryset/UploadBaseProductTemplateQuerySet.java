/*
 UploadBaseProductTemplateQuerySet was created on Oct 22, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.queryset;

import com.monsanto.tcc.lexicon.baseproduct.queryset.query.BaseProductByBaseNameQuery;
import com.monsanto.tcc.lexicon.baseproduct.queryset.query.CropNameQuery;
import com.monsanto.tcc.lexicon.baseproduct.queryset.query.ManufacturingFamiliesByBaseNamesQuery;

/**
 * nbwald Oct 22, 2007 12:33:18 PM
 */
public interface UploadBaseProductTemplateQuerySet
   extends
   BaseProductByBaseNameQuery,
   CropNameQuery,
   ManufacturingFamiliesByBaseNamesQuery
{
}