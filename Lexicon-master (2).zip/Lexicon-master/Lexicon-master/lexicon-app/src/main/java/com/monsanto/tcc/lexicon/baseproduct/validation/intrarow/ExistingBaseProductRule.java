/*
 ExistingBaseProductRule was created on Oct 22, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.validation.intrarow;

import com.monsanto.tcc.lexicon.baseproduct.queryset.model.BaseProduct;
import com.monsanto.tcc.lexicon.baseproduct.queryset.query.BaseProductByBaseNameQuery;
import com.monsanto.tcc.lexicon.baseproduct.validation.BaseProductTemplateRule;

/**
 * nbwald Oct 22, 2007 11:11:51 AM
 */
public abstract class ExistingBaseProductRule
   implements BaseProductTemplateRule
{
   private final BaseProductByBaseNameQuery baseProductQuery;
   private final String baseManfName;

   public ExistingBaseProductRule(BaseProductByBaseNameQuery baseProductQuery, String baseManfName) {
      this.baseProductQuery = baseProductQuery;
      this.baseManfName = baseManfName;
   }

   public boolean violated() {
      BaseProduct baseProduct = baseProductQuery.getBaseProduct(baseManfName);
      return exists(baseProduct) && violated(baseProduct);
   }

   protected abstract boolean violated(BaseProduct existingBaseProduct);

   private boolean exists(BaseProduct baseProduct) {
      return baseProduct != null;
   }
}