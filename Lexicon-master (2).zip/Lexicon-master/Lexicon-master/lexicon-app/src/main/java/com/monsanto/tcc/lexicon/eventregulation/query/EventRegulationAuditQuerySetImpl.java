package com.monsanto.tcc.lexicon.eventregulation.query;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.lexicon.referencetable.audit.query.AuditInfoByTableNameAndPrimaryKeyQuery;
import com.monsanto.tcc.lexicon.utils.audit.AuditInfo;

/**
 * nbwald - Feb 10, 2009 11:07:50 PM
 */
public class EventRegulationAuditQuerySetImpl
   implements EventRegulationAuditQuerySet
{
   @Override
   public String[] findEventRegulationPrimaryKeysByEventName(String eventName)
      throws WrappingException
   {
      EventRegulationPrimaryKeysByEventNameQuery query = new EventRegulationPrimaryKeysByEventNameQuery(eventName);
      return query.find();
   }

   @Override
   public AuditInfo findEventRegulationAuditInfoByPrimaryKey(String primaryKeyValue)
      throws WrappingException
   {
      AuditInfoByTableNameAndPrimaryKeyQuery query = new AuditInfoByTableNameAndPrimaryKeyQuery("EVENT_AGENCY_ALIGNMENT", primaryKeyValue);
      return query.find();
   }
}
