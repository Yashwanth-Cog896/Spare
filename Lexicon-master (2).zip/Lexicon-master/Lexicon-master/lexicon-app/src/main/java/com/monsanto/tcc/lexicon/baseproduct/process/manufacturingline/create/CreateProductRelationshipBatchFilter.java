/*
 CreateProductRelationshipBatchFilter was created on Aug 7, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.process.manufacturingline.create;

import com.monsanto.tcc.lexicon.baseproduct.model.CreateableProductRelationship;
import com.monsanto.tcc.lexiconcommon.pos.batch.InputModelBatchFilter;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald Aug 7, 2007 1:59:13 PM
 */
public class CreateProductRelationshipBatchFilter
   implements InputModelBatchFilter<CreateableProductRelationship>
{
   public boolean includeModel(CreateableProductRelationship inputModel)
      throws WrappingException
   {
      return inputModel.isCreateable();
   }
}