/*
 CreateBaseProductResponseUpdater was created on Jul 2, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.process.baseproduct.create;

import com.monsanto.tcc.lexicon.baseproduct.model.BaseProductBean;
import com.monsanto.tcc.lexiconcommon.pos.batch.ServiceResponseMerger;
import com.monsanto.tcc.lexiconcommon.service.baseproduct.CreateBaseProductResponse;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald Jul 2, 2007 12:32:13 PM
 */
public class CreateBaseProductResponseMerger
   implements ServiceResponseMerger<BaseProductBean, CreateBaseProductResponse>
{
   public void mergeResponse(final BaseProductBean baseProduct, final CreateBaseProductResponse response)
      throws WrappingException
   {
      baseProduct.update(response.getMessages());
   }
}