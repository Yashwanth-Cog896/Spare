package com.monsanto.tcc.lexicon.baseproduct.process.baseproduct.create;

import com.monsanto.tcc.lexicon.baseproduct.model.BaseProductBean;
import com.monsanto.tcc.lexiconcommon.pos.batch.InputModelBatchFilter;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Aug 3, 2007
 * Time: 6:24:24 PM
 */
public class CreateBaseProductBatchFilter
   implements InputModelBatchFilter<BaseProductBean>
{
   public boolean includeModel(final BaseProductBean baseProduct) throws WrappingException {
      return baseProduct.isCommitable();
   }
}

