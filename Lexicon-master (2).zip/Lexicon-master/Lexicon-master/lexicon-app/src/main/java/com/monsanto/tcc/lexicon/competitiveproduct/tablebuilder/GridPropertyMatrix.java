package com.monsanto.tcc.lexicon.competitiveproduct.tablebuilder;

import com.monsanto.tcc.lexicon.competitiveproduct.mapping.RowObject;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.RowObjectList;
import com.monsanto.tcc.lexicon.utils.gui.HtmlRow;
import com.monsanto.tcc.lexicon.utils.gui.HtmlTable;
import com.monsanto.Util.Exceptions.WrappingException;
import java.util.Iterator;
import java.util.Properties;

/**
 * Created by IntelliJ IDEA.
 * User: adcox
 * Date: Jan 21, 2005
 * Time: 3:45:33 PM
 * To change this template use File | Settings | File Templates.
 */
public class GridPropertyMatrix {
   private boolean hasEditableRows;
   private boolean hasCopyableRows;
   private Properties propsBase;
   private Properties propsEditEditable;
   private Properties propsCopyCopyable;
   private Properties propsEditReadOnly;
   private Properties propsCopyReadOnly;
   private Properties propsCopyEditable;

   private void init(
           RowObjectList list,
           Properties propsBase,
           Properties propsEditEditable,
           Properties propsEditReadOnly,
           Properties propsCopyReadOnly,
           Properties propsCopyEditable,
           Properties propsCopyCopyable )
   {
      this.propsBase         = propsBase;
      this.propsEditReadOnly = propsEditReadOnly;
      this.propsEditEditable = propsEditEditable;
      this.propsCopyReadOnly = propsCopyReadOnly;
      this.propsCopyEditable = propsCopyEditable;
      this.propsCopyCopyable = propsCopyCopyable;

      setEditableCopyableFlags(list);
   }

   private void setEditableCopyableFlags(RowObjectList list) {
      hasEditableRows = false;
      hasCopyableRows = false;

      for (Iterator iterator = list.iterator(); iterator.hasNext();) {
         RowObject rowObject = (RowObject) iterator.next();
         if (rowObject.isCopied()) {
            hasCopyableRows = true;
            if (rowObject.isEditing()) {
               throw new RuntimeException("Cannot support isEditing() and isCopied() in same row.");
            }
         }
         else if (rowObject.isEditing()) {
            hasEditableRows = true;
         }

         if (hasCopyableRows && hasEditableRows) {
            break;
         }
      }
   }



   public GridPropertyMatrix(RowObjectList list, Properties propsBase) {
      init(list, propsBase, propsBase, propsBase, propsBase, propsBase, propsBase);   
   }

   public GridPropertyMatrix(
           RowObjectList list,
           Properties propsBase,
           Properties propsEditable,
           Properties propsEditReadOnly,
           Properties propsCopyReadOnly,
           Properties propsCopyEditable,
           Properties propsCopyCopy )
   {
      init(list, propsBase, propsEditable, propsEditReadOnly, propsCopyReadOnly,
                 propsCopyEditable, propsCopyCopy);
   }


   public HtmlTable buildTableHeader() {
      HtmlTable table = null;
      if (hasCopyableRows) {
         table = new HtmlTable(propsCopyCopyable);
      }
      else if (hasEditableRows) {
         table = new HtmlTable(propsEditEditable);
      }
      else {
         table = new HtmlTable(propsBase);
      }

      return table;
   }

   public HtmlRow buildRow(
      RowObject ro,
      boolean isHidden)
      throws WrappingException 
   {
      HtmlRow row = null;
      if (isHidden) {
         row = new HtmlRow(true);
      }
      else if (hasCopyableRows) {
         if (ro.isCopied()) {
            row = new HtmlRow(propsCopyCopyable);
         }
         else if (ro.isEditing()) {
            row = new HtmlRow(propsCopyEditable);
         }
         else {
            row = new HtmlRow(propsCopyReadOnly);
         }
      }
      else if (hasEditableRows) {
         // implied that matrix does not have copied rows
         if (ro.isCopied()) {
            throw new RuntimeException("Cannot support isEditing() and isCopied() in same row.");
         }
         else if (ro.isEditing()) {
            row = new HtmlRow(propsEditEditable);
         }
         else {
            row = new HtmlRow(propsEditReadOnly);
         }
      }
      else {
         row = new HtmlRow(propsBase);
      }

      return row;
   }
}
