package com.monsanto.tcc.lexicon.baseproduct.dao.manufacturingfamily;

import com.monsanto.tcc.lexiconcommon.pos.LexiconServiceInvoker;
import com.monsanto.tcc.lexiconcommon.pos.ServiceInvoker;
import com.monsanto.tcc.lexiconcommon.pos.SingleModelServiceCall;
import com.monsanto.tcc.lexiconcommon.service.manufacturingfamily.search.dom.ManufacturingFamilySearchRequestSerializer;
import com.monsanto.tcc.lexiconcommon.service.manufacturingfamily.search.dom.ManufacturingFamilySearchResponseSerializer;
import com.monsanto.tcc.lexiconcommon.service.manufacturingfamily.search.model.ManufacturingFamilySearchRequest;
import com.monsanto.tcc.lexiconcommon.service.manufacturingfamily.search.model.ManufacturingFamilySearchResponse;
import com.monsanto.tcc.lexiconcommon.service.serialize.Serializer;

/**
 * User: pjberry
 * Date: Aug 22, 2007
 * Time: 3:03:47 PM
 */
public class ManufacturingFamilySearchServiceCall
   extends SingleModelServiceCall<ManufacturingFamilySearchRequest, ManufacturingFamilySearchResponse>
{
   protected ServiceInvoker getServiceInvoker() {
      return new LexiconServiceInvoker("Lex_ManufacturingFamilySearch");
   }

   protected Serializer<ManufacturingFamilySearchRequest> getRequestSerializer() {
      return new ManufacturingFamilySearchRequestSerializer();
   }

   protected Serializer<ManufacturingFamilySearchResponse> getResponseSerializer() {
      return new ManufacturingFamilySearchResponseSerializer();
   }
}
