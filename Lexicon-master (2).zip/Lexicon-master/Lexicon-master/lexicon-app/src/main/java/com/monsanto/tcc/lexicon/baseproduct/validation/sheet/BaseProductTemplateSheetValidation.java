/*
 BaseProductTemplateSheetValidation was created on Oct 9, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.validation.sheet;

import com.monsanto.tcc.lexicon.baseproduct.excel.BaseProductTemplateRow;
import com.monsanto.tcc.lexicon.baseproduct.queryset.UploadBaseProductTemplateQuerySet;
import com.monsanto.tcc.lexicon.baseproduct.validation.BaseProductTemplateError;
import com.monsanto.tcc.lexicon.baseproduct.validation.BaseProductTemplateSheetMessages;
import com.monsanto.tcc.lexicon.baseproduct.validation.InvalidTemplateException;
import com.monsanto.tcc.lexicon.baseproduct.validation.interrow.BaseProductTemplateInterrowValidation;
import com.monsanto.tcc.lexicon.baseproduct.validation.intrarow.BaseProductTemplateIntrarowValidation;
import com.monsanto.tcc.lexiconcommon.file.excel.ExcelRow;
import com.monsanto.tcc.lexiconcommon.file.excel.ExcelSheet;

/**
 * nbwald Oct 9, 2007 3:14:18 PM
 */
public class BaseProductTemplateSheetValidation
{
   private final ExcelSheet excelSheet;
   private final UploadBaseProductTemplateQuerySet querySet;

   public BaseProductTemplateSheetValidation(ExcelSheet excelSheet, UploadBaseProductTemplateQuerySet querySet) {
      this.excelSheet = excelSheet;
      this.querySet = querySet;
   }

   public void validate()
      throws InvalidTemplateException
   {
      BaseProductTemplateSheetMessages sheetMessages = new BaseProductTemplateSheetMessages();
      validateHasData(excelSheet);
      validateHasLessThanMaxRows(excelSheet);
      collectInterrowMessages(excelSheet.getData(), sheetMessages);
      collectIntrarowMessages(excelSheet.getData(), sheetMessages);
      if(sheetMessages.hasMessages()) {
         throw new InvalidTemplateException(sheetMessages);
      }
   }

   private void validateHasData(ExcelSheet excelSheet)
      throws InvalidTemplateException
   {
      HasDataRule rule = new HasDataRule(excelSheet);
      if(rule.violated()) {
         throw new InvalidTemplateException(rule.getViolation());
      }
   }

   private void validateHasLessThanMaxRows(ExcelSheet excelSheet)
      throws InvalidTemplateException
   {
      LessThanMaxNumberOfRowsRule rule = new LessThanMaxNumberOfRowsRule(excelSheet);
      if(rule.violated()) {
         throw new InvalidTemplateException(rule.getViolation());
      }
   }

   private void collectInterrowMessages(ExcelRow[] excelRows, BaseProductTemplateSheetMessages sheetMessages) {
      for (int i = 0; i < excelRows.length; i++) {
         for (int j = i + 1; j < excelRows.length; j++) {
            BaseProductTemplateError[] errors = doInterrowValidation(excelRows[i], excelRows[j]);
            sheetMessages.addErrors(getExcelRow(i), getExcelRow(j), errors);
         }
      }
   }

   private BaseProductTemplateError[] doInterrowValidation(ExcelRow excelRowI, ExcelRow excelRowJ) {
      BaseProductTemplateRow rowI = new BaseProductTemplateRow(excelRowI);
      BaseProductTemplateRow rowJ = new BaseProductTemplateRow(excelRowJ);
      BaseProductTemplateInterrowValidation validation = new BaseProductTemplateInterrowValidation(rowI, rowJ);
      return validation.validate();
   }

   private void collectIntrarowMessages(ExcelRow[] excelRows, BaseProductTemplateSheetMessages sheetMessages) {
      for (int i = 0; i < excelRows.length; i++) {
         BaseProductTemplateError[] rowErrors = doIntrarowValidation(excelRows[i]);
         sheetMessages.addErrors(getExcelRow(i), rowErrors);
      }
   }

   private BaseProductTemplateError[] doIntrarowValidation(ExcelRow excelRow) {
      BaseProductTemplateIntrarowValidation validation = new BaseProductTemplateIntrarowValidation(excelRow, querySet);
      return validation.validate();
   }

   private int getExcelRow(int i) {
      return i + 2; // One based (instead of 0) and skip header row.
   }
}