package com.monsanto.tcc.lexicon.controllers;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.tcc.lexicon.LexiconServlet.LexiconUseCaseController;
import com.monsanto.tcc.lexicon.controllers.beans.LogViewerBean;

import java.io.File;
import java.io.IOException;


/**
 * Created by IntelliJ IDEA.
 * User: JASKIDI
 * Date: Jul 12, 2004
 * Time: 10:15:12 AM
 * To change this template use File | Settings | File Templates.
 */
public class LogViewerUCC
   extends LexiconUseCaseController
{
   private static final String FORWARD_PAGE = "/LogViewer.jsp";

   public static final String FILE_NAME_PARAM = "fileName";
   public static final String REG_EXP_PARAM = "regexp";
   public static final String LINE_COUNT_PARAM = "lineCount";
   public static final String START_LINE_PARAM = "startLine";
   public static final String REVERSE_PARAM = "reverse";
   public static final String SEARCH_ONLY_PARAM = "searchOnly";
   public static final String WRAP_PARAM = "wrap";

   public static final String SUBMIT_PARAM = "submit";
   public static final String PREV_SUBMIT = "Previous";
   public static final String NEXT_SUBMIT = "Next";

   public static final String SPECIFY_FILE_MSG = "Please specify a file.";
   public static final String FILE_NOT_FOUND_MSG = "File not found: ";
   public static final String CANT_READ_FILE_MSG = "Can't read file: ";

   public void doService(
      UCCHelper helper)
      throws IOException
   {
      LogViewerBean bean = getBean(helper);
      try {
          StringBuffer statusBuffer  = new StringBuffer();
          File file = getFile(bean, statusBuffer);

          if (statusBuffer.length() > 0) {
              bean.setStatus(statusBuffer.toString());
          }
          else {
              LogContent logContent = new LogContent(file);
              int startLine = getStartLine(bean, logContent.getLogLineCount());
              int lineCount = getLineCount(bean, logContent.getLogLineCount());
              if (bean.getSubmit() != null) {
                  startLine = adjustStartLine(bean, startLine, lineCount, logContent.getLogLineCount());
              }

              String strRegExp = bean.getRegexp();
              boolean isReverse = (bean.getReverse() != null);
              boolean isSearchOnly = (bean.getSearchOnly() != null);

              StringBuffer contentBuffer = logContent.getLogfileContent(
                  startLine, lineCount, isReverse, statusBuffer, strRegExp, isSearchOnly);

              wrapContentWithTags(bean, contentBuffer);
              bean.setStatus(statusBuffer.toString());
              bean.setContent(contentBuffer.toString());
          }
      }
      catch (Exception e) {
          bean.setStatus(e.getMessage());
          Logger.log(new LoggableError(e));
      }

      helper.forward(FORWARD_PAGE);
 }

  private LogViewerBean getBean(
      UCCHelper helper)
      throws IOException
  {
      LogViewerBean bean = (LogViewerBean) helper.getRequestAttributeValue(LogViewerBean.NAME);
      if (bean == null) {
          bean = new LogViewerBean();
          fillBean(bean, helper);
          helper.setRequestAttributeValue(LogViewerBean.NAME, bean);
      }
      return bean;
  }

  private void fillBean(
      LogViewerBean bean,
      UCCHelper helper)
      throws IOException
  {
      bean.setStatus(null);
      bean.setContent(null);
      bean.setAbsolutePath(null);
      bean.setSubmit((String)helper.getRequestParameterValue(SUBMIT_PARAM));
      bean.setFileName((String)helper.getRequestParameterValue(FILE_NAME_PARAM));
      bean.setRegexp((String)helper.getRequestParameterValue(REG_EXP_PARAM));
      bean.setLineCount((String)helper.getRequestParameterValue(LINE_COUNT_PARAM));
      bean.setStartLine((String)helper.getRequestParameterValue(START_LINE_PARAM));
      bean.setReverse(getCBRequest(helper, REVERSE_PARAM));
      bean.setSearchOnly(getCBRequest(helper, SEARCH_ONLY_PARAM));
      bean.setWrap(getCBRequest(helper, WRAP_PARAM));
  }

  private String getCBRequest(
      UCCHelper helper,
      String key)
      throws IOException
  {
      return (helper.getRequestParameterValue(key) != null) ? "CHECKED" : null;
  }

  private File getFile(
      LogViewerBean bean,
      StringBuffer statusBuffer)
      throws IOException
  {
      String filename = bean.getFileName();
      if (filename == null || filename.length() == 0) {
         statusBuffer.append(SPECIFY_FILE_MSG);
         return null;
      }

      File file = new File(filename);
      if (!file.exists()) {
          if (!(filename.startsWith("/") || filename.startsWith("\\"))) {
              String str = prependLogPath(filename);
              file = new File(str);
          }
      }
      if (!file.exists()) {
          statusBuffer.append(FILE_NOT_FOUND_MSG + filename);
          return null;
      }
      if ((!file.canRead())) {
          statusBuffer.append(CANT_READ_FILE_MSG + bean.getFileName());
          return null;
      }
      bean.setAbsolutePath(file.getCanonicalPath());
      return file;
  }

  private String prependLogPath(String strFilename)
  {
      String str = getLogPath();
      if (str != null) {
         str += File.separator + strFilename;
      }
      return str;
 }

  private int getStartLine(
      LogViewerBean bean,
      int logLineCount)
  {
      int startLine;
      try {
          startLine = Integer.parseInt(bean.getStartLine());
      }
      catch (NumberFormatException nfe) {
          startLine = 0;
      }
      startLine = Math.max(0, startLine);
      if (startLine > logLineCount) {
          startLine = 0;
      }
      bean.setStartLine(Integer.toString(startLine));
      return startLine;
  }

  private int getLineCount(
      LogViewerBean bean,
      int logLineCount)
  {
      int lineCount;
      try {
          lineCount = Integer.parseInt(bean.getLineCount());
      }
      catch (NumberFormatException nfe) {
          lineCount = 100;
      }
      lineCount = Math.max(1, lineCount);
      lineCount = Math.min(lineCount, logLineCount);
      bean.setLineCount(Integer.toString(lineCount));
      return lineCount;
  }

  private int adjustStartLine(
      LogViewerBean bean,
      int startLine,
      int lineCount,
      int logLineCount)
  {
      int newStartLine = startLine;
      if (bean.getSubmit().equalsIgnoreCase(PREV_SUBMIT)) {
          if (startLine == 0) {
              newStartLine = logLineCount - lineCount +1;
          }
          newStartLine = Math.max(0, newStartLine - lineCount);
      }
      else if (bean.getSubmit().equalsIgnoreCase(NEXT_SUBMIT)) {
          if (startLine > 0) {
              newStartLine += lineCount;
              if (newStartLine > logLineCount) {
                  newStartLine = startLine;
              }
          }
      }
      bean.setStartLine(Integer.toString(newStartLine));
      return newStartLine;
  }

  private void wrapContentWithTags(
      LogViewerBean bean,
      StringBuffer contentBuffer)
  {
      contentBuffer.insert(0, "<CODE>");
      contentBuffer.append("</CODE>");
      if (bean.getWrap() != null) {
          contentBuffer.insert(0, "<TABLE BORDER=\"0\"><TR><TD NOWRAP>");
          contentBuffer.append("</TD></TR></TABLE>");
      }
  }

}
