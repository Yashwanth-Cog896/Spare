package com.monsanto.tcc.lexicon.competitiveproduct.types;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Mar 31, 2005
 * Time: 4:25:46 PM
 * To change this template use File | Settings | File Templates.
 */
public class CompProdSourceType
{
   public static final CompProdSourceType WEB_VERIFIED = new CompProdSourceType("VWEB");
   public static final CompProdSourceType CAT_VERIFIED = new CompProdSourceType("VCAT");

   public static final CompProdSourceType[] TYPES = new CompProdSourceType[]
      { WEB_VERIFIED, CAT_VERIFIED };


   public static CompProdSourceType fromName(String name)
   {
      for (int i = 0; i < TYPES.length; i++) {
         if (TYPES[i].equals(name)) {
            return TYPES[i];
         }
      }
      return null;
   }

   private String name;

   protected CompProdSourceType(String name)
   {
      if (name == null) {
         throw new NullPointerException();
      }
      this.name = name;
   }

   public String getName() {
      return name;
   }

   public String toString() {
      return getName();
   }

   public boolean equals(String str) {
      return (str == null) ? false : this.name.toUpperCase().equals(str.toUpperCase());
   }

   public boolean equals(Object o)
   {
      if (this == o) {
         return true;
      }
      if (o == null || !(o instanceof CompProdSourceType)) {
         return false;
      }
      final CompProdSourceType type = (CompProdSourceType)o;
      return equals(type.getName());
   }

   public int hashCode() {
      return name.hashCode();
   }
}
