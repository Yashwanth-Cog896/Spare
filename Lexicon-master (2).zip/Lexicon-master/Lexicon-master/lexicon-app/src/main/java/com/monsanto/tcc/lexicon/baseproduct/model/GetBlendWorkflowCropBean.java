package com.monsanto.tcc.lexicon.baseproduct.model;

import com.monsanto.tcc.lexicon.spring.ThreadLocalApplicationContext;
import com.monsanto.tps.lexiconservices.crop.service.BlendWorkflowCropService;
import com.monsanto.tps.lexiconservices.manufacturing.line.edit.services.EditManufacturingLineService;
import org.springframework.context.ApplicationContext;

import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 4/25/14
 * Time: 2:03 PM
 */

public class GetBlendWorkflowCropBean {

    private static List<String> blendWorkflowCrops = null;

    public List<String> getBlendWorkflowCrops() {
        if (null == blendWorkflowCrops) {
            BlendWorkflowCropService blendWorkflowCropService = getBlendWorkflowCropServiceBean();
            blendWorkflowCrops = blendWorkflowCropService.getBlendWorkflowCropNames();
        }
        return blendWorkflowCrops;
    }

    private BlendWorkflowCropService getBlendWorkflowCropServiceBean() {
        ApplicationContext context = ThreadLocalApplicationContext.getApplicationContext();
        return (BlendWorkflowCropService) context.getBean("blendWorkflowCropService");
    }
}
