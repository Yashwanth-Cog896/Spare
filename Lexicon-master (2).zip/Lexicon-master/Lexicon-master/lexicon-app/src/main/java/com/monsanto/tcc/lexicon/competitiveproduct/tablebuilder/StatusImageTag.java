package com.monsanto.tcc.lexicon.competitiveproduct.tablebuilder;

import com.monsanto.tcc.lexicon.competitiveproduct.mapping.RowObject;
import com.monsanto.tcc.lexicon.templates.type.RowStatusType;
import com.monsanto.Util.StringUtils;
import org.apache.regexp.RE;
import org.apache.regexp.RESyntaxException;

/**
 * Created by IntelliJ IDEA.
 * User: adcox
 * Date: Sep 2, 2004
 * Time: 4:49:43 PM
 * To change this template use File | Settings | File Templates.
 */
public class StatusImageTag {
   private static volatile RE reQuote;

   public StatusImageTag() {
      if (reQuote == null) {
         synchronized(this.getClass()) {
            reQuote = null;
            try {
               reQuote = new RE("\"|'");
            } catch (RESyntaxException e) {
               throw new RuntimeException(e.getMessage());
            }
         }
      }
   }


   public String getImageTag(int iRow, RowObject ro, boolean bIncludeDeleteImage, boolean bLinkToTitle)
   {
//      boolean bLinkToTitle = (!RowStatusType.COMMITTED.equals(ro.getStatus()));
      return getImageTag(iRow, ro.getStatus(), ro.getErrors(), ro.getNotes(), bIncludeDeleteImage, bLinkToTitle);
   }


   public String getImageTag(
      int iRow,
      String status,
      String errors,
      String notes,
      boolean bIncludeDeleteImage,
      boolean bLinkToTitle)
   {
      String imageSrc = getImageSrcName(status, notes);

      StringBuffer sb = new StringBuffer("");

      sb.append("<IMG ID=\"I" + iRow + "_IMG\"");
      sb.append(" BORDER=\"0\"");
      sb.append(" WIDTH=\"16\"");
      sb.append(" HEIGHT=\"16\"");
      sb.append(" SRC=\"" + imageSrc + "\"");

      sb.append(" TITLE=\"");
      sb.append(stripQuotes(status));
      if (!StringUtils.isNullOrEmpty(stripQuotes(errors))) {
         sb.append(": " + errors);
      }
      else if (!StringUtils.isNullOrEmpty(stripQuotes(notes))) {
         sb.append(": " + notes);
      }
      sb.append("\"");

      if (bLinkToTitle) {
         sb.append(" ONCLICK=\"showTitle(this);\"");
      }

      sb.append(">");


      if (bIncludeDeleteImage) {
         if (!RowStatusType.COMMITTED.equals(status)) {

            if (RowStatusType.ABANDONED.equals(status)) {
               sb.append("<A HREF=\"javascript:document.SubmitChanges.submit();\" onclick=\"return deleteTheRow('" + iRow + "');\" ><IMG BORDER=\"0\" WIDTH=\"7\" HEIGHT=\"7\" SRC=\"/lexicon-app/images/undo.gif\" TITLE=\"UN delete row "+(iRow+1)+".\" ></A>");
            }
            else {
               sb.append("<A HREF=\"javascript:document.SubmitChanges.submit();\" onclick=\"return deleteTheRow('" + iRow + "');\" ><IMG BORDER=\"0\" WIDTH=\"7\" HEIGHT=\"7\" SRC=\"/lexicon-app/images/X.gif\" TITLE=\"Delete row "+(iRow+1)+".\" ></A>");
            }
         }
      }

      return sb.toString();
   }

   private String getImageSrcName(String status, String notes)
   {
      String ret = null;
      if (RowStatusType.ERRORED.equals(status)) {
         ret = "/lexicon-app/images/stopsign_16.gif";
      }
      else if (RowStatusType.UNPROCESSED.equals(status)) {
         ret = "/lexicon-app/images/question_16.gif";
      }
      else if (RowStatusType.COMMITTED.equals(status)) {
         if (StringUtils.isNullOrEmpty(notes)) {
            ret = "/lexicon-app/images/checkmark_16.gif";
         } else {
            ret = "/lexicon-app/images/checkmark_info_16.gif";
         }
      }
      else if (RowStatusType.VALIDATED.equals(status)) {
         if (StringUtils.isNullOrEmpty(notes)) {
            ret = "/lexicon-app/images/yield_16.gif";
         } else {
            ret = "/lexicon-app/images/yield_info_16.gif";
         }
      }
      else if (RowStatusType.ABANDONED.equals(status)) {
         ret = "/lexicon-app/images/noenter_16.gif";
      }
      else if (RowStatusType.EXISTS.equals(status)) {
         ret = "/lexicon-app/images/checkmark_16.gif";
      }
      else {
         throw new RuntimeException("Invalid status: " + status);
      }

      return ret;
   }

   public synchronized String stripQuotes(String src) {
      return ((src != null && reQuote.match(src)) ? reQuote.subst(src, "") : src);
   }
}
