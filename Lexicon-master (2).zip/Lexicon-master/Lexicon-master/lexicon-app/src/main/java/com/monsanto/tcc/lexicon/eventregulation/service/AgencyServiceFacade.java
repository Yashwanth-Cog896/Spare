package com.monsanto.tcc.lexicon.eventregulation.service;

import com.monsanto.tps.lexicon.agency.Agency;

/**
 * nbwald - Feb 3, 2009 6:55:39 PM
 */
public interface AgencyServiceFacade
{
   Agency[] findAllAgencies();
}
