package com.monsanto.tcc.lexicon.controllers.beans;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Aug 10, 2004
 * Time: 2:47:28 PM
 * To change this template use File | Settings | File Templates.
 */
public class MainMenu
{
   public static final String BEAN_ATTR_NAME = "MainMenuBean";

   private String userName;
   private String version;
   private String databaseMessage;

   public String getUserName() {
      return userName;
   }

   public void setUserName(String userName) {
      this.userName = userName;
   }

   public String getDatabaseMessage() {
      return databaseMessage;
   }

   public void setDatabaseMessage(String databaseMessage) {
      this.databaseMessage = databaseMessage;
   }
}
