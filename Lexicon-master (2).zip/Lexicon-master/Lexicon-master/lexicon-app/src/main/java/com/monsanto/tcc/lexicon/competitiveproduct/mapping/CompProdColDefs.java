package com.monsanto.tcc.lexicon.competitiveproduct.mapping;

import java.util.HashMap;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Aug 26, 2004
 * Time: 10:18:32 AM
 * To change this template use File | Settings | File Templates.
 */
public class CompProdColDefs
   implements ICompProdColDefs,
              CompProdXmlTags
{
   private static HashMap _map = new HashMap();

   public static HashMap getColumnNameMap() {
      if (_map.size() == 0) {
         synchronized(_map) {
            if (_map.size() == 0) {
               for(int i = 0; i < ELEMENT_NAMES.length; i++) {
                  _map.put(ELEMENT_NAMES[i], new Integer(i));
               }
            }
         }
      }

      return _map;
   }

/*
   public static String getColumnName(
      String strElementName)
   {
      return getColumnName(getIndexFromElementName(strElementName));
   }

   public static String getColumnName(
      int idx)
   {
      return (-1 == idx) ? null : TEMPLATE_COLUMNS[idx];
   }

   public static int getIndexFromElementName(
      String strElementName)
   {
      for(int i = 0; i < ELEMENT_NAMES.length; i++) {
         if(ELEMENT_NAMES[i].equals(strElementName)) {
            return i;
         }
      }
      return -1;
   }
*/
}
