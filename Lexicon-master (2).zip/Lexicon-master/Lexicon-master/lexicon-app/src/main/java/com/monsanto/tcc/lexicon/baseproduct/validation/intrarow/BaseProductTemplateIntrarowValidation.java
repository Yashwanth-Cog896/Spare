/*
 BaseProductTemplateRowValidation was created on Oct 8, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.validation.intrarow;

import com.monsanto.tcc.lexicon.baseproduct.excel.BaseProductTemplateRow;
import com.monsanto.tcc.lexicon.baseproduct.queryset.UploadBaseProductTemplateQuerySet;
import com.monsanto.tcc.lexicon.baseproduct.validation.AbstractBaseProductTemplateErrorCollector;
import com.monsanto.tcc.lexicon.baseproduct.validation.BaseProductTemplateRule;
import com.monsanto.tcc.lexiconcommon.file.excel.ExcelRow;

/**
 * nbwald Oct 8, 2007 2:49:48 PM
 */
public class BaseProductTemplateIntrarowValidation
        extends AbstractBaseProductTemplateErrorCollector {
    private final BaseProductTemplateRow row;
    private final UploadBaseProductTemplateQuerySet querySet;

    public BaseProductTemplateIntrarowValidation(ExcelRow excelRow, UploadBaseProductTemplateQuerySet querySet) {
        this.row = new BaseProductTemplateRow(excelRow);
        this.querySet = querySet;
    }

    protected BaseProductTemplateRule[] getRules() {
        return new BaseProductTemplateRule[]{
                new ValidBaseManufacturingNameRule(row.getBaseManufacturingName()),
                new ValidCropNameRule(querySet, row.getCropName()),
                new ValidParentFlagRule(row.getParentFlag()),
                new ExistingBaseProductsCropMatchesTemplateRule(querySet, row.getBaseManufacturingName(), row.getCropName()),
                new ExistingBaseProductsParentFlagMatchesTemplateRule(querySet, row.getBaseManufacturingName(), row.isParentProduct()),
                new BlendValidationRule(row.getCropName(), row.isBlend())
        };
    }

}