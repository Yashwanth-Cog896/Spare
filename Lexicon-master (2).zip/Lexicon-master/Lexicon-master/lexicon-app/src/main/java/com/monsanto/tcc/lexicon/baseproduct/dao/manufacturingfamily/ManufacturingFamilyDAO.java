package com.monsanto.tcc.lexicon.baseproduct.dao.manufacturingfamily;

import com.monsanto.tcc.lexiconcommon.service.manufacturingfamily.search.model.ManufacturingFamily;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * User: pjberry
 * Date: Aug 22, 2007
 * Time: 10:08:29 AM
 */
public interface ManufacturingFamilyDAO
{
   ManufacturingFamily[] findMatchingManufacturingFamilies(String[] names, String nameType)
      throws WrappingException;
}
