package com.monsanto.tcc.lexicon.businessdata;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Nov 12, 2004
 * Time: 10:38:08 AM
 * To change this template use File | Settings | File Templates.
 */
public interface CompProdSQL
{
   String CP_SELECT_BY_PUBKEY = "CompetitiveProduct.SelectByPublicKey";
   String CP_SELECT_BY_PROD_PUBKEY = "CompetitiveProduct.SelectByProdPublicKey";
   String CP_SELECT_BY_ALTKEYS = "CompetitiveProduct.SelectByAltKeys";
   String CP_SELECT_BY_NAME_CROP_BRAND = "CompetitiveProduct.SelectByNameCropBrand";
   String CP_SELECT_ALL = "CompetitiveProduct.SelectAll";

   String CP_NAME_ID_FROM_PUBKEY = "CompetitiveProduct.GetNameIdFromPubkey";
   String CP_PROD_ID_FROM_PUBKEY = "CompetitiveProduct.GetProdIdFromPubkey";

   String CP_INSERT_NAME       = "CompetitiveProduct.InsertProductName";
   String CP_INSERT_PROD       = "CompetitiveProduct.InsertProduct";
   String CP_UPDATE_NAME       = "CompetitiveProduct.UpdateProductName";
	String CP_SET_PRODUCT_LEVEL_UNDELETED = "CompetitiveProduct.SetProductLevelUndeleted";

   String PROD_PUBKEY_SEQ = "Product_Pubkey_Seq";
   String NAME_PUBKEY_SEQ = "Product_Name_PubKey_Seq";
   String PROD_ID_SEQ = "Unique_Product_Id_Seq";
   String NAME_ID_SEQ = "Unique_Product_Name_Id_Seq";
}
