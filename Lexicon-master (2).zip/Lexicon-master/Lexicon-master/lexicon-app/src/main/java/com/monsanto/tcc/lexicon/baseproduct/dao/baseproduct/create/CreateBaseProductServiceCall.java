/*
 CreateBaseProductServiceImpl was created on Jun 26, 2007 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.dao.baseproduct.create;

import com.monsanto.tcc.lexiconcommon.pos.LexiconServiceInvoker;
import com.monsanto.tcc.lexiconcommon.pos.ServiceInvoker;
import com.monsanto.tcc.lexiconcommon.pos.batch.BatchModelServiceCall;
import com.monsanto.tcc.lexiconcommon.service.baseproduct.CreateBaseProductRequest;
import com.monsanto.tcc.lexiconcommon.service.baseproduct.CreateBaseProductRequestSerializer;
import com.monsanto.tcc.lexiconcommon.service.baseproduct.CreateBaseProductResponse;
import com.monsanto.tcc.lexiconcommon.service.baseproduct.CreateBaseProductResponseSerializer;

/**
 * nbwald Jun 26, 2007 6:25:02 PM
 */
public class CreateBaseProductServiceCall
   extends BatchModelServiceCall<CreateBaseProductRequest, CreateBaseProductResponse>
   implements CreateBaseProduct
{
   protected CreateBaseProductRequestSerializer getRequestSerializer() {
      return new CreateBaseProductRequestSerializer();
   }
   protected ServiceInvoker getServiceInvoker() {
      return new LexiconServiceInvoker("Lex_CreateBaseProduct");
   }
   protected CreateBaseProductResponseSerializer getResponseSerializer() {
      return new CreateBaseProductResponseSerializer();
   }
}