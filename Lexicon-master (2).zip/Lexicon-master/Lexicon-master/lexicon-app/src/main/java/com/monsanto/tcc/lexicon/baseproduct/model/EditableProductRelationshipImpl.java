/*
 EditableProductRelationshipImpl was created on Jan 18, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.model;

import com.monsanto.tcc.lexiconcommon.ArrayUtils;
import com.monsanto.tcc.lexiconcommon.service.manufacturingline.edit.EditManufacturingLineResponse;

/**
 * nbwald Jan 18, 2008 2:54:26 PM
 */
public class EditableProductRelationshipImpl
   implements EditableProductRelationship
{
   private final BaseProductBean baseProduct;
   private final ProductRelationshipBean relationship;

   public EditableProductRelationshipImpl(BaseProductBean baseProduct, ProductRelationshipBean relationship) {
      this.baseProduct = baseProduct;
      this.relationship = relationship;
   }

   public String getTargetManufacturingName() {
      return relationship.getCommittedManufacturingName();
   }

   public String getNewManufacturingName() {
      return relationship.getManufacturingName();
   }

   public String getNewVarietyName() {
      return relationship.getVarietyName();
   }

   public boolean isEditable() {
      return relationship.isCommitable()
         && relationship.isEntityCommitted()
         && !baseProduct.isErred();
   }

   public void update(EditManufacturingLineResponse response) {
      String[] errors = response.getMessages();
      if(ArrayUtils.hasItems(errors)) {
         relationship.updateOnFailedEdit(errors);
      }
      else {
         relationship.updateOnSuccessfulEdit();
      }
   }
}