/*
 CreateBaseProductAction was created on Aug 2, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.action;

import com.monsanto.tcc.lexicon.baseproduct.action.locator.BaseProductBeanLocator;

/**
 * nbwald Aug 2, 2007 10:10:33 AM
 */
public class CreateBaseProductAction
   extends BeanLocatingBaseProductAction
{
   public static final String ACTION_NAME = "CreateBaseProductAction";
   
   public CreateBaseProductAction(BaseProductBeanLocator beanLocator) {
      super(beanLocator);
   }

   public String getActionName() {
      return ACTION_NAME;
   }

   public void handle() {
      getPageBean().createBaseProduct();
   }
}