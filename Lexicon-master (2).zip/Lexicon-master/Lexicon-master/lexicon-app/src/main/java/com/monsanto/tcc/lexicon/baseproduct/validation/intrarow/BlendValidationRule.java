package com.monsanto.tcc.lexicon.baseproduct.validation.intrarow;

import com.monsanto.tcc.lexicon.baseproduct.validation.BaseProductTemplateError;
import com.monsanto.tcc.lexicon.baseproduct.validation.BaseProductTemplateRule;
import com.monsanto.tcc.lexicon.baseproduct.validation.GetBlendWorkflowCrops;

import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: SKUMA
 * Date: 6/6/14
 * Time: 11:52 AM
 */
public class BlendValidationRule implements BaseProductTemplateRule {

    private final String cropName;
    private final boolean blend;
    private List<String> blendWorkflowCrops;

    public BlendValidationRule(String cropName, boolean blend) {
        this.cropName = cropName;
        this.blend = blend;
    }

    @Override
    public boolean violated() {
        GetBlendWorkflowCrops workflowCrops = new GetBlendWorkflowCrops();
        blendWorkflowCrops = workflowCrops.getBlendWorkflowCrops();
        return !blendWorkflowCrops.contains(cropName) && blend;
    }

    @Override
    public BaseProductTemplateError getViolation() {
        return BaseProductTemplateError.IS_BLEND_CANT_BE_TRUE;
    }
}
