package com.monsanto.tcc.lexicon.competitiveproduct.beans;


import com.monsanto.tcc.lexicon.competitiveproduct.repository.CompProdXmlRepositoryHeader;
import java.io.Serializable;
import java.text.SimpleDateFormat;

/**
 * Created by IntelliJ IDEA.
 * User: adcox
 * Date: Aug 27, 2004
 * Time: 9:10:47 AM
 * To change this template use File | Settings | File Templates.
 */
public class FileDisplayItem
   extends GridContainer
   implements Serializable
{
   public static final String ATTR_NAME = "FileDisplayItem";
   private static final SimpleDateFormat s_DateFormat = new SimpleDateFormat("MM/dd/yyyy");

   private String image;
   private String rowClass;
   private String deleteRow;
   private String deleteLink;
   private String excelLink;
   private boolean forcePosCall;
   private CompProdXmlRepositoryHeader repoHeader;

   public String getImage() {
      return image;
   }
   public void setImage(String image) {
      this.image = image;
   }

   public String getRowClass() {
      return rowClass;
   }
   public void setRowClass(String rowClass) {
      this.rowClass = rowClass;
   }

   public String getDeleteRow() {
      return deleteRow;
   }
   public void setDeleteRow(String deleteRow) {
      this.deleteRow = deleteRow;
   }

   public boolean isForcePosCall() {
      return forcePosCall;
   }
   public void setForcePosCall(boolean forcePosCall) {
      this.forcePosCall = forcePosCall;
   }

   public void setHeader(CompProdXmlRepositoryHeader header) {
      repoHeader = header;
   }
   public CompProdXmlRepositoryHeader getHeader() {
      return repoHeader;
   }

   public String getFileName() {
      return repoHeader.getName();
   }
   public String getTotal() {
      return Integer.toString(repoHeader.numTotal() - repoHeader.numAbandoned());
   }
   public String getAdded() {
      return Integer.toString(repoHeader.numCommitted());
   }
   public String getUnprocessed() {
      return Integer.toString(repoHeader.numUnprocessed() + repoHeader.numErrored() + repoHeader.numValidated());
   }
   public String getModifiedDate() {
      return s_DateFormat.format(repoHeader.getEntryDate());
   }

   public String getDeleteLink() {
      return deleteLink;
   }

   public void setDeleteLink(String deleteLink) {
      this.deleteLink = deleteLink;
   }

   public String getExcelLink() {
      return excelLink;
   }

   public void setExcelLink(String excelLink) {
      this.excelLink = excelLink;
   }

/*
   public void setModifiedDate(String modifiedDate) {
      this.modifiedDate = modifiedDate;
   }

   public void setModifiedDate(Date date) {
      modifiedDate = s_DateFormat.format(date);
   }
*/
}
