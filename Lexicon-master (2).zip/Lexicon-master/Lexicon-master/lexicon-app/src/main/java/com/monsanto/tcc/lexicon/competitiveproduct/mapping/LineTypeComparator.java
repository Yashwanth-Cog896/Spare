package com.monsanto.tcc.lexicon.competitiveproduct.mapping;

import com.monsanto.tcc.lexicon.competitiveproduct.mapping.RowObject;

/**
 * nbwald - Nov 12, 2009 1:26:12 PM
 */
public class LineTypeComparator
   extends StringMethodComparator
{
   @Override
   public String eval(RowObject rowObject) {
      return rowObject.getLineType();
   }
}
