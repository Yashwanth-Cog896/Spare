package com.monsanto.tcc.lexicon.competitiveproduct.mapping;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.lexicon.templates.type.RowStatusType;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: adcox
 * Date: Sep 7, 2004
 * Time: 11:24:30 AM
 * To change this template use File | Settings | File Templates.
 */
public class RowObjectListReader
   implements CompProdGridReader
{
   private RowObjectList _list;

   public RowObjectListReader(
      RowObjectList list)
   {
      _list = list;
   }

   public boolean requiresValidation() {
      return false;
   }

   public String validateTemplate() {
      return null;
   }


   /**
    * Returns the length of the corresponding row list + 1.  The +1 is added to
    * represent the first column of the display grid, which is the header column names.
    **/
   public int getNumRows() {
      return _list.size() + 1;
   }

   public int getCommittedCount() {
      return _list.getStatusCount(RowStatusType.COMMITTED);
   }

   public int getValidatedCount() {
      return _list.getStatusCount(RowStatusType.VALIDATED);
   }

   public int getUnprocessedCount() {
      return _list.getStatusCount(RowStatusType.UNPROCESSED);
   }

   public int getErrorCount() {
      return _list.getStatusCount(RowStatusType.ERRORED);
   }

   public int getAbandonedCount() {
      return _list.getStatusCount(RowStatusType.ABANDONED);
   }

   public int getExistingCount() {
      return _list.getStatusCount(RowStatusType.EXISTS);
   }

   private RowObject getRowObject(int iRowNum) {
      return (RowObject)_list.get(iRowNum -1);
   }

   public List getRowValues(
      int iRowNum)
      throws IOException
   {
      List listValues = null;

      if (0 == iRowNum) {
         //listValues = _list.getHeaderList();
         throw new RuntimeException("Not expecting headers to be called");
      }
      else {
         RowObject ro = getRowObject(iRowNum);
         try {
            listValues = buildValueList(ro, _list.getAttributeList());
         }
         catch (NoSuchMethodException e) {
            throw new IOException(e.getMessage());
         }
         catch (IllegalAccessException e) {
            throw new IOException(e.getMessage());
         }
         catch (InvocationTargetException e) {
            throw new IOException(e.getMessage());
         }
      }

      return listValues;
   }

   public String getRowStatus(int iRowNum) {
      RowObject ro = getRowObject(iRowNum);
      return ro.getStatus();
   }

   public int getRowID(int iRowNum) {
      RowObject ro = getRowObject(iRowNum);
      return ro.getRowNumber();
   }

   public boolean getCommitFlag(int iRowNum) {
      RowObject ro = getRowObject(iRowNum);
      return ro.isCommitFlag();
   }

   public String getPublicKey(int iRowNum) {
      RowObject ro = getRowObject(iRowNum);
      return ro.getPublicKey();
   }

   public String getProductPublicKey(int iRowNum) {
      RowObject ro = getRowObject(iRowNum);
      return ro.getProductPublicKey();
   }

   public boolean getActiveFlag(int iRowNum) {
      RowObject ro = getRowObject(iRowNum);
      return ro.isActive();
   }

   public boolean getEditingFlag(int iRowNum) {
      RowObject ro = getRowObject(iRowNum);
      return ro.isEditing();
   }

   public boolean getCopiedFlag(int iRowNum) {
      RowObject ro = getRowObject(iRowNum);
      return ro.isCopied();
   }

   public List getErrorStringList(int iRowNum)
   {
      RowObject ro = getRowObject(iRowNum);
      String errorString = ro.getErrors();

      if (!StringUtils.isNullOrEmpty(errorString)) {
         String[] errors = errorString.split(RowObjectList.ERROR_SEP + "\\*");
         if (errors.length > 0 && errors[0].length() > 0 && '*' == errors[0].charAt(0))
         {
            errors[0] = errors[0].substring(1);
         }
         return Arrays.asList(errors);
      }
      else {
         return null;
      }
   }

   public List getNoteStringList(int iRowNum)
   {
      RowObject ro = getRowObject(iRowNum);
      String notesString = ro.getNotes();

      if (!StringUtils.isNullOrEmpty(notesString)) {
         String[] notes = notesString.split(RowObjectList.ERROR_SEP + "\\d+\\)");
         if (notes.length > 0 && notes[0].length() > 2 &&
             notes[0].substring(0, 2).equals("1)"))
         {
            notes[0] = notes[0].substring(2);
         }
         return Arrays.asList(notes);
      }
      else {
         return null;
      }
   }

   private List buildValueList(
      RowObject ro,
      List headerList)
      throws NoSuchMethodException,
             IllegalAccessException,
             InvocationTargetException
   {
      List listValues = new ArrayList();

      for (int i = 0; i < headerList.size(); i++) {
         String propName = (String) headerList.get(i);
         String methodName = "get" + propName.substring(0, 1).toUpperCase() +
                                     propName.substring(1);

         Method meth = ro.getClass().getMethod(methodName, ((Class[])null));
         String value = (String) meth.invoke(ro, ((Object[])null));
         listValues.add(value);
      }

      return listValues;
   }
}
