package com.monsanto.tcc.lexicon.controllers;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.tcc.lexicon.LexiconServlet.LexiconUseCaseController;
import com.monsanto.tcc.lexicon.typedata.crop.CropByNameQuery;
import com.monsanto.tcc.lexicon.typedata.crop.CropDTO;
import com.monsanto.tcc.lexicon.utils.ucc.JSONResponseWriter;

import java.io.IOException;

/**
 * nbwald - Dec 23, 2009 5:12:43 PM
 */
public class IsVegetableCropUCC
   extends LexiconUseCaseController
{
   @Override
   public void doService(UCCHelper helper)
      throws Throwable
   {
      String cropName = helper.getRequestParameterValue("cropName");
      CropDTO crop = findCropByName(cropName);
      writeResponse(helper, isVegetable(crop));
   }

   private CropDTO findCropByName(String cropName) {
      CropByNameQuery query = new CropByNameQuery(cropName);
      return query.find();
   }

   private boolean isVegetable(CropDTO crop) {
      return crop != null && crop.isVegetable();
   }

   private void writeResponse(UCCHelper helper, boolean vegetable)
      throws IOException
   {
      JSONResponseWriter writer = new JSONResponseWriter();
      writer.write(helper, vegetable);
   }
}
