/*
 ExistingBaseProductsCropMatchesTemplateRule was created on Oct 22, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.validation.intrarow;

import com.monsanto.tcc.lexicon.baseproduct.queryset.model.BaseProduct;
import com.monsanto.tcc.lexicon.baseproduct.queryset.query.BaseProductByBaseNameQuery;
import com.monsanto.tcc.lexicon.baseproduct.validation.BaseProductTemplateError;
import com.monsanto.Util.StringUtils;

/**
 * nbwald Oct 22, 2007 11:02:31 AM
 */
public class ExistingBaseProductsCropMatchesTemplateRule
   extends ExistingBaseProductRule
{
   private final String templateCropName;

   public ExistingBaseProductsCropMatchesTemplateRule(BaseProductByBaseNameQuery baseProductQuery, String baseManfName, String templateCropName) {
      super(baseProductQuery, baseManfName);
      this.templateCropName = templateCropName;
   }

   protected boolean violated(BaseProduct existingBaseProduct) {
      return !cropsMatch(existingBaseProduct.getCropName(), templateCropName);
   }

   private boolean cropsMatch(String existingCropName, String templateCropName) {
      return StringUtils.areEqual(StringUtils.toUpperCaseNull(existingCropName), StringUtils.toUpperCaseNull(templateCropName));
   }

   public BaseProductTemplateError getViolation() {
      return BaseProductTemplateError.EXISTING_CROP_DIFF_THAN_TEMPLATES;
   }
}