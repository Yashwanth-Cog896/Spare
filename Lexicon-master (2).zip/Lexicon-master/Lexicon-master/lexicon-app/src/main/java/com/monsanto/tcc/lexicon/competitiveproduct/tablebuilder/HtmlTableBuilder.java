package com.monsanto.tcc.lexicon.competitiveproduct.tablebuilder;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.lexicon.LexiconServlet.LexiconPropertiesImpl;
import com.monsanto.tcc.lexicon.LexiconServlet.LexiconUseCaseController;
import com.monsanto.tcc.lexicon.competitiveproduct.beans.GridContainer;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.RowObject;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.RowObjectComparator;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.RowObjectList;
import com.monsanto.tcc.lexicon.templates.type.RowStatusType;
import com.monsanto.tcc.lexicon.utils.PropertyTool;
import com.monsanto.tcc.lexicon.utils.gui.HtmlCell;
import com.monsanto.tcc.lexicon.utils.gui.HtmlRow;
import com.monsanto.tcc.lexicon.utils.gui.HtmlTable;
import com.monsanto.tcc.lexicon.utils.gui.I_HtmlKeys;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Properties;

/**
 * Created by IntelliJ IDEA.
 * User: adcox
 * Date: Oct 19, 2004
 * Time: 10:21:48 AM
 * To change this template use File | Settings | File Templates.
 */
public class HtmlTableBuilder  {

   private static final String DOT_SORT_CODE   = ".SORT_CODE";

   public static final String ACTIVE      = "active";
   public static final String COMMIT      = "commit";
   public static final String STATUS      = "status";
   public static final String ROW_NUMBER  = "rowNumber";
   public static final String ERRORS      = "errors";

   private final CellDisplayOverrides overrides = new CellDisplayOverrides();

   public HtmlTableBuilder() {
      overrides.addDisplayMapping("isTDRestricted", "Yes", "No");
      overrides.addDisplayMapping("isTDRestricted", "No", "Yes");
   }

   public HtmlTable buildDisplayGrid(Comparator comparator,
                                     GridContainer bean,
                                     GridPropertyMatrix matrix,
                                     StringBuffer sbError,
                                     boolean bAllowDeleteLink,
                                     boolean bDisableRowOnCommit)
      throws IOException,
             NoSuchMethodException,
             IllegalAccessException,
           InvocationTargetException,
           WrappingException
   {

      RowObject ro = null;

      RowObjectList list = bean.getRowObjectList();
      if (comparator != null) {
         Collections.sort(list, comparator);
      }

      if (bean.isFixedRowNumbers()) {
         resetRowNumbers(list);
      }

      boolean isHidden;
      HtmlRow row = null;
      HtmlTable table = matrix.buildTableHeader();
      for (Iterator iter = list.iterator(); iter.hasNext(); ) {
         ro = (RowObject) iter.next();
         isHidden = (bean.isHideCommitted() && RowStatusType.COMMITTED.equals(ro.getStatus()));
         row = matrix.buildRow(ro, isHidden);
         table.add(row);
         if (!isHidden) {
            setGuiRowProperties(row, ro, bAllowDeleteLink, bDisableRowOnCommit);
         }
      }

      table.setSortColumn(bean.getSortByColumn(), bean.getSortType());

      bean.setGrid(table.toHtml().toString());

      if (sbError.length() > 0) {
         bean.setErrorMessage(sbError.toString());
      }

      return table;
   }

/*
   private void resetInputTypes(HtmlRow row) {
      for (Iterator iterator = row.iterator(); iterator.hasNext();) {
         HtmlCell cell = (HtmlCell) iterator.next();
         if (I_HtmlKeys.TYPE_SELECT.equals(cell.getInputType()) ||
             I_HtmlKeys.TYPE_TEXT.equals(cell.getInputType()))
         {
            cell.setInputType(null);
         }
      }

   }
*/

   private void resetRowNumbers(RowObjectList list)
   {
      RowObject ro;
      for (int i = 0; i < list.size(); i++) {
         ro = (RowObject)list.get(i);
         ro.setRowNumber(i);
      }
      list.updateMaps();
   }

   public Comparator getComparator(GridContainer bean, Properties props, StringBuffer sbError) {
      int sortCode = RowObjectComparator.SORT_BY_ROW_NUM;
      int sortType = RowObjectComparator.SORTED_ASC;

      String sortByColumn = bean.getSortByColumn();
      if (!StringUtils.isNullOrEmpty(sortByColumn)) {
         String value = PropertyTool.getProperty(props, sortByColumn + DOT_SORT_CODE, false);
         if (value == null) {
            sbError.append("Unexpected sort column: " + sortByColumn);
         }
         else {
            sortCode = Integer.parseInt(value);
            if (bean.getSortType() == I_HtmlKeys.SORTED_DESC) {
               sortType = RowObjectComparator.SORTED_DESC;
            }
         }
      }

      return new RowObjectComparator(sortCode, sortType);
   }

   private void setGuiRowProperties(HtmlRow row,
                                    RowObject ro,
                                    boolean bAllowDeleteLink, boolean bDisableRowOnCommit)
           throws NoSuchMethodException,
           IllegalAccessException,
           InvocationTargetException, IOException
   {
      // set input text value for each cell in form
      for (int i = 0; i < row.size(); i++) {
         HtmlCell cell = row.getCell(i);
         String name = cell.getName();

         setCellInputValue(name, ro, cell);
      }

      LexiconPropertiesImpl lexProps = new LexiconPropertiesImpl();

      // Determine class type (color) for this row
      String status = ro.getStatus();
      String[] astr = new String[1];
      HtmlCell cellStatus = row.getCell(STATUS);
      StatusImageTag sit = new StatusImageTag();
      if (RowStatusType.ERRORED.equals(status)) {
         astr[0] = lexProps.getProperty(LexiconUseCaseController.CLASS_REDBACK, true);
         row.setClasses(astr);
         cellStatus.setContent(sit.getImageTag(row.getRowNum(), ro, bAllowDeleteLink, true));
      }
      else if (RowStatusType.UNPROCESSED.equals(status)) {
         astr[0] = lexProps.getProperty(LexiconUseCaseController.CLASS_CYANBACK, true);
         row.setClasses(astr);
         cellStatus.setContent(sit.getImageTag(row.getRowNum(), ro, bAllowDeleteLink, false));
      }
      else if (RowStatusType.VALIDATED.equals(status)) {
         astr[0] = lexProps.getProperty(LexiconUseCaseController.CLASS_YELLOWBACK, true);
         row.setClasses(astr);
         HtmlCell cellCommit = row.getCell(COMMIT);
         if (cellCommit != null) {
            cellCommit.setInputType(HtmlCell.TYPE_CHECKBOX);
            cellCommit.setDisabled(false);
            cellCommit.setChecked(true);
         }
         //cellCommit.setContent(null);
         cellStatus.setContent(sit.getImageTag(row.getRowNum(), ro, bAllowDeleteLink, true));
      }
      else if (RowStatusType.ABANDONED.equals(status)) {
         astr[0] = lexProps.getProperty(LexiconUseCaseController.CLASS_GREYBACK, true);
         row.setClasses(astr);
         disableRow(row);
         cellStatus.setContent(sit.getImageTag(row.getRowNum(), ro, bAllowDeleteLink, false));
      }
      else if (RowStatusType.COMMITTED.equals(status)) {
         astr[0] = lexProps.getProperty(LexiconUseCaseController.CLASS_GREENBACK, false);
         row.setClasses(astr);
         if (bDisableRowOnCommit) {
            disableRow(row);
         }
         cellStatus.setContent(sit.getImageTag(row.getRowNum(), ro, bAllowDeleteLink, false));
      }
      else if (RowStatusType.EXISTS.equals(status)) {
         astr[0] = lexProps.getProperty(LexiconUseCaseController.CLASS_CLEARBACK, false);
         row.setClasses(astr);
         cellStatus.setContent(sit.getImageTag(row.getRowNum(), ro, bAllowDeleteLink, false));
      }
      else {
         throw new RuntimeException("Unexpected status: " + status);
      }
   }

   private void disableRow(HtmlRow row)
   {
      HtmlCell cell = row.getCell(COMMIT);
      if (cell != null) {
         if (HtmlCell.TYPE_CHECKBOX.equals(cell.getInputType())) {
            cell.setChecked(false);
         }
      }

      for (int i = 0; i < row.size(); i++) {
         cell = row.getCell(i);
         cell.setDisabled(true);
      }
   }

   private void setCellInputValue(
      String name,
      RowObject ro,
      HtmlCell cell)
      throws NoSuchMethodException,
             IllegalAccessException,
             InvocationTargetException
   {
      if (name.equals(COMMIT)) {
      }
      else if (name.equals(ACTIVE)) {
         cell.setChecked(ro.isActive());
      }
      else if (name.equals(ROW_NUMBER)) {
         cell.setContent(I_HtmlKeys.NBSP + Integer.toString(ro.getRowNumber()+1) + I_HtmlKeys.NBSP);
      }
      else if (name.equals(ERRORS)) {
         String comments = null;
         if (RowStatusType.VALIDATED.equals(ro.getStatus()) ||
             RowStatusType.COMMITTED.equals(ro.getStatus()))
         {
            //cell.setContent(ro.getNotes());
            comments = ro.getNotes();
         }
         else {
            //cell.setContent(ro.getErrors());
            comments = ro.getErrors();
         }
         cell.setContent(StringUtils.isNullOrEmpty(comments) ? I_HtmlKeys.NBSP : comments);
      }
      else {
         String method = "get" + name.substring(0,1).toUpperCase() +
                                 name.substring(1);

         Class[] acls = new Class[0];

         Method meth = ro.getClass().getMethod(method, acls);
         String value = (String) meth.invoke(ro, null);

         if (StringUtils.isNullOrEmpty(cell.getInputType())) {
            // initial content is set by defaul in properties file.  Only
            // fill cell content if not null or empty
            if (!StringUtils.isNullOrEmpty(value)) {
               cell.setContent(overrides.getCellDisplayValue(name, value));
            }
         }
         else {
            if (HtmlCell.TYPE_SELECT.equals(cell.getInputType())) {
               //cell.setSelectedDisplay(value);
               cell.setSelectedDisplayByValue(value);
            }
            else {
               cell.setInputValue(value);
            }
         }
      }
   }
}
