package com.monsanto.tcc.lexicon.eventregulation.query;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.lexicon.utils.audit.AuditInfo;

/**
 * nbwald - Feb 10, 2009 10:57:21 PM
 */
public interface EventRegulationAuditQuerySet
{
   String[] findEventRegulationPrimaryKeysByEventName(String eventName)
      throws WrappingException;

   AuditInfo findEventRegulationAuditInfoByPrimaryKey(String primaryKeyValue)
      throws WrappingException;
}
