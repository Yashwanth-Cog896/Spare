/*
 BaseProductDAO was created on Oct 19, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.queryset.query;

import com.monsanto.tcc.lexicon.baseproduct.queryset.model.BaseProduct;

/**
 * nbwald Oct 19, 2007 4:34:46 PM
 */
public interface BaseProductByBaseNameQuery
{
   BaseProduct getBaseProduct(String baseManufacturingName);
}