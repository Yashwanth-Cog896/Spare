/*
 ManufacturingFamiliesByBaseNamesQuery was created on Oct 24, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.queryset.query;

import com.monsanto.tcc.lexiconcommon.service.manufacturingfamily.search.model.ManufacturingFamily;

/**
 * nbwald Oct 24, 2007 1:54:28 PM
 */
public interface ManufacturingFamiliesByBaseNamesQuery
{
   ManufacturingFamily[] getManufacturingFamilies(String[] baseManfNames);
}