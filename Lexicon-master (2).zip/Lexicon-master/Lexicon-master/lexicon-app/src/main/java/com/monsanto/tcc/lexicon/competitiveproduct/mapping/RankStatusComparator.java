package com.monsanto.tcc.lexicon.competitiveproduct.mapping;

import com.monsanto.tcc.lexicon.competitiveproduct.mapping.RowObject;

import java.util.Comparator;

/**
 * nbwald - Nov 12, 2009 1:58:18 PM
 */
public class RankStatusComparator
   implements Comparator<RowObject>
{
   @Override
   public int compare(RowObject a, RowObject b) {
      return a.rankStatus() - b.rankStatus();
   }
}
