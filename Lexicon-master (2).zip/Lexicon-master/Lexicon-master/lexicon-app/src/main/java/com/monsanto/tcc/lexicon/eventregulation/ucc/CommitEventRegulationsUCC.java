package com.monsanto.tcc.lexicon.eventregulation.ucc;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.tcc.lexicon.LexiconServlet.SimpleLexiconUCC;
import com.monsanto.tcc.lexicon.eventregulation.view.EventRegulationsBean;

/**
 * nbwald - Feb 10, 2009 2:45:31 PM
 */
public class CommitEventRegulationsUCC
   extends SimpleLexiconUCC
{
   @Override
   protected void executeAction(UCCHelper helper)
      throws Exception
   {
      EventRegulationsBean eventRegulationsBean = (EventRegulationsBean) helper.getSessionParameter(EventRegulationsBean.NAME);
      eventRegulationsBean.syncValuesFromRequest(helper);
      eventRegulationsBean.commit();
   }
}
