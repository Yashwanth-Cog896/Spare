package com.monsanto.tcc.lexicon.competitiveproduct.mapping;

import com.monsanto.tcc.lexicon.competitiveproduct.mapping.RowObject;

import java.util.Comparator;

/**
 * nbwald - Nov 12, 2009 3:10:05 PM
 */
public class TwoStageProductPublicKeyComparator
   implements Comparator<RowObject>
{
   private final ProductPublicKeyComparator productPublicKeyComparator;
   private final PublicKeyComparator publicKeyComparator;

   public TwoStageProductPublicKeyComparator(ProductPublicKeyComparator productPublicKeyComparator, PublicKeyComparator publicKeyComparator) {
      this.productPublicKeyComparator = productPublicKeyComparator;
      this.publicKeyComparator = publicKeyComparator;
   }

   public TwoStageProductPublicKeyComparator() {
      this(new ProductPublicKeyComparator(), new PublicKeyComparator());
   }

   @Override
   public int compare(RowObject a, RowObject b) {
      int result = productPublicKeyComparator.compare(a, b);
      if(result == 0) {
         return publicKeyComparator.compare(a, b);
      }
      return result;
   }
}
