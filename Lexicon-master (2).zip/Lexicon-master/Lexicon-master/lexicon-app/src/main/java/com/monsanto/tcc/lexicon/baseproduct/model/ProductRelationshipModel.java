/*
 ProductRelationshipModel was created on Jan 23, 2008 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.model;

import com.monsanto.tcc.lexiconcommon.service.manufacturingfamily.search.model.ManufacturingLineLevelResponse;

/**
 * nbwald Jan 23, 2008 2:15:17 PM
 */
public class ProductRelationshipModel
{
   private String manufacturingName;
   private String varietyName;
   private boolean blend;

   public ProductRelationshipModel() {
   }

   public ProductRelationshipModel(String manufacturingName) {
      this(manufacturingName, null);
   }

   public ProductRelationshipModel(ManufacturingLineLevelResponse manufacturingLineLevel) {
      this(manufacturingLineLevel.getManufacturingName(), manufacturingLineLevel.getVarietyName(),manufacturingLineLevel.isBlendedProduct());
   }

   private ProductRelationshipModel(String manufacturingName, String varietyName) {
      this.manufacturingName = manufacturingName;
      this.varietyName = varietyName;
   }

    public ProductRelationshipModel(String manufacturingName, boolean blend) {
        this.manufacturingName = manufacturingName;
        this.blend = blend;
    }

    public ProductRelationshipModel(String manufacturingName, String varietyName, boolean blend) {
        this.manufacturingName = manufacturingName;
        this.varietyName = varietyName;
        this.blend = blend;
    }

    public ProductRelationshipModel copy() {
      return new ProductRelationshipModel(manufacturingName, varietyName, blend);
   }

   public String getManufacturingName() {
      return manufacturingName;
   }

   public void setManufacturingName(String manufacturingName) {
      this.manufacturingName = manufacturingName;
   }

   public String getVarietyName() {
      return varietyName;
   }

   public void setVarietyName(String varietyName) {
      this.varietyName = varietyName;
   }

    public boolean isBlend() {
        return blend;
    }

    public void setBlend(boolean blend) {
        this.blend = blend;
    }
}