/*
 InvalidTemplateException was created on Oct 8, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.validation;

/**
 * nbwald Oct 8, 2007 3:30:26 PM
 */
public class InvalidTemplateException
   extends Exception
{
   private final String[] messages;

   public InvalidTemplateException(BaseProductTemplateSheetMessages sheetMessages) {
      messages = sheetMessages.getMessageTexts();
   }

   public InvalidTemplateException(BaseProductTemplateError error) {
      this.messages = new String[] { error.toString() };
   }

   public String[] getMessages() {
      return messages;
   }
}