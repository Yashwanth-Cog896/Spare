package com.monsanto.tcc.lexicon.competitiveproduct.mapping;

import com.monsanto.tcc.lexicon.templates.dom.TemplateRowStatistics;
import com.monsanto.tcc.lexicon.templates.type.RowStatusType;
import com.monsanto.tcc.lexicon.utils.LogWriter;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.DOMUtil;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: adcox
 * Date: Sep 2, 2004
 * Time: 1:35:20 PM
 * To change this template use File | Settings | File Templates.
 */
public class RowObjectList
   extends ArrayList
   implements Cloneable
{
   public static final String ERROR_SEP = " \n";

   private Date _dateModified;
   private static List _lstAttribute = null;
   private HashMap _mapByRowNum = new HashMap();
   private HashMap _mapByPublicKey = new HashMap();
   private TemplateRowStatistics _stats = new TemplateRowStatistics();
   private CompProdXmlUtils _cpXmlUtil = new CompProdXmlUtils();

   public RowObjectList() {
   }

   public RowObjectList(
      Document doc)
      throws IllegalAccessException,
             NoSuchMethodException,
             InvocationTargetException,
             WrappingException
   {
      fillList(this, doc);
   }

   public RowObjectList buildList(
      Document doc)
      throws IllegalAccessException,
             NoSuchMethodException,
             InvocationTargetException,
             WrappingException
   {
      RowObjectList lst = new RowObjectList();
      fillList(lst, doc);
      return lst;
   }

   private void fillList(
      RowObjectList lst,
      Document doc)
      throws NoSuchMethodException,
             IllegalAccessException,
             InvocationTargetException,
             WrappingException
   {
      Element elemRoot = doc.getDocumentElement();
      if (elemRoot != null) {
         _dateModified = _cpXmlUtil.getEntryDate(doc);

         //boolean bAddedAttributes = false;
         NodeList nodes = _cpXmlUtil.getRowElements(doc);
         for (int i = 0; i < nodes.getLength(); i++) {
            Element elem = (Element) nodes.item(i);

            RowObject ro = new RowObject(
               _cpXmlUtil.getPublicKey(elem),
               _cpXmlUtil.getProductPublicKey(elem));

            ro.setRowNumber(_cpXmlUtil.getRownum(elem));
            ro.setActive(_cpXmlUtil.isActive(elem));
            ro.setEditing(_cpXmlUtil.isEditing(elem));
            ro.setCopied(_cpXmlUtil.isCopied(elem));

//            if (!bAddedAttributes) {
//               setAttributes(elem);
//               bAddedAttributes = true;
//            }
            setValueNodes(ro, elem);
            setStatusAndErrorNode(ro, elem);

            String status = ro.getStatus();
            lst.addStatusCount(status);
            lst.add(ro);
         }
      }
   }

//   private static void setAttributes(/* Element elemProduct */)
//   {
//      HashMap map = CompProdColDefs.getColumnNameMap();
//      NodeList nodes = elemProduct.getChildNodes();
//      for (int i = 0; i < nodes.getLength(); i++) {
//         Node node = nodes.item(i);
//         Integer index = (Integer) map.get(node.getNodeName());
//         if (index != null) {
//            _lstAttribute.add(CompProdColDefs.ELEMENT_NAMES[index.intValue()]);
//         }
//      }
//      for (int i = 0; i < CompProdColDefs.ELEMENT_NAMES.length; i++) {
//         _lstAttribute.add(CompProdColDefs.ELEMENT_NAMES[i]);
//      }
//   }

   private void addStatusCount(
      String status)
   {
      _stats.incrementStatusCount(status);
  }

   private void setValueNodes(
      RowObject ro,
      Element elemProduct)
      throws IllegalAccessException,
             NoSuchMethodException,
             InvocationTargetException
   {
      Logger log = LogWriter.getCategory(this);

      HashMap map = CompProdColDefs.getColumnNameMap();
      NodeList nodes = elemProduct.getChildNodes();
      for (int i = 0; i < nodes.getLength(); i++) {
         Node node = nodes.item(i);
         Integer index = (Integer) map.get(node.getNodeName());

         if (index != null) {
            setValueNode(ro, DOMUtil.getTextValue(node), CompProdColDefs.ELEMENT_NAMES[index.intValue()]);
         }
         else if (!(CompProdColDefs.STATUS_ELEM.equals(node.getNodeName()) ||
                    CompProdColDefs.AUDIT_INFO_ELEM.equals(node.getNodeName()) ||
                    CompProdColDefs.IS_TRANSG_ELEM.equals(node.getNodeName())))
         {
            log.warn("Ignored child node: " + node.getNodeName());
         }
      }
   }

   private void setValueNode(
      RowObject ro,
      String value,
      String elemName)
      throws NoSuchMethodException,
             IllegalAccessException,
             InvocationTargetException
   {
      String method = "set" + elemName;

      Class[] acls = new Class[1];
      acls[0] = String.class;

      Method meth = ro.getClass().getMethod(method, acls);
      Object[] aobj = new Object[1];
      //aobj[0] = value;
      aobj[0] = StringUtils.isNullOrEmpty(value) ? null : value;
      meth.invoke(ro, aobj);
   }


   private void setStatusAndErrorNode(
      RowObject ro,
      Element elemProduct)
   {
      String status = _cpXmlUtil.getStatusString(elemProduct);
      ro.setStatus(status);
      setErrorNode(ro, elemProduct);
      setNotesNode(ro, elemProduct);
   }

   private void setErrorNode(
      RowObject ro,
      Element elemProduct)
   {
      StringBuffer sb = new StringBuffer();

      Element elemError = null;
      NodeList errors = _cpXmlUtil.getErrorNodes(elemProduct);
      for (int i = 0; i < errors.getLength(); i++) {
         if (i > 0) {
            sb.append(ERROR_SEP);
         }
         elemError = (Element) errors.item(i);
         sb.append("*" + DOMUtil.getTextValue(elemError));
      }
      if (sb.length() > 0) {
         ro.setErrors(sb.toString());
      }
   }

   private void setNotesNode(
      RowObject ro,
      Element elemProduct)
   {
      StringBuffer sb = new StringBuffer();

      Element elemNote = null;
      NodeList notes = _cpXmlUtil.getNoteNodes(elemProduct);
      for (int i = 0; i < notes.getLength(); i++) {
         if (i > 0) {
            sb.append(ERROR_SEP);
         }
         elemNote = (Element) notes.item(i);
         sb.append("*" + DOMUtil.getTextValue(elemNote));
      }
      if (sb.length() > 0) {
         ro.setNotes(sb.toString());
      }
   }

   public int getStatusCount(RowStatusType status) {
      return _stats.getStatusCount(status);
   }

/*
   public int getStatusCount(String status) {
      return _stats.getStatusCount(status);
   }
*/

   public synchronized List getAttributeList() {
      if (_lstAttribute == null) {
         _lstAttribute = new ArrayList();
         for (int i = 0; i < CompProdColDefs.ELEMENT_NAMES.length; i++) {
            _lstAttribute.add(CompProdColDefs.ELEMENT_NAMES[i]);
         }
      }
      return _lstAttribute;
   }

   public Date getModifiedDate()
   {
      return _dateModified;
   }


   public Object clone() {
      RowObjectList list = new RowObjectList();
      if (_dateModified != null) {
         list._dateModified = new Date(_dateModified.getTime());
      }

//      Iterator iter = _lstAttribute.iterator();
//      while (iter.hasNext()) {
//         list._lstAttribute.add(iter.next().toString());
//      }

      list._stats = (TemplateRowStatistics)_stats.clone();

      Iterator iter = this.iterator();
      while (iter.hasNext()) {
         RowObject ro = (RowObject) iter.next();
         list.add(ro.clone());
      }


      return list;
   }

   public RowObject getByRowNum(int rownum) {
      RowObject ro = (RowObject) _mapByRowNum.get(new Integer(rownum));
      if (ro == null) {
         throw new RuntimeException("can't find RowObject by rownum: " + rownum);
      }

      return ro;
   }

   public void updateMaps()
   {
      _mapByRowNum.clear();
      _mapByPublicKey.clear();

      RowObject ro;
      for (int i = 0; i < size(); i++) {
         ro = (RowObject)get(i);
         updateMaps(ro);
      }
   }

   private void updateMaps(RowObject ro)
   {
      if (ro.getRowNumber() != RowObject.UNASSIGNED) {
         _mapByRowNum.put(new Integer(ro.getRowNumber()), ro);
      }

      String str = ro.getPublicKey();
      if (! StringUtils.isNullOrEmpty(str)) {
         _mapByPublicKey.put(str, ro);
      }
   }

   public void add(int i, RowObject ro) {
      super.add(i, ro);
      updateMaps(ro);
   }

   public boolean add(RowObject ro) {
      boolean b = super.add(ro);
      updateMaps(ro);
      return b;
   }

   public boolean add(Object o) {
      return add((RowObject) o);
   }

   public void add(int i, Object o) {
      add(i, (RowObject)o);
   }

   public void clear() {
      super.clear();
      _dateModified = null;
      //_lstAttribute.clear();
      _mapByRowNum.clear();
      _mapByPublicKey.clear();
   }

   public RowObject getByPublicKey(String publicKey) {
      RowObject ro = (RowObject) _mapByPublicKey.get(publicKey);
      if (ro == null) {
         throw new RuntimeException("can't find RowObject by public key: " + publicKey);
      }

      return ro;
   }
}
