/*
 CropNameValidatorImpl was created on Oct 8, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.queryset.query;

import com.monsanto.tcc.lexicon.productflow.query.AllCropsQuery;
import com.monsanto.tcc.lexicon.typedata.crop.CropDTO;

import java.util.Arrays;
import java.util.List;

/**
 * nbwald Oct 8, 2007 2:19:34 PM
 */
public class CropNameQueryImpl
   implements CropNameQuery
{
   private final List<CropDTO> crops;

   public CropNameQueryImpl() {
      this.crops = loadAllCrops();
   }

   private List<CropDTO> loadAllCrops() {
      AllCropsQuery query = new AllCropsQuery();
      return Arrays.asList(query.findAll());
   }

   public boolean isValid(String cropName) {
      for (CropDTO crop : crops) {
         if(crop.getName().equals(cropName)) {
            return true;
         }
      }
      return false;
   }
}