/*
 ValidParentFlagRule was created on Oct 8, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.validation.intrarow;

import com.monsanto.tcc.lexicon.baseproduct.validation.BaseProductTemplateError;
import com.monsanto.tcc.lexicon.baseproduct.validation.BaseProductTemplateRule;

/**
 * nbwald Oct 8, 2007 1:56:44 PM
 */
public class ValidParentFlagRule
   implements BaseProductTemplateRule
{
   private final String parentFlag;

   public ValidParentFlagRule(String parentFlag) {
      this.parentFlag = parentFlag;
   }

   public boolean violated() {
      return !validParentFlag();
   }

   private boolean validParentFlag() {
      return "YES".equalsIgnoreCase(parentFlag) || "NO".equalsIgnoreCase(parentFlag);
   }

   public BaseProductTemplateError getViolation() {
      return BaseProductTemplateError.INVALID_PARENT_FLAG;
   }
}