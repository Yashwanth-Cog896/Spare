package com.monsanto.tcc.lexicon.croproles;

import com.monsanto.tcc.lexicon.spring.ThreadLocalApplicationContext;
import com.monsanto.tps.lexicon.user.UserPrivilegesService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.context.WebApplicationContext;

/**
 * rrchak1 - Feb 25, 2009 4:36:41 PM
 */
public class CropAuthorizationImpl
   implements CropAuthorization
{
   private String[] authorizedCrops;

   public CropAuthorizationImpl(UserPrivilegesService userPrivilegesService, String userLoginId) {
      this.authorizedCrops = userPrivilegesService.getCrops(userLoginId);
   }

   public CropAuthorizationImpl(String userLoginId) {
      this(getUserPrivilegesService(), userLoginId);
   }

   private static UserPrivilegesService getUserPrivilegesService() {
      ApplicationContext context =  ThreadLocalApplicationContext.getApplicationContext();
      UserPrivilegesService userPrivilegesService = (UserPrivilegesService) context.getBean("userPrivilegesService");
      return userPrivilegesService;
   }

   public String[] getAuthorizedCrops() {
      return authorizedCrops;
   }

}
