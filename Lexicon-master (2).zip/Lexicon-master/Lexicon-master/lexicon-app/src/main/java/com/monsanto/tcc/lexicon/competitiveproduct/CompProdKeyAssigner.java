package com.monsanto.tcc.lexicon.competitiveproduct;

import com.monsanto.tcc.lexicon.businessdata.CompProdDAO;
import com.monsanto.tcc.lexicon.businessdata.CompProdDTO;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.CompProdXmlUtils;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.RowObject;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.RowObjectList;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.dataservices.PersistentStoreConnection;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Jan 24, 2005
 * Time: 9:57:56 AM
 * To change this template use File | Settings | File Templates.
 */
public class CompProdKeyAssigner
{
   private NodeList rows;
   private CompProdXmlUtils cpXmlUtil;
   
   public CompProdKeyAssigner(
      Document doc)
   {
      cpXmlUtil = new CompProdXmlUtils();
      rows = cpXmlUtil.getRowElements(doc);
   }
   
   public void assignKeys(
      PersistentStoreConnection conn)
      throws WrappingException
   {
      Element row;
      CompProdDAO dao = CompProdDAO.newInstance();
      for (int i = 0; i < rows.getLength(); i++) {
         row = (Element) rows.item(i);
         assignNameKey(row, dao, conn);
         assignProductKey(row, dao, conn);
      }
   }

   public void assignToStorageDoc(
      Document docStorage)
   {
      Element row, rowStorage;
      for (int i = 0; i < rows.getLength(); i++) {
         row = (Element) rows.item(i);
         rowStorage = cpXmlUtil.getRowElement(docStorage, cpXmlUtil.getRownum(row));
         cpXmlUtil.setPublicKey(rowStorage, cpXmlUtil.getPublicKey(row));
         cpXmlUtil.setProductPublicKey(rowStorage, cpXmlUtil.getProductPublicKey(row));
      }
   }

   private void assignNameKey(
      Element row,
      CompProdDAO dao,
      PersistentStoreConnection conn)
      throws WrappingException
   {
      String publicKey;
      publicKey = cpXmlUtil.getPublicKey(row);

      if (StringUtils.isNullOrEmpty(publicKey)) {
         publicKey = dao.newPublicKey(conn);
      }
      cpXmlUtil.setPublicKey(row, publicKey);
   }

   private void assignProductKey(
      Element row,
      CompProdDAO dao,
      PersistentStoreConnection conn)
      throws WrappingException
   {
      String publicKey;
      publicKey = findMatchInBatch(row);

      if (StringUtils.isNullOrEmpty(publicKey)) {
         publicKey = findExistingMatchingProduct(row, dao, conn);

         if (StringUtils.isNullOrEmpty(publicKey)) {
            publicKey = cpXmlUtil.getProductPublicKey(row);

            if (StringUtils.isNullOrEmpty(publicKey)) {
               publicKey = dao.newProductPublicKey(conn);
            }
         }
      }
      cpXmlUtil.setProductPublicKey(row, publicKey);
   }

   private String findMatchInBatch(
      Element row)
   {
      Element rowCompare;
      int currRowNum = -1;
      String productName, bayerCode, brandName;
      for(int i = 0; i < rows.getLength(); i++) {
         rowCompare = (Element) rows.item(i);
         currRowNum = cpXmlUtil.getRownum(rowCompare);
         if (currRowNum >= cpXmlUtil.getRownum(row)) {
            break;
         }

         productName = cpXmlUtil.getProductName(row);
         bayerCode = cpXmlUtil.getBayerCode(row);
         brandName = cpXmlUtil.getBrand(row);
         if (productName != null && productName.equals(cpXmlUtil.getProductName(rowCompare)) &&
             bayerCode != null && bayerCode.equals(cpXmlUtil.getBayerCode(rowCompare)) &&
             brandName != null && brandName.equals(cpXmlUtil.getBrand(rowCompare)))
         {
            return cpXmlUtil.getProductPublicKey(rowCompare);            
         }
      }
      return null;
   }
   
   private String findExistingMatchingProduct(
      Element row,
      CompProdDAO dao,
      PersistentStoreConnection conn)
      throws WrappingException
   {
      List listMatching = dao.loadByProductLevel(
         conn, cpXmlUtil.getProductName(row), cpXmlUtil.getBayerCode(row), cpXmlUtil.getBrand(row));

      return (listMatching != null && listMatching.size() > 0) ?
         ((CompProdDTO)listMatching.get(0)).getProductPublicKey() : null;
   }

   public void assignToRowObjectList(RowObjectList rowObjectList) 
   {
      Element rowXml;
      for (int i = 0; i < rows.getLength(); i++) {
         rowXml = (Element) rows.item(i);
         RowObject ro = rowObjectList.getByRowNum(cpXmlUtil.getRownum(rowXml));
         String newPubKey = cpXmlUtil.getPublicKey(rowXml);
         if (StringUtils.isNullOrEmpty(ro.getPublicKey())) {
            ro.setPublicKey(newPubKey);
         }
         else {
            if (! ro.getPublicKey().equals(newPubKey)) {
               throw new RuntimeException("ASSERTION: old and new public keys don't match: " + ro.getPublicKey() + ":" + newPubKey);
            }
         }


         String newProdPubKey = cpXmlUtil.getProductPublicKey(rowXml);
         if (StringUtils.isNullOrEmpty(ro.getProductPublicKey())) {
            ro.setProductPublicKey(newProdPubKey);
         }
         else {
            if (! ro.getProductPublicKey().equals(newProdPubKey)) {
               throw new RuntimeException("ASSERTION: old and new product public keys don't match: " + ro.getProductPublicKey() + ":" + newProdPubKey);               
            }
         }
      }
   }
}
