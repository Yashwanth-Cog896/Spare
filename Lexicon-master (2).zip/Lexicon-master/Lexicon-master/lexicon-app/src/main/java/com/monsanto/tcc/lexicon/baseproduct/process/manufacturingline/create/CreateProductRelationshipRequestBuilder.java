/*
 CreateProductRelationshipRequestBuilder was created on Aug 7, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.process.manufacturingline.create;

import com.monsanto.tcc.lexicon.baseproduct.model.CreateableProductRelationship;
import com.monsanto.tcc.lexiconcommon.pos.batch.ServiceRequestBuilder;
import com.monsanto.tcc.lexiconcommon.service.productrelationship.create.CreateProductRelationshipRequest;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald Aug 7, 2007 2:43:40 PM
 */
public class CreateProductRelationshipRequestBuilder
   implements ServiceRequestBuilder<CreateableProductRelationship, CreateProductRelationshipRequest>
{
   public CreateProductRelationshipRequest buildRequest(CreateableProductRelationship inputModel)
      throws WrappingException
   {
      return new CreateProductRelationshipRequest(inputModel.getBaseManufacturingName(), inputModel.getManufacturingName(), inputModel.isBlend());
   }
}