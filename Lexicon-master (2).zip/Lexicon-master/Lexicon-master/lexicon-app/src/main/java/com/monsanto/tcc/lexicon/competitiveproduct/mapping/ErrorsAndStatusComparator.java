package com.monsanto.tcc.lexicon.competitiveproduct.mapping;

import com.monsanto.tcc.lexicon.competitiveproduct.mapping.RowObject;
import com.monsanto.Util.StringUtils;

import java.util.Comparator;

/**
 * nbwald - Nov 12, 2009 2:37:38 PM
 */
public class ErrorsAndStatusComparator
   implements Comparator<RowObject>
{
   private final ErrorsComparator errorsComparator;
   private final RankStatusComparator rankStatusComparator;

   public ErrorsAndStatusComparator(ErrorsComparator errorsComparator, RankStatusComparator rankStatusComparator) {
      this.errorsComparator = errorsComparator;
      this.rankStatusComparator = rankStatusComparator;
   }

   public ErrorsAndStatusComparator() {
      this(new ErrorsComparator(), new RankStatusComparator());
   }

   @Override
   public int compare(RowObject a, RowObject b) {
      return StringUtils.isNullOrEmpty(a.getErrors()) || StringUtils.isNullOrEmpty(b.getErrors()) ?
         rankStatusComparator.compare(a, b) :
         errorsComparator.compare(a, b);
   }
}
