package com.monsanto.tcc.lexicon.businessdata;


/**
 * Created by IntelliJ IDEA.
 * User: adcox
 * Date: Oct 26, 2004
 * Time: 2:54:00 PM
 * To change this template use File | Settings | File Templates.
 */
public class CompProdDTOImpl
   implements CompProdDTO
{
   private String publicKey;
   private String productPublicKey;
   private boolean active;
   private String bayerCode;
   private String productName;
   private String brandName;
   private String countryName;
   private String commercialMaturity;
   private String characteristicTraits;
   private String traitAttributes;
   private String sourceVerified;
   private String sourceYear;
   private String comments;
   private boolean deleted;

   public String getPublicKey() {
      return publicKey;
   }
   public void setPublicKey(String publicKey) {
      this.publicKey = publicKey;
   }

   public String getProductPublicKey() {
      return productPublicKey;
   }
   public void setProductPublicKey(String publicKey) {
      this.productPublicKey = publicKey;
   }

   public boolean isActive() {
      return active;
   }
   protected void setActive(boolean active) {
      this.active = active;
   }

   public boolean isDeleted() {
      return deleted;
   }
   public void setLogicalDelete(boolean deleted) {
      this.deleted = deleted;
   }

   public String getBayerCode() {
      return bayerCode;
   }
   protected void setBayerCode(String bayerCode) {
      this.bayerCode = bayerCode;
   }

   public String getProductName() {
      return productName;
   }
   protected void setProductName(String productName) {
      this.productName = productName;
   }

   public String getBrandName() {
      return brandName;
   }
   protected void setBrandName(String brandName) {
      this.brandName = brandName;
   }

   public String getCountryName() {
      return countryName;
   }
   protected void setCountryName(String countryName) {
      this.countryName = countryName;
   }

   public String getCommercialMaturity() {
      return commercialMaturity;
   }
   protected void setCommercialMaturity(String commercialMaturity) {
      this.commercialMaturity = commercialMaturity;
   }

   public String getCharacteristicTraits() {
      return characteristicTraits;
   }
   protected void setCharacteristicTraits(String characteristicTraits) {
      this.characteristicTraits = characteristicTraits;
   }

   public String getTraitAttributes() {
      return traitAttributes;
   }
   protected void setTraitAttributes(String traitAttributes) {
      this.traitAttributes = traitAttributes;
   }

   public String getSourceVerified() {
      return sourceVerified;
   }
   protected void setSourceVerified(String sourceVerified) {
      this.sourceVerified = sourceVerified;
   }

   public String getSourceYear() {
      return sourceYear;
   }
   protected void setSourceYear(String sourceYear) {
      this.sourceYear = sourceYear;
   }

   public String getComments() {
      return comments;
   }
   protected void setComments(String comments) {
      this.comments = comments;
   } 
}
