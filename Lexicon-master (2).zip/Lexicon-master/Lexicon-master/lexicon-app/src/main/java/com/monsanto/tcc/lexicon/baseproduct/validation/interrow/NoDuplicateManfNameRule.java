/*
 NoDuplicateManfNameRule was created on Oct 11, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexicon.baseproduct.validation.interrow;

import com.monsanto.tcc.lexicon.baseproduct.excel.BaseProductTemplateRow;
import com.monsanto.tcc.lexicon.baseproduct.validation.BaseProductTemplateError;
import com.monsanto.tcc.lexicon.baseproduct.validation.BaseProductTemplateRule;
import com.monsanto.Util.StringUtils;

/**
 * nbwald Oct 11, 2007 3:46:43 PM
 */
public class NoDuplicateManfNameRule
   implements BaseProductTemplateRule
{
   private final BaseProductTemplateRow rowA;
   private final BaseProductTemplateRow rowB;

   public NoDuplicateManfNameRule(BaseProductTemplateRow rowA, BaseProductTemplateRow rowB) {
      this.rowA = rowA;
      this.rowB = rowB;
   }

   public boolean violated() {
      return notDuplicateRow() && manfNamesAreSame() && manfNamesAreNotEmpty();
   }

   private boolean notDuplicateRow() {
      return !rowA.equals(rowB);
   }

   private boolean manfNamesAreSame() {
      return StringUtils.areEqual(rowA.getManufacturingName(), rowB.getManufacturingName());
   }

   private boolean manfNamesAreNotEmpty() {
      return !StringUtils.isNullOrEmpty(rowA.getManufacturingName());
   }

   public BaseProductTemplateError getViolation() {
      return BaseProductTemplateError.DUPLICATE_MANF_NAME;
   }
}