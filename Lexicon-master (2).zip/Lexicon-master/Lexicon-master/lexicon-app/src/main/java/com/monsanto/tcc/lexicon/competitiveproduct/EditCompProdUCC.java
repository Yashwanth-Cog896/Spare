package com.monsanto.tcc.lexicon.competitiveproduct;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.tcc.lexicon.LexiconServlet.beans.ToolBar;
import com.monsanto.tcc.lexicon.applicationroles.AppRoles;
import com.monsanto.tcc.lexicon.businessdata.CompProdDAOType;
import com.monsanto.tcc.lexicon.competitiveproduct.beans.CompProdQuery;
import com.monsanto.tcc.lexicon.competitiveproduct.beans.GridContainer;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.RowObject;
import com.monsanto.tcc.lexicon.competitiveproduct.mapping.RowObjectList;
import com.monsanto.tcc.lexicon.competitiveproduct.tablebuilder.GridPropertyMatrix;
import com.monsanto.tcc.lexicon.competitiveproduct.tablebuilder.HtmlTableBuilder;
import com.monsanto.tcc.lexicon.controllers.HtmlTableLoader;
import com.monsanto.tcc.lexicon.templates.type.RowStatusType;
import com.monsanto.tcc.lexicon.utils.LogWriter;
import com.monsanto.tcc.lexicon.utils.PropertyTool;
import com.monsanto.tcc.lexicon.utils.audit.AuditConstants;
import com.monsanto.tcc.lexicon.utils.gui.HtmlCell;
import com.monsanto.tcc.lexicon.utils.gui.HtmlRow;
import com.monsanto.tcc.lexicon.utils.gui.HtmlTable;
import com.monsanto.tcc.lexiconcommon.user.LexSecureUser;
import com.monsanto.tcc.lexiconcommon.user.LexSecureUserHelperImpl;
import org.apache.regexp.RE;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import javax.xml.transform.TransformerException;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Properties;

/**
 * Created by IntelliJ IDEA.
 * User: adcox
 * Date: Oct 13, 2004
 * Time: 9:34:26 AM
 */
public class EditCompProdUCC
   extends CompProdGridBaseController
   implements HtmlTableLoader,
              CompProdDAOType,
              AuditConstants
{
   public static final String PROP_FILENAME_QUERY           = "EditCompProdGrid_Query.properties";
   public static final String PROP_FILENAME_EDITABLE        = "EditCompProdGrid_Editable.properties";
   private static final String PROP_FILENAME_EDIT_READ_ONLY = "EditCompProdGrid_EditReadOnly.properties";;
   private static final String PROP_FILENAME_COPY_READ_ONLY = "EditCompProdGrid_CopyReadOnly.properties";
   private static final String PROP_FILENAME_COPY_EDITABLE  = "EditCompProdGrid_CopyEditable.properties";
   private static final String PROP_FILENAME_COPY_COPY      = "EditCompProdGrid_CopyCopyable.properties";

   private static final String TABLE_ID     = "edit_competitive_product";
   public static final String SUBMIT_NAME   = "submitBtn";
   public static final String RESET_ROWS    = "resetRows";
   public static final String FROM_SRC_JSP = "fromSrcJsp";
   private static final String ROLE_PROP_FILENAME    = "EditCompProdRoles.properties";
   private static final String TS_RESPONSE_BACK_FROM = "ts: response back from ";

   public void doService(UCCHelper helper)
           throws IOException, TransformerException, SAXException
   {
      _log.info("ts: enter EditCompProdUCC.doService()");

      CompProdQuery bean = getSessionBean(helper);
      StringBuffer sb = new StringBuffer();

      LexSecureUser user = new LexSecureUserHelperImpl(helper);
      String successForward = getSuccessForward();
       try {
          updateBeanFromRequest(helper, bean);

          successForward = performAction(helper, bean, sb, user, successForward);

          buildGrid(helper, sb);
      }
      catch (WrappingException e) {
          LogWriter.logWrappingException(_log, e);
         sb.append(e.getMessage());
      }
      catch (Exception e) {
         _log.error(e.getMessage(), e);
         String msg = e.getMessage();
         sb.append(StringUtils.isNullOrEmpty(msg) ? "Null Pointer Exception" : e.getMessage());
      }

      //sb.append("post submit val: " + bean.getSubmitBtn() + "<BR>");
      if (sb.length() > 0) {
         //int lastChar = Math.min(200, sb.length());
         //bean.setErrorMessage("Error: " + sb.toString().substring(0, lastChar));
         bean.setErrorMessage("Error: " + sb.toString());
      }

      _log.info("ts: exit EditCompProdUCC.doService()");

      helper.forward(successForward);

   }

   private String performAction(UCCHelper helper, CompProdQuery bean, StringBuffer sb, LexSecureUser user, String successForward)
      throws Exception
   {
      if (ToolBar.VALIDATE_SUBMIT.equals(bean.getSubmitBtn())) {
         _log.info("ts:  validate hit");
         callMidasPosAndSave("Dont Save", user, bean, false, false);
      }
      else if(ToolBar.COMMIT_SUBMIT.equals(bean.getSubmitBtn())) {
         callMidasPosAndSave("Dont Save", user, bean, false, true);
      }
      else if (ToolBar.RESET_SUBMIT.equals(bean.getSubmitBtn())) {
         resetRows(bean, sb, true);
      }
      else if (ToolBar.COPY_SUBMIT.equals(bean.getSubmitBtn())) {
         copyRows(bean, sb);
      }
      else if (ToolBar.EDIT_SUBMIT.equals(bean.getSubmitBtn())) {
         setRowsForEdit(bean, sb);
      }
      else if (ToolBar.AUDIT_SUBMIT.equals(bean.getSubmitBtn())) {
         CompProdAuditHandler handler = new CompProdAuditHandler();
         handler.handleAudit(helper, bean);
         successForward = AuditConstants.AUDIT_FORWARD;
      }
      else if (! StringUtils.isNullOrEmpty(bean.getSubmitBtn())) {
         sb.append("Unhandled submit:");
         sb.append(bean.getSubmitBtn());
         _log.error("Unhandled submit:" + bean.getSubmitBtn());
      }
      return successForward;
   }

   private void updateBeanFromRequest(UCCHelper helper, CompProdQuery bean)
      throws IOException, NoSuchMethodException, IllegalAccessException, InvocationTargetException
   {
      bean.setErrorMessage(null);

      bean.toggleSortRequest(helper.getRequestParameterValue(CompProdGridBaseController.SORT_COLUMN),
                                 helper.getRequestParameterValue(CompProdGridBaseController.REQUEST_SORT));

      bean.setRowSelection(helper.getRequestParameterValue(RESET_ROWS));

      bean.setSubmitBtn(helper.getRequestParameterValue(SUBMIT_NAME));

      bean.setFromSrcJsp(false);
      if (helper.getRequestParameterValue(FROM_SRC_JSP) != null) {
             bean.setFromSrcJsp(true);
          }
      if (bean.isFromSrcJsp()) {
//            _log.debug("adc: calling updateList" );
        updateListFromRequest(bean.getRowObjectList(), helper, true);
     }
//         else {
//            _log.debug("adc: NOT calling updateList" );
//         }
   }

   protected void setRowsForEdit(CompProdQuery bean, StringBuffer sbError) {
      List listIndex = getSelectionListReverseOrder(bean.getRowSelection());
      if (listIndex.isEmpty()) {
         sbError.append("You must select a row to edit.");
      }
      else {
         RowObjectList listSrc = bean.getRowObjectList();
         for (int i = 0; i < listIndex.size(); i++) {
            int indexSrc = ((Integer)listIndex.get(i)).intValue();
            RowObject roSrc = (RowObject) listSrc.get(indexSrc);
            // Editing a 'copied' row leaves it as 'copied'
            if (! roSrc.isCopied()) {
               roSrc.setEditing(true);
            }
            roSrc.setStatus(RowStatusType.UNPROCESSED);
         }
      }
   }

   private List getSelectionListReverseOrder(String rowSelection) {
      List listIndex = new ArrayList();
      String[] astr = StringUtils.splitCsv(rowSelection, false);
      if (astr.length > 0) {
         for (int i = 0; i < astr.length; i++) {
            listIndex.add( Integer.valueOf(astr[i]));
         }
         Collections.sort(listIndex, Collections.reverseOrder());
      }

      return listIndex;
   }

   public CompProdQuery getSessionBean(UCCHelper helper) {
      CompProdQuery bean = (CompProdQuery) helper.getSessionParameter(CompProdQuery.NAME);
      if (bean == null) {
         //_log.debug("ECP: bean was null");
         bean = newCompProdQuery();
         helper.setSessionParameter(CompProdQuery.NAME, bean);
      }
      return bean;
   }

   private CompProdQuery newCompProdQuery() {
      CompProdQuery bean = new CompProdQuery();
      bean.setFixedRowNumbers(true);
      return bean;
   }

   public HtmlTable buildGrid(UCCHelper helper, StringBuffer sbError) throws IOException {
      HtmlTable table = null;
      try {
         CompProdQuery bean = getSessionBean(helper);
         if (bean.getRowObjectList() != null) {
            Properties propsReadOnly = PropertyTool.loadProperties(EditCompProdUCC.class, PROP_FILENAME_QUERY);

            HtmlTableBuilder builder = new HtmlTableBuilder();
            Comparator comparator = builder.getComparator(bean, propsReadOnly, sbError);
            GridPropertyMatrix matrix = buildGridPropertyMatrix(bean.getRowObjectList());
            table = builder.buildDisplayGrid(comparator, bean, matrix, sbError, false, true);
         }
      }
      catch (WrappingException e) {
         sbError.append(e.getMessage());
         LogWriter.logWrappingException(_log, e);
      }
      catch (Exception e) {
         sbError.append(e.getMessage());
         _log.error(e.getMessage(), e);
      }

      return table;

   }

   protected GridPropertyMatrix buildGridPropertyMatrix(RowObjectList list) throws IOException {
      return new GridPropertyMatrix(
              list,
              PropertyTool.loadProperties(EditCompProdUCC.class, PROP_FILENAME_QUERY),
              PropertyTool.loadProperties(EditCompProdUCC.class, PROP_FILENAME_EDITABLE),
              PropertyTool.loadProperties(EditCompProdUCC.class, PROP_FILENAME_EDIT_READ_ONLY),
              PropertyTool.loadProperties(EditCompProdUCC.class, PROP_FILENAME_COPY_READ_ONLY),
              PropertyTool.loadProperties(EditCompProdUCC.class, PROP_FILENAME_COPY_EDITABLE),
              PropertyTool.loadProperties(EditCompProdUCC.class, PROP_FILENAME_COPY_COPY));
   }

   public ToolBar getToolBar(UCCHelper helper) {
      ToolBar tb = new ToolBar();

      tb.setNestedFormName("SubmitChanges");
      tb.setNestedInputName(SUBMIT_NAME);

      AppRoles appRolesBean = null;
      try {
         appRolesBean = loadUserAppRoles(helper);
      } catch (Exception e) {
         _log.error(e.getMessage(), e);
         throw new RuntimeException(e.getMessage(),e);
      }

      if (appRolesBean != null && appRolesBean.isUserInAppRole(AppRoles.ROLE_CP_EDIT)) {
         tb.setValidateDisabled(false);
         tb.setCommitDisabled(false);
         tb.setResetRowDisabled(false);
         tb.setCopyDisabled(false);
         tb.setEditDisabled(false);
      }

      tb.setExcelDisabled(false);
      tb.setExcelId(getId());
      tb.setSeparatorDisabled(false);
      tb.setAuditDisabled(false);

      return tb;
   }

   public HtmlTable getTable(UCCHelper helper)
      throws IOException
   {
      HtmlTable table = new HtmlTable();

      StringBuffer sb = new StringBuffer();
      table = buildGrid(helper, sb);

      if (table != null) {
         table.stripNBSP();

         RE re = new RE("TITLE=\"(.*?)\"");

         // Extract title from status column
         for (int r = 0; r < table.size(); r++) {
            HtmlRow row = table.getRow(r);
            HtmlCell cell = row.getCell(HtmlTableBuilder.STATUS);

            String content = cell.getContent();
            if (re.match(content)) {
               cell.setContent(getContentAfterSpace(re));
            }
         }
      }

      return table == null ? new HtmlTable() : table;
   }

   private String getContentAfterSpace(RE re) {
      String content;
      content = re.getParen(1);
      int i = content.indexOf(" ");
      if (i > 0) {
         content = content.substring(0, i);
      }
      return content;
   }

   public String getId() {
      return TABLE_ID;
   }

   protected void copyRows(
      CompProdQuery bean,
      StringBuffer sbError)
   {
      List listIndex = getSelectionListReverseOrder(bean.getRowSelection());
      if (listIndex.isEmpty()) {
         sbError.append("You must select a row to copy.");
      }
      else {
         RowObjectList listSrc = bean.getRowObjectList();
         for (int i = 0; i < listIndex.size(); i++) {
            int indexSrc = ((Integer)listIndex.get(i)).intValue();
            RowObject roSrc = (RowObject) listSrc.get(indexSrc);
            RowObject roDst = (RowObject) roSrc.clone();
            roDst.setPublicKey(null);
            roDst.setProductPublicKey(null);
//            roDst.setRowNumber(++iRowNumberCounter);
            roDst.setCopied(true);
            roDst.setEditing(false);
            roDst.setCommitFlag(false);
            roDst.setStatus(RowStatusType.UNPROCESSED);
            listSrc.add(indexSrc+1, roDst);
         }

         //new HtmlTableBuilder().resetRowNumbers(listSrc);
      }
   }


   protected Document[] getResponseDocsFromMidas(
           PersistentStoreConnection conn,
           TemplateDOMBuilder builder,
           Document docStorage,
           GridContainer bean,
           boolean bSendCommits)
      throws IOException, WrappingException

   {
      Document[] responseDocs = new Document[2];

      CompProdValidator validator = new CompProdValidator();
      _log.info("ts: calling services...");
      if (bSendCommits) {
         validator.validateCommitsAndSetStatus(docStorage, conn);
         Document commitAdds = builder.buildRequestDocument(docStorage, conn, TemplateDOMBuilder.ADD_BY_COPY_FLAG, false);

         assignKeys(commitAdds, conn, docStorage, bean);

         responseDocs[0] = callPOS(commitAdds, ADD_COMMIT_POSNAME);
         if (responseDocs[0] != null) {
            _log.info(TS_RESPONSE_BACK_FROM + ADD_COMMIT_POSNAME);
         }

         Document commitUpdates = builder.buildRequestDocument(docStorage, conn, TemplateDOMBuilder.UPDATE_BY_EDIT_FLAG, false);
         responseDocs[1] = callPOS(commitUpdates, UPDATE_COMMIT_POSNAME);
         if (responseDocs[1] != null) {
            _log.info(TS_RESPONSE_BACK_FROM + UPDATE_COMMIT_POSNAME);
         }
      }
      else {
         validator.validateAndSetStatus(docStorage, conn);
         Document validateAdds = builder.buildRequestDocument(docStorage, conn, TemplateDOMBuilder.ADD_BY_COPY_FLAG, true);
         //_log.info("ts: request xml: " + DOMUtil.dumpToString(validateAdds));
         responseDocs[0] = callPOS(validateAdds, ADD_VALIDATE_POSNAME);
         if (responseDocs[0] != null) {
            _log.info(TS_RESPONSE_BACK_FROM + ADD_VALIDATE_POSNAME);
         }

         generateATComment(bean, "TEST1", validateAdds);
         Document validateUpdates = builder.buildRequestDocument(docStorage, conn, TemplateDOMBuilder.UPDATE_BY_EDIT_FLAG, true);
         responseDocs[1] = callPOS(validateUpdates, UPDATE_VALIDATE_POSNAME);
         if (responseDocs[1] != null) {
            _log.info(TS_RESPONSE_BACK_FROM + UPDATE_VALIDATE_POSNAME);
         }
      }

      return responseDocs;
   }

   private boolean isFirstPass(String submitBtn) {
      if (submitBtn == null) {
         return true;
      }
      return false;
   }

   private boolean isSortRequest(UCCHelper helper)
      throws IOException
   {
      if( helper.getRequestParameterValue(CompProdGridBaseController.REQUEST_SORT) != null &&
              !helper.getRequestParameterValue(CompProdGridBaseController.SORT_COLUMN).equals("") )
      {
         return true;
      }
      return false;
   }

   public boolean isValidRequest(
      UCCHelper helper)
      throws WrappingException, IOException

   {
      // Make sure we're at least in read only role
      AppRoles appRolesBean = loadUserAppRoles(helper);
      if (!appRolesBean.isUserInAppRole(AppRoles.ROLE_CP_ACCESS)) {
         return false;
      }

      String submitBtn = helper.getRequestParameterValue(SUBMIT_NAME);
      if ( isFirstPass(submitBtn) || isSortRequest(helper) || submitBtn.equals(ToolBar.AUDIT_SUBMIT)) {
         return true;
      }

      Properties roleProps = PropertyTool.loadProperties(EditCompProdUCC.class, ROLE_PROP_FILENAME);
      String requiredAppRole = roleProps.getProperty(submitBtn);

      return appRolesBean.isUserInAppRole(requiredAppRole);
   }
}
