package com.monsanto.tcc.lexicon.controllers;

import org.apache.regexp.RE;
import org.apache.regexp.RESyntaxException;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Feb 23, 2005
 * Time: 4:19:39 PM
 * To change this template use File | Settings | File Templates.
 */
public class LogContent
{
   private File file;
   private ArrayList linePointers;

   public LogContent(File file)
       throws IOException
   {
       this.file = file;
       linePointers = new ArrayList();
       determineLinePointers();
   }

   private void determineLinePointers()
       throws IOException
   {
       int ch;
       long currPointer = 0;
       boolean isReadingLine = false;
       BufferedReader br = new BufferedReader(new FileReader(file));
       try {
           while (-1 != (ch = br.read())) {
               if (isReadingLine && (ch == '\n' || ch == '\r')) {
                   isReadingLine = false;
               }
               else if (!isReadingLine && ch != '\n' && ch != '\r' && ch != ' ') {
                   isReadingLine = true;
                   linePointers.add(new Long(currPointer));
               }
               currPointer++;
           }
       }
       finally {
           br.close();
       }
   }

   public int getLogLineCount() {
       return linePointers.size();
   }

   public StringBuffer getLogfileContent(
       int startWithLineNum,
       int numLinesToRetrieve,
       boolean doReverse,
       StringBuffer statusBuffer,
       String searchString,
       boolean doMatchesOnly)
       throws IOException,
              RESyntaxException
   {
       //TODO: replace regexp w/ Java String
       StringBuffer   contentBuffer = new StringBuffer();
       ArrayList      lineArray  = new ArrayList(numLinesToRetrieve);
       int            numMatches = 0;
       int            lastLine  = 0;
       String         strLine = null;
       String         matchedLine = null;

       RE  re = null;
       if (searchString != null && searchString.trim().length() > 0) {
           re = new RE("(" + searchString + ")");
           re.setMatchFlags(RE.MATCH_CASEINDEPENDENT);
       }

       int startLine  = startWithLineNum;
       if (startLine <= 0) {
           startLine = getLogLineCount() - numLinesToRetrieve +1;
       }

       long startPosition = ((Long)linePointers.get(startLine -1)).longValue();
       RandomAccessFile raFile = new RandomAccessFile(file, "r");
       try {
           raFile.seek(startPosition);
           for(int idxCurrLine = startLine; idxCurrLine <= getLogLineCount(); idxCurrLine++)
           {
               strLine = raFile.readLine();
               if (strLine == null) {
                   break;
               }

               if (re != null) {
                   matchedLine = matchSearchString(re, strLine);
                   if (null != matchedLine) {
                       if (lastLine == 0) {
                           startLine = idxCurrLine;
                       }
                       strLine = matchedLine;
                       lastLine = idxCurrLine;
                       ++numMatches;
                   }
                   else if (doMatchesOnly) {
                       continue;
                   }
               }

               if (strLine.trim().length() > 0) {
                   lastLine = idxCurrLine;
                   lineArray.add(appendLineNumberToLine(idxCurrLine, strLine));
                   if (lineArray.size() >= numLinesToRetrieve) {
                       break;
                   }
               }
           }
       }
       finally {
           raFile.close();
       }

       appendLinesToContentBuffer(lineArray, doReverse, contentBuffer);
       appendLinesToStatusBuffer(startLine, lastLine, numMatches, statusBuffer);

       return contentBuffer;
   }

   private String matchSearchString(
       RE re,
       String strLine)
   {
       if (re.match(strLine)) {

           StringBuffer sbLine = new StringBuffer();
           sbLine.setLength(0);
           sbLine.append("<B>");

           String strMatch = re.getParen(1);
           int    iFrom = re.getParenStart(1);
           int    iTo   = re.getParenEnd(1);

           sbLine.append(strLine.substring(0, iFrom));
           sbLine.append("<U><I>");
           sbLine.append(strMatch);
           sbLine.append("</I></U>");

           while (re.match(strLine, iTo)) {
               strMatch = re.getParen(1);
               iFrom    = re.getParenStart(1);

               sbLine.append(strLine.substring(iTo, iFrom));

               iTo = re.getParenEnd(1);

               sbLine.append("<U><I>");
               sbLine.append(strMatch);
               sbLine.append("</I></U>");
           }

           sbLine.append(strLine.substring(iTo));
           sbLine.append("</B>");

           return sbLine.toString();
       }
       else {
           return null;
       }
   }

   private void appendLinesToContentBuffer(
       ArrayList lineArray,
       boolean doReverse,
       StringBuffer contentBuffer)
   {
       if (doReverse) {
           for (int i = lineArray.size() -1; i >= 0; i--) {
               contentBuffer.append(lineArray.get(i));
               contentBuffer.append("<BR>");
           }
       }
       else {
           for (int i = 0; i < lineArray.size(); i++) {
               contentBuffer.append(lineArray.get(i));
               contentBuffer.append("<BR>");
           }
       }
   }

   private void appendLinesToStatusBuffer(
       int iStartLine,
       int iLastLine,
       int numMatches,
       StringBuffer statusBuffer)
   {
       if (iLastLine > 0) {
           statusBuffer.append("Displaying line " + iStartLine + " through " + iLastLine);
           statusBuffer.append(" of " + getLogLineCount() + " lines.");
           if (numMatches > 0 ) {
               statusBuffer.append(" (" + numMatches + " matches)");
           }
       }
       else {
           statusBuffer.append("No mathcing lines found.");
       }
   }

   private String appendLineNumberToLine(
       int idxCurrLine,
       String strLine)
   {
       return "# " + Integer.toString(idxCurrLine) + ": " + strLine;
   }
}
