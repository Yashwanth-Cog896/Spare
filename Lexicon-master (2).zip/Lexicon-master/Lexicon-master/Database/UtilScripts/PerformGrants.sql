BEGIN 
	DECLARE
	    grantFromUser VARCHAR2(30) := 'LEXICON';
		grantToUser VARCHAR2(30) := 'LEXICON_USER';

		CURSOR TableCurs IS
			SELECT table_name
			  FROM All_Tables
			 WHERE owner = grantFromUser;
          
		CURSOR ViewCurs IS
			SELECT view_name
			  FROM All_Views
			 WHERE owner = grantFromUser;
          
		CURSOR SequenceCurs IS
			SELECT sequence_name
			  FROM All_Sequences
			 WHERE sequence_owner = grantFromUser;
         
		strDynamicSql VARCHAR2(100);

	BEGIN
		FOR TableRec IN TableCurs
		LOOP
			strDynamicSql := 'GRANT SELECT, INSERT, UPDATE, DELETE ON ' || TableRec.table_name || ' TO ' || grantToUser;
			dbms_output.put_line(strDynamicSql);
			EXECUTE IMMEDIATE strDynamicSql;
		END LOOP;

		FOR ViewRec IN ViewCurs
		LOOP
			strDynamicSql := 'GRANT SELECT ON ' || ViewRec.view_name || ' TO ' || grantToUser;
			dbms_output.put_line(strDynamicSql);
			EXECUTE IMMEDIATE strDynamicSql;
		END LOOP;

		FOR SequenceRec IN SequenceCurs
		LOOP
			strDynamicSql := 'GRANT SELECT ON ' || SequenceRec.sequence_name || ' TO ' || grantToUser;
			dbms_output.put_line(strDynamicSql);
			EXECUTE IMMEDIATE strDynamicSql;
		END LOOP;
	END;
END;

