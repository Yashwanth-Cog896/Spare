BEGIN 
	DECLARE
		CURSOR UserTableCurs IS
			SELECT table_name
			  FROM User_Tables;
          
		CURSOR UserSequenceCurs IS
			SELECT sequence_name
			  FROM User_Sequences;
         
		strDynamicSql VARCHAR2(100);

	BEGIN
		FOR UserTableRec IN UserTableCurs
		LOOP
			strDynamicSql := 'DROP TABLE ' || UserTableRec.table_name || ' CASCADE CONSTRAINTS';
			dbms_output.put_line(strDynamicSql);
			EXECUTE IMMEDIATE strDynamicSql;
		END LOOP;

		FOR UserSequenceRec IN UserSequenceCurs
		LOOP
			strDynamicSql := 'DROP SEQUENCE ' || UserSequenceRec.sequence_name;
			dbms_output.put_line(strDynamicSql);
			EXECUTE IMMEDIATE strDynamicSql;
		END LOOP;
	END;
END;


