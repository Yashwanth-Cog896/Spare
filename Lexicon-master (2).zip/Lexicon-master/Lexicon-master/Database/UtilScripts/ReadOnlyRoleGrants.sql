GRANT SELECT ON Lexicon.Bayer_Code TO Lexicon_Ro_Role
/
GRANT SELECT ON Lexicon.Brand TO Lexicon_Ro_Role
/
GRANT SELECT ON Lexicon.Coml_Trait_Name2 TO Lexicon_Ro_Role
/
GRANT SELECT ON Lexicon.Coml_Trait_Stack_Xref2 TO Lexicon_Ro_Role
/
GRANT SELECT ON Lexicon.Coml_Trait_Stack2 TO Lexicon_Ro_Role
/
GRANT SELECT ON Lexicon.Coml_Trait_Type TO Lexicon_Ro_Role
/
GRANT SELECT ON Lexicon.Coml_Trait_Type_Xref2 TO Lexicon_Ro_Role
/
GRANT SELECT ON Lexicon.Company TO Lexicon_Ro_Role
/
GRANT SELECT ON Lexicon.Country TO Lexicon_Ro_Role
/
GRANT SELECT ON Lexicon.Crop TO Lexicon_Ro_Role
/
GRANT SELECT ON Lexicon.Ctry_Reg_Region_Xref TO Lexicon_Ro_Role
/
GRANT SELECT ON Lexicon.Event_Coml_Trait_Xref TO Lexicon_Ro_Role
/
GRANT SELECT ON Lexicon.Base_Product TO Lexicon_Ro_Role
/
GRANT SELECT ON Lexicon.Pre_Coml_Product TO Lexicon_Ro_Role
/
GRANT SELECT ON Lexicon.Product TO Lexicon_Ro_Role
/
GRANT SELECT ON Lexicon.Product_Collapse_Audit_Detail TO Lexicon_Ro_Role
/
GRANT SELECT ON Lexicon.Product_Collapse_Audit_Header TO Lexicon_Ro_Role
/
GRANT SELECT ON Lexicon.Product_Name TO Lexicon_Ro_Role
/
GRANT SELECT ON Lexicon.Product_Stage TO Lexicon_Ro_Role
/
GRANT SELECT ON Lexicon.Product_Relationship TO Lexicon_Ro_Role
/
GRANT SELECT ON Lexicon.Product_Relationship_Xref TO Lexicon_Ro_Role
/
GRANT SELECT ON Lexicon.Regulatory_Agency TO Lexicon_Ro_Role
/
GRANT SELECT ON Lexicon.Regulatory_Agency_Status TO Lexicon_Ro_Role
/
GRANT SELECT ON Lexicon.Regulatory_Region TO Lexicon_Ro_Role
/
GRANT SELECT ON Lexicon.Regulatory_Status_Type TO Lexicon_Ro_Role
/
GRANT SELECT ON Lexicon.Regulatory_Sub_Country_Status TO Lexicon_Ro_Role
/
GRANT SELECT ON Lexicon.Sap_Linkage_Audit TO Lexicon_Ro_Role
/
GRANT SELECT ON Lexicon.Stage TO Lexicon_Ro_Role
/
GRANT SELECT ON Lexicon.Unit_Of_Measure TO Lexicon_Ro_Role
/
GRANT SELECT ON Lexicon.Unit_Of_Measure_Lookup TO Lexicon_Ro_Role
/
GRANT SELECT ON Lexicon.Vendor TO Lexicon_Ro_Role
/
GRANT SELECT ON Lexicon.Vendor_Carrier TO Lexicon_Ro_Role
/
GRANT SELECT ON Lexicon.Generic_Product_Name_View TO Lexicon_Ro_Role
/
GRANT SELECT ON Lexicon.Generic_Product_View TO Lexicon_Ro_Role
/

/* Argot Objects */
GRANT SELECT ON Lexicon.Additional_Material TO Lexicon_RO_Role
/
GRANT SELECT ON Lexicon.Chemical_Name TO Lexicon_RO_Role
/
GRANT SELECT ON Lexicon.Container_Type TO Lexicon_RO_Role
/
GRANT SELECT ON Lexicon.External_Contact TO Lexicon_RO_Role
/
GRANT SELECT ON Lexicon.Formulation_Type TO Lexicon_RO_Role
/
GRANT SELECT ON Lexicon.Genetic_Background TO Lexicon_RO_Role
/
GRANT SELECT ON Lexicon.Molecular_Description TO Lexicon_RW_Role
/
GRANT SELECT ON Lexicon.Mon_Number TO Lexicon_RO_Role
/
GRANT SELECT ON Lexicon.Plant_Name TO Lexicon_RO_Role
/
GRANT SELECT ON Lexicon.Protein_Name TO Lexicon_RO_Role
/
GRANT SELECT ON Lexicon.Sample_Type TO Lexicon_RO_Role
/
GRANT SELECT ON Lexicon.Shipping_Condition TO Lexicon_RO_Role
/
GRANT SELECT ON Lexicon.Storage_Condition TO Lexicon_RO_Role
/
GRANT SELECT ON Lexicon.Storage_Location TO Lexicon_RO_Role
/

