BEGIN 
	DECLARE
	    objectOwner VARCHAR2(30) := 'LEXICON';
	    
		CURSOR LexiconObjectCurs IS
			SELECT  object_name 
			  FROM  All_Objects
			 WHERE  owner = objectOwner
			   AND  object_type IN 
			   		('FUNCTION', 'PACKAGE', 'PACKAGE BODY', 'PROCEDURE',
			   		 'SEQUENCE', 'TABLE', 'VIEW');
          
		strDynamicSql VARCHAR2(100);
		strErrors VARCHAR2(4000) := NULL;

	BEGIN
		FOR LexiconObjectRec IN LexiconObjectCurs
		LOOP
			strDynamicSql := 'CREATE OR REPLACE SYNONYM ' || LexiconObjectRec.object_name || ' FOR ' || objectOwner || '.' || LexiconObjectRec.object_name;
			BEGIN
				EXECUTE IMMEDIATE strDynamicSql;
				DBMS_OUTPUT.put_line(strDynamicSql || ';');
			EXCEPTION
				WHEN OTHERS THEN
					strErrors := strErrors || SQLERRM || '. Failure on object: ' || LexiconObjectRec.object_name || CHR(13) || CHR(10); --|| strDynamicSql || CHR(13) || CHR(10);
			END;
		END LOOP;
		
		IF strErrors IS NOT NULL THEN
			strErrors := 'The following errors occured during synonym creation:' || CHR(13) || CHR(10) || strErrors;
			raise_application_error(-20001, strErrors);
		END IF;
	END;
END;
/


