GRANT EXECUTE ON Lexicon.Audit_Pkg TO Lexicon_User;
GRANT EXECUTE ON Lexicon.Audit_Pkg TO NGSCHO;
