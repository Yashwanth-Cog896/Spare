CREATE OR REPLACE PACKAGE Audit_Pkg
IS
/**
    Audit Operation Constants
*/
    INSERT_OPERATION Audit_Header.audit_operation_type%TYPE := 'I';
    UPDATE_OPERATION Audit_Header.audit_operation_type%TYPE := 'U';
    DELETE_OPERATION Audit_Header.audit_operation_type%TYPE := 'D';

/**
    No Audit Stage Record Exception Declarations and constants
*/
    NO_AUDIT_STAGE_REC_EXCEPTION EXCEPTION;
    NO_AUDIT_STAGE_REC_ERRNUM INTEGER := -20500;
    NO_AUDIT_STAGE_REC_ERRMSG VARCHAR2(60) := 'No audit staging record associated with the current session';
    PRAGMA EXCEPTION_INIT(NO_AUDIT_STAGE_REC_EXCEPTION, -20500);

/**
    Audit_Detail_Array_Type - Associative Array of Audit_Detail records
*/
    TYPE Audit_Detail_Array_Type
    IS
        TABLE OF Audit_Detail%ROWTYPE
        INDEX BY BINARY_INTEGER;
        
/**
    Audit_Staging_Info_Type - The columns of the audit staging table that can be set
*/
    TYPE Audit_Staging_Info_Type IS Record (
        user_party_id Audit_Staging.user_party_id%TYPE,
        process_name Audit_Staging.process_name%TYPE,
        audit_comment Audit_Staging.audit_comment%TYPE,
        audit_requestor Audit_Staging.audit_requestor%TYPE,
        user_login_id Audit_Staging.user_login_id%TYPE  -- sasteib added on 10/21/08
    );

/**
    PROCEDURE Write_Audit_P
    This procedure is the entry point for triggers that perform auditing actions.

    Parameters
        inTableName - The name of the table to be audited. No check is performed to determine
            if it is a valid table.
        inOperationType - A CHAR(1) field indicated the type of operation.
            'I'nsert, 'U'pdate or, 'D'elete.
        inPrimaryKeyIndex - The index number of the column that is the primary key.
        inAuditDetailArray - An associative array of Audit_Detail records. These records only
            contain the colunm_name, new_value, and old_value values for each column in table
            that is being audited.
*/
    PROCEDURE Write_Audit_P(
        inTableName IN Audit_Header.table_name%TYPE,
        inOperationType IN Audit_Header.audit_operation_type%TYPE,
        inPrimaryKeyIndex IN INTEGER,
        inAuditDetailArray IN Audit_Detail_Array_Type);

/**
    PROCEDURE Initialize_Staging_P
    This procedure initializes the Audit_Staging for the current session. If the staging row
    associated with current session already exisits it is updated, otherwise a new row is created.

    Parameters
        inUserPartyId - The party id of the user performing the action.
        inProcessName - The process involved in making the action.
        inAuditComment - The optional comment about the action.
        inAuditRequestor - The person requesting the change.
*/
    PROCEDURE Initialize_Staging_P(
        inUserPartyId Audit_Staging.user_party_id%TYPE,
        inProcessName Audit_Staging.process_name%TYPE,
        inAuditComment Audit_Staging.audit_comment%TYPE,
        inAuditRequestor Audit_Staging.audit_requestor%TYPE);

        
/**
    PROCEDURE Initialize_Staging_P  -- sasteib added on 10/21/08
    This procedure initializes the Audit_Staging for the current session. If the staging row
    associated with current session already exisits it is updated, otherwise a new row is created.

    Parameters
        inUserPartyId - The party id of the user performing the action.
        inProcessName - The process involved in making the action.
        inAuditComment - The optional comment about the action.
        inAuditRequestor - The person requesting the change.
        inUserLoginId - The network login id of the user performing the action.
*/
    PROCEDURE Initialize_Staging_P(
        inUserPartyId Audit_Staging.user_party_id%TYPE,
        inProcessName Audit_Staging.process_name%TYPE,
        inAuditComment Audit_Staging.audit_comment%TYPE,
        inAuditRequestor Audit_Staging.audit_requestor%TYPE,
        inUserLoginId Audit_Staging.user_login_id%TYPE);

/**
    FUNCTION Create_Detail_Record_F
    This function returns a newly constucted, but not inserted Audit_Detail record from the
    supplied parameters. The audit_detail_id and audit_header_id fields are set to NULL.

    Parameters
        inColumn - The name of the column to be audited
        inNewValue - The TO_CHAR representation of the new value
        inOldValue - The TO_CHAR representation of the old value
*/
    FUNCTION Create_Detail_Record_F(
        inColumnName IN Audit_Detail.column_name%TYPE,
        inNewValue IN Audit_Detail.new_value%TYPE,
        inOldValue IN Audit_Detail.old_value%TYPE)
        RETURN Audit_Detail%ROWTYPE;

/**
    FUNCTION Create_Header_Record_F
    This function returns a newly constucted, but not inserted Audit_Header record from the
    supplied parameters.

    Parameters
        inTableName - The name of the table to be audited
        inOperationType - A CHAR(1) field indicated the type of operation.
            'I'nsert, 'U'pdate or, 'D'elete.
        inPrimaryKeyValue - The current value of the primary key field.
        inAuditStagingRecord - The Audit_Staging record associated with the current session.
*/
    FUNCTION Create_Header_Record_F(
        inTableName Audit_Header.table_name%TYPE,
        inOperationType IN Audit_Header.audit_operation_type%TYPE,
        inPrimaryKeyValue IN Audit_Header.primary_key_field1%TYPE,
        inAuditStagingRecord IN Audit_Staging_Info_Type)
        RETURN Audit_Header%ROWTYPE;

/**
    FUNCTION Create_Staging_Record_F
    This function returns a newly constucted, but not inserted Audit_Staging record from the
    supplied parameters and the current session id.

    Parameters
        inUserPartyId - The party id of the user performing the action.
        inProcessName - The process involved in making the action.
        inAuditComment - The optional comment about the action.
        inAuditRequestor - The person requesting the change.
*/
    FUNCTION Create_Staging_Record_F(
        inUserPartyId Audit_Staging.user_party_id%TYPE,
        inProcessName Audit_Staging.process_name%TYPE,
        inAuditComment Audit_Staging.audit_comment%TYPE,
        inAuditRequestor Audit_Staging.audit_requestor%TYPE)
    RETURN Audit_Staging_Info_Type;

    
/**
    FUNCTION Create_Staging_Record_F  -- sasteib added on 10/21/08
    This function returns a newly constucted, but not inserted Audit_Staging record from the
    supplied parameters and the current session id.

    Parameters
        inUserPartyId - The party id of the user performing the action.
        inProcessName - The process involved in making the action.
        inAuditComment - The optional comment about the action.
        inAuditRequestor - The person requesting the change.
*/
    FUNCTION Create_Staging_Record_F(
        inUserPartyId Audit_Staging.user_party_id%TYPE,
        inProcessName Audit_Staging.process_name%TYPE,
        inAuditComment Audit_Staging.audit_comment%TYPE,
        inAuditRequestor Audit_Staging.audit_requestor%TYPE,
        inUserLoginId Audit_Staging.user_login_id%TYPE)
    RETURN Audit_Staging_Info_Type;

/**
    FUNCTION Get_Session_Staging_Record_F
    This function returns the Audit_Staging record associated with the current session.
    If no such record exists a NO_AUDIT_STAGE_REC_EXCEPTION is thrown.
*/
    FUNCTION Get_Session_Staging_Record_F
        RETURN Audit_Staging_Info_Type;

/**
    FUNCTION Get_Session_Id_F
    This function returns the Oralce Session Id for the current session.
*/
    FUNCTION Get_Session_Id_F
        RETURN Sys.V_$Session.sid%TYPE;

/**
    FUNCTION Get_Next_Header_ID_F
    This function returns the next Audit_Header primary key value.
*/
    FUNCTION Get_Next_Header_ID_F
        RETURN Audit_Header.audit_header_id%TYPE;

/**
    FUNCTION Get_Next_Detail_ID_F
    This function returns the next Audit_Detail primary key value.
*/
    FUNCTION Get_Next_Detail_ID_F
        RETURN Audit_Detail.audit_detail_id%TYPE;

/**
    FUNCTION Do_Audit_Detail_F
    This function determines whether a detail record should be created based upon the operation
    type and/or the contents the new_value, old_value pair in the supplied Audit_Detail record.

    Parameters
        inTableName - The name of the table to be audited.
        inOperationType - A CHAR(1) field indicated the type of operation.
            'I'nsert, 'U'pdate or, 'D'elete.
*/
    FUNCTION Do_Audit_Detail_F(
        inOperationType IN Audit_Header.audit_operation_type%TYPE,
        inAuditDetailRecord IN Audit_Detail%ROWTYPE)
        RETURN boolean;

/**
    FUNCTION Do_Audit_Table_F
    This function determines whether the given table should be auditied.
    Currently, this function is merely a placehold for potential future functionality.

    Parameters
        inTableName - The name of the table to potentially be audited
*/
    FUNCTION Do_Audit_Table_F(
        inTableName Audit_Header.table_name%TYPE)
        RETURN boolean;

/**
    FUNCTION Do_Audit_Column_F
    This function determines whether the given table.column should be auditied.
    Currently, this function is merely a placehold for potential future functionality.

    Parameters
        inTableName - The name of the table to be audited
        inColumnName - The name of the column to potentially be audited
*/
    FUNCTION Do_Audit_Column_F(
        inTableName IN Audit_Header.table_name%TYPE,
        inColumnName IN Audit_Detail.column_name%TYPE)
        RETURN boolean;
        
/**
    PROCEDURE Insert_Audit_Header_P
    This procedure inserts an Audit_Header row.

    Parameters
        inAuditHeaderRecord - The Audit_Detail record to be inserted.
*/
    PROCEDURE Insert_Audit_Header_P(
        inAuditHeaderRecord IN Audit_Header%ROWTYPE);

/**
    PROCEDURE Insert_Audit_Detail_P
    This procedure inserts an Audit_Detail row.
    
    Parameters
        inAuditDetailRecord - The Audit_Detail record to be inserted.
*/
    PROCEDURE Insert_Audit_Detail_P(
        inAuditDetailRecord IN Audit_Detail%ROWTYPE);

/**
    PROCEDURE Insert_Audit_Staging_P
    This procedure inserts an Audit_Staging row.
    
    Parameters
        inAuditStagingRecord - The Audit_Staging record to be inserted.
*/
    PROCEDURE Insert_Audit_Staging_P(
        inAuditStagingRecord IN Audit_Staging_Info_Type);

/**
    PROCEDURE Update_Audit_Staging_P
    This procedure update an Audit_Staging row.

    Parameters
        inAuditStagingRecord - The Audit_Staging record to be updated.
*/
    PROCEDURE Update_Audit_Staging_P(
        inAuditStagingRecord IN Audit_Staging_Info_Type);
        
/**
    PROCEDURE Delete_Staging_Record_P
    This procedure deletes the Audit_Staging record associated with the current session.
*/
    PROCEDURE Delete_Staging_Record_P;
    
/**
    FUNCTION Get_Session_OSUser_F
    This function returns to the osuser associated with the current session
*/
    FUNCTION Get_Session_OSUser_F
        RETURN Sys.V_$Session.osuser%TYPE;

/**
    FUNCTION Get_Session_Machine_F
    This function returns to the machine associated with the current session
*/
    FUNCTION Get_Session_Machine_F
        RETURN Sys.V_$Session.machine%TYPE;

END Audit_Pkg; -- Package spec
/

