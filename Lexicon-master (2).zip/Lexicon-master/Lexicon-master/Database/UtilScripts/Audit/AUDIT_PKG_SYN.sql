CREATE SYNONYM lexicon_user.audit_pkg 
  FOR LEXICON.AUDIT_PKG;

