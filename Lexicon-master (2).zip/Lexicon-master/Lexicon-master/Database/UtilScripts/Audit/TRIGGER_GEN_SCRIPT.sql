BEGIN
   DECLARE
    	lSchema VARCHAR2(30) := 'LEXICON';

        TYPE User_Table_Array_Type
        IS
            TABLE OF VARCHAR2(32)
            INDEX BY BINARY_INTEGER;

        TYPE Table_Columns_Array_Type
        IS
            TABLE OF VARCHAR2(32)
            INDEX BY BINARY_INTEGER;

        lUserTableArray User_Table_Array_Type;
        lTableColumnsArray Table_Columns_Array_Type;
        lTableName Sys.User_Tables.table_name%TYPE;
        lTriggerName Sys.User_Tables.table_name%TYPE;
        lColumnName Sys.User_Tab_Columns.column_name%TYPE;
        lPKColumnName Sys.User_Tab_Columns.column_name%TYPE;
        lPrimaryKeyPosition INTEGER;
        lDMLString VARCHAR2(4000);
        lchar CHAR(1);

    BEGIN
        SELECT  table_name
          BULK  COLLECT INTO lUserTableArray
          FROM  Sys.All_Tables
         WHERE  UPPER(owner) = 'LEXICON'
           AND  UPPER(table_name) IN (
                    'BAYER_CODE', 'BRAND', 'COMPANY', 'COUNTRY', 'CROP', 'STAGE', 
                    'PRE_COML_PRODUCT', 'PRODUCT', 'PRODUCT_NAME', 'PRODUCT_STAGE',
                    'COML_TRAIT_NAME2', 'COML_TRAIT_STACK2', 'COML_TRAIT_STACK_XREF2',
		            'COML_TRAIT_TYPE_XREF2', 'COML_TRAIT_TYPE', 'APP_ROLE', 'USER_APP_ROLE',
					'PRODUCT_RELATIONSHIP', 'PRODUCT_RELATIONSHIP_XREF', 'BASE_PRODUCT',
					'EVENT_COML_TRAIT_XREF', 'REGULATORY_REGION', 'REGULATORY_AGENCY', 
					'REGULATORY_AGENCY_STATUS', 'CTRY_REG_REGION_XREF', 'REGULATORY_SUB_COUNTRY_STATUS',
					'ADDITIONAL_MATERIAL', 'CHEMICAL_NAME', 'CONTAINER_TYPE', 'EXTERNAL_CONTACT',
					'FORMULATION_TYPE', 'GENETIC_BACKGROUND', 'MON_NUMBER', 'PLANT_NAME', 'PROTEIN_NAME',
					'SAMPLE_TYPE', 'SHIPPING_CONDITION', 'STORAGE_CONDITION', 'STORAGE_LOCATION',
					'MOLECULAR_DESCRIPTION', 'PRODUCT_SUBSCRIPTION'
				);

       FOR i IN 1..lUserTableArray.COUNT
       LOOP
          BEGIN
            lTableName := lUserTableArray(i);
            lTriggerName := SUBSTR(lTableName, 1, 26) || '_TRG';

            SELECT  column_name
              BULK  COLLECT INTO lTableColumnsArray
              FROM  Sys.All_Tab_Columns
             WHERE  owner = lSchema
               AND  Table_Name = lTableName
               AND  Data_Type NOT IN ('BLOB', 'CLOB', 'NCLOB', 'BFILE');

            BEGIN
                SELECT  column_name
                  INTO  lPKColumnName
                  FROM  Sys.All_Cons_Columns
                 WHERE  owner = lSchema
                   AND  Constraint_Name IN (
                            SELECT Constraint_Name
        	                  FROM Sys.All_Constraints
            	             WHERE Constraint_Type = 'P'
                	           AND owner = lSchema
                               AND Table_Name = lTableName);

            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    raise_application_error(-20499, 'Unable to determine the primary key column name for the table ' || lTableName);
                WHEN TOO_MANY_ROWS THEN
                    raise_application_error(-20498, 'More the 1 primary key column was found for the table ' || lTableName);
            END;

            lPrimaryKeyPosition := -1;
            FOR j IN 1..lTableColumnsArray.COUNT
            LOOP
            	IF lTableColumnsArray(j) = lPKColumnName THEN
            		lPrimaryKeyPosition := j;
            	END IF;
            END LOOP;

            IF lPrimaryKeyPosition = -1 THEN
        		raise_application_error(-20497, 'Unable to determine primary key column id for the table ' || lTableName);
			END IF;

            lDMLString := 'CREATE OR REPLACE TRIGGER ' || lSchema || '.' || lTriggerName || CHR(10) ||
                          '  AFTER INSERT OR DELETE OR UPDATE' || CHR(10) ||
                          '  ON ' || lSchema || '.' || lTableName || CHR(10) ||
                          '  FOR EACH ROW' || CHR(10) ||
                          CHR(10) ||
                          'DECLARE' || CHR(10) ||
                          '  lOperationType CHAR(1);' || CHR(10) ||
                          '  lPrimaryKeyPosition INTEGER := ' || TO_CHAR(lPrimaryKeyPosition) || ';' || CHR(10) ||
                          '  lTableName VARCHAR2(30) := ''' || lTableName || ''';' || CHR(10) ||
                          '  lAuditDetailArray Audit_Pkg.Audit_Detail_Array_Type;' || CHR(10) ||
                          CHR(10) ||
                          'BEGIN' || CHR(10) ||
                          '  IF Audit_Pkg.Do_Audit_Table_F(lTableName) THEN' || CHR(10) ||
                          CHR(10) ||
                          '    IF INSERTING THEN lOperationType := Audit_Pkg.INSERT_OPERATION;' || CHR(10) ||
                          '    ELSIF UPDATING THEN lOperationType := Audit_Pkg.UPDATE_OPERATION;' || CHR(10) ||
                          '    ELSIF DELETING THEN lOperationType := Audit_Pkg.DELETE_OPERATION;' || CHR(10) ||
                          '    ELSE lOperationType := NULL;' || CHR(10) ||
                          '    END IF;' || CHR(10) ||
                          CHR(10);

            FOR j IN 1..lTableColumnsArray.COUNT
            LOOP
                lColumnName := lTableColumnsArray(j);
                lDMLString := lDMLString || '    ' ||
                              'lAuditDetailArray(' || TO_CHAR(j) || ') := ' ||
                                  'Audit_Pkg.Create_Detail_Record_F(' ||
                                      '''' || lColumnName || ''', ' ||
                                      ':NEW.' || lColumnName || ', ' ||
                                      ':OLD.' || lColumnName ||
                                  ');' || CHR(10);
            END LOOP;

            lDMLString := lDMLString || CHR(10) ||
                        '    Audit_Pkg.Write_Audit_P(lTableName , lOperationType, lPrimaryKeyPosition, lAuditDetailArray);' || CHR(10) ||
                        '  END IF;' || CHR(10) ||
                        'END;';

            EXECUTE IMMEDIATE lDMLString;
	        DBMS_OUTPUT.Put_Line(lTriggerName || ' trigger created (or replaced)');
/*			FOR k IN 1..LENGTH(lDMLString) LOOP
				lChar := SUBSTR(lDMLString, k, 1);
				IF lChar = CHR(10) THEN
					DBMS_OUTPUT.new_line;
				ELSE
					DBMS_OUTPUT.put(lChar);
				END IF;
			END LOOP;
			DBMS_OUTPUT.new_line;
*/

          EXCEPTION
              WHEN OTHERS THEN
                  raise_application_error(-20499, 'Error creating the ' || lTriggerName || ' trigger.' ||CHR(10) || SQLERRM);
		  END;
       END LOOP;

    END;
END;
/


