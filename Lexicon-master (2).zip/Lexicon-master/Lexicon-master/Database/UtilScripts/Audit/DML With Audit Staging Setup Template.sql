BEGIN
    DECLARE
        partyID      NUMBER;
        loginName    VARCHAR2(100) := 'JASKIDI';
        process      VARCHAR2(100) := 'DATA MAINT';
        auditComment VARCHAR2(100) := 'Data Maintenance';
        requestor    VARCHAR2(100) := 'Jason Skidis';
        
    BEGIN
        SELECT  object_id
          INTO  partyID
          FROM  Mon_Ldap_Security.Monsanto_Secure_User 
         WHERE  UPPER(user_name) = loginName;

        Lexicon.Audit_Pkg.initialize_staging_p(partyID, process, auditcomment, requestor);

        --Put DML Statements Here
                
        Lexicon.Audit_pkg.delete_staging_record_p;
    END;
END;

