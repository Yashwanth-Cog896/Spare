INSERT INTO Audit_Table_Includes VALUES (1, 'PRODUCT');
INSERT INTO Audit_Table_Includes VALUES (2, 'PRODUCT_NAME');
INSERT INTO Audit_Table_Includes VALUES (3, 'BRAND'); 
INSERT INTO Audit_Table_Includes VALUES (4, 'COUNTRY'); 
INSERT INTO Audit_Table_Includes VALUES (5, 'COMPANY'); 
INSERT INTO Audit_Table_Includes VALUES (6, 'COML_TRAIT'); 
INSERT INTO Audit_Table_Includes VALUES (7, 'COML_TRAIT_NAME'); 
INSERT INTO Audit_Table_Includes VALUES (8, 'COML_TRAIT_TYPE');
INSERT INTO Audit_Table_Includes VALUES (9, 'COML_TRAIT_TYPE_XREF'); 
INSERT INTO Audit_Table_Includes VALUES (10, 'COML_TRAIT_STACK');
INSERT INTO Audit_Table_Includes VALUES (11, 'COML_TRAIT_STACK_XREF'); 
INSERT INTO Audit_Table_Includes VALUES (12, 'COML_TRAIT_STACK_NAME_XREF');

--DELETE FROM audit_table_includes WHERE table_name = 'BRAND';

