CREATE OR REPLACE PACKAGE BODY Audit_Pkg
IS
    PROCEDURE Write_Audit_P(
        inTableName IN Audit_Header.table_name%TYPE,
        inOperationType IN Audit_Header.audit_operation_type%TYPE,
        inPrimaryKeyIndex IN INTEGER,
        inAuditDetailArray IN Audit_Detail_Array_Type)
    IS
        lPrimaryKeyValue Audit_Header.primary_key_field1%TYPE;
        lAuditStagingRecord Audit_Staging_Info_Type;
        lAuditHeaderRecord Audit_Header%ROWTYPE;
        lAuditDetailRecord Audit_Detail%ROWTYPE;
        lDetailToInsertArray Audit_Detail_Array_Type;
        lNumDetailToInsert INTEGER := 0;
    BEGIN
        -- Determine if table is be to audited
        IF Do_Audit_Table_F(inTableName) THEN
        
            -- Get the primary key value
            IF inOperationType = DELETE_OPERATION THEN
                lPrimaryKeyValue := TO_CHAR(inAuditDetailArray(inPrimaryKeyIndex).old_Value);
            ELSE
                lPrimaryKeyValue := TO_CHAR(inAuditDetailArray(inPrimaryKeyIndex).new_value);
            END IF;
            
            -- Get the audit staging record associated with the current session id
            lAuditStagingRecord := Get_Session_Staging_Record_F();

            -- Create a new audit header record with the supplied values
            lAuditHeaderRecord := Create_Header_Record_F(inTableName, inOperationType, lPrimaryKeyValue, lAuditStagingRecord);

            -- Loop through all detail records
            FOR i IN 1..inAuditDetailArray.COUNT
            LOOP
                -- Determine if column is to be audited
                IF Do_Audit_Column_F(inTableName, inAuditDetailArray(i).column_name) THEN

                    -- Get the detail record from the array
                    lAuditDetailRecord := inAuditDetailArray(i);

                    -- Determine if column values and/or operation type require a new detail record
                    IF Do_Audit_Detail_F(inOperationType, lAuditDetailRecord) THEN

                        -- Set the remaining detail fields and store record in array to detail records to be inserted
                        lAuditDetailRecord.audit_detail_id := Get_Next_Detail_ID_F();
                        lAuditDetailRecord.audit_header_id := lAuditHeaderRecord.audit_header_id;
                        lNumDetailToInsert := lNumDetailToInsert + 1;
                        lDetailToInsertArray(lNumDetailToInsert) := lAuditDetailRecord;
                    END IF;

                END IF;
            END LOOP;

            -- If there is at least 1 detail record to inserted
            IF lNumDetailToInsert > 0 THEN
                -- Insert the audit header
                Insert_Audit_Header_P(lAuditHeaderRecord);
                
                -- Insert the detail records
                FOR i IN 1..lNumDetailToInsert
                LOOP
                    Insert_Audit_Detail_P(lDetailToInsertArray(i));
                END LOOP;
            END IF;

        END IF;
    END Write_Audit_P;

    
    PROCEDURE Initialize_Staging_P(
        inUserPartyId Audit_Staging.user_party_id%TYPE,
        inProcessName Audit_Staging.process_name%TYPE,
        inAuditComment Audit_Staging.audit_comment%TYPE,
        inAuditRequestor Audit_Staging.audit_requestor%TYPE)
    IS
        lAuditStagingRecord Audit_Staging_Info_Type := null;
    BEGIN
        -- Get the current staging record
        lAuditStagingRecord := Get_Session_Staging_Record_F();
        
        -- Set the fields
        lAuditStagingRecord.user_party_id := inUserPartyId;
        lAuditStagingRecord.process_name := inProcessName;
        lAuditStagingRecord.audit_comment := inAuditComment;
        lAuditStagingRecord.audit_requestor := inAuditRequestor;
        
        -- Update the row
        Update_Audit_Staging_P(lAuditStagingRecord);
    EXCEPTION
        -- If the current staging record doesn't exist
        WHEN NO_AUDIT_STAGE_REC_EXCEPTION THEN
            -- Create and insert a new record
            lAuditStagingRecord := Create_Staging_Record_F(inUserPartyId, inProcessName, inAuditComment, inAuditRequestor);
            Insert_Audit_Staging_P(lAuditStagingRecord);
    END;

    -- sasteib added on 10/21/08
    PROCEDURE Initialize_Staging_P(
        inUserPartyId Audit_Staging.user_party_id%TYPE,
        inProcessName Audit_Staging.process_name%TYPE,
        inAuditComment Audit_Staging.audit_comment%TYPE,
        inAuditRequestor Audit_Staging.audit_requestor%TYPE,
        inUserLoginId Audit_Staging.user_login_id%TYPE)
    IS
        lAuditStagingRecord Audit_Staging_Info_Type := null;
    BEGIN

        -- Get the current staging record
        lAuditStagingRecord := Get_Session_Staging_Record_F();
        

        
        -- Set the fields
        lAuditStagingRecord.user_party_id := inUserPartyId;
        lAuditStagingRecord.process_name := inProcessName;
        lAuditStagingRecord.audit_comment := inAuditComment;
        lAuditStagingRecord.audit_requestor := inAuditRequestor;
        lAuditStagingRecord.user_login_id := inUserLoginId;
        
        -- Update the row
        Update_Audit_Staging_P(lAuditStagingRecord);
    EXCEPTION
        -- If the current staging record doesn't exist
        WHEN NO_AUDIT_STAGE_REC_EXCEPTION THEN
            -- Create and insert a new record
            lAuditStagingRecord := Create_Staging_Record_F(inUserPartyId, inProcessName, inAuditComment, inAuditRequestor, inUserLoginId);
            Insert_Audit_Staging_P(lAuditStagingRecord);
    END;

    FUNCTION Create_Detail_Record_F(
        inColumnName IN Audit_Detail.column_name%TYPE,
        inNewValue IN Audit_Detail.new_value%TYPE,
        inOldValue IN Audit_Detail.old_value%TYPE)
        RETURN Audit_Detail%ROWTYPE
    IS
        lAuditDetailRecord Audit_Detail%ROWTYPE;
    BEGIN
        SELECT  null AS audit_detail_id,
                null AS audit_header_id,
                inColumnName AS column_name,
                inNewValue AS new_value,
                inOldValue AS old_value
          INTO  lAuditDetailRecord
          FROM  DUAL;

        RETURN lAuditDetailRecord;
    END Create_Detail_Record_F;


    FUNCTION Create_Header_Record_F(
        inTableName Audit_Header.table_name%TYPE,
        inOperationType IN Audit_Header.audit_operation_type%TYPE,
        inPrimaryKeyValue IN Audit_Header.primary_key_field1%TYPE,
        inAuditStagingRecord IN Audit_Staging_Info_Type)
        RETURN Audit_Header%ROWTYPE
    IS
        lAuditHeaderRecord Audit_Header%ROWTYPE;
    BEGIN
        SELECT  Get_Next_Header_ID_F() AS audit_header_id,
                inOperationType AS audit_operation_type,
                inAuditStagingRecord.user_party_id AS user_party_id,
                inTableName AS table_name,
                SYSDATE AS entry_date,
                inPrimaryKeyValue AS primary_key_field1,
                inAuditStagingRecord.process_name AS process_name,
                inAuditStagingRecord.audit_comment AS audit_comment,
                inAuditStagingRecord.audit_requestor AS audit_requestor,
                inAuditStagingRecord.user_login_id as user_login_id       -- sasteib added on 10/21/08
          INTO  lAuditHeaderRecord
          FROM  DUAL;

        RETURN lAuditHeaderRecord;
    END Create_Header_Record_F;


    FUNCTION Create_Staging_Record_F(
        inUserPartyId Audit_Staging.user_party_id%TYPE,
        inProcessName Audit_Staging.process_name%TYPE,
        inAuditComment Audit_Staging.audit_comment%TYPE,
        inAuditRequestor Audit_Staging.audit_requestor%TYPE)
        RETURN Audit_Staging_Info_Type
    IS
        lAuditStagingRecord Audit_Staging_Info_Type;
    BEGIN
        SELECT  inUserPartyId AS user_party_id,
                inProcessName AS process_name,
                inAuditComment AS audit_comment,
                inAuditRequestor AS audit_requestor,
                null AS user_login_id       -- sasteib added on 10/21/08
          INTO  lAuditStagingRecord
          FROM  DUAL;

        RETURN lAuditStagingRecord;
    END Create_Staging_Record_F;

    -- sasteib added on 10/21/08
    FUNCTION Create_Staging_Record_F(
        inUserPartyId Audit_Staging.user_party_id%TYPE,
        inProcessName Audit_Staging.process_name%TYPE,
        inAuditComment Audit_Staging.audit_comment%TYPE,
        inAuditRequestor Audit_Staging.audit_requestor%TYPE,
        inUserLoginId Audit_Staging.user_login_id%TYPE)
        RETURN Audit_Staging_Info_Type
    IS
        lAuditStagingRecord Audit_Staging_Info_Type;
    BEGIN
    
        SELECT  inUserPartyId AS user_party_id,
                inProcessName AS process_name,
                inAuditComment AS audit_comment,
                inAuditRequestor AS audit_requestor,
                inUserLoginId AS user_login_id
          INTO  lAuditStagingRecord
          FROM  DUAL;

        RETURN lAuditStagingRecord;
    END Create_Staging_Record_F;

    FUNCTION Get_Session_Staging_Record_F
        RETURN Audit_Staging_Info_Type
    IS
        lAuditStagingRecord Audit_Staging_Info_Type;
    BEGIN
        SELECT  user_party_id,
                process_name,
                audit_comment,
                audit_requestor,
                user_login_id           -- sasteib added on 10/27/08
          INTO  lAuditStagingRecord
          FROM  Audit_Staging
         WHERE  oracle_sid = Get_Session_Id_F();

        RETURN lAuditStagingRecord;
        
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(NO_AUDIT_STAGE_REC_ERRNUM, NO_AUDIT_STAGE_REC_ERRMSG);
    END Get_Session_Staging_Record_F;


    FUNCTION Get_Session_Id_F
        RETURN Sys.V_$Session.sid%TYPE
    IS
        lSID Sys.V_$Session.sid%TYPE;
    BEGIN
        SELECT  sid
          INTO  lSID
          FROM  Sys.V_$Session
         WHERE  audsid = (
                SELECT  USERENV('sessionid')
                  FROM  DUAL);

        RETURN lSID;
    END Get_Session_Id_F;


    FUNCTION Get_Next_Header_ID_F
        RETURN Audit_Header.audit_header_id%TYPE
    IS
        lAuditHeaderID Audit_Header.audit_header_id%TYPE;
    BEGIN
        SELECT  Audit_Header_Seq.NEXTVAL
          INTO  lAuditHeaderID
          FROM  DUAL;

        RETURN lAuditHeaderID;
    END Get_Next_Header_ID_F;


    FUNCTION Get_Next_Detail_ID_F
        RETURN Audit_Detail.audit_detail_id%TYPE
    IS
        lAuditDetailID Audit_Detail.audit_detail_id%TYPE;
    BEGIN
        SELECT  Audit_Detail_Seq.NEXTVAL
          INTO  lAuditDetailID
          FROM  DUAL;

        RETURN lAuditDetailID;
    END Get_Next_Detail_ID_F;


    FUNCTION Do_Audit_Detail_F(
        inOperationType IN Audit_Header.audit_operation_type%TYPE,
        inAuditDetailRecord IN Audit_Detail%ROWTYPE)
        RETURN boolean
    IS
        lDoAddDetail boolean := true;
    BEGIN
        -- If the operation is update and new value and old value are the same,
        -- don't write a detail record
        IF inOperationType = UPDATE_OPERATION THEN
            IF NVL(inAuditDetailRecord.new_value, '-x-DUMMY NULL-x-') = NVL(inAuditDetailRecord.old_value, '-x-DUMMY NULL-x-') THEN
                lDoAddDetail := false;
            END IF;
        END IF;
        RETURN lDoAddDetail;
    END Do_Audit_Detail_F;


    FUNCTION Do_Audit_Table_F(
        inTableName Audit_Header.table_name%TYPE)
        RETURN boolean
    IS
    	lCount INTEGER;
    BEGIN
        RETURN TRUE;
/*
        SELECT  COUNT(*)
          INTO  lCount
          FROM  Audit_Table_Includes
         WHERE  table_name = inTableName;

		IF lCount = 0 THEN
			RETURN FALSE;
		ELSE
			RETURN TRUE;
		END IF;
*/
    END Do_Audit_Table_F;


    FUNCTION Do_Audit_Column_F(
        inTableName IN Audit_Header.table_name%TYPE,
        inColumnName IN Audit_Detail.column_name%TYPE)
        RETURN boolean
    IS
    	lCount INTEGER;
    BEGIN
        RETURN TRUE;
/*
        SELECT  COUNT(*)
          INTO  lCount
          FROM  Audit_Column_Excludes
         WHERE  table_name = inTableName
           AND  column_name = inColumnName;

		IF lCount = 0 THEN
			RETURN TRUE;
		ELSE
			RETURN FALSE;
		END IF;
*/
    END Do_Audit_Column_F;


    PROCEDURE Insert_Audit_Header_P(
        inAuditHeaderRecord IN Audit_Header%ROWTYPE)
    IS
    BEGIN
        INSERT
          INTO  Audit_Header(
                audit_header_id,
                audit_operation_type,
                table_name,
                primary_key_field1,
                entry_date,
                user_party_id,
                process_name,
                audit_comment,
                audit_requestor,
                user_login_id)      -- sasteib added on 10/24/08
        VALUES (inAuditHeaderRecord.audit_header_id,
                inAuditHeaderRecord.audit_operation_type,
                inAuditHeaderRecord.table_name,
                inAuditHeaderRecord.primary_key_field1,
                inAuditHeaderRecord.entry_date,
                inAuditHeaderRecord.user_party_id,
                inAuditHeaderRecord.process_name,
                inAuditHeaderRecord.audit_comment,
                inAuditHeaderRecord.audit_requestor,
                inAuditHeaderRecord.user_login_id);     -- sasteib added on 10/24/08
    END Insert_Audit_Header_P;


    PROCEDURE Insert_Audit_Detail_P(
        inAuditDetailRecord IN Audit_Detail%ROWTYPE)
    IS
    BEGIN
        INSERT
          INTO  Audit_Detail(
                audit_detail_id,
                audit_header_id,
                column_name,
                new_value,
                old_value)
        VALUES (inAuditDetailRecord.audit_detail_id,
                inAuditDetailRecord.audit_header_id,
                inAuditDetailRecord.column_name,
                inAuditDetailRecord.new_value,
                inAuditDetailRecord.old_value);
    END Insert_Audit_Detail_P;


    PROCEDURE Insert_Audit_Staging_P(
        inAuditStagingRecord IN Audit_Staging_Info_Type)
    IS
    BEGIN
        INSERT
          INTO  Audit_Staging(
                oracle_sid,
                user_party_id,
                process_name,
                audit_comment,
                audit_requestor,
                user_login_id,      -- sasteib added on 10/27/08
                creation_timestamp,
                osuser,
                machine)
        VALUES (Get_Session_Id_F(),
                inAuditStagingRecord.user_party_id,
                inAuditStagingRecord.process_name,
                inAuditStagingRecord.audit_comment,
                inAuditStagingRecord.audit_requestor,
                inAuditStagingRecord.user_login_id, -- sasteib added on 10/27/08
                SYSDATE,
                Get_Session_OSUser_F(),
                Get_Session_Machine_F());
    END Insert_Audit_Staging_P;


    PROCEDURE Update_Audit_Staging_P(
        inAuditStagingRecord IN Audit_Staging_Info_Type)
    IS
    BEGIN
        UPDATE  Audit_Staging
           SET  user_party_id = inAuditStagingRecord.user_party_id,
                process_name = inAuditStagingRecord.process_name,
                audit_comment = inAuditStagingRecord.audit_comment,
                audit_requestor = inAuditStagingRecord.audit_requestor,
                user_login_id = inAuditStagingRecord.user_login_id,     -- sasteib added on 10/27/08
                creation_timestamp = SYSDATE,
                osuser = Get_Session_OSUser_F(),
                machine = Get_Session_Machine_F()
         WHERE  oracle_sid = Get_Session_Id_F();
    END Update_Audit_Staging_P;


    PROCEDURE Delete_Staging_Record_P
    IS
    BEGIN
        DELETE
          FROM  Audit_Staging
         WHERE  oracle_sid = Get_Session_Id_F();
    END Delete_Staging_Record_P;
    
    FUNCTION Get_Session_OSUser_F
    	RETURN Sys.V_$Session.osuser%TYPE    
	IS
        lOSUser Sys.V_$Session.osuser%TYPE;
    BEGIN
        SELECT  osuser
          INTO  lOSUser
          FROM  Sys.V_$Session
         WHERE  audsid = (
                SELECT  USERENV('sessionid')
                  FROM  DUAL);

        RETURN lOSUser;
    END Get_Session_OSUser_F;

    FUNCTION Get_Session_Machine_F
        RETURN Sys.V_$Session.machine%TYPE
	IS
        lMachine Sys.V_$Session.machine%TYPE;
    BEGIN
        SELECT  machine
          INTO  lMachine
          FROM  Sys.V_$Session
         WHERE  audsid = (
                SELECT  USERENV('sessionid')
                  FROM  DUAL);

        RETURN lMachine;
    END Get_Session_Machine_F;
END Audit_Pkg;
/

