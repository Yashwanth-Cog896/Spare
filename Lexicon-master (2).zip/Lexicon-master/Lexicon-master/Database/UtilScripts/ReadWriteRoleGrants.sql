GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.App_Role TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Audit_Detail TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Audit_Header TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Audit_Staging TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Bayer_Code TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Brand TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Comp_Prod_Batch TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Comp_Prod_Batch_Row TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Comp_Prod_Batch_Row_Status TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Company TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Country TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Crop TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Coml_Trait_Name2 TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Coml_Trait_Stack_Xref2 TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Coml_Trait_Stack2 TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Coml_Trait_Type TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Coml_Trait_Type_Xref2 TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Ctry_Reg_Region_Xref TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Event_Coml_Trait_Xref TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.DSR_Pull_Sync TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.DW_Default TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.DW_Subject_Area_Pull_Log TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.DW_Table_Pull_Log TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Base_Product TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Pre_Coml_Product TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Product TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Product_Collapse_Audit_Detail TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Product_Collapse_Audit_Header TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Product_Name TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Product_Stage TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Product_Relationship TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Product_Relationship_Xref TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Production_Status TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Regulatory_Agency TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Regulatory_Agency_Status TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Regulatory_Region TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Regulatory_Status_Type TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Regulatory_Sub_Country_Status TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Report TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Report_Execution TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Resource_Lock TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Sap_Linkage_Audit TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Stage TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Unit_Of_Measure TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Unit_Of_Measure_Lookup TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.User_App_Role TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.User_Preference TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.User_Preference_Value TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Vendor TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Vendor_Carrier TO Lexicon_RW_Role, Lexicon_User
/

GRANT SELECT ON Lexicon.Generic_Product_Name_View TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Generic_Product_View TO Lexicon_RW_Role, Lexicon_User
/

GRANT EXECUTE ON Lexicon.Audit_Pkg TO Lexicon_RW_Role
/
GRANT EXECUTE ON Lexicon.DSR_Pull TO Lexicon_RW_Role
/
GRANT EXECUTE ON Lexicon.Unique_Vendor_Name_Maint_Pkg TO Lexicon_RW_Role
/
GRANT EXECUTE ON Lexicon.Audit_Pkg TO Lexicon_User
/
GRANT EXECUTE ON Lexicon.DSR_Pull TO Lexicon_User
/
GRANT EXECUTE ON Lexicon.Unique_Vendor_Name_Maint_Pkg TO Lexicon_User
/

GRANT SELECT ON Lexicon.App_Role_ID_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Audit_Detail_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Audit_Header_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Bayer_Code_Id_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Bayer_Code_Pubkey_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Brand_Id_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Brand_Pubkey_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Coml_Trait_Name_Id_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Coml_Trait_Stack_Id_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Coml_Trait_Stack_Pubkey_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Coml_Trait_Stack_Xref_Id_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Coml_Trait_Type_Id_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Coml_Trait_Type_Xref_Id_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Comp_Prod_Batch_Id_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Comp_Prod_Batch_Row_Id_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Company_Id_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Company_Pubkey_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Country_Id_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Country_Pubkey_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Crop_Id_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Crop_Pubkey_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Ctry_Reg_Region_Xref_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Event_Coml_Trait_Xref_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Base_Product_Id_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Pre_Coml_Product_Pubkey_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Prod_Collpse_Audit_Dtl_Id_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Prod_Collpse_Audit_Hdr_id_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Product_Pubkey_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Product_Name_Pubkey_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Product_Pubkey_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Product_Relationship_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Product_Rel_Pubkey_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Product_Relationship_Xref_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Production_Status_Id_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Regulatory_Agency_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Regulatory_Agency_Pubkey_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Regulatory_Agency_Status_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Regulatory_Region_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Regulatory_Region_Pubkey_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Regulatory_SC_Status_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Report_Execution_ID_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Report_ID_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Resource_Lock_ID_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Sap_Linkage_Audit_Id_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Stage_ID_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Stage_Pubkey_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Unique_Product_ID_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Unique_Product_Name_ID_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.User_App_Role_ID_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.User_Preference_ID_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.User_Preference_Value_ID_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Variety_Name_Seq TO Lexicon_RW_Role, Lexicon_User
/

/* ARGOT Objects */
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Additional_Material TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Chemical_Name TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Container_Type TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.External_Contact TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Formulation_Type TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Genetic_Background TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Molecular_Description TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Mon_Number TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Plant_Name TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Protein_Name TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Sample_Type TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Shipping_Condition TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Storage_Condition TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Storage_Location TO Lexicon_RW_Role, Lexicon_User
/

/* Argot Objects */
GRANT SELECT ON Lexicon.Additional_Material_Id_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Chemical_Name_Id_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Container_Type_Id_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.External_Contact_Id_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Formulation_Type_Id_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Genetic_Background_Id_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Molecular_Description_Id_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Mon_Number_Id_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Plant_Name_Id_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Protein_Name_Id_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Sample_Type_Id_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Shipping_Condition_Id_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Storage_Cond_Id_Seq TO Lexicon_RW_Role, Lexicon_User
/
GRANT SELECT ON Lexicon.Storage_Location_Id_Seq TO Lexicon_RW_Role, Lexicon_User
/


