CREATE or replace SYNONYM resource_lock FOR LEXICON.resource_lock;

CREATE or replace SYNONYM resource_lock_id_seq FOR LEXICON.resource_lock_id_seq;

