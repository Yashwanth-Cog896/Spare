DROP SEQUENCE Resource_lock_id_seq;

drop table RESOURCE_LOCK cascade constraints;


