GRANT SELECT, INSERT, UPDATE, DELETE ON Company TO Lexicon_User, ngscho;
GRANT SELECT ON Company_pubkey_seq to Lexicon_user, ngscho;
GRANT SELECT on company_id_seq to Lexicon_user, ngscho;

GRANT SELECT, INSERT, UPDATE, DELETE ON Brand TO Lexicon_User, ngscho;
GRANT SELECT ON brand_pubkey_seq TO Lexicon_User, ngscho;
GRANT SELECT ON brand_id_seq TO Lexicon_User, ngscho;

GRANT SELECT, INSERT, UPDATE, DELETE ON Country TO Lexicon_User, ngscho;
GRANT SELECT, INSERT, UPDATE, DELETE ON Crop TO Lexicon_User, ngscho;
GRANT SELECT, INSERT, UPDATE, DELETE ON Bayer_Code TO Lexicon_User, ngscho;
--GRANT SELECT, INSERT, UPDATE, DELETE ON Product_Stage TO Lexicon_User;
--GRANT SELECT, INSERT, UPDATE, DELETE ON Trait TO Lexicon_User, ngscho;
