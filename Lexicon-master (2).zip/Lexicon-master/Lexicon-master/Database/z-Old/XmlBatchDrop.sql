DROP sequence comp_prod_batch_id_seq;
DROP sequence comp_prod_batch_row_id_seq;

drop table comp_prod_batch_row_status cascade constraints;
drop table comp_prod_batch_row cascade constraints;
drop table comp_prod_batch cascade constraints;


