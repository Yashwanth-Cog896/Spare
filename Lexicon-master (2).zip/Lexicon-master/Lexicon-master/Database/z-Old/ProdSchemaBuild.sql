CREATE SEQUENCE product_pubkey_seq
INCREMENT BY 100
START WITH 1002
NOMAXVALUE
NOMINVALUE
CACHE 30
NOCYCLE
NOORDER
;

CREATE SEQUENCE product_ID_seq
INCREMENT BY 1
START WITH 1000
NOMAXVALUE
NOMINVALUE
CACHE 30
NOCYCLE
NOORDER
;

CREATE SEQUENCE product_NAME_pubkey_seq
INCREMENT BY 100
START WITH 1007
NOMAXVALUE
NOMINVALUE
CACHE 30
NOCYCLE
NOORDER
;

CREATE SEQUENCE product_NAME_ID_seq
INCREMENT BY 1
START WITH 1000
NOMAXVALUE
NOMINVALUE
CACHE 30
NOCYCLE
NOORDER
;

CREATE SEQUENCE equiv_product_name_id_seq
INCREMENT BY 1
START WITH 1000
NOMAXVALUE
NOMINVALUE
CACHE 30
NOCYCLE
NOORDER
;


CREATE TABLE Product(
    product_id                      NUMBER NOT NULL,
    product_pubkey                  VARCHAR2(20) NOT NULL,
    crop_id                         NUMBER NOT NULL,
    
	CONSTRAINT Product_PK
		PRIMARY KEY (product_id)
		USING INDEX
	TABLESPACE  Lexicon_Index,
	
	CONSTRAINT Product_AK1
		UNIQUE (product_pubkey)
		USING INDEX
	TABLESPACE  Lexicon_Index
)
TABLESPACE Lexicon_Data;

CREATE TABLE Product_Name(
	product_name_id                 NUMBER NOT NULL,
	product_name_pubkey             VARCHAR2(20) NOT NULL,
	product_name                    VARCHAR2(50) NOT NULL,
	product_id                      NUMBER NOT NULL,
	coml_trait_stack_id             NUMBER NULL,
	bayer_code_id                   NUMBER NOT NULL,
	country_id                      NUMBER NOT NULL,
	brand_id                        NUMBER NOT NULL,
	commercial_maturity             NUMBER(6,1),
	verified_data_source            VARCHAR2(20),
	data_source_year                NUMBER,
	comments                        VARCHAR2(2000),
	is_active                       VARCHAR2(1) NOT NULL
		CONSTRAINT Trueorfalse204
			CHECK (is_active IN ('y', 'n')),    

	CONSTRAINT Product_Name_PK
		PRIMARY KEY (product_name_id)
		USING INDEX
	TABLESPACE  Lexicon_Index,

	CONSTRAINT Product_Name_AK1
		UNIQUE (product_name, bayer_code_id, country_id, brand_id)
		USING INDEX
	TABLESPACE Lexicon_Index,
        
	CONSTRAINT Product_Name_AK2
		UNIQUE (product_name_pubkey)
		USING INDEX
	TABLESPACE Lexicon_Index
)
TABLESPACE Lexicon_Data;

CREATE INDEX Product_Name_IDX1 ON Product_Name(
	brand_id                        ASC
)
TABLESPACE Lexicon_Index;

CREATE INDEX Product_Name_IDX2 ON Product_Name(
	bayer_code_id                   ASC
)
TABLESPACE Lexicon_Index;

CREATE INDEX Product_Name_IDX3 ON Product_Name(
	country_id                      ASC
)
TABLESPACE Lexicon_Index;


CREATE TABLE Equiv_Product_Name(
   equiv_product_name_id           NUMBER NOT NULL,
   active_product_name_id          NUMBER NOT NULL,
   inactive_product_name_id        NUMBER NOT NULL,
	comments                        VARCHAR2(2000) NOT NULL,

	CONSTRAINT Equiv_Product_Name_PK
		PRIMARY KEY (equiv_product_name_id)
		USING INDEX
	TABLESPACE  Lexicon_Index,

	CONSTRAINT Equiv_Product_Name_AK1
		UNIQUE (active_product_name_id, inactive_product_name_id)
		USING INDEX
	TABLESPACE Lexicon_Index

)
TABLESPACE Lexicon_data;


CREATE TABLE Midas_Dup_Product_Name(
	name               VARCHAR2(50) NOT NULL,
	brand_pk                 NUMBER NOT NULL,
	country_pk               NUMBER NOT NULL,
	product_pk               NUMBER NOT NULL,
	group_no                 NUMBER NOT NULL

)
TABLESPACE Lexicon_Data;




ALTER TABLE Product
	ADD CONSTRAINT FK_Prod_Crop_CropId
		FOREIGN KEY (crop_id)
		REFERENCES Crop (crop_id);

ALTER TABLE Product_Name
	ADD CONSTRAINT FK_ProdName_Prod_ProdId
		FOREIGN KEY (product_id)
		REFERENCES Product (product_id);

ALTER TABLE Product_Name
	ADD CONSTRAINT FK_ProdName_BayerCd_BayerCdId 
		FOREIGN KEY (bayer_code_id)
		REFERENCES Bayer_Code (bayer_code_id);

ALTER TABLE Product_Name
	ADD CONSTRAINT FK_ProdName_Brand_BrandId 
		FOREIGN KEY (brand_id)
		REFERENCES Brand (brand_id);

ALTER TABLE Product_Name
	ADD CONSTRAINT FK_Prod_Name_Country_CountryId 
		FOREIGN KEY (country_id)
		REFERENCES Country (country_id);

ALTER TABLE Equiv_product_name
	ADD CONSTRAINT FK_Equiv_Prod_Name_Active_id
		FOREIGN KEY (active_product_name_id)
		REFERENCES Product_Name (Product_Name_Id);

ALTER TABLE Equiv_product_name
	ADD CONSTRAINT FK_Equiv_Prod_Name_Inactive_id
		FOREIGN KEY (inactive_product_name_id)
		REFERENCES Product_Name (Product_Name_Id);



