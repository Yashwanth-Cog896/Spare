BEGIN
    DECLARE
        CURSOR curs IS
            SELECT CTSX.coml_trait_stack_id AS StackId, 
                   CTN.coml_trait_name_abbr AS TraitAbbr,
                   CTSX.stack_order AS StackOrder,
                   CTS.crop_id AS CropId
              FROM Coml_Trait_Stack_Xref CTSX,
                   Coml_Trait_Name CTN,
                   Coml_Trait_Stack CTS
             WHERE CTN.coml_trait_name_id = CTSX.coml_trait_name_id
               AND CTS.coml_trait_stack_id = CTSX.coml_trait_stack_id
         ORDER BY CTSX.coml_trait_stack_id, CTSX.stack_order;
    
         currStackName Coml_Trait_Stack_Name_Xref.value%TYPE;
         currStackId Coml_Trait_Stack_Name_Xref.coml_trait_stack_id%TYPE;
         currCropId Coml_Trait_Stack.crop_id%TYPE;
         dynamicSQL VARCHAR2(200);
         
    BEGIN
        dynamicSQL := 'DELETE FROM Coml_Trait_Stack_Name_Xref WHERE name_type = ''G''';
        DBMS_OUTPUT.put_line(dynamicSQL);
        EXECUTE IMMEDIATE dynamicSQL;
        
        currStackId := -1;
        currCropId := -1;
        currStackName := NULL;    
        dynamicSQL := 'INSERT INTO Coml_Trait_Stack_Name_Xref' || '(trait_stack_name_xref_id, coml_trait_stack_id, crop_id, name_type, value) ' || 'VALUES(trait_stack_name_xref_id_seq.NEXTVAL, :id, :crop, ''G'', :name)';
        DBMS_OUTPUT.put_line(dynamicSQL);

        FOR rec IN curs
        LOOP
            IF rec.StackId <> currStackId 
            THEN
                IF currStackName IS NOT NULL
                THEN
                    DBMS_OUTPUT.put_line('StackId:' || currStackId || '  CropId:' || currCropId || '  StackName:' || currStackName);
                    EXECUTE IMMEDIATE dynamicSQL USING currStackId, currCropId, currStackName;
                END IF;
                currStackId := rec.StackId;
                currCropId := rec.CropId;
                currStackName := rec.TraitAbbr;
            ELSE
                currStackName := currStackName || '/' || rec.TraitAbbr;
            END IF;            
        END LOOP;

        IF currStackName IS NOT NULL
        THEN
            DBMS_OUTPUT.put_line('StackId:' || currStackId || '  CropId:' || currCropId || '  StackName:' || currStackName);
            EXECUTE IMMEDIATE dynamicSQL USING currStackId, currCropId, currStackName;
        END IF;
    END;
END;


