
-- COUNTRY CHECKS
-- check country cross reference
select count(*) from fbs_common.Country_xref@prem_tst fbsc;

-- detail to verify names.
select FBSC.Lexicon_country_pubkey, lc.country_name, lc.country_abbr, rc.country_abbrev, rc.country_name, 
       mc.name

from fbs_common.Country_xref@prem_tst fbsc, 
     lexicon.country lc, 
     midas.country@prem_tst mc, 
     mirage.countries@ceregn_tst rc
     
where fbsc.lexicon_country_pubkey = lc.country_pubkey
     and fbsc.midas_country_id = mc.country_id
     and fbsc.mirage_country_code = rc.country_code;
 
-- BRAND CHECKS  

-- Count active brands in Midas

-- Count companies in Mirage that are seed companies.

-- Find brands missing from Mirage.

-- Find brands missing from Midas.

-- 



  
-- check brand cross reference
select count(*) from fbs_common.brand_xref@prem_tst fbsb;

-- detail to compare names
select fbsb.Lexicon_brand_pubkey,  fbsb.Midas_brand_id, fbsb.Mirage_company_id,
      lb.brand_name, lb.brand_abbr,
    rb.company_name, rb.company_abbrev, 
      mb.name

from  fbs_common.brand_xref@prem_tst fbsb,
      lexicon.brand lb,
      midas.brand@prem_tst mb,
      mirage2.companies@ceregn_tst rb
      
where  fbsb.lexicon_brand_pubkey = lb.brand_pubkey
      and  fbsb.midas_brand_id = mb.brand_id
      and fbsb.mirage_company_id = rb.company_id (+);
     
-- MINOR CROP CHECKS for PRODUCT   
-- count minor crop products in Lexicon.

select count(*)
from lexicon.product_name pn, lexicon.product p, lexicon.bayer_code bc
where pn.product_id = p.product_id 
  and p.bayer_code_id = bc.bayer_code_id
  and bc.bayer_code_name not in ('ZEAMD', 'GLXMA', 'HELAN', 'SORGR', 'SORCU', 'BRSNW', 'BRSNC', 'GOSHI');
 
 
-- Count rows in fbs_common.product_name_xref for minor crop products.

select count(*) 
from (select lbc.bayer_code_name, lb.brand_name, lpn.product_name, lctry.country_name, 
       sp.crop_bayer_code, rb.company_name, sp.product_name, rctry.country_name

from fbs_common.product_name_xref@prem_tst fbspn,
     lexicon.product lp,
     lexicon.product_name lpn,
     lexicon.brand lb, 
     mirage2.seed_products@ceregn_tst sp,
     mirage2.companies@ceregn_tst rb,
     lexicon.country lctry,
     mirage2.countries@ceregn_tst rctry,
     lexicon.bayer_code lbc
    
where fbspn.lexicon_product_name_pubkey = lpn.product_name_pubkey
  and lpn.product_id = lp.product_id
  and lpn.brand_id = lb.brand_id
  and fbspn.mirage_product_id = sp.product_id
  and sp.company_id = rb.company_id
  and lpn.country_id = lctry.country_id
  and sp.country_code = rctry.country_code
  and lp.bayer_code_id = lbc.bayer_code_id
  and lbc.bayer_code_name not in ('ZEAMD', 'GLXMA', 'HELAN', 'SORGR', 'SORCU', 'BRSNW', 'BRSNC', 'GOSHI'));  

-- check that product names for minor crops are cross referenced correctly in FBS_Common

select lbc.bayer_code_name, lb.brand_name, lpn.product_name, lctry.country_name, 
       sp.crop_bayer_code, rb.company_name, sp.product_name, rctry.country_name

from fbs_common.product_name_xref@prem_tst fbspn,
     lexicon.product lp,
     lexicon.product_name lpn,
     lexicon.brand lb, 
     mirage2.seed_products@ceregn_tst sp,
     mirage2.companies@ceregn_tst rb,
     lexicon.country lctry,
     mirage2.countries@ceregn_tst rctry,
     lexicon.bayer_code lbc
    
where fbspn.lexicon_product_name_pubkey = lpn.product_name_pubkey
  and lpn.product_id = lp.product_id
  and lpn.brand_id = lb.brand_id
  and fbspn.mirage_product_id = sp.product_id
  and sp.company_id = rb.company_id
  and lpn.country_id = lctry.country_id
  and sp.country_code = rctry.country_code
  and lp.bayer_code_id = lbc.bayer_code_id
  and lbc.bayer_code_name not in ('ZEAMD', 'GLXMA', 'HELAN', 'SORGR', 'SORCU', 'BRSNW', 'BRSNC', 'GOSHI');  
  
-- Count all minor crop active competitive products in Mirage (not including old product in equivalence).

select count(*)
from mirage2.seed_products@ceregn_tst sp,
     mirage2.companies@ceregn_tst c,
     mirage2.seed_products@ceregn_tst eqsp
where sp.company_id = c.company_id
   and sp.enabled = 'Y'
   and sp.product_id = eqsp.equivalent_product_id (+)
   and eqsp.equivalent_product_id is null 
   and sp.crop_bayer_code not in ('ZEAMD', 'GLXMA', 'SORGR', 'SORCU', 'HELAN', 'GOSHI', 'BRSNW', 'BRSNC')
   and company_name not in ('AGROCERES', 'ASGROW', 'CARNIA', 'CERES', 'CORN STATES', 'CORN STATES INTERNATIONAL',
           'DEKALB', 'DEKASOL', 'FIRST LINE', 'HARTZ', 'MONSOY', 'SENSAKO', 'MONSANTO', 'HOLDEN''S', 'UNKNOWN') ;
  
  
  
-- MAJOR CROP CHECKS for PRODUCT 
-- count major crop products in Lexicon.

select count(*) 
from lexicon.product_name pn, 
     lexicon.product p, 
     lexicon.bayer_code bc
where pn.product_id = p.product_id 
  and p.bayer_code_id = bc.bayer_code_id
  and bc.bayer_code_name in ('ZEAMD', 'GLXMA', 'HELAN', 'SORGR', 'SORCU', 'BRSNW', 'BRSNC', 'GOSHI');

-- Count rows in fbs_common.product_name_xref for major crop products.

select count(*) 
from (select lbc.bayer_code_name, lb.brand_name, lpn.product_name, lctry.country_name, 
       mc.name "Crop", mb.name "brandname", mpn.name "prodname", mctry.name "countryname", 
       sp.crop_bayer_code, rb.company_name, sp.product_name, rctry.country_name --,
  --     mpm.old_brand_name, mpm.Mirage_name
       
from fbs_common.product_name_xref@prem_tst fbspn,
     fbs_common.product_xref@prem_tst fbsp,
	 lexicon.product lp,
     lexicon.product_name lpn,
     lexicon.brand lb, 
     mirage2.seed_products@ceregn_tst sp,
     mirage2.companies@ceregn_tst rb,
     lexicon.country lctry,
     mirage2.countries@ceregn_tst rctry,
     lexicon.bayer_code lbc,
     midas.product@prem_tst mp,
     midas.product_name@prem_tst mpn,
     midas.brand@prem_tst mb,
     midas.country@prem_tst mctry,
     midas.crop@prem_tst mc --,
--     yldstg.map_product_mirage@prem_tst mpm
    
where fbsp.lexicon_product_pubkey = lp.product_pubkey
  and fbspn.lexicon_product_name_pubkey = lpn.product_name_pubkey
  and fbsp.midas_product_id = mp.product_id
--  and mp.product_id = mpm.product_pk
  and fbspn.midas_product_name_id = mpn.product_name_id
  and mp.product_id = mpn.product_id
  and mpn.brand_id = mb.brand_id
  and mpn.country_id = mctry.country_id
  and lpn.product_id = lp.product_id
  and mp.crop_id = mc.crop_id
  and lpn.brand_id = lb.brand_id
  and lpn.country_id = lctry.country_id
  and fbspn.mirage_product_id = sp.product_id
  and sp.company_id = rb.company_id
  and sp.country_code = rctry.country_code
  and lp.bayer_code_id = lbc.bayer_code_id
  and lbc.bayer_code_name in ('ZEAMD', 'GLXMA', 'HELAN', 'SORGR', 'SORCU', 'BRSNW', 'BRSNC', 'GOSHI'));
  

-- check that product and product names for major crops are cross referenced correctly in FBS_Common

select lbc.bayer_code_name, lb.brand_name, lpn.product_name, lctry.country_name, 
       mc.name "Crop", mb.name "brandname", mpn.name "prodname", mctry.name "countryname", 
       sp.crop_bayer_code, rb.company_name, sp.product_name, rctry.country_name --,
  --     mpm.old_brand_name, mpm.Mirage_name
       
from fbs_common.product_name_xref@prem_tst fbspn,
     fbs_common.product_xref@prem_tst fbsp,
	 lexicon.product lp,
     lexicon.product_name lpn,
     lexicon.brand lb, 
     mirage2.seed_products@ceregn_tst sp,
     mirage2.companies@ceregn_tst rb,
     lexicon.country lctry,
     mirage2.countries@ceregn_tst rctry,
     lexicon.bayer_code lbc,
     midas.product@prem_tst mp,
     midas.product_name@prem_tst mpn,
     midas.brand@prem_tst mb,
     midas.country@prem_tst mctry,
     midas.crop@prem_tst mc --,
--     yldstg.map_product_mirage@prem_tst mpm
    
where fbsp.lexicon_product_pubkey = lp.product_pubkey
  and fbspn.lexicon_product_name_pubkey = lpn.product_name_pubkey
  and fbsp.midas_product_id = mp.product_id
--  and mp.product_id = mpm.product_pk
  and fbspn.midas_product_name_id = mpn.product_name_id
  and mp.product_id = mpn.product_id
  and mpn.brand_id = mb.brand_id
  and mpn.country_id = mctry.country_id
  and lpn.product_id = lp.product_id
  and mp.crop_id = mc.crop_id
  and lpn.brand_id = lb.brand_id
  and lpn.country_id = lctry.country_id
  and fbspn.mirage_product_id = sp.product_id
  and sp.company_id = rb.company_id
  and sp.country_code = rctry.country_code
  and lp.bayer_code_id = lbc.bayer_code_id
  and lbc.bayer_code_name in ('ZEAMD', 'GLXMA', 'HELAN', 'SORGR', 'SORCU', 'BRSNW', 'BRSNC', 'GOSHI');
  
--  Count all competitor crops in Midas production
-- 1st. product

select  count(distinct p.product_id)
from midas.product@prem p,
	 midas.product_name@prem pn,
     midas.brand@prem b,
     midas.company@prem c
where p.product_id = pn.product_id
and   pn.brand_id = b.brand_id
and   b.company_id = c.company_id
and   c.name <> 'MONSANTO'
and   b.ref_active = 'T' and pn.ref_active = 'T' and p.ref_active = 'T';


-- 2nd. product_name

select count(*)
from midas.product_name@prem pn,
     midas.brand@prem b,
     midas.company@prem c
where pn.brand_id = b.brand_id
and   b.company_id = c.company_id
and   c.name <> 'MONSANTO'
and   b.ref_active = 'T' and pn.ref_active = 'T';


-- Count all competitor crops in Yldmart production
-- 1st. product

select  count(distinct p.product_pk)
from yldmart.product@prem p,
  	 yldmart.product_name@prem pn,
     yldmart.brand@prem b,
     yldmart.company@prem c
where p.product_pk = pn.product_pk
and   pn.brand_pk = b.brand_pk
and   b.company_pk = c.company_pk
and   c.name <> 'MONSANTO';

-- Count all competitor crops in Yldmart production
-- 2nd. product name

select  count(*)
from yldmart.product_name@prem pn,
     yldmart.brand@prem b,
     yldmart.company@prem c
where pn.brand_pk = b.brand_pk
and   b.company_pk = c.company_pk
and   c.name <> 'MONSANTO';


-- Midas and Yldmart should have the same number of competitive products.

-- Patro's query - checks for product names existing in Midas, not in Yldmart.
     
SELECT mpn.*, mb.NAME brand, mb.REF_ACTIVE brand_ref_active, 
		 mc.NAME company, mc.REF_ACTIVE company_ref_active 
FROM midas.product_name@prem mpn,
	  yldmart.product_name@prem ypn,
	  midas.brand@prem mb,
	  midas.company@prem mc
WHERE mpn.ref_active = 'T'
AND ypn.PRODUCT_NAME_PK (+) = mpn.PRODUCT_NAME_ID
AND mpn.BRAND_ID = mb.brand_id
AND mb.COMPANY_ID = mc.COMPANY_ID
AND mc.NAME <> 'MONSANTO'
AND ypn.PRODUCT_NAME_PK IS NULL

-- my version of Patro's query - checks for product names existing in Yldmart, not in Midas.
     
SELECT ypn.* 
FROM  midas.product_name@prem mpn,
	  yldmart.product_name@prem ypn,
	  yldmart.brand@prem mb,
	  yldmart.company@prem mc
WHERE  ypn.PRODUCT_NAME_PK  = mpn.PRODUCT_NAME_ID (+)
   AND ypn.BRAND_PK = mb.brand_PK
   AND mb.COMPANY_PK = mc.COMPANY_PK
   AND mc.NAME <> 'MONSANTO'
   AND mpn.PRODUCT_NAME_id IS NULL
   
-- Count all competitor product (names) for major crops in Mirage, removing inactive products and old name equivalents

select count(*)
from mirage2.seed_products@ceregn_tst sp,
     mirage2.companies@ceregn_tst c,
     mirage2.seed_products@ceregn_tst eqsp
where sp.company_id = c.company_id
and sp.enabled = 'Y'
and sp.product_id = eqsp.equivalent_product_id (+)
       and eqsp.equivalent_product_id is null 
and   sp.crop_bayer_code in ('ZEAMD', 'GLXMA', 'SORGR', 'SORCU', 'HELAN', 'GOSHI', 'BRSNW', 'BRSNC')
and   company_name not in ('AGROCERES', 'ASGROW', 'CARNIA', 'CERES', 'CORN STATES', 'CORN STATES INTERNATIONAL',
           'DEKALB', 'DEKASOL', 'FIRST LINE', 'HARTZ', 'MONSOY', 'SENSAKO', 'MONSANTO', 'HOLDEN''S', 'UNKNOWN') ;
           
-- Count competitive products mapped in yldstg mapping table to Mirage2, when product_names match, 
--   ignoring the old product in equivalent product, and inactive products in Mirage.

select count(*)
from yldstg.map_product_mirage@prem_tst mpm,
     mirage2.seed_products@ceregn_tst sp,
     mirage2.seed_products@ceregn_tst eqsp,
     yldmart.product@prem_tst yp,
     yldmart.product_name@prem_tst ypn,
     yldmart.brand@prem_tst yb,
     yldmart.company@prem_tst yc,
     fbs_common.country_xref@prem_tst fbsc
where mpm.seed_product_id = sp.product_id
  and mpm.product_pk = yp.product_pk
  and yp.product_pk = ypn.product_pk
  and ypn.brand_pk = yb.brand_pk
  and yb.company_pk = yc.company_pk
  and yc.name <> 'MONSANTO'
  and sp.country_code = fbsc.mirage_country_code
  and fbsc.midas_country_id = ypn.country_pk
  and ypn.name = sp.product_name
  and sp.enabled = 'Y'
  and sp.product_id = eqsp.equivalent_product_id (+)
  and eqsp.equivalent_product_id is null ;


           

