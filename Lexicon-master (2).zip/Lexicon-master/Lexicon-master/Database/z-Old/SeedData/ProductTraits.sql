-- Load product commercial traits from Mirage.
-- Run after the MajorCropProduct and MinorCropProduct has run, and loaded products to Product_name.
-- Run after commercial traits tables are loaded.

-- Step 1: 

-- Run to switch the Lexicon country names to the Mirage country names.

 Update Lexicon.country set country_name = 'UNITED STATES' where country_name = 'UNITED STATES OF AMERICA';
 Update Lexicon.country set country_name = 'UNITED KINGDOM' 
     where country_name = 'UNITED KINGDOM OF GREAT BRITAIN AND NORTHERN IRELA';
 Update Lexicon.country set country_name = 'RUSSIA' where country_name = 'RUSSIAN FEDERATION';
 Update Lexicon.country set country_name = 'REPUBLICA DOMINICANA' where country_name = 'DOMINICAN REPUBLIC';
 Update Lexicon.country set country_name = 'FRENCH GUYANA' where country_name = 'FRENCH GUIANA';
 Update Lexicon.country set country_name = 'GUADALOUPE' where country_name = 'GUADELOUPE';
 Update Lexicon.country set country_name = 'ANTIGUA & BARBUDA' where country_name = 'ANTIGUA AND BARBUDA';
 Update Lexicon.country set country_name = 'TRINIDAD & TOBAGO' where country_name = 'TRINIDAD AND TOBAGO';
 Update Lexicon.country set country_name = 'LAOS' where country_name = 'LAO PEOPLE''S DEMOCRATIC REPUBLIC';
 Update Lexicon.country set country_name = 'TANZANIA' where country_name = 'UNITED REPUBLIC OF TANZANIA';
 Update Lexicon.country set country_name = 'VIETNAM' where country_name = 'VIET NAM';
-- Step 2:  Remove coml_trait_stack_id from Lexicon Product_name table.

update lexicon.mirage_seed_product_name set triat = null;
update lexicon.product_name set coml_trait_stack_id = null;
 

-- Step 3: Setup query, run to find all stacks coming from Mirage data.  (Only certain traits are loaded from the 
--         Attributes table.)  This query will show all data, even some stacks we won't load.

select 
       kw.name  "Trait",
	   kw.value  "Trait desc",
	   sp.crop_Bayer_code "Product Crop",  
	   a.bayer_code "Attr Crop",
	   a.description "Attr desc",
	   count(*)

from lexicon.mirage_seed_product_name lmspn,
     lexicon.mirage_minorcrop_compet_comp mmcc,
	 mirage2.seed_products@ceregn sp, 
     mirage2.seed_products_attributes@ceregn pa, 
     mirage2.attributes@ceregn a, 
	 mirage2.kw@ceregn kw
	 
where   lmspn.company_name = mmcc.company_name
    and lmspn.product_id = sp.product_id
	and sp.product_id = pa.product_id(+) 
    and pa.attribute_id = a.attribute_id(+)
    and sp.trait_characteristic_code = kw.code

group by  
         kw.name,
	     kw.value, 
	     sp.crop_bayer_code,
	     a.bayer_code,
	     a.description
order by kw.name, a.description
;

-- Step 4: Count trait records from Mirage using the Trait_Characteristic_Code in Seed_Products.
--         These traits will be loaded into Lexicon.Mirage_Seed_Product_Name table.  In subsequent steps,
--         we'll get the attributes, and concatenate them to the trait stored in Mirage_Seed_Product_Name 
--         when we're loading to Lexicon.Product_Name.

select count(*)
--      sp.product_id, sp.product_name, sp.enabled, sp.trait_characteristic_code, sp.equivalent_product_id,
--      kw.name as trait_abbr, kw.value as trait_desc, a.attribute_name, a.description

from lexicon.mirage_seed_product_name lmspn,
     lexicon.mirage_minorcrop_compet_comp mmcc,
	 mirage2.seed_products@ceregn sp, 
	 mirage2.kw@ceregn kw

where lmspn.company_name = mmcc.company_name
    and lmspn.product_id = sp.product_id
    and sp.trait_characteristic_code = kw.code

   and kw.name not in ('NON-TRANSGENIC', 'UNKNOWN', 'UNK')
    ;
    
-- Step 5: Update trait in Lexicon.Mirage_Seed_Product_Name from Mirage trait characteristics code.
begin
declare
str VARCHAR2(500);

CURSOR c_map  IS
   SELECT  lmspn.product_name_id, kw.name as trait
   from lexicon.mirage_seed_product_name lmspn,
     lexicon.mirage_minorcrop_compet_comp mmcc,
	 mirage2.seed_products@ceregn sp,  
	 mirage2.kw@ceregn kw
    
 where lmspn.company_name = mmcc.company_name
    and lmspn.product_id = sp.product_id
    and sp.trait_characteristic_code = kw.code
     and kw.name not in ('NON-TRANSGENIC', 'UNKNOWN', 'UNK')
;	 
         
begin
  FOR rec IN c_map LOOP
 
    str := 'update lexicon.mirage_seed_product_name set triat = :trt where product_name_id = :prod_name_id'; 
    execute immediate str using rec.trait, rec.product_name_id;
  end loop;
end;
end;

-- Step 6: Check row count where trait was loaded.

select count(*)
from lexicon.Mirage_Seed_Product_name lmspn,
     lexicon.mirage_minorcrop_compet_comp mmcc
where lmspn.company_name = mmcc.company_name and lmspn.triat is not null
     ;
-- double check the trait stacks loaded thus far.
     
select lmspn.triat, count(*)
from lexicon.mirage_seed_Product_Name lmspn
where lmspn.triat is not null
group by lmspn.triat order by lmspn.triat;
                    
-- Step 7:  Concatenate attributes to traits in Lexicon.Mirage_Seed_product_name.
-- This query gives us a previow of the results of the load in the query following this query.
select distinct sp.product_id, lmspn.triat, 
        decode(a.description, 
		       'SOYBEAN CYST NEMATODE RESISTANCE', 'SCN',
		       'HURCULEX I', 'HX',
		        'HERCULEX I', 'HX',
                'NATUREGARD', 'NG',
                'FOOD GRADE', 'FG',
                'HIGH LYSINE', 'LY',
                'HIGH OIL', 'HO',
                'NUSUN', 'NUSUN',
                'HIGH PROTIEN', 'HP', -- was spelled wrong in MIRAGE
                'PHYTOPTHORA ROOT ROT RESISTANCE', 'PRR', -- was spelled wrong in MIRAGE
                'PHTOPHTHORA ROOT ROT RESISTANCE', 'PRR', -- was spelled wrong in MIRAGE
                'PHYTOPHTHORA ROOT ROT RESISTANCE', 'PRR', -- correct spelling
                'SOYBEAN CYST NEMATODE RESISTANCE', 'SCN',
                'WAXY', 'WAXY',
                'WHITE CORN', 'WHITE',
                'RR FLEX' , 'RRFLEX', 
		       'NOT FOUND') attrib
from lexicon.mirage_seed_product_name lmspn,
     lexicon.mirage_minorcrop_compet_comp mmcc,
	 mirage2.seed_products@ceregn sp, 
     mirage2.seed_products_attributes@ceregn pa, 
     mirage2.attributes@ceregn a
   
where lmspn.company_name = mmcc.company_name
    and lmspn.product_id = sp.product_id
    and sp.product_id = pa.product_id 
    and pa.attribute_id = a.attribute_id

     and a.description in ('HURCULEX I', 'HERCULEX I','NATUREGARD', 'FOOD GRADE', 'HIGH LYSINE', 'HIGH OIL', 'NUSUN', 
                         'HIGH PROTIEN',
                        'PHYTOPTHORA ROOT ROT RESISTANCE', 'PHYTOPHTHORA ROOT ROT RESISTANCE', 
			           'PHTOPHTHORA ROOT ROT RESISTANCE',
			             'SOYBEAN CYST NEMATODE RESISTANCE', 'WAXY', 'WHITE CORN')

order by sp.product_id, attrib                     
;


begin
declare
prod_id    NUMBER;
tmpAttrib  VARCHAR2(30);
str        VARCHAR2(1500);

CURSOR c_map  IS
select distinct sp.product_id, lmspn.triat, 
        decode(a.description, 
		       'SOYBEAN CYST NEMATODE RESISTANCE', 'SCN',
		       'HURCULEX I', 'HX',
		       'HERCULEX I', 'HX',
                'NATUREGARD', 'NG',
                'FOOD GRADE', 'FG',
                'HIGH LYSINE', 'LY',
                'HIGH OIL', 'HO',
                'NUSUN', 'NUSUN',
                'HIGH PROTIEN', 'HP', -- was spelled wrong in MIRAGE
                'PHYTOPTHORA ROOT ROT RESISTANCE', 'PRR', -- was spelled wrong in MIRAGE
                'PHTOPHTHORA ROOT ROT RESISTANCE', 'PRR', -- was spelled wrong in MIRAGE
                'PHYTOPHTHORA ROOT ROT RESISTANCE', 'PRR', -- correct spelling
                'SOYBEAN CYST NEMATODE RESISTANCE', 'SCN',
                'WAXY', 'WAXY',
                'WHITE CORN', 'WHITE',
                'RR FLEX' , 'RRFLEX', 
		        'NOT FOUND') attrib
		        
from lexicon.mirage_seed_product_name lmspn,
     lexicon.mirage_minorcrop_compet_comp mmcc,
	 mirage2.seed_products@ceregn sp, 
     mirage2.seed_products_attributes@ceregn pa, 
     mirage2.attributes@ceregn a
     
where lmspn.company_name = mmcc.company_name
    and lmspn.product_id = sp.product_id
    and sp.product_id = pa.product_id 
    and pa.attribute_id = a.attribute_id
    and a.description in ('HURCULEX I', 'HERCULEX I','NATUREGARD', 'FOOD GRADE', 'HIGH LYSINE', 
						  'HIGH OIL', 'NUSUN', 'HIGH PROTIEN',
                          'PHYTOPTHORA ROOT ROT RESISTANCE', 'PHYTOPHTHORA ROOT ROT RESISTANCE', 
			              'PHTOPHTHORA ROOT ROT RESISTANCE',
			              'SOYBEAN CYST NEMATODE RESISTANCE', 'WAXY', 'WHITE CORN')
			            
order by sp.product_id, attrib                     
;
         
begin
  prod_id := 0;
  tmpAttrib := '';
  FOR rec IN c_map LOOP
     --if (rec.attrib = 'NOT FOUND') then
      --   raise;
    -- end if;
     if rec.attrib <> 'NOT FOUND' then
     if (rec.product_id = prod_id) then 
        tmpAttrib := tmpAttrib || '/' || rec.attrib;
     else
        -- save tmpAttribute string;
        str := 'update lexicon.mirage_seed_product_name set triat = :trt where product_id = :prod_id'; 
        execute immediate str using tmpAttrib, prod_id;
        
		prod_id := rec.product_id;
		tmpAttrib := rec.triat;
		if (length(tmpAttrib) > 0) then
		   tmpAttrib := tmpAttrib || '/';
		end if;
		
        tmpAttrib := tmpAttrib || rec.attrib;
     end if;
     end if;
  end loop;

  -- save last one tmpAttribute string;
  str := 'update lexicon.mirage_seed_product_name set triat = :trt where product_id = :prod_id'; 
  execute immediate str using tmpAttrib, prod_id;
  
end;
end;
-- Run the query below to view all the trait stacks after concatenation. 
-- Get count of all trait stacks (9787 on 12/22)
  
select lmspn.triat, count(*)
from lexicon.mirage_seed_product_name lmspn,
     lexicon.mirage_minorcrop_compet_comp mmcc
where lmspn.company_name = mmcc.company_name
and lmspn.triat is not null
group by lmspn.triat;	   

-- Run query below to get trait stacks linking to Coml_Trait_Stack table.
-- If counts are off, probably a track stack has been added to the product data, 
-- and hasn't been added to the Coml_Trait_Stack table.
-- 9787 records on 12/22/2004.
 
select c.crop_name, lmspn.triat, count(*)
from 
    lexicon.mirage_seed_product_name lmspn,
    lexicon.mirage_minorcrop_compet_comp mmcc,
    lexicon.bayer_code bc,
    lexicon.crop c,
    lexicon.coml_trait_stack trt
where lmspn.company_name = mmcc.company_name 
    and bc.bayer_code_name = trim(lmspn.crop_bayer_code)
    and bc.crop_id = c.crop_id
    and c.crop_id = trt.crop_id 
    and lmspn.triat = trt.coml_trait_stack_abbr
	and  lmspn.triat is not null
group by c.crop_name, lmspn.triat;
   
-- Step 8:  Load trait_stack to Product_Name. 

-- Count records expected to load.

select count(*)
-- lmspn.company_name, lmspn.product_name, lmspn.crop_bayer_code, lmspn.country_name, lmspn.triat,
--       b.brand_name, pn.product_name, bc.bayer_code_name, c.country_name, cc.crop_name, trt.coml_trait_stack_abbr
from 
    lexicon.mirage_seed_product_name lmspn,
    lexicon.mirage_minorcrop_compet_comp mmcc,
    lexicon.product_name pn,
    lexicon.country c,
    lexicon.brand b,
    lexicon.bayer_code bc,
    lexicon.crop cc,
    lexicon.coml_trait_stack trt
    
 where lmspn.company_name = mmcc.company_name
     and pn.product_name = lmspn.product_name 
     and pn.country_id = c.country_id
     and c.country_name = lmspn.country_name  
     and pn.brand_id = b.brand_id
     and b.brand_name = lmspn.company_name
     and pn.bayer_code_id = bc.bayer_code_id
     and bc.bayer_code_name = trim(lmspn.crop_bayer_code)
     and lmspn.triat = trt.coml_trait_stack_abbr
     and bc.crop_id = cc.crop_id
     and cc.crop_id = trt.crop_id
     and lmspn.triat is not null
    ; 
	-- 9467 products

begin
declare
str VARCHAR2(500);

CURSOR c_map  IS
   SELECT  pn.product_name_id, trt.coml_trait_stack_id as trait
from 
    lexicon.mirage_seed_product_name lmspn,
    lexicon.mirage_minorcrop_compet_comp mmcc,
    lexicon.product_name pn,
    lexicon.country c,
    lexicon.brand b,
    lexicon.bayer_code bc,
    lexicon.crop cc,
    lexicon.coml_trait_stack trt
    
 where lmspn.company_name = mmcc.company_name
     and pn.product_name = lmspn.product_name 
     and pn.country_id = c.country_id
     and c.country_name = lmspn.country_name  
     and pn.brand_id = b.brand_id
     and b.brand_name = lmspn.company_name
     and pn.bayer_code_id = bc.bayer_code_id
     and bc.bayer_code_name = trim(lmspn.crop_bayer_code)
     and lmspn.triat = trt.coml_trait_stack_abbr
     and bc.crop_id = cc.crop_id
     and cc.crop_id = trt.crop_id
     and lmspn.triat is not null;
    
begin
  FOR rec IN c_map LOOP
 
    str := 'update lexicon.product_name set coml_trait_stack_id = :trt where product_name_id = :prod_name_id'; 
    execute immediate str using rec.trait, rec.product_name_id;
  end loop;
end;
end;

-- Count records updated.
select count(*) from lexicon.product_name pn where pn.coml_trait_Stack_id is not null;

-- Count by trait stack.
select trt.coml_trait_stack_abbr, count(*)
from lexicon.product_name pn, lexicon.coml_trait_stack trt
where pn.coml_trait_stack_id = trt.coml_trait_stack_id (+) and pn.coml_trait_Stack_id is not null
group by trt.coml_trait_stack_abbr;

select pn.product_name, trt.coml_trait_Stack_abbr
from lexicon.product_name pn, lexicon.coml_trait_stack trt
where pn.coml_trait_stack_id = trt.coml_trait_stack_id (+) and pn.coml_trait_Stack_id is not null
;

-- Step 9: 
-- Run to put Mirage country names back to the Lexicon country names.

 Update Lexicon.country set country_name = 'UNITED STATES OF AMERICA' where country_name = 'UNITED STATES';
 Update Lexicon.country set country_name = 'UNITED KINGDOM OF GREAT BRITAIN AND NORTHERN IRELA' 
     where country_name = 'UNITED KINGDOM';
 Update Lexicon.country set country_name = 'RUSSIAN FEDERATION' where country_name = 'RUSSIA';
 Update Lexicon.country set country_name = 'DOMINICAN REPUBLIC' where country_name = 'REPUBLICA DOMINICANA';
 Update Lexicon.country set country_name = 'FRENCH GUIANA' where country_name = 'FRENCH GUYANA';
 Update Lexicon.country set country_name = 'GUADELOUPE' where country_name = 'GUADALOUPE';
 Update Lexicon.country set country_name = 'ANTIGUA AND BARBUDA' where country_name = 'ANTIGUA & BARBUDA';
 Update Lexicon.country set country_name = 'TRINIDAD AND TOBAGO' where country_name = 'TRINIDAD & TOBAGO';
 Update Lexicon.country set country_name = 'LAO PEOPLE''S DEMOCRATIC REPUBLIC' where country_name = 'LAOS';
 Update Lexicon.country set country_name = 'UNITED REPUBLIC OF TANZANIA' where country_name = 'TANZANIA';
 Update Lexicon.country set country_name = 'VIET NAM' where country_name = 'VIETNAM';
 
 
 




