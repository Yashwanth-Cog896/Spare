select 'insert into lexicon.country (country_id, country_pubkey, country_abbr, country_name) ' ||
       'values (lexicon.country_id_seq.nextval, lexicon.country_pubkey_seq.nextval, ' ||
       '''' || upper(trim(country_abbr)) || ''', ''' || upper(trim(country_name)) || ''');'
 from lexicon.country@dsbreed_tst;   
 
 
 -- The results of this query should be provided to FBS so they can see the Lexicon Public keys with country names.

select Country_Pubkey, Country_Name, Country_Abbr
from Lexicon.Country C;    
