BEGIN
INSERT INTO Crop (crop_id, crop_name, is_major_crop) VALUES (1, 'CORN', 'y');
INSERT INTO Crop (crop_id, crop_name, is_major_crop) VALUES (2, 'SOYBEANS', 'y');
INSERT INTO Crop (crop_id, crop_name, is_major_crop) VALUES (3, 'SORGHUM', 'y');
INSERT INTO Crop (crop_id, crop_name, is_major_crop) VALUES (4, 'SUNFLOWER', 'y');
INSERT INTO Crop (crop_id, crop_name, is_major_crop) VALUES (5, 'WHEAT', 'y');
INSERT INTO Crop (crop_id, crop_name, is_major_crop) VALUES (6, 'OSR-Canola', 'y');
INSERT INTO Crop (crop_id, crop_name, is_major_crop) VALUES (7, 'COTTON', 'y');
END;
/

