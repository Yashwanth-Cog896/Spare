-- Step 1: Delete Lexicon to Midas cross references.
-- Remember to copy Midas/Lexicon cross references to excel for loading to FBS_Common from the MajorCropProductLoad
-- before deleting to reuse for the Mirage product id cross references.

delete lexicon.midas_lexicon_product; 
delete lexicon.midas_lexicon_product_name;

-- Step 2: Count minor crop competitor product records that will be loaded into Lexicon.Product.
-- count distinct bayer code, product name and brand which makes a unique PRODUCT.

select product_id, count(*) 
from
   (select distinct sp.product_id, lbc.bayer_code_id --trim(sp.crop_bayer_code)
   
    from mirage2.seed_products@ceregn sp, 
         mirage2.seed_products@ceregn eqsp,
		 fbs_common.brand_xref@prem fbsb, 
         lexicon.brand lb,
         lexicon.company lcomp,
         lexicon.country lctry,
         fbs_common.country_xref@prem fbsc,
         lexicon.bayer_code lbc
     
    where  sp.company_id = fbsb.mirage_company_id
	   and fbsb.lexicon_brand_pubkey = lb.brand_pubkey
	   and lb.company_id = lcomp.company_id 
	   and lcomp.is_competitor = 'y'
	    -- next 2 statements omits old equivalent products
       and sp.product_id = eqsp.equivalent_product_id (+)
       and eqsp.equivalent_product_id is null 
	   and trim(sp.crop_bayer_code) = lbc.bayer_code_name
	   and lbc.bayer_code_name not in ('ZEAMD', 'GLXMA', 'SORCU', 'SORGR', 'HELAN', 'GOSHI', 'BRSNC', 'BRSNW')
       and sp.country_code = fbsc.mirage_country_code
	   and fbsc.lexicon_country_pubkey = lctry.country_pubkey 
	   and sp.enabled = 'Y'
)
group by product_id having count(*) > 1
;
     
-- Step 3: This query inserts product records from Mirage competitor, minor crop products to be loaded to 
-- Lexicon.Product.  This query loads the lexicon.product table with the mirage.Seed_Product.product_id 
-- in the primary key (product_id). Mirage data is at the country level or product_name.  It doesn't have a product 
-- level, so the number of rows loaded to Product and Product_name should be the same.

insert into lexicon.product (product_pubkey, product_id, bayer_code_id)
(
select lexicon.product_pubkey_seq.nextval, iq.UniqueProduct, iq.BayerCodeId
 FROM (
      Select distinct sp.product_id * 1000 as UniqueProduct, lbc.bayer_code_id as BayerCodeId
        from mirage2.seed_products@ceregn sp, 
         mirage2.seed_products@ceregn eqsp,
		 fbs_common.brand_xref@prem fbsb, 
         lexicon.brand lb,
         lexicon.company lcomp,
         lexicon.country lctry,
         fbs_common.country_xref@prem fbsc,
         lexicon.bayer_code lbc
     
    where  sp.company_id = fbsb.mirage_company_id
	   and fbsb.lexicon_brand_pubkey = lb.brand_pubkey
	   and lb.company_id = lcomp.company_id 
	   and lcomp.is_competitor = 'y'
	    -- next 2 statements omits old equivalent products
       and sp.product_id = eqsp.equivalent_product_id (+)
       and eqsp.equivalent_product_id is null 
	   and trim(sp.crop_bayer_code) = lbc.bayer_code_name
	   and lbc.bayer_code_name not in ('ZEAMD', 'GLXMA', 'SORCU', 'SORGR', 'HELAN', 'GOSHI', 'BRSNC', 'BRSNW')
       and sp.country_code = fbsc.mirage_country_code
	   and fbsc.lexicon_country_pubkey = lctry.country_pubkey   
	   and sp.enabled = 'Y'
)iq
);

-- Step 4a: populates midas_lexicon_product table with the Mirage.Seed_products.product_id currently in the lexicon.product_id  
-- and generates the Lexicon.Product_id to store in the cross reference table.

insert into lexicon.midas_lexicon_product (midas_product_id, lexicon_product_id)
(select lp.product_id, lexicon.product_id_seq.nextval 
   from lexicon.product lp,
        lexicon.bayer_code lbc,
        mirage2.seed_products@ceregn sp
   -- limits cross reference to just the minor crops
   where lp.bayer_code_id = lbc.bayer_code_id
   and lbc.bayer_code_name not in ('ZEAMD', 'GLXMA', 'SORCU', 'SORGR', 'HELAN', 'GOSHI', 'BRSNC', 'BRSNW')
   and lp.product_id / 1000 = sp.product_id);
   
-- Step 4b: update lexicon_product table with lexicon values instead of mirage keys
begin
declare
str VARCHAR2(500);

CURSOR c_map  IS
   SELECT  *
     FROM  lexicon.midas_lexicon_product; 

begin
  FOR rec IN c_map LOOP
    str := 'update lexicon.product set product_id = :lex_prod_id where product_id = :midas_prod_id';
    execute immediate str using rec.lexicon_product_id, rec.midas_product_id;
  end loop;
end;
end;


-- Step 5: Count of competitive product name records from Mirage competitive, minor crop product to be loaded to Lexicon.

select count(*) from (
select sp.product_id, lb.brand_id, lctry.country_id, sp.product_name 

   from mirage2.seed_products@ceregn sp, 
         mirage2.seed_products@ceregn eqsp,
		 fbs_common.brand_xref@prem fbsb, 
         lexicon.brand lb,
         lexicon.company lcomp,
         lexicon.country lctry,
         fbs_common.country_xref@prem fbsc,
         lexicon.bayer_code lbc
     
    where  sp.company_id = fbsb.mirage_company_id
	   and fbsb.lexicon_brand_pubkey = lb.brand_pubkey
	   and lb.company_id = lcomp.company_id 
	   and lcomp.is_competitor = 'y'
	    -- next 2 statements omits old equivalent products
       and sp.product_id = eqsp.equivalent_product_id (+)
       and eqsp.equivalent_product_id is null 
	   and trim(sp.crop_bayer_code) = lbc.bayer_code_name
	   and lbc.bayer_code_name not in ('ZEAMD', 'GLXMA', 'SORCU', 'SORGR', 'HELAN', 'GOSHI', 'BRSNC', 'BRSNW')
       and sp.country_code = fbsc.mirage_country_code
	   and fbsc.lexicon_country_pubkey = lctry.country_pubkey
	   and sp.enabled = 'Y'
)
; 

-- Step 6: Load Lexicon.Product_Name competitive product_names for minor crop, competitive products from Mirage.

insert into lexicon.product_name 
(product_name_pubkey, product_id, product_name_id, brand_id, country_id, product_name, is_active, comments)
(
select lexicon.product_name_pubkey_seq.nextval, iq.productid, iq.productnameid,
       iq.brandid, iq.countryid, iq.productname, iq.isactive, iq.comments
From

(select lmap.lexicon_product_id as productid, sp.product_id * 1000 as productnameid, lb.brand_id as brandid,  
                 lctry.country_id as countryid, sp.product_name as productname, 
				 decode(sp.enabled,'Y','y','N','n',null) as isactive,
				 sp.comments as comments

   from  mirage2.seed_products@ceregn sp, 
         lexicon.midas_lexicon_product lmap,
         mirage2.seed_products@ceregn eqsp,
		 fbs_common.brand_xref@prem fbsb, 
         lexicon.brand lb,
         lexicon.company lcomp,
         lexicon.country lctry,
         fbs_common.country_xref@prem fbsc,
         lexicon.bayer_code lbc
     
    where  sp.company_id = fbsb.mirage_company_id
	   and fbsb.lexicon_brand_pubkey = lb.brand_pubkey
	   and lb.company_id = lcomp.company_id 
	   and lcomp.is_competitor = 'y'
	   and sp.product_id = lmap.midas_product_id 
	    -- next 2 statements omits old equivalent products
       and sp.product_id = eqsp.equivalent_product_id (+)
       and eqsp.equivalent_product_id is null 
	   and trim(sp.crop_bayer_code) = lbc.bayer_code_name
	   and lbc.bayer_code_name not in ('ZEAMD', 'GLXMA', 'SORCU', 'SORGR', 'HELAN', 'GOSHI', 'BRSNC', 'BRSNW')
       and sp.country_code = fbsc.mirage_country_code
	   and fbsc.lexicon_country_pubkey = lctry.country_pubkey 
	   and sp.enabled = 'Y'
 ) iq
);
  
-- step 7a. populates midas_lexicon_product_name table with the mirage.Seed_product.product_id currently in the 
-- lexicon.product_name_id and generates the Lexicon.Product_name_id to store in the cross reference table.
insert into lexicon.midas_lexicon_product_name (midas_product_name_id, lexicon_product_name_id)
(select lpn.product_name_id, lexicon.product_name_id_seq.nextval 
  from lexicon.product_name lpn,
       lexicon.product lp,
       lexicon.bayer_code lbc,
       mirage2.seed_products@ceregn sp
   -- limits cross reference to just the minor crops
   where lpn.product_id = lp.product_id 
   and lp.bayer_code_id = lbc.bayer_code_id
   and lbc.bayer_code_name not in ('ZEAMD', 'GLXMA', 'SORCU', 'SORGR', 'HELAN', 'GOSHI', 'BRSNC', 'BRSNW')
   and lpn.product_name_id = sp.product_id);  
   
-- Step 7b. update lexicon_product_name table with lexicon values instead of mirage keys
begin
declare
str VARCHAR2(500);

CURSOR c_map  IS
   SELECT  *
     FROM  lexicon.midas_lexicon_product_name; 

begin
  FOR rec IN c_map LOOP
    str := 'update lexicon.product_name set product_name_id = :lex_prod_id where product_name_id = :midas_prod_id';
    execute immediate str using rec.lexicon_product_name_id, rec.midas_product_name_id;
  end loop;
end;
end;

-- Note:  Left to load is inactive major crop products from Mirage.
-- Queries to load this product data are in MajorCropInactiveProduct.sql.

-- Step 8: Run query to obtain Lexicon.Product_pubkey and midas_id, and mirage.seed_products_id to load to FBS_Common.
-- I don't think we're cross referencing product for Mirage, so this query can be removed????
select lp.product_pubkey "Lexicon Product Pubkey", 
       mlp.midas_product_id "Mirage Product Id"
  --     mpm.seed_product_id "Mirage Product Id"
from lexicon.product lp,
     lexicon.midas_lexicon_product mlp
 --    yldstg.map_product_mirage@prem mpm
where lp.product_id = mlp.lexicon_product_id
 -- and mlp.midas_product_id = mpm.product_pk
;
 
-- Step 8: Run query to obtain Lexicon.Product_name_pubkey and mirage key cross reference for loading 
-- to FBS Common.
 
select  lpn.product_name_pubkey "Lexicon Product Name Pubkey", 
        mlpn.midas_product_name_id "Mirage Product Name Id"
       
from lexicon.product_name lpn,
     lexicon.midas_lexicon_product_name mlpn,
     mirage2.seed_products@ceregn sp
      
where lpn.product_name_id = mlpn.lexicon_product_name_id
and mlpn.midas_product_name_id = sp.product_id

;

begin 
  lexicon.audit_pkg.initialize_staging_p('23228', 'Manual','Inital Data Load','Nancy Schomburg');
end;

select count(*) from lexicon.product;
