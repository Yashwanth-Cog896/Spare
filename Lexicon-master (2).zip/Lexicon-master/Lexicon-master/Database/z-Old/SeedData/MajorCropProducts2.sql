-- This SQL will load Lexicon.Product and Product_name tables with major crop products from Midas.
-- It will generate Lexicon public keys with cross references to Midas product and product name ids.
-- Premise for load to test:  All major crop ACTIVE competitive products exist in Midas and Mirage and are linked
-- via Yldstg.Map_Product_Mirage table.  All country and brand pubkeys are in FBS Common tables.
-- Lexicon will load all products from YldMart.

-- Step 1: Delete product_name and product data and Lexicon to Midas cross references.

delete lexicon.product_name; 
delete lexicon.product;
delete lexicon.midas_lexicon_product;
delete lexicon.midas_lexicon_product_name;

-- Step 2a: Run Aaron's java program that adds duplicates into 
-- lexicon.midas_dup_product_name

-- Step 2b. Run query below to find Mirage dups to omit from load.  Removed this query - matched on product name 
-- between midas and mirage, so we won't load the dups in Mirage.

-- Find multiple records in Mirage linking to 1 product in Map_product_mirage
--and load into temp table to omit them from the major crop load.

--delete lexicon.mirage_seed_product;

--insert into lexicon.mirage_seed_product
-- (product_id, crop_bayer_code)
--select tmp.product_name_pk, 'dups'
--  from (
--select  lmap.lexicon_product_id, ypn.product_name_pk, 
 --       lb.brand_id, lctry.country_id, --ypn.name, 
 --       count(*) 
 
-- From yldmart.product_name@prem ypn, 
 --      lexicon.midas_lexicon_product lmap,
 --      yldmart.brand@prem yb, 
 --      lexicon.brand lb,
--	   yldmart.company@prem ycomp,  
 --      yldmart.product@prem yp, 
--	   lexicon.country lctry, 
--	   yldstg.map_product_mirage@prem mpm, 
--	   mirage2.seed_products@ceregn msp,
--	   mirage2.seed_products@ceregn eqsp, -- equivalent products
--	   fbs_common.country_xref@prem fbsc,
--	   fbs_common.brand_xref@prem fbsb,
--	   lexicon.bayer_code lbc,
--	   lexicon.midas_dup_product_name lmdpn
 
-- where ypn.brand_pk = yb.brand_pk 
 --   and yb.company_pk = ycomp.company_pk 
 --   and ycomp.name <> 'MONSANTO' 
 --   and ypn.product_pk = yp.product_pk
 --   and ypn.product_pk = lmap.midas_product_id
    -- remove from query when data is corrected.  wheat in Mirage mapping to soybeans in Midas.
    --and yp.product_pk <> 2461906239488
--	and ypn.brand_pk = fbsb.midas_brand_id 
--    and ypn.country_pk = fbsc.midas_country_id 
 --   and yp.product_pk = mpm.product_pk 
 --   and mpm.seed_product_id = msp.product_id
 --   and msp.country_code = fbsc.mirage_country_code
    -- next 2 statements omits old equivalent products
 --   and msp.product_id = eqsp.equivalent_product_id (+)
 --   and eqsp.equivalent_product_id is null
  --  and trim(msp.crop_bayer_code) = lbc.bayer_code_name 
 --   and fbsc.lexicon_country_pubkey = lctry.country_pubkey
 --   and fbsb.lexicon_brand_pubkey = lb.brand_pubkey
  -- don't pull Midas duplicate products
 --   and ypn.product_name_pk = lmdpn.product_pk(+) 
  --  and lmdpn.product_pk is null 
 
 --group by lmap.lexicon_product_id, ypn.product_name_pk, 
    --    lb.brand_id, lctry.country_id  --, ypn.name
    --    having count(*) >1 
--) tmp


-- Step 3: This query gives us the count of competitive product records (with corresponding Mirage products) 
-- to be loaded to Lexicon.
-- Need to get bayer code from Mirage for matching products so that for Canola and Sorghum, the Mirage bayer code 
-- is loaded to Lexicon. 

SELECT count(*) from ( 
Select distinct yp.product_pk , lbc.bayer_code_id 

  From yldmart.product_name@prem ypn, 
       yldmart.brand@prem yb, 
       lexicon.brand lb,
	   yldmart.company@prem ycomp,  
       yldmart.product@prem yp, 
	   lexicon.country lctry, 
	   yldstg.map_product_mirage@prem mpm, 
	   mirage2.seed_products@ceregn msp,
	   mirage2.seed_products@ceregn eqsp, -- equivalent products
	   fbs_common.country_xref@prem fbsc,
	   fbs_common.brand_xref@prem fbsb,
	   lexicon.bayer_code lbc,
	   lexicon.midas_dup_product_name lmdpn
--	   lexicon.mirage_seed_product lmsp
 
 where ypn.brand_pk = yb.brand_pk 
    and yb.company_pk = ycomp.company_pk 
    and ycomp.name <> 'MONSANTO' 
    and ypn.product_pk = yp.product_pk
    -- remove from query for now, until data is corrected.
    and yp.product_pk <> 1350830718976
	and ypn.brand_pk = fbsb.midas_brand_id 
    and ypn.country_pk = fbsc.midas_country_id 
    and yp.product_pk = mpm.product_pk 
    and mpm.seed_product_id = msp.product_id
    and msp.country_code = fbsc.mirage_country_code
    -- next 2 statements omits old equivalent products
    and msp.product_id = eqsp.equivalent_product_id (+)
    and eqsp.equivalent_product_id is null
    and trim(msp.crop_bayer_code) = lbc.bayer_code_name 
    and fbsc.lexicon_country_pubkey = lctry.country_pubkey
    and fbsb.lexicon_brand_pubkey = lb.brand_pubkey
    and msp.product_name = upper(ypn.name)
  -- don't pull Midas duplicate products
    and ypn.product_name_pk = lmdpn.product_pk(+) 
    and lmdpn.product_pk is null 
 -- don't pull Mirage duplicate products
--    and ypn.product_name_pk = lmsp.product_id(+) 
--    and lmsp.product_id is null 
)
--group by product_pk having count(*) > 1
;

-- Step 4: This query inserts product records with corresponding Mirage product to be loaded to Lexicon. 
-- this query loads the lexicon.product table with the midas.Product_id in the primary key (product_id).


 
insert into lexicon.product (product_pubkey, product_id, bayer_code_id)
(
select lexicon.product_pubkey_seq.nextval, iq.UniqueProduct, iq.BayerCodeId
 FROM (
      Select distinct yp.product_pk as UniqueProduct, lbc.bayer_code_id as BayerCodeId

  From yldmart.product_name@prem ypn, 
       yldmart.brand@prem yb, 
       lexicon.brand lb,
	   yldmart.company@prem ycomp,  
       yldmart.product@prem yp, 
	   lexicon.country lctry, 
	   yldstg.map_product_mirage@prem mpm, 
	   mirage2.seed_products@ceregn msp,
	   mirage2.seed_products@ceregn eqsp, -- equivalent products
	   fbs_common.country_xref@prem fbsc,
	   fbs_common.brand_xref@prem fbsb,
	   lexicon.bayer_code lbc,
	   lexicon.midas_dup_product_name lmdpn
--	   lexicon.mirage_seed_product lmsp
 
 where ypn.brand_pk = yb.brand_pk 
    and yb.company_pk = ycomp.company_pk 
    and ycomp.name <> 'MONSANTO' 
    and ypn.product_pk = yp.product_pk
    -- remove from query for now, until data is corrected.
    and yp.product_pk <> 1350830718976
	and ypn.brand_pk = fbsb.midas_brand_id 
    and ypn.country_pk = fbsc.midas_country_id 
    and yp.product_pk = mpm.product_pk 
    and mpm.seed_product_id = msp.product_id
    and msp.country_code = fbsc.mirage_country_code
    -- next 2 statements omits old equivalent products
    and msp.product_id = eqsp.equivalent_product_id (+)
    and eqsp.equivalent_product_id is null
    and trim(msp.crop_bayer_code) = lbc.bayer_code_name 
    and fbsc.lexicon_country_pubkey = lctry.country_pubkey
    and fbsb.lexicon_brand_pubkey = lb.brand_pubkey
    and msp.product_name = upper(ypn.name)
     -- don't pull Midas duplicate products
    and ypn.product_name_pk = lmdpn.product_pk(+) 
    and lmdpn.product_pk is null
) iq
);

-- Step 5a: populates midas_lexicon_product table with the midas.product_id currently in the lexicon.product_id  
-- and generates the Lexicon.Product_id to store in the cross reference table.

insert into lexicon.midas_lexicon_product (midas_product_id, lexicon_product_id)
(select product_id, lexicon.product_id_seq.nextval 
   from lexicon.product);
   
-- Step 5b: update lexicon_product table with lexicon values instead of midas keys
begin
declare
str VARCHAR2(500);

CURSOR c_map  IS
   SELECT  *
     FROM  lexicon.midas_lexicon_product; 

begin
  FOR rec IN c_map LOOP
    str := 'update lexicon.product set product_id = :lex_prod_id where product_id = :midas_prod_id';
    execute immediate str using rec.lexicon_product_id, rec.midas_product_id;
  end loop;
end;
end;

-- Step 6: Count of competitive product name records with corresponding active Mirage product to be loaded to Lexicon.
select count(*) from (
select distinct lmap.lexicon_product_id, ypn.product_name_pk, lb.brand_id, lctry.country_id, ypn.name 
 
 From yldmart.product_name@prem ypn, 
       lexicon.midas_lexicon_product lmap,
       yldmart.brand@prem yb, 
       lexicon.brand lb,
	   yldmart.company@prem ycomp,  
       yldmart.product@prem yp, 
	   lexicon.country lctry, 
	   yldstg.map_product_mirage@prem mpm, 
	   mirage2.seed_products@ceregn msp,
	   mirage2.seed_products@ceregn eqsp, -- equivalent products
	   fbs_common.country_xref@prem fbsc,
	   fbs_common.brand_xref@prem fbsb,
	   lexicon.bayer_code lbc,
	   lexicon.midas_dup_product_name lmdpn,
	   lexicon.mirage_seed_product lmsp
 
 where ypn.brand_pk = yb.brand_pk 
    and yb.company_pk = ycomp.company_pk 
    and ycomp.name <> 'MONSANTO' 
    and ypn.product_pk = yp.product_pk
    and ypn.product_pk = lmap.midas_product_id
    -- remove from query when data is corrected.  wheat in Mirage mapping to soybeans in Midas.
    and yp.product_pk <> 1350830718976
	and ypn.brand_pk = fbsb.midas_brand_id 
    and ypn.country_pk = fbsc.midas_country_id 
    and yp.product_pk = mpm.product_pk 
    and mpm.seed_product_id = msp.product_id
    and msp.country_code = fbsc.mirage_country_code
    -- next 2 statements omits old equivalent products
    and msp.product_id = eqsp.equivalent_product_id (+)
    and eqsp.equivalent_product_id is null
    and trim(msp.crop_bayer_code) = lbc.bayer_code_name 
    and fbsc.lexicon_country_pubkey = lctry.country_pubkey
    and fbsb.lexicon_brand_pubkey = lb.brand_pubkey
  -- don't pull Midas duplicate products
    and ypn.product_name_pk = lmdpn.product_pk(+) 
    and lmdpn.product_pk is null 
 -- don't pull Mirage duplicate products
   and ypn.product_name_pk = lmsp.product_id(+) 
   and lmsp.product_id is null
)
;
-- Step 7: Load Lexicon.Product_Name competitive product_names for corn, soybeans, cotton, OSR-Canola, sorghum, 
-- and sunflower where there is an ACTIVE corresponding product in Mirage to get the bayer code.  (Inactive Mirage
-- products won't be in Midas.)


insert into lexicon.product_name (product_name_pubkey, product_id, product_name_id, brand_id,  
country_id, product_name, is_active) 
(
select lexicon.product_name_pubkey_seq.nextval, iq.productid, iq.productnameid,
       iq.brandid, iq.countryid, iq.productname, 'y'  
From

(select distinct lmap.lexicon_product_id as productid, ypn.product_name_pk as productnameid, lb.brand_id as brandid,  
                 lctry.country_id as countryid, ypn.name as productname  

  From yldmart.product_name@prem ypn, 
       lexicon.midas_lexicon_product lmap,
       yldmart.brand@prem yb, 
       lexicon.brand lb,
	   yldmart.company@prem ycomp,  
       yldmart.product@prem yp, 
	   lexicon.country lctry, 
	   yldstg.map_product_mirage@prem mpm, 
	   mirage2.seed_products@ceregn msp,
	   mirage2.seed_products@ceregn eqsp, -- equivalent products
	   fbs_common.country_xref@prem fbsc,
	   fbs_common.brand_xref@prem fbsb,
	   lexicon.bayer_code lbc,
	   lexicon.midas_dup_product_name lmdpn,
	   lexicon.mirage_seed_product lmsp
 
 where ypn.brand_pk = yb.brand_pk 
    and yb.company_pk = ycomp.company_pk 
    and ycomp.name <> 'MONSANTO' 
    and ypn.product_pk = yp.product_pk
    and ypn.product_pk = lmap.midas_product_id
    -- remove from query when data is corrected.   Wheat in Mirage mapping to Soybeans in Midas.
    and yp.product_pk <> 1350830718976
	and ypn.brand_pk = fbsb.midas_brand_id 
    and ypn.country_pk = fbsc.midas_country_id 
    and yp.product_pk = mpm.product_pk 
    and mpm.seed_product_id = msp.product_id
    and msp.country_code = fbsc.mirage_country_code
    -- next 2 statements omits old equivalent products
    and msp.product_id = eqsp.equivalent_product_id (+)
    and eqsp.equivalent_product_id is null
    and trim(msp.crop_bayer_code) = lbc.bayer_code_name 
    and fbsc.lexicon_country_pubkey = lctry.country_pubkey
    and fbsb.lexicon_brand_pubkey = lb.brand_pubkey
  -- don't pull Midas duplicate products
    and ypn.product_name_pk = lmdpn.product_pk(+) 
    and lmdpn.product_pk is null 
 -- don't pull Mirage duplicate products
    and ypn.product_name_pk = lmsp.product_id(+) 
    and lmsp.product_id is null
) iq
);

-- step 8a, populates midas_lexicon_product_name table with the midas.product_name_id currently in the 
-- lexicon.product_name_id and generates the Lexicon.Product_name_id to store in the cross reference table.
insert into lexicon.midas_lexicon_product_name (midas_product_name_id, lexicon_product_name_id)
(select product_name_id, lexicon.product_name_id_seq.nextval 
   from lexicon.product_name);
   
-- Step 8b, update lexicon_product_name table with lexicon values instead of midas keys
begin
declare
str VARCHAR2(500);

CURSOR c_map  IS
   SELECT  *
     FROM  lexicon.midas_lexicon_product_name; 

begin
  FOR rec IN c_map LOOP
    str := 'update lexicon.product_name set product_name_id = :lex_prod_id where product_name_id = :midas_prod_id';
    execute immediate str using rec.lexicon_product_name_id, rec.midas_product_name_id;
  end loop;
end;
end;

-- Step 9: Check - Count Lexicon Products.

Select count(p.product_id)
from lexicon.product p;

-- Step 10: Check - Count Lexicon product names.

Select count(pn.product_name_id)
from lexicon.product_name pn;

-- Note:  Left to load is minor crop products and inactive major crop products.
-- Queries to load this product data are in MinorCropProduct.sql.

-- Step 11: Run query to obtain Lexicon.Product_pubkey and midas_id, and mirage.seed_products_id to load to FBS_Common.

select lp.product_pubkey "Lexicon Product Pubkey", mlp.midas_product_id "Midas Product Id"
-- mpm.seed_product_id "Mirage Product Id"
from lexicon.product lp,
     lexicon.midas_lexicon_product mlp
--    yldstg.map_product_mirage@prem mpm
where lp.product_id = mlp.lexicon_product_id
--  and mlp.midas_product_id = mpm.product_pk
;
 
-- Step 12: Run query to obtain Lexicon.Product_name_pubkey and midas and mirage key cross reference for loading 
-- to FBS Common.
 
select lpn.product_name_pubkey "Lexicon Product Name Pubkey", 
        mlpn.midas_product_name_id "Midas Product Name Id",
        sp.product_id "Mirage Product Id"
       
from lexicon.product_name lpn,
     lexicon.midas_lexicon_product_name mlpn,
     yldmart.product_name@prem ypn,
     yldstg.map_product_mirage@prem mpm,
     fbs_common.country_xref@prem fbsc,
     mirage2.seed_products@ceregn sp,
     mirage2.seed_products@ceregn eqsp,
     lexicon.country lc,
     lexicon.midas_dup_product_name lmdpn,
 	 lexicon.mirage_seed_product lmsp
     
where lpn.product_name_id = mlpn.lexicon_product_name_id
  and mlpn.midas_product_name_id = ypn.product_name_pk
  and ypn.product_pk = mpm.product_pk
  and mpm.seed_product_id = sp.product_id 
  and lpn.country_id = lc.country_id
  and lc.country_pubkey = fbsc.lexicon_country_pubkey 
  and fbsc.mirage_country_code = sp.country_code
-- next 2 statements omits old equivalent products
  and sp.product_id = eqsp.equivalent_product_id (+)
  and eqsp.equivalent_product_id is null
  -- don't pull Midas duplicate products
   and ypn.product_name_pk = lmdpn.product_pk(+) 
    and lmdpn.product_pk is null 
 -- don't pull Mirage duplicate products
   and ypn.product_name_pk = lmsp.product_id(+) 
   and lmsp.product_id is null
  

begin 
  lexicon.audit_pkg.initialize_staging_p('23228', 'Manual','Inital Data Load','Nancy Schomburg');
end;


 
