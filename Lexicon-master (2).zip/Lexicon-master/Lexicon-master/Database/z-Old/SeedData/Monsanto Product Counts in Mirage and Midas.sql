-- Counts active pre-commercial names in Midas

select count(*)
from midas.product_name@prem pn,
     midas.brand@prem b,
     midas.company@prem c
where pn.brand_id = b.brand_id
and b.company_id = c.company_id
and pn.ref_active = 'T' and b.ref_active = 'T' and c.ref_active = 'T'
and c.name = 'MONSANTO' and b.name = 'MONSANTO';

-- Counts active commercial names in Midas

select count(*)
from midas.product_name@prem pn,
     midas.brand@prem b,
     midas.company@prem c
where pn.brand_id = b.brand_id
and b.company_id = c.company_id
and pn.ref_active = 'T' and b.ref_active = 'T' and c.ref_active = 'T'
and c.name = 'MONSANTO' and b.name <> 'MONSANTO';

-- Count active pre-com'l Monsanto in Mirage.

select count(*)
from mirage2.seed_products@ceregn sp,
     mirage2.companies@ceregn c
where sp.company_id = c.company_id and sp.enabled = 'Y'
and c.company_name = 'MONSANTO';

-- count Monsanto commercial products in Mirage.

select count(*)
from mirage2.seed_products@ceregn sp,
     mirage2.companies@ceregn c
where sp.company_id = c.company_id and sp.enabled = 'Y'
and  c.company_name in ('AGROCERES', 'ASGROW', 'CARNIA', 'CERES', 'CORN STATES', 'CORN STATES INTERNATIONAL',
           'DEKALB', 'DEKASOL', 'FIRST LINE', 'HARTZ', 'MONSOY', 'SENSAKO', 'MONSANTO', 'HOLDEN''S', 'UNKNOWN',
		   'TITANIUM', 'NUTRILINE', 'COTTON STATES');
		   
		   
--  Get origins and product names
		   
select  b.name "Brand", pn.name "Product name", g.germplasm_id, g.origin, g.line_code, g.event_display,
g.pedigree_name, lt.line_type_ref_id, brp.br_prog_ref_id
from midas.product_name@prem pn,
     midas.brand@prem b,
     midas.company@prem c,
     midas.product@prem p,
  --  midas.product_stage@prem ps,
     midas.product_germplasm@prem pg,
     midas.germplasm@prem g,
     midas.line_type@prem lt,
     midas.br_prog@prem brp
    
where pn.brand_id = b.brand_id
--and pn.product_stage_id = ps.product_stage_id
and b.company_id = c.company_id
and pn.product_id = p.product_id
and p.product_id = pg.product_id
and pg.germplasm_id = g.germplasm_id
and g.line_type_id = lt.line_type_id
and g.owner_br_prog_id = brp.br_prog_id

and pn.ref_active = 'T' and b.ref_active = 'T' and c.ref_active = 'T'
and c.name = 'MONSANTO' and b.name = 'MONSANTO' --and ps.product_stage_ref_id = 'PMC1'
and g.is_finished_or_finished_child = 'T' and g.event_display is not null
and lt.line_type_ref_id <> 'HYBRID'

and rownum < 1500;
----
-- find all product names for some origins

select  b.name "Brand", pn.name "Product name", ps.product_stage_ref_id "Product Stage", ct.name "Country", 
g.germplasm_id, g.origin, g.line_code, g.event_display,
g.pedigree_name, lt.line_type_ref_id, brp.br_prog_ref_id, gm.source_str, gm.lineage
from midas.product_name@prem pn,
     midas.brand@prem b,
     midas.company@prem c,
     midas.product@prem p,
     midas.product_stage@prem ps,
     midas.country@prem ct,
     midas.product_germplasm@prem pg,
     midas.germplasm@prem g,
     midas.line_type@prem lt,
     midas.br_prog@prem brp,
    midas.genetic_material@prem gm
where pn.brand_id = b.brand_id
and b.company_id = c.company_id
and pn.country_id = ct.country_id
and pn.product_id = p.product_id
and pn.product_stage_id = ps.product_stage_id
and p.product_id = pg.product_id
and pg.germplasm_id = g.germplasm_id
and g.line_type_id = lt.line_type_id
and g.owner_br_prog_id = brp.br_prog_id
and g.germplasm_id = gm.germplasm_id
and pn.ref_active = 'T' and b.ref_active = 'T' and c.ref_active = 'T'
--and g.is_finished_or_finished_child = 'F' and g.event_display is not null and lt.line_type_ref_id = 'HYBRID'
and c.name = 'MONSANTO' and b.name = 'MONSANTO' and ps.product_stage_ref_id = 'OLD2'
--and g.origin = 'WQCD10+91INH2EZRAB'
--and g.origin = 'HC34BT1-2+LH277'
--and g.origin = '09DSS1EZRAB+(90LDC2*4/(B73/H99MON84006):@>0002>0078>0099.@.)'
--and g.origin = '09DSS1EZRAB+((90LDC2*4/MON863:0001)/(90LDC2*7/FBLLEZRA):0001.)'
and rownum < 500
order by ct.name;

-- View product stage data

select b.name, ps.product_stage_ref_id, ps.name, count(*)
from midas.product_name@prem pn,
     midas.brand@prem b,
     midas.company@prem c,
     midas.product_stage@prem ps
where pn.brand_id = b.brand_id
and b.company_id = c.company_id
and pn.product_stage_id = ps.product_stage_id
and c.name = 'MONSANTO'
and pn.ref_active = 'T' and b.ref_active = 'T' and c.ref_active = 'T'
group by b.name, ps.product_stage_ref_id, ps.name
;

-- find germplasm data without product names 

select g.germplasm_id, g.origin, g.line_code, g.event_display,
       g.pedigree_name, lt.line_type_ref_id, brp.br_prog_ref_id, gm.source_str  -- , gm.lineage
from midas.germplasm@prem g,
     midas.line_type@prem lt,
     midas.br_prog@prem brp,
     midas.genetic_material@prem gm,
     midas.product_germplasm@prem pg
where g.germplasm_id = pg.germplasm_id (+)
and pg.product_id is null
and g.line_type_id = lt.line_type_id
and g.owner_br_prog_id = brp.br_prog_id
and g.germplasm_id = gm.germplasm_id
and g.is_finished_or_finished_child = 'F' and g.event_display is not null and lt.line_type_ref_id = 'HYBRID'
and g.origin like '%01INL1EZRA-MON863D%' and g.origin like '%91DUQ1%'
--and g.origin = '(91DUQ1/90SEQ1:@.0073.)+01INL1EZRA-MON863D'
--and g.origin = 'WQCD10+91INH2EZRAB'
--and g.origin = 'HC34BT1-2+LH277'
--and g.origin = '09DSS1EZRAB+(90LDC2*4/(B73/H99MON84006):@>0002>0078>0099.@.)'
--and g.origin = '09DSS1EZRAB+((90LDC2*4/MON863:0001)/(90LDC2*7/FBLLEZRA):0001.)'
and rownum < 500;

-- Find germplasm data without genetic material

select g.germplasm_id, g.origin, g.line_code, g.event_display,
       g.pedigree_name, lt.line_type_ref_id, brp.br_prog_ref_id --, gm.source_str  -- , gm.lineage
from midas.germplasm@prem g,
     midas.line_type@prem lt,
     midas.br_prog@prem brp
 --    midas.genetic_material@prem gm--,
 --    midas.product_germplasm@prem pg
where --g.germplasm_id = pg.germplasm_id (+)
--and pg.product_id is null
 g.line_type_id = lt.line_type_id
and g.owner_br_prog_id = brp.br_prog_id
--and g.germplasm_id = gm.germplasm_id
and g.germplasm_id in (
531798753710,
531799146926,
322427945390,
322428338606,
322428731822,
456510734722,
322429125038);

select g.germplasm_id, g.origin, g.line_code, g.event_display,
       g.pedigree_name, lt.line_type_ref_id, brp.br_prog_ref_id --, gm.source_str  -- , gm.lineage
from midas.germplasm@prem g,
     midas.line_type@prem lt,
     midas.br_prog@prem brp
 --    midas.genetic_material@prem gm--,
 --    midas.product_germplasm@prem pg
where --g.germplasm_id = pg.germplasm_id (+)
--and pg.product_id is null
 g.line_type_id = lt.line_type_id
and g.owner_br_prog_id = brp.br_prog_id
--and g.germplasm_id = gm.germplasm_id
and g.origin in 
('17AFD1+94INK1A',
'17AFD1+94IZI14',
'87AFD3+94IYI3B',
'87DUA3+87IKI2',
'87DUA3+94IZI33',
'87DUA3+94IZI34',
'87DUA5+83IDI11',
'87DUA5+94ISI27',
'87DUA5+94ISI28',
'87DUA5+94ISI29',
'87DUA5+94ISI38',
'87DUA5+94XCC1',
'87EED5+87IZI15',
'87EED5+91IDI13',
'87SIA10+94IZI14',
'89AHA1NK603A+87ITI5',
'91DUA1+94ISI38',
'91DUA1+94XCC1',
'(91DUA4:0001.0001.@.)+83IDI11',
'94AFA10+94IZI11',
'94AFA4+94IZI11',
'94AFA9+94IYI3B',
'94AFD14+94IZI14',
'94AHA8+94AZB6++94XCI5',
'94AHA8NK603A+87IFI6',
'94AHA8NK603A+87IKI2',
'94AHA8NK603A+91AHB1NK603A++94XCI16',
'94AHA8NK603A+91AHB1NK603A++94XCI20',
'94AHA8NK603A+91AHB1NK603A++94XCI22',
'94AHA8NK603A+(91INM11:0002.0001.@.)',
'94AHA8NK603A+94ISI28',
'94AHA8NK603A+94ITX2',
'94AHA8NK603A+94XCI22',
'94AHD11+87IKI2',
'17DUD17+17IVI7',
'17DUD19+91INZ2EZRAE',
'17DUD23+17IVI7',
'17DUD24+17IVI7',
'(49SIS1:0002.0002.@.)+17IVI7',
'64DJD1+83IDI1',
'83DUD7+17IVI7',
'83DUQ3+83IDI11',
'83DUQ3+87IFH1',
'83DUQ3+(87IZI16:@.)',
'87DUA5+17IFI13',
'87DUA5+72IFH1',
'87DUA5+87IFK2',
'87DUQ6+17IVI7',
'87EED5+17IDI6',
'87EED5+17IFI7',
'87EED5+83IDI11',
'87EED5+87IDZ2',
'87EED5+87IFK2',
'87EED5+(91IBI7:0003.0001.@.)',
'87EED5+(91IDI14:0003.0001.@.)',
'87SIA10+87IDI1EZRAC',
'87SIA4+87IDI1EZRAD',
'87SIE3+01INL1EZRAD',
'(91DKD11:0003.0001.@.)+87IDI1A',
'91DUA1+01CEI5',
'91DUA1+01IDC5',
'91DUA1+17IFI16',
'91DUA1+17IFI2',
'91DUA1+17IFI6',
'91DUA1+87IDZ2',
'91DUA1+94IYL1',
'(91DUA2:0001.0001.@.)+87IDI2EZRAB',
'(91DUA6:0002.0001.@.)+17IFI6',
'(91DUA8:0001.0001.@.)+83IDI11',
'(91DUA8:0001.0001.@.)+87IDI1A',
'91DUD5NK603D+83IDI11',
'91DUD5NK603D+83IZI8',
'91DUD5NK603D+87IFH1',
'91DUD5NK603D+87IFI6',
'91DUQ1NK603B+01IDC6',
'91DUQ1NK603B+17IDI12',
'91DUQ1NK603B+17IFI14',
'91DUQ1NK603B+17IFI9',
'91DUQ1NK603B+17III12',
'91DUQ1NK603B+17III13',
'91DUQ1NK603B+17III7',
'91DUQ1NK603B+87IFK2',
'91DUQ1NK603B+(91IFC11:0003.0001.@.)',
'91DUQ1NK603B+(91IKI14:0001.0002.@.)',
'91DZB3NK603A+17IDI11',
'91DZB3NK603A+17IDI6',
'91DZB3NK603A+17IFI2',
'91DZB3NK603A+17IFI6',
'91DZB3NK603A+17IVI11',
'91DZB3NK603A+64CBI1',
'91DZB3NK603A+83IDI3',
'91QGD11+(91IFC11:0003.0001.@.)',
'(91SID12:0002.0001.@.)+83IDI11',
'91SID13+83IDI11',
'94AHD11+94IZI33',
'01QZF1+83IDI1',
'01SID2+64CBI1',
'17DUD16+83IZI8',
'17DUD17+91INH2EZRAB'
)
order by g.origin;

-- Check if origin without trait has a name

select b.name "Brand", b.ref_active "Brand Active", pn.name "Product name", pn.ref_active "ProdName Active", 
    p.ref_active "Prod Active", ps.product_stage_ref_id "Product Stage", ct.name "Country", 
    g.germplasm_id, g.origin, g.line_code, g.event_display,
g.pedigree_name, lt.line_type_ref_id, brp.br_prog_ref_id  --, gm.source_str, gm.lineage
from midas.germplasm@prem g,
     midas.product_germplasm@prem pg,
     midas.line_type@prem lt,
     midas.br_prog@prem brp,
     midas.product_name@prem pn,
     midas.brand@prem b,
     midas.company@prem c,
     midas.product@prem p,
     midas.product_stage@prem ps,
     midas.country@prem ct
--    midas.genetic_material@prem gm
where g.line_type_id = lt.line_type_id
and g.owner_br_prog_id = brp.br_prog_id
and g.germplasm_id = pg.germplasm_id
and pg.product_id = p.product_id
and p.product_id = pn.product_id
and pn.brand_id = b.brand_id
and pn.country_id = ct.country_id
and pn.product_stage_id = ps.product_stage_id
-- and g.germplasm_id = gm.germplasm_id
and g.origin in 
(
'89AHA1+87ITI5',
'94AHA8+87IFI6',
'94AHA8+87IKI2',
'94AHA8+91AHB1++94XCI16',
'94AHA8+91AHB1++94XCI20',
'94AHA8+91AHB1++94XCI22',
'94AHA8+(91INM11:0002.0001.@.)',
'94AHA8+94ISI28',
'94AHA8+94ITX2',
'94AHA8+94XCI22',
'17DUD19+91INZ2',
'87SIA10+87IDI1',
'87SIA4+87IDI1',
'87SIE3+01INL1',
'(91DUA2:0001.0001.@.)+87IDI2',
'91DUD5+83IDI11',
'91DUD5+83IZI8',
'91DUD5+87IFH1',
'91DUD5+87IFI6',
'91DUQ1+01IDC6',
'91DUQ1+17IDI12',
'91DUQ1+17IFI14',
'91DUQ1+17IFI9',
'91DUQ1+17III12',
'91DUQ1+17III13',
'91DUQ1+17III7',
'91DUQ1+87IFK2',
'91DUQ1+(91IFC11:0003.0001.@.)',
'91DUQ1+(91IKI14:0001.0002.@.)',
'91DZB3+17IDI11',
'91DZB3+17IDI6',
'91DZB3+17IFI2',
'91DZB3+17IFI6',
'91DZB3+17IVI11',
'91DZB3+64CBI1',
'91DZB3+83IDI3',
'17DUD17+91INH2'
)
order by g.origin;

-- Check if origin without lineage has a name

select b.name "Brand", b.ref_active "Brand Active", pn.name "Product name", pn.ref_active "ProdName Active", 
    p.ref_active "Prod Active", ps.product_stage_ref_id "Product Stage", ct.name "Country", 
    g.germplasm_id, g.origin, g.line_code, g.event_display,
g.pedigree_name, lt.line_type_ref_id, brp.br_prog_ref_id  --, gm.source_str, gm.lineage
from midas.germplasm@prem g,
     midas.product_germplasm@prem pg,
     midas.line_type@prem lt,
     midas.br_prog@prem brp,
     midas.product_name@prem pn,
     midas.brand@prem b,
     midas.company@prem c,
     midas.product@prem p,
     midas.product_stage@prem ps,
     midas.country@prem ct
--    midas.genetic_material@prem gm
where g.line_type_id = lt.line_type_id
and g.owner_br_prog_id = brp.br_prog_id
and g.germplasm_id = pg.germplasm_id
and pg.product_id = p.product_id
and p.product_id = pn.product_id
and pn.brand_id = b.brand_id
and pn.country_id = ct.country_id
and pn.product_stage_id = ps.product_stage_id
-- and g.germplasm_id = gm.germplasm_id
and g.origin in 
(
'91DUA4+83IDI11',
'94AHA8NK603A+91INM11',
'49SIS1+17IVI7',
'83DUQ3+87IZI16',
'87EED5+91IBI7',
'87EED5+91IDI14',
'91DKD11+87IDI1A',
'91DUA2+87IDI2EZRAB',
'91DUA6+17IFI6',
'91DUA8+83IDI11',
'91DUA8+87IDI1A',
'91DUQ1NK603B+91IFC11',
'91DUQ1NK603B+91IKI14',
'91QGD11+91IFC11',
'91SID12+83IDI11'
)
order by g.origin;
