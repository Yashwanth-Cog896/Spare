-- Load product commercial traits from Mirage.
-- Run after the MajorCropProduct2 and MinorCropProduct2 has run, and loaded products to Product_name.
-- Run after commercial traits tables are loaded.
-- Run after Lexicon.Product_pubkey and Lexicon.Product_name_pubkey are loaded to FBS_common tables with cross
-- references to Midas and Mirage ids.

-- Step 1:  Remove coml_trait_stack_id from Lexicon Product_name table.

update lexicon.product_name set coml_trait_stack_id = null where coml_trait_stack_id is not null;

-- Step 2: Delete rows from Lexicon.Mirage_Seed_Product_Name, which will be used to house the traits temporarily.

delete lexicon.mirage_seed_product_name;

delete lexicon.mirage_seed_product;

-- Step 3:  Count product_name records that will be updated with a trait_stack.  We will load traits from KW first
-- into Lexicon.Mirage_Seed_product_name as a holding place until we can concatenate the attributes, and ensure all
-- trait stacks exist in COML_TRAIT_STACK.

select count(*)
--       lpn.product_name_id, count(*)
 
from lexicon.product_name lpn, 
     lexicon.brand lb,
     lexicon.company lcomp,
	 fbs_common.product_name_xref@prem fbspn,
	 mirage2.seed_products@ceregn sp,
	 mirage2.kw@ceregn kw
	 
where lpn.brand_id = lb.brand_id 
    and lb.company_id = lcomp.company_id 
	and lcomp.is_competitor = 'y'
    and lpn.product_name_pubkey = fbspn.lexicon_product_name_pubkey
    and fbspn.mirage_product_id = sp.product_id
    and sp.trait_characteristic_code = kw.code
    and kw.name not in ('NON-TRANSGENIC', 'UNKNOWN', 'UNK')
--group by lpn.product_name_id
--having count(*) > 1
    ;
    
--step 3b insert product / initial trait into Lexicon.Mirage_Seed_Product
insert into lexicon.mirage_seed_product
 (product_id, crop_bayer_code)
(
select distinct lpn.product_name_id, 0
from lexicon.product_name lpn, 
     lexicon.brand lb,
     lexicon.company lcomp,
	 fbs_common.product_name_xref@prem fbspn,
	 mirage2.seed_products@ceregn sp,
	 mirage2.kw@ceregn kw
where lpn.brand_id = lb.brand_id 
    and lb.company_id = lcomp.company_id 
	and lcomp.is_competitor = 'y'
    and lpn.product_name_pubkey = fbspn.lexicon_product_name_pubkey
    and fbspn.mirage_product_id = sp.product_id
    and sp.trait_characteristic_code = kw.code
    and kw.name not in ('NON-TRANSGENIC', 'UNKNOWN', 'UNK')
)
;


--step 3c insert product name / initial trait into Lexicon.Mirage_Seed_Product_Name
insert into lexicon.mirage_seed_product_name lm
 (lm.product_name_id, lm.product_id, lm.company_name, lm.crop_bayer_code, lm.product_name, lm.country_name)
 (
select lpn.product_name_id, lpn.product_name_id, 'bogus', lbc.crop_id, lpn.product_name, 'bogus'
from lexicon.product_name lpn, 
     lexicon.product lp,
     lexicon.bayer_code lbc,
     lexicon.brand lb,
     lexicon.company lcomp,
	 fbs_common.product_name_xref@prem fbspn,
	 mirage2.seed_products@ceregn sp,
	 mirage2.kw@ceregn kw
where lpn.brand_id = lb.brand_id 
    and lpn.product_id = lp.product_id
    and lp.bayer_code_id = lbc.bayer_code_id
    and lb.company_id = lcomp.company_id 
	and lcomp.is_competitor = 'y'
    and lpn.product_name_pubkey = fbspn.lexicon_product_name_pubkey
    and fbspn.mirage_product_id = sp.product_id
    and sp.trait_characteristic_code = kw.code
    and kw.name not in ('NON-TRANSGENIC', 'UNKNOWN', 'UNK')
) 
;  

    
-- Step 4: Update trait stack in Lexicon.Mirage_Seed_Product_Name from Mirage trait characteristics code.
begin
declare
str VARCHAR2(500);

CURSOR c_map  IS
   SELECT  lpn.product_name_id, kw.name as trait
   
   from lexicon.product_name lpn, 
     lexicon.brand lb,
     lexicon.company lcomp,
	 fbs_common.product_name_xref@prem fbspn,
	 mirage2.seed_products@ceregn sp,
	 mirage2.kw@ceregn kw
	 
   where lpn.brand_id = lb.brand_id 
    and lb.company_id = lcomp.company_id 
	and lcomp.is_competitor = 'y'
    and lpn.product_name_pubkey = fbspn.lexicon_product_name_pubkey
    and fbspn.mirage_product_id = sp.product_id
    and sp.trait_characteristic_code = kw.code
    and kw.name not in ('NON-TRANSGENIC', 'UNKNOWN', 'UNK')

;	 
         
begin
  FOR rec IN c_map LOOP
 
    str := 'update lexicon.mirage_seed_product_name set triat = :trt where product_name_id = :prod_name_id'; 
    execute immediate str using rec.trait, rec.product_name_id;
  end loop;
end;
end;
    
-- Step 5: Check row count where trait was loaded.

select count(*)
from lexicon.Mirage_Seed_Product_name lmspn
where lmspn.triat is not null
     ;
-- double check the trait stacks loaded thus far.
     
select lmspn.triat, count(*)
from lexicon.mirage_seed_Product_Name lmspn
where lmspn.triat is not null
group by lmspn.triat order by lmspn.triat;
                    
-- Step 6:  Concatenate attributes to traits in Lexicon.Mirage_Seed_product_name.
-- This query gives us a previow of the results of the load in the query following this query.
-- Need to include records with only attributes and no trait characteristic code 
-- (e.g. a conventional high-oil, for instance.)

select distinct lpn.product_name_id, lmspn.triat, 
        decode(a.description, 
		       'SOYBEAN CYST NEMATODE RESISTANCE', 'SCN',
                'FOOD GRADE', 'FG',
                'HIGH LYSINE', 'LY',
                'HIGH OIL', 'HO',
                'NUSUN', 'NUSUN',
                'HIGH PROTIEN', 'HP', -- was spelled wrong in MIRAGE
                'PHYTOPTHORA ROOT ROT RESISTANCE', 'PRR', -- was spelled wrong in MIRAGE
                'PHTOPHTHORA ROOT ROT RESISTANCE', 'PRR', -- was spelled wrong in MIRAGE
                'PHYTOPHTHORA ROOT ROT RESISTANCE', 'PRR', -- correct spelling
                'SOYBEAN CYST NEMATODE RESISTANCE', 'SCN',
                'WAXY', 'WAXY',
                'WHITE CORN', 'WHITE',
                'RR FLEX' , 'RRFLEX', 
		        'NOT FOUND') attrib 
		        
from lexicon.product_name lpn, 
     lexicon.brand lb,
     lexicon.company lcomp,
     lexicon.mirage_seed_product_name lmspn,
	 fbs_common.product_name_xref@prem fbspn,
	 mirage2.seed_products@ceregn sp, 
     mirage2.seed_products_attributes@ceregn pa, 
     mirage2.attributes@ceregn a
   
 where  lpn.product_name_id = lmspn.product_name_id  -- What about if only attribute exist??
    and lpn.brand_id = lb.brand_id 
    and lb.company_id = lcomp.company_id 
	and lcomp.is_competitor = 'y'
	and lpn.product_name_pubkey = fbspn.lexicon_product_name_pubkey
	and fbspn.mirage_product_id = sp.product_id
    and sp.product_id = pa.product_id 
    and pa.attribute_id = a.attribute_id
    and a.description in ('FOOD GRADE', 'HIGH LYSINE', 'HIGH OIL', 'NUSUN', 'HIGH PROTIEN',
                        'PHYTOPTHORA ROOT ROT RESISTANCE', 'PHYTOPHTHORA ROOT ROT RESISTANCE', 
			           'PHTOPHTHORA ROOT ROT RESISTANCE',
			             'SOYBEAN CYST NEMATODE RESISTANCE', 'WAXY', 'WHITE CORN')
			            
order by lpn.product_name_id, attrib                     
;
	 
begin
declare
prod_id    NUMBER;
tmpAttrib  VARCHAR2(30);
str        VARCHAR2(1500);

CURSOR c_map  IS
select distinct lpn.product_name_id, lmspn.triat, 
        decode(a.description, 
		       'SOYBEAN CYST NEMATODE RESISTANCE', 'SCN',
                'FOOD GRADE', 'FG',
                'HIGH LYSINE', 'LY',
                'HIGH OIL', 'HO',
                'NUSUN', 'NUSUN',
                'HIGH PROTIEN', 'HP', -- was spelled wrong in MIRAGE
                'PHYTOPTHORA ROOT ROT RESISTANCE', 'PRR', -- was spelled wrong in MIRAGE
                'PHTOPHTHORA ROOT ROT RESISTANCE', 'PRR', -- was spelled wrong in MIRAGE
                'PHYTOPHTHORA ROOT ROT RESISTANCE', 'PRR', -- correct spelling
                'SOYBEAN CYST NEMATODE RESISTANCE', 'SCN',
                'WAXY', 'WAXY',
                'WHITE CORN', 'WHITE',
                'RR FLEX' , 'RRFLEX', 
		        'NOT FOUND') attrib 
		        
from lexicon.product_name lpn, 
     lexicon.brand lb,
     lexicon.company lcomp,
     lexicon.mirage_seed_product_name lmspn,
	 fbs_common.product_name_xref@prem fbspn,
	 mirage2.seed_products@ceregn sp, 
     mirage2.seed_products_attributes@ceregn pa, 
     mirage2.attributes@ceregn a
   
 where  lpn.product_name_id = lmspn.product_name_id  -- What about if only attribute exist??
    and lpn.brand_id = lb.brand_id 
    and lb.company_id = lcomp.company_id 
	and lcomp.is_competitor = 'y'
	and lpn.product_name_pubkey = fbspn.lexicon_product_name_pubkey
	and fbspn.mirage_product_id = sp.product_id
    and sp.product_id = pa.product_id 
    and pa.attribute_id = a.attribute_id
    and a.description in ('FOOD GRADE', 'HIGH LYSINE', 'HIGH OIL', 'NUSUN', 'HIGH PROTIEN',
                        'PHYTOPTHORA ROOT ROT RESISTANCE', 'PHYTOPHTHORA ROOT ROT RESISTANCE', 
			           'PHTOPHTHORA ROOT ROT RESISTANCE',
			             'SOYBEAN CYST NEMATODE RESISTANCE', 'WAXY', 'WHITE CORN')
			            
order by lpn.product_name_id, attrib                     
;
         
begin
  prod_id := 0;
  tmpAttrib := '';
  FOR rec IN c_map LOOP
     --if (rec.attrib = 'NOT FOUND') then
      --   raise;
    -- end if;
     if (rec.attrib <> 'NOT FOUND') then
     if (rec.product_id = prod_id) then 
        tmpAttrib := tmpAttrib || '/' || rec.attrib;
     else
        -- save tmpAttribute string;
        str := 'update lexicon.mirage_seed_product_name set triat = :trt where product_name_id = :prod_id'; 
        execute immediate str using tmpAttrib, prod_id;
        
		prod_id := rec.product_id;
		tmpAttrib := rec.triat;
		if (length(tmpAttrib) > 0) then
		   tmpAttrib := tmpAttrib || '/';
		end if;
		
        tmpAttrib := tmpAttrib || rec.attrib;
     end if;
     end if;
  end loop;

  -- save last one tmpAttribute string;
  str := 'update lexicon.mirage_seed_product_name set triat = :trt where product_id = :prod_id'; 
  execute immediate str using tmpAttrib, prod_id;
  
end;
end;
-- Step 7: Run the query below to view all the trait stacks after concatenation. 
--         Get list/count of all unique trait stacks 
  
select distinct lmspn.triat, count(*)
from lexicon.mirage_seed_product_name lmspn
where lmspn.triat is not null
group by lmspn.triat;	   

-- Run query below to get trait stacks from Coml_trait_stack.
-- compare against stacks the data produced to make sure all tracks are in the table.
select coml_trait_stack_abbr
from lexicon.coml_trait_stack cts
order by coml_trait_stack_abbr;

-- list trait abbriviations in mirage_seed_product_name, that are not in coml_trait_stack_name_xref
select lc.crop_name, mspn.triat, count(*)
  from lexicon.mirage_seed_product_name mspn,
       lexicon.coml_trait_stack_name_xref cts,
       lexicon.crop lc
 where mspn.crop_bayer_code = lc.crop_id
   and mspn.crop_bayer_code = cts.crop_id (+)
   and mspn.triat = cts.value (+)
   and cts.value is null
group by lc.crop_name, mspn.triat   
;  

-- similar query, expected update count for prod_name association
select count(*)
  from lexicon.mirage_seed_product_name mspn,
       lexicon.coml_trait_stack_name_xref cts,
       lexicon.crop lc
 where mspn.crop_bayer_code = lc.crop_id
   and mspn.crop_bayer_code = cts.crop_id
   and mspn.triat = cts.value
;  




-- If some are missing, add to excel spreadsheets and reload coml trait data.

-- Step 8:  Load trait_stack to Product_Name. 

-- Count records expected to load, should match 1st query in step 7.

update lexicon.product_name set product_name_pubkey = '21315307' where product_name_pubkey = '21315307';

    
begin lexicon.audit_pkg.initialize_staging_p('22680', 'Manual','Manual','Aaron Cox');
end;


begin
declare
str VARCHAR2(500);

CURSOR c_map  IS
   SELECT  mspn.product_name_id as product_name_id, cts.coml_trait_stack_id as trait
  from lexicon.mirage_seed_product_name mspn,
       lexicon.coml_trait_stack_name_xref cts,
       lexicon.crop lc
 where mspn.crop_bayer_code = lc.crop_id
   and mspn.crop_bayer_code = cts.crop_id
   and mspn.triat = cts.value
;  
    
begin
  FOR rec IN c_map LOOP
 
    str := 'update lexicon.product_name set coml_trait_stack_id = :trt where product_name_id = :prod_name_id'; 
    execute immediate str using rec.trait, rec.product_name_id;
  end loop;
end;
end;

begin
lexicon.audit_pkg.delete_staging_record_p;
end;


-- Count records updated.
select count(*) from lexicon.product_name pn where pn.coml_trait_Stack_id is not null;

-- Count by trait stack.
select trt.coml_trait_stack_abbr, count(*)
from lexicon.product_name pn, lexicon.coml_trait_stack trt
where pn.coml_trait_stack_id = trt.coml_trait_stack_id (+) and pn.coml_trait_Stack_id is not null
group by trt.coml_trait_stack_abbr;

select pn.product_name, trt.coml_trait_Stack_abbr
from lexicon.product_name pn, lexicon.coml_trait_stack trt
where pn.coml_trait_stack_id = trt.coml_trait_stack_id (+) and pn.coml_trait_Stack_id is not null
;




begin 
  lexicon.audit_pkg.initialize_staging_p('23228', 'Manual','Inital Data Load','Nancy Schomburg');
end;

begin
lexicon.audit_pkg.delete_staging_record_p;
end;


select mspn.triat, c.crop_name, count(*)
  from lexicon.mirage_seed_product_name mspn,
       lexicon.crop c
 where mspn.crop_bayer_code = c.crop_id       
 group by mspn.triat, c.crop_name
 order by 1
; 

