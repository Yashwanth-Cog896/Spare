BEGIN
INSERT INTO User_Preference_Definition (user_preference_definition_id, user_pref_name, metadata, is_multivalue)
  VALUES(1, 'Country', 'com.monsanto.tcc.lexicon.typedata.country.CountryDynamicValueCollection', 'y');

INSERT INTO User_Preference_Definition (user_preference_definition_id, user_pref_name, metadata, is_multivalue)
  VALUES(2, 'Crop', 'com.monsanto.tcc.lexicon.typedata.crop.CropDynamicValueCollection', 'y');
END;
/

