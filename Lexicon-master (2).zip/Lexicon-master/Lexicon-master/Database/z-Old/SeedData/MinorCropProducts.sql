-- Step1: Add temp table MIRAGE_MINORCROP_BAYER_CODE, with 1 field BAYER_CODE_NAME.

delete Lexicon.MIRAGE_MINORCROP_BAYER_CODE;

insert into Lexicon.MIRAGE_MINORCROP_BAYER_CODE (Bayer_code_name)
(select lbc.bayer_code_name from lexicon.bayer_code lbc
  where lbc.bayer_code_name not in ('ZEAMD', 'GLXMA', 'SORCU', 'SORGR', 'HELAN', 'GOSHI', 'BRSNC', 'BRSNW'));
  
-- Step 2:  Add temp table MIRAGE_MINORCROP_COMPET_COMP, with 1 field COMPANY_NAME.
 
delete  lexicon.MIRAGE_MINORCROP_COMPET_COMP;
 
insert into Lexicon.MIRAGE_MINORCROP_COMPET_COMP (company_name)
(select lb.brand_name from lexicon.brand lb
  where lb.brand_name not in ('UNKNOWN', 'AGROCERES', 'ASGROW', 'CARNIA', 'CERES', 'CORN STATES', 
 'CORN STATES INTERNATIONAL', 'DEKALB', 'DEKASOL', 'FIRST LINE', 'HARTZ', 'MONSOY', 'SENSAKO', 'MONSANTO', 'HOLDEN''S')
  );

-- Step 3. Count Mirage products to be loaded to temp MIRAGE_SEED_PRODUCT table, including all crops and
--         companies/brands.
 
 Select count(*)
 from
 (select distinct msp.product_id, trim(msp.crop_bayer_code)
        
  FROM  mirage2.seed_products@ceregn msp, 
        mirage2.companies@ceregn mcomp, 
	 	mirage2.treatment_list@ceregn mtl,
	    mirage2.experiments@ceregn me, 
		mirage2.cooperator_site_location@ceregn mcsl,
        mirage2.subsubcountries@ceregn mssc, 
		mirage2.countries@ceregn mctry
        
  where msp.company_id = mcomp.company_id
     and msp.product_id = mtl.seed_product_id 
     and mtl.experiment_number = me.experiment_number
     and me.experiment_number = mcsl.experiment_number 
     and mcsl.site_subsubcountry_code = mssc.subsubcountry_code 
     and mssc.country_code = mctry.country_code
     and msp.enabled = 'Y' 
     and msp.equivalent_product_id is null
     and me.experiment_year > 1999
     and msp.crop_bayer_code is not null
 );
  
-- Step 4:  Load temp table MIRAGE_SEED_PRODUCT with data

delete Lexicon.MIRAGE_SEED_PRODUCT;

insert into lexicon.MIRAGE_SEED_PRODUCT (product_id, crop_bayer_code)

(select distinct msp.product_id, trim(msp.crop_bayer_code)
        
  FROM  mirage2.seed_products@ceregn msp, 
        mirage2.companies@ceregn mcomp, 
	    mirage2.treatment_list@ceregn mtl, 
	    mirage2.experiments@ceregn me, 
		mirage2.cooperator_site_location@ceregn mcsl,
        mirage2.subsubcountries@ceregn mssc, 
		mirage2.countries@ceregn mctry
        
  where msp.company_id = mcomp.company_id
     and msp.product_id = mtl.seed_product_id 
     and mtl.experiment_number = me.experiment_number
     and me.experiment_number = mcsl.experiment_number 
     and mcsl.site_subsubcountry_code = mssc.subsubcountry_code 
     and mssc.country_code = mctry.country_code
     and msp.enabled = 'Y' 
     and msp.equivalent_product_id is null
     and me.experiment_year > 1999
     and msp.crop_bayer_code is not null
);
  
-- Step 5. Count Mirage products at the country level to be loaded to temp MIRAGE_SEED_PRODUCT_NAME table, 
-- including all crops and companies/brands.
 
 Select count(*)
 from
 -- need "distinct" because the product is on many treatment lists on many several experiments.
  
 (select distinct msp.crop_bayer_code, msp.product_id, mcomp.company_name, msp.product_name, mctry.country_code 
        
  FROM  mirage2.seed_products@ceregn msp, 
        mirage2.companies@ceregn mcomp, 
	 	mirage2.treatment_list@ceregn mtl,
	    mirage2.experiments@ceregn me, 
		mirage2.cooperator_site_location@ceregn mcsl,
        mirage2.subsubcountries@ceregn mssc, 
		mirage2.countries@ceregn mctry
        
  where msp.company_id = mcomp.company_id
     and msp.product_id = mtl.seed_product_id 
     and mtl.experiment_number = me.experiment_number
     and me.experiment_number = mcsl.experiment_number 
     and mcsl.site_subsubcountry_code = mssc.subsubcountry_code 
     and mssc.country_code = mctry.country_code
     and msp.enabled = 'Y' 
     and msp.equivalent_product_id is null
     and me.experiment_year > 1999
     and msp.crop_bayer_code is not null
 );
  
-- Step 6:  Load temp table MIRAGE_SEED_PRODUCT_NAME
-- May NOT need to reload.  Any new products for minor crops should be loaded via Lexicon to Midas and Mirage now, 
-- so the list of products shouldn't change.

delete Lexicon.MIRAGE_SEED_PRODUCT_NAME;

-- Run select to create insert statements.  (did this way, because insert into xxx select ran forever!!)
										
select 'insert into lexicon.mirage_seed_product_name (product_name_id, product_id, company_name, crop_bayer_code, product_name, comments, country_name) values (''' ||
       iq.fieldid|| ''','''||iq.product_id||''','''|| replace(iq.company_name,'''', '''''') ||''','''|| iq.crop_bayer_code ||''','''|| iq.product_name ||''','|| replace(decode(iq.comments,null,'NULL', ''''||iq.comments||''''), ''', ''''') ||','''|| iq.country_name ||''');'
 from (
select distinct 
msp.product_id || '.' || mctry.country_code as fieldid, msp.product_id, mcomp.company_name, msp.crop_bayer_code,  
          msp.product_name, msp.comments, mctry.country_name
        
  FROM  mirage2.seed_products@ceregn msp, 
        mirage2.companies@ceregn mcomp, 
	    mirage2.treatment_list@ceregn mtl, 
	    mirage2.experiments@ceregn me, 
		mirage2.cooperator_site_location@ceregn mcsl,
        mirage2.subsubcountries@ceregn mssc, 
		mirage2.countries@ceregn mctry
        
  where msp.company_id = mcomp.company_id
     and msp.product_id = mtl.seed_product_id 
     and mtl.experiment_number = me.experiment_number
     and me.experiment_number = mcsl.experiment_number 
     and mcsl.site_subsubcountry_code = mssc.subsubcountry_code 
     and mssc.country_code = mctry.country_code
     and msp.enabled = 'Y' 
     and msp.equivalent_product_id is null
     and me.experiment_year > 1999
     and msp.crop_bayer_code is not null 
 
) iq
;     
-- Step 7:  Save insert statements from above query to a text file, then open it and run the insert statements.
--          Then return to this query.
-- Step 8:  Test that all records are loaded.

select count(*) from lexicon.mirage_seed_product_name;

-- Step 9: 
-- Before the load of Mirage products into Lexicon, need to make country names match between Lexicon and Mirage.
-- RUN ONCE, at end set country names back to Lexicon names.

 Update Lexicon.country set country_name = 'UNITED STATES' where country_name = 'UNITED STATES OF AMERICA';
 Update Lexicon.country set country_name = 'UNITED KINGDOM' 
     where country_name = 'UNITED KINGDOM OF GREAT BRITAIN AND NORTHERN IRELA';
 Update Lexicon.country set country_name = 'RUSSIA' where country_name = 'RUSSIAN FEDERATION';
 Update Lexicon.country set country_name = 'REPUBLICA DOMINICANA' where country_name = 'DOMINICAN REPUBLIC';
 Update Lexicon.country set country_name = 'FRENCH GUYANA' where country_name = 'FRENCH GUIANA';
 Update Lexicon.country set country_name = 'GUADALOUPE' where country_name = 'GUADELOUPE';
 Update Lexicon.country set country_name = 'ANTIGUA & BARBUDA' where country_name = 'ANTIGUA AND BARBUDA';
 Update Lexicon.country set country_name = 'TRINIDAD & TOBAGO' where country_name = 'TRINIDAD AND TOBAGO';
 Update Lexicon.country set country_name = 'LAOS' where country_name = 'LAO PEOPLE''S DEMOCRATIC REPUBLIC';
 Update Lexicon.country set country_name = 'TANZANIA' where country_name = 'UNITED REPUBLIC OF TANZANIA';
 Update Lexicon.country set country_name = 'VIETNAM' where country_name = 'VIET NAM';
 
 -- Step 10: Get count of minor crop, competitive products from Mirage to be loaded to Lexicon database.
 -- In lexicon, use MIRAGE SEED PRODUCT table joined to minor crop bayer codes, and minor crop competitors 
  -- to get the records to load to the Lexicon Product and Product_name tables.  This query will knock out 
  -- the major crop bayer codes and it'll knock out, the Monsanto brands.
  -- counts product (not product name) records to be loaded to Lexicon.product.
  
 select count(*)
 from
 (select distinct msp.product_id, lcrop.crop_name
  from Lexicon.mirage_seed_product msp, 
       Lexicon.mirage_seed_product_name mspn,
       Lexicon.mirage_minorcrop_bayer_code mbc,
       Lexicon.mirage_minorcrop_compet_comp mcomp,
       lexicon.brand lb,
       lexicon.bayer_code lbc,
       lexicon.crop lcrop,
       lexicon.country lctry
       
  where msp.product_id = mspn.product_id
     and mspn.company_name = mcomp.company_name
     and trim(mspn.crop_bayer_code) = mbc.bayer_code_name
     and mspn.company_name = lb.brand_name
     and trim(mspn.crop_bayer_code) = lbc.bayer_code_name
     and lbc.crop_id = lcrop.crop_id
     and mspn.country_name = lctry.country_name
 ) ;
 
-- Step 11:  Counts Mirage Seed Product (competitor and minor crop) product name records to be loaded to
--          Lexicon.product_name.
  
select count(*)
 from
 (select 
         mspn.product_name_id, mspn.product_id, lb.brand_id, mspn.product_name, lbc.bayer_code_name, lctry.country_id
		 
  from Lexicon.mirage_seed_product msp, 
       Lexicon.mirage_seed_product_name mspn,
       Lexicon.mirage_minorcrop_bayer_code mbc,
       Lexicon.mirage_minorcrop_compet_comp mcomp,
       lexicon.brand lb,
       lexicon.bayer_code lbc,
       lexicon.crop lcrop,
       lexicon.country lctry
       
  where msp.product_id = mspn.product_id
     and mspn.company_name = mcomp.company_name
     and trim(mspn.crop_bayer_code) = mbc.bayer_code_name
     and mspn.company_name = lb.brand_name
     and trim(mspn.crop_bayer_code) = lbc.bayer_code_name
     and lbc.crop_id = lcrop.crop_id
     and mspn.country_name = lctry.country_name
 ) ;
-- Run to see brand names, country names, minor crops. 
select 
   mspn.product_name_id, mspn.product_id, lb.brand_name, mspn.product_name, lbc.bayer_code_name, lctry.country_name
		 
  from Lexicon.mirage_seed_product msp, 
       Lexicon.mirage_seed_product_name mspn,
       Lexicon.mirage_minorcrop_bayer_code mbc,
       Lexicon.mirage_minorcrop_compet_comp mcomp,
       lexicon.brand lb,
       lexicon.bayer_code lbc,
       lexicon.crop lcrop,
       lexicon.country lctry
       
  where msp.product_id = mspn.product_id
     and mspn.company_name = mcomp.company_name
     and trim(mspn.crop_bayer_code) = mbc.bayer_code_name
     and mspn.company_name = lb.brand_name
     and trim(mspn.crop_bayer_code) = lbc.bayer_code_name
     and lbc.crop_id = lcrop.crop_id
     and mspn.country_name = lctry.country_name;
     
     
  
-- Step 12: Populate product_id cross reference for Mirage and Lexicon products.

insert into lexicon.mirage_lexicon_product (mirage_product_id, lexicon_product_id)
(select iq.productid, lexicon.product_id_seq.nextval 
   from 
    
(select distinct msp.product_id as productid --, lcrop.crop_id as CropId                     
  from lexicon.mirage_seed_product msp,
       lexicon.mirage_seed_product_name mspn, 
       lexicon.mirage_minorcrop_bayer_code mbc,
       lexicon.mirage_minorcrop_compet_comp mcomp,
       lexicon.brand lb,
       lexicon.bayer_code lbc,
       lexicon.crop lcrop,
       lexicon.country lctry
       
  where  msp.product_id = mspn.product_id 
     and mspn.company_name = mcomp.company_name
     and trim(msp.crop_bayer_code) = mbc.bayer_code_name
     and mspn.company_name = lb.brand_name
     and trim(msp.crop_bayer_code) = lbc.bayer_code_name
     and lbc.crop_id = lcrop.crop_id
     and mspn.country_name = lctry.country_name
 ) iq
 );
   
     
-- Step 13: Insert minor crop products into Lexicon.product. 
  
 insert into lexicon.product (product_pubkey, product_id, crop_id) 
(
select lexicon.product_pubkey_seq.nextval, iq.productid, iq.CropId  
 FROM 
(select distinct lmap.lexicon_product_id as productid, lcrop.crop_id as CropId                     
  from lexicon.mirage_seed_product msp,
       lexicon.mirage_lexicon_product lmap,
       lexicon.mirage_seed_product_name mspn, 
       lexicon.mirage_minorcrop_bayer_code mbc,
       lexicon.mirage_minorcrop_compet_comp mcomp,
       lexicon.brand lb,
       lexicon.bayer_code lbc,
       lexicon.crop lcrop,
       lexicon.country lctry
       
  where  msp.product_id = mspn.product_id 
     and msp.product_id = lmap.mirage_product_id
     and mspn.company_name = mcomp.company_name
     and trim(msp.crop_bayer_code) = mbc.bayer_code_name
     and mspn.company_name = lb.brand_name
     and trim(msp.crop_bayer_code) = lbc.bayer_code_name
     and lbc.crop_id = lcrop.crop_id
     and mspn.country_name = lctry.country_name
 ) iq
 );

-- Step 14: Insert minor crop products into Lexicon.product_name table.  
  
insert into lexicon.product_name (product_name_pubkey, product_id, product_name_id, brand_id, bayer_code_id, 
country_id, product_name, is_active)
(
select lexicon.product_name_pubkey_seq.nextval, iq.productid, lexicon.product_name_id_seq.nextval,
       iq.brandid, iq.bayercodeid, iq.countryid, iq.productname, 'y'
From
(select 
        lmap.lexicon_product_id as productid,
        lb.brand_id as brandid, 
        lbc.bayer_code_id as bayercodeid, 
        lctry.country_id as countryid, 
		mspn.product_name as productname
                     
 from  lexicon.mirage_seed_product msp,
       lexicon.mirage_lexicon_product lmap,
       lexicon.mirage_seed_product_name mspn, 
       lexicon.mirage_minorcrop_bayer_code mbc,
       lexicon.mirage_minorcrop_compet_comp mcomp,
       lexicon.brand lb,
       lexicon.bayer_code lbc,
       lexicon.crop lcrop,
       lexicon.country lctry
       
  where  msp.product_id = mspn.product_id
     and msp.product_id = lmap.mirage_product_id
     and mspn.company_name = mcomp.company_name
     and trim(msp.crop_bayer_code) = mbc.bayer_code_name
     and mspn.company_name = lb.brand_name
     and trim(msp.crop_bayer_code) = lbc.bayer_code_name
     and lbc.crop_id = lcrop.crop_id
     and mspn.country_name = lctry.country_name
 ) iq
 );
  
-- Run once after the load to set the countries back to the Lexicon country name.

Update Lexicon.country set country_name = 'UNITED STATES OF AMERICA' where country_name = 'UNITED STATES';
 Update Lexicon.country set country_name = 'UNITED KINGDOM OF GREAT BRITAIN AND NORTHERN IRELA' 
     where country_name = 'UNITED KINGDOM';
 Update Lexicon.country set country_name = 'RUSSIAN FEDERATION' where country_name = 'RUSSIA';
 Update Lexicon.country set country_name = 'DOMINICAN REPUBLIC' where country_name = 'REPUBLICA DOMINICANA';
 Update Lexicon.country set country_name = 'FRENCH GUIANA' where country_name = 'FRENCH GUYANA';
 Update Lexicon.country set country_name = 'GUADELOUPE' where country_name = 'GUADALOUPE';
 Update Lexicon.country set country_name = 'ANTIGUA AND BARBUDA' where country_name = 'ANTIGUA & BARBUDA';
 Update Lexicon.country set country_name = 'TRINIDAD AND TOBAGO' where country_name = 'TRINIDAD & TOBAGO';
 Update Lexicon.country set country_name = 'LAO PEOPLE''S DEMOCRATIC REPUBLIC' where country_name = 'LAOS';
 Update Lexicon.country set country_name = 'UNITED REPUBLIC OF TANZANIA' where country_name = 'TANZANIA';
 Update Lexicon.country set country_name = 'VIET NAM' where country_name = 'VIETNAM';
 

-- Ran query below, and sent results to Wendi to get countries.
-- Find competitive products for minor crops without a treatment list for products entered in 2004.
  --Need to get a country for them.
  
 select iq.product_id, iq.company_Name, iq.product_name, iq.audit_insert_date, iq.comments, mkw.name, mkw.value 
 from 
  mirage2.seed_products_regions@ceregn mspr,
  mirage2.kw@ceregn mkw,
  
 (select msp.product_id, mc.company_name, msp.product_name, msp.audit_insert_date, msp.comments 
 
 From mirage2.seed_Products@ceregn msp, 
      mirage2.companies@ceregn mc,
      mirage2.treatment_list@ceregn mtl,
      lexicon.MIRAGE_MINORCROP_BAYER_CODE mmbc,
      Lexicon.mirage_minorcrop_compet_comp mcomp
  
 where 
      msp.company_id = mc.company_id
  and msp.product_id = mtl.seed_product_id (+) and mtl.seed_product_id is null
  and msp.audit_insert_date > '31-DEC-2003'
  and trim(msp.crop_bayer_code) = mmbc.bayer_code_name -- minor crop
  and mc.company_name = mcomp.company_name )      -- not Monsanto brand
  iq
  
  where
      iq.product_id = mspr.product_id
  and mspr.region_code = mkw.code ;
  
  
  --    and rownum <= 100

