
-- Check Mirage .

select * 
from mirage2.seed_products@ceregn_tst sp, 
     mirage2.countries@ceregn_tst c,
     mirage2.companies@ceregn_tst m,
     mirage2.kw@ceregn_tst k,
     mirage2.kw@ceregn_tst kk,
     mirage2.seed_products_maturity@ceregn_tst spm
    
where sp.company_id = m.company_id
and sp.trait_characteristic_code = k.code (+)
and sp.country_code = c.country_code
and sp.product_id = spm.product_id
and spm.maturity_unit = kk.code (+)
and kk.name = 'RM'
and sp.crop_bayer_code = 'ZEAMD' and sp.product_name = 'BETTER' and m.company_name = 'ADLER';



-- Check Midas
select t.name as "Crop", p.product_id, pn.product_name_id, pn.name "Product name",  b.name "Brand", s.name "Stage"
from midas.product_name@prem_tst pn,
     midas.product@prem_tst p,
     midas.crop@prem_tst t,
     midas.brand@prem_tst b,
     midas.country@prem_tst c,
     midas.product_stage@prem_tst s
where pn.product_id = p.product_id
     and p.crop_id = t.crop_id
     and pn.brand_id = b.brand_id
     and pn.country_id = c.country_id
     and pn.product_stage_id = s.product_stage_id
     and t.name = 'Corn' and pn.name in ('BETTER', 'CORN12'); -- and c.name = 'United States of America';
    
;


-- need to check fbs common, and yldstg too.
-- let dave check germplasm and genetic material
