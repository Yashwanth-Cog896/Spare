 
-- Use to load Lexicon Crop table, load first before loading Bayer Code table.

select c.name
from midas.crop@prem c
where c.name <> 'Wheat'
;
-- This query below produces dups on the bayer code because of 2 different common names, so I listed the names that
-- are causing the dups to eliminate them from the load.  Also, not loading bayer codes that link to Midas crops because
-- they will be loaded from Midas.

SELECT distinct a.bayer_code, b.common_name
  FROM mirage2.species@ceregn a, mirage2.species_names@ceregn b, mirage2.kw@ceregn k, 
       mirage2.seed_products@ceregn p
  where b.bayer_code = a.bayer_code and k.code = a.species_type_code and a.bayer_code = p.crop_bayer_code
  and k.value = 'CROP' 
  and a.bayer_code not in ('BRSNC', 'BRSNW', 'ZEAMD', 'GOSHI', 'SORCU', 'SORGR', 'GLXMA', 'HELAN') 
  and b.common_name not in ('SUGAR BEET', 'BARLEY, FOUR-ROWED (=SIX-ROWED)', 'APPLES', 
  'BEAN, NAVY', 'SITKA SPRUCE', 'SORGHUM (GRAIN)', 'CHICHORY, WITLOOF', 'ZANAHORIA', 'LECHUGA', 
         'CABBAGE, FIELD', 'TURNIP, WILD', 'GUMTREE')
     -- for production
--	     and b.common_name not in ('BARLEY, FOUR-ROWED (=SIX-ROWED)', 'APPLES', 'BEAN, NAVY', 'SITKA SPRUCE', 'SORGHUM (GRAIN)',
--         'CABBAGE, FIELD', 'TURNIP, WILD', 'GUMTREE')
  order by a.bayer_code
;

-- Step 0. Delete data in tables.
delete lexicon.product_name;
delete lexicon.product;
delete lexicon.coml_trait_stack_name_xref;
delete lexicon.coml_trait_stack_xref;
delete lexicon.coml_trait_stack;
delete lexicon.coml_trait_name;
delete lexicon.coml_trait_type_xref;
delete lexicon.coml_trait;
delete lexicon.bayer_code;
delete lexicon.crop;


-- Step 1.  Load Midas Crop codes to the Lexicon Crop Table. 

insert into lexicon.crop (crop_id, crop_name)  
(select lexicon.crop_id_seq.nextval, Upper(a.name)
From midas.crop@prem a
where a.name <> 'Wheat')
;


-- Step 2.  Load Mirage Crops (being used by seed products) to Lexicon Crop table excluding the Midas crops.
-- Omit common-names below because they have another common_name linking to the same bayer code, making duplicate bayer codes.

insert into lexicon.crop (crop_id, crop_name )
(select lexicon.crop_id_seq.nextval,  iq.CommonName
  FROM (
        SELECT DISTINCT b.common_name AS CommonName
          FROM mirage2.species@ceregn a, mirage2.species_names@ceregn b, mirage2.kw@ceregn k, 
		  mirage2.seed_products@ceregn p
         where b.bayer_code = a.bayer_code and k.code = a.species_type_code and a.bayer_code = p.crop_bayer_code
           and k.value = 'CROP' 
           and a.bayer_code not in ('BRSNC', 'BRSNW', 'ZEAMD', 'GOSHI', 'SORCU', 'SORGR', 'GLXMA', 'HELAN') 
          and b.common_name not in ('SUGAR BEET', 'BARLEY, FOUR-ROWED (=SIX-ROWED)', 'APPLES', 
  'BEAN, NAVY', 'SITKA SPRUCE', 'SORGHUM (GRAIN)', 'CHICHORY, WITLOOF', 'ZANAHORIA', 'LECHUGA', 
         'CABBAGE, FIELD', 'TURNIP, WILD', 'GUMTREE')
		) iq
 )
 ;
 -- Step 3.  Load Bayer Codes to Lexicon Bayer Code table.
 -- Get bayer codes from Mirage, linking to Lexicon.Crop table to limit bayer codes to those that are in the Crop table.
 -- Omit loading the bayer codes for the midas crops because the crop names loaded from Midas won't match the common
 -- name from mirage species.

insert into lexicon.bayer_code (bayer_code_id, bayer_code_name, bayer_code_desc, crop_id )
(select lexicon.bayer_code_id_seq.nextval, ltrim(rtrim(iq.bayercode)), iq.cropname, iq.cropid
        From (
        Select distinct a.bayer_code AS bayercode, c.crop_name as cropname, c.crop_id as cropid
        FROM lexicon.crop c, mirage2.species@ceregn a, mirage2.species_names@ceregn b
        where c.crop_name = b.common_name and b.bayer_code = a.bayer_code 
     and a.bayer_code not in ('BRSNC', 'BRSNW', 'ZEAMD', 'GOSHI', 'SORCU', 'SORGR', 'GLXMA', 'HELAN')
     and b.common_name not in ('SUGAR BEET', 'BARLEY, FOUR-ROWED (=SIX-ROWED)', 'APPLES', 
  'BEAN, NAVY', 'SITKA SPRUCE', 'SORGHUM (GRAIN)', 'CHICHORY, WITLOOF', 'ZANAHORIA', 'LECHUGA', 
         'CABBAGE, FIELD', 'TURNIP, WILD', 'GUMTREE')
 ) iq
 )
;

-- Step 4.  Load bayer codes for Midas crops.  This ensures Midas crop names are in the table, not Mirage common 
-- names for Midas crops.
    
INSERT INTO lexicon.bayer_code (bayer_code_id, bayer_code_name, bayer_code_desc, crop_id) 
(select lexicon.bayer_code_id_seq.nextval, 'ZEAMD', c.crop_name, c.crop_id
from lexicon.crop c
where c.crop_name = 'CORN'
)
;
INSERT INTO lexicon.bayer_code (bayer_code_id, bayer_code_name, bayer_code_desc, crop_id) 
(select lexicon.bayer_code_id_seq.nextval, 'BRSNC', c.crop_name, c.crop_id
from lexicon.crop c
where c.crop_name = 'OSR-CANOLA'
)
;
INSERT INTO lexicon.bayer_code (bayer_code_id, bayer_code_name, bayer_code_desc, crop_id) 
(select lexicon.bayer_code_id_seq.nextval, 'BRSNW', c.crop_name, c.crop_id
from lexicon.crop c
where c.crop_name = 'OSR-CANOLA'
)
;
INSERT INTO lexicon.bayer_code (bayer_code_id, bayer_code_name, bayer_code_desc, crop_id) 
(select lexicon.bayer_code_id_seq.nextval, 'GLXMA', c.crop_name, c.crop_id
from lexicon.crop c
where c.crop_name = 'SOYBEANS'
)
;
INSERT INTO lexicon.bayer_code (bayer_code_id, bayer_code_name, bayer_code_desc, crop_id) 
(select lexicon.bayer_code_id_seq.nextval, 'SORCU', c.crop_name, c.crop_id
from lexicon.crop c
where c.crop_name = 'SORGHUM'
)
;
INSERT INTO lexicon.bayer_code (bayer_code_id, bayer_code_name, bayer_code_desc, crop_id) 
(select lexicon.bayer_code_id_seq.nextval, 'SORGR', c.crop_name, c.crop_id
from lexicon.crop c
where c.crop_name = 'SORGHUM'
)
;
INSERT INTO lexicon.bayer_code (bayer_code_id, bayer_code_name, bayer_code_desc, crop_id) 
(select lexicon.bayer_code_id_seq.nextval, 'GOSHI', c.crop_name, c.crop_id
from lexicon.crop c
where c.crop_name = 'COTTON'
)
;
INSERT INTO lexicon.bayer_code (bayer_code_id, bayer_code_name, bayer_code_desc, crop_id) 
(select lexicon.bayer_code_id_seq.nextval, 'HELAN', c.crop_name, c.crop_id
from lexicon.crop c
where c.crop_name = 'SUNFLOWER'
)
;

/*
grant select on crop_id_seq to ngscho;
grant select on bayer_code_id_seq to ngscho;
grant insert,update,delete,select on crop to ngscho;
grant insert,update,delete,select on bayer_code to ngscho;
*/



