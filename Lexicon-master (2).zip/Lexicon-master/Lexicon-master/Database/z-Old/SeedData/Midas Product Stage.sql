select distinct b.name "brand", pn.name "product", ps.name "stage", ps.ref_active
from midas.product p,
	 midas.product_name pn,
     midas.brand b,
     midas.company c,
     midas.product_stage ps
where p.product_id = pn.product_id
and   pn.brand_id = b.brand_id
and   b.company_id = c.company_id
and   c.name = 'MONSANTO'
and pn.product_stage_id = ps.product_stage_id 
and pn.ref_active = 'T'
and ps.name = 'CP1';

select distinct b.name "brand", pn.name "product", ps.name "stage", ps.ref_active
from midas.product p,
	 midas.product_name pn,
     midas.brand b,
     midas.company c,
     midas.product_stage ps
where p.product_id = pn.product_id
and   pn.brand_id = b.brand_id
and   b.company_id = c.company_id
and   c.name = 'MONSANTO'
and pn.product_stage_id = ps.product_stage_id 
and pn.ref_active = 'T'
and ps.name = 'CPX';

select distinct b.name "brand", pn.name "product", ps.name "stage", ps.product_stage_ref_id, ps.ref_active
from midas.product p,
	 midas.product_name pn,
     midas.brand b,
     midas.company c,
     midas.product_stage ps
where p.product_id = pn.product_id
and   pn.brand_id = b.brand_id
and   b.company_id = c.company_id
and   c.name = 'MONSANTO'
and pn.product_stage_id = ps.product_stage_id 
and pn.ref_active = 'T'
and ps.product_stage_ref_id in ('OLD1', 'OLD2', 'OLD7');

select distinct b.name "brand", pn.name "product", ps.name "stage", t.name "country", ps.ref_active
from midas.product p,
	 midas.product_name pn,
     midas.brand b,
     midas.company c,
     midas.product_stage ps,
     midas.country t
where p.product_id = pn.product_id
and   pn.brand_id = b.brand_id
and   b.company_id = c.company_id
and   c.name = 'MONSANTO'
and pn.product_stage_id = ps.product_stage_id 
and pn.country_id = t.country_id
and pn.ref_active = 'T'
and pn.name in (
'A7573',
'AI9868',
'AI996ABT',
'ALCE',
'ALHAJA',
'AP2155T',
'BELEM',
'FLEURET',
'FORTE',
'MH2212',
'MIREVAL',
'RX326',
'RX326',
'RX348',
'RX393',
'RX393',
'RX481',
'RX481',
'RX634',
'RX670YG',
'RX708',
'RX708',
'RX764',
'RX773',
'RX901W',
'RX938',
'XP7908',
'333B',
'CRN1414',
'CRN30B',
'CRN3893',
'ARESOL',
'CAMERON',
'CH04C1',
'CH04C2',
'COSENO',
'TECLEADO',
'605F',
'ADANA',
'AGENOR',
'AGROBEL962',
'AGROBEL972DM',
'AI9943BT',
'AI996BBT',
'ALLER',
'ALTDEK',
'ANDRODEK',
'ARAMIS',
'ARSENAL',
'ASMAR',
'AW831',
'BIRKO',
'C7993',
'CADASOL',
'CANDISOL',
'CHALLENGER',
'CIGAL',
'CIVIC',
'CLEDESOL',
'COACH',
'COBAN',
'D47',
'D65',
'D861',
'D865',
'D866',
'D867',
'D867',
'D869',
'D869',
'D871',
'D880',
'D891',
'DK119',
'DK183',
'DK2002',
'DK207',
'DK207',
'DK210',
'DK212',
'DK221',
'DK227',
'DK230',
'DK233',
'DK237',
'DK243',
'DK250',
'DK256',
'DK267',
'DK272',
'DK277',
'DK281',
'DK281',
'DK287',
'DK287',
'DK28E',
'DK292',
'DK295',
'DK298',
'DK300',
'DK302',
'DK307',
'DK307',
'DK308',
'DK312',
'DK315',
'DK325',
'DK343',
'DK345',
'DK353',
'DK355',
'DK356',
'DK365',
'DK366',
'DK37',
'DK376',
'DK3790',
'DK38',
'DK3810',
'DK3820',
'DK3845',
'DK3849',
'DK385B',
'DK386',
'DK3868',
'DK3875',
'DK3878',
'DK3880CL',
'DK3884',
'DK3900',
'DK3900',
'DK3900DM',
'DK391',
'DK3915',
'DK3915',
'DK3920',
'DK3945',
'DK39Y',
'DK3S41',
'DK3S41',
'DK4000CL',
'DK4000CL263',
'DK4030',
'DK4040',
'DK4040',
'DK405',
'DK4050',
'DK4050DM',
'DK40Y',
'DK417',
'DK41Y',
'DK4200',
'DK431',
'DK432',
'DK434',
'DK442',
'DK443',
'DK443',
'DK446',
'DK449',
'DK454',
'DK471',
'DK477',
'DK483',
'DK48A',
'DK493',
'DK493BTX',
'DK493GR',
'DK493RR',
'DK493SR',
'DK493WX',
'DK4F37',
'DK502',
'DK507',
'DK507',
'DK512',
'DK512BTY',
'DK512RR',
'DK514',
'DK521',
'DK523',
'DK524',
'DK525',
'DK526',
'DK527',
'DK52G',
'DK537',
'DK539',
'DK539',
'DK54',
'DK545BTY',
'DK546',
'DK547',
'DK55',
'DK551',
'DK559',
'DK56',
'DK560',
'DK560',
'DK560WX'
)
order by b.name, pn.name
;
select distinct b.name "brand", pn.name "product", ps.name "stage", t.name "country", ps.ref_active "stage status"
from midas.product p,
	 midas.product_name pn,
     midas.brand b,
     midas.company c,
     midas.product_stage ps,
     midas.country t
where p.product_id = pn.product_id
and   pn.brand_id = b.brand_id
and   b.company_id = c.company_id
and pn.country_id = t.country_id
and   c.name = 'MONSANTO'
and pn.product_stage_id = ps.product_stage_id 
and pn.ref_active = 'T'
and pn.name = 'DK210';




