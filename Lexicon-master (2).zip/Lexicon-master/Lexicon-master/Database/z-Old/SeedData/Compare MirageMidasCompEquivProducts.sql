select sp.crop_bayer_code, c.company_name, sp.product_id, sp.product_name, sp.enabled, sp.equivalent_product_id,
     eqsp.product_id, eqc.company_name, eqsp.product_name, eqsp.enabled, eqsp.equivalent_product_id,
     b.name "Midas Brand", pn.name "Midas product", pn.country_id, pn.ref_active
from mirage2.seed_products@ceregn sp, 
mirage2.companies@ceregn c, 
mirage2.seed_products@ceregn eqsp, 
mirage2.companies@ceregn eqc, 
lexicon.mirage_minorcrop_compet_comp mmcc, 
yldstg.map_product_mirage@prem mpm,
midas.product@prem p,
midas.product_name@prem pn,
midas.brand@prem b

where sp.company_id = c.company_id 
and c.company_name = mmcc.company_name
and sp.equivalent_product_id = eqsp.product_id
and eqsp.company_id = eqc.company_id 
and sp.equivalent_product_id is not null 

and sp.product_id = mpm.seed_product_id 
and mpm.product_pk = p.product_id
and p.product_id = pn.product_id
and pn.brand_id = b.brand_id
;

-- count the number of product_names for each bayer/code and crop.

select distinct sp.crop_bayer_code, p.crop_id, sp.enabled, count(*) 

from mirage2.seed_products@ceregn sp, 
  mirage2.companies@ceregn c, 
  lexicon.mirage_minorcrop_compet_comp mmcc, 
  yldstg.map_product_mirage@prem mpm,
  midas.product@prem p

where sp.company_id = c.company_id 
and c.company_name = mmcc.company_name
and sp.equivalent_product_id is not null 
and sp.product_id = mpm.seed_product_id (+)
and mpm.product_pk = p.product_id (+)

group by sp.crop_bayer_code, p.crop_id, sp.enabled
;


