-- Lexicon DataDips:  Contains queries to view data issues.

-- 1. (MIDAS and LEXICON) Holden's marked as a competitor company in Midas.  Need to update MIDAS to make Holden's Monsanto, and delete
-- these 57 records from Lexicon product and product_name, 
-- and from fbs_common.product_xref, and fbs_common.product_name_xref

select * from Lexicon.product_name pn, lexicon.brand b
where pn.brand_id = b.brand_id and b.brand_name = 'HOLDEN''S';
  
-- 2/3. (LEXICON & YLDSTAGE) Lexicon didn't map (SORSL to Sorghum) or (BRSRA or BRSNR to OSR-Canola) or
-- (ZEAME to Corn) , so Major Crop load added it, 
-- since the product was in Midas, and the minor crop load added it, since it wasn't considered a major crop.
-- Need to remove the duplicate loaded from Mirage.   34 records, 17 need to be removed from product and product_name
-- and fbs_common.product_xref and product_name_xref.  This query gives us the 17 that were loaded from Mirage.
-- Need to add these bayer codes to MAP_CROP_MIRAGE.

select * from lexicon.product_name pn, lexicon.product p, lexicon.bayer_code lbc, 
              fbs_common.product_name_xref@prem fbspn, fbs_common.product_xref@prem fbsp
where pn.product_id = p.product_id and p.bayer_code_id = lbc.bayer_code_id
  and p.product_pubkey = fbsp.lexicon_product_pubkey (+) and fbsp.midas_product_id is not null
  and pn.product_name_pubkey = fbspn.lexicon_product_name_pubkey 
  and lbc.bayer_code_name in ('SORSL', 'BRSRA', 'BRSNR', 'ZEAME')
  order by pn.product_name;
  
-- 3a - Run query for Beth - wants to see products for ZEAME, with germplasm.  DONE.

select mcrop.name, mp.product_id, mpn.product_name_id, mb.name "Brand", mpn.name "Product", 
       mc.name "Country"  --, mgp.germplasm_id, mgp.pedigree_name
from   midas.product@prem mp,
	   midas.crop@prem mcrop,
	   midas.product_name@prem mpn,
		  midas.brand@prem mb,
		  midas.country@prem mc
	--	  midas.product_germplasm@prem mpg,
	--	  midas.germplasm@prem mgp
where  mp.product_id = mpn.product_id
and mpn.product_name_id in (2465552596992,2465552793600,2465552990208)
and mpn.brand_id = mb.brand_id
and mpn.country_id = mc.country_id
and mp.crop_id = mcrop.crop_id
--and mp.product_id = mpg.product_id
--and mpg.germplasm_id = mgp.germplasm_id
;
  
-- 4. (MIDAS CLEANUP) 7 products with inactive brands on active product/product_name in Midas.  The brand name = the product name.  
-- I think need to make the ref_active 'F' on product and product_name.  Do not load to Lexicon or Mirage.

select *
from midas.product@prem p,
	 midas.product_name@prem pn,
     midas.brand@prem b,
     midas.company@prem c
where p.product_id = pn.product_id
and   pn.brand_id = b.brand_id
and   b.company_id = c.company_id
and   c.name <> 'MONSANTO'
and   b.ref_active = 'F' 
and pn.ref_active = 'T' 
and p.ref_active = 'T'
;

-- 4a.  Beth wants to see if there is germplasm for these 7 products.


select *
from midas.product@prem p,
	 midas.product_name@prem pn,
     midas.brand@prem b,
     midas.company@prem c,
     midas.product_germplasm@prem pg,
	midas.germplasm@prem gp
where p.product_id = pn.product_id
and p.product_id = pg.product_id
and pg.germplasm_id = gp.germplasm_id
and   pn.brand_id = b.brand_id
and   b.company_id = c.company_id
and   c.name <> 'MONSANTO'
and   b.ref_active = 'F' 
and pn.ref_active = 'T' 
and p.ref_active = 'T'
;


-- 5. (MIDAS CLEANUP) 7 products with active brands and active product_name in Midas, with inactive product.  
-- Should we activate the product record or inactive the product_name?  
-- Depending on the answer, may have to load to Lexicon and Mirage.  (Could do with import.)

select *
from midas.product@prem p,
	 midas.product_name@prem pn,
     midas.brand@prem b,
     midas.company@prem c
where p.product_id = pn.product_id
and   pn.brand_id = b.brand_id
and   b.company_id = c.company_id
and   c.name <> 'MONSANTO'
and   b.ref_active = 'T' 
and pn.ref_active = 'T' 
and p.ref_active = 'F'
;

-- 5a.
select *
from midas.product@prem p,
	 midas.product_name@prem pn,
     midas.brand@prem b,
     midas.company@prem c,
     midas.product_germplasm@prem pg,
	midas.germplasm@prem gp
where p.product_id = pn.product_id
and p.product_id = pg.product_id
and pg.germplasm_id = gp.germplasm_id
and   pn.brand_id = b.brand_id
and   b.company_id = c.company_id
and   c.name <> 'MONSANTO'
and   b.ref_active = 'T' 
and pn.ref_active = 'T' 
and p.ref_active = 'F'
;


-- Find products in Mirage with GLXMA and RR2.  Lexicon didn't load RR2 on soybean products.

select * from  mirage2.seed_products@ceregn sp, mirage2.companies@ceregn c, mirage2.kw@ceregn kw
    where sp.company_id = c.company_id
	and sp.trait_characteristic_code = kw.code 
	and sp.crop_bayer_code = 'GLXMA' and kw.name = 'RR2';
	
	select * from midas.crop@prem where crop_id = 65994752

;
-- Find 

select b.name, pn.name, mpm.product_pk, mpm.seed_product_id, mpm.mirage_name
from midas.product@prem p,
	 midas.product_name@prem pn,
     midas.brand@prem b,
     midas.company@prem c,
     yldstg.map_product_mirage@prem mpm
--     midas.product_germplasm@prem pg,
--	midas.germplasm@prem gp
where p.product_id = pn.product_id
--and p.product_id = pg.product_id
--and pg.germplasm_id = gp.germplasm_id
and   pn.brand_id = b.brand_id
and   b.company_id = c.company_id
and   c.name <> 'MONSANTO'
and pn.product_name_id = 2729443727
and p.product_id = mpm.product_pk
--and pn.name = 'NIKOSI'
;

select count(distinct p.product_id) 
from midas.product@prem p,
    midas.product_name@prem pn,
    midas.brand@prem b,
    midas.company@prem c
where p.product_id = pn.product_id
and pn.brand_id = b.brand_id
and b.company_id = c.company_id and c.name <> 'MONSANTO'
;

select count(*) from
lexicon.product p, lexicon.bayer_code  bc
where p.bayer_code_id = bc.bayer_code_id and bc.bayer_code_name in ('ZEAMD', 'GLXMA', 'SORGR', 'SORCU', 'BRSNC', 'BRSNW', 'HELAN', 'GOSHI');
