
-- COUNTRY CHECKS
-- check country cross reference
select count(*) from fbs_common.Country_xref@prem fbsc;

-- detail to verify names.
select FBSC.Lexicon_country_pubkey, lc.country_name, lc.country_abbr, rc.country_abbrev, rc.country_name, 
       mc.name

from fbs_common.Country_xref@prem fbsc, 
     lexicon.country lc, 
     midas.country@prem mc, 
     mirage2.countries@ceregn rc
     
where fbsc.lexicon_country_pubkey = lc.country_pubkey 
     and fbsc.midas_country_id = mc.country_id 
     and fbsc.mirage_country_code = rc.country_code 
   --  and rc.country_code is null
;     

-- BRAND CHECKS  in test

-- Count active brands in Midas

Select count(*)
from Midas.brand@prem b
where b.ref_active = 'T';

-- Count brands in Yldmart

Select count(distinct name)
from Yldmart.brand@prem b

-- Find brands in Midas that aren't in Yldmart (Midas had more brands)

select b.brand_id, b.name
from Midas.brand@prem b, 
     yldmart.brand@prem yb
--where b.brand_id = yb.brand_pk (+) 
where b.name = yb.name (+)
  and yb.brand_pk is null
  and b.ref_active = 'T'
;

-- Find brands in Yldmart that aren't in Midas.

select yb.name
from yldmart.brand@prem_tst yb,
     Midas.brand@prem_tst b
--where  yb.brand_pk = b.brand_id (+) 
where yb.name = b.name (+)
  and b.brand_id is null;
  
  
select * from Midas.brand@prem b
where b.ref_active = 'T'
order by b.name;

-- Identify brands where Id in Midas doesn't match the id in Yldmart

select b.brand_id, b.name, yb.brand_pk, yb.name
from Midas.brand@prem_tst b, 
     yldmart.brand@prem_tst yb
--where b.brand_id = yb.brand_pk (+) 
where b.name = yb.name (+)
and b.brand_id <> yb.brand_pk
 -- and yb.brand_pk is null
  and b.ref_active = 'T'
;

-- Count companies in Mirage that are seed companies.

select count(*)
from Mirage2.companies@ceregn_tst c
where c.seed_flag = 'Y';

-- Find brands missing from Mirage.

select b.name
from Midas.brand@prem_tst b,
     Mirage2.companies@ceregn_tst c
where b.name = c.company_name (+)
  and c.company_name is null
  and b.ref_active = 'T';


-- Find brands missing from Midas.

select c.company_name, c.company_abbrev
from Mirage2.companies@ceregn_tst c,
     Midas.brand@prem_tst b
where c.company_name = b.name (+)
  and b.name is null
  and c.seed_flag = 'Y';
  
-- check brand cross reference
select count(*) from fbs_common.brand_xref@prem fbsb;

-- detail to compare names
select fbsb.Lexicon_brand_pubkey,  fbsb.Midas_brand_id, fbsb.Mirage_company_id,
      lb.brand_name, lb.brand_abbr,
    rb.company_name, rb.company_abbrev, 
      mb.name

from  fbs_common.brand_xref@prem fbsb,
      lexicon.brand lb,
      midas.brand@prem mb,
      mirage2.companies@ceregn rb
      
where  fbsb.lexicon_brand_pubkey = lb.brand_pubkey
      and  fbsb.midas_brand_id = mb.brand_id
      and fbsb.mirage_company_id = rb.company_id ;
     
-- MINOR CROP CHECKS for PRODUCT   
-- count minor crop products in Lexicon.

select count(*)
from lexicon.product_name pn, lexicon.product p, lexicon.bayer_code bc
where pn.product_id = p.product_id 
  and p.bayer_code_id = bc.bayer_code_id
  and bc.bayer_code_name not in ('ZEAMD', 'GLXMA', 'HELAN', 'SORGR', 'SORCU', 'BRSNW', 'BRSNC', 'GOSHI');
 
 
-- Count rows in fbs_common.product_name_xref for minor crop products.

select count(*) 
from (

select --lpn.product_name, count(distinct lpn.product_name)
lbc.bayer_code_name, Lpn.product_id, lpn.product_name_id, lc.crop_name, lb.brand_name, 
            lpn.product_name, lctry.country_name, sp.product_id, 
           sp.crop_bayer_code, rb.company_name, sp.product_name, rctry.country_name

from fbs_common.product_name_xref@prem fbspn,
     lexicon.product lp,
     lexicon.product_name lpn,
     lexicon.brand lb, 
     mirage2.seed_products@ceregn sp,
     mirage2.companies@ceregn rb,
    lexicon.country lctry,
    mirage2.countries@ceregn rctry,
     lexicon.bayer_code lbc,
     lexicon.crop lc
    
where fbspn.lexicon_product_name_pubkey = lpn.product_name_pubkey
  and lpn.product_id = lp.product_id
  and lpn.brand_id = lb.brand_id
  and fbspn.mirage_product_id = sp.product_id
  and sp.company_id = rb.company_id
 and lpn.country_id = lctry.country_id
  and sp.country_code = rctry.country_code
  and lp.bayer_code_id = lbc.bayer_code_id
  and lbc.crop_id = lc.crop_id
--  and lpn.product_name <> sp.product_name  -- check that product Names matched.
--   and lbc.bayer_code_name not in ('ZEAMD', 'GLXMA', 'HELAN', 'SORGR', 'SORCU', 'BRSNW', 'BRSNC', 'GOSHI')
  and lbc.bayer_code_name in ('SORSL', 'BRSRA', 'BRSNR')
group by lpn.product_name having count(*) > 1
  
  );  
select * from lexicon.bayer_code bc where bc.bayer_code_desc like '%CANOLA%' or bc.bayer_code_desc like 'RAPE%' order by bc.bayer_code_name;

-- check that product names for minor crops are cross referenced correctly in FBS_Common

select lbc.bayer_code_name, lb.brand_name, lpn.product_name, lctry.country_name, 
       sp.crop_bayer_code, rb.company_name, sp.product_name, rctry.country_name

from fbs_common.product_name_xref@prem fbspn,
     lexicon.product lp,
     lexicon.product_name lpn,
     lexicon.brand lb, 
     mirage2.seed_products@ceregn sp,
     mirage2.companies@ceregn rb,
     lexicon.country lctry,
     mirage2.countries@ceregn rctry,
     lexicon.bayer_code lbc
    
where fbspn.lexicon_product_name_pubkey = lpn.product_name_pubkey
  and lpn.product_id = lp.product_id
  and lpn.brand_id = lb.brand_id
  and fbspn.mirage_product_id = sp.product_id
  and sp.company_id = rb.company_id
  and lpn.country_id = lctry.country_id
  and sp.country_code = rctry.country_code
  and lp.bayer_code_id = lbc.bayer_code_id
  and lbc.bayer_code_name not in ('ZEAMD', 'GLXMA', 'HELAN', 'SORGR', 'SORCU', 'BRSNW', 'BRSNC', 'GOSHI');  
  
-- Count all minor crop active competitive products in Mirage (not including old product in equivalence).

select count(*)
from mirage2.seed_products@ceregn sp,
     mirage2.companies@ceregn c,
     mirage2.seed_products@ceregn eqsp
where sp.company_id = c.company_id
   and sp.enabled = 'Y'
   and sp.product_id = eqsp.equivalent_product_id (+)
   and eqsp.equivalent_product_id is null 
   and sp.crop_bayer_code not in ('ZEAMD', 'GLXMA', 'SORGR', 'SORCU', 'HELAN', 'GOSHI', 'BRSNW', 'BRSNC')
   and company_name not in ('AGROCERES', 'ASGROW', 'CARNIA', 'CERES', 'CORN STATES', 'CORN STATES INTERNATIONAL',
           'DEKALB', 'DEKASOL', 'FIRST LINE', 'HARTZ', 'MONSOY', 'SENSAKO', 'MONSANTO', 'HOLDEN''S', 'UNKNOWN',
		   'TITANIUM', 'NUTRILINE', 'COTTON STATES') ;
  
  
  
-- MAJOR CROP CHECKS for PRODUCT 
-- count major crop products in Lexicon.

select count(*) 
from lexicon.product_name pn
   --  lexicon.product p 
  --   lexicon.bayer_code bc
--where --pn.product_id = p.product_id 
 --  p.bayer_code_id = bc.bayer_code_id
--  and bc.bayer_code_name in ('ZEAMD', 'GLXMA', 'HELAN', 'SORGR', 'SORCU', 'BRSNW', 'BRSNC', 'GOSHI');

-- Count rows in fbs_common.product_name_xref for major crop products.

select count(*) 
from (select lbc.bayer_code_name, lb.brand_name, lpn.product_name, lctry.country_name, 
       mc.name "Crop", mb.name "brandname", mpn.name "prodname", mctry.name "countryname", 
       sp.crop_bayer_code, rb.company_name, sp.product_name, rctry.country_name --,
  --     mpm.old_brand_name, mpm.Mirage_name
       
from fbs_common.product_name_xref@prem fbspn,
     fbs_common.product_xref@prem fbsp,
	 lexicon.product lp,
     lexicon.product_name lpn,
     lexicon.brand lb, 
     mirage2.seed_products@ceregn sp,
     mirage2.companies@ceregn rb,
     lexicon.country lctry,
     mirage2.countries@ceregn rctry,
     lexicon.bayer_code lbc,
     midas.product@prem mp,
     midas.product_name@prem mpn,
     midas.brand@prem mb,
     midas.country@prem mctry,
     midas.crop@prem mc --,
--     yldstg.map_product_mirage@prem_tst mpm
    
where fbsp.lexicon_product_pubkey = lp.product_pubkey
  and fbspn.lexicon_product_name_pubkey = lpn.product_name_pubkey
  and fbsp.midas_product_id = mp.product_id
--  and mp.product_id = mpm.product_pk
  and fbspn.midas_product_name_id = mpn.product_name_id
  and mp.product_id = mpn.product_id
  and mpn.brand_id = mb.brand_id
  and mpn.country_id = mctry.country_id
  and lpn.product_id = lp.product_id
  and mp.crop_id = mc.crop_id
  and lpn.brand_id = lb.brand_id
  and lpn.country_id = lctry.country_id
  and fbspn.mirage_product_id = sp.product_id
  and sp.company_id = rb.company_id
  and sp.country_code = rctry.country_code
  and lp.bayer_code_id = lbc.bayer_code_id
  and lbc.bayer_code_name in ('ZEAMD', 'GLXMA', 'HELAN', 'SORGR', 'SORCU', 'BRSNW', 'BRSNC', 'GOSHI'));
  

-- check that product and product names for major crops are cross referenced correctly in FBS_Common

select lbc.bayer_code_name, lb.brand_name, lpn.product_name, lctry.country_name, 
       mc.name "Crop", mb.name "brandname", mpn.name "prodname", mctry.name "countryname", 
       sp.crop_bayer_code, rb.company_name, sp.product_name, rctry.country_name --,
  --     mpm.old_brand_name, mpm.Mirage_name
       
from fbs_common.product_name_xref@prem fbspn,
     fbs_common.product_xref@prem fbsp,
	 lexicon.product lp,
     lexicon.product_name lpn,
     lexicon.brand lb, 
     mirage2.seed_products@ceregn sp,
     mirage2.companies@ceregn rb,
     lexicon.country lctry,
     mirage2.countries@ceregn rctry,
     lexicon.bayer_code lbc,
     midas.product@prem mp,
     midas.product_name@prem mpn,
     midas.brand@prem mb,
     midas.country@prem mctry,
     midas.crop@prem mc --,
--     yldstg.map_product_mirage@prem_tst mpm
    
where fbsp.lexicon_product_pubkey = lp.product_pubkey
  and fbspn.lexicon_product_name_pubkey = lpn.product_name_pubkey
  and fbsp.midas_product_id = mp.product_id
--  and mp.product_id = mpm.product_pk
  and fbspn.midas_product_name_id = mpn.product_name_id
  and mp.product_id = mpn.product_id
  and mpn.brand_id = mb.brand_id
  and mpn.country_id = mctry.country_id
  and lpn.product_id = lp.product_id
  and mp.crop_id = mc.crop_id
  and lpn.brand_id = lb.brand_id
  and lpn.country_id = lctry.country_id
  and fbspn.mirage_product_id = sp.product_id
  and sp.company_id = rb.company_id
  and sp.country_code = rctry.country_code
  and lp.bayer_code_id = lbc.bayer_code_id
  and lbc.bayer_code_name in ('ZEAMD', 'GLXMA', 'HELAN', 'SORGR', 'SORCU', 'BRSNW', 'BRSNC', 'GOSHI');
  
--  Count all competitor crops in Midas production
-- 1st. product

select  count(distinct p.product_id)
from midas.product@prem p,
	 midas.product_name@prem pn,
     midas.brand@prem b,
     midas.company@prem c
where p.product_id = pn.product_id
and   pn.brand_id = b.brand_id
and   b.company_id = c.company_id
and   c.name <> 'MONSANTO'
--and   b.ref_active = 'T' 
and pn.ref_active = 'T' 
--and p.ref_active = 'T'
;


-- 2nd. product_name

select count(distinct pn.product_name_id)
from midas.product_name@prem pn,
     midas.brand@prem b,
     midas.company@prem c
where pn.brand_id = b.brand_id
and   b.company_id = c.company_id
and   c.name <> 'MONSANTO'
and   b.ref_active = 'T' 
and pn.ref_active = 'T';


-- Count all competitor crops in Yldmart production
-- 1st. product

select  count(distinct p.product_pk)
from yldmart.product@prem p,
  	 yldmart.product_name@prem pn,
     yldmart.brand@prem b,
     yldmart.company@prem c
where p.product_pk = pn.product_pk
and   pn.brand_pk = b.brand_pk
and   b.company_pk = c.company_pk
and   c.name <> 'MONSANTO';

-- Count all competitor crops in Yldmart production
-- 2nd. product name

select  count(*)
from yldmart.product_name@prem pn,
     yldmart.brand@prem b,
     yldmart.company@prem c
where pn.brand_pk = b.brand_pk
and   b.company_pk = c.company_pk
and   c.name <> 'MONSANTO';


-- Midas and Yldmart should have the same number of competitive products.

-- Patro's query - checks for product names existing in Midas, not in Yldmart.
     
SELECT mpn.*, mb.NAME brand, mb.REF_ACTIVE brand_ref_active, 
		 mc.NAME company, mc.REF_ACTIVE company_ref_active 
FROM midas.product_name@prem mpn,
	  yldmart.product_name@prem ypn,
	  midas.brand@prem mb,
	  midas.company@prem mc
WHERE mpn.ref_active = 'T'
AND ypn.PRODUCT_NAME_PK (+) = mpn.PRODUCT_NAME_ID
AND mpn.BRAND_ID = mb.brand_id
AND mb.COMPANY_ID = mc.COMPANY_ID
AND mc.NAME <> 'MONSANTO'
AND ypn.PRODUCT_NAME_PK IS NULL

-- my version of Patro's query - checks for product names existing in Yldmart, not in Midas.
     
SELECT ypn.* 
FROM  yldmart.product_name@prem ypn,
	  yldmart.brand@prem yb,
	  yldmart.company@prem yc,
	  midas.product_name@prem mpn
WHERE  ypn.PRODUCT_NAME_PK  = mpn.PRODUCT_NAME_ID (+)
   AND ypn.BRAND_PK = yb.brand_PK
   AND yb.COMPANY_PK = yc.COMPANY_PK
   AND yc.NAME <> 'MONSANTO'
   AND mpn.PRODUCT_NAME_id IS NULL
   
-- using name/country/brand to link 
SELECT ypn.* 
FROM  yldmart.product_name@prem ypn,
	  yldmart.brand@prem yb,
	  yldmart.company@prem yc,
	  midas.product_name@prem mpn
WHERE  ypn.name  = mpn.name (+)
   AND ypn.BRAND_PK = yb.brand_PK
   AND yb.COMPANY_PK = yc.COMPANY_PK
   AND yc.NAME <> 'MONSANTO'
   AND mpn.name IS NULL
;   
-- Count all competitor product (names) for major crops in Mirage, removing inactive products and old name equivalents

select count(*)
from mirage2.seed_products@ceregn sp,
     mirage2.companies@ceregn c,
     mirage2.seed_products@ceregn eqsp
where sp.company_id = c.company_id
and sp.enabled = 'Y'
and sp.product_id = eqsp.equivalent_product_id (+)
      and eqsp.equivalent_product_id is null 
and   sp.crop_bayer_code in ('ZEAMD', 'GLXMA', 'SORGR', 'SORCU', 'HELAN', 'GOSHI', 'BRSNW', 'BRSNC')
and   company_name not in ('AGROCERES', 'ASGROW', 'CARNIA', 'CERES', 'CORN STATES', 'CORN STATES INTERNATIONAL',
           'DEKALB', 'DEKASOL', 'FIRST LINE', 'HARTZ', 'MONSOY', 'SENSAKO', 'MONSANTO', 'HOLDEN''S', 'UNKNOWN',
		   'TITANIUM', 'NUTRILINE', 'COTTON STATES') ;
           
-- Count all competitor products in Mirage linked to the mapping table.

select count(*)
from mirage2.seed_products@ceregn sp,
     mirage2.companies@ceregn c,
     yldstg.map_product_mirage@prem mpm
where sp.company_id = c.company_id
and sp.enabled = 'Y'
and   sp.crop_bayer_code in ('ZEAMD', 'GLXMA', 'SORGR', 'SORCU', 'HELAN', 'GOSHI', 'BRSNW', 'BRSNC')
and   company_name not in ('AGROCERES', 'ASGROW', 'CARNIA', 'CERES', 'CORN STATES', 'CORN STATES INTERNATIONAL',
           'DEKALB', 'DEKASOL', 'FIRST LINE', 'HARTZ', 'MONSOY', 'SENSAKO', 'MONSANTO', 'HOLDEN''S', 'UNKNOWN',
		   'TITANIUM', 'NUTRILINE', 'COTTON STATES')
		   and mpm.seed_product_id = sp.product_id; 
		   
select count(distinct product_pk)
from midas.product@prem p,
     midas.product_name@prem pn,
     midas.brand@prem b,
	 midas.company@prem c,
     yldstg.map_product_mirage@prem mpm
where p.product_id = mpm.product_pk 
and p.product_id = pn.product_id 
and pn.brand_id = b.brand_id 
and b.company_id = c.company_id 
and c.name <> 'MONSANTO' 
and p.ref_active = 'T' 
and pn.ref_active = 'T' 
and b.ref_active = 'T';
		            
-- Count competitive products mapped in yldstg mapping table to Mirage2, when product_names match, 
--   ignoring the old product in equivalent product, and inactive products in Mirage.  

select count(*)
from yldstg.map_product_mirage@prem mpm,
     mirage2.seed_products@ceregn sp,
     mirage2.seed_products@ceregn eqsp,
     yldmart.product@prem yp,
     yldmart.product_name@prem ypn,
     yldmart.brand@prem yb,
     yldmart.company@prem yc,
     fbs_common.country_xref@prem fbsc
where mpm.seed_product_id = sp.product_id
  and mpm.product_pk = yp.product_pk
  and yp.product_pk = ypn.product_pk
  and ypn.brand_pk = yb.brand_pk
  and yb.company_pk = yc.company_pk
  and yc.name <> 'MONSANTO'
  and sp.country_code = fbsc.mirage_country_code
  and fbsc.midas_country_id = ypn.country_pk
  and ypn.name = sp.product_name
  and sp.enabled = 'Y'
  and sp.product_id = eqsp.equivalent_product_id (+)
  and eqsp.equivalent_product_id is null ;



-- brand tests in Production

-- BRAND CHECKS  in test

-- Count active brands in Midas

Select count(*)
from Midas.brand@prem b
where b.ref_active = 'T';

-- Count brands in Yldmart

Select count(*)
from Yldmart.brand@prem b

-- Find brands in Midas that aren't in Yldmart (Midas had more brands)

select b.brand_id, b.name
from Midas.brand@prem b, 
     yldmart.brand@prem yb
where b.brand_id = yb.brand_pk (+) 
--where b.name = yb.name (+)
  and yb.brand_pk is null
  and b.ref_active = 'T'
;

-- Find brands in Yldmart that aren't in Midas.

select yb.brand_pk, yb.name, b.brand_Id, b.name, b.ref_active
from yldmart.brand@prem yb,
     Midas.brand@prem b
--where  yb.brand_pk = b.brand_id (+) 
where yb.name = b.name 
 and yb.brand_pk <> b.brand_id
-- and (b.ref_active = 'T' or b.ref_active is null)

--  and b.brand_id is null;
order by yb.name
  
  
select * from Midas.brand@prem_tst b
where b.ref_active = 'T'
order by b.name;

-- Identify brands where Id in Midas doesn't match the id in Yldmart

select b.brand_id, b.name, yb.brand_pk, yb.name
from Midas.brand@prem_tst b, 
     yldmart.brand@prem_tst yb
--where b.brand_id = yb.brand_pk (+) 
where b.name = yb.name (+)
and b.brand_id <> yb.brand_pk
 -- and yb.brand_pk is null
  and b.ref_active = 'T'
;

           

--============================


-- Count all competitor crops in Yldmart production
-- 2nd. product name

select count(distinct pn.product_name_id)
from midas.product_name@prem pn,
     midas.brand@prem b,
     midas.company@prem c
where pn.brand_id = b.brand_id
and   b.company_id = c.company_id
and   c.name <> 'MONSANTO'
and   b.ref_active = 'T' and pn.ref_active = 'T';



select  count(distinct pn.product_name_pk)
from yldmart.product_name@prem pn,
     yldmart.brand@prem b,
     yldmart.company@prem c
where pn.brand_pk = b.brand_pk
and   b.company_pk = c.company_pk
and   c.name <> 'MONSANTO'
and   b.ref_active = 'T';

select tmp.product_name_pk
  from 
  (
    select  distinct pn.product_name_pk
from yldmart.product_name@prem pn,
     yldmart.brand@prem b,
     yldmart.company@prem c
where pn.brand_pk = b.brand_pk
and   b.company_pk = c.company_pk
and   c.name <> 'MONSANTO') tmp,
     midas.product_name@prem pn
  where tmp.product_name_pk = pn.product_name_id (+)
    and pn.product_name_id is null;
    
    

