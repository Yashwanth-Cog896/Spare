-- Step 1: Clear out required tables

delete lexicon.product_name;
delete lexicon.brand;
delete lexicon.company;
;
-- this sets up the audit staging table.

begin 
  lexicon.audit_pkg.initialize_staging_p('23228', 'Manual','Inital Data Load','Nancy Schomburg');
end;



-- Step 2: Insert companies

insert into lexicon.company (company_id, company_pubkey, company_name, is_competitor, is_active)
(
select lexicon.company_id_seq.nextval, lexicon.company_pubkey_seq.nextval,
       a.name, decode (a.name, 'MONSANTO', 'n', 'y'), decode (a.ref_active, 'T', 'y', 'n')
from Midas.company@prem a
where a.ref_active = 'T'  and a.name <> 'Monsanto'
);


-- Step 3: Insert brands 

insert into lexicon.brand (brand_id, brand_pubkey, brand_name, company_id, is_active, brand_abbr )
( 
select lexicon.brand_id_seq.nextval, lexicon.brand_pubkey_seq.nextval,  b.name,
       l.company_id, l.is_active, m.company_abbrev 	   
FROM  midas.brand@prem b, 
      midas.company@prem c, 
      lexicon.company l, 
	  mirage2.companies@ceregn m
where b.company_id = c.company_id 
   and c.name = l.company_name 
   and b.ref_active = 'T' 
   and c.ref_active = 'T'
   and b.name = m.company_name(+)  
);

-- Step 4: Create a list of companies with Lexicon pubkey and Midas.Company_id to give to FBS to load 
-- into FBS_COMMON tables.

select lc.company_pubkey, lc.company_name "Lex company", c.company_id, c.name "Midas company"
from lexicon.company lc, 
      midas.company@prem c
where lc.company_name = c.name;

-- Step 5: Create a list of brands with Lexicon pubkey and Midas.Brand_id to give to FBS to load into FBS_COMMON tables.

select lb.brand_pubkey "Lex Brand PubKey", lb.brand_name "Lex Brand Name", lb.brand_abbr "Lex Brand Abbr", 
       lc.company_pubkey "Lex Company PubKey",  lc.company_name "Lex Company Name", 
        b.brand_id "Midas Brand ID", b.name "Midas Brand Name", 
		c.company_id "Midas Company id", c.name "Midas Company Name",
		m.company_id "Mirage Companies Id", m.company_name "Mirage Company Name", m.company_abbrev "Mirage abbr"

FROM  lexicon.brand lb,
      midas.brand@prem b, 
      midas.company@prem c, 
      lexicon.company lc, 
	  mirage2.companies@ceregn m
where lb.company_id = lc.company_id
   and b.company_id = c.company_id 
   and lb.brand_name = b.name 
   and b.ref_active = 'T' 
   and c.ref_active = 'T'
   and b.name = m.company_name(+)   
   and c.name <> 'Monsanto'
;
-- this purges the audit staging table


begin
lexicon.audit_pkg.delete_staging_record_p;
end;

/*
select * from lexicon.brand;

select * from lexicon.company;

connect lexicon/lexicon_123@dsbreed_devl;

grant select on company_id_seq to ngscho;
grant select on company_pubkey_seq to ngscho;
grant select on brand_id_seq to ngscho;
grant select on brand_pubkey_seq to ngscho;
grant insert,update,delete,select on PRODUCT_NAME to NGSCHO;
grant insert,update,delete,select on COMPANY to NGSCHO;
grant insert,update,delete,select on BRAND to NGSCHO;
*/

  
