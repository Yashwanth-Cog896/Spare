-- The results of this query should be provided to FBS so they can see the Lexicon Public keys with country names.

select Country_Pubkey, Country_Name, Country_Abbr
from Lexicon.Country C;


