
-- To load the commercial trait tables, see Lexicon/Doc/Product/Product_trait/trait_devl.mdb or trait_tst.mdb.
-- The data is stored in Lexicon/Doc/Product/Product_trait/coml trait data w HXNG corrected (2005.01.26).xls.

-- After loading the trait data, run java program  - RebuildGeneratedTraitNames - to rebuild the generated stack names.

-- Need to remove rows if reloading Coml_Trait_stack which has a foreign key to Product_name.
delete lexicon.product_name;   

