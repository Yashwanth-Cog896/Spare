-- look for product in midas

select pn.product_name_id, p.product_id, c.name as "Crop", b.name as "brand", pn.name as "product", t.name as "country", 
b.ref_active, pn.ref_active, p.ref_active
from midas.product_name@prem pn,
     midas.brand@prem b,
     midas.product@prem p,
     midas.crop@prem c,
     midas.country@prem t
where pn.product_id = p.product_id
and pn.brand_id = b.brand_id
and p.crop_id = c.crop_id
and pn.country_id = t.country_id
--and pn.name = 'AV 3919 R2CB' 
and b.name = 'ADVANTAGE SEED' and c.name = 'Corn' and t.name = 'Canada';

-- look for product in Yldmart

select pn.product_name_pk, p.product_pk, c.name as "Crop", b.name as "brand", pn.name as "product", t.name as "country"
from yldmart.product_name@prem pn,
     yldmart.brand@prem b,
     yldmart.product@prem p,
     yldmart.crop@prem c,
     yldmart.country@prem t
where pn.product_pk = p.product_pk
and pn.brand_pk = b.brand_pk
and p.crop_id = c.crop_pk
and pn.country_pk = t.country_pk
--and pn.name = 'AV 3919 R2CB' 
and b.name = 'ADVANTAGE SEED' and c.name = 'Corn' and t.name = 'Canada';

-- look for product in mapping table

select * from yldstg.map_product_mirage@prem where seed_product_id = 1390932;
 
-- look for product in Mirage

select sp.product_id, sp.crop_bayer_code, c.company_name, sp.product_name, sp.enabled, sp.equivalent_product_id
from mirage2.seed_products@ceregn sp,
     mirage2.companies@ceregn c,
     mirage2.countries@ceregn t
where sp.country_code = t.country_code
and sp.company_id = c.company_id
--and  sp.product_name = 'AV 3919 R2CB' 
and c.company_name = 'ADVANTAGE SEED' and sp.crop_bayer_code = 'ZEAMD' and t.country_name = 'CANADA';


-- from major crop load, does product drop out?

Select  yp.product_pk , lbc.bayer_code_id 

  From yldmart.product_name@prem ypn, 
       yldmart.brand@prem yb, 
       lexicon.brand lb,
	   yldmart.company@prem ycomp,  
       yldmart.product@prem yp, 
	   lexicon.country lctry, 
	   yldstg.map_product_mirage@prem mpm, 
	   mirage2.seed_products@ceregn msp,
	   mirage2.seed_products@ceregn eqsp, -- equivalent products
	   fbs_common.country_xref@prem fbsc,
	   fbs_common.brand_xref@prem fbsb,
	   lexicon.bayer_code lbc
--	   lexicon.midas_dup_product_name lmdpn
--	   lexicon.mirage_seed_product lmsp
 
 where ypn.brand_pk = yb.brand_pk 
    and yb.company_pk = ycomp.company_pk 
    and ycomp.name <> 'MONSANTO' 
    and ypn.product_pk = yp.product_pk
    -- remove from query for now, until data is corrected.
  --  and yp.product_pk <> 1350830718976
    and yp.product_pk = 2724436639744  
	and ypn.brand_pk = fbsb.midas_brand_id 
    and ypn.country_pk = fbsc.midas_country_id 
    and yp.product_pk = mpm.product_pk 
    and mpm.seed_product_id = msp.product_id
    and msp.country_code = fbsc.mirage_country_code
    -- next 2 statements omits old equivalent products
    and msp.product_id = eqsp.equivalent_product_id (+)
    and eqsp.equivalent_product_id is null
    and trim(msp.crop_bayer_code) = lbc.bayer_code_name 
    and fbsc.lexicon_country_pubkey = lctry.country_pubkey
    and fbsb.lexicon_brand_pubkey = lb.brand_pubkey
    and msp.product_name = upper(ypn.name)
  -- don't pull Midas duplicate products
--   and ypn.product_name_pk = lmdpn.product_pk(+) 
--    and lmdpn.product_pk is null 
 -- don't pull Mirage duplicate products
--    and ypn.product_name_pk = lmsp.product_id(+) 
--    and lmsp.product_id is null 

;
