-- Load miscellaneous product_name fields:  Commercial Maturity for all competitive products, 
-- and Comments for major crop competitive products.
-- Run after the MajorCropProduct and MinorCropProduct has run, and loaded products to Product_name.
	 
-- Step 1:  Remove maturity and comments from Lexicon.Product_name table.

update lexicon.product_name set commercial_maturity = null;
update lexicon.product_name set comments = null;
 
-- Step 2: Load commercial maturity from Mirage.

select count(*) -- 11445 records on 2/18/2005
from  lexicon.product_name lpn, 
      fbs_common.product_name_xref@prem fbspn,
	  mirage2.seed_products@ceregn sp, 
	  mirage2.seed_products_maturity@ceregn mpm,
	  mirage2.kw@ceregn kw
     
    where  lpn.product_name_pubkey = fbspn.lexicon_product_name_pubkey
	    and fbspn.mirage_product_id = sp.product_id
	    and sp.product_id = mpm.product_id
		and mpm.maturity_unit = kw.code
        and kw.name = 'RM'
	    and mpm.maturity_rating is not null
	   ;


begin
declare
str VARCHAR2(500);

CURSOR c_map  IS
   SELECT  lpn.product_name_id, mpm.maturity_rating as maturity
    
	from  lexicon.product_name lpn, 
      fbs_common.product_name_xref@prem fbspn,
	  mirage2.seed_products@ceregn sp, 
	  mirage2.seed_products_maturity@ceregn mpm,
	  mirage2.kw@ceregn kw
     
    where  lpn.product_name_pubkey = fbspn.lexicon_product_name_pubkey
	    and fbspn.mirage_product_id = sp.product_id
	    and sp.product_id = mpm.product_id
		and mpm.maturity_unit = kw.code
        and kw.name = 'RM'
	    and mpm.maturity_rating is not null
;	 
         
begin
  FOR rec IN c_map LOOP
 
    str := 'update lexicon.product_name set maturity = :mat where product_name_id = :prod_name_id'; 
    execute immediate str using rec.maturity, rec.product_name_id;
  end loop;
end;
end;

-- Count the records loaded into Mirage_Seed_Product_name with a maturity.

select count(*)
from  lexicon.product_name lpn 
where lpn.commercial_maturity is not null
;


-- Step 3: Load comments from Mirage.

select count(*) -- 14582 records on 2/18/2005
from  lexicon.product_name lpn, 
      fbs_common.product_name_xref@prem fbspn,
	  mirage2.seed_products@ceregn sp

where  lpn.product_name_pubkey = fbspn.lexicon_product_name_pubkey
   and fbspn.mirage_product_id = sp.product_id
   and sp.comments is not null
	   ;

begin
declare
str VARCHAR2(500);

CURSOR c_map  IS
   SELECT  lpn.product_name_id, sp.comments as comments
    
	from  lexicon.product_name lpn, 
      fbs_common.product_name_xref@prem fbspn,
	  mirage2.seed_products@ceregn sp

where  lpn.product_name_pubkey = fbspn.lexicon_product_name_pubkey
   and fbspn.mirage_product_id = sp.product_id
   and sp.comments is not null
;	 
         
begin
  FOR rec IN c_map LOOP
 
    str := 'update lexicon.product_name set comments = :mat where product_name_id = :prod_name_id'; 
    execute immediate str using rec.comments, rec.product_name_id;
  end loop;
end;
end;

-- Count the records loaded into Mirage_Seed_Product_name with a comment.

select count(*)
from  lexicon.product_name lpn 
where lpn.comments is not null
;


















