-- Update valueslists in Master Template for Product Add import.

-- Update country list - save in excel, then import into valuelist sheet.

Select c.country_name || ' (' || c.country_abbr || ')' as "Country"
from lexicon.country c
order by c.country_name;

-- Update trait stack - save in excel, then import into valueslist sheet.
select decode(reporting_name,null,generated_name, reporting_name) || ' (' || crop_name || ')'
  from coml_trait_stack_names_vw
 where generated_name is not null
order by 1
;


-- Update Brand list - save in excel, then import into valuelist sheet.

select b.brand_name
from lexicon.brand b,
     lexicon.company c
where b.company_id = c.company_id
and c.is_competitor = 'y' and c.is_active = 'y' and b.is_active = 'y'
order by 1;



