-- check country cross reference

-- ensure no duplicate keys (should return 0)
select lc.country_pubkey, count(*)
  from lexicon.country lc,
       fbs_common.Country_xref@prem_tst fc
 where lc.country_pubkey = fc.lexicon_country_pubkey
group by lc.country_pubkey
having count(*) > 1;	      

-- ensure all lexicon keys exist in fbs tables (should return 0)
select lc.*
  from lexicon.country lc,
       fbs_common.Country_xref@prem_tst fc
 where lc.country_pubkey = fc.lexicon_country_pubkey (+)
   and fc.lexicon_country_pubkey is null;
   
-- get count of lexicon countries
select count(*) from lexicon.country;

-- show cross reference of each system, should match previous count
select FBSC.Lexicon_country_pubkey, 
       lc.country_name as "lex name", lc.country_abbr "lex abbr", 
	   rc.country_abbrev as "mirage abbr", rc.country_name as "mirage name", 
       mc.name as "midas name"
from fbs_common.Country_xref@prem_tst fbsc, 
     lexicon.country lc, 
     midas.country@prem_tst mc, 
     mirage.countries@ceregn_tst rc
where fbsc.lexicon_country_pubkey = lc.country_pubkey
     and fbsc.midas_country_id = mc.country_id (+)
     and fbsc.mirage_country_code = rc.country_code (+);
     
-- check brand cross reference

select count(*) from lexicon.brand;

-- check for duplicates mapped in fbs_common
select lb.brand_pubkey, count(*)
  from lexicon.brand lb,
       fbs_common.brand_xref@prem_tst fb
 where lb.brand_pubkey = fb.lexicon_brand_pubkey
group by lb.brand_pubkey
having count(*) > 1;	      

-- lexicon brand not mapped in common (should be 0)
select lb.*
  from lexicon.brand lb,
       fbs_common.brand_xref@prem_tst fb
 where lb.brand_pubkey = fb.lexicon_brand_pubkey (+)
   and fb.lexicon_brand_pubkey is null;

-- cross reference of brands via common
select fbsb.Lexicon_brand_pubkey as "lex pubkey",  fbsb.Midas_brand_id as "midas id", fbsb.Mirage_company_id as "mirage id",
      lb.brand_name as "lex name", lb.brand_abbr as "lex abbr",
    rb.company_name as "mir name", rb.company_abbrev as "mir abbr", 
      mb.name as "midas name"
from  fbs_common.brand_xref@prem_tst fbsb,
      lexicon.brand lb,
      midas.brand@prem_tst mb,
      mirage2.companies@ceregn_tst rb
where  fbsb.lexicon_brand_pubkey = lb.brand_pubkey
      and  fbsb.midas_brand_id = mb.brand_id (+)
      and fbsb.mirage_company_id = rb.company_id (+);
      
-- product mappings (regardless of major/minor)

select count(*) from lexicon.product;

-- check for duplicates mapped in fbs_common
select lp.product_pubkey, count(*)
  from lexicon.product lp,
       fbs_common.product_xref@prem_tst fp
 where lp.product_pubkey = fp.lexicon_product_pubkey
group by lp.product_pubkey
having count(*) > 1;	      

-- ensure all lex id's are mapped to common (should return 0)
select lp.*
  from lexicon.product lp,
       fbs_common.product_xref@prem_tst fp
 where lp.product_pubkey = fp.lexicon_product_pubkey (+)
   and fp.lexicon_product_pubkey is null;
   

-- product_name map, regardless of major/minor
select count(*) from lexicon.product_name;

-- check for duplicates mapped in fbs_common (should be 0)
select lpn.product_name_pubkey, count(*)
  from lexicon.product_name lpn,
       fbs_common.product_name_xref@prem_tst fpn
 where lpn.product_name_pubkey = fpn.lexicon_product_name_pubkey
group by lpn.product_name_pubkey
having count(*) > 1;	      

-- ensure all product_names are in common; should be 0
select lpn.*
  from lexicon.product_name lpn,
       fbs_common.product_name_xref@prem_tst fpn
 where lpn.product_name_pubkey = fpn.lexicon_product_name_pubkey
   and fpn.lexicon_product_name_pubkey is null;


     
-- count minor crop products in Lexicon.
select count(*) from lexicon.product_name pn, lexicon.product p, lexicon.bayer_code bc
where pn.product_id = p.product_id and p.bayer_code_id = bc.bayer_code_id
and bc.bayer_code_name not in ('ZEAMD', 'GLXMA', 'HELAN', 'SORGR', 'SORCU', 'BRSNW', 'BRSNC', 'GOSHI');
    
-- check that product names for minor crops are cross referenced correctly in FBS_Common

select lbc.bayer_code_name, lb.brand_name, lpn.product_name, lctry.country_name, 
       sp.crop_bayer_code, rb.company_name, sp.product_name, rctry.country_name

from fbs_common.product_name_xref@prem_tst fbspn,
     lexicon.product lp,
     lexicon.product_name lpn,
     lexicon.brand lb, 
     mirage2.seed_products@ceregn_tst sp,
     mirage2.companies@ceregn_tst rb,
     lexicon.country lctry,
     mirage2.countries@ceregn_tst rctry,
     lexicon.bayer_code lbc
    
where fbspn.lexicon_product_name_pubkey = lpn.product_name_pubkey
  and lpn.product_id = lp.product_id
  and lpn.brand_id = lb.brand_id
  and fbspn.mirage_product_id = sp.product_id
  and sp.company_id = rb.company_id
  and lpn.country_id = lctry.country_id
  and sp.country_code = rctry.country_code
  and lp.bayer_code_id = lbc.bayer_code_id
  and lbc.bayer_code_name not in ('ZEAMD', 'GLXMA', 'HELAN', 'SORGR', 'SORCU', 'BRSNW', 'BRSNC', 'GOSHI');
  
  
  
-- count major crop products in Lexicon.

select count(*) from lexicon.product_name pn, lexicon.product p, lexicon.bayer_code bc
where pn.product_id = p.product_id and p.bayer_code_id = bc.bayer_code_id
and bc.bayer_code_name  in ('ZEAMD', 'GLXMA', 'HELAN', 'SORGR', 'SORCU', 'BRSNW', 'BRSNC', 'GOSHI');

-- Count rows Robert added match with excel row count.  24734 = 24319 major + 415 minor

select count(*) 
from fbs_common.product_name_xref@prem_tst fbspn;

-- check that product and product names for major crops are cross referenced correctly in FBS_Common

select lbc.bayer_code_name, lb.brand_name, lpn.product_name, lctry.country_name, 
       mc.name "Crop", mb.name "brandname", mpn.name "prodname", mctry.name "countryname", 
       sp.crop_bayer_code, rb.company_name, sp.product_name, rctry.country_name --,
  --     mpm.old_brand_name, mpm.Mirage_name
       
from fbs_common.product_name_xref@prem_tst fbspn,
     fbs_common.product_xref@prem_tst fbsp,
	 lexicon.product lp,
     lexicon.product_name lpn,
     lexicon.brand lb, 
     mirage2.seed_products@ceregn_tst sp,
     mirage2.companies@ceregn_tst rb,
     lexicon.country lctry,
     mirage2.countries@ceregn_tst rctry,
     lexicon.bayer_code lbc,
     midas.product@prem_tst mp,
     midas.product_name@prem_tst mpn,
     midas.brand@prem_tst mb,
     midas.country@prem_tst mctry,
     midas.crop@prem_tst mc --,
--     yldstg.map_product_mirage@prem_tst mpm
    
where fbsp.lexicon_product_pubkey = lp.product_pubkey
  and fbspn.lexicon_product_name_pubkey = lpn.product_name_pubkey
  and fbsp.midas_product_id = mp.product_id
--  and mp.product_id = mpm.product_pk
  and fbspn.midas_product_name_id = mpn.product_name_id
  and mp.product_id = mpn.product_id
  and mpn.brand_id = mb.brand_id
  and mpn.country_id = mctry.country_id
  and lpn.product_id = lp.product_id
  and mp.crop_id = mc.crop_id
  and lpn.brand_id = lb.brand_id
  and lpn.country_id = lctry.country_id
  and fbspn.mirage_product_id = sp.product_id
  and sp.company_id = rb.company_id
  and sp.country_code = rctry.country_code
  and lp.bayer_code_id = lbc.bayer_code_id
  and lbc.bayer_code_name in ('ZEAMD', 'GLXMA', 'HELAN', 'SORGR', 'SORCU', 'BRSNW', 'BRSNC', 'GOSHI');
  
  






  
where fbsp.lexicon_product_pubkey = lp.product_pubkey
  and fbspn.lexicon_product_name_pubkey = lpn.product_name_pubkey
  and fbsp.midas_product_id = mp.midas_product_id
  and fbspn.midas_product_Name_id = mpn.midas_product_Name_id
  and fbspn.mirage_product_id = sp.product_id
  and lpn.brand_id = lb.brand_id
  and mpn.brand_id = mb.brand_id
  and sp.company_id = rb.company_id
  and lpn.country_id = lctry.country_id
  and mpn.country_id = mctry.country_id
  and sp.country_code = rctry.country_code
  and sp.product_id = mpm.seed_product_id
  
  and lbc.bayer_code_name in ('ZEAMD', 'GLXMA', 'HELAN', 'SORGR', 'SORCU', 'BRSNW', 'BRSNC', 'GOSHI');
  
  select sp.Product_name, sp.crop_bayer_code, c.company_name, t.country_name
  from mirage2.seed_products@ceregn_tst sp, 
  mirage2.companies@ceregn_tst c, 
  mirage2.countries@ceregn_tst t
   where sp.company_id = c.company_id
   and sp.country_code = t.country_code
   and product_id = '1555';
   
   select t.name as "Crop", 
   p.product_pk, pn.product_name_pk, 
   pn.name "Product name",  b.name "Brand",   c.name
   from yldmart.product_name@prem_tst pn,
     yldmart.product@prem_tst p,
     Yldmart.crop@prem_tst t,
     yldmart.brand@prem_tst b,
     yldmart.company@prem_tst cp,
     yldmart.country@prem_tst c
     where pn.product_pk = p.product_pk
     and p.crop_id = t.crop_pk
     and pn.brand_pk = b.brand_pk
     and b.company_pk = cp.company_pk
     and cp.name <> 'MONSANTO'
 -- group by  p.product_pk, --pn.product_name_pk, 
 --  pn.name,  b.name
  -- having count(*) > 1
   and pn.country_pk = c.country_pk
--	 and rownum < 100;
    and p.product_pk = 1350141804544
;
     
     select pn.product_name, c.country_name, b.brand_name, bc.bayer_code_name
     from lexicon.product_name pn,
     lexicon.product p,
     lexicon.bayer_code bc,
     lexicon.brand b,
     lexicon.country c
     where pn.product_id = p.product_id
     and p.bayer_code_id = bc.bayer_code_id
     and pn.brand_id = b.brand_id
     and pn.country_id = c.country_id
     and pn.product_name_pubkey = '23005807';
  
  
  select tmp.product_pk, count(*)  
  from
  ( 
  select p.product_pk, b.brand_pk, pn.name
   from yldmart.product_name@prem_tst pn,
     yldmart.product@prem_tst p,
  --   Yldmart.crop@prem_tst t,
     yldmart.brand@prem_tst b,
     yldmart.company@prem_tst cp
  --   yldmart.country@prem_tst c
     where pn.product_pk = p.product_pk
  --   and p.crop_id = t.crop_pk
     and pn.brand_pk = b.brand_pk
     and b.company_pk = cp.company_pk
     and cp.name <> 'MONSANTO'
  group by  p.product_pk, b.brand_pk, pn.name
  ) tmp
  group by tmp.product_pk
   having count(*) > 1
 

select * from fbs_common.Country_xref@prem_tst;     

select * from midas.country@prem_tst mc where upper(NAME) = 'CANADA';

select * from mirage.countries@ceregn_tst rc where upper(COUNTRY_NAME) = 'CANADA';

select * from fbs_common.Country_xref@prem_tst fc where midas_country_id = '391118848';

select * from lexicon.country lc where lc.country_pubkey = '4704';

select * from lexicon.country lc where lc.country_abbr = 'USA';

select * from fbs_common.Country_xref@prem_tst fc where fc.lexicon_country_pubkey = '74504';

