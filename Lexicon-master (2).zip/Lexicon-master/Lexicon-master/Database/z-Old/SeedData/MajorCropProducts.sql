-- This SQL will load Lexicon.Product and Product_name tables with major crop products from Midas.
-- It will generate Lexicon public keys cross referenced to Midas and Mirage product and product name ids.

-- Step 1: RUN ONCE
-- Run the update queries to make the country names match between Midas and Lexicon.  
-- Will change back after products are loaded.

Update Lexicon.country set country_name = 'VIETNAM' where country_name = 'VIET NAM';
Update Lexicon.country set country_name = 'UNITED KINGDOM OF GREAT BRITAIN AND NORTHERN IREL' 
    where country_name = 'UNITED KINGDOM OF GREAT BRITAIN AND NORTHERN IRELAND' or country_name = 'UNITED KINGDOM';
Update Lexicon.country set country_name = 'KOREA' where country_name = 'REPUBLIC OF KOREA';
Update Lexicon.country set country_name = 'COLUMBIA' where country_name = 'COLOMBIA';
Update Lexicon.country set country_name = 'IRAN' where country_name = 'IRAN (ISLAMIC REPUBLIC OF)';
Update Lexicon.country set country_name = 'UNITED STATES OF AMERICA' where country_name = 'UNITED STATES';
    
-- Step 2: Delete product_name and product data.

delete lexicon.product_name;
delete lexicon.product;
delete lexicon.midas_lexicon_product;
delete lexicon.midas_lexicon_product_name;

-- Step 2b: run Aaron's java program that adds duplicates into 
-- lexicon.midas_dup_product_name


-- Step 3: This query gives us the count of all competitive product records to be loaded to Lexicon.  

SELECT count(*) from (
Select distinct ypn.product_pk, lcrop.crop_id 
  From yldmart.product_name@prem_tst ypn, 
       yldmart.brand@prem_tst yb, 
       lexicon.brand lb,
	   yldmart.company@prem_tst ycomp,  
       yldmart.product@prem_tst yp, 
	   yldmart.crop@prem_tst ycrop,
	   yldmart.country@prem_tst yctry, 
	   lexicon.country lctry,
	   lexicon.crop lcrop, 
	   lexicon.bayer_code lbc,
	   lexicon.midas_dup_product_name lmdpn
	   
 where ypn.brand_pk = yb.brand_pk 
   and yb.name = lb.brand_name
   and yb.company_pk = ycomp.company_pk 
   and ycomp.name <> 'MONSANTO' 
   and ypn.product_pk = yp.product_pk
   and yp.crop_id = ycrop.crop_pk 
   and ypn.country_pk = yctry.country_pk 
   and UPPER(yctry.name) = lctry.country_name
   and upper(ycrop.name) = lcrop.crop_name
   and lcrop.crop_id = lbc.crop_id
   and lbc.bayer_code_name in ('ZEAMD', 'GLXMA', 'HELAN', 'SORGR', 'BRSNW', 'GOSHI')
   and ypn.product_name_pk = lmdpn.product_pk(+) 
   and lmdpn.product_pk is null 
)
;
-- Step 4: This query gives us the count of all competitive product name records to be loaded to Lexicon.  

SELECT count(*) from (

select distinct ypn.product_pk, ypn.product_name_pk, lb.brand_id, lbc.bayer_code_id, lctry.country_id, ypn.name 


  From yldmart.product_name@prem_tst ypn, 
       yldmart.brand@prem_tst yb, 
       lexicon.brand lb,
	   yldmart.company@prem_tst ycomp,  
       yldmart.product@prem_tst yp, 
	   yldmart.crop@prem_tst ycrop,
	   yldmart.country@prem_tst yctry, 
	   lexicon.country lctry,
	   lexicon.crop lcrop, 
 	   lexicon.bayer_code lbc,
	   lexicon.midas_dup_product_name lmdpn
	   
 where ypn.brand_pk = yb.brand_pk 
   and yb.name = lb.brand_name
   and yb.company_pk = ycomp.company_pk 
   and ycomp.name <> 'MONSANTO' 
   and ypn.product_pk = yp.product_pk
   and yp.crop_id = ycrop.crop_pk 
   and ypn.country_pk = yctry.country_pk 
   and UPPER(yctry.name) = lctry.country_name
   and upper(ycrop.name) = lcrop.crop_name
   and lcrop.crop_id = lbc.crop_id
   and lbc.bayer_code_name in ('ZEAMD', 'GLXMA', 'HELAN', 'SORGR', 'BRSNW', 'GOSHI')
   and ypn.product_name_pk = lmdpn.product_pk(+) 
   and lmdpn.product_pk is null 
)
;

-- Step 5: This query gives us the count of product records with corresponding Mirage products to be loaded to Lexicon.
  
SELECT count(*) from (
Select distinct ypn.product_pk, lcrop.crop_id --ypn.name, ypn.country_pk, ypn.brand_pk--, ypn.product_pk -- , lcrop.crop_id, mpm.product_pk, msp.product_name, msp.crop_bayer_code
  From yldmart.product_name@prem_tst ypn, 
       yldmart.brand@prem_tst yb, 
       lexicon.brand lb,
	   yldmart.company@prem_tst ycomp,  
       yldmart.product@prem_tst yp, 
	   yldmart.crop@prem_tst ycrop,
	   yldmart.country@prem_tst yctry, 
	   lexicon.country lctry,
	   lexicon.crop lcrop, 
	   --yldstg.map_product_mirage@prem_tst mpm, 
	   mirage2.seed_products@ceregn_tst msp,
	   mirage2.companies@ceregn_tst mcomp, 
	   lexicon.bayer_code lbc,
	   lexicon.midas_dup_product_name lmdpn
 where ypn.brand_pk = yb.brand_pk 
   and yb.name = lb.brand_name
   and yb.company_pk = ycomp.company_pk 
   and ycomp.name <> 'MONSANTO' 
   and ypn.product_pk = yp.product_pk
   and yp.crop_id = ycrop.crop_pk 
   and ypn.country_pk = yctry.country_pk 
   and UPPER(yctry.name) = lctry.country_name
   and upper(ycrop.name) = lcrop.crop_name
   --and yp.product_pk = mpm.product_pk 
  -- and mpm.seed_product_id = msp.product_id
   and ypn.name = msp.product_name
   and msp.company_id = mcomp.company_id
   and lb.brand_name = mcomp.company_name
   and msp.enabled = 'Y'
   and msp.crop_bayer_code in ('ZEAMD', 'GLXMA', 'HELAN', 'SORGR', 'SORCU', 'BRSNW', 'BRSNC', 'GOSHI')
   and trim(msp.crop_bayer_code) = lbc.bayer_code_name 
   and msp.equivalent_product_id is null
   and ypn.product_name_pk = lmdpn.product_pk(+) 
   and lmdpn.product_pk is null 
)
;
-- Step 6: This query inserts product records with corresponding Mirage product to be loaded to Lexicon.  
insert into lexicon.product (product_pubkey, product_id, crop_id)
(
select lexicon.product_pubkey_seq.nextval, iq.UniqueProduct, iq.CropId
 FROM (
      Select distinct ypn.product_pk as UniqueProduct, lcrop.crop_id as CropId

  From yldmart.product_name@prem ypn, 
       yldmart.brand@prem yb, 
       lexicon.brand lb,
	   yldmart.company@prem ycomp,  
       yldmart.product@prem yp, 
	   yldmart.crop@prem ycrop,
	   yldmart.country@prem yctry, 
	   lexicon.country lctry,
	   lexicon.crop lcrop, 
	 --  yldstg.map_product_mirage@prem mpm, 
	    mirage2.seed_products@ceregn msp, 
	    mirage2.companies@ceregn mcomp,
	   lexicon.bayer_code lbc,
	   lexicon.midas_dup_product_name lmdpn
 where ypn.brand_pk = yb.brand_pk 
   and yb.name = lb.brand_name
   and yb.company_pk = ycomp.company_pk 
   and ycomp.name <> 'MONSANTO' 
   and ypn.product_pk = yp.product_pk
   and yp.crop_id = ycrop.crop_pk 
   and ypn.country_pk = yctry.country_pk 
   and UPPER(yctry.name) = lctry.country_name
   and upper(ycrop.name) = lcrop.crop_name
   --and yp.product_pk = mpm.product_pk 
   --and mpm.seed_product_id = msp.product_id
   and ypn.name = msp.product_name
   and msp.company_id = mcomp.company_id
   and lb.brand_name = mcomp.company_name
   and msp.enabled = 'Y'
   and msp.crop_bayer_code in ('ZEAMD', 'GLXMA', 'HELAN', 'SORGR', 'SORCU', 'BRSNW', 'BRSNC', 'GOSHI')
   and trim(msp.crop_bayer_code) = lbc.bayer_code_name
   and msp.equivalent_product_id is null
   and ypn.product_name_pk = lmdpn.product_pk(+) 
   and lmdpn.product_pk is null 
--   and rownum <= 10
) iq
);


-- Step 6a, populate midas_lexicon_product
insert into lexicon.midas_lexicon_product (midas_product_id, lexicon_product_id)
(select product_id, lexicon.product_id_seq.nextval 
   from lexicon.product);
   
-- Step 6b, update lexicon_product table with lexicon values instead of midas keys
begin
declare
str VARCHAR2(500);

CURSOR c_map  IS
   SELECT  *
     FROM  lexicon.midas_lexicon_product; 

begin
  FOR rec IN c_map LOOP
    str := 'update lexicon.product set product_id = :lex_prod_id where product_id = :midas_prod_id';
    execute immediate str using rec.lexicon_product_id, rec.midas_product_id;
  end loop;
end;
end;


-- Step 7: Count of competitive product name records with corresponding Mirage product to be loaded to Lexicon.
select count(*) from (
select yp.product_pk, ypn.product_name_pk, lb.brand_id, lbc.bayer_code_id, lctry.country_id, ypn.name 

  From yldmart.product_name@prem ypn, 
       yldmart.brand@prem yb, 
       lexicon.brand lb,
	   yldmart.company@prem ycomp,  
       yldmart.product@prem yp, 
	   yldmart.crop@prem ycrop,
	   yldmart.country@prem yctry, 
	   lexicon.country lctry,
	   lexicon.crop lcrop, 
	 --  yldstg.map_product_mirage@prem mpm, 
	   mirage2.seed_products@ceregn msp,
	   mirage2.companies@ceregn mcomp,
	   lexicon.bayer_code lbc, 
	   lexicon.midas_dup_product_name lmdpn
 where ypn.brand_pk = yb.brand_pk 
   and yb.name = lb.brand_name
   and yb.company_pk = ycomp.company_pk 
   and ycomp.name <> 'MONSANTO' 
   and ypn.product_pk = yp.product_pk
   and yp.crop_id = ycrop.crop_pk 
   and ypn.country_pk = yctry.country_pk 
   and UPPER(yctry.name) = lctry.country_name
   and upper(ycrop.name) = lcrop.crop_name
   --and yp.product_pk = mpm.product_pk 
  -- and mpm.seed_product_id = msp.product_id
   and ypn.name = msp.product_name
   and msp.company_id = mcomp.company_id
   and mcomp.company_name = lb.brand_name 
   and msp.enabled = 'Y'
   and msp.crop_bayer_code in ('ZEAMD', 'GLXMA', 'HELAN', 'SORGR',  'BRSNW',  'GOSHI', 'SORCU', 'BRSNC')
   and TRIM(msp.crop_bayer_code) = lbc.bayer_code_name
   and msp.equivalent_product_id is null
   and ypn.product_name_pk = lmdpn.product_pk(+) 
   and lmdpn.product_pk is null 
)
;
-- Step 8: Load Lexicon.Product_Name competitive product_names for corn, soybeans, cotton, OSR-Canola, sorghum, 
-- and sunflower where there is a corresponding product in Mirage to get the bayer code.

insert into lexicon.product_name (product_name_pubkey, product_id, product_name_id, brand_id, bayer_code_id, 
country_id, product_name, is_active)
(
select lexicon.product_name_pubkey_seq.nextval, iq.productid, iq.productnameid,
       iq.brandid, iq.bayercodeid, iq.countryid, iq.productname, 'y'
From
(select lmap.lexicon_product_id as productid, ypn.product_name_pk as productnameid, lb.brand_id as brandid, 
                 lbc.bayer_code_id as bayercodeid, 
                 lctry.country_id as countryid, ypn.name as productname

  From yldmart.product_name@prem ypn, 
       yldmart.brand@prem yb, 
       lexicon.brand lb,
	   yldmart.company@prem ycomp,  
       yldmart.product@prem yp, 
	   yldmart.crop@prem ycrop,
	   yldmart.country@prem yctry, 
	   lexicon.country lctry,
	   lexicon.crop lcrop, 
	   -- yldstg.map_product_mirage@prem mpm, 
	   mirage2.seed_products@ceregn msp,
	   mirage2.companies@ceregn mcomp,
	   lexicon.bayer_code lbc, 
	   lexicon.midas_dup_product_name lmdpn,
	   lexicon.midas_lexicon_product lmap
 where ypn.brand_pk = yb.brand_pk 
   and yb.name = lb.brand_name
   and yb.company_pk = ycomp.company_pk 
   and ycomp.name <> 'MONSANTO' 
   and ypn.product_pk = yp.product_pk
   and yp.crop_id = ycrop.crop_pk 
   and ypn.country_pk = yctry.country_pk 
   and UPPER(yctry.name) = lctry.country_name
   and upper(ycrop.name) = lcrop.crop_name
   and yp.product_pk = lmap.midas_product_id
   --and yp.product_pk = mpm.product_pk 
   --and mpm.seed_product_id = msp.product_id
     and ypn.name = msp.product_name
     and msp.company_id = mcomp.company_id
     and lb.brand_name = mcomp.company_name
     and msp.enabled = 'Y'
   and msp.crop_bayer_code in ('ZEAMD', 'GLXMA', 'HELAN', 'SORGR',  'BRSNW',  'GOSHI', 'SORCU', 'BRSNC')
   and TRIM(msp.crop_bayer_code) = lbc.bayer_code_name
   and msp.equivalent_product_id is null
   and ypn.product_name_pk = lmdpn.product_pk(+) 
   and lmdpn.product_pk is null 
) iq
);




-- Step 9: This query gives us the count of product records from YldMart that haven't been loaded to Lexicon.
SELECT count(*) from (
Select distinct ypn.product_pk, lcrop.crop_id 
  From yldmart.product_name@prem ypn, 
      lexicon.midas_lexicon_product lp,
      -- lexicon.product_name lpn,
       yldmart.brand@prem yb, 
       lexicon.brand lb,
	   yldmart.company@prem ycomp,  
       yldmart.product@prem yp, 
	   yldmart.crop@prem ycrop,
	   yldmart.country@prem yctry, 
	   lexicon.country lctry,
	   lexicon.crop lcrop, 
	   lexicon.bayer_code lbc,
	   lexicon.midas_dup_product_name lmdpn
 where ypn.brand_pk = yb.brand_pk 
   and yb.name = lb.brand_name
   and yb.company_pk = ycomp.company_pk 
   and ycomp.name <> 'MONSANTO' 
   and ypn.product_pk = yp.product_pk

   -- The 2 lines below were added to make sure the product doesn't exist in Lexicon yet. 
   and yp.product_pk = lp.midas_product_id (+) and lp.midas_product_id is null
 --  and ypn.product_name_pk = lpn.product_name_id (+) and lpn.product_name_id is null
   -- 
   and yp.crop_id = ycrop.crop_pk 
   and ypn.country_pk = yctry.country_pk 
   and UPPER(yctry.name) = lctry.country_name
   and upper(ycrop.name) = lcrop.crop_name
   and lcrop.crop_id = lbc.crop_id
   and lbc.bayer_code_name in ('ZEAMD', 'GLXMA', 'HELAN', 'SORGR', 'BRSNW', 'GOSHI')
   and ypn.product_name_pk = lmdpn.product_pk(+) 
   and lmdpn.product_pk is null 
)
;
-- Step 10: This query inserts product records from YldMart that haven't been loaded to Lexicon.  

insert into lexicon.product (product_pubkey, product_id, crop_id)
(
select lexicon.product_pubkey_seq.nextval, iq.UniqueProduct, iq.CropId
 FROM (
    Select distinct ypn.product_pk as UniqueProduct, lcrop.crop_id as CropId
    From yldmart.product_name@prem ypn, 
       lexicon.midas_lexicon_product lp,
    --   lexicon.product_name lpn,
       yldmart.brand@prem yb, 
       lexicon.brand lb,
	   yldmart.company@prem ycomp,  
       yldmart.product@prem yp, 
	   yldmart.crop@prem ycrop,
	   yldmart.country@prem yctry, 
	   lexicon.country lctry,
	   lexicon.crop lcrop, 
	   lexicon.bayer_code lbc,
	   lexicon.midas_dup_product_name lmdpn
 where ypn.brand_pk = yb.brand_pk 
   and yb.name = lb.brand_name
   and yb.company_pk = ycomp.company_pk 
   and ycomp.name <> 'MONSANTO' 
   and ypn.product_pk = yp.product_pk
    -- 
   and yp.product_pk = lp.midas_product_id (+) and lp.midas_product_id is null
   -- and ypn.product_name_pk = lpn.product_name_id (+) and lpn.product_name_id is null
   --
   and yp.crop_id = ycrop.crop_pk 
   and ypn.country_pk = yctry.country_pk 
   and UPPER(yctry.name) = lctry.country_name
   and upper(ycrop.name) = lcrop.crop_name
   and lcrop.crop_id = lbc.crop_id
   and lbc.bayer_code_name in ('ZEAMD', 'GLXMA', 'HELAN', 'SORGR', 'BRSNW', 'GOSHI')
   and ypn.product_name_pk = lmdpn.product_pk(+) 
   and lmdpn.product_pk is null 
--   and rownum <= 10
)  iq
);

-- Step 10a, populate midas_lexicon_product with new rows
insert into lexicon.midas_lexicon_product (midas_product_id, lexicon_product_id)
(select lp.product_id, lexicon.product_id_seq.nextval 
   from lexicon.product lp, lexicon.midas_lexicon_product lmap
  where lp.product_id = lmap.lexicon_product_id(+)
    and lmap.lexicon_product_id is null);
   
-- Step 10b, update lexicon_product table with lexicon values instead of midas keys
begin
declare
str VARCHAR2(500);

CURSOR c_map  IS
   SELECT  *
     FROM  lexicon.midas_lexicon_product; 

begin
  FOR rec IN c_map LOOP
    str := 'update lexicon.product set product_id = :lex_prod_id where product_id = :midas_prod_id';
    execute immediate str using rec.lexicon_product_id, rec.midas_product_id;
  end loop;
end;
end;

-- Step 11:  This query gives us the count of product_name count of product records from YldMart that 
-- haven't been loaded to Lexicon.

SELECT count(*) from (
Select ypn.product_pk, ypn.product_name_pk, ypn.name, lctry.country_id, lbc.bayer_code_id, lb.brand_id
  
   From yldmart.product_name@prem ypn, 
   --    lexicon.product lp,
       lexicon.product_name lpn,
       yldmart.brand@prem yb, 
       lexicon.brand lb,
	   yldmart.company@prem ycomp,  
       yldmart.product@prem yp, 
	   yldmart.crop@prem ycrop,
	   yldmart.country@prem yctry, 
	   lexicon.country lctry,
	   lexicon.crop lcrop, 
	   lexicon.bayer_code lbc,
	   lexicon.midas_dup_product_name lmdpn
 where ypn.brand_pk = yb.brand_pk 
   and yb.name = lb.brand_name
   and yb.company_pk = ycomp.company_pk 
   and ycomp.name <> 'MONSANTO' 
   and ypn.product_pk = yp.product_pk
   -- 
   -- and yp.product_pk = lp.product_id (+) and lp.product_id is null
   and ypn.product_name_pk = lpn.product_name_id (+) and lpn.product_name_id is null
   --
   and yp.crop_id = ycrop.crop_pk 
   and ypn.country_pk = yctry.country_pk 
   and UPPER(yctry.name) = lctry.country_name
   and upper(ycrop.name) = lcrop.crop_name
   and lcrop.crop_id = lbc.crop_id
   and lbc.bayer_code_name in ('ZEAMD', 'GLXMA', 'HELAN', 'SORGR', 'BRSNW', 'GOSHI')
   and ypn.product_name_pk = lmdpn.product_pk(+) 
   and lmdpn.product_pk is null 
)
;  

-- Step 12: Load Lexicon.Product_Name competitive product (names) for corn, soybeans, cotton, OSR-Canola, sorghum, 
-- and sunflower where product_name records from YldMart haven't been loaded to Lexicon.

insert into lexicon.product_name (product_name_pubkey, product_id, product_name_id, brand_id, bayer_code_id, 
country_id, product_name, is_active)
(
select lexicon.product_name_pubkey_seq.nextval, iq.productid, iq.productnameid,
       iq.brandid, iq.bayercodeid, iq.countryid, iq.productname, 'y'
From
(select lmap.lexicon_product_id as productid, ypn.product_name_pk as productnameid, lb.brand_id as brandid, 
                 lbc.bayer_code_id as bayercodeid, 
                 lctry.country_id as countryid, ypn.name as productname

  From yldmart.product_name@prem ypn, 
   --    lexicon.product lp,
       lexicon.product_name lpn,
       lexicon.midas_lexicon_product lmap,
       yldmart.brand@prem yb, 
       lexicon.brand lb,
	   yldmart.company@prem ycomp,  
       yldmart.product@prem yp, 
	   yldmart.crop@prem ycrop,
	   yldmart.country@prem yctry, 
	   lexicon.country lctry,
	   lexicon.crop lcrop, 
	   lexicon.bayer_code lbc,
	   lexicon.midas_dup_product_name lmdpn
 where ypn.brand_pk = yb.brand_pk 
   and yb.name = lb.brand_name
   and yb.company_pk = ycomp.company_pk 
   and ycomp.name <> 'MONSANTO' 
   and ypn.product_pk = yp.product_pk
   and yp.product_pk = lmap.midas_product_id
   --
 --  and yp.product_pk = lp.product_id (+) and lp.product_id is null
   and ypn.product_name_pk = lpn.product_name_id (+) and lpn.product_name_id is null
   --
   and yp.crop_id = ycrop.crop_pk 
   and ypn.country_pk = yctry.country_pk 
   and UPPER(yctry.name) = lctry.country_name
   and upper(ycrop.name) = lcrop.crop_name
   and lcrop.crop_id = lbc.crop_id
   and lbc.bayer_code_name in ('ZEAMD', 'GLXMA', 'HELAN', 'SORGR', 'BRSNW', 'GOSHI')
   and ypn.product_name_pk = lmdpn.product_pk(+) 
   and lmdpn.product_pk is null 
--   and rownum <= 10
) iq
);  

 -- Step 13: RUN ONCE to put countries back to Lexicon Names
-- Run the update queries to make the country names match between Midas and Lexicon.  
-- Will change back after products are loaded.

Update Lexicon.country set country_name = 'VIET NAM' where country_name = 'VIETNAM';
Update Lexicon.country set country_name = 'UNITED KINGDOM OF GREAT BRITAIN AND NORTHERN IRELA' 
    where country_name = 'UNITED KINGDOM OF GREAT BRITAIN AND NORTHERN IREL';
Update Lexicon.country set country_name = 'REPUBLIC OF KOREA' where country_name = 'KOREA';
Update Lexicon.country set country_name = 'COLOMBIA' where country_name = 'COLUMBIA';
Update Lexicon.country set country_name = 'IRAN (ISLAMIC REPUBLIC OF)' where country_name = 'IRAN';

-- step 13b, populate midas_lexicon_product_name
insert into lexicon.midas_lexicon_product_name (midas_product_name_id, lexicon_product_name_id)
(select product_name_id, lexicon.product_name_id_seq.nextval 
   from lexicon.product_name);
   
-- Step 13b, update lexicon_product table with lexicon values instead of midas keys
begin
declare
str VARCHAR2(500);

CURSOR c_map  IS
   SELECT  *
     FROM  lexicon.midas_lexicon_product_name; 

begin
  FOR rec IN c_map LOOP
    str := 'update lexicon.product_name set product_name_id = :lex_prod_id where product_name_id = :midas_prod_id';
    execute immediate str using rec.lexicon_product_name_id, rec.midas_product_name_id;
  end loop;
end;
end;

-- Step 14: Check - Count Lexicon Products.

Select count(p.product_id)
from lexicon.product p;

-- Step 15: Check - Count Lexicon product names.

Select count(pn.product_name_id)
from lexicon.product_name pn;




select count(*) from lexicon.product_name;
