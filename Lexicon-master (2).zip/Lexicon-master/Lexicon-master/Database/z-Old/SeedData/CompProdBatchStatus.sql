BEGIN
INSERT INTO comp_prod_BATCH_ROW_STATUS (comp_prod_BATCH_ROW_STATUS, comp_prod_BATCH_ROW_STAT_NAME)
  VALUES('C', 'Committed');

INSERT INTO comp_prod_BATCH_ROW_STATUS (comp_prod_BATCH_ROW_STATUS, comp_prod_BATCH_ROW_STAT_NAME)
  VALUES('V', 'Validated');

INSERT INTO comp_prod_BATCH_ROW_STATUS (comp_prod_BATCH_ROW_STATUS, comp_prod_BATCH_ROW_STAT_NAME)
  VALUES('U', 'Unprocessed');

INSERT INTO comp_prod_BATCH_ROW_STATUS (comp_prod_BATCH_ROW_STATUS, comp_prod_BATCH_ROW_STAT_NAME)
  VALUES('E', 'Errored');

INSERT INTO comp_prod_BATCH_ROW_STATUS (comp_prod_BATCH_ROW_STATUS, comp_prod_BATCH_ROW_STAT_NAME)
  VALUES('A', 'Abandoned');
END;
/

