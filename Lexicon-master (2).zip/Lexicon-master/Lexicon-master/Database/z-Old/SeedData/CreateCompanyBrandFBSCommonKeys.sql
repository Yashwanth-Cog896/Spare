-- Run these in devl.
select company_pubkey, company_name from lexicon.company 
where company_name in ('DOW', 'DUPONT', 'MONSANTO', 'SYNGENTA', 'LIMAGRAIN', 'BAYER', 'PUBLIC', 'COMPETITOR', 'D&PL');


select b.brand_pubkey, b.brand_name, b.is_active, c.company_pubkey, c.company_name, c.is_active
from lexicon.brand b, lexicon.company c 
where b.company_id = c.company_id
and company_name in ('DOW', 'DUPONT', 'MONSANTO', 'SYNGENTA', 'LIMAGRAIN', 'BAYER', 'PUBLIC', 'COMPETITOR', 'D&PL');

-- Run these in tst environment
select c.company_pubkey, c.company_name, m.company_id, m.name
from lexicon.company c, midas.company@prem_tst m
where c.company_name = m.name;

select b.brand_pubkey, b.brand_name, b.is_active, c.company_pubkey, c.company_name, c.is_active
from lexicon.brand b, lexicon.company c 
where b.company_id = c.company_id;

