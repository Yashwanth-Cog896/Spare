INSERT INTO Product_Stage(product_stage_id, product_stage_public_key, product_stage_name, product_stage_abbr, product_stage_type) VALUES (1, 'CM', 'Commercial', 'CM', 'Commercial');
