--Lookup DKB27-51 and 27-51R
-- Products aren't in Lexicon
select p.product_pubkey, p.product_id, p.pre_coml_name, pn.product_stage_pubkey, pn.product_stage_id, 
b.brand_pubkey, b.brand_id, b.brand_name, 
pn.commercial_name,  pn.is_active, 
c.country_id, c.country_pubkey, c.country_name
from lexicon.pre_coml_product p, 
lexicon.product_stage pn, 
lexicon.brand b,
lexicon.country c
where p.product_id = pn.product_id
and pn.brand_id = b.brand_id 
and pn.country_id = c.country_id
and p.product_id = '370202';

--Competitive product for inactive brands
select p.product_pubkey, p.product_id, pn.product_name_pubkey, pn.product_name_id, pn.product_name,  
b.brand_pubkey, b.brand_id, b.brand_name, pn.is_active, 
c.country_id, c.country_pubkey, c.country_name, mb.name "Midas brand", mb.ref_active
from lexicon.product p, 
lexicon.product_name pn, 
lexicon.brand b,
lexicon.country c, fbs_common.brand_xref@prem bx, midas.brand@prem mb
where p.product_id = pn.product_id
and pn.brand_id = b.brand_id 
and pn.country_id = c.country_id
and b.brand_pubkey = bx.lexicon_brand_pubkey
and mb.brand_id = bx.midas_brand_id
and mb.ref_active = 'F'
;


-- display products linking Lexicon to FBSCOMMON 

--select p.product_pubkey, p.product_id, p.pre_coml_name, pn.product_stage_pubkey, pn.product_stage_id, 
--b.brand_pubkey, b.brand_id, b.brand_name, 
---pn.commercial_name,  pn.is_active, 
--c.country_id, c.country_pubkey, c.country_name,
--px.midas_product_id, pnx.midas_product_name_id, pnx.mirage_product_id
--from lexicon.pre_coml_product p, 
--lexicon.product_stage pn, 
--lexicon.brand b,
--lexicon.country c,
--fbs_common.product_xref@prem px,
--fbs_common.product_name_xref@prem pnx
--where p.product_id = pn.product_id
--and pn.brand_id = b.brand_id 
--and pn.country_id = c.country_id
--and p.product_pubkey = px.lexicon_product_pubkey
--and pn.product_stage_pubkey = pnx.lexicon_product_name_pubkey
--and b.brand_name = 'STONEVILLE';

--map_product_mirage
select mpm.*
from yldstg.map_product_mirage@prem mpm
where mpm.seed_product_id = '1380452';

-- display Mirage product data 

select  sp.product_id, co.company_name, sp.product_name, ct.country_name, sp.enabled
from  mirage2.seed_products@ceregn sp,
mirage2.companies@ceregn co,
mirage2.countries@ceregn ct
where sp.country_code = ct.country_code
and sp.company_id = co.company_id
and sp.product_name in ('S54-G9');
--and sp.product_id = '1822';

-- List product data from Midas for brand

select mp.product_id, mpn.product_name_id, mb.name, mpn.name, mco.name, mct.name, mp.ref_active "Prod Active",
 mpn.ref_active "PN Active"
from midas.product@prem mp,
midas.product_name@prem mpn,
midas.brand@prem mb, 
midas.country@prem mct, 
midas.company@prem mco
where mp.product_id = mpn.product_id
and mpn.brand_id = mb.brand_id 
and mpn.country_id = mct.country_id 
and mb.company_id = mco.company_id
and mpn.name in ('S54-G9');

--Identify Midas products using a brand id that isn't in FBS_COMMON
select mp.product_id, mpn.product_name_id, mb.name "brand", mpn.name"product", mco.name "company", mct.name "country", mp.ref_active "Prod Active",
 mpn.ref_active "PN Active", mb.ref_active "brand", mb.brand_id
from midas.product@prem mp,
midas.product_name@prem mpn,
midas.brand@prem mb, 
midas.country@prem mct, 
midas.company@prem mco, 
fbs_common.brand_xref@prem bx
where mp.product_id = mpn.product_id
and mpn.brand_id = mb.brand_id 
and mpn.country_id = mct.country_id 
and mb.company_id = mco.company_id
and mb.brand_id = bx.midas_brand_id (+)
and bx.midas_brand_id is null
and mp.ref_active = 'T'
and mpn.ref_active = 'T';

--Identify bad brand ids
select distinct mb.brand_id, mb.name
from midas.product@prem mp,
midas.product_name@prem mpn,
midas.brand@prem mb, 
midas.country@prem mct, 
midas.company@prem mco, 
fbs_common.brand_xref@prem bx
where mp.product_id = mpn.product_id
and mpn.brand_id = mb.brand_id 
and mpn.country_id = mct.country_id 
and mb.company_id = mco.company_id
and mb.brand_id = bx.midas_brand_id (+)
and bx.midas_brand_id is null
and mp.ref_active = 'T'
and mpn.ref_active = 'T';

select * from midas.brand@prem b, midas.company@prem c
where b.company_id = c.company_id
and b.name in ('LUMIAN6',
'ANKUR651',
'SICALA40',
'XINLUZAO8',
'ZHONGMIAN35',
'CIM473',
'MBS',
'FUNDULEA',
'COOPDEPAU',
'RAGT',
'KWS',
'ADVANTA')
order by b.name
;


select * from lexicon.brand b, lexicon.company c, fbs_common.brand_xref@prem bx
where b.company_id = c.company_id
and b.brand_pubkey = bx.lexicon_brand_pubkey
and b.brand_name in ('LUMIAN6',
'ANKUR651',
'SICALA40',
'XINLUZAO8',
'ZHONGMIAN35',
'CIM473',
'MBS',
'FUNDULEA',
'COOPDEPAU',
'RAGT',
'KWS',
'ADVANTA');



-- FIX from HERE DOWN!!!!!!!
select * from fbs_common.product_name_xref@prem px 
where px.lexicon_product_name_pubkey in ('141407');

select * from fbs_common.product_name_xref@prem px 
where px.MIDAS_product_name_ID in (1352801910784);

select * from fbs_common.product_name_xref@prem px 
where px.mirage_product_ID = '1380452';

-- check out germplasm and genetic material for Monsanto products for brand.

select mpn.product_name_id, mpn.name, mpn.country_id, mp.product_id, 
  g.pedigree_name, gm.source_str, g.origin, g.line_code,g.germplasm_id, gm.genetic_material_id
from  
midas.product_name@prem mpn,
midas.brand@prem mb, 
midas.product@prem mp,
midas.product_germplasm@prem pg,
midas.germplasm@prem g,
midas.genetic_material@prem gm
where  mpn.brand_id = mb.brand_id 
and mpn.product_id = mp.product_id
and mp.product_id = pg.product_id
and pg.germplasm_id = g.germplasm_id
and g.germplasm_id = gm.germplasm_id
and mp.product_id in (3082829168640)
order by mpn.name;

-- 2462601183232 is the product_id

select * 
from yldstg.map_product_mirage@prem mpm
where mpm.genetic_material_pk in (
2450741985280,
2766759002112);

select sp.product_id, sp.product_name, co.company_name, ct.country_name
from mirage2.seed_products@ceregn sp, mirage2.companies@ceregn co, mirage.countries@ceregn ct
where sp.company_id = co.company_id 
and sp.country_code = ct.country_code
and sp.product_id in (7471,1410904);


