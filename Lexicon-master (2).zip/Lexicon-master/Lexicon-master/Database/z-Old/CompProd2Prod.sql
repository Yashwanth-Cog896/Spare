CREATE TABLE Product(
    product_id                      NUMBER NOT NULL,
    product_pubkey                  VARCHAR2(20) NOT NULL,
    crop_id                         NUMBER NOT NULL,
    
	CONSTRAINT Product_PK
		PRIMARY KEY (product_id)
		USING INDEX
	TABLESPACE  Lexicon_Index,
	
	CONSTRAINT Product_AK1
		UNIQUE (product_pubkey)
		USING INDEX
	TABLESPACE  Lexicon_Index
)
TABLESPACE Lexicon_Data;

CREATE TABLE Product_Name(
	product_name_id                 NUMBER NOT NULL,
	product_name_pubkey             VARCHAR2(20) NOT NULL,
	product_name                    VARCHAR2(50),
	product_id                      NUMBER NOT NULL,
	bayer_code_id                   NUMBER,
	country_id                      NUMBER,
	brand_id                        NUMBER,
	commercial_maturity             NUMBER(6,1),
	verified_data_source            VARCHAR2(20),
	data_source_year                NUMBER,
	requestor_name                  VARCHAR2(50),
	comments                        VARCHAR2(2000),

	is_active                       VARCHAR2(1) NOT NULL
		CONSTRAINT Trueorfalse204
			CHECK (is_active IN ('y', 'n')),    

	process_id                      NUMBER NULL,
	user_id                         NUMBER,
	entry_date                      DATE DEFAULT SYSDATE NOT NULL,

	CONSTRAINT Product_Name_PK
		PRIMARY KEY (product_name_id)
		USING INDEX
	TABLESPACE  Lexicon_Index,

	CONSTRAINT Product_Name_AK1
		UNIQUE (product_name, bayer_code_id, country_id, brand_id)
		USING INDEX
	TABLESPACE Lexicon_Index,
        
	CONSTRAINT Product_Name_AK2
		UNIQUE (product_name_pubkey)
		USING INDEX
	TABLESPACE Lexicon_Index
)
TABLESPACE Lexicon_Data;

CREATE INDEX Product_Name_IDX1 ON Product_Name(
	brand_id                        ASC
)
TABLESPACE Lexicon_Index;

CREATE INDEX Product_Name_IDX2 ON Product_Name(
	bayer_code_id                   ASC
)
TABLESPACE Lexicon_Index;

CREATE INDEX Product_Name_IDX3 ON Product_Name(
	country_id                      ASC
)
TABLESPACE Lexicon_Index;

CREATE TABLE Product_Name_Trait(
	product_name_trait_id           NUMBER NOT NULL,
	product_name_id                 NUMBER NOT NULL,
	trait_id                        NUMBER NOT NULL,
	process_id                      NUMBER NULL,
	user_id                         NUMBER,
	entry_date                      DATE DEFAULT SYSDATE NOT NULL,

	CONSTRAINT Product_Name_Triat_PK
		PRIMARY KEY (product_name_trait_id)
		USING INDEX
	TABLESPACE  Lexicon_Index,

	CONSTRAINT Product_Name_Trait_AK1
		UNIQUE (product_name_id, trait_id)
		USING INDEX
	TABLESPACE Lexicon_Index
)        
TABLESPACE Lexicon_Data;

CREATE INDEX Product_Name_Trait_IDX1 ON Product_Name_Trait(
	trait_id                        ASC
)
TABLESPACE Lexicon_Index;



ALTER TABLE Product
	ADD CONSTRAINT FK_Prod_Crop_CropId
		FOREIGN KEY (crop_id)
		REFERENCES Crop (crop_id);

ALTER TABLE Product_Name
	ADD CONSTRAINT FK_ProdName_Prod_ProdId
		FOREIGN KEY (product_id)
		REFERENCES Product (product_id);

ALTER TABLE Product_Name
	ADD CONSTRAINT FK_ProdName_BayerCd_BayerCdId 
		FOREIGN KEY (bayer_code_id)
		REFERENCES Bayer_Code (bayer_code_id);

ALTER TABLE Product_Name
	ADD CONSTRAINT FK_ProdName_Brand_BrandId 
		FOREIGN KEY (brand_id)
		REFERENCES Brand (brand_id);

ALTER TABLE Product_Name
	ADD CONSTRAINT FK_Prod_Name_Country_CountryId 
		FOREIGN KEY (country_id)
		REFERENCES Country (country_id);

ALTER TABLE Product_Name_Trait
	ADD CONSTRAINT FK_ProdNmTrt_Trait_TraitId 
		FOREIGN KEY (trait_id)
		REFERENCES Trait (trait_id);
		
ALTER TABLE Product_Name_Trait
	ADD CONSTRAINT FK_ProdNmTrt_ProdNm_ProdNmId
		FOREIGN KEY (product_name_id)
		REFERENCES Product_Name (product_name_id);

