CREATE SEQUENCE Comp_prod_batch_id_seq 
INCREMENT BY 1 
START WITH 1000 
NOMAXVALUE 
NOMINVALUE 
CACHE 30 
NOCYCLE
NOORDER
;
CREATE SEQUENCE Comp_prod_batch_row_id_seq 
INCREMENT BY 1 
START WITH 1000 
NOMAXVALUE 
NOMINVALUE 
CACHE 30 
NOCYCLE
NOORDER
;
CREATE SEQUENCE Product_germplasm_id_seq 
INCREMENT BY 1 
START WITH 1000 
NOMAXVALUE 
NOMINVALUE 
CACHE 30 
NOCYCLE
NOORDER
;
CREATE SEQUENCE Product_id_seq 
INCREMENT BY 1 
START WITH 1000 
NOMAXVALUE 
NOMINVALUE 
CACHE 30 
NOCYCLE
NOORDER
;
CREATE SEQUENCE Product_trait_id_seq 
INCREMENT BY 1 
START WITH 1000 
NOMAXVALUE 
NOMINVALUE 
CACHE 30 
NOCYCLE
NOORDER
;
CREATE SEQUENCE Resource_lock_id_seq 
INCREMENT BY 1 
START WITH 1000 
NOMAXVALUE 
NOMINVALUE 
CACHE 30 
NOCYCLE
NOORDER
;
CREATE SEQUENCE Transgenic_event_id_seq 
INCREMENT BY 1 
START WITH 1000 
NOMAXVALUE 
NOMINVALUE 
CACHE 30 
NOCYCLE
NOORDER
;
CREATE SEQUENCE User_preference_id_seq 
INCREMENT BY 1 
START WITH 1000 
NOMAXVALUE 
NOMINVALUE 
CACHE 30 
NOCYCLE
NOORDER
;
CREATE SEQUENCE User_preference_value_id_seq 
INCREMENT BY 1 
START WITH 1000 
NOMAXVALUE 
NOMINVALUE 
CACHE 30 
NOCYCLE
NOORDER
;

CREATE TABLE BRAND (
       Brand_id             NUMBER NOT NULL,
       Brand_name           VARCHAR2(50) NULL,
       Is_Monsanto_com_brand VARCHAR2(1) NULL
                                   CONSTRAINT Trueorfalse200
                                          CHECK (Is_Monsanto_com_brand IN ('T', 'F')),
       Is_global_brand      VARCHAR2(1) NULL
                                   CONSTRAINT Trueorfalse201
                                          CHECK (Is_global_brand IN ('T', 'F')),
       Is_competitor_brand  VARCHAR2(1) NULL
                                   CONSTRAINT Trueorfalse202
                                          CHECK (Is_competitor_brand IN ('T', 'F')),
       Company_id           NUMBER NULL,
       Is_active            VARCHAR2(1) NULL
                                   CONSTRAINT Trueorfalse203
                                          CHECK (Is_active IN ('T', 'F')),
       CONSTRAINT BRAND_PK 
              PRIMARY KEY (Brand_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT BRAND_AK1
       UNIQUE (
              Brand_name
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;

CREATE UNIQUE INDEX BRAND_PK ON BRAND
(
       Brand_id                       ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX BRAND_IDX1 ON BRAND
(
       Company_id                     ASC
)
    	 TABLESPACE LEXICON_INDEX
;


CREATE TABLE COMP_PROD_BATCH (
       Comp_prod_batch_id   NUMBER NOT NULL,
       Comp_prod_batch_name VARCHAR2(50) NULL,
       Num_total            NUMBER NULL,
       Num_committed        NUMBER NULL,
       Num_validated        NUMBER NULL,
       Num_errored          NUMBER NULL,
       Num_abandoned        NUMBER NULL,
       Num_unprocessed      NUMBER NULL,
       Entry_date           DATE NULL,
       CONSTRAINT COMP_PROD_BATCH_PK 
              PRIMARY KEY (Comp_prod_batch_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT COMP_PROD_BATCH_AK1
       UNIQUE (
              Comp_prod_batch_name
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
);

CREATE UNIQUE INDEX COMP_PROD_BATCH_PK ON COMP_PROD_BATCH
(
       Comp_prod_batch_id             ASC
)
    	 TABLESPACE LEXICON_INDEX
;


CREATE TABLE COMP_PROD_BATCH_ROW (
       Comp_prod_batch_row_id NUMBER NOT NULL,
       Comp_prod_batch_id   NUMBER NULL,
       Comp_prod_batch_row_num NUMBER NULL,
       Comp_prod_batch_row_status VARCHAR2(1) NULL,
       XML_representation   VARCHAR2(2000) NULL,
       CONSTRAINT COMP_PROD_BATCH_ROW_PK 
              PRIMARY KEY (Comp_prod_batch_row_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT COMP_PROD_BATCH_ROW_AK1
       UNIQUE (
              Comp_prod_batch_id,
              Comp_prod_batch_row_num
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
);

CREATE UNIQUE INDEX COMP_PROD_BATCH_ROW_PK ON COMP_PROD_BATCH_ROW
(
       Comp_prod_batch_row_id         ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX COMP_PROD_BATCH_ROW_IDX1 ON COMP_PROD_BATCH_ROW
(
       Comp_prod_batch_id             ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX COMP_PROD_BATCH_ROW_IDX2 ON COMP_PROD_BATCH_ROW
(
       Comp_prod_batch_row_status     ASC
)
    	 TABLESPACE LEXICON_INDEX
;


CREATE TABLE COMP_PROD_BATCH_ROW_STATUS (
       Comp_prod_batch_row_status VARCHAR2(1) NOT NULL,
       Comp_prod_batch_row_stat_name VARCHAR2(20) NULL,
       CONSTRAINT COMP_PROD_BATCH_ROW_STATUS_PK 
              PRIMARY KEY (Comp_prod_batch_row_status)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT COMP_PROD_BATCH_ROW_STATUS_AK1
       UNIQUE (
              Comp_prod_batch_row_stat_name
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
);

CREATE UNIQUE INDEX COMP_PROD_BATCH_ROW_STATUS_PK ON COMP_PROD_BATCH_ROW_STATUS
(
       Comp_prod_batch_row_status     ASC
)
    	 TABLESPACE LEXICON_INDEX
;


CREATE TABLE COMP_PROD_COUNTRY (
       Comp_prod_country_id NUMBER NOT NULL,
       Comp_prod_id         NUMBER NULL,
       Country_id           NUMBER NULL,
       CONSTRAINT COMP_PROD_COUNTRY_PK 
              PRIMARY KEY (Comp_prod_country_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT COMP_PROD_COUNTRY_AK1
       UNIQUE (
              Comp_prod_id,
              Country_id
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
);

CREATE UNIQUE INDEX COMP_PROD_COUNTRY_PK ON COMP_PROD_COUNTRY
(
       Comp_prod_country_id           ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX COMP_PROD_COUNTRY_IDX1 ON COMP_PROD_COUNTRY
(
       Comp_prod_id                   ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX COMP_PROD_COUNTRY_IDX2 ON COMP_PROD_COUNTRY
(
       Country_id                     ASC
)
    	 TABLESPACE LEXICON_INDEX
;


CREATE TABLE COMP_PROD_EQUIV (
       Comp_prod_equiv_id   NUMBER NOT NULL,
       Comp_prod_id         NUMBER NULL,
       CONSTRAINT COMP_PROD_EQUIV_PK 
              PRIMARY KEY (Comp_prod_equiv_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT COMP_PROD_EQUIV_AK1
       UNIQUE (
              Comp_prod_id
       )
);

CREATE UNIQUE INDEX COMP_PROD_EQUIV_PK ON COMP_PROD_EQUIV
(
       Comp_prod_equiv_id             ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX COMP_PROD_EQUIV_IDX1 ON COMP_PROD_EQUIV
(
       Comp_prod_id                   ASC
)
    	 TABLESPACE LEXICON_INDEX
;


CREATE TABLE COMP_PROD_TRAIT (
       Comp_prod_trait_id   NUMBER NOT NULL,
       Trait_id             NUMBER NULL,
       Comp_prod_id         NUMBER NULL,
       CONSTRAINT COMP_PROD_TRAIT_PK 
              PRIMARY KEY (Comp_prod_trait_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT COMP_PROD_TRAIT_AK1
       UNIQUE (
              Trait_id,
              Comp_prod_id
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
);

CREATE UNIQUE INDEX COMP_PROD_TRAIT_PK ON COMP_PROD_TRAIT
(
       Comp_prod_trait_id             ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX COMP_PROD_TRAIT_IDX1 ON COMP_PROD_TRAIT
(
       Trait_id                       ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX COMP_PROD_TRAIT_IDX2 ON COMP_PROD_TRAIT
(
       Comp_prod_id                   ASC
)
    	 TABLESPACE LEXICON_INDEX
;


CREATE TABLE COMP_PRODUCT (
       Comp_prod_id         NUMBER NOT NULL,
       Product_name         VARCHAR2(50) NULL,
       Brand_id             NUMBER NULL,
       Commercial_maturity  NUMBER(6,1) NULL,
       Verified_data_source VARCHAR2(20) NULL,
       Data_source_year     NUMBER NULL,
       Crop_id              NUMBER NULL,
       Requestor_name       VARCHAR2(50) NULL,
       Comments             VARCHAR2(2000) NULL,
       Process_id           NUMBER NULL,
       User_id              NUMBER NULL,
       Last_update_date     DATE NULL,
       Entry_date           DATE NULL,
       Is_active            VARCHAR2(20) NULL
                                   CONSTRAINT Trueorfalse204
                                          CHECK (Is_active IN ('T', 'F')),
       Comp_prod_equiv_id   NUMBER NULL,
       CONSTRAINT COMP_PRODUCT_PK 
              PRIMARY KEY (Comp_prod_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT COMP_PRODUCT_AK1
       UNIQUE (
              Product_name,
              Crop_id
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
);

CREATE UNIQUE INDEX COMP_PRODUCT_PK ON COMP_PRODUCT
(
       Comp_prod_id                   ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX COMP_PRODUCT_IDX1 ON COMP_PRODUCT
(
       Brand_id                       ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX COMP_PRODUCT_IDX2 ON COMP_PRODUCT
(
       Process_id                     ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX COMP_PRODUCT_IDX3 ON COMP_PRODUCT
(
       Crop_id                        ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX COMP_PRODUCT_IDX4 ON COMP_PRODUCT
(
       Comp_prod_equiv_id             ASC
)
    	 TABLESPACE LEXICON_INDEX
;


CREATE TABLE COMPANY (
       Company_id           NUMBER NOT NULL,
       Company_name         VARCHAR2(50) NULL,
       Is_active            VARCHAR2(1) NULL
                                   CONSTRAINT Trueorfalse205
                                          CHECK (Is_active IN ('T', 'F')),
       CONSTRAINT COMPANY_PK 
              PRIMARY KEY (Company_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT COMPANY_AK1
       UNIQUE (
              Company_name
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;

CREATE UNIQUE INDEX COMPANY_PK ON COMPANY
(
       Company_id                     ASC
)
    	 TABLESPACE LEXICON_INDEX
;


CREATE TABLE COUNTRY (
       Country_id           NUMBER NOT NULL,
       Country_abbr         VARCHAR2(5) NULL,
       Country_name         VARCHAR2(50) NULL,
       CONSTRAINT COUNTRY_PK 
              PRIMARY KEY (Country_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT COUNTRY_AK1
       UNIQUE (
              Country_abbr
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;

CREATE UNIQUE INDEX COUNTRY_PK ON COUNTRY
(
       Country_id                     ASC
)
    	 TABLESPACE LEXICON_INDEX
;


CREATE TABLE CROP (
       Crop_id              NUMBER NOT NULL,
       Crop_name            VARCHAR2(50) NOT NULL,
       Bayer_code           VARCHAR2(20) NOT NULL,
       Relative_maturity_min NUMBER(6,1) NULL,
       Relative_maturity_max NUMBER(6,1) NULL,
       Relative_maturity_increment NUMBER(6,1) NULL,
       Bayer_descr          VARCHAR2(50) NULL,
       Midas_crop_id        NUMBER NULL,
       CONSTRAINT PK_CROP 
              PRIMARY KEY (Crop_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT AK_CROP1
       UNIQUE (
              Crop_name,
              Bayer_code
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;

CREATE UNIQUE INDEX PK_CROP ON CROP
(
       Crop_id                        ASC
)
    	 TABLESPACE LEXICON_INDEX
;


CREATE TABLE EQUIV_GERMPLASM_MAP (
       Equiv_germplasm_map_id NUMBER NOT NULL,
       Primary_product_germplasm_id NUMBER NOT NULL,
       Product_germplasm_id NUMBER NOT NULL,
       Country_id           NUMBER NOT NULL,
       Reason               VARCHAR2(50) NULL,
       Equiv_type_id        NUMBER NULL,
       Process_id           NUMBER NULL,
       User_id              NUMBER NULL,
       Entry_date           DATE NULL,
       CONSTRAINT EQUIV_GERMPLASM_MAP_PK 
              PRIMARY KEY (Equiv_germplasm_map_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT AK1_EQUIV_GERMPLASM_MAP
       UNIQUE (
              Primary_product_germplasm_id,
              Product_germplasm_id,
              Country_id
       )
)
    	 TABLESPACE LEXICON_DATA
 ;

CREATE UNIQUE INDEX EQUIV_GERMPLASM_MAP_PK ON EQUIV_GERMPLASM_MAP
(
       Equiv_germplasm_map_id         ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX EQUIV_GERMPLASM_MAP_IDX1 ON EQUIV_GERMPLASM_MAP
(
       Product_germplasm_id           ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX EQUIV_GERMPLASM_MAP_IDX2 ON EQUIV_GERMPLASM_MAP
(
       Country_id                     ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX EQUIV_GERMPLASM_MAP_IDX3 ON EQUIV_GERMPLASM_MAP
(
       Primary_product_germplasm_id   ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX EQUIV_GERMPLASM_MAP_IDX4 ON EQUIV_GERMPLASM_MAP
(
       Equiv_type_id                  ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX EQUIV_GERMPLASM_MAP_IDX5 ON EQUIV_GERMPLASM_MAP
(
       Process_id                     ASC
)
    	 TABLESPACE LEXICON_INDEX
;


CREATE TABLE EQUIV_GERMPLASM_MAP_TRANS (
       Equiv_germplasm_trans_id NUMBER NOT NULL,
       Primary_product_germplasm_id NUMBER NULL,
       Product_germplasm_id NUMBER NULL,
       Country_id           NUMBER NULL,
       Reason               VARCHAR2(50) NULL,
       Equiv_type_id        NUMBER NULL,
       Equiv_germplasm_map_id NUMBER NULL,
       Equiv_germplasm_map_status VARCHAR2(1) NULL
                                   CONSTRAINT APRstatus56
                                          CHECK (Equiv_germplasm_map_status IN ('A', 'P', 'R')),
       Process_id           NUMBER NULL,
       User_id              NUMBER NULL,
       Entry_date           DATE NULL,
       CONSTRAINT EQUIV_GERMPLASM_MAP_TRANS_PK 
              PRIMARY KEY (Equiv_germplasm_trans_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT EQUIV_GERMPLASM_MAP_TRANS_AK1
       UNIQUE (
              Primary_product_germplasm_id,
              Product_germplasm_id,
              Country_id,
              Entry_date
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
);

CREATE UNIQUE INDEX EQUIV_GERMPLASM_MAP_TRANS_PK ON EQUIV_GERMPLASM_MAP_TRANS
(
       Equiv_germplasm_trans_id       ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX EQUIV_GERMPLASM_MAP_TRANS_IDX1 ON EQUIV_GERMPLASM_MAP_TRANS
(
       Country_id                     ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX EQUIV_GERMPLASM_MAP_TRANS_IDX2 ON EQUIV_GERMPLASM_MAP_TRANS
(
       Process_id                     ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX EQUIV_GERMPLASM_MAP_TRANS_IDX3 ON EQUIV_GERMPLASM_MAP_TRANS
(
       Product_germplasm_id           ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX EQUIV_GERMPLASM_MAP_TRANS_IDX4 ON EQUIV_GERMPLASM_MAP_TRANS
(
       Primary_product_germplasm_id   ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX EQUIV_GERMPLASM_MAP_TRANS_IDX5 ON EQUIV_GERMPLASM_MAP_TRANS
(
       Equiv_germplasm_map_id         ASC
)
    	 TABLESPACE LEXICON_INDEX
;


CREATE TABLE EQUIV_TYPE (
       Equiv_type_id        NUMBER NOT NULL,
       Equiv_type_name      VARCHAR2(50) NULL,
       CONSTRAINT EQUIV_TYPE_PK 
              PRIMARY KEY (Equiv_type_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT EQUIVALENT_TYPE_IDX1
       UNIQUE (
              Equiv_type_name
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;

CREATE UNIQUE INDEX EQUIV_TYPE_PK ON EQUIV_TYPE
(
       Equiv_type_id                  ASC
)
    	 TABLESPACE LEXICON_INDEX
;


CREATE TABLE INTELLECTUAL_PROPERTY (
       Ip_id                NUMBER NOT NULL,
       Country_id           NUMBER NULL,
       Patent_filing_date   DATE NULL,
       Provisional_patent_filing_date DATE NULL,
       Plantbreeder_right_filing_date DATE NULL,
       US_patent_office_number NUMBER NULL,
       Patent_status        VARCHAR2(50) NULL,
       Product_germplasm_id NUMBER NULL,
       CONSTRAINT INTELLECTUAL_PROPERTY_PK 
              PRIMARY KEY (Ip_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;

CREATE UNIQUE INDEX INTELLECTUAL_PROPERTY_PK ON INTELLECTUAL_PROPERTY
(
       Ip_id                          ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX INTELLECTUAL_PROPERTY_IDX1 ON INTELLECTUAL_PROPERTY
(
       Product_germplasm_id           ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX INTELLECTUAL_PROPERTY_IDX2 ON INTELLECTUAL_PROPERTY
(
       Country_id                     ASC
)
    	 TABLESPACE LEXICON_INDEX
;


CREATE TABLE MIDAS_GERMPLASM (
       Midas_germplasm_id   NUMBER NOT NULL,
       Product_germplasm_id NUMBER NULL,
       CONSTRAINT MIDAS_GERMPLASM_PK 
              PRIMARY KEY (Midas_germplasm_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT MIDAS_GERMPLASM_AK1
       UNIQUE (
              Midas_germplasm_id,
              Product_germplasm_id
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;

CREATE UNIQUE INDEX MIDAS_GERMPLASM_PK ON MIDAS_GERMPLASM
(
       Midas_germplasm_id             ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX MIDAS_GERMPLASM_IDX1 ON MIDAS_GERMPLASM
(
       Product_germplasm_id           ASC
)
    	 TABLESPACE LEXICON_INDEX
;


CREATE TABLE PROCESS (
       Process_id           NUMBER NOT NULL,
       Process_name         VARCHAR2(50) NULL,
       Process_description  VARCHAR2(200) NULL,
       CONSTRAINT PROCESS_PK 
              PRIMARY KEY (Process_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT PROCESS_AK1
       UNIQUE (
              Process_name
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;

CREATE UNIQUE INDEX PROCESS_PK ON PROCESS
(
       Process_id                     ASC
)
    	 TABLESPACE LEXICON_INDEX
;


CREATE TABLE PRODUCT (
       Product_id           NUMBER NOT NULL,
       Product_germplasm_id NUMBER NULL,
       Country_id           NUMBER NULL,
       Brand_id             NUMBER NULL,
       Product_stage_id     NUMBER NULL,
       Commercial_name      VARCHAR2(50) NULL,
       Pre_commercial_name  VARCHAR2(50) NULL,
       Relative_maturity    NUMBER(6,1) NULL,
       Commercial_maturity  NUMBER(6,1) NULL,
       Is_product_stage_active VARCHAR2(1) NULL
                                   CONSTRAINT Trueorfalse206
                                          CHECK (Is_product_stage_active IN ('T', 'F')),
       User_id              NUMBER NULL,
       Entry_date           DATE NULL,
       Process_id           NUMBER NULL,
       CONSTRAINT PRODUCT_PK 
              PRIMARY KEY (Product_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT PRODUCT_AK1
       UNIQUE (
              Product_germplasm_id,
              Country_id,
              Brand_id,
              Product_stage_id
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;

CREATE UNIQUE INDEX PRODUCT_PK ON PRODUCT
(
       Product_id                     ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX PRODUCT_IDX1 ON PRODUCT
(
       Brand_id                       ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX PRODUCT_IDX2 ON PRODUCT
(
       Product_stage_id               ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX PRODUCT_IDX3 ON PRODUCT
(
       Country_id                     ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX PRODUCT_IDX4 ON PRODUCT
(
       Product_germplasm_id           ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX PRODUCT_IDX5 ON PRODUCT
(
       Process_id                     ASC
)
    	 TABLESPACE LEXICON_INDEX
;


CREATE TABLE PRODUCT_GERMPLASM (
       Product_germplasm_id NUMBER NOT NULL,
       Midas_origin         VARCHAR2(2000) NULL,
       Midas_line_code      VARCHAR2(50) NULL,
       Crop_id              NUMBER NULL,
       SAP_origin           VARCHAR2(50) NULL,
       USA_variety_name     VARCHAR2(50) NULL,
       Process_id           NUMBER NULL,
       User_id              NUMBER NULL,
       Entry_date           DATE NULL,
       CONSTRAINT PRODUCT_GERMPLASM_PK 
              PRIMARY KEY (Product_germplasm_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT PRODUCT_GERMPLASM_AK1
       UNIQUE (
              Midas_origin,
              Midas_line_code
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;

CREATE UNIQUE INDEX PRODUCT_GERMPLASM_PK ON PRODUCT_GERMPLASM
(
       Product_germplasm_id           ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX PRODUCT_GERMPLASM_IDX1 ON PRODUCT_GERMPLASM
(
       Crop_id                        ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX PRODUCT_GERMPLASM_IDX2 ON PRODUCT_GERMPLASM
(
       Process_id                     ASC
)
    	 TABLESPACE LEXICON_INDEX
;


CREATE TABLE PRODUCT_GERMPLASM_TRANS (
       Product_germplasm_trans_id NUMBER NOT NULL,
       Midas_origin         VARCHAR2(2000) NULL,
       Midas_line_code      VARCHAR2(50) NULL,
       Crop_id              NUMBER NULL,
       SAP_Origin           VARCHAR2(50) NULL,
       USA_variety_name     VARCHAR2(50) NULL,
       Product_germplasm_id NUMBER NULL,
       Product_germplasm_status VARCHAR2(1) NULL
                                   CONSTRAINT APRstatus57
                                          CHECK (Product_germplasm_status IN ('A', 'P', 'R')),
       Process_id           NUMBER NULL,
       User_id              NUMBER NULL,
       Entry_date           DATE NULL,
       CONSTRAINT PRODUCT_GERMPLASM_TRANS_PK 
              PRIMARY KEY (Product_germplasm_trans_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT PRODUCT_GERMPLASM_TRANS_AK1
       UNIQUE (
              Midas_origin,
              Midas_line_code,
              Entry_date
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
);

CREATE UNIQUE INDEX PRODUCT_GERMPLASM_TRANS_PK ON PRODUCT_GERMPLASM_TRANS
(
       Product_germplasm_trans_id     ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX PRODUCT_GERMPLASM_TRANS_IDX1 ON PRODUCT_GERMPLASM_TRANS
(
       Product_germplasm_id           ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX PRODUCT_GERMPLASM_TRANS_IDX2 ON PRODUCT_GERMPLASM_TRANS
(
       Process_id                     ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX PRODUCT_GERMPLASM_TRANS_IDX3 ON PRODUCT_GERMPLASM_TRANS
(
       Crop_id                        ASC
)
    	 TABLESPACE LEXICON_INDEX
;


CREATE TABLE PRODUCT_STAGE (
       Product_stage_id     NUMBER NOT NULL,
       Product_stage_name   VARCHAR2(50) NULL,
       Product_stage_abbr   VARCHAR2(20) NULL,
       Product_stage_type   VARCHAR2(20) NULL,
       CONSTRAINT PRODUCT_STAGE_PK 
              PRIMARY KEY (Product_stage_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT PRODUCT_STAGE_AK1
       UNIQUE (
              Product_stage_name
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;

CREATE UNIQUE INDEX PRODUCT_STAGE_PK ON PRODUCT_STAGE
(
       Product_stage_id               ASC
)
    	 TABLESPACE LEXICON_INDEX
;


CREATE TABLE PRODUCT_TRAIT (
       Product_trait_id     NUMBER NOT NULL,
       Trait_id             NUMBER NULL,
       Product_id           NUMBER NULL,
       CONSTRAINT PRODUCT_TRAIT_PK 
              PRIMARY KEY (Product_trait_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT PRODUCT_TRAIT_AK1
       UNIQUE (
              Trait_id,
              Product_id
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;

CREATE UNIQUE INDEX PRODUCT_TRAIT_PK ON PRODUCT_TRAIT
(
       Product_trait_id               ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX PRODUCT_TRAIT_IDX1 ON PRODUCT_TRAIT
(
       Trait_id                       ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX PRODUCT_TRAIT_IDX2 ON PRODUCT_TRAIT
(
       Product_id                     ASC
)
    	 TABLESPACE LEXICON_INDEX
;


CREATE TABLE PRODUCT_TRANS (
       Product_trans_id     NUMBER NOT NULL,
       Product_germplasm_id NUMBER NULL,
       Country_id           NUMBER NULL,
       Brand_id             NUMBER NULL,
       Product_stage_id     NUMBER NULL,
       Commercial_name      VARCHAR2(50) NULL,
       Pre_commercial_name  VARCHAR2(20) NULL,
       Relative_maturity    NUMBER(6,1) NULL,
       Commercial_maturity  NUMBER(6,1) NULL,
       Is_product_stage_active VARCHAR2(1) NULL
                                   CONSTRAINT Trueorfalse207
                                          CHECK (Is_product_stage_active IN ('T', 'F')),
       Product_status       VARCHAR2(50) NULL
                                   CONSTRAINT APRstatus58
                                          CHECK (Product_status IN ('A', 'P', 'R')),
       Product_id           NUMBER NULL,
       Process_id           NUMBER NULL,
       User_id              NUMBER NULL,
       Entry_date           DATE NULL,
       CONSTRAINT PRODUCT_TRANS_PK 
              PRIMARY KEY (Product_trans_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT PRODUCT_TRANS_AK1
       UNIQUE (
              Product_germplasm_id,
              Country_id,
              Brand_id,
              Product_stage_id,
              Entry_date
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
);

CREATE UNIQUE INDEX PRODUCT_TRANS_PK ON PRODUCT_TRANS
(
       Product_trans_id               ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX PRODUCT_TRANS_IDX1 ON PRODUCT_TRANS
(
       Process_id                     ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX PRODUCT_TRANS_IDX2 ON PRODUCT_TRANS
(
       Product_id                     ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX PRODUCT_TRANS_IDX3 ON PRODUCT_TRANS
(
       Country_id                     ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX PRODUCT_TRANS_IDX4 ON PRODUCT_TRANS
(
       Product_germplasm_id           ASC
)
    	 TABLESPACE LEXICON_INDEX
;


CREATE TABLE RESOURCE_LOCK (
       Resource_lock_id     NUMBER NOT NULL,
       Resource_name        VARCHAR2(256) NOT NULL,
       User_id              NUMBER NOT NULL,
       Entry_date           DATE NOT NULL,
       CONSTRAINT RESOURCE_LOCK_PK 
              PRIMARY KEY (Resource_lock_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT RESOURCE_LOCK_AK1
       UNIQUE (
              Resource_name
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
);

CREATE UNIQUE INDEX RESOURCE_LOCK_PK ON RESOURCE_LOCK
(
       Resource_lock_id               ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX RESOURCE_LOCK_IDX1 ON RESOURCE_LOCK
(
       User_id                        ASC
)
    	 TABLESPACE LEXICON_INDEX
;


CREATE TABLE TRAIT (
       Trait_id             NUMBER NOT NULL,
       Trait_name           VARCHAR2(50) NULL,
       Crop_id              NUMBER NULL,
       Trait_abbr           VARCHAR2(8) NULL,
       Is_Monsanto          VARCHAR2(1) NULL
                                   CONSTRAINT Trueorfalse208
                                          CHECK (Is_Monsanto IN ('T', 'F')),
       Is_transgenic        VARCHAR2(1) NULL
                                   CONSTRAINT Trueorfalse209
                                          CHECK (Is_transgenic IN ('T', 'F')),
       CONSTRAINT TRAIT_PK 
              PRIMARY KEY (Trait_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT TRAIT_AK1
       UNIQUE (
              Trait_name,
              Crop_id
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;

CREATE UNIQUE INDEX TRAIT_PK ON TRAIT
(
       Trait_id                       ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX TRAIT_IDX1 ON TRAIT
(
       Crop_id                        ASC
)
    	 TABLESPACE LEXICON_INDEX
;


CREATE TABLE TRANSGENIC_EVENT (
       Transgenic_event_id  NUMBER NOT NULL,
       Trait_id             NUMBER NULL,
       Midas_event_construct_id NUMBER NULL,
       CONSTRAINT TRANSGENIC_EVENT_PK 
              PRIMARY KEY (Transgenic_event_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT TRANSGENIC_TRAIT_AK1
       UNIQUE (
              Trait_id
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;

CREATE UNIQUE INDEX TRANSGENIC_EVENT_PK ON TRANSGENIC_EVENT
(
       Transgenic_event_id            ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX TRANSGENIC_EVENT_IDX1 ON TRANSGENIC_EVENT
(
       Trait_id                       ASC
)
    	 TABLESPACE LEXICON_INDEX
;


CREATE TABLE LEXICON.USER_PREFERENCE (
       USER_PREFERENCE_ID   NUMBER NOT NULL,
       USER_OBJECT_ID       NUMBER NOT NULL,
       DEFAULT_VALUE        VARCHAR2(100 BYTE) NULL,
       USER_PREFERENCE_DEFINITION_ID NUMBER NULL,
       CONSTRAINT USER_PREFERENCE_PK 
              PRIMARY KEY (USER_PREFERENCE_ID)
       USING INDEX
	 PCTFREE 10
  	 INITRANS 2
 	 MAXTRANS 255
 	 TABLESPACE LEXICON_INDEX
 	 STORAGE  (
		 INITIAL 65536
		 NEXT 65536
		 MINEXTENTS 1 
		 MAXEXTENTS 2147483645 
		 PCTINCREASE 0 
		 FREELISTS 1 
		 FREELIST GROUPS 1 
		 BUFFER_POOL DEFAULT 
 	)
	 LOGGING,
       CONSTRAINT USER_PREFERENCE_AK1
       UNIQUE (
              USER_OBJECT_ID,
              USER_PREFERENCE_DEFINITION_ID
       )
       USING INDEX
	 PCTFREE 10
  	 INITRANS 2
 	 MAXTRANS 255
 	 TABLESPACE LEXICON_INDEX
 	 STORAGE  (
		 INITIAL 65536
		 NEXT 65536
		 MINEXTENTS 1 
		 MAXEXTENTS 2147483645 
		 PCTINCREASE 0 
		 FREELISTS 1 
		 FREELIST GROUPS 1 
		 BUFFER_POOL DEFAULT 
 	)
	 LOGGING
)
	 PCTFREE 10
 	 PCTUSED 40
 	 INITRANS 1
 	 MAXTRANS 255
 	 TABLESPACE LEXICON_DATA
 	 STORAGE  (
		 INITIAL 65536
		 NEXT 65536
		 MINEXTENTS 1 
		 MAXEXTENTS 2147483645 
		 PCTINCREASE 0 
		 FREELISTS 1 
		 FREELIST GROUPS 1 
		 BUFFER_POOL DEFAULT 
 	)
	 LOGGING 
;

COMMENT ON TABLE LEXICON.USER_PREFERENCE IS 'This table stores the default value and/or a link to a list of values for a given user and user preference definition';
COMMENT ON COLUMN LEXICON.USER_PREFERENCE.USER_PREFERENCE_ID IS 'Primary Key';
COMMENT ON COLUMN LEXICON.USER_PREFERENCE.USER_OBJECT_ID IS 'Object ID used to identify a user in the security tables';
COMMENT ON COLUMN LEXICON.USER_PREFERENCE.DEFAULT_VALUE IS 'Default value (optional)';
COMMENT ON COLUMN LEXICON.USER_PREFERENCE.USER_PREFERENCE_DEFINITION_ID IS 'Primary Key';
CREATE UNIQUE INDEX LEXICON.USER_PREFERENCE_PK ON LEXICON.USER_PREFERENCE
(
       USER_PREFERENCE_ID             ASC
)
	 PCTFREE 10
  	 INITRANS 2
 	 MAXTRANS 255
 	 TABLESPACE LEXICON_INDEX
 	 STORAGE  (
		 INITIAL 65536
		 NEXT 65536
		 MINEXTENTS 1 
		 MAXEXTENTS 2147483645 
		 PCTINCREASE 0 
		 FREELISTS 1 
		 FREELIST GROUPS 1 
		 BUFFER_POOL DEFAULT 
 	)
	 LOGGING 
;

CREATE INDEX LEXICON.XIF1USER_PREFERENCE ON LEXICON.USER_PREFERENCE
(
       USER_PREFERENCE_DEFINITION_ID  ASC
);

CREATE SYNONYM USER_PREFERENCE FOR LEXICON.USER_PREFERENCE;


CREATE TABLE LEXICON.USER_PREFERENCE_DEFINITION (
       USER_PREFERENCE_DEFINITION_ID NUMBER NOT NULL,
       User_pref_name       VARCHAR2(50 BYTE) NOT NULL,
       METADATA             VARCHAR2(250 BYTE) NOT NULL,
       IS_MULTIVALUE        VARCHAR2(1 BYTE) DEFAULT 'T' NULL
                                   CONSTRAINT Trueorfalse210
                                          CHECK (IS_MULTIVALUE IN ('T', 'F')),
       CONSTRAINT USER_PREFERENCE_DEFINITION_PK 
              PRIMARY KEY (USER_PREFERENCE_DEFINITION_ID)
       USING INDEX
	 PCTFREE 10
  	 INITRANS 2
 	 MAXTRANS 255
 	 TABLESPACE LEXICON_INDEX
 	 STORAGE  (
		 INITIAL 65536
		 NEXT 65536
		 MINEXTENTS 1 
		 MAXEXTENTS 2147483645 
		 PCTINCREASE 0 
		 FREELISTS 1 
		 FREELIST GROUPS 1 
		 BUFFER_POOL DEFAULT 
 	)
	 LOGGING,
       CONSTRAINT USER_PREFERENCE_DEFINITION_AK`
       UNIQUE (
              User_pref_name
       )
       USING INDEX
	 PCTFREE 10
  	 INITRANS 2
 	 MAXTRANS 255
 	 TABLESPACE LEXICON_INDEX
 	 STORAGE  (
		 INITIAL 65536
		 NEXT 65536
		 MINEXTENTS 1 
		 MAXEXTENTS 2147483645 
		 PCTINCREASE 0 
		 FREELISTS 1 
		 FREELIST GROUPS 1 
		 BUFFER_POOL DEFAULT 
 	)
	 LOGGING
)
	 PCTFREE 10
 	 PCTUSED 40
 	 INITRANS 1
 	 MAXTRANS 255
 	 TABLESPACE LEXICON_DATA
 	 STORAGE  (
		 INITIAL 65536
		 NEXT 65536
		 MINEXTENTS 1 
		 MAXEXTENTS 2147483645 
		 PCTINCREASE 0 
		 FREELISTS 1 
		 FREELIST GROUPS 1 
		 BUFFER_POOL DEFAULT 
 	)
	 LOGGING 
;

COMMENT ON TABLE LEXICON.USER_PREFERENCE_DEFINITION IS 'This table stores all of the different Types that may be used in User Preferences';
COMMENT ON COLUMN LEXICON.USER_PREFERENCE_DEFINITION.USER_PREFERENCE_DEFINITION_ID IS 'Primary Key';
COMMENT ON COLUMN LEXICON.USER_PREFERENCE_DEFINITION.User_pref_name IS 'User identifiable name (unique)';
COMMENT ON COLUMN LEXICON.USER_PREFERENCE_DEFINITION.METADATA IS 'Metadata information used to retrieve possible values';
COMMENT ON COLUMN LEXICON.USER_PREFERENCE_DEFINITION.IS_MULTIVALUE IS 'Flag for determing if multiple values are allowed';
CREATE UNIQUE INDEX LEXICON.USER_PREFERENCE_DEFINITION_PK ON LEXICON.USER_PREFERENCE_DEFINITION
(
       USER_PREFERENCE_DEFINITION_ID  ASC
)
	 PCTFREE 10
  	 INITRANS 2
 	 MAXTRANS 255
 	 TABLESPACE LEXICON_INDEX
 	 STORAGE  (
		 INITIAL 65536
		 NEXT 65536
		 MINEXTENTS 1 
		 MAXEXTENTS 2147483645 
		 PCTINCREASE 0 
		 FREELISTS 1 
		 FREELIST GROUPS 1 
		 BUFFER_POOL DEFAULT 
 	)
	 LOGGING 
;


CREATE TABLE LEXICON.USER_PREFERENCE_VALUE (
       USER_PREFERENCE_VALUE_ID NUMBER NOT NULL,
       USER_PREFERENCE_ID   NUMBER NOT NULL,
       VALUE                VARCHAR2(100 BYTE) NOT NULL,
       CONSTRAINT USER_PREFERENCE_VALUE_PK 
              PRIMARY KEY (USER_PREFERENCE_VALUE_ID)
       USING INDEX
	 PCTFREE 10
  	 INITRANS 2
 	 MAXTRANS 255
 	 TABLESPACE LEXICON_INDEX
 	 STORAGE  (
		 INITIAL 65536
		 NEXT 65536
		 MINEXTENTS 1 
		 MAXEXTENTS 2147483645 
		 PCTINCREASE 0 
		 FREELISTS 1 
		 FREELIST GROUPS 1 
		 BUFFER_POOL DEFAULT 
 	)
	 LOGGING,
       CONSTRAINT USER_PREFERENCE_VALUE_AK1
       UNIQUE (
              USER_PREFERENCE_ID,
              VALUE
       )
       USING INDEX
	 PCTFREE 10
  	 INITRANS 2
 	 MAXTRANS 255
 	 TABLESPACE LEXICON_INDEX
 	 STORAGE  (
		 INITIAL 65536
		 NEXT 65536
		 MINEXTENTS 1 
		 MAXEXTENTS 2147483645 
		 PCTINCREASE 0 
		 FREELISTS 1 
		 FREELIST GROUPS 1 
		 BUFFER_POOL DEFAULT 
 	)
	 LOGGING
)
	 PCTFREE 10
 	 PCTUSED 40
 	 INITRANS 1
 	 MAXTRANS 255
 	 TABLESPACE LEXICON_DATA
 	 STORAGE  (
		 INITIAL 65536
		 NEXT 65536
		 MINEXTENTS 1 
		 MAXEXTENTS 2147483645 
		 PCTINCREASE 0 
		 FREELISTS 1 
		 FREELIST GROUPS 1 
		 BUFFER_POOL DEFAULT 
 	)
	 LOGGING 
;

COMMENT ON TABLE LEXICON.USER_PREFERENCE_VALUE IS 'This table stores values for a given user preference entry, this table is used to allow multiple values for a given user preference';
COMMENT ON COLUMN LEXICON.USER_PREFERENCE_VALUE.USER_PREFERENCE_VALUE_ID IS 'Primary Key';
COMMENT ON COLUMN LEXICON.USER_PREFERENCE_VALUE.USER_PREFERENCE_ID IS 'Foreign key to the user preference this value is a member of';
COMMENT ON COLUMN LEXICON.USER_PREFERENCE_VALUE.VALUE IS 'An individual value of a list entry';
CREATE UNIQUE INDEX LEXICON.USER_PREFERENCE_VALUE_PK ON LEXICON.USER_PREFERENCE_VALUE
(
       USER_PREFERENCE_VALUE_ID       ASC
)
	 PCTFREE 10
  	 INITRANS 2
 	 MAXTRANS 255
 	 TABLESPACE LEXICON_INDEX
 	 STORAGE  (
		 INITIAL 65536
		 NEXT 65536
		 MINEXTENTS 1 
		 MAXEXTENTS 2147483645 
		 PCTINCREASE 0 
		 FREELISTS 1 
		 FREELIST GROUPS 1 
		 BUFFER_POOL DEFAULT 
 	)
	 LOGGING 
;


ALTER TABLE BRAND
       ADD  ( CONSTRAINT FK_BRAND_COMPANY_COMPANYID
              FOREIGN KEY (Company_id)
                             REFERENCES COMPANY ) ;


ALTER TABLE COMP_PROD_BATCH_ROW
       ADD  ( CONSTRAINT FK_COMPPRODROW_COMPSTAT_STATUS
              FOREIGN KEY (Comp_prod_batch_row_status)
                             REFERENCES COMP_PROD_BATCH_ROW_STATUS ) ;


ALTER TABLE COMP_PROD_BATCH_ROW
       ADD  ( CONSTRAINT FK_COMPPRODBROW_COMPPROD_ROWID
              FOREIGN KEY (Comp_prod_batch_id)
                             REFERENCES COMP_PROD_BATCH ) ;


ALTER TABLE COMP_PROD_COUNTRY
       ADD  ( CONSTRAINT FK_COMPPRDCNTRY_CNTRY_CNTRYID
              FOREIGN KEY (Country_id)
                             REFERENCES COUNTRY ) ;


ALTER TABLE COMP_PROD_COUNTRY
       ADD  ( CONSTRAINT FK_COMPPCNTRY_COMPPROD_CPID
              FOREIGN KEY (Comp_prod_id)
                             REFERENCES COMP_PRODUCT ) ;


ALTER TABLE COMP_PROD_EQUIV
       ADD  ( CONSTRAINT FK_COMPPRDEQV_COMPPROD_COMPPID
              FOREIGN KEY (Comp_prod_id)
                             REFERENCES COMP_PRODUCT ) ;


ALTER TABLE COMP_PROD_TRAIT
       ADD  ( CONSTRAINT FK_COMPPTRAIT_COMPPRD_CPTID
              FOREIGN KEY (Comp_prod_id)
                             REFERENCES COMP_PRODUCT ) ;


ALTER TABLE COMP_PROD_TRAIT
       ADD  ( CONSTRAINT FK_COMPPRODTRAIT_TRAIT_TRAITID
              FOREIGN KEY (Trait_id)
                             REFERENCES TRAIT ) ;


ALTER TABLE COMP_PRODUCT
       ADD  ( CONSTRAINT FK_COMPPRD_COMPPEQV_COMPPRODID
              FOREIGN KEY (Comp_prod_equiv_id)
                             REFERENCES COMP_PROD_EQUIV ) ;


ALTER TABLE COMP_PRODUCT
       ADD  ( CONSTRAINT FK_COMPPRODUCT_CROP_CROPID
              FOREIGN KEY (Crop_id)
                             REFERENCES CROP ) ;


ALTER TABLE COMP_PRODUCT
       ADD  ( CONSTRAINT FK_COMPPROD_PROCESS_PROCESSID
              FOREIGN KEY (Process_id)
                             REFERENCES PROCESS ) ;


ALTER TABLE COMP_PRODUCT
       ADD  ( CONSTRAINT FK_COMPPROD_BRAND_BRANDID
              FOREIGN KEY (Brand_id)
                             REFERENCES BRAND ) ;


ALTER TABLE EQUIV_GERMPLASM_MAP
       ADD  ( CONSTRAINT FK_EQGMAP_PROCESS_PROCESSID
              FOREIGN KEY (Process_id)
                             REFERENCES PROCESS ) ;


ALTER TABLE EQUIV_GERMPLASM_MAP
       ADD  ( CONSTRAINT FK_EQGMAP_EQTYPE_EQUIVTYPEID
              FOREIGN KEY (Equiv_type_id)
                             REFERENCES EQUIV_TYPE ) ;


ALTER TABLE EQUIV_GERMPLASM_MAP
       ADD  ( CONSTRAINT FK_EQGMAP_PRODGERM_PRODGERMID
              FOREIGN KEY (Primary_product_germplasm_id)
                             REFERENCES PRODUCT_GERMPLASM ) ;


ALTER TABLE EQUIV_GERMPLASM_MAP
       ADD  ( CONSTRAINT FK_EQGMAP_COUNTRY_COUNTRYID
              FOREIGN KEY (Country_id)
                             REFERENCES COUNTRY ) ;


ALTER TABLE EQUIV_GERMPLASM_MAP
       ADD  ( CONSTRAINT FK_EQGMAP_PRODGERM_PRODGERMID2
              FOREIGN KEY (Product_germplasm_id)
                             REFERENCES PRODUCT_GERMPLASM ) ;


ALTER TABLE EQUIV_GERMPLASM_MAP_TRANS
       ADD  ( CONSTRAINT FK_EQUVMAPTRNS_EQVGRMMAP_EGMID
              FOREIGN KEY (Equiv_germplasm_map_id)
                             REFERENCES EQUIV_GERMPLASM_MAP ) ;


ALTER TABLE EQUIV_GERMPLASM_MAP_TRANS
       ADD  ( CONSTRAINT FK_EQGPMAPTRNS_PRDGRM_PRDGRMID
              FOREIGN KEY (Primary_product_germplasm_id)
                             REFERENCES PRODUCT_GERMPLASM ) ;


ALTER TABLE EQUIV_GERMPLASM_MAP_TRANS
       ADD  ( CONSTRAINT FK_EQGPMAPTRNS_PRDGRM_PRDGRMID
              FOREIGN KEY (Product_germplasm_id)
                             REFERENCES PRODUCT_GERMPLASM ) ;


ALTER TABLE EQUIV_GERMPLASM_MAP_TRANS
       ADD  ( CONSTRAINT FK_EQGPMAPTRANS_PROC_PROCID
              FOREIGN KEY (Process_id)
                             REFERENCES PROCESS ) ;


ALTER TABLE EQUIV_GERMPLASM_MAP_TRANS
       ADD  ( CONSTRAINT FK_EQGPMAPTRANS_CNTRY_CNTRYID
              FOREIGN KEY (Country_id)
                             REFERENCES COUNTRY ) ;


ALTER TABLE INTELLECTUAL_PROPERTY
       ADD  ( CONSTRAINT FK_INTELPROP_PRODGERM_PRDGRMID
              FOREIGN KEY (Product_germplasm_id)
                             REFERENCES PRODUCT_GERMPLASM ) ;


ALTER TABLE INTELLECTUAL_PROPERTY
       ADD  ( CONSTRAINT FK_INTELPROP_COUNTRY_COUNTRYID
              FOREIGN KEY (Country_id)
                             REFERENCES COUNTRY ) ;


ALTER TABLE MIDAS_GERMPLASM
       ADD  ( CONSTRAINT FK_MIDGERM_PRODGERM_PRODGERMID
              FOREIGN KEY (Product_germplasm_id)
                             REFERENCES PRODUCT_GERMPLASM ) ;


ALTER TABLE PRODUCT
       ADD  ( CONSTRAINT FK_PRODUCT_PROCESS_PROCESSID
              FOREIGN KEY (Process_id)
                             REFERENCES PROCESS ) ;


ALTER TABLE PRODUCT
       ADD  ( CONSTRAINT FK_PRODUCT_PRODGERM_PRODGERMID
              FOREIGN KEY (Product_germplasm_id)
                             REFERENCES PRODUCT_GERMPLASM ) ;


ALTER TABLE PRODUCT
       ADD  ( CONSTRAINT FK_PRODUCT_COUNTRY_COUNTRYID
              FOREIGN KEY (Country_id)
                             REFERENCES COUNTRY ) ;


ALTER TABLE PRODUCT
       ADD  ( CONSTRAINT FK_PRODUCT_PRODSTG_PRODSTGID
              FOREIGN KEY (Product_stage_id)
                             REFERENCES PRODUCT_STAGE ) ;


ALTER TABLE PRODUCT
       ADD  ( CONSTRAINT FK_PRODUCT_BRAND_BRANDID
              FOREIGN KEY (Brand_id)
                             REFERENCES BRAND ) ;


ALTER TABLE PRODUCT_GERMPLASM
       ADD  ( CONSTRAINT FK_PRODGERM_PROCESS_PROCESSID
              FOREIGN KEY (Process_id)
                             REFERENCES PROCESS ) ;


ALTER TABLE PRODUCT_GERMPLASM
       ADD  ( CONSTRAINT FK_PRODGERM_CROP_CROPID
              FOREIGN KEY (Crop_id)
                             REFERENCES CROP ) ;


ALTER TABLE PRODUCT_GERMPLASM_TRANS
       ADD  ( CONSTRAINT FK_PRODGERMTRANS_CROP_CROPID
              FOREIGN KEY (Crop_id)
                             REFERENCES CROP ) ;


ALTER TABLE PRODUCT_GERMPLASM_TRANS
       ADD  ( CONSTRAINT FK_PRODGERMTRANS_PROC_PROCID
              FOREIGN KEY (Process_id)
                             REFERENCES PROCESS ) ;


ALTER TABLE PRODUCT_GERMPLASM_TRANS
       ADD  ( CONSTRAINT FK_PRODGERMTRANS_PRODGERM_PGID
              FOREIGN KEY (Product_germplasm_id)
                             REFERENCES PRODUCT_GERMPLASM ) ;


ALTER TABLE PRODUCT_TRAIT
       ADD  ( CONSTRAINT FK_PRODTRAIT_PRODUCT_PRODUCTID
              FOREIGN KEY (Product_id)
                             REFERENCES PRODUCT ) ;


ALTER TABLE PRODUCT_TRAIT
       ADD  ( CONSTRAINT FK_PRODTRAIT_TRAIT_TRAITID
              FOREIGN KEY (Trait_id)
                             REFERENCES TRAIT ) ;


ALTER TABLE PRODUCT_TRANS
       ADD  ( CONSTRAINT FK_PRODTRANS_PRODGM_PRODGMID
              FOREIGN KEY (Product_germplasm_id)
                             REFERENCES PRODUCT_GERMPLASM ) ;


ALTER TABLE PRODUCT_TRANS
       ADD  ( CONSTRAINT FK_PRODTRANS_COUNTRY_COUNTRYID
              FOREIGN KEY (Country_id)
                             REFERENCES COUNTRY ) ;


ALTER TABLE PRODUCT_TRANS
       ADD  ( CONSTRAINT FK_PRODTRANS_PRODUCT_PRODUCTID
              FOREIGN KEY (Product_id)
                             REFERENCES PRODUCT ) ;


ALTER TABLE PRODUCT_TRANS
       ADD  ( CONSTRAINT FK_PRODTRANS_PROCESS_PROCESSID
              FOREIGN KEY (Process_id)
                             REFERENCES PROCESS ) ;


ALTER TABLE TRAIT
       ADD  ( CONSTRAINT FK_TRAIT_CROP_CROPID
              FOREIGN KEY (Crop_id)
                             REFERENCES CROP ) ;


ALTER TABLE TRANSGENIC_EVENT
       ADD  ( CONSTRAINT FK_TRANEVENT_TRAIT_TRAITID
              FOREIGN KEY (Trait_id)
                             REFERENCES TRAIT ) ;


ALTER TABLE LEXICON.USER_PREFERENCE
       ADD  ( CONSTRAINT FK_USRPRF_USRPRFDEF_USRPRFDFID
              FOREIGN KEY (USER_PREFERENCE_DEFINITION_ID)
                             REFERENCES LEXICON.USER_PREFERENCE_DEFINITION ) ;


ALTER TABLE LEXICON.USER_PREFERENCE_VALUE
       ADD  ( CONSTRAINT FK_USRPRFVAL_USRPRF_USRPRFID
              FOREIGN KEY (USER_PREFERENCE_ID)
                             REFERENCES LEXICON.USER_PREFERENCE ) ;



