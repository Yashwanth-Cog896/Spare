CREATE SEQUENCE Product_germplasm_id_seq 
INCREMENT BY 1 
START WITH 1000 
NOMAXVALUE 
NOMINVALUE 
CACHE 30 
NOCYCLE
NOORDER
;

CREATE SEQUENCE Product_id_seq 
INCREMENT BY 1 
START WITH 1000 
NOMAXVALUE 
NOMINVALUE 
CACHE 30 
NOCYCLE
NOORDER
;


CREATE SEQUENCE Product_trait_id_seq 
INCREMENT BY 1 
START WITH 1000 
NOMAXVALUE 
NOMINVALUE 
CACHE 30 
NOCYCLE
NOORDER
;


CREATE SEQUENCE Transgenic_event_id_seq 
INCREMENT BY 1 
START WITH 1000 
NOMAXVALUE 
NOMINVALUE 
CACHE 30 
NOCYCLE
NOORDER
;


CREATE SEQUENCE User_preference_id_seq 
INCREMENT BY 1 
START WITH 1000 
NOMAXVALUE 
NOMINVALUE 
CACHE 30 
NOCYCLE
NOORDER
;


CREATE SEQUENCE User_preference_value_id_seq 
INCREMENT BY 1 
START WITH 1000 
NOMAXVALUE 
NOMINVALUE 
CACHE 30 
NOCYCLE
NOORDER
;


CREATE TABLE EQUIV_GERMPLASM_MAP (
       Country_id           NUMBER NOT NULL,
       Primary_product_germplasm_id NUMBER NOT NULL,
       Product_germplasm_id NUMBER NOT NULL,
       Reason               VARCHAR2(50) NULL,
       Equiv_germplasm_map_status VARCHAR2(1) NULL
                                   CONSTRAINT APRstatus17
                                          CHECK (Equiv_germplasm_map_status IN ('A', 'P', 'R')),
       Equiv_type_id        NUMBER NULL,
       Process_id           NUMBER NULL,
       User_id              NUMBER NULL,
       Entry_date           DATE NULL,
       CONSTRAINT EQUIV_GERMPLASM_MAP_PK 
              PRIMARY KEY (Country_id, Primary_product_germplasm_id, 
              Product_germplasm_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;


CREATE INDEX EQUIV_GERMPLASM_MAP_IDX1 ON EQUIV_GERMPLASM_MAP
(
       Product_germplasm_id           ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX EQUIV_GERMPLASM_MAP_IDX2 ON EQUIV_GERMPLASM_MAP
(
       Country_id                     ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX EQUIV_GERMPLASM_MAP_IDX3 ON EQUIV_GERMPLASM_MAP
(
       Primary_product_germplasm_id   ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX EQUIV_GERMPLASM_MAP_IDX4 ON EQUIV_GERMPLASM_MAP
(
       Equiv_type_id                  ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX EQUIV_GERMPLASM_MAP_IDX5 ON EQUIV_GERMPLASM_MAP
(
       Process_id                     ASC
)
    	 TABLESPACE LEXICON_INDEX
;


CREATE TABLE EQUIV_TYPE (
       Equiv_type_id        NUMBER NOT NULL,
       Equiv_type_name      VARCHAR2(50) NULL,
       CONSTRAINT EQUIV_TYPE_PK 
              PRIMARY KEY (Equiv_type_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT EQUIVALENT_TYPE_IDX1
       UNIQUE (
              Equiv_type_name
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;




CREATE TABLE EQUIV_GERMPLASM_MAP_HISTORY (
       Country_id           NUMBER NOT NULL,
       Primary_product_germplasm_id NUMBER NOT NULL,
       Product_germplasm_id NUMBER NOT NULL,
       Entry_date           DATE NOT NULL,
       Reason               VARCHAR2(50) NULL,
       Equiv_germplasm_map_status VARCHAR2(1) NULL,
       Process_id           NUMBER NULL,
       Equiv_type_id        NUMBER NULL,
       CONSTRAINT EQUIV_GERMPLASM_MAP_HISTORY_PK 
              PRIMARY KEY (Country_id, Primary_product_germplasm_id, 
              Product_germplasm_id, Entry_date)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;



CREATE TABLE LEXICON.USER_PREFERENCE_VALUE (
       USER_PREFERENCE_VALUE_ID NUMBER NOT NULL,
       USER_PREFERENCE_ID   NUMBER NOT NULL,
       VALUE                VARCHAR2(100 BYTE) NOT NULL,
       CONSTRAINT USER_PREFERENCE_VALUE_PK 
              PRIMARY KEY (USER_PREFERENCE_VALUE_ID)
       USING INDEX
	 PCTFREE 10
  	 INITRANS 2
 	 MAXTRANS 255
 	 TABLESPACE LEXICON_INDEX
 	 STORAGE  (
		 INITIAL 65536
		 NEXT 65536
		 MINEXTENTS 1 
		 MAXEXTENTS 2147483645 
		 PCTINCREASE 0 
		 FREELISTS 1 
		 FREELIST GROUPS 1 
		 BUFFER_POOL DEFAULT 
 	)
	 LOGGING,
       CONSTRAINT USER_PREFERENCE_VALUE_AK1
       UNIQUE (
              USER_PREFERENCE_ID,
              VALUE
       )
       USING INDEX
	 PCTFREE 10
  	 INITRANS 2
 	 MAXTRANS 255
 	 TABLESPACE LEXICON_INDEX
 	 STORAGE  (
		 INITIAL 65536
		 NEXT 65536
		 MINEXTENTS 1 
		 MAXEXTENTS 2147483645 
		 PCTINCREASE 0 
		 FREELISTS 1 
		 FREELIST GROUPS 1 
		 BUFFER_POOL DEFAULT 
 	)
	 LOGGING
)
	 PCTFREE 10
 	 PCTUSED 40
 	 INITRANS 1
 	 MAXTRANS 255
 	 TABLESPACE LEXICON_DATA
 	 STORAGE  (
		 INITIAL 65536
		 NEXT 65536
		 MINEXTENTS 1 
		 MAXEXTENTS 2147483645 
		 PCTINCREASE 0 
		 FREELISTS 1 
		 FREELIST GROUPS 1 
		 BUFFER_POOL DEFAULT 
 	)
	 LOGGING 
;




CREATE TABLE LEXICON.USER_PREFERENCE (
       USER_PREFERENCE_ID   NUMBER NOT NULL,
       USER_OBJECT_ID       NUMBER NOT NULL,
       USER_PREFERENCE_DEFINITION_ID NUMBER NOT NULL,
       DEFAULT_VALUE        VARCHAR2(100 BYTE) NULL,
       CONSTRAINT USER_PREFERENCE_PK
              PRIMARY KEY (USER_PREFERENCE_ID)
       USING INDEX
	 PCTFREE 10
  	 INITRANS 2
 	 MAXTRANS 255
 	 TABLESPACE LEXICON_INDEX
 	 STORAGE  (
		 INITIAL 65536
		 NEXT 65536
		 MINEXTENTS 1 
		 MAXEXTENTS 2147483645 
		 PCTINCREASE 0 
		 FREELISTS 1 
		 FREELIST GROUPS 1 
		 BUFFER_POOL DEFAULT 
 	)
	 LOGGING,
       CONSTRAINT USER_PREFERENCE_AK1
       UNIQUE (
              USER_OBJECT_ID,
              USER_PREFERENCE_DEFINITION_ID
       )
       USING INDEX
	 PCTFREE 10
  	 INITRANS 2
 	 MAXTRANS 255
 	 TABLESPACE LEXICON_INDEX
 	 STORAGE  (
		 INITIAL 65536
		 NEXT 65536
		 MINEXTENTS 1 
		 MAXEXTENTS 2147483645 
		 PCTINCREASE 0 
		 FREELISTS 1 
		 FREELIST GROUPS 1 
		 BUFFER_POOL DEFAULT 
 	)
	 LOGGING
)
	 PCTFREE 10
 	 PCTUSED 40
 	 INITRANS 1
 	 MAXTRANS 255
 	 TABLESPACE LEXICON_DATA
 	 STORAGE  (
		 INITIAL 65536
		 NEXT 65536
		 MINEXTENTS 1 
		 MAXEXTENTS 2147483645 
		 PCTINCREASE 0 
		 FREELISTS 1 
		 FREELIST GROUPS 1 
		 BUFFER_POOL DEFAULT 
 	)
	 LOGGING 
;


CREATE INDEX LEXICON.XIF1USER_PREFERENCE ON LEXICON.USER_PREFERENCE
(
       USER_PREFERENCE_DEFINITION_ID  ASC
);


CREATE TABLE LEXICON.USER_PREFERENCE_DEFINITION (
       USER_PREFERENCE_DEFINITION_ID NUMBER NOT NULL,
       User_pref_name       VARCHAR2(50 BYTE) NOT NULL,
       METADATA             VARCHAR2(250 BYTE) NOT NULL,
       IS_MULTIVALUE        VARCHAR2(1 BYTE) DEFAULT 'y' NULL
                                   CONSTRAINT Trueorfalse65
                                          CHECK (IS_MULTIVALUE IN ('y', 'n')),
       CONSTRAINT USER_PREFERENCE_DEFINITION_PK 
              PRIMARY KEY (USER_PREFERENCE_DEFINITION_ID)
       USING INDEX
	 PCTFREE 10
  	 INITRANS 2
 	 MAXTRANS 255
 	 TABLESPACE LEXICON_INDEX
 	 STORAGE  (
		 INITIAL 65536
		 NEXT 65536
		 MINEXTENTS 1 
		 MAXEXTENTS 2147483645 
		 PCTINCREASE 0 
		 FREELISTS 1 
		 FREELIST GROUPS 1 
		 BUFFER_POOL DEFAULT 
 	)
	 LOGGING,
       CONSTRAINT USER_PREFERENCE_DEFINITION_AK
       UNIQUE (
              User_pref_name
       )
       USING INDEX
	 PCTFREE 10
  	 INITRANS 2
 	 MAXTRANS 255
 	 TABLESPACE LEXICON_INDEX
 	 STORAGE  (
		 INITIAL 65536
		 NEXT 65536
		 MINEXTENTS 1 
		 MAXEXTENTS 2147483645 
		 PCTINCREASE 0 
		 FREELISTS 1 
		 FREELIST GROUPS 1 
		 BUFFER_POOL DEFAULT 
 	)
	 LOGGING
)
	 PCTFREE 10
 	 PCTUSED 40
 	 INITRANS 1
 	 MAXTRANS 255
 	 TABLESPACE LEXICON_DATA
 	 STORAGE  (
		 INITIAL 65536
		 NEXT 65536
		 MINEXTENTS 1 
		 MAXEXTENTS 2147483645 
		 PCTINCREASE 0 
		 FREELISTS 1 
		 FREELIST GROUPS 1 
		 BUFFER_POOL DEFAULT 
 	)
	 LOGGING 
;


CREATE TABLE MIDAS_GERMPLASM (
       Midas_germplasm_id   NUMBER NOT NULL,
       Product_germplasm_id NUMBER NULL,
       CONSTRAINT MIDAS_GERMPLASM_PK 
              PRIMARY KEY (Midas_germplasm_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT MIDAS_GERMPLASM_AK1
       UNIQUE (
              Midas_germplasm_id,
              Product_germplasm_id
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;


CREATE INDEX MIDAS_GERMPLASM_IDX1 ON MIDAS_GERMPLASM
(
       Product_germplasm_id           ASC
)
    	 TABLESPACE LEXICON_INDEX
;


CREATE TABLE TRANSGENIC_EVENT (
       Transgenic_event_id  NUMBER NOT NULL,
       Trait_id             NUMBER NULL,
       Midas_event_construct_id NUMBER NULL,
       CONSTRAINT TRANSGENIC_EVENT_PK 
              PRIMARY KEY (Transgenic_event_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT TRANSGENIC_TRAIT_AK1
       UNIQUE (
              Trait_id
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;


CREATE INDEX TRANSGENIC_EVENT_IDX1 ON TRANSGENIC_EVENT
(
       Trait_id                       ASC
)
    	 TABLESPACE LEXICON_INDEX
;


CREATE TABLE PRODUCT_TRAIT (
       Product_trait_id     NUMBER NOT NULL,
       Trait_id             NUMBER NULL,
       Product_id           NUMBER NULL,
       CONSTRAINT PRODUCT_TRAIT_PK 
              PRIMARY KEY (Product_trait_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT PRODUCT_TRAIT_AK1
       UNIQUE (
              Trait_id,
              Product_id
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;


CREATE INDEX PRODUCT_TRAIT_IDX1 ON PRODUCT_TRAIT
(
       Trait_id                       ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX PRODUCT_TRAIT_IDX2 ON PRODUCT_TRAIT
(
       Product_id                     ASC
)
    	 TABLESPACE LEXICON_INDEX
;


CREATE TABLE PRODUCT (
       Product_id           NUMBER NOT NULL,
       Product_germplasm_id NUMBER NULL,
       Country_id           NUMBER NULL,
       Brand_id             NUMBER NULL,
       Product_stage_id     NUMBER NULL,
       Commercial_name      VARCHAR2(50) NULL,
       Pre_commercial_name  VARCHAR2(50) NULL,
       Relative_maturity    NUMBER(6,1) NULL,
       Commercial_maturity  NUMBER(6,1) NULL,
       Product_status       VARCHAR2(50) NULL
                                   CONSTRAINT APRstatus18
                                          CHECK (Product_status IN ('A', 'P', 'R')),
       Is_product_stage_active VARCHAR2(1) NULL
                                   CONSTRAINT Trueorfalse66
                                          CHECK (Is_product_stage_active IN ('y', 'n')),
       User_id              NUMBER NULL,
       Entry_date           DATE NULL,
       Process_id           NUMBER NULL,
       CONSTRAINT PRODUCT_PK 
              PRIMARY KEY (Product_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT PRODUCT_AK1
       UNIQUE (
              Product_germplasm_id,
              Country_id,
              Brand_id,
              Product_stage_id
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;


CREATE INDEX PRODUCT_IDX1 ON PRODUCT
(
       Brand_id                       ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX PRODUCT_IDX2 ON PRODUCT
(
       Product_stage_id               ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX PRODUCT_IDX3 ON PRODUCT
(
       Country_id                     ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX PRODUCT_IDX4 ON PRODUCT
(
       Product_germplasm_id           ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX PRODUCT_IDX5 ON PRODUCT
(
       Process_id                     ASC
)
    	 TABLESPACE LEXICON_INDEX
;


CREATE TABLE PRODUCT_STAGE (
       Product_stage_id     NUMBER NOT NULL,
       Product_stage_name   VARCHAR2(50) NULL,
       Product_stage_abbr   VARCHAR2(20) NULL,
       Product_stage_type   VARCHAR2(20) NULL,
       CONSTRAINT PRODUCT_STAGE_PK 
              PRIMARY KEY (Product_stage_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT PRODUCT_STAGE_AK1
       UNIQUE (
              Product_stage_name
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;


CREATE TABLE BRAND (
       Brand_id             NUMBER NOT NULL,
       Brand_name           VARCHAR2(50) NULL,
       Is_Monsanto_com_brand VARCHAR2(1) NULL
                                   CONSTRAINT Trueorfalse67
                                          CHECK (Is_Monsanto_com_brand IN ('y', 'n')),
       Is_global_brand      VARCHAR2(1) NULL
                                   CONSTRAINT Trueorfalse68
                                          CHECK (Is_global_brand IN ('y', 'n')),
       Is_competitor_brand  VARCHAR2(1) NULL
                                   CONSTRAINT Trueorfalse69
                                          CHECK (Is_competitor_brand IN ('y', 'n')),
       Company_id           NUMBER NULL,
       CONSTRAINT BRAND_PK 
              PRIMARY KEY (Brand_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT BRAND_AK1
       UNIQUE (
              Brand_name
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;


CREATE INDEX BRAND_IDX1 ON BRAND
(
       Company_id                     ASC
)
    	 TABLESPACE LEXICON_INDEX
;


CREATE TABLE COMPANY (
       Company_id           NUMBER NOT NULL,
       Company_name         VARCHAR2(50) NULL,
       CONSTRAINT COMPANY_PK 
              PRIMARY KEY (Company_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT COMPANY_AK1
       UNIQUE (
              Company_name
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;



CREATE TABLE INTELLECTUAL_PROPERTY (
       Ip_id                NUMBER NOT NULL,
       Country_id           NUMBER NULL,
       Patent_filing_date   DATE NULL,
       Provisional_patent_filing_date DATE NULL,
       Plantbreeder_right_filing_date DATE NULL,
       US_patent_office_number NUMBER NULL,
       Patent_status        VARCHAR2(50) NULL,
       Product_germplasm_id NUMBER NULL,
       CONSTRAINT INTELLECTUAL_PROPERTY_PK 
              PRIMARY KEY (Ip_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;


CREATE INDEX INTELLECTUAL_PROPERTY_IDX1 ON INTELLECTUAL_PROPERTY
(
       Product_germplasm_id           ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX INTELLECTUAL_PROPERTY_IDX2 ON INTELLECTUAL_PROPERTY
(
       Country_id                     ASC
)
    	 TABLESPACE LEXICON_INDEX
;


CREATE TABLE TRAIT (
       Trait_id             NUMBER NOT NULL,
       Trait_name           VARCHAR2(50) NULL,
       Crop_id              NUMBER NULL,
       Trait_abbr           VARCHAR2(8) NULL,
       Is_Monsanto          VARCHAR2(1) NULL
                                   CONSTRAINT Trueorfalse70
                                          CHECK (Is_Monsanto IN ('y', 'n')),
       Is_transgenic        VARCHAR2(1) NULL
                                   CONSTRAINT Trueorfalse71
                                          CHECK (Is_transgenic IN ('y', 'n')),
       CONSTRAINT TRAIT_PK 
              PRIMARY KEY (Trait_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT TRAIT_AK1
       UNIQUE (
              Trait_name,
              Crop_id
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;


CREATE INDEX TRAIT_IDX1 ON TRAIT
(
       Crop_id                        ASC
)
    	 TABLESPACE LEXICON_INDEX
;


CREATE TABLE PRODUCT_GERMPLASM (
       Product_germplasm_id NUMBER NOT NULL,
       Midas_origin         VARCHAR2(2000) NULL,
       Midas_line_code      VARCHAR2(50) NULL,
       Crop_id              NUMBER NULL,
       SAP_origin           VARCHAR2(50) NULL,
       USA_variety_name     VARCHAR2(50) NULL,
       Is_active            VARCHAR2(1) NULL
                                   CONSTRAINT Trueorfalse72
                                          CHECK (Is_active IN ('y', 'n')),
       Process_id           NUMBER NULL,
       Entry_date           DATE NULL,
       User_id              NUMBER NULL,
       CONSTRAINT PRODUCT_GERMPLASM_PK 
              PRIMARY KEY (Product_germplasm_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT PRODUCT_GERMPLASM_AK1
       UNIQUE (
              Midas_origin,
              Midas_line_code
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;


CREATE INDEX PRODUCT_GERMPLASM_IDX1 ON PRODUCT_GERMPLASM
(
       Crop_id                        ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX PRODUCT_GERMPLASM_IDX2 ON PRODUCT_GERMPLASM
(
       Process_id                     ASC
)
    	 TABLESPACE LEXICON_INDEX
;


CREATE TABLE CROP (
       Crop_id              NUMBER NOT NULL,
       Crop_name            VARCHAR2(50) NOT NULL,
       Bayer_code           VARCHAR2(20) NOT NULL,
       Relative_maturity_min NUMBER(6,1) NULL,
       Relative_maturity_max NUMBER(6,1) NULL,
       Relative_maturity_increment NUMBER(6,1) NULL,
       Bayer_descr          VARCHAR2(50) NULL,
       Midas_crop_id        NUMBER NULL,
       CONSTRAINT PK_CROP 
              PRIMARY KEY (Crop_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT AK_CROP1
       UNIQUE (
              Crop_name,
              Bayer_code
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;



CREATE TABLE COUNTRY (
       Country_id           NUMBER NOT NULL,
       Country_abbr         VARCHAR2(5) NULL,
       Country_name         VARCHAR2(50) NULL,
       CONSTRAINT COUNTRY_PK 
              PRIMARY KEY (Country_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT COUNTRY_AK1
       UNIQUE (
              Country_abbr
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;



CREATE TABLE PRODUCT_HISTORY (
       Product_id           NUMBER NOT NULL,
       Entry_date           DATE NOT NULL,
       Brand_id             NUMBER NULL,
       Product_stage_id     NUMBER NULL,
       Commercial_name      VARCHAR2(50) NULL,
       Country_id           NUMBER NULL,
       Product_germplasm_id NUMBER NULL,
       Pre_commercial_name  VARCHAR2(50) NULL,
       Relative_maturity    NUMBER(6,1) NULL,
       Commercial_maturity  NUMBER(6,1) NULL,
       Product_status       VARCHAR2(50) NULL,
       Is_product_stage_active VARCHAR2(1) NULL,
       User_id              NUMBER NULL,
       Process_id           NUMBER NULL,
       CONSTRAINT PRODUCT_HISTORY_PK 
              PRIMARY KEY (Product_id, Entry_date)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;




CREATE TABLE PROCESS (
       Process_id           NUMBER NOT NULL,
       Process_name         VARCHAR2(50) NULL,
       Process_description  VARCHAR2(200) NULL,
       CONSTRAINT PROCESS_PK 
              PRIMARY KEY (Process_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT PROCESS_AK1
       UNIQUE (
              Process_name
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;



CREATE TABLE PRODUCT_GERMPLASM_HISTORY (
       Product_germplasm_id NUMBER NOT NULL,
       Entry_date           DATE NOT NULL,
       SAP_origin           VARCHAR2(50) NULL,
       USA_variety_name     VARCHAR2(50) NULL,
       Is_active            VARCHAR2(50) NULL,
       User_id              NUMBER NULL,
       Process_id           NUMBER NULL,
       CONSTRAINT PRODUCT_GERMPLASM_HISTORY_PK 
              PRIMARY KEY (Product_germplasm_id, Entry_date)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;




ALTER TABLE EQUIV_GERMPLASM_MAP
       ADD  ( CONSTRAINT FK_EQGMAP_PROCESS_PROCESSID
              FOREIGN KEY (Process_id)
                             REFERENCES PROCESS ) ;


ALTER TABLE EQUIV_GERMPLASM_MAP
       ADD  ( CONSTRAINT FK_EQGMAP_EQTYPE_EQUIVTYPEID
              FOREIGN KEY (Equiv_type_id)
                             REFERENCES EQUIV_TYPE ) ;


ALTER TABLE EQUIV_GERMPLASM_MAP
       ADD  ( CONSTRAINT FK_EQGMAP_PRODGERM_PRODGERMID
              FOREIGN KEY (Primary_product_germplasm_id)
                             REFERENCES PRODUCT_GERMPLASM ) ;


ALTER TABLE EQUIV_GERMPLASM_MAP
       ADD  ( CONSTRAINT FK_EQGMAP_COUNTRY_COUNTRYID
              FOREIGN KEY (Country_id)
                             REFERENCES COUNTRY ) ;


ALTER TABLE EQUIV_GERMPLASM_MAP
       ADD  ( CONSTRAINT FK_EQGMAP_PRODGERM_PRODGERMID2
              FOREIGN KEY (Product_germplasm_id)
                             REFERENCES PRODUCT_GERMPLASM ) ;


ALTER TABLE LEXICON.USER_PREFERENCE_VALUE
       ADD  ( CONSTRAINT FK_USRPRFVAL_USRPRF_USRPRFID
              FOREIGN KEY (USER_PREFERENCE_ID)
                             REFERENCES LEXICON.USER_PREFERENCE ) ;


ALTER TABLE LEXICON.USER_PREFERENCE
       ADD  ( CONSTRAINT FK_USRPRF_USRPRFDEF_USRPRFDFID
              FOREIGN KEY (USER_PREFERENCE_DEFINITION_ID)
                             REFERENCES LEXICON.USER_PREFERENCE_DEFINITION ) ;


ALTER TABLE MIDAS_GERMPLASM
       ADD  ( CONSTRAINT FK_MIDGERM_PRODGERM_PRODGERMID
              FOREIGN KEY (Product_germplasm_id)
                             REFERENCES PRODUCT_GERMPLASM ) ;


ALTER TABLE TRANSGENIC_EVENT
       ADD  ( CONSTRAINT FK_TRANEVENT_TRAIT_TRAITID
              FOREIGN KEY (Trait_id)
                             REFERENCES TRAIT ) ;


ALTER TABLE PRODUCT_TRAIT
       ADD  ( CONSTRAINT FK_PRODTRAIT_PRODUCT_PRODUCTID
              FOREIGN KEY (Product_id)
                             REFERENCES PRODUCT ) ;


ALTER TABLE PRODUCT_TRAIT
       ADD  ( CONSTRAINT FK_PRODTRAIT_TRAIT_TRAITID
              FOREIGN KEY (Trait_id)
                             REFERENCES TRAIT ) ;


ALTER TABLE PRODUCT
       ADD  ( CONSTRAINT FK_PRODUCT_PROCESS_PROCESSID
              FOREIGN KEY (Process_id)
                             REFERENCES PROCESS ) ;


ALTER TABLE PRODUCT
       ADD  ( CONSTRAINT FK_PRODUCT_PRODGERM_PRODGERMID
              FOREIGN KEY (Product_germplasm_id)
                             REFERENCES PRODUCT_GERMPLASM ) ;


ALTER TABLE PRODUCT
       ADD  ( CONSTRAINT FK_PRODUCT_COUNTRY_COUNTRYID
              FOREIGN KEY (Country_id)
                             REFERENCES COUNTRY ) ;


ALTER TABLE PRODUCT
       ADD  ( CONSTRAINT FK_PRODUCT_PRODSTG_PRODSTGID
              FOREIGN KEY (Product_stage_id)
                             REFERENCES PRODUCT_STAGE ) ;


ALTER TABLE PRODUCT
       ADD  ( CONSTRAINT FK_PRODUCT_BRAND_BRANDID
              FOREIGN KEY (Brand_id)
                             REFERENCES BRAND ) ;


ALTER TABLE BRAND
       ADD  ( CONSTRAINT FK_BRAND_COMPANY_COMPANYID
              FOREIGN KEY (Company_id)
                             REFERENCES COMPANY ) ;


ALTER TABLE INTELLECTUAL_PROPERTY
       ADD  ( CONSTRAINT FK_INTELPROP_PRODGERM_PRDGRMID
              FOREIGN KEY (Product_germplasm_id)
                             REFERENCES PRODUCT_GERMPLASM ) ;


ALTER TABLE INTELLECTUAL_PROPERTY
       ADD  ( CONSTRAINT FK_INTELPROP_COUNTRY_COUNTRYID
              FOREIGN KEY (Country_id)
                             REFERENCES COUNTRY ) ;


ALTER TABLE TRAIT
       ADD  ( CONSTRAINT FK_TRAIT_CROP_CROPID
              FOREIGN KEY (Crop_id)
                             REFERENCES CROP ) ;


ALTER TABLE PRODUCT_GERMPLASM
       ADD  ( CONSTRAINT FK_PRODGERM_PROCESS_PROCESSID
              FOREIGN KEY (Process_id)
                             REFERENCES PROCESS ) ;


ALTER TABLE PRODUCT_GERMPLASM
       ADD  ( CONSTRAINT FK_PRODGERM_CROP_CROPID
              FOREIGN KEY (Crop_id)
                             REFERENCES CROP ) ;

