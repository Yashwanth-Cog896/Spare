DROP TABLE comp_prod_trait CASCADE CONSTRAINTS;
DROP TABLE comp_product CASCADE CONSTRAINTS;
DROP TABLE product_name_trait CASCADE CONSTRAINTS;
DROP TABLE product_name CASCADE CONSTRAINTS;
DROP TABLE product CASCADE CONSTRAINTS;
drop table Midas_Dup_Product_Name cascade constraints;
drop table equiv_product_name cascade constraints;
