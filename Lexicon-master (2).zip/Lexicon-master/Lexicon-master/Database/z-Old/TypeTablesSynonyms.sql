CREATE OR REPLACE SYNONYM Company FOR Lexicon.Company;
CREATE OR REPLACE SYNONYM company_pubkey_seq FOR Lexicon.Company_pubkey_seq;
CREATE OR REPLACE SYNONYM company_id_seq FOR Lexicon.Company_id_seq;

CREATE OR REPLACE SYNONYM Brand FOR Lexicon.Brand;
CREATE OR REPLACE SYNONYM brand_pubkey_seq FOR Lexicon.brand_pubkey_seq;
CREATE OR REPLACE SYNONYM brand_id_seq FOR Lexicon.brand_id_seq;

CREATE OR REPLACE SYNONYM Country FOR Lexicon.Country;
CREATE OR REPLACE SYNONYM country_pubkey_seq FOR Lexicon.country_pubkey_seq;
CREATE OR REPLACE SYNONYM country_id_seq FOR Lexicon.country_id_seq;

CREATE OR REPLACE SYNONYM Crop FOR Lexicon.Crop;
CREATE OR REPLACE SYNONYM Crop_id_seq FOR Lexicon.Crop_id_seq;

CREATE OR REPLACE SYNONYM Bayer_Code FOR Lexicon.Bayer_Code;
CREATE OR REPLACE SYNONYM bayer_code_id_seq FOR Lexicon.bayer_codeid_seq;
--CREATE OR REPLACE SYNONYM Product_Stage FOR Lexicon.Product_Stage;
--CREATE OR REPLACE SYNONYM Trait FOR Lexicon.Trait;

