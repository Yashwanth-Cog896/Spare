DROP SEQUENCE Audit_detail_seq;
DROP SEQUENCE Audit_header_seq;
DROP TABLE AUDIT_STAGING CASCADE CONSTRAINTS;
DROP TABLE AUDIT_DETAIL CASCADE CONSTRAINTS;
DROP TABLE AUDIT_HEADER CASCADE CONSTRAINTS;


CREATE SEQUENCE Audit_detail_seq 
INCREMENT BY 1 
START WITH 1000 
NOMAXVALUE 
NOMINVALUE 
CACHE 30 
NOCYCLE
NOORDER
;
CREATE SEQUENCE Audit_header_seq 
INCREMENT BY 1 
START WITH 1000 
NOMAXVALUE 
NOMINVALUE 
CACHE 30 
NOCYCLE
NOORDER
;

CREATE TABLE AUDIT_DETAIL (
       Audit_detail_id      NUMBER NOT NULL,
       Audit_header_id      NUMBER NOT NULL,
       Column_name          VARCHAR2(50) NOT NULL,
       New_value            VARCHAR2(4000) NULL,
       Old_value            VARCHAR2(4000) NULL,
       CONSTRAINT AUDIT_DETAIL_PK 
              PRIMARY KEY (Audit_detail_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT AUDIT_DETAIL_AK1
       UNIQUE (
              Audit_header_id,
              Column_name
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;

CREATE INDEX AUDIT_DETAIL_IDX1 ON AUDIT_DETAIL
(
       Audit_header_id                ASC
)
    	 TABLESPACE LEXICON_INDEX
;


CREATE TABLE AUDIT_HEADER (
       Audit_header_id      NUMBER NOT NULL,
       Audit_operation_type VARCHAR2(1) NOT NULL
                                   CONSTRAINT IUDaudit
                                          CHECK (Audit_operation_type IN ('I', 'U', 'D')),
       User_party_id        NUMBER NOT NULL,
       Table_name           VARCHAR2(50) NOT NULL,
       Entry_date           DATE NOT NULL,
       Primary_key_field1   NUMBER NOT NULL,
       Process_name         VARCHAR2(50) NOT NULL,
       Audit_comment        VARCHAR2(4000) NULL,
       Audit_requestor      VARCHAR2(50) NULL,
       CONSTRAINT AUDIT_HEADER_PK 
              PRIMARY KEY (Audit_header_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT AUDIT_HEADER_AK1
       UNIQUE (
              Audit_operation_type,
              Table_name,
              Entry_date
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;


CREATE TABLE AUDIT_STAGING (
       Oracle_sid           NUMBER NOT NULL,
       User_party_id        NUMBER NOT NULL,
       Process_name         VARCHAR2(50) NOT NULL,
       Audit_comment        VARCHAR2(4000) NULL,
       Audit_requestor      VARCHAR2(50) NULL,
       CONSTRAINT AUDIT_STAGING_PK 
              PRIMARY KEY (Oracle_sid)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;




ALTER TABLE AUDIT_DETAIL
       ADD  ( CONSTRAINT R_232
              FOREIGN KEY (Audit_header_id)
                             REFERENCES AUDIT_HEADER ) ;




GRANT SELECT, INSERT, UPDATE, DELETE ON AUDIT_HEADER TO Lexicon_User;
GRANT SELECT, INSERT, UPDATE, DELETE ON AUDIT_DETAIL TO Lexicon_User;
GRANT SELECT, INSERT, UPDATE, DELETE ON AUDIT_STAGING TO Lexicon_User;

GRANT SELECT ON Audit_header_seq  TO Lexicon_User;
GRANT SELECT ON Audit_detail_seq  TO Lexicon_User;


CREATE OR REPLACE SYNONYM audit_header_seq FOR Lexicon.audit_header_seq;
CREATE OR REPLACE SYNONYM audit_detail_seq FOR Lexicon.audit_detail_seq;
CREATE OR REPLACE SYNONYM audit_header FOR Lexicon.audit_header;
CREATE OR REPLACE SYNONYM audit_detail FOR Lexicon.audit_detail;
CREATE OR REPLACE SYNONYM audit_staging FOR Lexicon.staging; 








