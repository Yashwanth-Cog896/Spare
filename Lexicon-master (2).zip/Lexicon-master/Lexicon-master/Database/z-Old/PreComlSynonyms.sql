CREATE OR REPLACE SYNONYM Pre_Coml_Product_Id_Seq FOR Lexicon.Pre_Coml_Product_Id_Seq;
CREATE OR REPLACE SYNONYM Pre_Coml_Product_Pubkey_Seq FOR Lexicon.Pre_Coml_Product_Pubkey_Seq;
CREATE OR REPLACE SYNONYM Pre_Coml_Product FOR Lexicon.Pre_Coml_Product;

CREATE OR REPLACE SYNONYM Product_Stage_Pubkey_Seq FOR Lexicon.Product_Stage_Pubkey_Seq;
CREATE OR REPLACE SYNONYM Product_Stage_Id_Seq FOR Lexicon.Product_Stage_Id_Seq;
CREATE OR REPLACE SYNONYM Product_Stage FOR Lexicon.Product_Stage;

CREATE OR REPLACE SYNONYM Product_Gp_Action_Id_Seq FOR Lexicon.Product_Gp_Action_Id_Seq;
CREATE OR REPLACE SYNONYM Product_Gp_Action FOR Lexicon.Product_Gp_Action;

CREATE OR REPLACE SYNONYM Stage_Id_Seq FOR Lexicon.Stage_Id_Seq;
CREATE OR REPLACE SYNONYM Stage_Pubkey_Seq FOR Lexicon.Stage_Pubkey_Seq;
CREATE OR REPLACE SYNONYM Stage FOR Lexicon.Stage;