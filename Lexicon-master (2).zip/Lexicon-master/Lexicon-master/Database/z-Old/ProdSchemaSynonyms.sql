CREATE OR REPLACE SYNONYM product FOR Lexicon.product;
CREATE OR REPLACE SYNONYM product_id_seq FOR Lexicon.product_id_seq;
CREATE OR REPLACE SYNONYM product_pubkey_seq FOR Lexicon.product_pubkey_seq;

CREATE OR REPLACE SYNONYM product_name FOR Lexicon.product_name;
CREATE OR REPLACE SYNONYM product_name_id_seq FOR Lexicon.product_name_id_seq;
CREATE OR REPLACE SYNONYM product_name_pubkey_seq FOR Lexicon.product_name_pubkey_seq;

CREATE OR REPLACE SYNONYM equiv_product_name_id_seq FOR Lexicon.equiv_product_name_id_seq;
CREATE OR REPLACE SYNONYM equiv_product_name FOR Lexicon.equiv_product_name;

CREATE OR REPLACE SYNONYM product_trait FOR Lexicon.product_trait;
CREATE OR REPLACE SYNONYM product_trait_id_seq FOR Lexicon.product_trait_id_seq;

