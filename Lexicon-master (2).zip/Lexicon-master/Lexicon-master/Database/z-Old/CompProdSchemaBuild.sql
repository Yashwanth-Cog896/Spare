-- Create Sequences
CREATE SEQUENCE Comp_product_pubkey_seq
INCREMENT BY 100
START WITH 1002
NOMAXVALUE
NOMINVALUE
CACHE 30
NOCYCLE
NOORDER
;

CREATE SEQUENCE Comp_Prod_Id_Seq
INCREMENT BY 1
START WITH 1000
NOMAXVALUE
NOMINVALUE
CACHE 30
NOCYCLE
NOORDER;

CREATE SEQUENCE Comp_Prod_Trait_Id_Seq
INCREMENT BY 1
START WITH 1000
NOMAXVALUE
NOMINVALUE
CACHE 30
NOCYCLE
NOORDER;

-- Create Comp_Product table
CREATE TABLE COMP_PRODUCT (
       Comp_prod_id         NUMBER NOT NULL,
       Comp_product_pubkey  VARCHAR2(20) NOT NULL,
       Product_name         VARCHAR2(50) NULL,
       Country_id           NUMBER NULL,
       Brand_id             NUMBER NULL,
       Bayer_code_id        NUMBER NULL,
       Commercial_maturity  NUMBER(6,1) NULL,
       Verified_data_source VARCHAR2(20) NULL,
       Data_source_year     NUMBER NULL,
       Requestor_name       VARCHAR2(50) NULL,
       Comments             VARCHAR2(2000) NULL,
       Is_active            VARCHAR2(1) NOT NULL
                                   CONSTRAINT YesorNo35
                                          CHECK (Is_active IN ('y', 'n')),
       Process_id           NUMBER NULL,
       User_id              NUMBER NULL,
       Entry_date           DATE DEFAULT SYSDATE NOT NULL,
       CONSTRAINT COMP_PRODUCT_PK
              PRIMARY KEY (Comp_prod_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT COMP_PRODUCT_AK1
       UNIQUE (
              Product_name,
              Bayer_code_id,
              Country_id,
              Brand_id
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT COMP_PRODUCT_AK2
       UNIQUE (
              Comp_product_pubkey
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;

CREATE INDEX COMP_PRODUCT_IDX1 ON COMP_PRODUCT
(
       Brand_id                       ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX COMP_PRODUCT_IDX2 ON COMP_PRODUCT
(
       Process_id                     ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX COMP_PRODUCT_IDX3 ON COMP_PRODUCT
(
       Bayer_code_id                  ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX COMP_PRODUCT_IDX4 ON COMP_PRODUCT
(
       Country_id                     ASC
)
    	 TABLESPACE LEXICON_INDEX
;


-- Create Comp_Prod_Trait table
CREATE TABLE COMP_PROD_TRAIT (
       Comp_prod_trait_id   NUMBER NOT NULL,
       Trait_id             NUMBER NULL,
       Comp_prod_id         NUMBER NULL,
       Process_id           NUMBER NULL,
       Entry_date           DATE DEFAULT SYSDATE NOT NULL,
       User_id              NUMBER NULL,
       CONSTRAINT COMP_PROD_TRAIT_PK
              PRIMARY KEY (Comp_prod_trait_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT COMP_PROD_TRAIT_AK1
       UNIQUE (
              Trait_id,
              Comp_prod_id
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;

CREATE INDEX COMP_PROD_TRAIT_IDX1 ON COMP_PROD_TRAIT
(
       Trait_id                       ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX COMP_PROD_TRAIT_IDX2 ON COMP_PROD_TRAIT
(
       Comp_prod_id                   ASC
)
    	 TABLESPACE LEXICON_INDEX
;

CREATE INDEX COMP_PROD_TRAIT_IDX3 ON COMP_PROD_TRAIT
(
       Process_id                     ASC
)
    	 TABLESPACE LEXICON_INDEX
;





-- Foreign Keys
ALTER TABLE COMP_PRODUCT
       ADD  ( CONSTRAINT FK_COMPPROD_COUNTRY_COUNTRYID
              FOREIGN KEY (Country_id)
                             REFERENCES COUNTRY ) ;


ALTER TABLE COMP_PRODUCT
       ADD  ( CONSTRAINT FK_COMPPROD_BAYERCD_BAYERCDID
              FOREIGN KEY (Bayer_code_id)
                             REFERENCES BAYER_CODE ) ;


ALTER TABLE COMP_PRODUCT
       ADD  ( CONSTRAINT FK_COMPPROD_BRAND_BRANDID
              FOREIGN KEY (Brand_id)
                             REFERENCES BRAND ) ;


ALTER TABLE COMP_PROD_TRAIT
       ADD  ( CONSTRAINT FK_COMPPTRAIT_COMPPRD_CPTID
              FOREIGN KEY (Comp_prod_id)
                             REFERENCES COMP_PRODUCT ) ;


ALTER TABLE COMP_PROD_TRAIT
       ADD  ( CONSTRAINT FK_COMPPRODTRAIT_TRAIT_TRAITID
              FOREIGN KEY (Trait_id)
                             REFERENCES TRAIT ) ;



