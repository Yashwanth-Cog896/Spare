CREATE SEQUENCE pre_coml_product_id_seq
INCREMENT BY 1
START WITH 1000
NOMAXVALUE
NOMINVALUE
CACHE 30
NOCYCLE
NOORDER
;

CREATE SEQUENCE pre_coml_product_pubkey_seq
INCREMENT BY 100
START WITH 1009
NOMAXVALUE
NOMINVALUE
CACHE 30
NOCYCLE
NOORDER
;

CREATE TABLE pre_coml_product(
    product_id                      NUMBER NOT NULL,
    product_pubkey                  VARCHAR2(20) NOT NULL,
    pre_coml_name                   VARCHAR2(40) NOT NULL,
    crop_id									NUMBER NOT NULL,
    ustv_name								VARCHAR2(40),

	CONSTRAINT Pre_Coml_Product_PK
		PRIMARY KEY (product_id)
		USING INDEX
	TABLESPACE  Lexicon_Index,

	CONSTRAINT Pre_Coml_Product_AK1
		UNIQUE (product_pubkey)
		USING INDEX
	TABLESPACE  Lexicon_Index,

	CONSTRAINT Pre_Coml_Product_AK2
		UNIQUE (ustv_name)
		USING INDEX
	TABLESPACE  Lexicon_Index,

	CONSTRAINT Pre_Coml_Product_AK3
		UNIQUE (pre_coml_name)
		USING INDEX
	TABLESPACE  Lexicon_Index
)
TABLESPACE Lexicon_Data;

ALTER TABLE pre_coml_product
ADD CONSTRAINT fk_pcp_crop_cropid FOREIGN KEY (crop_id)
REFERENCES crop (crop_id);


CREATE SEQUENCE product_stage_id_seq
INCREMENT BY 1
START WITH 1000
NOMAXVALUE
NOMINVALUE
CACHE 30
NOCYCLE
NOORDER
;

CREATE SEQUENCE product_stage_pubkey_seq
INCREMENT BY 100
START WITH 1012
NOMAXVALUE
NOMINVALUE
CACHE 30
NOCYCLE
NOORDER
;

CREATE TABLE product_stage
    (product_stage_id              NUMBER NOT NULL,
    product_stage_pubkey           VARCHAR2(20) NOT NULL,
    product_id                     NUMBER NOT NULL,
    country_id                     NUMBER NOT NULL,
    brand_id                       NUMBER NOT NULL,
    stage_id                       NUMBER NOT NULL,
    commercial_name                VARCHAR2(40),
    test_name                      VARCHAR2(40),
    oecd_reqd_name                 VARCHAR2(40),
    commercial_maturity            NUMBER(6,1),
    is_active							  VARCHAR2(1) NOT NULL,

    	CONSTRAINT Product_Stage_PK
    		PRIMARY KEY (product_stage_id)
    		USING INDEX
    	TABLESPACE  Lexicon_Index,

    	CONSTRAINT Product_Stage_AK1
    		UNIQUE (product_stage_pubkey)
    		USING INDEX
		TABLESPACE  Lexicon_Index,

		CONSTRAINT Product_Stage_AK2
			UNIQUE (
						product_id,
						country_id,
						brand_id
					  )
			USING INDEX
    	 TABLESPACE LEXICON_INDEX

)
TABLESPACE Lexicon_Data;

ALTER TABLE product_stage
ADD CONSTRAINT fk_ps_pcprod_prodid FOREIGN KEY (product_id)
REFERENCES pre_coml_product (product_id);

ALTER TABLE product_stage
ADD CONSTRAINT fk_ps_country_countryid FOREIGN KEY (country_id)
REFERENCES country (country_id);

ALTER TABLE product_stage
ADD CONSTRAINT fk_ps_brand_brandid FOREIGN KEY (brand_id)
REFERENCES brand (brand_id);

ALTER TABLE product_stage
ADD CONSTRAINT fk_ps_stage_stageid FOREIGN KEY (stage_id)
REFERENCES stage (stage_id);

ALTER TABLE product_stage
ADD CONSTRAINT trueorfalseps CHECK (is_active IN ('y', 'n'));

CREATE SEQUENCE product_gp_action_id_seq
INCREMENT BY 1
START WITH 1000
NOMAXVALUE
NOMINVALUE
CACHE 30
NOCYCLE
NOORDER
;

CREATE TABLE product_gp_action(
    product_gp_action_id			NUMBER NOT NULL,
    product_pubkey               VARCHAR2(20) NOT NULL,
    gp_key								VARCHAR2(20) NOT NULL,

    	CONSTRAINT Product_Gp_Action_PK
		PRIMARY KEY (product_gp_action_id)
		USING INDEX
		TABLESPACE  Lexicon_Index

)
TABLESPACE Lexicon_Data;

ALTER TABLE product_gp_action
ADD CONSTRAINT fk_pga_pcprod_prodpubkey FOREIGN KEY (product_pubkey)
REFERENCES pre_coml_product (product_pubkey);


CREATE SEQUENCE stage_id_seq
INCREMENT BY 100
START WITH 2100
NOMAXVALUE
NOMINVALUE
CACHE 30
NOCYCLE
NOORDER
;

CREATE SEQUENCE stage_pubkey_seq
INCREMENT BY 100
START WITH 2100
NOMAXVALUE
NOMINVALUE
CACHE 30
NOCYCLE
NOORDER
;

CREATE TABLE stage(
	stage_id					NUMBER NOT NULL,
	stage_pubkey			VARCHAR(20) NOT NULL,
	stage_abbr           VARCHAR2(4) NOT NULL,
	stage_desc				VARCHAR2(50) NOT NULL,
	order_by_num         NUMBER,
	is_coml_stage        VARCHAR2(1) NOT NULL,

	CONSTRAINT Stage_PK
		PRIMARY KEY (stage_id)
		USING INDEX
	TABLESPACE  Lexicon_Index,

	CONSTRAINT Stage_AK1
   	UNIQUE (stage_abbr)
    	USING INDEX
	TABLESPACE  Lexicon_Index,

	CONSTRAINT Stage_AK3
   	UNIQUE (stage_pubkey)
    	USING INDEX
	TABLESPACE  Lexicon_Index

)
TABLESPACE Lexicon_Data;

ALTER TABLE stage ADD CONSTRAINT true_or_false_stage CHECK (is_coml_stage IN ('y', 'n'));

ALTER TABLE STAGE ADD CONSTRAINT STAGE_UNIQUE_ORDER_BY_NUM UNIQUE (ORDER_BY_NUM);

ALTER table crop add major_crop varchar2(1) DEFAULT 'n' not null;
ALTER table crop add CONSTRAINT Trueorfalsemjrcrop CHECK (major_crop IN ('y', 'n'));
update crop set major_crop = 'y' where crop_name in ('CORN', 'COTTON', 'SOYBEANS', 'SORGHUM', 'SUNFLOWER', 'OSR-CANOLA');