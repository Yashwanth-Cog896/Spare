CREATE OR REPLACE SYNONYM Comp_Product FOR Lexicon.Comp_Product;
CREATE OR REPLACE SYNONYM Comp_Prod_Trait FOR Lexicon.Comp_Prod_Trait;
CREATE OR REPLACE SYNONYM Comp_Prod_Id_Seq FOR Lexicon.Comp_Prod_Id_Seq;
CREATE OR REPLACE SYNONYM Comp_Prod_Trait_id_Seq FOR Lexicon.Comp_Prod_Trait_id_Seq;
CREATE OR REPLACE SYNONYM Comp_Product_pubkey_seq FOR Lexicon.Comp_Product_pubkey_seq;

