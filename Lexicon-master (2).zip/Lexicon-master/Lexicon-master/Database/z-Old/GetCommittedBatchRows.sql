BEGIN
	DECLARE 
		CURSOR GetRowsCurs IS
			SELECT xml_representation
			  FROM Comp_Prod_Batch_Row 
			 WHERE comp_prod_batch_row_status = 'C'
			   AND xml_representation IS NOT NULL;

		errNum NUMBER;		
		errMsg VARCHAR2(250);
		xmlrep VARCHAR2(2000);

	BEGIN
	    dbms_output.enable(100000);
		FOR rec IN GetRowsCurs 
		LOOP
			xmlrep := rec.xml_representation;
			xmlrep := REPLACE(xmlrep, '<Status type="Committed"/>', '');
			xmlrep := REPLACE(xmlrep, ' commit="true"', '');
			xmlrep := REPLACE(xmlrep, ' xmlns="http://www.monsanto.com/lexicon/cp" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"', '');

			dbms_output.put_line(SUBSTR(xmlrep, 1, 250));
			IF LENGTH(xmlrep) >  250 THEN dbms_output.put_line(SUBSTR(xmlrep,  251, 250)); END IF;
			IF LENGTH(xmlrep) >  500 THEN dbms_output.put_line(SUBSTR(xmlrep,  501, 250)); END IF;
			IF LENGTH(xmlrep) >  750 THEN dbms_output.put_line(SUBSTR(xmlrep,  751, 250)); END IF;
			IF LENGTH(xmlrep) > 1000 THEN dbms_output.put_line(SUBSTR(xmlrep, 1001, 250)); END IF;
			IF LENGTH(xmlrep) > 1250 THEN dbms_output.put_line(SUBSTR(xmlrep, 1251, 250)); END IF;
            dbms_output.new_line;
		END LOOP;
	EXCEPTION
		WHEN OTHERS THEN
			errNum := SQLCODE;
			errMsg := SUBSTR(SQLERRM, 1, 250);
			dbms_output.put_line(errNum || ':' || errMsg);
	END;
END;
 


