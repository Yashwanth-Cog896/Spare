update comp_prod_batch_row
   set xml_representation = 
        substr(xml_representation, 1, instr(xml_representation, '><Status', 1, 1) -1) || 
        ' xmlns="http://www.monsanto.com/lexicon/cp" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"' ||
        substr(xml_representation, instr(xml_representation, '><Status', 1, 1), length(xml_representation) - instr(xml_representation, '><Status', 1, 1) +1)
 where xml_representation not like '%xmlns%'; 
 
 


