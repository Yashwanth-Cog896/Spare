GRANT SELECT, INSERT, UPDATE, DELETE ON product TO Lexicon_User, ngscho;
GRANT SELECT ON PRODUCT_PUBKEY_SEQ TO  Lexicon_User, ngscho;
GRANT SELECT ON PRODUCT_ID_SEQ TO  Lexicon_User, ngscho;

GRANT SELECT, INSERT, UPDATE, DELETE ON product_name TO Lexicon_User, ngscho;
GRANT SELECT ON PRODUCT_NAME_PUBKEY_SEQ TO  Lexicon_User, ngscho;
GRANT SELECT ON PRODUCT_NAME_ID_SEQ TO  Lexicon_User, ngscho;
GRANT SELECT ON EQUIV_PRODUCT_NAME_ID_SEQ TO  Lexicon_User, ngscho;


GRANT SELECT, INSERT, UPDATE, DELETE ON Midas_Dup_Product_Name to Lexicon_User, ngscho;

grant insert,update,delete,select on Midas_Dup_Product_Name to lexicon_user, ngscho;

GRANT SELECT, INSERT, UPDATE, DELETE ON equiv_Product_Name to Lexicon_User, ngscho;


--GRANT SELECT, INSERT, UPDATE, DELETE ON product_name_trait TO Lexicon_User, ngscho;
