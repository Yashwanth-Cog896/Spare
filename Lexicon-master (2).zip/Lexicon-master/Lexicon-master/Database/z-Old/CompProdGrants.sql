GRANT SELECT, INSERT, UPDATE, DELETE ON Comp_Product TO Lexicon_User;
GRANT SELECT, INSERT, UPDATE, DELETE ON Comp_Prod_Trait TO Lexicon_User;

GRANT SELECT ON Comp_Prod_Id_Seq TO Lexicon_User;
GRANT SELECT ON Comp_Prod_Trait_Id_Seq TO Lexicon_User;
GRANT SELECT ON Comp_Product_pubkey_seq to lexicon_user;

