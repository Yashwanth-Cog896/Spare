CREATE SEQUENCE Country_pubkey_seq
INCREMENT BY 100
START WITH 1004
NOMAXVALUE
NOMINVALUE
CACHE 30
NOCYCLE
NOORDER
;

CREATE SEQUENCE Company_pubkey_seq
INCREMENT BY 100
START WITH 1003
NOMAXVALUE
NOMINVALUE
CACHE 30
NOCYCLE
NOORDER
;

CREATE SEQUENCE Brand_pubkey_seq
INCREMENT BY 100
START WITH 1001
NOMAXVALUE
NOMINVALUE
CACHE 30
NOCYCLE
NOORDER
;

CREATE SEQUENCE Company_id_seq
INCREMENT BY 1
START WITH 1000
NOMAXVALUE
NOMINVALUE
CACHE 30
NOCYCLE
NOORDER
;

CREATE SEQUENCE Brand_id_seq
INCREMENT BY 1
START WITH 1000
NOMAXVALUE
NOMINVALUE
CACHE 30
NOCYCLE
NOORDER
;

CREATE SEQUENCE Country_id_seq
INCREMENT BY 1
START WITH 1000
NOMAXVALUE
NOMINVALUE
CACHE 30
NOCYCLE
NOORDER
;

CREATE SEQUENCE Crop_id_seq
INCREMENT BY 1
START WITH 1000
NOMAXVALUE
NOMINVALUE
CACHE 30
NOCYCLE
NOORDER
;

CREATE SEQUENCE Bayer_code_id_seq
INCREMENT BY 1
START WITH 1000
NOMAXVALUE
NOMINVALUE
CACHE 30
NOCYCLE
NOORDER
;



CREATE TABLE COUNTRY (
       Country_id           NUMBER NOT NULL,
       Country_pubkey       VARCHAR2(20) NOT NULL,
       Country_abbr         VARCHAR2(5) NOT NULL,
       Country_name         VARCHAR2(80) NOT NULL,
       CONSTRAINT COUNTRY_PK
              PRIMARY KEY (Country_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT COUNTRY_AK1
       UNIQUE (
              Country_abbr
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT COUNTRY_AK2
       UNIQUE (
              Country_pubkey
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT COUNTRY_AK3
       UNIQUE (
              Country_name
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;


-- Create Company Table
CREATE TABLE COMPANY (
       Company_id           NUMBER NOT NULL,
       Company_pubkey       VARCHAR2(20) NOT NULL,
       Company_name         VARCHAR2(50) NOT NULL,
       Is_active            VARCHAR2(1) NOT NULL
                                   CONSTRAINT YesorNo37
                                          CHECK (Is_active IN ('y', 'n')),
       Is_competitor  VARCHAR2(1) NOT NULL
                                   CONSTRAINT YesorNo33
                                          CHECK (Is_competitor IN ('y', 'n')),
       CONSTRAINT COMPANY_PK
              PRIMARY KEY (Company_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT COMPANY_AK1
       UNIQUE (
              Company_name
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT COMPANY_AK2
       UNIQUE (
              Company_pubkey
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;

CREATE TABLE BRAND (
       Brand_id             NUMBER NOT NULL,
       Brand_pubkey         VARCHAR2(20) NOT NULL,
       Brand_name           VARCHAR2(50) NOT NULL,
       Brand_abbr           VARCHAR2(20) NULL,
       Company_id           NUMBER NOT NULL,
       Is_active            VARCHAR2(1) NOT NULL
                                   CONSTRAINT YesorNo34
                                          CHECK (Is_active IN ('y', 'n')),
       CONSTRAINT BRAND_PK
              PRIMARY KEY (Brand_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT BRAND_AK1
       UNIQUE (
              Brand_name
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT BRAND_ABBR_UNQ
       UNIQUE (
              Brand_abbr
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT BRAND_AK2
       UNIQUE (
              Brand_pubkey
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;

CREATE INDEX BRAND_IDX1 ON BRAND
(
       Company_id                     ASC
)
    	 TABLESPACE LEXICON_INDEX
;


-- Create Crop Table
CREATE TABLE CROP (
       Crop_id              NUMBER NOT NULL,
       Crop_name            VARCHAR2(50) NOT NULL,
       CONSTRAINT CROP_PK
              PRIMARY KEY (Crop_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT CROP_AK1
       UNIQUE (
              Crop_name
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;



-- Create Bayer Table
CREATE TABLE BAYER_CODE (
       Bayer_code_id        NUMBER NOT NULL,
       Bayer_code_name      VARCHAR2(50) NOT NULL,
       Bayer_code_desc      VARCHAR2(100) NOT NULL,
       Crop_id              NUMBER NOT NULL,
       CONSTRAINT BAYER_CODE_PK
              PRIMARY KEY (Bayer_code_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT BAYER_CODE_AK1
       UNIQUE (
              Bayer_code_name
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
)
    	 TABLESPACE LEXICON_DATA
 ;

CREATE INDEX BAYER_CODE_IDX1 ON BAYER_CODE
(
       Crop_id                        ASC
)
    	 TABLESPACE LEXICON_INDEX
;


/*
CREATE TABLE Product_Stage (
	Product_stage_id                NUMBER          NOT NULL,
	Product_stage_public_key        VARCHAR2(10)    NOT NULL,
	Product_stage_name              VARCHAR2(50)    NOT NULL,
	Product_stage_abbr              VARCHAR2(20)    NOT NULL,
	Product_stage_type              VARCHAR2(20)    NULL,

	CONSTRAINT Product_Stage_PK 
		PRIMARY KEY (Product_stage_id)
		USING INDEX
	TABLESPACE Lexicon_Index,
		
	CONSTRAINT Product_Stage_AK1
		UNIQUE (Product_stage_name)
		USING INDEX
	TABLESPACE Lexicon_Index,
		
	CONSTRAINT Product_Stage_AK2
		UNIQUE (Product_stage_public_key)
		USING INDEX
	TABLESPACE Lexicon_Index
)
TABLESPACE Lexicon_Data;
*/


-- Foreign Keys
ALTER TABLE BRAND
       ADD  ( CONSTRAINT FK_BRAND_COMPANY_COMPANYID
              FOREIGN KEY (Company_id)
                             REFERENCES COMPANY ) ;


ALTER TABLE BAYER_CODE
       ADD  ( CONSTRAINT FK_BAYERCODE_CROP_CROPID
              FOREIGN KEY (Crop_id)
                             REFERENCES CROP ) ;


