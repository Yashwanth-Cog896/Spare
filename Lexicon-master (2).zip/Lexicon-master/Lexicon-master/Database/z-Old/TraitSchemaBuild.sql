DROP VIEW coml_trait_stack_names_vw;

DROP TABLE Coml_Trait CASCADE CONSTRAINTS;
DROP TABLE Coml_Trait_Type CASCADE CONSTRAINTS;
DROP TABLE Coml_Trait_Type_Xref CASCADE CONSTRAINTS;
DROP TABLE Coml_Trait_Name CASCADE CONSTRAINTS;
DROP TABLE Coml_Trait_Stack CASCADE CONSTRAINTS;
DROP TABLE Coml_Trait_Stack_Name_Xref CASCADE CONSTRAINTS;
DROP TABLE Coml_Trait_Stack_Xref CASCADE CONSTRAINTS; 

DROP SEQUENCE Coml_Trait_Id_Seq;
DROP SEQUENCE Coml_Trait_Type_Id_seq;  
DROP SEQUENCE Coml_Trait_Type_Xref_Id_seq;
DROP SEQUENCE Coml_Trait_Name_Id_seq;
DROP SEQUENCE Coml_Trait_Stack_Xref_Id_seq;
DROP SEQUENCE Coml_Trait_Stack_Id_seq;
DROP SEQUENCE Trait_Stack_Name_Xref_Id_Seq;

CREATE SEQUENCE Coml_Trait_Id_Seq
INCREMENT BY 1
START WITH 1000
NOMAXVALUE
NOMINVALUE
CACHE 30
NOCYCLE
NOORDER
;

CREATE SEQUENCE Coml_Trait_Type_Id_seq
INCREMENT BY 1
START WITH 1000
NOMAXVALUE
NOMINVALUE
CACHE 30
NOCYCLE
NOORDER
;

CREATE SEQUENCE Coml_Trait_Type_Xref_Id_seq
INCREMENT BY 1
START WITH 1000
NOMAXVALUE
NOMINVALUE
CACHE 30
NOCYCLE
NOORDER
;

CREATE SEQUENCE Coml_Trait_Name_Id_seq
INCREMENT BY 1
START WITH 1000
NOMAXVALUE
NOMINVALUE
CACHE 30
NOCYCLE
NOORDER
;

CREATE SEQUENCE Coml_Trait_Stack_Xref_Id_seq
INCREMENT BY 1
START WITH 1000
NOMAXVALUE
NOMINVALUE
CACHE 30
NOCYCLE
NOORDER
;

CREATE SEQUENCE Coml_Trait_Stack_Id_seq
INCREMENT BY 1
START WITH 1000
NOMAXVALUE
NOMINVALUE
CACHE 30
NOCYCLE
NOORDER
;

CREATE SEQUENCE Trait_Stack_Name_Xref_Id_Seq
INCREMENT BY 1
START WITH 1000
NOMAXVALUE
NOMINVALUE
CACHE 30
NOCYCLE
NOORDER
;


CREATE TABLE Coml_Trait (
    coml_trait_id                   NUMBER          NOT NULL,
    crop_id                         NUMBER          NOT NULL,
    coml_trait_abbr                 VARCHAR2(8)     NOT NULL,
    coml_trait_desc                 VARCHAR2(50)    NOT NULL,
    is_active                       VARCHAR2(1)     NOT NULL
        CONSTRAINT yesorno44
          CHECK (is_active IN ('y', 'n')),

    CONSTRAINT Coml_Trait_PK
        PRIMARY KEY (coml_trait_id)
        USING INDEX
    TABLESPACE Lexicon_Index,

    CONSTRAINT Coml_Trait_AK1
        UNIQUE (crop_id, coml_trait_abbr)
        USING INDEX
    TABLESPACE Lexicon_Index
)
TABLESPACE Lexicon_Data;


CREATE TABLE Coml_Trait_Type (
    coml_trait_type_id              NUMBER          NOT NULL,
    coml_trait_type_abbr            VARCHAR2(8)     NOT NULL,
    coml_trait_type_desc            VARCHAR2(50)    NOT NULL,

    CONSTRAINT Coml_Trait_Type_PK
       PRIMARY KEY (coml_trait_type_id)
       USING INDEX
    TABLESPACE Lexicon_Index,

    CONSTRAINT Coml_Trait_Type_AK1
       UNIQUE (coml_trait_type_abbr)
       USING INDEX
    TABLESPACE Lexicon_Index
)
TABLESPACE Lexicon_Data;


CREATE TABLE Coml_Trait_Type_Xref (
    coml_trait_type_xref_id         NUMBER          NOT NULL,
    coml_trait_id                   NUMBER          NOT NULL,
    coml_trait_type_id              NUMBER          NOT NULL,

    CONSTRAINT Coml_Trait_Type_Xref_PK
        PRIMARY KEY (coml_trait_type_xref_id)
        USING INDEX
    TABLESPACE Lexicon_Index,

    CONSTRAINT Coml_Trait_Type_Xref_AK1
       UNIQUE (coml_trait_id, coml_trait_type_id)
       USING INDEX
    TABLESPACE Lexicon_Index
)
TABLESPACE Lexicon_Data;


CREATE TABLE Coml_Trait_Name (
    coml_trait_name_id              NUMBER          NOT NULL,
    coml_trait_id                   NUMBER          NOT NULL,
    company_id                      NUMBER          NOT NULL,
    coml_trait_name_abbr            VARCHAR2(8)     NOT NULL,
    coml_trait_name_desc            VARCHAR2(50)    NOT NULL,
    is_active                       VARCHAR2(1)     NOT NULL
        CONSTRAINT yesorno44b
            CHECK (is_active IN ('y', 'n')),

    CONSTRAINT coml_trait_name_PK
        PRIMARY KEY (coml_trait_name_id)
        USING INDEX
    TABLESPACE Lexicon_Index, 
  
    CONSTRAINT coml_trait_name_AK1
        UNIQUE (coml_trait_id, coml_trait_name_abbr)
        USING INDEX
    TABLESPACE Lexicon_Index
)
TABLESPACE Lexicon_Data;


CREATE TABLE Coml_Trait_Stack (
    coml_trait_stack_id             NUMBER          NOT NULL,
    coml_trait_stack_abbr           VARCHAR2(20)     NOT NULL,
    crop_id                         NUMBER          NOT NULL,

    CONSTRAINT Coml_Trait_Stack_PK
        PRIMARY KEY (coml_trait_stack_id)
        USING INDEX
    TABLESPACE Lexicon_Index,

    CONSTRAINT Coml_Trait_Stack_AK
        UNIQUE (crop_id, coml_trait_stack_abbr)
        USING INDEX
    TABLESPACE Lexicon_Index
)
TABLESPACE Lexicon_Data;


CREATE TABLE Coml_Trait_Stack_Name_Xref (
    trait_stack_name_xref_id        NUMBER          NOT NULL,
    crop_id                         NUMBER          NOT NULL,
    coml_trait_stack_id             NUMBER          NOT NULL,
    name_type                       VARCHAR2(1)     NOT NULL
        CONSTRAINT RGQ1
            CHECK (name_type IN ('R', 'G')),

	 value                           VARCHAR2(50)    NOT NULL,

    CONSTRAINT Coml_Trait_Stack_Name_Xref_PK
        PRIMARY KEY (trait_stack_name_xref_id)
        USING INDEX
    TABLESPACE Lexicon_Index,

    CONSTRAINT Coml_Trait_Stack_Name_Xref_AK1
        UNIQUE (coml_trait_stack_id, name_type)
        USING INDEX
    TABLESPACE Lexicon_Index,

    CONSTRAINT Coml_Trait_Stack_Name_Xref_AK2
        UNIQUE (crop_id, value)
        USING INDEX
    TABLESPACE Lexicon_Index
)
TABLESPACE Lexicon_Data;



CREATE TABLE Coml_Trait_Stack_Xref (
    coml_trait_stack_xref_id        NUMBER          NOT NULL,
    coml_trait_name_id              NUMBER          NOT NULL,
    coml_trait_stack_id             NUMBER          NOT NULL,
    stack_order                     NUMBER          NOT NULL,

    CONSTRAINT Coml_Trait_Stack_Xref_PK
       PRIMARY KEY (coml_trait_stack_xref_id)
       USING INDEX
    TABLESPACE Lexicon_Index,

    CONSTRAINT Coml_Trait_Stack_Xref_AK1
        UNIQUE (coml_trait_name_id, coml_trait_stack_id, stack_order)
        USING INDEX
    TABLESPACE Lexicon_Index
)
TABLESPACE Lexicon_Data;


-- FK constraints
ALTER TABLE Coml_Trait ADD (
    CONSTRAINT FK_Coml_Trait_Crop_Id
        FOREIGN KEY (crop_id)
            REFERENCES Crop
);

ALTER TABLE Coml_Trait_Type_Xref ADD (
    CONSTRAINT FK_Trait_Type_Xref_Trait_Id
        FOREIGN KEY (coml_trait_id)
            REFERENCES Coml_Trait
);

ALTER TABLE Coml_Trait_Type_Xref ADD (
    CONSTRAINT FK_Trait_Type_Xref_Type_Id
        FOREIGN KEY (coml_trait_type_id)
            REFERENCES Coml_Trait_Type
);

ALTER TABLE Coml_Trait_Name ADD ( 
    CONSTRAINT FK_Coml_Trait_Name_Company_Id
        FOREIGN KEY (company_id)
            REFERENCES Company
);

ALTER TABLE Coml_Trait_Name ADD (
    CONSTRAINT FK_Coml_Trait_Name_Trait_Id
        FOREIGN KEY (coml_trait_id)
            REFERENCES Coml_Trait
);

ALTER TABLE Coml_Trait_Stack ADD ( 
    CONSTRAINT FK_Trait_Stack_Crop_Id
        FOREIGN KEY (crop_id)
            REFERENCES CROP
);

ALTER TABLE Coml_Trait_Stack_Xref ADD ( 
    CONSTRAINT FK_Trait_Stack_Xref_Stack_Id
        FOREIGN KEY (coml_trait_stack_id)
            REFERENCES Coml_Trait_Stack
);

ALTER TABLE Coml_Trait_Stack_Xref ADD ( 
    CONSTRAINT FK_Trait_Stack_Xref_Name_Id
        FOREIGN KEY (coml_trait_name_id)
            REFERENCES Coml_Trait_Name
);

ALTER TABLE Coml_Trait_Stack_Name_Xref ADD (
    CONSTRAINT FK_Trait_Stack_Name_Stack_Id
        FOREIGN KEY (coml_trait_stack_id)
            REFERENCES Coml_Trait_Stack
);

ALTER TABLE Coml_Trait_Stack_Name_Xref ADD (
    CONSTRAINT FK_Trait_Stack_Name_Crop_Id
        FOREIGN KEY (crop_id)
            REFERENCES Crop
);

ALTER TABLE Product_Name ADD (
    CONSTRAINT FK_Product_Name_Trait_Stack_Id
        FOREIGN KEY (coml_trait_stack_id)
            REFERENCES Coml_Trait_Stack
);

-- Create Views
CREATE or replace VIEW coml_trait_stack_names_vw (
    coml_trait_stack_id,
    crop_name,
    reporting_name,
    generated_name)
AS
SELECT CTS.coml_trait_stack_id AS coml_trait_stack_id,
       C.crop_name as crop_name,
       RepName.value AS Reporting_Name,
       GenName.value AS Generated_Name
  FROM Coml_Trait_Stack CTS, Crop C,
       (SELECT coml_trait_stack_id, value FROM Coml_Trait_Stack_Name_XRef WHERE name_type = 'R') RepName,
       (SELECT coml_trait_stack_id, value FROM Coml_Trait_Stack_Name_XRef WHERE name_type = 'G') GenName
 WHERE RepName.coml_trait_stack_id (+)= CTS.coml_trait_stack_id
   AND GenName.coml_trait_stack_id (+)= CTS.coml_trait_stack_id
   AND C.crop_id = cts.crop_id
;


GRANT SELECT, INSERT, UPDATE, DELETE ON COML_TRAIT_TYPE TO Lexicon_User, NGSCHO;
GRANT SELECT ON COML_TRAIT_TYPE_ID_SEQ to Lexicon_user, NGSCHO;
GRANT SELECT, INSERT, UPDATE, DELETE ON COML_TRAIT TO Lexicon_User, NGSCHO;
GRANT SELECT ON COML_TRAIT_ID_SEQ to Lexicon_user, NGSCHO;
GRANT SELECT, INSERT, UPDATE, DELETE ON COML_TRAIT_TYPE_XREF TO Lexicon_User, NGSCHO;
GRANT SELECT ON COML_TRAIT_TYPE_XREF_ID_SEQ to Lexicon_user, NGSCHO;
GRANT SELECT, INSERT, UPDATE, DELETE ON COML_TRAIT_NAME TO Lexicon_User, NGSCHO;
GRANT SELECT ON COML_TRAIT_NAME_ID_SEQ to Lexicon_user, NGSCHO;
GRANT SELECT, INSERT, UPDATE, DELETE ON COML_TRAIT_STACK TO Lexicon_User, NGSCHO;
GRANT SELECT ON COML_TRAIT_STACK_ID_SEQ to Lexicon_user, NGSCHO;
GRANT SELECT, INSERT, UPDATE, DELETE ON COML_TRAIT_STACK_XREF TO Lexicon_User, NGSCHO;
GRANT SELECT ON COML_TRAIT_STACK_XREF_ID_SEQ to Lexicon_user, NGSCHO;
GRANT SELECT, INSERT, UPDATE, DELETE ON COML_TRAIT_STACK_NAME_XREF TO Lexicon_User, NGSCHO;
GRANT SELECT ON TRAIT_STACK_NAME_XREF_ID_SEQ to Lexicon_user, NGSCHO;
GRANT SELECT, INSERT, UPDATE, DELETE ON coml_trait_stack_names_vw TO Lexicon_User, NGSCHO;


CREATE OR REPLACE SYNONYM coml_Trait FOR Lexicon.coml_Trait;
CREATE OR REPLACE SYNONYM coml_Trait_id_seq FOR Lexicon.coml_Trait_id_seq;
CREATE OR REPLACE SYNONYM coml_Trait_type FOR Lexicon.coml_Trait_type;
CREATE OR REPLACE SYNONYM coml_Trait_type_id_seq FOR Lexicon.coml_Trait_type_id_seq;
CREATE OR REPLACE SYNONYM coml_Trait_type_xref FOR Lexicon.coml_Trait_type_xref;
CREATE OR REPLACE SYNONYM coml_Trait_type_xref_id_seq FOR Lexicon.coml_Trait_type_xref_id_seq;
CREATE OR REPLACE SYNONYM coml_Trait_name FOR Lexicon.coml_Trait_name;
CREATE OR REPLACE SYNONYM coml_Trait_name_id_seq FOR Lexicon.coml_Trait_name_id_seq;
CREATE OR REPLACE SYNONYM coml_Trait_stack FOR Lexicon.coml_Trait_stack;
CREATE OR REPLACE SYNONYM coml_Trait_stack_id_seq FOR Lexicon.coml_Trait_stack_id_seq;
CREATE OR REPLACE SYNONYM coml_Trait_stack_xref FOR Lexicon.coml_Trait_stack_xref;
CREATE OR REPLACE SYNONYM coml_Trait_stack_xref_id_seq FOR Lexicon.coml_Trait_stack_xref_id_seq;
CREATE OR REPLACE SYNONYM Coml_Trait_Stack_Name_xref for lexicon.Coml_Trait_Stack_Name_xref;
CREATE OR REPLACE SYNONYM coml_trait_stack_names_vw for lexicon.coml_trait_stack_names_vw;
