drop table lexicon_parameter cascade constraints;

CREATE TABLE lexicon_parameter(
    lsi_env                        VARCHAR2(5) NOT NULL,
    parameter_key                  VARCHAR2(32) NOT NULL,
    numeric_value                  NUMBER,
    xml_value                      CLOB)
TABLESPACE Lexicon_Data;


alter table lexicon_parameter add CONSTRAINT lexicon_parameter_pk
		PRIMARY KEY (lsi_env, parameter_key)
		USING INDEX
	TABLESPACE  Lexicon_Index;


GRANT SELECT, INSERT, UPDATE, DELETE ON lexicon_parameter to Lexicon_User, ngscho;

CREATE OR REPLACE SYNONYM lexicon_parameter FOR Lexicon.lexicon_parameter;
