CREATE SEQUENCE report_id_seq
INCREMENT BY 1
START WITH 1000
NOMAXVALUE
NOMINVALUE
CACHE 30
NOCYCLE
NOORDER
;

CREATE TABLE report
    (report_id                NUMBER NOT NULL,
     report_name              VARCHAR2(20) NOT NULL,
     report_desc              VARCHAR2(100),
     order_by_num             NUMBER,

    	CONSTRAINT Report_PK
    		PRIMARY KEY (report_id)
    		USING INDEX
    	TABLESPACE  Lexicon_Index,

    	CONSTRAINT Report_Name_AK1
    		UNIQUE (report_name)
    		USING INDEX
		TABLESPACE  Lexicon_Index
)
TABLESPACE Lexicon_Data;

CREATE TABLE report_execution
    (user_party_id            NUMBER NOT NULL,
     report_id                NUMBER NOT NULL,
     start_date               DATE NOT NULL,
     finished_date            DATE,
     report_contents          CLOB,
     error_msg                CLOB,

    	CONSTRAINT User_Party_ID_PK
    		PRIMARY KEY (user_party_id)
    		USING INDEX
    	TABLESPACE  Lexicon_Index,

      CONSTRAINT FK_Report_ID FOREIGN KEY (report_id)
         REFERENCES report (report_id)
)
TABLESPACE Lexicon_Data;

-- GRANT SELECT, INSERT, UPDATE, DELETE ON report TO Lexicon_User, ngscho;
-- GRANT SELECT ON report_id_seq TO Lexicon_User, ngscho;

-- GRANT SELECT, INSERT, UPDATE, DELETE ON report_execution TO Lexicon_User, ngscho;

-- CREATE OR REPLACE SYNONYM report FOR Lexicon.report;
-- CREATE OR REPLACE SYNONYM report_execution FOR Lexicon.report_execution;
-- CREATE OR REPLACE SYNONYM report_id_seq FOR Lexicon.report_id_seq;