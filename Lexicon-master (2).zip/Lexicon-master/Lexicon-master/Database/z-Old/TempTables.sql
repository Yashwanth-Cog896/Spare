drop table MIRAGE_MINORCROP_BAYER_CODE;
drop table MIRAGE_MINORCROP_COMPET_COMP;
drop table MIRAGE_SEED_PRODUCT;
drop table MIRAGE_SEED_PRODUCT_name cascade constraints;
drop table MIDAS_LEXICON_PRODUCT cascade constraints;
drop table MIDAS_LEXICON_PRODUCT_NAME cascade constraints;
drop table MIRAGE_LEXICON_PRODUCT cascade constraints;

CREATE TABLE MIDAS_LEXICON_PRODUCT (
       midas_product_id NUMBER NOT NULL,
      lexicon_product_id NUMBER NOT NULL,
	CONSTRAINT MIDAS_LEXICON_PRODUCT_AK1
		UNIQUE (midas_product_id)
		USING INDEX
	TABLESPACE  Lexicon_Index,
	CONSTRAINT MIDAS_LEXICON_PRODUCT_AK2
		UNIQUE (lexicon_product_id)
		USING INDEX
	TABLESPACE  Lexicon_Index

)
TABLESPACE lexicon_data;

CREATE TABLE MIRAGE_LEXICON_PRODUCT (
       mirage_product_id NUMBER NOT NULL,
      lexicon_product_id NUMBER NOT NULL,
	CONSTRAINT MIRAGE_LEXICON_PRODUCT_AK1
		UNIQUE (mirage_product_id)
		USING INDEX
	TABLESPACE  Lexicon_Index,
	CONSTRAINT MIRAGE_LEXICON_PRODUCT_AK2
		UNIQUE (lexicon_product_id)
		USING INDEX
	TABLESPACE  Lexicon_Index

)
TABLESPACE lexicon_data;


CREATE TABLE MIDAS_LEXICON_PRODUCT_name (
       midas_product_name_id NUMBER NOT NULL,
       lexicon_product_name_id NUMBER NOT NULL,
	CONSTRAINT MIDAS_LEXICON_PRODUCT_NAME_AK1
		UNIQUE (midas_product_name_id)
		USING INDEX
	TABLESPACE  Lexicon_Index,
	CONSTRAINT MIDAS_LEXICON_PRODUCT_NAME_AK2
		UNIQUE (lexicon_product_name_id)
		USING INDEX
	TABLESPACE  Lexicon_Index
)
TABLESPACE lexicon_data;



CREATE TABLE MIRAGE_MINORCROP_BAYER_CODE (
       Bayer_code_name   VARCHAR2(8) NOT NULL,
       CONSTRAINT Bayer_code_name_pk
              PRIMARY KEY (Bayer_code_name)
       USING INDEX
       TABLESPACE lexicon_index
)
       TABLESPACE lexicon_data;


CREATE TABLE MIRAGE_MINORCROP_COMPET_COMP (
       company_name   VARCHAR2(100) NOT NULL,
       CONSTRAINT company_name_PK
              PRIMARY KEY (company_name)
       USING INDEX
       TABLESPACE lexicon_index 
)
       TABLESPACE lexicon_data;

CREATE TABLE MIRAGE_SEED_PRODUCT (
       product_id     NUMBER NOT NULL,
       crop_bayer_code VARCHAR2(8) not null,
       CONSTRAINT mirage_seed_product_pk
              PRIMARY KEY (product_id)
       USING INDEX
       TABLESPACE lexicon_index
       
)
       TABLESPACE lexicon_data;
       
CREATE TABLE MIRAGE_SEED_PRODUCT_NAME (
       product_name_id     VARCHAR2(30) NOT NULL,
       product_id     NUMBER NOT NULL,
       company_name   VARCHAR2(100) NOT NULL,
       crop_bayer_code VARCHAR2(8) not null,
       product_name    VARCHAR2(100) not null,
       maturity        VARCHAR2(20),
       comments        VARCHAR2(2000),
       country_name    VARCHAR2(60) not null,
       triat           VARCHAR2(20),
       CONSTRAINT mirage_seed_product_name_pk
              PRIMARY KEY (product_name_id)
       USING INDEX
       TABLESPACE lexicon_index
       
)
       TABLESPACE lexicon_data;
       


ALTER TABLE MIRAGE_SEED_PRODUCT_NAME
       ADD  ( CONSTRAINT FK_MIRAGE_SEED_PRODUCT_NAME_id
              FOREIGN KEY (product_id)
                             REFERENCES MIRAGE_SEED_PRODUCT ) ;
       
       
       
grant insert,update,delete,select on MIRAGE_MINORCROP_BAYER_CODE to lexicon_user,ngscho;
grant insert,update,delete,select on MIRAGE_MINORCROP_COMPET_COMP to lexicon_user,ngscho;
grant insert,update,delete,select on MIRAGE_SEED_PRODUCT to lexicon_user,ngscho;
grant insert,update,delete,select on MIRAGE_SEED_PRODUCT_name to lexicon_user,ngscho;
grant insert,update,delete,select on MIDAS_LEXICON_PRODUCT to lexicon_user,ngscho;
grant insert,update,delete,select on MIDAS_LEXICON_PRODUCT_NAME to lexicon_user,ngscho;
grant insert,update,delete,select on MIRAGE_LEXICON_PRODUCT to lexicon_user,ngscho;



