--DROP SEQUENCE Comp_product_pubkey_seq;
--DROP SEQUENCE Comp_Prod_Id_Seq;
--DROP SEQUENCE Comp_Prod_Trait_Id_Seq;

--DROP TABLE Comp_Prod_Trait CASCADE CONSTRAINTS;

--DROP TABLE Comp_Product CASCADE CONSTRAINTS;


