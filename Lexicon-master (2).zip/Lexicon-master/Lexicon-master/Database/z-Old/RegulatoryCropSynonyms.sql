CREATE OR REPLACE SYNONYM Crop_Pubkey_Seq FOR Lexicon.Crop_Pubkey_Seq;
CREATE OR REPLACE SYNONYM Bayer_Code_Pubkey_Seq FOR Lexicon.Bayer_Code_Pubkey_Seq;