-- Create Sequences
CREATE SEQUENCE Comp_Prod_Batch_Id_Seq
INCREMENT BY 1
START WITH 1000
NOMAXVALUE
NOMINVALUE
CACHE 30
NOCYCLE
NOORDER;

CREATE SEQUENCE Comp_Prod_Batch_Row_Id_Seq
INCREMENT BY 1
START WITH 1000
NOMAXVALUE
NOMINVALUE
CACHE 30
NOCYCLE
NOORDER;

-- Create Comp_Prod_Batch table
CREATE TABLE Comp_Prod_Batch (
	Comp_prod_batch_id              NUMBER          NOT NULL,
	Comp_prod_batch_name            VARCHAR2(50)    NULL,
	Num_total                       NUMBER          NULL,
	Num_committed                   NUMBER          NULL,
	Num_validated                   NUMBER          NULL,
	Num_errored                     NUMBER          NULL,
	Num_abandoned                   NUMBER          NULL,
	Num_unprocessed                 NUMBER          NULL,
	Entry_date                      DATE            NULL,
	
	CONSTRAINT Comp_Prod_Batch_PK
		PRIMARY KEY (comp_prod_batch_id)
		USING INDEX
	TABLESPACE Lexicon_Index,
	
	CONSTRAINT Comp_Prod_Batch_AK1
		UNIQUE (Comp_prod_batch_name)
		USING INDEX
	TABLESPACE Lexicon_Index
)
TABLESPACE Lexicon_Data;

-- Create Comp_Prod_Batch_Row table
CREATE TABLE Comp_Prod_Batch_Row (
	Comp_prod_batch_row_id          NUMBER          NOT NULL,
	Comp_prod_batch_id              NUMBER          NULL,
	Comp_prod_batch_row_num         NUMBER          NULL,
	Comp_prod_batch_row_status      VARCHAR2(1)     NULL,
	XML_representation              VARCHAR2(2000)  NULL,

	CONSTRAINT Comp_Prod_Batch_Row_PK
		PRIMARY KEY (comp_prod_batch_row_id)
		USING INDEX
	TABLESPACE Lexicon_Index,

	CONSTRAINT Comp_Prod_Batch_Row_AK1
		UNIQUE (Comp_prod_batch_id, Comp_prod_batch_row_num)
		USING INDEX
	TABLESPACE Lexicon_Index
)
TABLESPACE Lexicon_Data;

CREATE INDEX Comp_Prod_Batch_Row_IDX1 ON Comp_Prod_Batch_Row (
	Comp_prod_batch_id              ASC
)
TABLESPACE Lexicon_Index;

CREATE INDEX Comp_Prod_Batch_Row_IDX2 ON Comp_Prod_Batch_Row (
	Comp_prod_batch_row_status      ASC
)
TABLESPACE Lexicon_Index;

-- Create Comp_Prod_Batch_Row_Status table
CREATE TABLE Comp_Prod_Batch_Row_Status (
	Comp_prod_batch_row_status      VARCHAR2(1)     NOT NULL,
	Comp_prod_batch_row_stat_name   VARCHAR2(20)    NULL,

	CONSTRAINT Comp_Prod_Batch_Row_Status_PK
		PRIMARY KEY (Comp_prod_batch_row_status)
		USING INDEX
	TABLESPACE Lexicon_Index,
	
	CONSTRAINT Comp_Prod_Batch_Row_Status_AK1
		UNIQUE (Comp_prod_batch_row_stat_name)
		USING INDEX
	TABLESPACE Lexicon_Index
)
TABLESPACE Lexicon_Data;

ALTER TABLE Comp_Prod_Batch_Row ADD ( 
	CONSTRAINT FK_CmpPrdBR_CmpPrdStat_Status
		FOREIGN KEY (Comp_prod_batch_row_status)
			REFERENCES Comp_Prod_Batch_Row_Status 
);

ALTER TABLE Comp_Prod_Batch_Row ADD (
	CONSTRAINT FK_CmpPrdBR_CmpPrdB_CmpPrdBId
		FOREIGN KEY (comp_prod_batch_id)
			REFERENCES Comp_Prod_Batch 
);			


