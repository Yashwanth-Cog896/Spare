CREATE SEQUENCE Resource_lock_id_seq
INCREMENT BY 1
START WITH 1000
NOMAXVALUE
NOMINVALUE
CACHE 30
NOCYCLE
NOORDER
;

CREATE TABLE RESOURCE_LOCK (
       Resource_lock_id     NUMBER NOT NULL,
       Resource_name        VARCHAR2(256) NOT NULL,
       User_id              NUMBER NOT NULL,
       Entry_date           DATE NOT NULL,
       CONSTRAINT RESOURCE_LOCK_PK
              PRIMARY KEY (Resource_lock_id)
       USING INDEX
    	 TABLESPACE LEXICON_INDEX,
       CONSTRAINT RESOURCE_LOCK_AK1
       UNIQUE (
              Resource_name
       )
       USING INDEX
    	 TABLESPACE LEXICON_INDEX
);

CREATE INDEX RESOURCE_LOCK_IDX1 ON RESOURCE_LOCK
(
       User_id                        ASC
)
    	 TABLESPACE LEXICON_INDEX
;

