set heading off
set pagesize 0
set linesize 1000
set verify off
set echo off

select
    decode( OBJECT_TYPE,
     'TABLE',  'grant insert, update, delete, select on ' || OWNER||'.'||OBJECT_NAME || ' to ngscho;',
     'VIEW',  'grant insert, update, delete, select on ' || OWNER||'.'||OBJECT_NAME || ' to ngscho;',
     'SNAPSHOT',  'grant select on ' || OWNER||'.'||OBJECT_NAME || ' to ngscho;',
     'SYNONYM',  'grant insert, update, delete, select on ' || OWNER||'.'||OBJECT_NAME || ' to ngscho;',
     'PROCEDURE', 'grant execute on ' || OWNER||'.'||OBJECT_NAME || ' to ngscho;',
     'FUNCTION', 'grant execute on ' || OWNER||'.'||OBJECT_NAME || ' to ngscho;',
     'TYPE', 'grant execute on ' || OWNER||'.'||OBJECT_NAME || ' to ngscho;',
     'PACKAGE', 'grant execute on ' || OWNER||'.'||OBJECT_NAME || ' to ngscho;',
     'SEQUENCE', 'grant alter, select on '|| OWNER||'.'||OBJECT_NAME || ' to ngscho;',
                  'grant execute on ' || OBJECT_TYPE || ' ' || OWNER||'.'||OBJECT_NAME || ' to ngscho;')
from
    dba_objects a
where
    owner = 'LEXICON' and
    OBJECT_TYPE not in ( 'INDEX','TRIGGER', 'DATABASE LINK', 'PACKAGE BODY' )
order by
    OBJECT_TYPE,
    OBJECT_NAME;
