DROP TABLE Crop CASCADE CONSTRAINTS;
DROP TABLE Bayer_Code CASCADE CONSTRAINTS;
DROP TABLE Country CASCADE CONSTRAINTS;
DROP TABLE Brand CASCADE CONSTRAINTS;
DROP TABLE Company CASCADE CONSTRAINTS;

--DROP TABLE Trait CASCADE CONSTRAINTS;

--drop SEQUENCE Country_pubkey_seq;
--drop SEQUENCE Company_pubkey_seq;
--drop SEQUENCE Brand_pubkey_seq;
--drop SEQUENCE Company_id_seq;
--drop SEQUENCE Brand_id_seq;
--drop SEQUENCE Country_id_seq;
--drop SEQUENCE Crop_id_seq;
--drop SEQUENCE Bayer_code_id_seq;

--DROP TABLE Product_Stage CASCADE CONSTRAINTS;


