--
-- Additional Material
--
CREATE TABLE Lexicon.Additional_Material
(
   additional_material_id  NUMBER                NOT NULL,
   material_name           NVARCHAR2(80)         NOT NULL,
   alias                   NVARCHAR2(40),
   chemical_name_cas       NVARCHAR2(255),
   chemical_name_iupac     NVARCHAR2(255),
   cp_number               NVARCHAR2(30),
   active_status           NVARCHAR2(8)          NOT NULL,
   user_id                 NVARCHAR2(7),
   record_date             TIMESTAMP(6),
   change_date_time        TIMESTAMP(6),
   comment_text            CLOB                  NOT NULL,
   CONSTRAINT Additional_Material_PK
      PRIMARY KEY (additional_material_id)
      USING INDEX
   TABLESPACE Lexicon_Index
)
TABLESPACE Lexicon_Data
/

ALTER TABLE Lexicon.Additional_Material
   ADD CONSTRAINT Additional_Material_AK1
      UNIQUE (material_name)
      USING INDEX
   TABLESPACE Lexicon_Index
/

CREATE SEQUENCE Lexicon.Additional_Material_Id_Seq
  INCREMENT BY 1
  START WITH 1000
  MINVALUE 1000
  MAXVALUE 999999999999999999999999999
  NOCYCLE
  NOORDER
  CACHE 20
/


--
-- Chemical Name
--

CREATE TABLE Lexicon.Chemical_Name
(
   chemical_name_id         NUMBER               NOT NULL,
   material_name            NVARCHAR2(80)        NOT NULL,
   active_ingredient        NVARCHAR2(40),
   material_classification  NVARCHAR2(21)        NOT NULL,
   active_status            NVARCHAR2(8)         NOT NULL,
   user_id                  NVARCHAR2(7),
   record_date              TIMESTAMP(6),
   change_date_time         TIMESTAMP(6),
   comment_text             CLOB                 NOT NULL,
   CONSTRAINT Chemical_Name_PK
      PRIMARY KEY (chemical_name_id)
      USING INDEX
   TABLESPACE Lexicon_Index
)
TABLESPACE Lexicon_Data
/

ALTER TABLE Lexicon.Chemical_Name
   ADD CONSTRAINT Chemical_Name_AK1
      UNIQUE (material_name, material_classification)
      USING INDEX
   TABLESPACE Lexicon_Index
/

CREATE SEQUENCE Lexicon.Chemical_Name_Id_Seq
  INCREMENT BY 1
  START WITH 1000
  MINVALUE 1000
  MAXVALUE 999999999999999999999999999
  NOCYCLE
  NOORDER
  CACHE 20
/


--
-- Container Type
--

CREATE TABLE Lexicon.Container_Type
(
   container_type_id  NUMBER                     NOT NULL,
   container_type     NVARCHAR2(40)              NOT NULL,
   storage_condition  NVARCHAR2(25),
   active_status      NVARCHAR2(8)               NOT NULL,
   user_id            NVARCHAR2(7),
   record_date        TIMESTAMP(6),
   change_date_time   TIMESTAMP(6),
   comment_text       CLOB                       NOT NULL,
   CONSTRAINT Container_Type_PK
      PRIMARY KEY (container_type_id)
      USING INDEX
   TABLESPACE Lexicon_Index
)
TABLESPACE Lexicon_Data
/

ALTER TABLE Lexicon.Container_Type
   ADD CONSTRAINT Container_Type_AK1
      UNIQUE (container_type)
      USING INDEX
   TABLESPACE Lexicon_Index
/

CREATE SEQUENCE Lexicon.Container_Type_Id_Seq
  INCREMENT BY 1
  START WITH 1000
  MINVALUE 1000
  MAXVALUE 999999999999999999999999999
  NOCYCLE
  NOORDER
  CACHE 20
/


--
-- External Contacts
--

CREATE TABLE Lexicon.External_Contact
(
   external_contact_id  NUMBER                   NOT NULL,
   last_name            NVARCHAR2(25)            NOT NULL,
   first_name           NVARCHAR2(20)            NOT NULL,
   middle_name          NVARCHAR2(2),
   title                NVARCHAR2(25),
   company_name         NVARCHAR2(70),
   address1             NVARCHAR2(50)            NOT NULL,
   address2             NVARCHAR2(40),
   address3             NVARCHAR2(40),
   city                 NVARCHAR2(40)            NOT NULL,
   county               NVARCHAR2(30),
   state_province       NVARCHAR2(20),
   country              NVARCHAR2(40)            NOT NULL,
   postal_code          NVARCHAR2(30),
   phone_number         NVARCHAR2(25),
   alt_phone_number     NVARCHAR2(25),
   fax_number           NVARCHAR2(25),
   cell_number          NVARCHAR2(25),
   pager_number         NVARCHAR2(25),
   email_address        NVARCHAR2(30),
   active_status        NVARCHAR2(8)             NOT NULL,
   user_id              NVARCHAR2(8),
   record_date          TIMESTAMP(6),
   change_date_time     TIMESTAMP(6),
   comment_text         CLOB                     NOT NULL,
   CONSTRAINT External_Contact_PK
      PRIMARY KEY (external_contact_id)
      USING INDEX
   TABLESPACE Lexicon_Index
)
TABLESPACE Lexicon_Data
/

ALTER TABLE Lexicon.External_Contact
   ADD CONSTRAINT External_Contact_AK1
      UNIQUE (last_name, first_name, address1, city, country)
      USING INDEX
   TABLESPACE Lexicon_Index
/

CREATE SEQUENCE Lexicon.External_Contact_Id_Seq
  INCREMENT BY 1
  START WITH 1000
  MINVALUE 1000
  MAXVALUE 999999999999999999999999999
  NOCYCLE
  NOORDER
  CACHE 20
/


--
-- Formulation Type
--

CREATE TABLE Lexicon.Formulation_Type
(
   formulation_type_id           NUMBER          NOT NULL,
   formulation_type              NVARCHAR2(40)   NOT NULL,
   formulation_type_description  NVARCHAR2(80)   NOT NULL,
   active_status                 NVARCHAR2(8)    NOT NULL,
   user_id                       NVARCHAR2(7),
   record_date                   TIMESTAMP(6),
   change_date_time              TIMESTAMP(6),
   comment_text                  CLOB            NOT NULL,
   CONSTRAINT Formulation_Type_PK
      PRIMARY KEY (formulation_type_id)
      USING INDEX
   TABLESPACE Lexicon_Index
)
TABLESPACE Lexicon_Data
/

ALTER TABLE Lexicon.Formulation_Type
   ADD CONSTRAINT Formulation_Type_AK1
      UNIQUE (formulation_type)
      USING INDEX
   TABLESPACE Lexicon_Index
/

CREATE SEQUENCE Lexicon.Formulation_Type_Id_Seq
  INCREMENT BY 1
  START WITH 1000
  MINVALUE 1000
  MAXVALUE 999999999999999999999999999
  NOCYCLE
  NOORDER
  CACHE 20
/


--
-- Genetic Background
--

CREATE TABLE Lexicon.Genetic_Background
(
   genetic_background_id  NUMBER                 NOT NULL,
   genetic_background     NVARCHAR2(40)          NOT NULL,
   active_status          NVARCHAR2(40)          NOT NULL,
   user_id                NVARCHAR2(40),
   record_date            TIMESTAMP(6),
   change_date_time       TIMESTAMP(6),
   comment_text           CLOB                   NOT NULL,
   CONSTRAINT Genetic_Background_PK
      PRIMARY KEY (genetic_background_id)
      USING INDEX
   TABLESPACE Lexicon_Index
)
TABLESPACE Lexicon_Data
/

ALTER TABLE Lexicon.Genetic_Background
   ADD CONSTRAINT Genetic_Background_AK1
      UNIQUE (genetic_background)
      USING INDEX
   TABLESPACE Lexicon_Index
/

CREATE SEQUENCE Lexicon.Genetic_Background_Id_Seq
  INCREMENT BY 1
  START WITH 1000
  MINVALUE 1000
  MAXVALUE 999999999999999999999999999
  NOCYCLE
  NOORDER
  CACHE 20
/


--
-- Mon Number
--

CREATE TABLE Lexicon.Mon_Number
(
   mon_number_id                   NUMBER        NOT NULL,
   mon_number                      NVARCHAR2(40) NOT NULL,
   crop                            NVARCHAR2(40) NOT NULL,
   event                           NVARCHAR2(200),
   material_name                   NVARCHAR2(40),
   previous_names                  NVARCHAR2(40),
   plasmid_pmon                    NVARCHAR2(200),
   plasmid_pvcode                  NVARCHAR2(50),
   transformation_background       NVARCHAR2(80),
   regulatory_trait_description    NVARCHAR2(40) NOT NULL,
   regulatory_genes_present        NVARCHAR2(40) NOT NULL,
   oecd_number                     NVARCHAR2(40),
   oecd_number_communication_date  TIMESTAMP(6),
   regulated_status                NVARCHAR2(40),
   jv_number                       NVARCHAR2(40),
   locked                          NVARCHAR2(1),
   active_status                   NVARCHAR2(40) NOT NULL,
   user_id                         NVARCHAR2(40),
   record_date                     TIMESTAMP(6),
   changed_date_time               TIMESTAMP(6),
   comment_text                    CLOB          NOT NULL,
   CONSTRAINT mon_number_PK
      PRIMARY KEY (mon_number_id)
      USING INDEX
   TABLESPACE Lexicon_Index
)
TABLESPACE Lexicon_Data
/

ALTER TABLE Lexicon.Mon_Number
   ADD CONSTRAINT Mon_Number_AK1
      UNIQUE (mon_number)
      USING INDEX
   TABLESPACE Lexicon_Index
/

ALTER TABLE Lexicon.Mon_Number
   ADD CONSTRAINT Mon_Number_AK2
      UNIQUE (oecd_number)
      USING INDEX
   TABLESPACE Lexicon_Index
/

ALTER TABLE Lexicon.Mon_Number
   ADD CONSTRAINT Mon_Number_AK3
      UNIQUE (event)
      USING INDEX
   TABLESPACE Lexicon_Index
/

CREATE SEQUENCE Lexicon.Mon_Number_Id_Seq
  INCREMENT BY 1
  START WITH 1000
  MINVALUE 1000
  MAXVALUE 999999999999999999999999999
  NOCYCLE
  NOORDER
  CACHE 20
/


--
-- Plant Name
--

CREATE TABLE Lexicon.Plant_Name
(
   plant_name_id            NUMBER               NOT NULL,
   material_name            NVARCHAR2(50)        NOT NULL,
   brand                    NVARCHAR2(40),
   previous_names           CLOB,
   crop                     NVARCHAR2(20)        NOT NULL,
   country                  NVARCHAR2(40)        NOT NULL,
   material_classification  NVARCHAR2(20)        NOT NULL,
   active_status            NVARCHAR2(8)         NOT NULL,
   user_id                  NVARCHAR2(7),
   record_date              TIMESTAMP(6),
   change_date_time         TIMESTAMP(6),
   comment_text             CLOB                 NOT NULL,
   CONSTRAINT Plant_Name_PK
      PRIMARY KEY (plant_name_id)
      USING INDEX
   TABLESPACE Lexicon_Index
)
TABLESPACE Lexicon_Data
/

ALTER TABLE Lexicon.Plant_Name
   ADD CONSTRAINT Plant_Name_AK1
      UNIQUE (material_name, material_classification)
      USING INDEX
   TABLESPACE Lexicon_Index
/

CREATE SEQUENCE Lexicon.Plant_Name_Id_Seq
  INCREMENT BY 1
  START WITH 1000
  MINVALUE 1000
  MAXVALUE 999999999999999999999999999
  NOCYCLE
  NOORDER
  CACHE 20
/


--
-- Protein Name
--

CREATE TABLE Lexicon.Protein_Name
(
   protein_name_id   NUMBER                      NOT NULL,
   protein_name      NVARCHAR2(40)               NOT NULL,
   active_status     NVARCHAR2(40)               NOT NULL,
   user_id           NVARCHAR2(40),
   record_date       TIMESTAMP(6),
   change_date_time  TIMESTAMP(6),
   comment_text      CLOB                        NOT NULL,
   CONSTRAINT Protein_Name_PK
      PRIMARY KEY (protein_name_id)
      USING INDEX
   TABLESPACE Lexicon_Index
)
TABLESPACE Lexicon_Data
/

ALTER TABLE Lexicon.Protein_Name
   ADD CONSTRAINT Protein_Name_AK1
      UNIQUE (protein_name)
      USING INDEX
   TABLESPACE Lexicon_Index
/

CREATE SEQUENCE Lexicon.Protein_Name_Id_Seq
  INCREMENT BY 1
  START WITH 1000
  MINVALUE 1000
  MAXVALUE 999999999999999999999999999
  NOCYCLE
  NOORDER
  CACHE 20
/


--
-- Sample Type
--

CREATE TABLE Lexicon.Sample_Type
(
   sample_type_id           NUMBER               NOT NULL,
   sample_type              NVARCHAR2(30)        NOT NULL,
   container_type           NVARCHAR2(40)        NOT NULL,
   storage_condition        NVARCHAR2(25),
   sample_type_description  NVARCHAR2(25)        NOT NULL,
   active_status            NVARCHAR2(8)         NOT NULL,
   user_id                  NVARCHAR2(7),
   record_date              TIMESTAMP(6),
   change_date_time         TIMESTAMP(6),
   comment_text             CLOB                 NOT NULL,
   CONSTRAINT Sample_Type_PK
      PRIMARY KEY (sample_type_id)
      USING INDEX
   TABLESPACE Lexicon_Index
)
TABLESPACE Lexicon_Data
/

ALTER TABLE Lexicon.Sample_Type
   ADD CONSTRAINT Sample_Type_AK1
      UNIQUE (sample_type)
      USING INDEX
   TABLESPACE Lexicon_Index
/

CREATE SEQUENCE Lexicon.Sample_Type_Id_Seq
  INCREMENT BY 1
  START WITH 1000
  MINVALUE 1000
  MAXVALUE 999999999999999999999999999
  NOCYCLE
  NOORDER
  CACHE 20
/


--
-- Shipping Condition
--

CREATE TABLE Lexicon.Shipping_Condition
(
   shipping_condition_id  NUMBER                 NOT NULL,
   shipping_condition     NVARCHAR2(40)          NOT NULL,
   active_status          NVARCHAR2(40)          NOT NULL,
   user_id                NVARCHAR2(40),
   record_date            TIMESTAMP(6),
   change_date_time       TIMESTAMP(6),
   comment_text           CLOB                   NOT NULL,
   CONSTRAINT Shipping_Condition_PK
      PRIMARY KEY (shipping_condition_id)
      USING INDEX
   TABLESPACE Lexicon_Index
)
TABLESPACE Lexicon_Data
/

ALTER TABLE Lexicon.Shipping_Condition
   ADD CONSTRAINT Shipping_Condition_AK1
      UNIQUE (shipping_condition)
      USING INDEX
   TABLESPACE Lexicon_Index
/

CREATE SEQUENCE Lexicon.Shipping_Condition_Id_Seq
  INCREMENT BY 1
  START WITH 1000
  MINVALUE 1000
  MAXVALUE 999999999999999999999999999
  NOCYCLE
  NOORDER
  CACHE 20
/


--
-- Storage Condition
--

CREATE TABLE Lexicon.Storage_Condition
(
   storage_condition_id  NUMBER                  NOT NULL,
   storage_condition     NVARCHAR2(40)           NOT NULL,
   active_status         NVARCHAR2(40)           NOT NULL,
   user_id               NVARCHAR2(40),
   record_date           TIMESTAMP(6),
   change_date_time      TIMESTAMP(6),
   comment_text          CLOB                    NOT NULL,
   CONSTRAINT Storage_Condition_PK
      PRIMARY KEY (storage_condition_id)
      USING INDEX
   TABLESPACE Lexicon_Index
)
TABLESPACE Lexicon_Data
/

ALTER TABLE Lexicon.Storage_Condition
   ADD CONSTRAINT Storage_Condition_AK1
      UNIQUE (storage_condition)
      USING INDEX
   TABLESPACE Lexicon_Index
/

CREATE SEQUENCE Lexicon.Storage_Cond_Id_Seq
  INCREMENT BY 1
  START WITH 1000
  MINVALUE 1000
  MAXVALUE 999999999999999999999999999
  NOCYCLE
  NOORDER
  CACHE 20
/


--
-- Storage Location
--

CREATE TABLE Lexicon.Storage_Location
(
   storage_location_id  NUMBER                   NOT NULL,
   storage_location     NVARCHAR2(40)            NOT NULL,
   storage_condition    NVARCHAR2(40)            NOT NULL,
   common_name          NVARCHAR2(60),
   common_description   NVARCHAR2(40),
   equipment_id         NVARCHAR2(40)            NOT NULL,
   physical_location    NVARCHAR2(40)            NOT NULL,
   active_status        NVARCHAR2(40)            NOT NULL,
   user_id              NVARCHAR2(40),
   record_date          TIMESTAMP(6),
   change_date_time     TIMESTAMP(6),
   comment_text         CLOB                     NOT NULL,
   CONSTRAINT Storage_Location_PK
      PRIMARY KEY (storage_location_id)
      USING INDEX
   TABLESPACE Lexicon_Index
)
TABLESPACE Lexicon_Data
/

ALTER TABLE Lexicon.Storage_Location
   ADD CONSTRAINT Storage_Location_AK1
      UNIQUE (storage_location)
      USING INDEX
   TABLESPACE Lexicon_Index
/

CREATE SEQUENCE Lexicon.Storage_Location_Id_Seq
  INCREMENT BY 1
  START WITH 1000
  MINVALUE 1000
  MAXVALUE 999999999999999999999999999
  NOCYCLE
  NOORDER
  CACHE 20
/

--
-- Foreign Keys
--

ALTER TABLE Lexicon.Container_Type 
	ADD CONSTRAINT Container_Type_FK 
		FOREIGN KEY (storage_condition) 
		REFERENCES Lexicon.Storage_Condition (storage_condition)
/

ALTER TABLE Lexicon.Sample_Type 
	ADD CONSTRAINT Sample_Type_Container_Type_FK 
		FOREIGN KEY (container_type) 
		REFERENCES Lexicon.Container_Type (container_type)
/

ALTER TABLE Lexicon.Sample_Type  
	ADD CONSTRAINT Sample_Type_Storage_Cond_FK 
	FOREIGN KEY (storage_condition) 
		REFERENCES Lexicon.Storage_Condition (storage_condition)
/

ALTER TABLE Lexicon.Storage_Location 
	ADD CONSTRAINT  Storage_Loc_Storage_Cond 
	FOREIGN KEY (storage_condition) 
		REFERENCES Lexicon.Storage_Condition (storage_condition)
/

