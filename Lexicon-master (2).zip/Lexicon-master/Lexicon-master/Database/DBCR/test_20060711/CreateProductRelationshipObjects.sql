CREATE TABLE Lexicon.Product_Relationship(
    Product_Relationship_Id        NUMBER NOT NULL,
    Product_Relationship_Pubkey    VARCHAR2(20) NOT NULL,
    Manufacturing_Name             VARCHAR2(50) NOT NULL,
    CONSTRAINT PRODUCT_RELATIONSHIP_PK
        PRIMARY KEY (Product_Relationship_Id)
        USING INDEX
        TABLESPACE  Lexicon_Index
    )
TABLESPACE  Lexicon_Index
/

ALTER TABLE Lexicon.Product_Relationship
   ADD CONSTRAINT Product_Relationship_Ak
		UNIQUE (Product_Relationship_Pubkey)
		USING INDEX
	TABLESPACE  Lexicon_Index
/

ALTER TABLE Lexicon.Product_Relationship
    ADD CONSTRAINT Product_Relationship_Ak2
        UNIQUE (Manufacturing_Name)
        USING INDEX
    TABLESPACE  Lexicon_Index
/

CREATE TABLE Lexicon.Production_Status(
   Production_Status_Id        NUMBER NOT NULL,
   Production_Status_Name      VARCHAR2(20),
   CONSTRAINT PRODUCTION_STATUS_PK
         PRIMARY KEY (Production_Status_Id)
         USING INDEX
   TABLESPACE  Lexicon_Index
   )
TABLESPACE  Lexicon_Data
/

CREATE TABLE Lexicon.Product_Relationship_Xref(
    Product_Relationship_Xref_Id   NUMBER NOT NULL,
    Product_Relationship_Id        NUMBER NOT NULL,
    Product_Id                     NUMBER NOT NULL,
    Trait_Version                  VARCHAR2(10),
    Production_Status_Id           NUMBER NOT NULL,
    CONSTRAINT PRODUCT_RELATIONSHIP_XREF_PK
        PRIMARY KEY (Product_Relationship_Xref_Id)
        USING INDEX
    TABLESPACE  Lexicon_Index
    )
TABLESPACE  Lexicon_Data
/

ALTER TABLE Lexicon.Product_Relationship_Xref
    ADD CONSTRAINT Product_Relationship_Xref_Ak 
        UNIQUE (Product_Relationship_Id, Product_Id)
        USING INDEX
    TABLESPACE  Lexicon_Index
/

ALTER TABLE Lexicon.Product_Relationship_Xref
    ADD CONSTRAINT Prod_Relate_Xref_Product_Fk
        FOREIGN KEY (Product_Id)
        REFERENCES Lexicon.Pre_Coml_Product (Product_Id)
/

ALTER TABLE Lexicon.Product_Relationship_Xref
    ADD CONSTRAINT Prod_Relate_Xref_Relate_Fk 
        FOREIGN KEY (Product_Relationship_Id)
        REFERENCES Lexicon.Product_Relationship (Product_Relationship_Id)
/

ALTER TABLE Lexicon.Product_Relationship_Xref
    ADD CONSTRAINT Prod_Relate_Xref_Status_Fk
        FOREIGN KEY (Production_Status_Id)
        REFERENCES Lexicon.Production_Status (Production_Status_Id)
/

CREATE SEQUENCE Lexicon.Product_Rel_Pubkey_Seq
   INCREMENT BY 100
   START WITH 1024
   NOMAXVALUE
   NOMINVALUE
   CACHE 20
   NOCYCLE
/

CREATE SEQUENCE Lexicon.Product_Relationship_Seq
  INCREMENT BY 1
  START WITH 1000
  MINVALUE 1
  MAXVALUE 999999999999999999999999999
  NOCYCLE
  NOORDER
  CACHE 20
/

CREATE SEQUENCE Lexicon.Product_Relationship_Xref_Seq
  INCREMENT BY 1
  START WITH 1000
  MINVALUE 1
  MAXVALUE 999999999999999999999999999
  NOCYCLE
  NOORDER
  CACHE 20
/

CREATE SEQUENCE Lexicon.Production_Status_Id_Seq
   INCREMENT BY 1
   START WITH 1000
   MINVALUE 1
   MAXVALUE 999999999999999999999999999
   NOCYCLE
   CACHE 20
/

INSERT INTO Lexicon.Production_Status (Production_Status_Id, Production_Status_Name)
VALUES (Lexicon.Production_Status_Id_Seq.NEXTVAL, 'Active')
/

INSERT INTO Lexicon.Production_Status (Production_Status_Id, Production_Status_Name)
VALUES (Lexicon.Production_Status_Id_Seq.NEXTVAL, 'Backup')
/

INSERT INTO Lexicon.Production_Status (Production_Status_Id, Production_Status_Name)
VALUES (Lexicon.Production_Status_Id_Seq.NEXTVAL, 'Inactive')
/

INSERT INTO Lexicon.Production_Status (Production_Status_Id, Production_Status_Name)
VALUES (Lexicon.Production_Status_Id_Seq.NEXTVAL, 'Primary')
/

