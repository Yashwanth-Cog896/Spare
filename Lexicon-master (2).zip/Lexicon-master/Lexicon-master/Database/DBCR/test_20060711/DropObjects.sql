DROP TABLE Lexicon.Product_Relationship_Xref CASCADE CONSTRAINTS
/

DROP TABLE Lexicon.Product_Relationship CASCADE CONSTRAINTS
/

DROP TABLE Lexicon.Production_Status CASCADE CONSTRAINTS
/

DROP SEQUENCE Lexicon.Product_Rel_Pubkey_Seq
/

DROP SEQUENCE Lexicon.Product_Relationship_Seq
/

DROP SEQUENCE Lexicon.Product_Relationship_Xref_Seq
/

DROP SEQUENCE Lexicon.Production_Status_Id_Seq
/


