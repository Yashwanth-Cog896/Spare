CREATE TABLE LEXICON.VENDOR
(
  VENDOR_ID                       VARCHAR2(10)  NOT NULL,
  CLIENT_ID                       VARCHAR2(3)   NOT NULL,
  SAP_SRCE_SYS_CODE               VARCHAR2(20)  NOT NULL,
  ROW_INSERT_DATE                 DATE,
  ROW_INSERT_USER_ID              VARCHAR2(20),
  ROW_INSERT_TASK_ID              VARCHAR2(35),
  ROW_UPDATE_DATE                 DATE,
  ROW_UPDATE_USER_ID              VARCHAR2(20),
  SUBJECT_AREA_RUN_ID             INTEGER,
  ACTION_TYPE                     VARCHAR2(1),
  LANGUAGE_CODE                   VARCHAR2(1),
  ROW_UPDATE_TASK_ID              VARCHAR2(35),
  NAME_1                          VARCHAR2(35),
    CONSTRAINT PK_VENDOR
        PRIMARY KEY (VENDOR_ID, SAP_SRCE_SYS_CODE, CLIENT_ID)
        USING INDEX
    	TABLESPACE LEXICON_INDEX
)
TABLESPACE LEXICON_DATA
/

CREATE TABLE Lexicon.Vendor_Unique(
    Vendor_Unique_Id               NUMBER NOT NULL,
    Vendor_Unique_Name             VARCHAR2(35) NOT NULL,
    CONSTRAINT VENDOR_UNIQUE_PK
        PRIMARY KEY (Vendor_Unique_Id)
        USING INDEX
        TABLESPACE  Lexicon_Index
)
TABLESPACE  Lexicon_Data
/

ALTER TABLE Lexicon.Vendor_Unique
    ADD CONSTRAINT Vendor_Unique_AK1
        UNIQUE (Vendor_Unique_Name)
        USING INDEX
    TABLESPACE  Lexicon_Index
/

CREATE TABLE Lexicon.Vendor_Unique_Map(
    Vendor_Unique_Map_Id           NUMBER NOT NULL,
    Vendor_Unique_Id               NUMBER NOT NULL,
    Vendor_Id                      VARCHAR2(10) NOT NULL,
    CONSTRAINT VENDOR_UNIQUE_MAP_PK
        PRIMARY KEY (Vendor_Unique_Map_Id)
        USING INDEX
        TABLESPACE  Lexicon_Index
)
TABLESPACE  Lexicon_Data
/

ALTER TABLE Lexicon.Vendor_Unique_Map
    ADD CONSTRAINT Vendor_Unique_Map_Ak1 
        UNIQUE (Vendor_Unique_Id, Vendor_Id)
        USING INDEX
    TABLESPACE  Lexicon_Index
/


ALTER TABLE Lexicon.Vendor_Unique_Map
    ADD CONSTRAINT Vendor_Unique_Map_Unique_Id_Fk 
        FOREIGN KEY (Vendor_Unique_Id)
        REFERENCES LEXICON.Vendor_Unique (Vendor_Unique_Id)
/

CREATE TABLE Lexicon.Vendor_Carrier(
    Vendor_Carrier_Id              NUMBER NOT NULL,
    Vendor_Id                      VARCHAR2(35) NOT NULL,
    CONSTRAINT VENDOR_CARRIER_PK
        PRIMARY KEY (Vendor_Carrier_Id)
        USING INDEX
    TABLESPACE  Lexicon_Index
)
TABLESPACE  Lexicon_Data
/

ALTER TABLE Lexicon.Vendor_Carrier
    ADD CONSTRAINT Vendor_Carrier_Ak1 
        UNIQUE (Vendor_Id)
        USING INDEX
    TABLESPACE  Lexicon_Index
/

CREATE TABLE Lexicon.Dsr_Pull_Sync(
    Dsr_Pull_Sync_Id               NUMBER NOT NULL,
    Table_Name                     VARCHAR2(32) NOT NULL,
    Last_Sync_Run_Id               NUMBER DEFAULT 0  NOT NULL,
    CONSTRAINT DSR_PULL_SYNC_PK
        PRIMARY KEY (Dsr_Pull_Sync_Id)
        USING INDEX
    TABLESPACE  Lexicon_Index
)
TABLESPACE  Lexicon_Data
/

ALTER TABLE Lexicon.Dsr_Pull_Sync
    ADD CONSTRAINT Dsr_Pull_Sync_Ak1 
        UNIQUE (Table_Name)
        USING INDEX
    TABLESPACE  Lexicon_Index
/

