INSERT 
INTO Lexicon.Parent_Crop_Type
VALUES (1, (SELECT crop_id FROM Lexicon.Crop WHERE crop_name = 'CORN'));
