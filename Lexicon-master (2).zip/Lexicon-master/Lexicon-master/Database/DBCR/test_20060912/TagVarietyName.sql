ALTER TABLE Lexicon.Pre_Coml_Product
	DROP CONSTRAINT Pre_Coml_Product_AK2
/

ALTER TABLE Lexicon.Pre_Coml_Product
    MODIFY ustv_name   VARCHAR2(10)
/
 
ALTER TABLE Lexicon.Pre_Coml_Product
    RENAME COLUMN ustv_name TO tag_variety_name
/


 

