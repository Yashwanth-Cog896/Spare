CREATE VIEW Lexicon.Generic_Product_View (
   product_id,
   product_pubkey,
   pre_coml_name,
   tag_variety_name,
   crop_id,
   logical_delete )
AS
SELECT  PCP.product_id,
        PCP.product_pubkey,
        PCP.pre_coml_name,
        PCP.tag_variety_name,
        PCP.crop_id,
        PCP.logical_delete
  FROM  Pre_Coml_Product PCP

UNION

SELECT  P.product_id,
        P.product_pubkey,
        NULL AS pre_com_name,
        NULL AS tag_variety_name,
        BC.crop_id,
        P.logical_delete
  FROM  Product P,
        Bayer_Code BC
 WHERE  P.bayer_code_id = BC.bayer_code_id
/

