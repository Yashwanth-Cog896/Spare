CREATE TABLE Lexicon.Parent_Crop_Type (
	Parent_Crop_Type_Id            NUMBER NOT NULL,
	Crop_Id                        NUMBER NOT NULL,
  	CONSTRAINT PARENT_CROP_TYPE_PK
  		PRIMARY KEY (Parent_Crop_Type_Id)
		USING INDEX
	TABLESPACE  Lexicon_Data)
TABLESPACE  Lexicon_Data
/

ALTER TABLE Lexicon.Parent_Crop_Type
	ADD CONSTRAINT Parent_Crop_Type_Ak 
		UNIQUE (Crop_Id)
		USING INDEX
	TABLESPACE  Lexicon_Index
/

ALTER TABLE Lexicon.Parent_Crop_Type
	ADD CONSTRAINT Parent_Crop_Type_Crop_Fk 
		FOREIGN KEY (Crop_Id)
		REFERENCES LEXICON.Crop (Crop_Id)
/

