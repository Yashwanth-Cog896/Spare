CREATE TABLE Lexicon.Base_Product (
    Base_Product_Id                NUMBER NOT NULL,
    Base_Manufacturing_Name        VARCHAR2(50) NOT NULL,
    Crop_Id                        NUMBER NOT NULL,
    Parent_Product                 VARCHAR2(1) DEFAULT 'n'  NOT NULL,
    CONSTRAINT Base_Product_Pk
        PRIMARY KEY (Base_Product_Id)
        USING INDEX
        TABLESPACE  Lexicon_Index
)
TABLESPACE  Lexicon_Data
/  

ALTER TABLE Lexicon.Base_Product
   ADD CONSTRAINT Base_Product_Ak
		UNIQUE (Base_Manufacturing_Name)
		USING INDEX
	TABLESPACE  Lexicon_Index
/

ALTER TABLE Lexicon.Base_Product
    ADD CONSTRAINT Base_Product_Crop_Fk
        FOREIGN KEY (Crop_Id)
        REFERENCES Lexicon.Crop (Crop_Id)
/

CREATE SEQUENCE Lexicon.Base_Product_Id_Seq
  INCREMENT BY 1
  START WITH 1000
  MINVALUE 1
  MAXVALUE 999999999999999999999999999
  NOCYCLE
  NOORDER
  CACHE 20
/

