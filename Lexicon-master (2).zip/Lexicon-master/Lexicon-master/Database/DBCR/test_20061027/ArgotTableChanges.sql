ALTER TABLE Lexicon.Additional_Material 
    MODIFY (
        active_status NVARCHAR2 (1)
    )
/

ALTER TABLE Lexicon.Additional_Material 
    ADD CONSTRAINT Add_Mat_Active_YesOrNo_CK
        CHECK (active_status = 'y' OR active_status = 'n')
/

ALTER TABLE Lexicon.Additional_Material 
	DROP (user_id, record_date, change_date_time, comment_text)
/



ALTER TABLE Lexicon.Chemical_Name 
    MODIFY (
        active_status NVARCHAR2 (1)
    )
/

ALTER TABLE Lexicon.Chemical_Name 
    ADD CONSTRAINT Chem_Name_Active_YesOrNo_CK
        CHECK (active_status = 'y' OR active_status = 'n')
/

ALTER TABLE Lexicon.Chemical_Name 
	DROP (user_id, record_date, change_date_time, comment_text)
/



ALTER TABLE Lexicon.Container_Type 
    MODIFY (
        active_status NVARCHAR2 (1)
    )
/

ALTER TABLE Lexicon.Container_Type 
    ADD CONSTRAINT Contain_Type_Active_YesOrNo_CK
        CHECK (active_status = 'y' OR active_status = 'n')
/

ALTER TABLE Lexicon.Container_Type 
	DROP (user_id, record_date, change_date_time, comment_text)
/



ALTER TABLE Lexicon.External_Contact 
    MODIFY (
        active_status NVARCHAR2 (1)
    )
/

ALTER TABLE Lexicon.External_Contact 
    ADD CONSTRAINT Ext_Contact_Active_YesOrNo_CK
        CHECK (active_status = 'y' OR active_status = 'n')
/

ALTER TABLE Lexicon.External_Contact 
	DROP (user_id, record_date, change_date_time, comment_text)
/



ALTER TABLE Lexicon.Formulation_Type
    MODIFY (
        active_status NVARCHAR2 (1)
    )
/

ALTER TABLE Lexicon.Formulation_Type 
    ADD CONSTRAINT Ext_Contact_Active_YesOrNo_CK
        CHECK (active_status = 'y' OR active_status = 'n')
/

ALTER TABLE Lexicon.Formulation_Type 
	DROP (user_id, record_date, change_date_time, comment_text)
/

ALTER TABLE Lexicon.Genetic_Background
    MODIFY (
        active_status NVARCHAR2 (1)
    )
/

ALTER TABLE Lexicon.Genetic_Background 
	DROP (user_id, record_date, change_date_time, comment_text)
/

ALTER TABLE Lexicon.Plant_Name
    MODIFY (
        active_status NVARCHAR2 (1)
    )
/

ALTER TABLE Lexicon.Plant_Name 
	DROP (user_id, record_date, change_date_time, comment_text)
/

ALTER TABLE Lexicon.Protein_Name
    MODIFY (
        active_status NVARCHAR2 (1)
    )
/

ALTER TABLE Lexicon.Protein_Name 
	DROP (user_id, record_date, change_date_time, comment_text)
/

ALTER TABLE Lexicon.Sample_Type
    MODIFY (
        active_status NVARCHAR2 (1)
    )
/

ALTER TABLE Lexicon.Sample_Type 
	DROP (user_id, record_date, change_date_time, comment_text)
/

ALTER TABLE Lexicon.Shipping_Condition
    MODIFY (
        active_status NVARCHAR2 (1)
    )
/

ALTER TABLE Lexicon.Shipping_Condition 
	DROP (user_id, record_date, change_date_time, comment_text)
/

ALTER TABLE Lexicon.Storage_Condition
    MODIFY (
        active_status NVARCHAR2 (1)
    )
/

ALTER TABLE Lexicon.Storage_Condition 
	DROP (user_id, record_date, change_date_time, comment_text)
/

ALTER TABLE Lexicon.Storage_Location
    MODIFY (
        active_status NVARCHAR2 (1)
    )
/

ALTER TABLE Lexicon.Storage_Location 
	DROP (user_id, record_date, change_date_time, comment_text)
/

ALTER TABLE Lexicon.Mon_Number
    MODIFY (
        active_status NVARCHAR2 (1)
    )
/

ALTER TABLE Lexicon.Mon_Number
    MODIFY (
        regulated_status NVARCHAR2 (1)
    )
/

ALTER TABLE Lexicon.Mon_Number 
	DROP (user_id, record_date, change_date_time, comment_text)
/


