CREATE TABLE USER_APP_ROLE
(
  USER_APP_ROLE_ID  NUMBER                      NOT NULL,
  USER_PARTY_ID     NUMBER                      NOT NULL,
  APP_ROLE_ID       NUMBER                      NOT NULL
)
TABLESPACE LEXICON_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             64K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


CREATE UNIQUE INDEX USER_APP_ROLE_AK ON USER_APP_ROLE
(USER_PARTY_ID, APP_ROLE_ID)
LOGGING
TABLESPACE LEXICON_DATA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             64K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE OR REPLACE TRIGGER USER_APP_ROLE_TRG
  AFTER INSERT OR DELETE OR UPDATE
  ON LEXICON.USER_APP_ROLE
  FOR EACH ROW
DECLARE
  lOperationType CHAR(1);
  lPrimaryKeyPosition INTEGER := 1;
  lTableName VARCHAR2(30) := 'USER_APP_ROLE';
  lAuditDetailArray Audit_Pkg.Audit_Detail_Array_Type;

BEGIN
  IF Audit_Pkg.Do_Audit_Table_F(lTableName) THEN

    IF INSERTING THEN lOperationType := Audit_Pkg.INSERT_OPERATION;
    ELSIF UPDATING THEN lOperationType := Audit_Pkg.UPDATE_OPERATION;
    ELSIF DELETING THEN lOperationType := Audit_Pkg.DELETE_OPERATION;
    ELSE lOperationType := NULL;
    END IF;

    lAuditDetailArray(1) := Audit_Pkg.Create_Detail_Record_F('USER_APP_ROLE_ID', :NEW.USER_APP_ROLE_ID, :OLD.USER_APP_ROLE_ID);
    lAuditDetailArray(2) := Audit_Pkg.Create_Detail_Record_F('USER_PARTY_ID', :NEW.USER_PARTY_ID, :OLD.USER_PARTY_ID);
    lAuditDetailArray(3) := Audit_Pkg.Create_Detail_Record_F('APP_ROLE_ID', :NEW.APP_ROLE_ID, :OLD.APP_ROLE_ID);

    Audit_Pkg.Write_Audit_P(lTableName , lOperationType, lPrimaryKeyPosition, lAuditDetailArray);
  END IF;
END;
/
SHOW ERRORS;



CREATE SYNONYM LEXICON_USER.USER_APP_ROLE FOR USER_APP_ROLE;


ALTER TABLE USER_APP_ROLE ADD (
  PRIMARY KEY
 (USER_APP_ROLE_ID)
    USING INDEX 
    TABLESPACE LEXICON_DATA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                NEXT             64K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));

ALTER TABLE USER_APP_ROLE ADD (
  CONSTRAINT USER_APP_ROLE_AK
 UNIQUE (USER_PARTY_ID, APP_ROLE_ID)
    USING INDEX 
    TABLESPACE LEXICON_DATA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                NEXT             64K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));


GRANT DELETE, INSERT, SELECT, UPDATE ON  USER_APP_ROLE TO LEXICON_USER;