ALTER TABLE Lexicon.User_App_Role
    ADD CONSTRAINT Fk_App_Role_Id 
        FOREIGN KEY (App_Role_Id)
        REFERENCES Lexicon.App_Role (App_Role_Id)
/

