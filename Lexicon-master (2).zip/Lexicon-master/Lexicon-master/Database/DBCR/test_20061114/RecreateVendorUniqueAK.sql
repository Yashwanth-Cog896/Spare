ALTER TABLE Lexicon.Vendor_Unique_Map
    DROP CONSTRAINT Vendor_Unique_Map_Ak1
/

ALTER TABLE Lexicon.Vendor_Unique_Map
    ADD CONSTRAINT Vendor_Unique_Map_Ak1 
        UNIQUE (Vendor_Id)
        USING INDEX
    TABLESPACE  Lexicon_Index
/




