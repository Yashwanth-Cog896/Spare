BEGIN
    DECLARE 
        prodAdj INTEGER := -300000;
        nameAdj INTEGER := -700000;
        
    BEGIN
        UPDATE  Lexicon.Product_Stage
           SET  product_id = product_id + prodAdj;
           
        UPDATE  Lexicon.Pre_Coml_Product
           SET  product_id = product_id + prodAdj;
         
        UPDATE  Lexicon.Product_Stage
           SET  product_stage_id = product_stage_id + nameAdj;
           
        UPDATE  Lexicon.Audit_Header
           SET  primary_key_field1 = primary_key_field1 + prodAdj
         WHERE  UPPER(table_name) = 'PRE_COML_PRODUCT'
           AND  primary_key_field1 > ABS(prodAdj);
           
        UPDATE  Lexicon.Audit_Detail
           SET  new_value = new_value + prodAdj
         WHERE  UPPER(column_name) = 'PRODUCT_ID'
           AND  new_value > ABS(prodAdj)
           AND  audit_header_id IN 
                (
                    SELECT  audit_header_id
                      FROM  Lexicon.Audit_Header
                     WHERE  UPPER(table_name) = 'PRODUCT_STAGE'
                );
           
        UPDATE  Lexicon.Audit_Detail
           SET  old_value = old_value + prodAdj
         WHERE  UPPER(column_name) = 'PRODUCT_ID'
           AND  old_value IS NOT NULL
           AND  old_value > ABS(prodAdj)
           AND  audit_header_id IN 
                (
                    SELECT  audit_header_id
                      FROM  Lexicon.Audit_Header
                     WHERE  UPPER(table_name) = 'PRODUCT_STAGE'
                );
                
        UPDATE  Lexicon.Audit_Header
           SET  primary_key_field1 = primary_key_field1 + nameAdj
         WHERE  UPPER(table_name) = 'PRODUCT_STAGE'
           AND  primary_key_field1 > ABS(nameAdj);
    END;
END;                        
         
        
           
