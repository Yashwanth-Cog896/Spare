select *
from pre_coml_product
order by product_id;

select *
from product_stage
order by product_stage_id;

select ah.audit_header_id, ah.audit_operation_type, ah.primary_key_field1, ah.process_name
from audit_header ah
where ah.table_name = 'PRE_COML_PRODUCT'
order by ah.primary_key_field1;

select ah.audit_header_id, ah.audit_operation_type, ah.primary_key_field1, ah.process_name
from audit_header ah
where ah.table_name = 'PRODUCT_STAGE'
order by ah.primary_key_field1;

select ad.audit_detail_id, ah.audit_header_id, ah.audit_operation_type, ah.primary_key_field1, 
       ad.column_name, ad.new_value, ad.old_value, ah.process_name
from audit_detail ad,
     ( select * from audit_header where table_name = 'PRODUCT_STAGE') ah
where ad.column_name = 'PRODUCT_ID'
and ad.audit_header_id = ah.audit_header_id
order by ah.primary_key_field1;
    
