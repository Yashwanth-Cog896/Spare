select 'MONPROD' AS "Entity", count(*) AS "Count", min(product_id) AS "Min", max(product_id) AS "Max"
from lexicon.pre_coml_product
where product_id > 0

union

select 'MONNAME' AS "Entity", count(*) AS "Count", min(product_stage_id) AS "Min", max(product_stage_id) AS "Max"
from lexicon.product_stage
where product_stage_id > 0

union

select 'COMPROD' AS "Entity", count(*) AS "Count", min(product_id) AS "Min", max(product_id) AS "Max"
from lexicon.product
where product_id > 0
union

select 'COMPNAME' AS "Entity", count(*) AS "Count", min(product_name_id) AS "Min", max(product_name_id) AS "Max"
from lexicon.product_name
where product_name_id > 0




