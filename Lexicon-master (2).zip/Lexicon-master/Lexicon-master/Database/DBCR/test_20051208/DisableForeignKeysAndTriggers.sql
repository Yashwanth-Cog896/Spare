ALTER TABLE Lexicon.Product_Stage
    DISABLE CONSTRAINT FK_PS_PCPROD_PRODID
/

ALTER TRIGGER Lexicon.Product_Stage_Trg
	DISABLE 
/

ALTER TRIGGER Lexicon.Pre_Coml_Product_Trg
	DISABLE 
/





