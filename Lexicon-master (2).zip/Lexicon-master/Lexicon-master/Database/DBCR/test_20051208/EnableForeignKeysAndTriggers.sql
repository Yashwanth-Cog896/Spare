ALTER TABLE Lexicon.Product_Stage
    ENABLE CONSTRAINT FK_PS_PCPROD_PRODID
/

ALTER TRIGGER Lexicon.Product_Stage_Trg
	ENABLE 
/

ALTER TRIGGER Lexicon.Pre_Coml_Product_Trg
	ENABLE
/


