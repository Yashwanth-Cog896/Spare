/********* Coml_Trait_Stack2 Table *********/
CREATE TABLE Lexicon.Coml_Trait_Stack2(
    Coml_Trait_Stack_Id            NUMBER NOT NULL,
    Reporting_Name                 VARCHAR2(50),
    Stack_Desc                     VARCHAR2(50) NOT NULL,
    Crop_Id                        NUMBER NOT NULL,
    Td_Name                        VARCHAR2(50),
    Stack_Abbr                     VARCHAR2(50) NOT NULL,
    CONSTRAINT COML_TRAIT_STACK2_PK
        PRIMARY KEY (Coml_Trait_Stack_Id)
        USING INDEX
    TABLESPACE  Lexicon_Index
)
TABLESPACE  Lexicon_Data
/

ALTER TABLE Lexicon.Coml_Trait_Stack2
    ADD CONSTRAINT Coml_Triat_Stack2_Ak1 
        UNIQUE (Crop_Id, Stack_Abbr)
        USING INDEX
    TABLESPACE  Lexicon_Index
/

/********* Coml_Trait_Name2 Table *********/
CREATE TABLE Lexicon.Coml_Trait_Name2(
    Coml_Trait_Name_Id             NUMBER NOT NULL,
    Trait_Abbr                     VARCHAR2(8) NOT NULL,
    Trait_Desc                     VARCHAR2(50) NOT NULL,
    Crop_Id                        NUMBER NOT NULL,
    Company_Id                     NUMBER,
    Is_Active                      VARCHAR2(1) NOT NULL,
    CONSTRAINT COML_TRAIT_NAME2_PK
        PRIMARY KEY (Coml_Trait_Name_Id)
        USING INDEX
    TABLESPACE  Lexicon_Index
)
TABLESPACE  Lexicon_Data
/

ALTER TABLE Lexicon.Coml_Trait_Name2
    ADD CONSTRAINT Trueorfalsetraitnameactive 
        CHECK (is_active IN ('y', 'n'))
/

ALTER TABLE Lexicon.Coml_Trait_Name2
    ADD CONSTRAINT Coml_Trait_Name2_Ak1 
        UNIQUE (Trait_Abbr, Crop_Id, Company_Id)
        USING INDEX
    TABLESPACE  Lexicon_Data
/

/********* Coml_Trait_Type_Xref2 Table *********/
CREATE TABLE Lexicon.Coml_Trait_Type_Xref2 (
    Coml_Trait_Type_Xref_Id        NUMBER NOT NULL,
    Coml_Trait_Name_Id             NUMBER NOT NULL,
    Coml_Trait_Type_Id             NUMBER NOT NULL,
    CONSTRAINT COML_TRAIT_TYPE_XREF2_PK
        PRIMARY KEY (Coml_Trait_Type_Xref_Id)
        USING INDEX
    TABLESPACE  Lexicon_Index
)
TABLESPACE  Lexicon_Data
/

ALTER TABLE Lexicon.Coml_Trait_Type_Xref2
    ADD CONSTRAINT Coml_Trait_Type_Xref2_Ak1 
        UNIQUE (Coml_Trait_Name_Id, Coml_Trait_Type_Id)
        USING INDEX
    TABLESPACE  Lexicon_Index
/

/********* Coml_Trait_Stack_Xref2 Table *********/
CREATE TABLE Lexicon.Coml_Trait_Stack_Xref2 (
    Coml_Trait_Stack_Xref_Id       NUMBER NOT NULL,
    Coml_Trait_Name_Id             NUMBER NOT NULL,
    Coml_Trait_Stack_Id            NUMBER NOT NULL,
    CONSTRAINT COML_TRIAT_STACK_XREF_PK
        PRIMARY KEY (Coml_Trait_Stack_Xref_Id)
        USING INDEX
        TABLESPACE  Lexicon_Index
)
TABLESPACE  Lexicon_Data
/

ALTER TABLE Lexicon.Coml_Trait_Stack_Xref2
    ADD CONSTRAINT Coml_Trait_Stack_Xref2_Ak1 
        UNIQUE (Coml_Trait_Name_Id, Coml_Trait_Stack_Id)
        USING INDEX
    TABLESPACE  Lexicon_Index
/

/********* Foreign Key Contraints *********/
ALTER TABLE Lexicon.Coml_Trait_Stack2
    ADD CONSTRAINT Coml_Trait_Stack_Crop_Fk 
        FOREIGN KEY (Crop_Id)
        REFERENCES Lexicon.Crop (Crop_Id)
/

ALTER TABLE Lexicon.Coml_Trait_Name2
    ADD CONSTRAINT Coml_Trait_Name_Crop_Fk 
        FOREIGN KEY (Crop_Id)
        REFERENCES Lexicon.Crop (Crop_Id)
/

ALTER TABLE Lexicon.Coml_Trait_Name2
    ADD CONSTRAINT Coml_Trait_Name_Company_Fk 
        FOREIGN KEY (Company_Id)
        REFERENCES Lexicon.Company (Company_Id)
/

ALTER TABLE Lexicon.Coml_Trait_Type_Xref2
    ADD CONSTRAINT Cttx_Trait_Name_Fk 
        FOREIGN KEY (Coml_Trait_Name_Id)
        REFERENCES Lexicon.Coml_Trait_Name2 (Coml_Trait_Name_Id)
/

ALTER TABLE Lexicon.Coml_Trait_Type_Xref2
    ADD CONSTRAINT Cttx_Trait_Type_Fk 
        FOREIGN KEY (Coml_Trait_Type_Id)
        REFERENCES Lexicon.Coml_Trait_Type (Coml_Trait_Type_Id)
/

ALTER TABLE Lexicon.Coml_Trait_Stack_Xref2
    ADD CONSTRAINT Ctsx_Stack_Fk 
        FOREIGN KEY (Coml_Trait_Stack_Id)
        REFERENCES Lexicon.Coml_Trait_Stack2 (Coml_Trait_Stack_Id)
/

ALTER TABLE Lexicon.Coml_Trait_Stack_Xref2
    ADD CONSTRAINT Ctsx_Trait_Name_Fk 
        FOREIGN KEY (Coml_Trait_Name_Id)
        REFERENCES Lexicon.Coml_Trait_Name2 (Coml_Trait_Name_Id)
/



