ALTER TABLE Lexicon.Product_GP_Action
    ADD CONSTRAINT Product_GP_Action_PK
        PRIMARY KEY (Product_GP_Action_ID)
        USING INDEX
    TABLESPACE Lexicon_Index
/

ALTER TABLE Lexicon.Product_GP_Action
    ADD CONSTRAINT Fk_PGA_PCProd_ProdPubkey 
        FOREIGN KEY (Product_Pubkey)
        REFERENCES Lexicon.Pre_Coml_Product (Product_Pubkey)
/

ALTER TABLE Lexicon.Product_GP_Action
    MODIFY (Product_GP_Action_ID NOT NULL)
/

ALTER TABLE Lexicon.Product_GP_Action
    MODIFY (Product_Pubkey NOT NULL)
/

ALTER TABLE Lexicon.Product_GP_Action
    MODIFY (GP_Key NOT NULL)
/


