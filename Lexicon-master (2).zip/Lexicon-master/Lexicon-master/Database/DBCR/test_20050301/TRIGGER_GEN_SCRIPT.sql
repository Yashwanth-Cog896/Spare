BEGIN
    DECLARE
    	lSchema VARCHAR2(30) := 'LEXICON';
        
        TYPE User_Table_Array_Type
        IS
            TABLE OF Sys.User_Tables.table_name%TYPE
            INDEX BY BINARY_INTEGER;
        
        TYPE Table_Columns_Array_Type
        IS
            TABLE OF Sys.User_Tab_Columns.column_name%TYPE
            INDEX BY BINARY_INTEGER;
        
        lUserTableArray User_Table_Array_Type;
        lTableColumnsArray Table_Columns_Array_Type;
        lTableName Sys.User_Tables.table_name%TYPE;
        lColumnName Sys.User_Tab_Columns.column_name%TYPE;
        lPKColumnName Sys.User_Tab_Columns.column_name%TYPE;
        lPrimaryKeyPosition INTEGER;
        lDMLString VARCHAR2(4000);
        
    BEGIN
        SELECT  table_name
          BULK  COLLECT INTO lUserTableArray
          FROM  Sys.All_Tables
         WHERE  owner = lSchema
           AND  table_name IN (
                    'PRODUCT', 'PRODUCT_NAME', 'BRAND', 'COUNTRY', 'COMPANY', 
                    'COML_TRAIT', 'COML_TRAIT_NAME', 'COML_TRAIT_TYPE', 'COML_TRAIT_TYPE_XREF', 
                    'COML_TRAIT_STACK', 'COML_TRAIT_STACK_XREF', 'COML_TRAIT_STACK_NAME_XREF'
					);
        
        -- For now we are explicitly naming the tables, 
        -- eventually will change the script to generate triggers
        -- on all tables except those that begin with AUDIT_ 
        -- i.e.
        -- WHERE table_name NOT LIKE ('AUDIT_%);
         
        FOR i IN 1..lUserTableArray.COUNT
        LOOP
          BEGIN
            lTableName := lUserTableArray(i);
        
            SELECT  column_name
              BULK  COLLECT INTO lTableColumnsArray
              FROM  Sys.All_Tab_Columns
             WHERE  owner = lSchema
               AND  Table_Name = lTableName;
        
            BEGIN             
                SELECT  column_name
                  INTO  lPKColumnName
                  FROM  Sys.All_Cons_Columns
                 WHERE  owner = lSchema
                   AND  Constraint_Name IN (
                            SELECT Constraint_Name
        	                  FROM Sys.All_Constraints
            	             WHERE Constraint_Type = 'P'
                	           AND owner = lSchema
                               AND Table_Name = lTableName);
            
            EXCEPTION 
                WHEN NO_DATA_FOUND THEN
                    raise_application_error(-20499, 'Unable to determine the primary key column name for the table ' || lTableName);
                WHEN TOO_MANY_ROWS THEN
                    raise_application_error(-20498, 'More the 1 primary key column was found for the table ' || lTableName); 
            END;
            
            lPrimaryKeyPosition := -1;
            FOR j IN 1..lTableColumnsArray.COUNT
            LOOP
            	IF lTableColumnsArray(j) = lPKColumnName THEN
            		lPrimaryKeyPosition := j;
            	END IF;
            END LOOP;
            
            IF lPrimaryKeyPosition = -1 THEN
        		raise_application_error(-20497, 'Unable to determine primary key column id for the table ' || lTableName);
			END IF;
            	
            lDMLString := 'CREATE OR REPLACE TRIGGER ' || lSchema || '.' || lTableName || '_TRG' || CHR(10) ||
                          '  AFTER INSERT OR DELETE OR UPDATE' || CHR(10) ||
                          '  ON ' || lTableName || CHR(10) ||
                          '  FOR EACH ROW' || CHR(10) ||
                          CHR(10) ||
                          'DECLARE' || CHR(10) ||
                          '  lOperationType CHAR(1);' || CHR(10) ||
                          '  lPrimaryKeyPosition INTEGER := ' || TO_CHAR(lPrimaryKeyPosition) || ';' || CHR(10) ||
                          '  lTableName VARCHAR2(30) := ''' || lTableName || ''';' || CHR(10) ||
                          '  lAuditDetailArray Audit_Pkg.Audit_Detail_Array_Type;' || CHR(10) ||
                          CHR(10) ||
                          'BEGIN' || CHR(10) ||
                          '  IF Audit_Pkg.Do_Audit_Table_F(lTableName) THEN' || CHR(10) ||
                          CHR(10) ||
                          '    IF INSERTING THEN lOperationType := Audit_Pkg.INSERT_OPERATION;' || CHR(10) ||
                          '    ELSIF UPDATING THEN lOperationType := Audit_Pkg.UPDATE_OPERATION;' || CHR(10) ||
                          '    ELSIF DELETING THEN lOperationType := Audit_Pkg.DELETE_OPERATION;' || CHR(10) ||
                          '    ELSE lOperationType := NULL;' || CHR(10) ||
                          '    END IF;' || CHR(10) ||
                          CHR(10);
        
            FOR j IN 1..lTableColumnsArray.COUNT
            LOOP
                lColumnName := lTableColumnsArray(j);
                lDMLString := lDMLString || '    ' ||
                              'lAuditDetailArray(' || TO_CHAR(j) || ') := ' ||
                                  'Audit_Pkg.Create_Detail_Record_F(' || 
                                      '''' || lColumnName || ''', ' ||
                                      ':NEW.' || lColumnName || ', ' ||
                                      ':OLD.' || lColumnName || 
                                  ');' || CHR(10);
            END LOOP;
        
            lDMLString := lDMLString || CHR(10) || 
                        '    Audit_Pkg.Write_Audit_P(lTableName , lOperationType, lPrimaryKeyPosition, lAuditDetailArray);' || CHR(10) ||
                        '  END IF;' || CHR(10) ||
                        'END;';
            
            EXECUTE IMMEDIATE lDMLString;
            DBMS_OUTPUT.Put_Line(lTableName || '_TRG trigger created (or replaced)');
        
          EXCEPTION
            WHEN OTHERS THEN
                DBMS_OUTPUT.Put_Line(SQLERRM);
          END;
		  
        END LOOP;
    END;
END;
/

