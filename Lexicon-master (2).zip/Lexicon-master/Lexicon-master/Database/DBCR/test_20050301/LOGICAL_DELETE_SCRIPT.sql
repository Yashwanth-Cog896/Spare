DROP TRIGGER Lexicon.Product_Trg
/

DROP TRIGGER Lexicon.Product_Name_Trg
/

ALTER TABLE Lexicon.Product 
    ADD (logical_delete VARCHAR2 (1) DEFAULT 'n' NOT NULL)
/

ALTER TABLE Lexicon.Product_Name
    ADD (logical_delete VARCHAR2 (1) DEFAULT 'n' NOT NULL)
/

ALTER TABLE Lexicon.Product
    ADD CONSTRAINT TrueOrFalse305 
    CHECK (logical_delete IN ('y', 'n'))
/

ALTER TABLE Lexicon.Product_Name
    ADD CONSTRAINT TrueOrFalse306 
    CHECK (logical_delete IN ('y', 'n'))
/


