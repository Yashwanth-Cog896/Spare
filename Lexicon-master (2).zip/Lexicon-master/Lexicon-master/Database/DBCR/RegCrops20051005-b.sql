-- disable trigger
ALTER trigger BAYER_CODE_TRG DISABLE;

-- add data
declare
vid number;
begin
  for rec in (select bayer_code_id from bayer_code) loop
    select bayer_code_pubkey_seq.nextval into vid from dual;
    update bayer_code set bayer_code_pubkey = vid where bayer_code_id = rec.bayer_code_id;
  end loop;
end;
/

commit;

-- add additional constraints
ALTER table bayer_code modify (bayer_code_pubkey NOT NULL);
ALTER TABLE bayer_code
ADD CONSTRAINT BAYER_CODE_AK2
		UNIQUE (bayer_code_pubkey)
		USING INDEX
	TABLESPACE  Lexicon_Index;

-- enable trigger
ALTER trigger BAYER_CODE_TRG ENABLE;
