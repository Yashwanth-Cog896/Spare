CREATE OR REPLACE TRIGGER LEXICON.PRODUCT_NAME_TRG
  AFTER INSERT OR DELETE OR UPDATE
  ON LEXICON.PRODUCT_NAME
  FOR EACH ROW
DECLARE
  lOperationType CHAR(1);
  lPrimaryKeyPosition INTEGER := 1;
  lTableName VARCHAR2(30) := 'PRODUCT_NAME';
  lAuditDetailArray Audit_Pkg.Audit_Detail_Array_Type;
BEGIN
  IF Audit_Pkg.Do_Audit_Table_F(lTableName) THEN
    IF INSERTING THEN lOperationType := Audit_Pkg.INSERT_OPERATION;
    ELSIF UPDATING THEN lOperationType := Audit_Pkg.UPDATE_OPERATION;
    ELSIF DELETING THEN lOperationType := Audit_Pkg.DELETE_OPERATION;
    ELSE lOperationType := NULL;
    END IF;
    lAuditDetailArray(1) := Audit_Pkg.Create_Detail_Record_F('PRODUCT_NAME_ID', :NEW.PRODUCT_NAME_ID, :OLD.PRODUCT_NAME_ID);
    lAuditDetailArray(2) := Audit_Pkg.Create_Detail_Record_F('PRODUCT_NAME_PUBKEY', :NEW.PRODUCT_NAME_PUBKEY, :OLD.PRODUCT_NAME_PUBKEY);
    lAuditDetailArray(3) := Audit_Pkg.Create_Detail_Record_F('PRODUCT_NAME', :NEW.PRODUCT_NAME, :OLD.PRODUCT_NAME);
    lAuditDetailArray(4) := Audit_Pkg.Create_Detail_Record_F('PRODUCT_ID', :NEW.PRODUCT_ID, :OLD.PRODUCT_ID);
    lAuditDetailArray(5) := Audit_Pkg.Create_Detail_Record_F('COML_TRAIT_STACK_ID', :NEW.COML_TRAIT_STACK_ID, :OLD.COML_TRAIT_STACK_ID);
    lAuditDetailArray(6) := Audit_Pkg.Create_Detail_Record_F('COUNTRY_ID', :NEW.COUNTRY_ID, :OLD.COUNTRY_ID);
    lAuditDetailArray(7) := Audit_Pkg.Create_Detail_Record_F('BRAND_ID', :NEW.BRAND_ID, :OLD.BRAND_ID);
    lAuditDetailArray(8) := Audit_Pkg.Create_Detail_Record_F('COMMERCIAL_MATURITY', :NEW.COMMERCIAL_MATURITY, :OLD.COMMERCIAL_MATURITY);
    lAuditDetailArray(9) := Audit_Pkg.Create_Detail_Record_F('VERIFIED_DATA_SOURCE', :NEW.VERIFIED_DATA_SOURCE, :OLD.VERIFIED_DATA_SOURCE);
    lAuditDetailArray(10) := Audit_Pkg.Create_Detail_Record_F('DATA_SOURCE_YEAR', :NEW.DATA_SOURCE_YEAR, :OLD.DATA_SOURCE_YEAR);
    lAuditDetailArray(11) := Audit_Pkg.Create_Detail_Record_F('COMMENTS', :NEW.COMMENTS, :OLD.COMMENTS);
    lAuditDetailArray(12) := Audit_Pkg.Create_Detail_Record_F('IS_ACTIVE', :NEW.IS_ACTIVE, :OLD.IS_ACTIVE);
    lAuditDetailArray(13) := Audit_Pkg.Create_Detail_Record_F('LOGICAL_DELETE', :NEW.LOGICAL_DELETE, :OLD.LOGICAL_DELETE);
    Audit_Pkg.Write_Audit_P(lTableName , lOperationType, lPrimaryKeyPosition, lAuditDetailArray);
  END IF;
END;

