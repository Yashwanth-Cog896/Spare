RENAME Product_Name_New TO Product_Name
/

