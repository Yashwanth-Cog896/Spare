INSERT INTO Lexicon.Product_Name_New
	        (product_name_id,
	         product_name_pubkey,
	         product_name,
	         product_id,
	         coml_trait_stack_id,
	         country_id,
	         brand_id,
	         commercial_maturity,
	         verified_data_source,
	         data_source_year,
	         comments,
	         is_active,
	         logical_delete)

	SELECT   product_name_id,
	         product_name_pubkey,
	         product_name,
	         product_id,
	         coml_trait_stack_id,
	         country_id,
	         brand_id,
	         commercial_maturity,
	         verified_data_source,
	         TO_CHAR(data_source_year),
	         comments,
	         is_active,
	         logical_delete
	  FROM   Lexicon.Product_Name;

