ALTER TABLE Lexicon.Product_Name
	ADD CONSTRAINT Product_Name_PK
		PRIMARY KEY(product_name_id)
		USING INDEX
TABLESPACE  Lexicon_Index
/

ALTER TABLE Lexicon.Product_Name
	ADD CONSTRAINT Product_Name_AK2 
		UNIQUE (product_name_pubkey)
		USING INDEX
TABLESPACE  Lexicon_Index
/

CREATE INDEX Lexicon.Product_Name_Idx1 
	ON Lexicon.Product_Name(
		brand_id                        ASC
)
TABLESPACE  Lexicon_Index
/

CREATE INDEX Lexicon.Product_Name_Idx3 
	ON Lexicon.Product_Name(
  		country_id                      ASC
)
TABLESPACE  Lexicon_Index
/

ALTER TABLE Lexicon.Product_Name
	ADD CONSTRAINT trueorfalse204 
		CHECK (is_active IN ('y', 'n'))
/

ALTER TABLE Lexicon.Product_Name
	ADD CONSTRAINT trueorfalse301 
		CHECK (logical_delete IN ('y', 'n'))
/

ALTER TABLE Lexicon.Product_Name
	ADD CONSTRAINT FK_ProdName_Prod_ProdID 
		FOREIGN KEY (product_id)
		REFERENCES Lexicon.Product (product_id)
/

ALTER TABLE Lexicon.Product_Name
	ADD CONSTRAINT FK_ProdName_Brand_BrandID 
		FOREIGN KEY (brand_id)
		REFERENCES Lexicon.Brand (brand_id)
/

ALTER TABLE Lexicon.Product_Name
	ADD CONSTRAINT FK_Prod_Name_Country_CountryID 
		FOREIGN KEY (country_id)
		REFERENCES Lexicon.Country (country_id)
/

ALTER TABLE Lexicon.Product_Name
	ADD CONSTRAINT FK_Product_Name_Trait_Stack_ID 
		FOREIGN KEY (coml_trait_stack_id)
		REFERENCES Lexicon.Coml_Trait_Stack (coml_trait_stack_id)
/

