CREATE TABLE Lexicon.Product_Name_New(
    product_name_id                NUMBER NOT NULL,
    product_name_pubkey            VARCHAR2(20) NOT NULL,
    product_name                   VARCHAR2(50) NOT NULL,
    product_id                     NUMBER NOT NULL,
    coml_trait_stack_id            NUMBER,
    country_id                     NUMBER NOT NULL,
    brand_id                       NUMBER NOT NULL,
    commercial_maturity            NUMBER(6,1),
    verified_data_source           VARCHAR2(20),
    data_source_year               VARCHAR2(20),
    comments                       VARCHAR2(2000),
    is_active                      VARCHAR2(1) NOT NULL,
    logical_delete                 VARCHAR2(1) DEFAULT 'n'  NOT NULL
)
TABLESPACE  Lexicon_Data
/

