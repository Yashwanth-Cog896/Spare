DROP TABLE Lexicon.User_Preference CASCADE CONSTRAINTS
/

DROP TABLE Lexicon.User_Preference_Definition CASCADE CONSTRAINTS
/

CREATE TABLE Lexicon.User_Preference(
    user_preference_id             NUMBER NOT NULL,
    user_object_id                 NUMBER NOT NULL,
    preference_definition_name     VARCHAR2(50) NOT NULL,
    default_value                  VARCHAR2(100),
    
    CONSTRAINT User_Preference_PK
        PRIMARY KEY (user_preference_id)
        USING INDEX
        TABLESPACE  Lexicon_Index
  )
  TABLESPACE Lexicon_Data
/

ALTER TABLE Lexicon.User_Preference
    ADD CONSTRAINT User_Preference_AK 
        UNIQUE (user_object_id, preference_definition_name)
        USING INDEX
        TABLESPACE  Lexicon_Index
/


