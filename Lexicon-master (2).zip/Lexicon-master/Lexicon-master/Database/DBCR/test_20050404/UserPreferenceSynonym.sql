-- Start of DDL Script for Table LEXICON.USER_PREFERENCE
-- Generated 4-Apr-2005 16:19:06 from LEXICON@DSBREED_DEVL.MONSANTO.COM

CREATE TABLE lexicon.user_preference
    (user_preference_id             NUMBER NOT NULL,
    user_object_id                 NUMBER NOT NULL,
    preference_definition_name     VARCHAR2(50) NOT NULL,
    default_value                  VARCHAR2(100)
  ,
  CONSTRAINT USER_PREFERENCE_PK
  PRIMARY KEY (user_preference_id)
  USING INDEX
  PCTFREE     10
  INITRANS    2
  MAXTRANS    255
  TABLESPACE  lexicon_index
  STORAGE   (
    INITIAL     65536
    NEXT        65536
    PCTINCREASE 0
    MINEXTENTS  1
    MAXEXTENTS  2147483645
  ))
  PCTFREE     10
  PCTUSED     40
  INITRANS    1
  MAXTRANS    255
  TABLESPACE  lexicon_data
  STORAGE   (
    INITIAL     65536
    NEXT        65536
    PCTINCREASE 0
    MINEXTENTS  1
    MAXEXTENTS  2147483645
  )
/

-- Create synonym USER_PREFERENCE
CREATE SYNONYM lexicon.user_preference
  FOR lexicon.user_preference
/

-- Grants for Table
GRANT DELETE ON lexicon.user_preference TO lexicon_user
/
GRANT INSERT ON lexicon.user_preference TO lexicon_user
/
GRANT SELECT ON lexicon.user_preference TO lexicon_user
/
GRANT UPDATE ON lexicon.user_preference TO lexicon_user
/
GRANT DELETE ON lexicon.user_preference TO ngscho
/
GRANT INSERT ON lexicon.user_preference TO ngscho
/
GRANT SELECT ON lexicon.user_preference TO ngscho
/
GRANT UPDATE ON lexicon.user_preference TO ngscho
/
GRANT DELETE ON lexicon.user_preference TO lexicon_rw_role
/
GRANT INSERT ON lexicon.user_preference TO lexicon_rw_role
/
GRANT SELECT ON lexicon.user_preference TO lexicon_rw_role
/
GRANT UPDATE ON lexicon.user_preference TO lexicon_rw_role
/
GRANT SELECT ON lexicon.user_preference TO lexicon_ro_role
/



-- Constraints for LEXICON.USER_PREFERENCE

ALTER TABLE lexicon.user_preference
ADD CONSTRAINT user_preference_ak UNIQUE (user_object_id, 
  preference_definition_name)
USING INDEX
  PCTFREE     10
  INITRANS    2
  MAXTRANS    255
  TABLESPACE  lexicon_index
  STORAGE   (
    INITIAL     65536
    NEXT        65536
    PCTINCREASE 0
    MINEXTENTS  1
    MAXEXTENTS  2147483645
  )
/


-- End of DDL Script for Table LEXICON.USER_PREFERENCE

