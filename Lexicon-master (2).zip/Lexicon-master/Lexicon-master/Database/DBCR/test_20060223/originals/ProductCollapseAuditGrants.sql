GRANT SELECT ON lexicon.prod_collpse_audit_dtl_id_seq TO lexicon_user, ngscho;
GRANT SELECT ON lexicon.prod_collpse_audit_hdr_id_seq TO lexicon_user, ngscho;

GRANT SELECT, INSERT ON lexicon.product_collapse_audit_detail TO lexicon_user, ngscho;
GRANT SELECT, INSERT ON lexicon.product_collapse_audit_header TO lexicon_user, ngscho;