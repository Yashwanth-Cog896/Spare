CREATE TABLE Lexicon.product_collapse_audit_header
    (
    header_id                      NUMBER NOT NULL,
    entry_date                     DATE NOT NULL,
    src_product_pubkey             VARCHAR2(20),
    src_product_level_name         VARCHAR2(50),
    is_src_competitive             VARCHAR2(1),
    dst_product_pubkey             VARCHAR2(20),
    dst_product_level_name         VARCHAR2(50),
    is_dst_competitive             VARCHAR2(1),
    crop_name                      VARCHAR2(50),
    remove_src                     VARCHAR2(1),
    audit_requestor                VARCHAR2(50),
    audit_comment                  VARCHAR2(4000),
    user_name                      VARCHAR2(50)
    )
TABLESPACE Lexicon_Data
/

ALTER TABLE Lexicon.product_collapse_audit_header
	ADD CONSTRAINT prod_collapse_audit_header_pk 
		PRIMARY KEY (header_id)
		USING INDEX
	TABLESPACE Lexicon_Index
/


CREATE TABLE Lexicon.product_collapse_audit_detail
    (detail_id                      NUMBER NOT NULL,
    header_id                      NUMBER NOT NULL,
    product_pubkey                 VARCHAR2(20),
    product_name_pubkey            VARCHAR2(20),
    product_name                   VARCHAR2(50),
    brand_name                     VARCHAR2(50),
    country_abbr                   VARCHAR2(3),
    action                         VARCHAR2(10));

ALTER TABLE Lexicon.product_collapse_audit_detail
	ADD CONSTRAINT product_collapse_audit_dtl_pk 
		PRIMARY KEY (detail_id)
		USING INDEX
	TABLESPACE Lexicon_Index
/


ALTER TABLE Lexicon.product_collapse_audit_detail
    ADD CONSTRAINT fk_product_collapse_header_id 
        FOREIGN KEY (header_id)
        REFERENCES product_collapse_audit_header (header_id)
/

CREATE SEQUENCE Lexicon.prod_collpse_audit_dtl_id_seq
  INCREMENT BY 1
  START WITH 2000
  MINVALUE 1
  MAXVALUE 999999999999999999999999999
  NOCYCLE
  NOORDER
  CACHE 30
/

CREATE SEQUENCE Lexicon.prod_collpse_audit_hdr_id_seq
  INCREMENT BY 1
  START WITH 2000
  MINVALUE 1
  MAXVALUE 999999999999999999999999999
  NOCYCLE
  NOORDER
  CACHE 30
/
