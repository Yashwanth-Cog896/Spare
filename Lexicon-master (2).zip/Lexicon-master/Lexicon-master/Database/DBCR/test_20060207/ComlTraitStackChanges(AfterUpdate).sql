ALTER TABLE Lexicon.Coml_Trait_Stack2
	MODIFY (
  		COML_TRAIT_STACK_PUBKEY NOT NULL
	)
/

ALTER TABLE Lexicon.Coml_Trait_Stack2
    ADD CONSTRAINT Coml_Trait_Stack2_AK2 
        UNIQUE (coml_trait_stack_pubkey)
        USING INDEX
    TABLESPACE  Lexicon_Index
/

ALTER TRIGGER Lexicon.Coml_Trait_Stack2_TRG ENABLE
/


