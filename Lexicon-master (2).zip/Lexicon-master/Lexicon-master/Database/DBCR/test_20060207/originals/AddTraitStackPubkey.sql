-- create coml_trait_stack_pubkey_seq
CREATE SEQUENCE coml_trait_stack_pubkey_seq
INCREMENT BY 100
START WITH 1023
MINVALUE 1000
MAXVALUE 999999999999999999999999999
CACHE 20
NOCYCLE
NOORDER
;

-- disable trigger
ALTER trigger COML_TRAIT_STACK2_TRG DISABLE;

-- alter table
ALTER table coml_trait_stack2 add coml_trait_stack_pubkey VARCHAR2(20);

-- add data
declare
vid number;
begin
  for rec in (select coml_trait_stack_id from coml_trait_stack2) loop
    select coml_trait_stack_pubkey_seq.nextval into vid from dual;
    update coml_trait_stack2 set coml_trait_stack_pubkey = vid where coml_trait_stack_id = rec.coml_trait_stack_id;
  end loop;
end;
/

-- add additional constraints
ALTER table coml_trait_stack2 modify (coml_trait_stack_pubkey NOT NULL);

ALTER TABLE coml_trait_stack2
   ADD CONSTRAINT COML_TRAIT_STACK2_AK2
		UNIQUE (coml_trait_stack_pubkey)
		USING INDEX
	TABLESPACE  Lexicon_Index;

-- enable trigger
ALTER trigger COML_TRAIT_STACK2_TRG ENABLE;

COMMIT;