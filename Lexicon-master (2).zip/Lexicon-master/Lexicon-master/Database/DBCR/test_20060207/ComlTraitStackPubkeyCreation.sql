UPDATE Lexicon.Coml_Trait_Stack2
   SET coml_trait_stack_pubkey = Coml_Trait_Stack_Pubkey_Seq.NEXTVAL;
   

