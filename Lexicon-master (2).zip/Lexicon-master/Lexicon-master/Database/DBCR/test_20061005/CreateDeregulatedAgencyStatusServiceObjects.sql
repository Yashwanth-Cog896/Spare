CREATE TABLE Lexicon.Regulatory_Region(
    Regulatory_Region_Id        NUMBER NOT NULL,
    Regulatory_Region_Pubkey    VARCHAR2(20) NOT NULL,
    Regulatory_Region_Abbr      VARCHAR2(3) NOT NULL,
    Regulatory_Region_Name      VARCHAR2(80) NOT NULL,
    CONSTRAINT REGULATORY_REGION_PK
        PRIMARY KEY (Regulatory_Region_Id)
        USING INDEX
        TABLESPACE  Lexicon_Index
)
TABLESPACE  Lexicon_Data
/

ALTER TABLE Lexicon.Regulatory_Region
   ADD CONSTRAINT Regulatory_Region_Ak
		UNIQUE (Regulatory_Region_Pubkey)
		USING INDEX
	TABLESPACE  Lexicon_Index
/

ALTER TABLE Lexicon.Regulatory_Region
    ADD CONSTRAINT Regulatory_Region_Ak2
        UNIQUE (Regulatory_Region_Abbr)
        USING INDEX
    TABLESPACE  Lexicon_Index
/

ALTER TABLE Lexicon.Regulatory_Region
    ADD CONSTRAINT Regulatory_Region_Ak3
        UNIQUE (Regulatory_Region_Name)
        USING INDEX
    TABLESPACE  Lexicon_Index
/

CREATE SEQUENCE Lexicon.Regulatory_Region_Seq
  INCREMENT BY 1
  START WITH 1000
  MINVALUE 1000
  MAXVALUE 999999999999999999999999999
  NOCYCLE
  NOORDER
  CACHE 20
/

CREATE SEQUENCE Lexicon.Regulatory_Region_Pubkey_Seq
   INCREMENT BY 100
   START WITH 1025
   NOMINVALUE
   NOMAXVALUE
   NOCYCLE
   NOORDER
   CACHE 20
/

CREATE TABLE Lexicon.Ctry_Reg_Region_Xref(
    Ctry_Reg_Region_Xref_Id     NUMBER NOT NULL,
    Country_Id                  NUMBER NOT NULL,
    Regulatory_Region_Id        NUMBER NOT NULL,
    CONSTRAINT CTRY_REG_REGION_XREF_PK
        PRIMARY KEY (Ctry_Reg_Region_Xref_Id)
        USING INDEX
        TABLESPACE  Lexicon_Index
)
TABLESPACE Lexicon_Data
/

ALTER TABLE Lexicon.Ctry_Reg_Region_Xref
    ADD CONSTRAINT Ctry_RR_Xref_Ctry_Fk
        FOREIGN KEY (Country_Id)
        REFERENCES Lexicon.Country (Country_Id)
/

ALTER TABLE Lexicon.Ctry_Reg_Region_Xref
    ADD CONSTRAINT Ctry_RR_Xref_RR_Fk
        FOREIGN KEY (Regulatory_Region_Id)
        REFERENCES Lexicon.Regulatory_Region (Regulatory_Region_Id)
/

ALTER TABLE Lexicon.Ctry_Reg_Region_Xref
	ADD CONSTRAINT Ctry_Reg_Region_Ak
        UNIQUE (Regulatory_Region_Id, Country_Id)
        USING INDEX
    TABLESPACE  Lexicon_Index
/

CREATE SEQUENCE Lexicon.Ctry_Reg_Region_Xref_Seq
  INCREMENT BY 1
  START WITH 1000
  MINVALUE 1
  MAXVALUE 999999999999999999999999999
  NOCYCLE
  NOORDER
  CACHE 20
/

CREATE TABLE Lexicon.Regulatory_Agency(
    Regulatory_Agency_Id        NUMBER NOT NULL,
    Regulatory_Agency_Pubkey    VARCHAR2(20) NOT NULL,
    Regulatory_Agency_Name      VARCHAR2(50) NOT NULL,
    Regulatory_Region_Id        NUMBER NOT NULL,
    CONSTRAINT REGULATORY_AGENCY_PK
        PRIMARY KEY (Regulatory_Agency_Id)
        USING INDEX
        TABLESPACE  Lexicon_Index
)
TABLESPACE Lexicon_Data
/

ALTER TABLE Lexicon.Regulatory_Agency
   ADD CONSTRAINT Regulatory_Agency_Ak
		UNIQUE (Regulatory_Agency_Pubkey)
		USING INDEX
	TABLESPACE  Lexicon_Index
/

ALTER TABLE Lexicon.Regulatory_Agency
    ADD CONSTRAINT Regulatory_Agency_RR_FK
        FOREIGN KEY (Regulatory_Region_Id)
        REFERENCES Lexicon.Regulatory_Region (Regulatory_Region_Id)
/

ALTER TABLE Lexicon.Regulatory_Agency
    ADD CONSTRAINT Regulatory_Agency_Ak2
        UNIQUE (Regulatory_Agency_Name, Regulatory_Region_Id)
        USING INDEX
    TABLESPACE  Lexicon_Index
/

CREATE SEQUENCE Lexicon.Regulatory_Agency_Seq
  INCREMENT BY 1
  START WITH 1000
  MINVALUE 1
  MAXVALUE 999999999999999999999999999
  NOCYCLE
  NOORDER
  CACHE 20
/

CREATE SEQUENCE Lexicon.Regulatory_Agency_Pubkey_Seq
   INCREMENT BY 100
   START WITH 1026
   NOMAXVALUE
   NOMINVALUE
   CACHE 20
   NOCYCLE
/

CREATE TABLE Lexicon.Regulatory_Status_Type(
    Status_Type_Id         NUMBER NOT NULL,
    Status_Name            VARCHAR2(10) NOT NULL,
    Is_Deregulated         VARCHAR2(1) NOT NULL,
    CONSTRAINT REG_STATUS_TYPE_PK
        PRIMARY KEY (Status_Type_Id)
        USING INDEX
        TABLESPACE  Lexicon_Index
)
TABLESPACE Lexicon_Data
/

ALTER TABLE Lexicon.Regulatory_Status_Type
ADD CONSTRAINT True_Or_False_RAS CHECK (Is_Deregulated IN ('y', 'n'))
/

CREATE TABLE Lexicon.Regulatory_Agency_Status(
    Regulatory_Agency_Status_Id    NUMBER NOT NULL,
    Coml_Trait_Stack_Id            NUMBER NOT NULL,
    Regulatory_Agency_Id           NUMBER NOT NULL,
    Status_Type_Id                 NUMBER NOT NULL,
    Notification_Date              DATE NOT NULL,
    CONSTRAINT REGULATORY_AGENCY_STATUS_PK
        PRIMARY KEY (Regulatory_Agency_Status_Id)
        USING INDEX
        TABLESPACE  Lexicon_Index
)
TABLESPACE Lexicon_Data
/

ALTER TABLE Lexicon.Regulatory_Agency_Status
    ADD CONSTRAINT Reg_Agncy_Stat_Trait_Stack_Fk
        FOREIGN KEY (Coml_Trait_Stack_Id)
        REFERENCES Lexicon.Coml_Trait_Stack2 (Coml_Trait_Stack_Id)
/

ALTER TABLE Lexicon.Regulatory_Agency_Status
    ADD CONSTRAINT Reg_Agncy_Stat_Agncy_Fk
        FOREIGN KEY (Regulatory_Agency_Id)
        REFERENCES Lexicon.Regulatory_Agency (Regulatory_Agency_Id)
/

ALTER TABLE Lexicon.Regulatory_Agency_Status
    ADD CONSTRAINT Reg_Agncy_Stat_Stat_Fk
        FOREIGN KEY (Status_Type_Id)
        REFERENCES Lexicon.Regulatory_Status_Type (Status_Type_Id)
/

CREATE SEQUENCE Lexicon.Regulatory_Agency_Status_Seq
  INCREMENT BY 1
  START WITH 1000
  MINVALUE 1
  MAXVALUE 999999999999999999999999999
  NOCYCLE
  NOORDER
  CACHE 20
/

CREATE TABLE Lexicon.Event_Coml_Trait_Xref(
    Event_Coml_Trait_Xref_Id    NUMBER NOT NULL,
    Event_Pubkey                VARCHAR2(20) NOT NULL,
    Coml_Trait_Name_Id          NUMBER NOT NULL,
    Crop_Id                     NUMBER NOT NULL,
    CONSTRAINT EVENT_COML_TRAIT_XREF_PK
        PRIMARY KEY (Event_Coml_Trait_Xref_Id)
        USING INDEX
        TABLESPACE  Lexicon_Index
)
TABLESPACE Lexicon_Data
/

ALTER TABLE Lexicon.Event_Coml_Trait_Xref
   ADD CONSTRAINT Event_Coml_Trait_Xref_Ak
		UNIQUE (Event_Pubkey)
		USING INDEX
	TABLESPACE  Lexicon_Index
/

ALTER TABLE Lexicon.Event_Coml_Trait_Xref
    ADD CONSTRAINT Event_Coml_Trait_Xref_Trait_Fk
        FOREIGN KEY (Coml_Trait_Name_Id)
        REFERENCES Lexicon.Coml_Trait_Name2 (Coml_Trait_Name_Id)
/

ALTER TABLE Lexicon.Event_Coml_Trait_Xref
    ADD CONSTRAINT Event_Coml_Trait_Xref_Crop_Fk
        FOREIGN KEY (Crop_Id)
        REFERENCES Lexicon.Crop (Crop_Id)
/

CREATE SEQUENCE Lexicon.Event_Coml_Trait_Xref_Seq
  INCREMENT BY 1
  START WITH 1000
  MINVALUE 1
  MAXVALUE 999999999999999999999999999
  NOCYCLE
  NOORDER
  CACHE 20
/

