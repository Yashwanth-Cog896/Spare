-- change for test & prod
BEGIN
	Lexicon.Audit_Pkg.Initialize_Staging_P('25160', 'DELETE_COUNTRY','delete countries that are not listed in UN.org','Katie Maschmeyer');
end;
/

-- misc devl entries
/*delete from lexicon.country
where country_abbr in ('NAN', 'MRK', 'KPL', 'GGG');*/

--diable constraint
--alter table lexicon.ctry_reg_region_xref disable constraint ctry_rr_xref_rr_fk; 

DELETE
  FROM  Lexicon.Regulatory_Region
 WHERE  regulatory_region_id IN (
			SELECT  Xref.regulatory_region_id 
			  FROM  Lexicon.Country C, Lexicon.Ctry_Reg_Region_Xref Xref 
			 WHERE  C.country_id IN(1306,  1400,  1429,  1419,  1420  1389,  1428,  1236)
                                             --'ATA', 'ATF', 'BVT', 'IOT', 'CXR' 'TWN', 'CCK', 'HMD')
			   AND  C.country_id = Xref.country_id
	   )
;
   
DELETE 
  FROM  Lexicon.Ctry_Reg_Region_Xref
 WHERE  country_id IN (1306,  1400,  1429,  1419,  /*1420,*/  1389,  1428,  1236);
                    --'ATA', 'ATF', 'BVT', 'IOT','CXR', 'TWN', 'CCK', 'HMD')

--enable constraint
--alter table lexicon.ctry_reg_region_xref enable constraint ctry_rr_xref_rr_fk; 

DELETE 
  FROM  Lexicon.Country
 WHERE  country_id IN (1306,  1400,  1429,  1419,  1420,  1389,  1428,  1236);
                     --'ATA', 'ATF', 'BVT', 'IOT', 'CXR', 'TWN', 'CCK', 'HMD')

BEGIN
Lexicon.Audit_Pkg.delete_staging_record_p;
END;
/

