Please run the scripts in the following order:

1. Run DeleteNonUNCountriesAndRegulatoryRegions.sql
2. Run AddColsandUniqueConstraints.sql
3. Run UpdateCountries.sql
4. Run ModifyColsToNotNull.sql

Thanks.
Lexicon Team