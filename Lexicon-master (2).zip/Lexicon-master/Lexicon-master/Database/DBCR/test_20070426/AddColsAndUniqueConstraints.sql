ALTER TABLE Lexicon.Country 
    ADD (iso_code VARCHAR2(2), un_code NUMBER(3,0));
    
ALTER TABLE Lexicon.Country
    ADD CONSTRAINT COUNTRY_AK4
    UNIQUE (iso_code)
    USING INDEX
	TABLESPACE  Lexicon_Index;
	
ALTER TABLE Lexicon.Country
    ADD CONSTRAINT COUNTRY_AK5
	UNIQUE (un_code)
	USING INDEX
	TABLESPACE  Lexicon_Index;