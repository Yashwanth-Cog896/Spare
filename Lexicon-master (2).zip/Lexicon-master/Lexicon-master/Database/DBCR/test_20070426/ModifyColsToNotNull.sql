ALTER TABLE Lexicon.Country
MODIFY iso_code VARCHAR2(2) not null;
	
ALTER TABLE Lexicon.Country
MODIFY un_code NUMBER(3,0) not null;
