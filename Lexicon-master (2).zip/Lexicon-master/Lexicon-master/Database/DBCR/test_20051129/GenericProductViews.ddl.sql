CREATE VIEW Lexicon.Generic_Product_View (
   Product_Id,
   Product_Pubkey,
   Pre_Coml_Name,
   Crop_Id,
   Logical_Delete )
AS
SELECT  PCP.product_id,
        PCP.product_pubkey,
        PCP.pre_coml_name,
        PCP.crop_id,
        PCP.logical_delete
  FROM  Pre_Coml_Product PCP
UNION

SELECT  P.product_id,
        P.product_pubkey,
        NULL AS pre_com_name,
        BC.crop_id,
        P.logical_delete
  FROM  Product P,
        Bayer_Code BC
 WHERE  P.bayer_code_id = BC.bayer_code_id
/

CREATE VIEW Lexicon.Generic_Product_Name_View (
   Product_Name_Id,
   Product_Name_Pubkey,
   Product_Id,
   Product_Name,
   Brand_Id,
   Country_Id,
   Stage_Id,
   Commercial_Maturity,
   Coml_Trait_Stack_Id,
   Is_Active,
   Logical_Delete )
AS
SELECT  PS.product_stage_id AS product_name_id,
        PS.product_stage_pubkey AS product_name_pubkey,
        PS.product_id,
        NVL(PS.commercial_name, PCP.pre_coml_name) AS product_name,
        PS.brand_id,
        PS.country_id,
        PS.stage_id,
        PS.commercial_maturity,
        PS.coml_trait_stack_id,
        PS.is_active,
        PS.logical_delete
  FROM  Product_Stage PS,
        Pre_Coml_Product PCP
 WHERE  PS.product_id = PCP.product_id

UNION

SELECT PN.product_name_id,
       PN.product_name_pubkey,
       PN.product_id,
       PN.product_name,
       PN.brand_id,
       PN.country_id,
       NULL AS stage_id,
       PN.commercial_maturity,
       PN.coml_trait_stack_id,
       PN.is_active,
       PN.logical_delete
  FROM Product_Name PN
/


