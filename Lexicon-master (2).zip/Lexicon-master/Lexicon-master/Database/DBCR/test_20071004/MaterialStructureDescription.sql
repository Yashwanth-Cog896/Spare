/*==============================================================*/
/* Table: MOLECULAR_DESCRIPTION                                 */
/*==============================================================*/
create table MOLECULAR_DESCRIPTION  (
   MOLECULAR_DESCRIPTION_ID NUMBER                          not null,
   ADDITIONAL_MATERIAL_ID NUMBER                          not null,
   MOLECULAR_FORMULA    NVARCHAR2(50),
   MOLECULAR_WEIGHT     NVARCHAR2(20),
   STRUCTURE_FILE_NAME       NVARCHAR2(40),
   MOLECULAR_STRUCTURE  BLOB,
   constraint MOLECULAR_DESCRIPTION_PK primary key (MOLECULAR_DESCRIPTION_ID)
);

/*==============================================================*/
/* Index: ADDITIONAL_MATERIAL_ID_AK                             */
/*==============================================================*/
create unique index ADDITIONAL_MATERIAL_ID_AK on MOLECULAR_DESCRIPTION (
   ADDITIONAL_MATERIAL_ID ASC
);

alter table MOLECULAR_DESCRIPTION
   add constraint MOLECULAR_DESCRIPTION_FK01 foreign key (ADDITIONAL_MATERIAL_ID)
      references LEXICON.ADDITIONAL_MATERIAL (ADDITIONAL_MATERIAL_ID);

CREATE SEQUENCE Lexicon.MOLECULAR_DESCRIPTION_ID_SEQ
  INCREMENT BY 1
  START WITH 1000
  MINVALUE 1
  MAXVALUE 999999999999999999999999999
  NOCYCLE
  NOORDER
  CACHE 20;

GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Molecular_Description TO Lexicon_RW_Role, Lexicon_User;
GRANT SELECT ON Lexicon.Molecular_Description TO Lexicon_RW_Role;
GRANT SELECT ON Lexicon.Molecular_Description_Id_Seq TO Lexicon_RW_Role, Lexicon_User;

-- Argot FOR DEV *ONLY*
--GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.Molecular_Description TO Argot_Admin_Role;
--GRANT SELECT ON Lexicon.Molecular_Description_Id_Seq TO Argot_Admin_Role;

-- Argot FOR Test and Prod
--GRANT SELECT ON Lexicon.Molecular_Description TO Argot_Admin_Role;
