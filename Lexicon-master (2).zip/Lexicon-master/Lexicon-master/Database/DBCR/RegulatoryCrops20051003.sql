
-- disable trigger
ALTER trigger CROP_TRG DISABLE;
ALTER trigger BRAND_TRG DISABLE;

-- create crop_pubkey_seq
CREATE SEQUENCE crop_pubkey_seq
INCREMENT BY 100
START WITH 1015
NOMAXVALUE
NOMINVALUE
CACHE 30
NOCYCLE
NOORDER
;

-- alter table
ALTER table crop add crop_pubkey VARCHAR2(20);
ALTER table crop add regulatory_crop varchar2(1) DEFAULT 'n' not null;
ALTER table crop add CONSTRAINT Trueorfalseregcrop CHECK (regulatory_crop IN ('y', 'n'));

-- add data
declare
vid number;
begin
  for rec in (select crop_id from crop) loop 
    select crop_pubkey_seq.nextval into vid from dual;
    update crop set crop_pubkey = vid where crop_id = rec.crop_id;
  end loop;
end;
/

-- add additional constraints
ALTER table crop modify (crop_pubkey NOT NULL);
ALTER TABLE crop
ADD CONSTRAINT CROP_AK2
		UNIQUE (crop_pubkey)
		USING INDEX
	TABLESPACE  Lexicon_Index;


-- insert missing regulatory crops
insert into crop (crop_id, crop_pubkey, crop_name, major_crop, regulatory_crop)
values (crop_id_seq.NEXTVAL, crop_pubkey_seq.NEXTVAL, 'FORESTRY', 'n', 'y');
insert into crop (crop_id, crop_pubkey, crop_name, major_crop, regulatory_crop)
values (crop_id_seq.NEXTVAL, crop_pubkey_seq.NEXTVAL, 'SUGAR CANE', 'n', 'y');
insert into crop (crop_id, crop_pubkey, crop_name, major_crop, regulatory_crop)
values (crop_id_seq.NEXTVAL, crop_pubkey_seq.NEXTVAL, 'TOBACCO', 'n', 'y');
insert into crop (crop_id, crop_pubkey, crop_name, major_crop, regulatory_crop)
values (crop_id_seq.NEXTVAL, crop_pubkey_seq.NEXTVAL, 'TOMATO', 'n', 'y');
insert into crop (crop_id, crop_pubkey, crop_name, major_crop, regulatory_crop)
values (crop_id_seq.NEXTVAL, crop_pubkey_seq.NEXTVAL, 'WATERMELON', 'n', 'y');

-- update requested crops to regulatory crops
update crop set regulatory_crop = 'y' where crop_name 
in ('ALFALFA', 'BEET, SUGAR', 'OSR-CANOLA', 'CORN', 'COTTON', 'BENTGRASS, CREEPING', 
'POTATO, RED - WHITE', 'SOYBEANS', 'SUNFLOWER');

-- still waiting on a decision on RICE and WHEAT !!!

COMMIT;

-- create bayer_code_pubkey_seq
CREATE SEQUENCE bayer_code_pubkey_seq
INCREMENT BY 100
START WITH 1018
NOMAXVALUE
NOMINVALUE
CACHE 30
NOCYCLE
NOORDER
;




-- enable trigger
ALTER trigger CROP_TRG ENABLE;
ALTER trigger BRAND_TRG ENABLE;

