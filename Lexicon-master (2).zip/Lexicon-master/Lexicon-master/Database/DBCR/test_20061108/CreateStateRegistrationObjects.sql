CREATE TABLE Lexicon.Regulatory_Sub_Country_Status(
    Sub_Country_Status_Id    		NUMBER NOT NULL,
    Coml_Trait_Stack_Id				NUMBER NOT NULL,
    Sub_Country_Key					VARCHAR2(20) NOT NULL,
    Approval_Date					DATE NOT NULL,
    Expiration_Date					DATE,
    Registration_Or_Notification	VARCHAR2(1) NOT NULL,
    CONSTRAINT REG_SC_STATUS_PK
        PRIMARY KEY (Sub_Country_Status_Id)
        USING INDEX
        TABLESPACE  Lexicon_Index
)
TABLESPACE  Lexicon_Data
/

ALTER TABLE Lexicon.Regulatory_Sub_Country_Status
    ADD CONSTRAINT Reg_SC_Stat_Trait_Stack_Fk
        FOREIGN KEY (Coml_Trait_Stack_Id)
        REFERENCES Lexicon.Coml_Trait_Stack2 (Coml_Trait_Stack_Id)
/

ALTER TABLE Lexicon.Regulatory_Sub_Country_Status
   ADD CONSTRAINT Regulatory_SC_Status_Ak
		UNIQUE (Coml_Trait_Stack_Id, Sub_Country_Key)
		USING INDEX
	TABLESPACE  Lexicon_Index
/

ALTER TABLE Lexicon.Regulatory_Sub_Country_Status
	ADD CONSTRAINT R_OR_N_RSCS 
		CHECK (Registration_Or_Notification IN ('r', 'n'))
/

ALTER TABLE Lexicon.Regulatory_Sub_Country_Status 
	ADD CONSTRAINT REG_SC_STAT_EXP_NN_ON_REG_CHK
		CHECK (
  			(EXPIRATION_DATE IS NOT NULL OR REGISTRATION_OR_NOTIFICATION = 'n') AND
			(EXPIRATION_DATE IS NULL OR REGISTRATION_OR_NOTIFICATION = 'r')
		)
/

CREATE SEQUENCE Lexicon.Regulatory_SC_Status_Seq
  INCREMENT BY 1
  START WITH 1000
  MINVALUE 1
  MAXVALUE 999999999999999999999999999
  NOCYCLE
  NOORDER
  CACHE 20
/
