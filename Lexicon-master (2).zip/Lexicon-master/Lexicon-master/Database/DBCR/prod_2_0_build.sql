Connect LEXICON@DSBREED.MONSANTO.COM

--------------------------------------------------------------------------
-- Play this script in LEXICON@DSBREED.MONSANTO.COM to make it look like LEXICON@DSBREED_TST.MONSANTO.COM
--                                                                      --
-- Please review the script before using it to make sure it won't       --
-- cause any unacceptable data loss.                                    --
--                                                                      --
-- LEXICON@DSBREED.MONSANTO.COM Schema Extracted by User DBA_GROUP 
-- LEXICON@DSBREED_TST.MONSANTO.COM Schema Extracted by User DBA_GROUP 
DROP INDEX MIRAGE_SEED_PRODUCT_NAME_PK;

DROP INDEX MIRAGE_LEXICON_PRODUCT_AK2;

DROP INDEX MIRAGE_LEXICON_PRODUCT_AK1;

DROP INDEX MIDAS_LEXICON_PRODUCT_NAME_AK2;

DROP INDEX MIDAS_LEXICON_PRODUCT_NAME_AK1;

DROP INDEX MIDAS_LEXICON_PRODUCT_AK2;

DROP INDEX MIDAS_LEXICON_PRODUCT_AK1;

DROP INDEX EQUIV_PRODUCT_NAME_PK;

DROP INDEX EQUIV_PRODUCT_NAME_AK1;

DROP INDEX COUNTRY_TEMP_PK;

DROP INDEX COUNTRY_TEMP_AK1;

--DROP INDEX COMPANY_NAME_PK;

--DROP INDEX BAYER_CODE_NAME_PK;

DROP TABLE MIRAGE_MINORCROP_COMPET_COMP CASCADE CONSTRAINTS;

DROP TABLE MIRAGE_MINORCROP_BAYER_CODE CASCADE CONSTRAINTS;

DROP TABLE MIRAGE_LEXICON_PRODUCT CASCADE CONSTRAINTS;

DROP TABLE MIDAS_LEXICON_PRODUCT_NAME CASCADE CONSTRAINTS;

DROP TABLE MIDAS_LEXICON_PRODUCT CASCADE CONSTRAINTS;

DROP TABLE MIDAS_DUP_PRODUCT_NAME CASCADE CONSTRAINTS;

DROP TABLE GSPC CASCADE CONSTRAINTS;

DROP TABLE COUNTRY_TEMP CASCADE CONSTRAINTS;

DROP TABLE EQUIV_PRODUCT_NAME CASCADE CONSTRAINTS;

DROP TABLE MIRAGE_SEED_PRODUCT_NAME CASCADE CONSTRAINTS;

CREATE SEQUENCE PRODUCT_GP_ACTION_ID_SEQ
  START WITH 1000
  MAXVALUE 999999999999999999999999999
  MINVALUE 1
  NOCYCLE
  CACHE 30
  NOORDER;

CREATE SEQUENCE STAGE_PUBKEY_SEQ
  START WITH 2000
  INCREMENT BY 100
  MAXVALUE 999999999999999999999999999
  MINVALUE 1
  NOCYCLE
  CACHE 30
  NOORDER;

CREATE SEQUENCE STAGE_ID_SEQ
  START WITH 2000
  MAXVALUE 999999999999999999999999999
  MINVALUE 1
  NOCYCLE
  CACHE 30
  NOORDER;

ALTER TABLE AUDIT_HEADER
MODIFY(ENTRY_DATE TIMESTAMP(7));


-- Difference : Column Order (No action taken)

alter trigger lexicon.brand_trg disable;

alter trigger lexicon.crop_trg disable;


ALTER TABLE CROP ADD (MAJOR_CROP  VARCHAR2(1 BYTE)                  DEFAULT 'n');

-- Difference : Column Order (No action taken) 

ALTER TABLE BRAND ADD (TD_RESTRICTED  VARCHAR2(1 BYTE)               DEFAULT 'n');

--CREATE TABLE AUDIT_TABLE_INCLUDES
--(
--  AUDIT_TABLE_INCLUDES_ID  NUMBER,
--  TABLE_NAME               VARCHAR2(32 BYTE)
--)
--LOGGING
--NOCOMPRESS
--NOCACHE
--NOPARALLEL
--MONITORING;

--CREATE TABLE AUDIT_COLUMN_EXCLUDES
--(
--  AUDIT_COLUMN_EXCLUDES_ID  NUMBER,
--  TABLE_NAME                VARCHAR2(32 BYTE),
--  COLUMN_NAME               VARCHAR2(32 BYTE)
--)
--LOGGING
--NOCOMPRESS
--NOCACHE
--NOPARALLEL
--MONITORING;

CREATE TABLE LEXICON_PARAMETER
(
  LSI_ENV        VARCHAR2(5 BYTE),
  PARAMETER_KEY  VARCHAR2(32 BYTE),
  NUMERIC_VALUE  NUMBER,
  XML_VALUE      CLOB
)
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

CREATE TABLE PRODUCT_GP_ACTION
(
  PRODUCT_GP_ACTION_ID  NUMBER,
  PRODUCT_PUBKEY        VARCHAR2(20 BYTE),
  GP_KEY                VARCHAR2(20 BYTE)
)
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;

--CREATE UNIQUE INDEX AUDIT_COLUMN_EXCLUDES_AK1 ON AUDIT_COLUMN_EXCLUDES
--(TABLE_NAME, COLUMN_NAME)
--LOGGING
--NOPARALLEL;

--CREATE UNIQUE INDEX AUDIT_COLUMN_EXCLUDES_PK ON AUDIT_COLUMN_EXCLUDES
--(AUDIT_COLUMN_EXCLUDES_ID)
--LOGGING
--NOPARALLEL;

CREATE INDEX AUDIT_HEADER_ENTRY_DATE_IDX ON AUDIT_HEADER
(ENTRY_DATE)
LOGGING
NOPARALLEL;

--CREATE UNIQUE INDEX AUDIT_TABLE_INCLUDES_AK1 ON AUDIT_TABLE_INCLUDES
--(TABLE_NAME)
--LOGGING
--NOPARALLEL;

--CREATE UNIQUE INDEX AUDIT_TABLE_INCLUDES_PK ON AUDIT_TABLE_INCLUDES
--(AUDIT_TABLE_INCLUDES_ID)
--LOGGING
--NOPARALLEL;

CREATE UNIQUE INDEX LEXICON_PARAMETER_PK ON LEXICON_PARAMETER
(LSI_ENV, PARAMETER_KEY)
LOGGING
NOPARALLEL;

CREATE UNIQUE INDEX PRODUCT_GP_ACTION_PK ON PRODUCT_GP_ACTION
(PRODUCT_GP_ACTION_ID)
LOGGING
NOPARALLEL;

CREATE OR REPLACE PACKAGE BODY AUDIT_PKG
IS
    PROCEDURE Write_Audit_P(
        inTableName IN Audit_Header.table_name%TYPE,
        inOperationType IN Audit_Header.audit_operation_type%TYPE,
        inPrimaryKeyIndex IN INTEGER,
        inAuditDetailArray IN Audit_Detail_Array_Type)
    IS
        lPrimaryKeyValue Audit_Header.primary_key_field1%TYPE;
        lAuditStagingRecord Audit_Staging%ROWTYPE;
        lAuditHeaderRecord Audit_Header%ROWTYPE;
        lAuditDetailRecord Audit_Detail%ROWTYPE;
        lDetailToInsertArray Audit_Detail_Array_Type;
        lNumDetailToInsert INTEGER := 0;
    BEGIN
        -- Determine if table is be to audited
        IF Do_Audit_Table_F(inTableName) THEN

            -- Get the primary key value
            IF inOperationType = DELETE_OPERATION THEN
                lPrimaryKeyValue := TO_CHAR(inAuditDetailArray(inPrimaryKeyIndex).old_Value);
            ELSE
                lPrimaryKeyValue := TO_CHAR(inAuditDetailArray(inPrimaryKeyIndex).new_value);
            END IF;

            -- Get the audit staging record associated with the current session id
            lAuditStagingRecord := Get_Session_Staging_Record_F();

            -- Create a new audit header record with the supplied values
            lAuditHeaderRecord := Create_Header_Record_F(inTableName, inOperationType, lPrimaryKeyValue, lAuditStagingRecord);

            -- Loop through all detail records
            FOR i IN 1..inAuditDetailArray.COUNT
            LOOP
                -- Determine if column is to be audited
                IF Do_Audit_Column_F(inTableName, inAuditDetailArray(i).column_name) THEN

                    -- Get the detail record from the array
                    lAuditDetailRecord := inAuditDetailArray(i);

                    -- Determine if column values and/or operation type require a new detail record
                    IF Do_Audit_Detail_F(inOperationType, lAuditDetailRecord) THEN

                        -- Set the remaining detail fields and store record in array to detail records to be inserted
                        lAuditDetailRecord.audit_detail_id := Get_Next_Detail_ID_F();
                        lAuditDetailRecord.audit_header_id := lAuditHeaderRecord.audit_header_id;
                        lNumDetailToInsert := lNumDetailToInsert + 1;
                        lDetailToInsertArray(lNumDetailToInsert) := lAuditDetailRecord;
                    END IF;

                END IF;
            END LOOP;

            -- If there is at least 1 detail record to inserted
            IF lNumDetailToInsert > 0 THEN
                -- Insert the audit header
                Insert_Audit_Header_P(lAuditHeaderRecord);

                -- Insert the detail records
                FOR i IN 1..lNumDetailToInsert
                LOOP
                    Insert_Audit_Detail_P(lDetailToInsertArray(i));
                END LOOP;
            END IF;

        END IF;
    END Write_Audit_P;


    PROCEDURE Initialize_Staging_P(
        inUserPartyId Audit_Staging.user_party_id%TYPE,
        inProcessName Audit_Staging.process_name%TYPE,
        inAuditComment Audit_Staging.audit_comment%TYPE,
        inAuditRequestor Audit_Staging.audit_requestor%TYPE)
    IS
        lAuditStagingRecord Audit_Staging%ROWTYPE := null;
    BEGIN
        -- Get the current staging record
        lAuditStagingRecord := Get_Session_Staging_Record_F();

        -- Set the fields
        lAuditStagingRecord.user_party_id := inUserPartyId;
        lAuditStagingRecord.process_name := inProcessName;
        lAuditStagingRecord.audit_comment := inAuditComment;
        lAuditStagingRecord.audit_requestor := inAuditRequestor;

        -- Update the row
        Update_Audit_Staging_P(lAuditStagingRecord);
    EXCEPTION
        -- If the current staging record doesn't exist
        WHEN NO_AUDIT_STAGE_REC_EXCEPTION THEN
            -- Create and insert a new record
            lAuditStagingRecord := Create_Staging_Record_F(inUserPartyId, inProcessName, inAuditComment, inAuditRequestor);
            Insert_Audit_Staging_P(lAuditStagingRecord);
    END;


    FUNCTION Create_Detail_Record_F(
        inColumnName IN Audit_Detail.column_name%TYPE,
        inNewValue IN Audit_Detail.new_value%TYPE,
        inOldValue IN Audit_Detail.old_value%TYPE)
        RETURN Audit_Detail%ROWTYPE
    IS
        lAuditDetailRecord Audit_Detail%ROWTYPE;
    BEGIN
        SELECT  null AS audit_detail_id,
                null AS audit_header_id,
                inColumnName AS column_name,
                inNewValue AS new_value,
                inOldValue AS old_value
          INTO  lAuditDetailRecord
          FROM  DUAL;

        RETURN lAuditDetailRecord;
    END Create_Detail_Record_F;


    FUNCTION Create_Header_Record_F(
        inTableName Audit_Header.table_name%TYPE,
        inOperationType IN Audit_Header.audit_operation_type%TYPE,
        inPrimaryKeyValue IN Audit_Header.primary_key_field1%TYPE,
        inAuditStagingRecord IN Audit_Staging%ROWTYPE)
        RETURN Audit_Header%ROWTYPE
    IS
        lAuditHeaderRecord Audit_Header%ROWTYPE;
    BEGIN
        SELECT  Get_Next_Header_ID_F() AS audit_header_id,
                inOperationType AS audit_operation_type,
                inAuditStagingRecord.user_party_id AS user_party_id,
                inTableName AS table_name,
                SYSDATE AS entry_date,
                inPrimaryKeyValue AS primary_key_field1,
                inAuditStagingRecord.process_name AS process_name,
                inAuditStagingRecord.audit_comment AS audit_comment,
                inAuditStagingRecord.audit_requestor AS audit_requestor
          INTO  lAuditHeaderRecord
          FROM  DUAL;

        RETURN lAuditHeaderRecord;
    END Create_Header_Record_F;


    FUNCTION Create_Staging_Record_F(
        inUserPartyId Audit_Staging.user_party_id%TYPE,
        inProcessName Audit_Staging.process_name%TYPE,
        inAuditComment Audit_Staging.audit_comment%TYPE,
        inAuditRequestor Audit_Staging.audit_requestor%TYPE)
        RETURN Audit_Staging%ROWTYPE
    IS
        lAuditStagingRecord Audit_Staging%ROWTYPE;
    BEGIN
        SELECT  Get_Session_Id_F() AS oracle_sid,
                inUserPartyId AS user_party_id,
                inProcessName AS process_name,
                inAuditComment AS audit_comment,
                inAuditRequestor AS audit_requestor
          INTO  lAuditStagingRecord
          FROM  DUAL;

        RETURN lAuditStagingRecord;
    END Create_Staging_Record_F;


    FUNCTION Get_Session_Staging_Record_F
        RETURN Audit_Staging%ROWTYPE
    IS
        lAuditStagingRecord Audit_Staging%ROWTYPE;
    BEGIN
        SELECT  *
          INTO  lAuditStagingRecord
          FROM  Audit_Staging
         WHERE  oracle_sid = Get_Session_Id_F();

        RETURN lAuditStagingRecord;

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(NO_AUDIT_STAGE_REC_ERRNUM, NO_AUDIT_STAGE_REC_ERRMSG);
    END Get_Session_Staging_Record_F;


    FUNCTION Get_Session_Id_F
        RETURN Sys.V_$Session.sid%TYPE
    IS
        lSID Sys.V_$Session.sid%TYPE;
    BEGIN
        SELECT  sid
          INTO  lSID
          FROM  Sys.V_$Session
         WHERE  audsid = (
                SELECT  USERENV('sessionid')
                  FROM  DUAL);

        RETURN lSID;
    END Get_Session_Id_F;


    FUNCTION Get_Next_Header_ID_F
        RETURN Audit_Header.audit_header_id%TYPE
    IS
        lAuditHeaderID Audit_Header.audit_header_id%TYPE;
    BEGIN
        SELECT  Audit_Header_Seq.NEXTVAL
          INTO  lAuditHeaderID
          FROM  DUAL;

        RETURN lAuditHeaderID;
    END Get_Next_Header_ID_F;


    FUNCTION Get_Next_Detail_ID_F
        RETURN Audit_Detail.audit_detail_id%TYPE
    IS
        lAuditDetailID Audit_Detail.audit_detail_id%TYPE;
    BEGIN
        SELECT  Audit_Detail_Seq.NEXTVAL
          INTO  lAuditDetailID
          FROM  DUAL;

        RETURN lAuditDetailID;
    END Get_Next_Detail_ID_F;


    FUNCTION Do_Audit_Detail_F(
        inOperationType IN Audit_Header.audit_operation_type%TYPE,
        inAuditDetailRecord IN Audit_Detail%ROWTYPE)
        RETURN boolean
    IS
        lDoAddDetail boolean := true;
    BEGIN
        -- If the operation is update and new value and old value are the same,
        -- don't write a detail record
        IF inOperationType = UPDATE_OPERATION THEN
            IF NVL(inAuditDetailRecord.new_value, '-x-DUMMY NULL-x-') = NVL(inAuditDetailRecord.old_value, '-x-DUMMY NULL-x-') THEN
                lDoAddDetail := false;
            END IF;
        END IF;
        RETURN lDoAddDetail;
    END Do_Audit_Detail_F;


    FUNCTION Do_Audit_Table_F(
        inTableName Audit_Header.table_name%TYPE)
        RETURN boolean
    IS
    	lCount INTEGER;
    BEGIN
        RETURN TRUE;
/*
        SELECT  COUNT(*)
          INTO  lCount
          FROM  Audit_Table_Includes
         WHERE  table_name = inTableName;

		IF lCount = 0 THEN
			RETURN FALSE;
		ELSE
			RETURN TRUE;
		END IF;
*/
    END Do_Audit_Table_F;


    FUNCTION Do_Audit_Column_F(
        inTableName IN Audit_Header.table_name%TYPE,
        inColumnName IN Audit_Detail.column_name%TYPE)
        RETURN boolean
    IS
    	lCount INTEGER;
    BEGIN
        RETURN TRUE;
/*
        SELECT  COUNT(*)
          INTO  lCount
          FROM  Audit_Column_Excludes
         WHERE  table_name = inTableName
           AND  column_name = inColumnName;

		IF lCount = 0 THEN
			RETURN TRUE;
		ELSE
			RETURN FALSE;
		END IF;
*/
    END Do_Audit_Column_F;


    PROCEDURE Insert_Audit_Header_P(
        inAuditHeaderRecord IN Audit_Header%ROWTYPE)
    IS
    BEGIN
        INSERT
          INTO  Audit_Header(
                audit_header_id,
                audit_operation_type,
                table_name,
                primary_key_field1,
                entry_date,
                user_party_id,
                process_name,
                audit_comment,
                audit_requestor)
        VALUES (inAuditHeaderRecord.audit_header_id,
                inAuditHeaderRecord.audit_operation_type,
                inAuditHeaderRecord.table_name,
                inAuditHeaderRecord.primary_key_field1,
                inAuditHeaderRecord.entry_date,
                inAuditHeaderRecord.user_party_id,
                inAuditHeaderRecord.process_name,
                inAuditHeaderRecord.audit_comment,
                inAuditHeaderRecord.audit_requestor);
    END Insert_Audit_Header_P;


    PROCEDURE Insert_Audit_Detail_P(
        inAuditDetailRecord IN Audit_Detail%ROWTYPE)
    IS
    BEGIN
        INSERT
          INTO  Audit_Detail(
                audit_detail_id,
                audit_header_id,
                column_name,
                new_value,
                old_value)
        VALUES (inAuditDetailRecord.audit_detail_id,
                inAuditDetailRecord.audit_header_id,
                inAuditDetailRecord.column_name,
                inAuditDetailRecord.new_value,
                inAuditDetailRecord.old_value);
    END Insert_Audit_Detail_P;


    PROCEDURE Insert_Audit_Staging_P(
        inAuditStagingRecord IN Audit_Staging%ROWTYPE)
    IS
    BEGIN
        INSERT
          INTO  Audit_Staging(
                oracle_sid,
                user_party_id,
                process_name,
                audit_comment,
                audit_requestor)
        VALUES (inAuditStagingRecord.oracle_sid,
                inAuditStagingRecord.user_party_id,
                inAuditStagingRecord.process_name,
                inAuditStagingRecord.audit_comment,
                inAuditStagingRecord.audit_requestor);
    END Insert_Audit_Staging_P;


    PROCEDURE Update_Audit_Staging_P(
        inAuditStagingRecord IN Audit_Staging%ROWTYPE)
    IS
    BEGIN
        UPDATE  Audit_Staging
           SET  user_party_id = inAuditStagingRecord.user_party_id,
                process_name = inAuditStagingRecord.process_name,
                audit_comment = inAuditStagingRecord.audit_comment,
                audit_requestor = inAuditStagingRecord.audit_requestor
         WHERE  oracle_sid = inAuditStagingRecord.oracle_sid;
    END Update_Audit_Staging_P;


    PROCEDURE Delete_Staging_Record_P
    IS
    BEGIN
        DELETE
          FROM  Audit_Staging
         WHERE  oracle_sid = Get_Session_Id_F();
    END Delete_Staging_Record_P;

END Audit_Pkg;
/

SHOW ERRORS;

CREATE OR REPLACE TRIGGER BAYER_CODE_TRG
  AFTER INSERT OR DELETE OR UPDATE
  ON BAYER_CODE   FOR EACH ROW
DECLARE
  lOperationType CHAR(1);
  lPrimaryKeyPosition INTEGER := 1;
  lTableName VARCHAR2(30) := 'BAYER_CODE';
  lAuditDetailArray Audit_Pkg.Audit_Detail_Array_Type;

BEGIN
  IF Audit_Pkg.Do_Audit_Table_F(lTableName) THEN

    IF INSERTING THEN lOperationType := Audit_Pkg.INSERT_OPERATION;
    ELSIF UPDATING THEN lOperationType := Audit_Pkg.UPDATE_OPERATION;
    ELSIF DELETING THEN lOperationType := Audit_Pkg.DELETE_OPERATION;
    ELSE lOperationType := NULL;
    END IF;

    lAuditDetailArray(1) := Audit_Pkg.Create_Detail_Record_F('BAYER_CODE_ID', :NEW.BAYER_CODE_ID, :OLD.BAYER_CODE_ID);
    lAuditDetailArray(2) := Audit_Pkg.Create_Detail_Record_F('BAYER_CODE_NAME', :NEW.BAYER_CODE_NAME, :OLD.BAYER_CODE_NAME);
    lAuditDetailArray(3) := Audit_Pkg.Create_Detail_Record_F('BAYER_CODE_DESC', :NEW.BAYER_CODE_DESC, :OLD.BAYER_CODE_DESC);
    lAuditDetailArray(4) := Audit_Pkg.Create_Detail_Record_F('CROP_ID', :NEW.CROP_ID, :OLD.CROP_ID);

    Audit_Pkg.Write_Audit_P(lTableName , lOperationType, lPrimaryKeyPosition, lAuditDetailArray);
  END IF;
END;
/
SHOW ERRORS;


CREATE OR REPLACE TRIGGER CROP_TRG
  AFTER INSERT OR DELETE OR UPDATE
  ON CROP   FOR EACH ROW
DECLARE
  lOperationType CHAR(1);
  lPrimaryKeyPosition INTEGER := 1;
  lTableName VARCHAR2(30) := 'CROP';
  lAuditDetailArray Audit_Pkg.Audit_Detail_Array_Type;

BEGIN
  IF Audit_Pkg.Do_Audit_Table_F(lTableName) THEN

    IF INSERTING THEN lOperationType := Audit_Pkg.INSERT_OPERATION;
    ELSIF UPDATING THEN lOperationType := Audit_Pkg.UPDATE_OPERATION;
    ELSIF DELETING THEN lOperationType := Audit_Pkg.DELETE_OPERATION;
    ELSE lOperationType := NULL;
    END IF;

    lAuditDetailArray(1) := Audit_Pkg.Create_Detail_Record_F('CROP_ID', :NEW.CROP_ID, :OLD.CROP_ID);
    lAuditDetailArray(2) := Audit_Pkg.Create_Detail_Record_F('CROP_NAME', :NEW.CROP_NAME, :OLD.CROP_NAME);
    lAuditDetailArray(3) := Audit_Pkg.Create_Detail_Record_F('MAJOR_CROP', :NEW.MAJOR_CROP, :OLD.MAJOR_CROP);

    Audit_Pkg.Write_Audit_P(lTableName , lOperationType, lPrimaryKeyPosition, lAuditDetailArray);
  END IF;
END;
/
SHOW ERRORS;


CREATE OR REPLACE TRIGGER BRAND_TRG
  AFTER INSERT OR DELETE OR UPDATE
  ON BRAND   FOR EACH ROW
DECLARE
  lOperationType CHAR(1);
  lPrimaryKeyPosition INTEGER := 1;
  lTableName VARCHAR2(30) := 'BRAND';
  lAuditDetailArray Audit_Pkg.Audit_Detail_Array_Type;

BEGIN
  IF Audit_Pkg.Do_Audit_Table_F(lTableName) THEN

    IF INSERTING THEN lOperationType := Audit_Pkg.INSERT_OPERATION;
    ELSIF UPDATING THEN lOperationType := Audit_Pkg.UPDATE_OPERATION;
    ELSIF DELETING THEN lOperationType := Audit_Pkg.DELETE_OPERATION;
    ELSE lOperationType := NULL;
    END IF;

    lAuditDetailArray(1) := Audit_Pkg.Create_Detail_Record_F('BRAND_ID', :NEW.BRAND_ID, :OLD.BRAND_ID);
    lAuditDetailArray(2) := Audit_Pkg.Create_Detail_Record_F('BRAND_PUBKEY', :NEW.BRAND_PUBKEY, :OLD.BRAND_PUBKEY);
    lAuditDetailArray(3) := Audit_Pkg.Create_Detail_Record_F('BRAND_NAME', :NEW.BRAND_NAME, :OLD.BRAND_NAME);
    lAuditDetailArray(4) := Audit_Pkg.Create_Detail_Record_F('BRAND_ABBR', :NEW.BRAND_ABBR, :OLD.BRAND_ABBR);
    lAuditDetailArray(5) := Audit_Pkg.Create_Detail_Record_F('COMPANY_ID', :NEW.COMPANY_ID, :OLD.COMPANY_ID);
    lAuditDetailArray(6) := Audit_Pkg.Create_Detail_Record_F('IS_ACTIVE', :NEW.IS_ACTIVE, :OLD.IS_ACTIVE);
    lAuditDetailArray(7) := Audit_Pkg.Create_Detail_Record_F('TD_RESTRICTED', :NEW.TD_RESTRICTED, :OLD.TD_RESTRICTED);

    Audit_Pkg.Write_Audit_P(lTableName , lOperationType, lPrimaryKeyPosition, lAuditDetailArray);
  END IF;
END;
/
SHOW ERRORS;


CREATE OR REPLACE TRIGGER COML_TRAIT_TRG
  AFTER INSERT OR DELETE OR UPDATE
  ON COML_TRAIT   FOR EACH ROW
DECLARE
  lOperationType CHAR(1);
  lPrimaryKeyPosition INTEGER := 1;
  lTableName VARCHAR2(30) := 'COML_TRAIT';
  lAuditDetailArray Audit_Pkg.Audit_Detail_Array_Type;

BEGIN
  IF Audit_Pkg.Do_Audit_Table_F(lTableName) THEN

    IF INSERTING THEN lOperationType := Audit_Pkg.INSERT_OPERATION;
    ELSIF UPDATING THEN lOperationType := Audit_Pkg.UPDATE_OPERATION;
    ELSIF DELETING THEN lOperationType := Audit_Pkg.DELETE_OPERATION;
    ELSE lOperationType := NULL;
    END IF;

    lAuditDetailArray(1) := Audit_Pkg.Create_Detail_Record_F('COML_TRAIT_ID', :NEW.COML_TRAIT_ID, :OLD.COML_TRAIT_ID);
    lAuditDetailArray(2) := Audit_Pkg.Create_Detail_Record_F('CROP_ID', :NEW.CROP_ID, :OLD.CROP_ID);
    lAuditDetailArray(3) := Audit_Pkg.Create_Detail_Record_F('COML_TRAIT_ABBR', :NEW.COML_TRAIT_ABBR, :OLD.COML_TRAIT_ABBR);
    lAuditDetailArray(4) := Audit_Pkg.Create_Detail_Record_F('COML_TRAIT_DESC', :NEW.COML_TRAIT_DESC, :OLD.COML_TRAIT_DESC);
    lAuditDetailArray(5) := Audit_Pkg.Create_Detail_Record_F('IS_ACTIVE', :NEW.IS_ACTIVE, :OLD.IS_ACTIVE);

    Audit_Pkg.Write_Audit_P(lTableName , lOperationType, lPrimaryKeyPosition, lAuditDetailArray);
  END IF;
END;
/
SHOW ERRORS;


CREATE OR REPLACE TRIGGER COML_TRAIT_NAME_TRG
  AFTER INSERT OR DELETE OR UPDATE
  ON COML_TRAIT_NAME   FOR EACH ROW
DECLARE
  lOperationType CHAR(1);
  lPrimaryKeyPosition INTEGER := 1;
  lTableName VARCHAR2(30) := 'COML_TRAIT_NAME';
  lAuditDetailArray Audit_Pkg.Audit_Detail_Array_Type;

BEGIN
  IF Audit_Pkg.Do_Audit_Table_F(lTableName) THEN

    IF INSERTING THEN lOperationType := Audit_Pkg.INSERT_OPERATION;
    ELSIF UPDATING THEN lOperationType := Audit_Pkg.UPDATE_OPERATION;
    ELSIF DELETING THEN lOperationType := Audit_Pkg.DELETE_OPERATION;
    ELSE lOperationType := NULL;
    END IF;

    lAuditDetailArray(1) := Audit_Pkg.Create_Detail_Record_F('COML_TRAIT_NAME_ID', :NEW.COML_TRAIT_NAME_ID, :OLD.COML_TRAIT_NAME_ID);
    lAuditDetailArray(2) := Audit_Pkg.Create_Detail_Record_F('COML_TRAIT_ID', :NEW.COML_TRAIT_ID, :OLD.COML_TRAIT_ID);
    lAuditDetailArray(3) := Audit_Pkg.Create_Detail_Record_F('COMPANY_ID', :NEW.COMPANY_ID, :OLD.COMPANY_ID);
    lAuditDetailArray(4) := Audit_Pkg.Create_Detail_Record_F('COML_TRAIT_NAME_ABBR', :NEW.COML_TRAIT_NAME_ABBR, :OLD.COML_TRAIT_NAME_ABBR);
    lAuditDetailArray(5) := Audit_Pkg.Create_Detail_Record_F('COML_TRAIT_NAME_DESC', :NEW.COML_TRAIT_NAME_DESC, :OLD.COML_TRAIT_NAME_DESC);
    lAuditDetailArray(6) := Audit_Pkg.Create_Detail_Record_F('IS_ACTIVE', :NEW.IS_ACTIVE, :OLD.IS_ACTIVE);

    Audit_Pkg.Write_Audit_P(lTableName , lOperationType, lPrimaryKeyPosition, lAuditDetailArray);
  END IF;
END;
/
SHOW ERRORS;


CREATE OR REPLACE TRIGGER COML_TRAIT_STACK_TRG
  AFTER INSERT OR DELETE OR UPDATE
  ON COML_TRAIT_STACK   FOR EACH ROW
DECLARE
  lOperationType CHAR(1);
  lPrimaryKeyPosition INTEGER := 1;
  lTableName VARCHAR2(30) := 'COML_TRAIT_STACK';
  lAuditDetailArray Audit_Pkg.Audit_Detail_Array_Type;

BEGIN
  IF Audit_Pkg.Do_Audit_Table_F(lTableName) THEN

    IF INSERTING THEN lOperationType := Audit_Pkg.INSERT_OPERATION;
    ELSIF UPDATING THEN lOperationType := Audit_Pkg.UPDATE_OPERATION;
    ELSIF DELETING THEN lOperationType := Audit_Pkg.DELETE_OPERATION;
    ELSE lOperationType := NULL;
    END IF;

    lAuditDetailArray(1) := Audit_Pkg.Create_Detail_Record_F('COML_TRAIT_STACK_ID', :NEW.COML_TRAIT_STACK_ID, :OLD.COML_TRAIT_STACK_ID);
    lAuditDetailArray(2) := Audit_Pkg.Create_Detail_Record_F('COML_TRAIT_STACK_ABBR', :NEW.COML_TRAIT_STACK_ABBR, :OLD.COML_TRAIT_STACK_ABBR);
    lAuditDetailArray(3) := Audit_Pkg.Create_Detail_Record_F('CROP_ID', :NEW.CROP_ID, :OLD.CROP_ID);

    Audit_Pkg.Write_Audit_P(lTableName , lOperationType, lPrimaryKeyPosition, lAuditDetailArray);
  END IF;
END;
/
SHOW ERRORS;


CREATE OR REPLACE TRIGGER COML_TRAIT_STACK_NAME_XREF_TRG
  AFTER INSERT OR DELETE OR UPDATE
  ON COML_TRAIT_STACK_NAME_XREF   FOR EACH ROW
DECLARE
  lOperationType CHAR(1);
  lPrimaryKeyPosition INTEGER := 1;
  lTableName VARCHAR2(30) := 'COML_TRAIT_STACK_NAME_XREF';
  lAuditDetailArray Audit_Pkg.Audit_Detail_Array_Type;

BEGIN
  IF Audit_Pkg.Do_Audit_Table_F(lTableName) THEN

    IF INSERTING THEN lOperationType := Audit_Pkg.INSERT_OPERATION;
    ELSIF UPDATING THEN lOperationType := Audit_Pkg.UPDATE_OPERATION;
    ELSIF DELETING THEN lOperationType := Audit_Pkg.DELETE_OPERATION;
    ELSE lOperationType := NULL;
    END IF;

    lAuditDetailArray(1) := Audit_Pkg.Create_Detail_Record_F('TRAIT_STACK_NAME_XREF_ID', :NEW.TRAIT_STACK_NAME_XREF_ID, :OLD.TRAIT_STACK_NAME_XREF_ID);
    lAuditDetailArray(2) := Audit_Pkg.Create_Detail_Record_F('CROP_ID', :NEW.CROP_ID, :OLD.CROP_ID);
    lAuditDetailArray(3) := Audit_Pkg.Create_Detail_Record_F('COML_TRAIT_STACK_ID', :NEW.COML_TRAIT_STACK_ID, :OLD.COML_TRAIT_STACK_ID);
    lAuditDetailArray(4) := Audit_Pkg.Create_Detail_Record_F('NAME_TYPE', :NEW.NAME_TYPE, :OLD.NAME_TYPE);
    lAuditDetailArray(5) := Audit_Pkg.Create_Detail_Record_F('VALUE', :NEW.VALUE, :OLD.VALUE);

    Audit_Pkg.Write_Audit_P(lTableName , lOperationType, lPrimaryKeyPosition, lAuditDetailArray);
  END IF;
END;
/
SHOW ERRORS;


CREATE OR REPLACE TRIGGER COML_TRAIT_STACK_XREF_TRG
  AFTER INSERT OR DELETE OR UPDATE
  ON COML_TRAIT_STACK_XREF   FOR EACH ROW
DECLARE
  lOperationType CHAR(1);
  lPrimaryKeyPosition INTEGER := 1;
  lTableName VARCHAR2(30) := 'COML_TRAIT_STACK_XREF';
  lAuditDetailArray Audit_Pkg.Audit_Detail_Array_Type;

BEGIN
  IF Audit_Pkg.Do_Audit_Table_F(lTableName) THEN

    IF INSERTING THEN lOperationType := Audit_Pkg.INSERT_OPERATION;
    ELSIF UPDATING THEN lOperationType := Audit_Pkg.UPDATE_OPERATION;
    ELSIF DELETING THEN lOperationType := Audit_Pkg.DELETE_OPERATION;
    ELSE lOperationType := NULL;
    END IF;

    lAuditDetailArray(1) := Audit_Pkg.Create_Detail_Record_F('COML_TRAIT_STACK_XREF_ID', :NEW.COML_TRAIT_STACK_XREF_ID, :OLD.COML_TRAIT_STACK_XREF_ID);
    lAuditDetailArray(2) := Audit_Pkg.Create_Detail_Record_F('COML_TRAIT_NAME_ID', :NEW.COML_TRAIT_NAME_ID, :OLD.COML_TRAIT_NAME_ID);
    lAuditDetailArray(3) := Audit_Pkg.Create_Detail_Record_F('COML_TRAIT_STACK_ID', :NEW.COML_TRAIT_STACK_ID, :OLD.COML_TRAIT_STACK_ID);
    lAuditDetailArray(4) := Audit_Pkg.Create_Detail_Record_F('STACK_ORDER', :NEW.STACK_ORDER, :OLD.STACK_ORDER);

    Audit_Pkg.Write_Audit_P(lTableName , lOperationType, lPrimaryKeyPosition, lAuditDetailArray);
  END IF;
END;
/
SHOW ERRORS;


CREATE OR REPLACE TRIGGER COML_TRAIT_TYPE_TRG
  AFTER INSERT OR DELETE OR UPDATE
  ON COML_TRAIT_TYPE   FOR EACH ROW
DECLARE
  lOperationType CHAR(1);
  lPrimaryKeyPosition INTEGER := 1;
  lTableName VARCHAR2(30) := 'COML_TRAIT_TYPE';
  lAuditDetailArray Audit_Pkg.Audit_Detail_Array_Type;

BEGIN
  IF Audit_Pkg.Do_Audit_Table_F(lTableName) THEN

    IF INSERTING THEN lOperationType := Audit_Pkg.INSERT_OPERATION;
    ELSIF UPDATING THEN lOperationType := Audit_Pkg.UPDATE_OPERATION;
    ELSIF DELETING THEN lOperationType := Audit_Pkg.DELETE_OPERATION;
    ELSE lOperationType := NULL;
    END IF;

    lAuditDetailArray(1) := Audit_Pkg.Create_Detail_Record_F('COML_TRAIT_TYPE_ID', :NEW.COML_TRAIT_TYPE_ID, :OLD.COML_TRAIT_TYPE_ID);
    lAuditDetailArray(2) := Audit_Pkg.Create_Detail_Record_F('COML_TRAIT_TYPE_ABBR', :NEW.COML_TRAIT_TYPE_ABBR, :OLD.COML_TRAIT_TYPE_ABBR);
    lAuditDetailArray(3) := Audit_Pkg.Create_Detail_Record_F('COML_TRAIT_TYPE_DESC', :NEW.COML_TRAIT_TYPE_DESC, :OLD.COML_TRAIT_TYPE_DESC);

    Audit_Pkg.Write_Audit_P(lTableName , lOperationType, lPrimaryKeyPosition, lAuditDetailArray);
  END IF;
END;
/
SHOW ERRORS;


CREATE OR REPLACE TRIGGER COML_TRAIT_TYPE_XREF_TRG
  AFTER INSERT OR DELETE OR UPDATE
  ON COML_TRAIT_TYPE_XREF   FOR EACH ROW
DECLARE
  lOperationType CHAR(1);
  lPrimaryKeyPosition INTEGER := 1;
  lTableName VARCHAR2(30) := 'COML_TRAIT_TYPE_XREF';
  lAuditDetailArray Audit_Pkg.Audit_Detail_Array_Type;

BEGIN
  IF Audit_Pkg.Do_Audit_Table_F(lTableName) THEN

    IF INSERTING THEN lOperationType := Audit_Pkg.INSERT_OPERATION;
    ELSIF UPDATING THEN lOperationType := Audit_Pkg.UPDATE_OPERATION;
    ELSIF DELETING THEN lOperationType := Audit_Pkg.DELETE_OPERATION;
    ELSE lOperationType := NULL;
    END IF;

    lAuditDetailArray(1) := Audit_Pkg.Create_Detail_Record_F('COML_TRAIT_TYPE_XREF_ID', :NEW.COML_TRAIT_TYPE_XREF_ID, :OLD.COML_TRAIT_TYPE_XREF_ID);
    lAuditDetailArray(2) := Audit_Pkg.Create_Detail_Record_F('COML_TRAIT_ID', :NEW.COML_TRAIT_ID, :OLD.COML_TRAIT_ID);
    lAuditDetailArray(3) := Audit_Pkg.Create_Detail_Record_F('COML_TRAIT_TYPE_ID', :NEW.COML_TRAIT_TYPE_ID, :OLD.COML_TRAIT_TYPE_ID);

    Audit_Pkg.Write_Audit_P(lTableName , lOperationType, lPrimaryKeyPosition, lAuditDetailArray);
  END IF;
END;
/
SHOW ERRORS;


CREATE OR REPLACE TRIGGER COMPANY_TRG
  AFTER INSERT OR DELETE OR UPDATE
  ON COMPANY   FOR EACH ROW
DECLARE
  lOperationType CHAR(1);
  lPrimaryKeyPosition INTEGER := 1;
  lTableName VARCHAR2(30) := 'COMPANY';
  lAuditDetailArray Audit_Pkg.Audit_Detail_Array_Type;

BEGIN
  IF Audit_Pkg.Do_Audit_Table_F(lTableName) THEN

    IF INSERTING THEN lOperationType := Audit_Pkg.INSERT_OPERATION;
    ELSIF UPDATING THEN lOperationType := Audit_Pkg.UPDATE_OPERATION;
    ELSIF DELETING THEN lOperationType := Audit_Pkg.DELETE_OPERATION;
    ELSE lOperationType := NULL;
    END IF;

    lAuditDetailArray(1) := Audit_Pkg.Create_Detail_Record_F('COMPANY_ID', :NEW.COMPANY_ID, :OLD.COMPANY_ID);
    lAuditDetailArray(2) := Audit_Pkg.Create_Detail_Record_F('COMPANY_PUBKEY', :NEW.COMPANY_PUBKEY, :OLD.COMPANY_PUBKEY);
    lAuditDetailArray(3) := Audit_Pkg.Create_Detail_Record_F('COMPANY_NAME', :NEW.COMPANY_NAME, :OLD.COMPANY_NAME);
    lAuditDetailArray(4) := Audit_Pkg.Create_Detail_Record_F('IS_ACTIVE', :NEW.IS_ACTIVE, :OLD.IS_ACTIVE);
    lAuditDetailArray(5) := Audit_Pkg.Create_Detail_Record_F('IS_COMPETITOR', :NEW.IS_COMPETITOR, :OLD.IS_COMPETITOR);

    Audit_Pkg.Write_Audit_P(lTableName , lOperationType, lPrimaryKeyPosition, lAuditDetailArray);
  END IF;
END;
/
SHOW ERRORS;


CREATE OR REPLACE TRIGGER COUNTRY_TRG
  AFTER INSERT OR DELETE OR UPDATE
  ON COUNTRY   FOR EACH ROW
DECLARE
  lOperationType CHAR(1);
  lPrimaryKeyPosition INTEGER := 1;
  lTableName VARCHAR2(30) := 'COUNTRY';
  lAuditDetailArray Audit_Pkg.Audit_Detail_Array_Type;

BEGIN
  IF Audit_Pkg.Do_Audit_Table_F(lTableName) THEN

    IF INSERTING THEN lOperationType := Audit_Pkg.INSERT_OPERATION;
    ELSIF UPDATING THEN lOperationType := Audit_Pkg.UPDATE_OPERATION;
    ELSIF DELETING THEN lOperationType := Audit_Pkg.DELETE_OPERATION;
    ELSE lOperationType := NULL;
    END IF;

    lAuditDetailArray(1) := Audit_Pkg.Create_Detail_Record_F('COUNTRY_ID', :NEW.COUNTRY_ID, :OLD.COUNTRY_ID);
    lAuditDetailArray(2) := Audit_Pkg.Create_Detail_Record_F('COUNTRY_PUBKEY', :NEW.COUNTRY_PUBKEY, :OLD.COUNTRY_PUBKEY);
    lAuditDetailArray(3) := Audit_Pkg.Create_Detail_Record_F('COUNTRY_ABBR', :NEW.COUNTRY_ABBR, :OLD.COUNTRY_ABBR);
    lAuditDetailArray(4) := Audit_Pkg.Create_Detail_Record_F('COUNTRY_NAME', :NEW.COUNTRY_NAME, :OLD.COUNTRY_NAME);

    Audit_Pkg.Write_Audit_P(lTableName , lOperationType, lPrimaryKeyPosition, lAuditDetailArray);
  END IF;
END;
/
SHOW ERRORS;


CREATE OR REPLACE TRIGGER PRE_COML_PRODUCT_TRG
  AFTER INSERT OR DELETE OR UPDATE
  ON PRE_COML_PRODUCT   FOR EACH ROW
DECLARE
  lOperationType CHAR(1);
  lPrimaryKeyPosition INTEGER := 1;
  lTableName VARCHAR2(30) := 'PRE_COML_PRODUCT';
  lAuditDetailArray Audit_Pkg.Audit_Detail_Array_Type;

BEGIN
  IF Audit_Pkg.Do_Audit_Table_F(lTableName) THEN

    IF INSERTING THEN lOperationType := Audit_Pkg.INSERT_OPERATION;
    ELSIF UPDATING THEN lOperationType := Audit_Pkg.UPDATE_OPERATION;
    ELSIF DELETING THEN lOperationType := Audit_Pkg.DELETE_OPERATION;
    ELSE lOperationType := NULL;
    END IF;

    lAuditDetailArray(1) := Audit_Pkg.Create_Detail_Record_F('PRODUCT_ID', :NEW.PRODUCT_ID, :OLD.PRODUCT_ID);
    lAuditDetailArray(2) := Audit_Pkg.Create_Detail_Record_F('PRODUCT_PUBKEY', :NEW.PRODUCT_PUBKEY, :OLD.PRODUCT_PUBKEY);
    lAuditDetailArray(3) := Audit_Pkg.Create_Detail_Record_F('PRE_COML_NAME', :NEW.PRE_COML_NAME, :OLD.PRE_COML_NAME);
    lAuditDetailArray(4) := Audit_Pkg.Create_Detail_Record_F('CROP_ID', :NEW.CROP_ID, :OLD.CROP_ID);
    lAuditDetailArray(5) := Audit_Pkg.Create_Detail_Record_F('USTV_NAME', :NEW.USTV_NAME, :OLD.USTV_NAME);

    Audit_Pkg.Write_Audit_P(lTableName , lOperationType, lPrimaryKeyPosition, lAuditDetailArray);
  END IF;
END;
/
SHOW ERRORS;


CREATE OR REPLACE TRIGGER PRODUCT_GP_ACTION_TRG
  AFTER INSERT OR DELETE OR UPDATE
  ON PRODUCT_GP_ACTION   FOR EACH ROW
DECLARE
  lOperationType CHAR(1);
  lPrimaryKeyPosition INTEGER := 1;
  lTableName VARCHAR2(30) := 'PRODUCT_GP_ACTION';
  lAuditDetailArray Audit_Pkg.Audit_Detail_Array_Type;

BEGIN
  IF Audit_Pkg.Do_Audit_Table_F(lTableName) THEN

    IF INSERTING THEN lOperationType := Audit_Pkg.INSERT_OPERATION;
    ELSIF UPDATING THEN lOperationType := Audit_Pkg.UPDATE_OPERATION;
    ELSIF DELETING THEN lOperationType := Audit_Pkg.DELETE_OPERATION;
    ELSE lOperationType := NULL;
    END IF;

    lAuditDetailArray(1) := Audit_Pkg.Create_Detail_Record_F('PRODUCT_GP_ACTION_ID', :NEW.PRODUCT_GP_ACTION_ID, :OLD.PRODUCT_GP_ACTION_ID);
    lAuditDetailArray(2) := Audit_Pkg.Create_Detail_Record_F('PRODUCT_PUBKEY', :NEW.PRODUCT_PUBKEY, :OLD.PRODUCT_PUBKEY);
    lAuditDetailArray(3) := Audit_Pkg.Create_Detail_Record_F('GP_KEY', :NEW.GP_KEY, :OLD.GP_KEY);

    Audit_Pkg.Write_Audit_P(lTableName , lOperationType, lPrimaryKeyPosition, lAuditDetailArray);
  END IF;
END;
/
SHOW ERRORS;


CREATE OR REPLACE TRIGGER PRODUCT_STAGE_TRG
  AFTER INSERT OR DELETE OR UPDATE
  ON PRODUCT_STAGE   FOR EACH ROW
DECLARE
  lOperationType CHAR(1);
  lPrimaryKeyPosition INTEGER := 2;
  lTableName VARCHAR2(30) := 'PRODUCT_STAGE';
  lAuditDetailArray Audit_Pkg.Audit_Detail_Array_Type;

BEGIN
  IF Audit_Pkg.Do_Audit_Table_F(lTableName) THEN

    IF INSERTING THEN lOperationType := Audit_Pkg.INSERT_OPERATION;
    ELSIF UPDATING THEN lOperationType := Audit_Pkg.UPDATE_OPERATION;
    ELSIF DELETING THEN lOperationType := Audit_Pkg.DELETE_OPERATION;
    ELSE lOperationType := NULL;
    END IF;

    lAuditDetailArray(1) := Audit_Pkg.Create_Detail_Record_F('COML_TRAIT_STACK_ID', :NEW.COML_TRAIT_STACK_ID, :OLD.COML_TRAIT_STACK_ID);
    lAuditDetailArray(2) := Audit_Pkg.Create_Detail_Record_F('PRODUCT_STAGE_ID', :NEW.PRODUCT_STAGE_ID, :OLD.PRODUCT_STAGE_ID);
    lAuditDetailArray(3) := Audit_Pkg.Create_Detail_Record_F('PRODUCT_STAGE_PUBKEY', :NEW.PRODUCT_STAGE_PUBKEY, :OLD.PRODUCT_STAGE_PUBKEY);
    lAuditDetailArray(4) := Audit_Pkg.Create_Detail_Record_F('PRODUCT_ID', :NEW.PRODUCT_ID, :OLD.PRODUCT_ID);
    lAuditDetailArray(5) := Audit_Pkg.Create_Detail_Record_F('COUNTRY_ID', :NEW.COUNTRY_ID, :OLD.COUNTRY_ID);
    lAuditDetailArray(6) := Audit_Pkg.Create_Detail_Record_F('BRAND_ID', :NEW.BRAND_ID, :OLD.BRAND_ID);
    lAuditDetailArray(7) := Audit_Pkg.Create_Detail_Record_F('STAGE_ID', :NEW.STAGE_ID, :OLD.STAGE_ID);
    lAuditDetailArray(8) := Audit_Pkg.Create_Detail_Record_F('COMMERCIAL_NAME', :NEW.COMMERCIAL_NAME, :OLD.COMMERCIAL_NAME);
    lAuditDetailArray(9) := Audit_Pkg.Create_Detail_Record_F('TEST_NAME', :NEW.TEST_NAME, :OLD.TEST_NAME);
    lAuditDetailArray(10) := Audit_Pkg.Create_Detail_Record_F('OECD_REQD_NAME', :NEW.OECD_REQD_NAME, :OLD.OECD_REQD_NAME);
    lAuditDetailArray(11) := Audit_Pkg.Create_Detail_Record_F('COMMERCIAL_MATURITY', :NEW.COMMERCIAL_MATURITY, :OLD.COMMERCIAL_MATURITY);
    lAuditDetailArray(12) := Audit_Pkg.Create_Detail_Record_F('IS_ACTIVE', :NEW.IS_ACTIVE, :OLD.IS_ACTIVE);

    Audit_Pkg.Write_Audit_P(lTableName , lOperationType, lPrimaryKeyPosition, lAuditDetailArray);
  END IF;
END;
/
SHOW ERRORS;


CREATE OR REPLACE TRIGGER STAGE_TRG
  AFTER INSERT OR DELETE OR UPDATE
  ON STAGE   FOR EACH ROW
DECLARE
  lOperationType CHAR(1);
  lPrimaryKeyPosition INTEGER := 1;
  lTableName VARCHAR2(30) := 'STAGE';
  lAuditDetailArray Audit_Pkg.Audit_Detail_Array_Type;

BEGIN
  IF Audit_Pkg.Do_Audit_Table_F(lTableName) THEN

    IF INSERTING THEN lOperationType := Audit_Pkg.INSERT_OPERATION;
    ELSIF UPDATING THEN lOperationType := Audit_Pkg.UPDATE_OPERATION;
    ELSIF DELETING THEN lOperationType := Audit_Pkg.DELETE_OPERATION;
    ELSE lOperationType := NULL;
    END IF;

    lAuditDetailArray(1) := Audit_Pkg.Create_Detail_Record_F('STAGE_ID', :NEW.STAGE_ID, :OLD.STAGE_ID);
    lAuditDetailArray(2) := Audit_Pkg.Create_Detail_Record_F('STAGE_ABBR', :NEW.STAGE_ABBR, :OLD.STAGE_ABBR);
    lAuditDetailArray(3) := Audit_Pkg.Create_Detail_Record_F('STAGE_DESC', :NEW.STAGE_DESC, :OLD.STAGE_DESC);
    lAuditDetailArray(4) := Audit_Pkg.Create_Detail_Record_F('ORDER_BY_NUM', :NEW.ORDER_BY_NUM, :OLD.ORDER_BY_NUM);
    lAuditDetailArray(5) := Audit_Pkg.Create_Detail_Record_F('IS_COML_STAGE', :NEW.IS_COML_STAGE, :OLD.IS_COML_STAGE);
    lAuditDetailArray(6) := Audit_Pkg.Create_Detail_Record_F('STAGE_PUBKEY', :NEW.STAGE_PUBKEY, :OLD.STAGE_PUBKEY);

    Audit_Pkg.Write_Audit_P(lTableName , lOperationType, lPrimaryKeyPosition, lAuditDetailArray);
  END IF;
END;
/
SHOW ERRORS;


CREATE OR REPLACE TRIGGER PRODUCT_TRG
  AFTER INSERT OR DELETE OR UPDATE
  ON PRODUCT   FOR EACH ROW
DECLARE
  lOperationType CHAR(1);
  lPrimaryKeyPosition INTEGER := 2;
  lTableName VARCHAR2(30) := 'PRODUCT';
  lAuditDetailArray Audit_Pkg.Audit_Detail_Array_Type;

BEGIN
  IF Audit_Pkg.Do_Audit_Table_F(lTableName) THEN

    IF INSERTING THEN lOperationType := Audit_Pkg.INSERT_OPERATION;
    ELSIF UPDATING THEN lOperationType := Audit_Pkg.UPDATE_OPERATION;
    ELSIF DELETING THEN lOperationType := Audit_Pkg.DELETE_OPERATION;
    ELSE lOperationType := NULL;
    END IF;

    lAuditDetailArray(1) := Audit_Pkg.Create_Detail_Record_F('LOGICAL_DELETE', :NEW.LOGICAL_DELETE, :OLD.LOGICAL_DELETE);
    lAuditDetailArray(2) := Audit_Pkg.Create_Detail_Record_F('PRODUCT_ID', :NEW.PRODUCT_ID, :OLD.PRODUCT_ID);
    lAuditDetailArray(3) := Audit_Pkg.Create_Detail_Record_F('PRODUCT_PUBKEY', :NEW.PRODUCT_PUBKEY, :OLD.PRODUCT_PUBKEY);
    lAuditDetailArray(4) := Audit_Pkg.Create_Detail_Record_F('BAYER_CODE_ID', :NEW.BAYER_CODE_ID, :OLD.BAYER_CODE_ID);

    Audit_Pkg.Write_Audit_P(lTableName , lOperationType, lPrimaryKeyPosition, lAuditDetailArray);
  END IF;
END;
/
SHOW ERRORS;


CREATE OR REPLACE TRIGGER PRODUCT_NAME_TRG
  AFTER INSERT OR DELETE OR UPDATE
  ON PRODUCT_NAME   FOR EACH ROW
DECLARE
  lOperationType CHAR(1);
  lPrimaryKeyPosition INTEGER := 1;
  lTableName VARCHAR2(30) := 'PRODUCT_NAME';
  lAuditDetailArray Audit_Pkg.Audit_Detail_Array_Type;

BEGIN
  IF Audit_Pkg.Do_Audit_Table_F(lTableName) THEN

    IF INSERTING THEN lOperationType := Audit_Pkg.INSERT_OPERATION;
    ELSIF UPDATING THEN lOperationType := Audit_Pkg.UPDATE_OPERATION;
    ELSIF DELETING THEN lOperationType := Audit_Pkg.DELETE_OPERATION;
    ELSE lOperationType := NULL;
    END IF;

    lAuditDetailArray(1) := Audit_Pkg.Create_Detail_Record_F('PRODUCT_NAME_ID', :NEW.PRODUCT_NAME_ID, :OLD.PRODUCT_NAME_ID);
    lAuditDetailArray(2) := Audit_Pkg.Create_Detail_Record_F('PRODUCT_NAME_PUBKEY', :NEW.PRODUCT_NAME_PUBKEY, :OLD.PRODUCT_NAME_PUBKEY);
    lAuditDetailArray(3) := Audit_Pkg.Create_Detail_Record_F('PRODUCT_NAME', :NEW.PRODUCT_NAME, :OLD.PRODUCT_NAME);
    lAuditDetailArray(4) := Audit_Pkg.Create_Detail_Record_F('PRODUCT_ID', :NEW.PRODUCT_ID, :OLD.PRODUCT_ID);
    lAuditDetailArray(5) := Audit_Pkg.Create_Detail_Record_F('COML_TRAIT_STACK_ID', :NEW.COML_TRAIT_STACK_ID, :OLD.COML_TRAIT_STACK_ID);
    lAuditDetailArray(6) := Audit_Pkg.Create_Detail_Record_F('COUNTRY_ID', :NEW.COUNTRY_ID, :OLD.COUNTRY_ID);
    lAuditDetailArray(7) := Audit_Pkg.Create_Detail_Record_F('BRAND_ID', :NEW.BRAND_ID, :OLD.BRAND_ID);
    lAuditDetailArray(8) := Audit_Pkg.Create_Detail_Record_F('COMMERCIAL_MATURITY', :NEW.COMMERCIAL_MATURITY, :OLD.COMMERCIAL_MATURITY);
    lAuditDetailArray(9) := Audit_Pkg.Create_Detail_Record_F('VERIFIED_DATA_SOURCE', :NEW.VERIFIED_DATA_SOURCE, :OLD.VERIFIED_DATA_SOURCE);
    lAuditDetailArray(10) := Audit_Pkg.Create_Detail_Record_F('DATA_SOURCE_YEAR', :NEW.DATA_SOURCE_YEAR, :OLD.DATA_SOURCE_YEAR);
    lAuditDetailArray(11) := Audit_Pkg.Create_Detail_Record_F('COMMENTS', :NEW.COMMENTS, :OLD.COMMENTS);
    lAuditDetailArray(12) := Audit_Pkg.Create_Detail_Record_F('IS_ACTIVE', :NEW.IS_ACTIVE, :OLD.IS_ACTIVE);
    lAuditDetailArray(13) := Audit_Pkg.Create_Detail_Record_F('LOGICAL_DELETE', :NEW.LOGICAL_DELETE, :OLD.LOGICAL_DELETE);

    Audit_Pkg.Write_Audit_P(lTableName , lOperationType, lPrimaryKeyPosition, lAuditDetailArray);
  END IF;
END;
/
SHOW ERRORS;

alter trigger lexicon.brand_trg enable;

alter trigger lexicon.crop_trg enable;

