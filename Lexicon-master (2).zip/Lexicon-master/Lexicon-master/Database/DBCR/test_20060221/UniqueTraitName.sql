DROP TRIGGER Lexicon.Coml_Trait_Name2_Trg
/

ALTER TABLE Lexicon.Coml_Trait_Name2 
	DROP CONSTRAINT COML_TRAIT_NAME_CROP_FK
/

ALTER TABLE Lexicon.Coml_Trait_Name2
	DROP CONSTRAINT Coml_Trait_Name2_AK1;

ALTER TABLE Lexicon.Coml_Trait_Name2
	DROP COLUMN Crop_Id
/

ALTER TABLE Lexicon.Coml_Trait_Name2
	ADD CONSTRAINT Coml_Trait_Name2_AK1
		UNIQUE (Trait_Abbr) 
		USING INDEX 
	TABLESPACE  Lexicon_Index
/

