

CREATE OR REPLACE PACKAGE DSR_PULL AS
/*************************************************************************
Module Name:DSR_PULL.pks

Author:Marty Kinsey

Create Date: December 1998

Overview:
 
 Modification History :

  $Id: CreatePullPackage.sql,v 1.1 2006-01-13 16:35:57 jaskidi Exp $
  $Log: not supported by cvs2svn $
  Revision 1.1  2005/12/14 18:34:59  jaskidi
  *** empty log message ***

  Revision 1.4  2003/02/26 21:49:05  nnwahe
  Uncommented the CREATE statement.

  Revision 1.3  2003/02/13 14:30:27  rktorbe
  Original DSRP code

TO RUN THE PULL PACKAGE EXECUTE THIS STATEMENT FOR EACH SUBJECT-AREA 
 
  exec dsr_pull.pull_target_subject_area('xx') where xx is the SUBJECT_AREA

*************************************************************************
  Private procedures:
     PULL_TARGET_SUBJECT_AREA
       Given a feed data warhouse subject area ID, pull ID,
         beginning subject area run ID and ending subject area run ID,
       this procedure will insert into the appropriate data warehouse
         table(s).

     PULL_TABLES
       Given a feed data warhouse subject area ID, pull ID,
         beginning subject area run ID and ending subject area run ID,
       this procedure will insert into the appropriate data warehouse
         table(s).
  
     DELETE_TABLE_ROWS
       Given a feed data warhouse target ID, subject area ID, pull ID,
       beginning subject area run ID and ending subject area run ID,
         this procedure will delete any existing matching rows from the
         data warehouse.
  
   REVISION LOG:
     2001/02/26 - DSDUFA:  Procedure PULL_TABLES:
         Revised restart processing - errors were being caused when
         restart was for the first (or only) table within a subject
         area, because the SELECT that tried to find last successful
         table from previous run relied on a SQL%NOTFOUND against a
         MAX function to indicate that no tables had been completed
         successfully, but a grouping function (like MAX) will never
         return a SQL%NOTFOUND condition.  Restructured logic in this
         routine to use a SELECT COUNT(*) instead.
*******************************************************************/

  PROCEDURE PULL_TARGET_SUBJECT_AREA
        (i_subject_area_id              IN              varchar2);
  PROCEDURE UPDATE_SUBJECT_AREA_PULL_LOG
        (i_subject_area_id              IN              varchar2,
         i_status                       IN OUT  		varchar2,
         o_pull_id                      IN OUT  		integer,
         o_beg_subject_area_run_id      IN OUT          integer,
         o_end_subject_area_run_id      IN OUT          integer);
  PROCEDURE UPDATE_TABLE_PULL_LOG
        (i_subject_area_id              IN              varchar2,
         i_table_name                   IN              varchar2,
         i_pull_id                      IN              integer,
         i_status                       IN              varchar2,
         i_row_count                    IN              integer);
  PROCEDURE PULL_TABLES
        (i_subject_area_id              IN              varchar2,
         i_pull_id                      IN              integer,
         i_beg_subject_area_run_id      IN              integer,
         i_end_subject_area_run_id      IN              integer,
         i_status                       IN              varchar2);
  PROCEDURE DELETE_TABLE_ROWS
        (i_subject_area_id              IN              varchar2,
        i_pull_id                       IN              integer,
        i_beg_subject_area_run_id       IN              integer,
        i_end_subject_area_run_id       IN              integer,
        i_table_name                    IN              varchar2,
        i_source_name                   IN              varchar2,
        i_dsr_schema_name               IN              varchar2,
        i_target_schema_name            IN              varchar2,
        i_db_link_name                  IN              varchar2,
	i_update_type			IN		varchar2);
END DSR_PULL;
/


CREATE OR REPLACE PACKAGE BODY DSR_PULL AS
/**************************************************************************
Module Name:DSR_PULL.pkb

Author: Marty Kinsey

Create Date: December 1998

Overview:
 
 Modification History :

  $Id: CreatePullPackage.sql,v 1.1 2006-01-13 16:35:57 jaskidi Exp $
  $Log: not supported by cvs2svn $
  Revision 1.1  2005/12/14 18:34:59  jaskidi
  *** empty log message ***

  Revision 1.9  2003/03/07 15:39:18  nnwahe
  Initial WinCVS insert.


  2001/02/26 - DSDUFA:  Procedure PULL_TABLES:
      Revised restart processing - errors were being caused when  
      restart was for the first (or only) table within a subject
      area, because the SELECT that tried to find last successful
      table from previous run relied on a SQL%NOTFOUND against a
       MAX function to indicate that no tables had been completed 
       successfully, but a grouping function (like MAX) will never 
       return a SQL%NOTFOUND condition.  Restructured logic in this
       routine to use a SELECT COUNT(*) instead.

  2002-07-02 -- Ted Palmer Procedure UPDATE_SUBJECT_AREA_PULL_LOG:
       Modified this procedure so that it would get the value for
       ENDING_SUBJECT_AREA_RUN_ID from table SUBJECT_AREA_NOTIFICATION
       instead of from table SUBJECT_AREA_RUN_LOG. The old way caused
       rows to be missed on target DW table pulls that started after a
       second SAP extract schedule began before a first SAP extract
       schedule data had been pulled by its target DW; e.g.
       The NOON scheduled SAP extract
       completed but the 09:00 PM SAP extract began before a target DW
       started pulling its data for the NOON SAP extract. The 1st thing
       that happens when an SAP extract begins is that the
       SUBJECT_AREA_RUN_ID (SARID) in table SUBJECT_AREA_RUN_LOG is
       incremented. The target DW was using this incremented SARID in
       its pull but the 2nd SAP extract had not finished getting all
       of its data from SAP.
  2002-07-10  "AND (SAN.dw_status is null OR SAN.dw_status <> 'C');"
       -- Walter suggested I remove this line from the SELECT statement that
       gets the ending_SARID to make it easier for failed pull recovery.
       He is right. SAN.dw_status has been adaquately checked in other
       procedures before "the process" gets to this point.

**************************************************************************/

PROCEDURE UPDATE_SUBJECT_AREA_PULL_LOG
        (i_subject_area_id              IN              varchar2,
         i_status                               IN OUT  varchar2,
         o_pull_id                              IN OUT  integer,
         o_beg_subject_area_run_id      IN OUT             integer,
         o_end_subject_area_run_id      IN OUT             integer)
is
---------------------------------------------------------------------------------
-- Working Area.
---------------------------------------------------------------------------------
        x_subject_area_id               varchar2(2);
        x_status                        varchar2(2);
        x_target_id                     varchar2(2);
        x_procname                      varchar2(30);
        x_beg_subject_area_run_id       integer;
        x_end_subject_area_run_id       integer;
        x_new_pull_id                   integer;
        x_cursor_handle                 integer;
        x_row_count                     integer;
        x_restart_pull_count            integer;
        x_pull_id                       integer;
	x_any_runs_in_progress_count	integer;
        x_statement                     varchar2(1000);
        user_exception                  EXCEPTION;
	run_out_of_sequence_exception	EXCEPTION;
	ending_sarid_exception      EXCEPTION;
BEGIN
---------------------------------------------------------------------------------
-- Initialize Working Area parameters.
---------------------------------------------------------------------------------
        x_procname              :=  'UPDATE_SUBJECT_AREA_PULL_LOG';
        x_subject_area_id       :=  i_subject_area_id;
        x_status                :=  i_status;
        x_pull_id               :=  o_pull_id;
        x_beg_subject_area_run_id := o_beg_subject_area_run_id;
        x_end_subject_area_run_id := o_end_subject_area_run_id;
	x_any_runs_in_progress_count	:= 0;
        
	SELECT    default_value
        INTO x_target_id
        FROM DW_DEFAULT
        WHERE     default_id = 'TARGET ID';
---------------------------------------------------------------------------------
-- Decide whether an insert or update is to be performed.  This is determined by
-- the following logic:  if input status = "S" (start), do an insert; otherwise
-- do an update.
---------------------------------------------------------------------------------
        If (x_status != 'C')
        Or (x_status is null)
        Then
---------------------------------------------------------------------------------
-- Check to see if this is a restart.  If the count from the call below is 0,
-- this is a normal start.  Otherwise, it's a restart.
---------------------------------------------------------------------------------
                SELECT  count(*)
                INTO  x_restart_pull_count
                FROM  DW_SUBJECT_AREA_PULL_LOG SAPL
                WHERE           SAPL.subject_area_id    =  x_subject_area_id
                AND             DW_Status                       != 'C';
                If x_restart_pull_count = 0
                THEN
--------------------------------------------------------------------------------
-- Check to see if ANY ACTA jobs for the Subject Area are in the process of running.
--------------------------------------------------------------------------------
     			SELECT    count(*)
			INTO x_any_runs_in_progress_count
     			FROM SUBJECT_AREA_NOTIFICATION
     			WHERE	dw_target_id    =  x_target_id
     			AND  	subject_area_id =  x_subject_area_id
     			AND	dsr_status 	=  'S';
     			If x_any_runs_in_progress_count > 0
     			THEN
          			RAISE user_exception;
     			END IF;
---------------------------------------------------------------------------------
-- This is a normal start.  Select the last pull_id and its corresponding
-- ending_subject_area_run_id from DW_SUBJECT_AREA_PULL_LOG for the input
-- i_subject_area_id.
---------------------------------------------------------------------------------
                        SELECT SAPL.ending_subject_area_run_id + 1,
                               max(SAPL.pull_id) + 1
                          INTO x_beg_subject_area_run_id,
                               x_new_pull_id
                          FROM DW_SUBJECT_AREA_PULL_LOG SAPL
                         WHERE SAPL.subject_area_id = x_subject_area_id
                           AND SAPL.pull_id            =
                               (SELECT max(SAPL2.pull_id)
                                  FROM DW_SUBJECT_AREA_PULL_LOG SAPL2
                                 WHERE SAPL2.subject_area_id = SAPL.subject_area_id)
                              GROUP BY sapl.subject_area_id,
                                       sapl.pull_id,
                                       sapl.ending_subject_area_run_id;

---------------------------------------------------------------------------------
-- Get the ending_subject_area_run_id for this pull from the
-- DSR.SUBJECT_AREA_NOTIFICATION table.
---------------------------------------------------------------------------------
                       SELECT max(SAN.subject_area_run_id)
                         INTO x_end_subject_area_run_id
                         FROM SUBJECT_AREA_NOTIFICATION SAN
                        WHERE (SAN.subject_area_id = x_subject_area_id)
                          AND (SAN.dw_target_id    = x_target_id)
                          AND (SAN.dsr_status = 'C');
                    
                        if x_end_subject_area_run_id is null then
          		        RAISE ending_sarid_exception;
                        end if;

---------------------------------------------------------------------------------
-- Insert to the local DW_SUBJECT_AREA_PULL_LOG and Set up and run the
-- dynamic SQL statement to insert the new pull_id and
-- corresponding beginning / ending_subject_area_run_id into
-- DW_SUBJECT_AREA_PULL_LOG for the input i_subject_area_id.
---------------------------------------------------------------------------------
                        INSERT INTO DW_SUBJECT_AREA_PULL_LOG
                                (
                                SUBJECT_AREA_ID,
                                PULL_ID,
                                ROW_INSERT_DATE,
                                ROW_INSERT_USER_ID,
                                ROW_INSERT_TASK_ID,
                                ROW_UPDATE_DATE,
                                ROW_UPDATE_USER_ID,
                                ROW_UPDATE_TASK_ID,
                                DW_COMPLETION_DATE_TIME,
                                DW_STATUS,
                                BEGINNING_SUBJECT_AREA_RUN_ID,
                                ENDING_SUBJECT_AREA_RUN_ID
                                )
		         VALUES (
                                x_subject_area_id,
                                x_new_pull_id,
                                null,
                                null,
                                null,
                                null,
                                null,
                                null,
                                null,
                                'S',
				x_beg_subject_area_run_id,
                                x_end_subject_area_run_id);

			---------------------------------------------------------------------------------
			-- Initialize the OUT parameters with the appropriate values
			---------------------------------------------------------------------------------
			If x_beg_subject_area_run_id 	>   x_end_subject_area_run_id
			Then
				rollback;
				raise run_out_of_sequence_exception;
			End If;
                        o_pull_id                       :=  x_new_pull_id;
                        o_beg_subject_area_run_id       :=  x_beg_subject_area_run_id;
                        o_end_subject_area_run_id       :=  x_end_subject_area_run_id;
                Else
---------------------------------------------------------------------------------
-- The following logic is for a Restart status.
---------------------------------------------------------------------------------
                        i_status :=  'R';
                        x_status :=  'R';
                        SELECT SAPL.beginning_subject_area_run_id,
                               SAPL.ending_subject_area_run_id,
                               SAPL.pull_id
                          INTO x_beg_subject_area_run_id,
                               x_end_subject_area_run_id,
                               x_new_pull_id
                          FROM DW_SUBJECT_AREA_PULL_LOG SAPL
                         WHERE SAPL.subject_area_id = x_subject_area_id
                           AND DW_STATUS in  ('S', 'R');
                        
			o_pull_id :=  x_new_pull_id;
                        o_beg_subject_area_run_id :=  x_beg_subject_area_run_id;
                        o_end_subject_area_run_id :=  x_end_subject_area_run_id;

                        UPDATE DW_SUBJECT_AREA_PULL_LOG
                           SET DW_STATUS = x_status
                         WHERE SUBJECT_AREA_ID = x_subject_area_id
                           AND DW_STATUS in ('S', 'R');

                END IF;
        Else
---------------------------------------------------------------------------------
-- The input status was not "S" or "R" which means we are updating the status.
-- Update the local DW_SUBJECT_AREA_PULL_LOG and Set up and run the
-- dynamic SQL statement to update the status for the new pull_id and
-- corresponding beginning / ending_subject_area_run_id into
-- DW_SUBJECT_AREA_PULL_LOG for the input i_subject_area_id.
---------------------------------------------------------------------------------
                        UPDATE DW_SUBJECT_AREA_PULL_LOG
                           SET DW_STATUS =  x_status,
                               DW_COMPLETION_DATE_TIME = sysdate
                         WHERE SUBJECT_AREA_ID = x_subject_area_id
                           AND PULL_ID = x_pull_id;
        
        End If;
--------------------------------------------------------------------------------
-- Update the SUBJECT_AREA_NOTIFICATION table with the appropriate dw_status.
-- IMPORTANT NOTE:  In order for the target instances to obtain access to the
-- SUBJECT_AREA_NOTIFICATION table on the DSR instance, each targe must establish
-- a private synonym to the SUBJECT_AREA_NOTIFICATION table.
--------------------------------------------------------------------------------
     UPDATE SUBJECT_AREA_NOTIFICATION
        SET dw_status = x_status
      WHERE subject_area_id = x_subject_area_id
        AND dw_target_id = x_target_id
        AND subject_area_run_id between x_beg_subject_area_run_id and x_end_subject_area_run_id
        AND  (dw_status is null
         OR   dw_status <> 'C');

EXCEPTION
        WHEN no_data_found
        THEN
                raise_application_error (-20001, 'Error in Stored Procedure: '
                        ||x_procname||' - Select Into failed to retrieve data');
        WHEN too_many_rows
        THEN
                raise_application_error (-20002, 'Error in Stored Procedure: '
                        ||x_procname||' - Select Into returned too many rows');
        WHEN user_exception
        THEN
                raise_application_error (-20003, 'Error in Stored Procedure: '
                        ||x_procname||' - A DSR SAP Pull is in progress - wait until it has completed');
        WHEN run_out_of_sequence_exception
        THEN
                raise_application_error (-20004, 'Error in Stored Procedure: '
                        ||x_procname||' - The beginning_subject_area_run_id is greater than the ending one'
			||' Possibly running before a new DSR run is ready');
        WHEN OTHERS
        THEN
                raise_application_error (-20005, 'Error in Stored Procedure: '
                        ||x_procname||' - '||SQLERRM);
        COMMIT;
END UPDATE_SUBJECT_AREA_PULL_LOG;

/******************UPDATE_TABLE_PULL_LOG********************************/
PROCEDURE UPDATE_TABLE_PULL_LOG
        (i_subject_area_id      IN              varchar2,
         i_table_name           IN              varchar2,
         i_pull_id                      IN              integer,
         i_status                       IN              varchar2,
         i_row_count            IN              integer)
IS
---------------------------------------------------------------------------------
-- Working Area.
---------------------------------------------------------------------------------
        x_subject_area_id                       varchar2(2);
        x_table_name                    varchar2(30);
        x_pull_id                               integer;
        x_status                                varchar2(2);
        x_row_count                             integer;
        x_procname                              varchar2(30);
        x_ending_subject_area_run_id    integer;
        x_cursor_handle                 integer;
        x_dyn_row_count                 integer;
        x_dyn_row_test                  varchar2(100);
        user_exception                  EXCEPTION;
BEGIN
---------------------------------------------------------------------------------
-- Initialize Working Area parameters.
---------------------------------------------------------------------------------
        x_procname              :=  'UPDATE_TABLE_PULL_LOG';
        x_table_name    :=  i_table_name;
        x_subject_area_id       :=  i_subject_area_id;
        x_pull_id               :=  i_pull_id;
        x_status                :=  i_status;
        x_row_count             :=  i_row_count;
---------------------------------------------------------------------------------
-- Decide whether an insert or update is to be performed.  This is determined by
-- the following logic:  if input status = "S" (start), do an insert; otherwise
-- do an update.
---------------------------------------------------------------------------------
        If x_status = 'DS'
        Then
---------------------------------------------------------------------------------
-- The deletes are beginning.  Update DW_TABLE_PULL_LOG setting the status = 'DS'
-- (Delete Started).
---------------------------------------------------------------------------------
                INSERT INTO DW_TABLE_PULL_LOG
                        (
                        SUBJECT_AREA_ID,
                        TABLE_NAME,
                        PULL_ID,
                        ROW_INSERT_DATE,
                        ROW_INSERT_USER_ID,
                        ROW_INSERT_TASK_ID,
                        ROW_UPDATE_DATE,
                        ROW_UPDATE_USER_ID,
                        ROW_UPDATE_TASK_ID,
                        DW_COMPLETION_DATE_TIME,
                        DW_STATUS,
                        DELETED_ROW_COUNT,
                        ROW_COUNT
                        )
                VALUES
                        (
                        x_subject_area_id,
                        x_table_name,
                        x_pull_id,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        x_status,
                        0,
                        0
                        );
        Else
                If x_status = 'IS'
                Then
---------------------------------------------------------------------------------
-- The deletes have just been completed.  Update the DW_TABLE_PULL_LOG with the
-- deleted row count and an 'IS' status (Insert started).
---------------------------------------------------------------------------------
                        UPDATE DW_TABLE_PULL_LOG
                        SET     DW_STATUS                               =  x_status,
                                deleted_row_count                       =  x_row_count
                        WHERE SUBJECT_AREA_ID   = x_subject_area_id
                          AND TABLE_NAME                = x_table_name
                          AND PULL_ID           = x_pull_id;
                Else
---------------------------------------------------------------------------------
-- The inserts have just been completed.  Update the DW_TABLE_PULL_LOG with the
-- inserted row count and an 'C' status (Insert completed).
---------------------------------------------------------------------------------
                        UPDATE DW_TABLE_PULL_LOG
                        SET     DW_STATUS                               =  x_status,
                                row_count                               =  x_row_count,
                                DW_COMPLETION_DATE_TIME         = sysdate
                        WHERE SUBJECT_AREA_ID   = x_subject_area_id
                          AND TABLE_NAME                = x_table_name
                          AND PULL_ID           = x_pull_id;
                End If;
        End If;
        COMMIT;
EXCEPTION
        WHEN no_data_found
        THEN
                raise_application_error (-20001, 'Error in Stored Procedure: '
                        ||x_procname||' - Select Into failed to retrieve data');
        WHEN too_many_rows
        THEN
                raise_application_error (-20002, 'Error in Stored Procedure: '
                        ||x_procname||' - Select Into returned too many rows');
        WHEN OTHERS
        THEN
                raise_application_error (-20003, 'Error in Stored Procedure: '
                        ||x_procname||' - '||SQLERRM);
END UPDATE_TABLE_PULL_LOG;



/******************DELETE_TABLE_ROWS********************************/
PROCEDURE DELETE_TABLE_ROWS
        (i_subject_area_id              IN              varchar2,
        i_pull_id                       IN              integer,
        i_beg_subject_area_run_id       IN              integer,
        i_end_subject_area_run_id       IN              integer,
        i_table_name                    IN              varchar2,
        i_source_name                   IN              varchar2,
        i_dsr_schema_name               IN              varchar2,
        i_target_schema_name            IN              varchar2,
        i_db_link_name                  IN              varchar2,
	i_update_type			IN		varchar2)
IS
---------------------------------------------------------------------------------
-- Working Area.
---------------------------------------------------------------------------------
        x_subject_area_id                       varchar2(2);
        x_pull_id                               integer;
        x_beg_subject_area_run_id       integer;
        x_end_subject_area_run_id       integer;
        x_table_name                    varchar2(30);
        x_source_name                   varchar2(30);
        x_dsr_schema_name               varchar2(30);
        x_target_schema_name            varchar2(30);
        x_procname                      varchar2(30);
        x_column_name                   varchar2(30);
        x_column_list                   varchar2(4000);
        x_cursor_handle                 integer;
        x_row_count                     integer;
        x_db_link_name                  varchar2(50);
		x_update_type					varchar2(1);
        user_exception                  EXCEPTION;
---------------------------------------------------------------------------------
-- Cursor to identify the Primary key columns for the delete
---------------------------------------------------------------------------------
CURSOR  PRIMARY_KEY_COLUMNS IS
SELECT  column_name
FROM    ALL_CONS_COLUMNS
WHERE   owner           =  x_target_schema_name
AND     table_name      =  x_table_name
AND     constraint_name = (SELECT constraint_name
                           FROM     ALL_CONSTRAINTS
                           WHERE    owner           = x_target_schema_name
                           AND      table_name      = x_table_name
                           AND      constraint_type = 'P');
BEGIN
---------------------------------------------------------------------------------
-- Initialize Working Area parameters.
---------------------------------------------------------------------------------
        x_procname                      :=  'DELETE_TABLE_ROWS';
        x_subject_area_id               :=  i_subject_area_id;
        x_pull_id                       :=  i_pull_id;
        x_beg_subject_area_run_id       :=  i_beg_subject_area_run_id;
        x_end_subject_area_run_id       :=  i_end_subject_area_run_id;
        x_table_name                    :=  i_table_name;
        x_source_name                   :=  i_source_name;
        x_dsr_schema_name               :=  i_dsr_schema_name;
        x_target_schema_name            :=  i_target_schema_name;
        x_db_link_name                  :=  i_db_link_name;
		x_update_type					:=	i_update_type;
        x_column_list := '';

---------------------------------------------------------------------------------
--  Determine the Primary key columns and create a string of them
---------------------------------------------------------------------------------
        OPEN PRIMARY_KEY_COLUMNS;
        LOOP
                FETCH PRIMARY_KEY_COLUMNS into x_column_name;
                EXIT WHEN NOT PRIMARY_KEY_COLUMNS%FOUND;
                x_column_list := x_column_list||','||x_column_name;
        END LOOP;
        CLOSE PRIMARY_KEY_COLUMNS;
        x_column_list := substr(x_column_list,2);
---------------------------------------------------------------------------------
--  Set up and run the dynamic SQL statement to delete all corresponding records
--  that will be inserted next.  If the update_type from DW_TABLE is set to "I"
--	(incremental), then only delete the rows for the subject_area_run_id(s) that
--	are being processed.  If the update_type is set to "F" (full), then delete all
--	rows from the table in anticipation of a full refresh.
---------------------------------------------------------------------------------
		If x_update_type = 'I'
		Then
			x_cursor_handle := DBMS_SQL.OPEN_CURSOR;
			DBMS_SQL.PARSE
			(x_cursor_handle,
			'DELETE FROM '||x_target_schema_name||'.'||x_table_name||' WHERE ('||
			x_column_list||') IN (SELECT '||x_column_list||
			' FROM '||x_dsr_schema_name||'.'||x_source_name||x_db_link_name||
			' WHERE subject_area_run_id BETWEEN '||
			x_beg_subject_area_run_id||' AND '||
			x_end_subject_area_run_id||')',
			DBMS_SQL.V7);
			x_row_count := DBMS_SQL.EXECUTE (x_cursor_handle);
			DBMS_SQL.CLOSE_CURSOR (x_cursor_handle);
		Else
			If x_update_type = 'F'
			Then
				x_cursor_handle := DBMS_SQL.OPEN_CURSOR;
				DBMS_SQL.PARSE
				(x_cursor_handle,
				'DELETE FROM '||x_target_schema_name||'.'||x_table_name,
				DBMS_SQL.V7);
				x_row_count := DBMS_SQL.EXECUTE (x_cursor_handle);
				DBMS_SQL.CLOSE_CURSOR (x_cursor_handle);
			Else
				Raise user_exception;
			End If;
		End If;
        COMMIT;
---------------------------------------------------------------------------------
-- Update the DW_TABLE_PUSH_LOG with a status of "IS" (Insert Started)
---------------------------------------------------------------------------------
        UPDATE_TABLE_PULL_LOG
                (
                x_subject_area_id,
                x_table_name,
                x_pull_id,
                'IS',
                x_row_count
                );
---------------------------------------------------------------------------------
-- Exception Processing
---------------------------------------------------------------------------------
        EXCEPTION
                WHEN no_data_found
                THEN
                        raise_application_error (-20001, 'Error in Stored Procedure: '
                                ||x_procname||' - Select Into failed to retrieve data');
                WHEN too_many_rows
                THEN
                        raise_application_error (-20002, 'Error in Stored Procedure: '
                                ||x_procname||' - Select Into returned too many rows');
				WHEN user_exception
				THEN
                        raise_application_error (-20003, 'Error in Stored Procedure: '
                                ||x_procname||' - DW_TABLE.update_type NOT I or F!  Table_name ---> '
								|| x_table_name);
                WHEN OTHERS
                THEN
                        raise_application_error (-20004, 'Error in Stored Procedure: '
                                ||x_procname||' - '||SQLERRM);
END DELETE_TABLE_ROWS;
/******************PULL_TABLES********************************/
PROCEDURE PULL_TABLES
        (i_subject_area_id                      IN              varchar2,
         i_pull_id                              IN              integer,
         i_beg_subject_area_run_id              IN              integer,
         i_end_subject_area_run_id              IN              integer,
         i_status                               IN              varchar2)
IS
---------------------------------------------------------------------------------
-- Working Area.
---------------------------------------------------------------------------------
        x_subject_area_id                       varchar2(2);
        x_pull_id                               integer;
        x_beg_subject_area_run_id               integer;
        x_end_subject_area_run_id               integer;
        x_procname                              varchar2(30);
        x_table_name                            varchar2(30);
        x_view_name                             varchar2(30);
        x_column_name                           varchar2(30);
        x_column_list                           varchar2(4000);
        x_cursor_handle                         integer;
        x_row_count                             integer;
        x_source_name                           varchar2(30);
        x_status                                varchar2(2);
        x_restart_table                         varchar2(30);
        x_restart_first_pass                    varchar2(1);
        x_target_schema_name                    varchar2(30);
        x_dsr_schema_name                       varchar2(30);
        x_db_link_name                          varchar2(50);
        x_target                                varchar2(2);
        x_column_filter                         varchar2(10);
        x_check_table_pull_log                  integer;
	x_update_type				varchar2(1);
        user_exception                          EXCEPTION;
	v_complete_count			number    := 0;

---------------------------------------------------------------------------------
-- Cursor which contains DW_TABLE.table_name(s) and view_name(s).
---------------------------------------------------------------------------------
        CURSOR  CUR_TABLE_NAME IS
        SELECT  table_name,
                view_name,
		update_type
        FROM            DW_TABLE
        WHERE           dw_target_id    = x_target
        AND             subject_area_id = x_subject_area_id
        AND             status          = 'A'
        ORDER BY        table_name;
---------------------------------------------------------------------------------
-- Cursor which contains USER_TAB_COLUMNS.column_name(s).
---------------------------------------------------------------------------------
        CURSOR  CUR_COLUMN_NAME IS
        SELECT  column_name
        FROM            ALL_TAB_COLUMNS
        WHERE           table_name      = x_table_name
        AND             owner           = x_target_schema_name
        AND             column_name not like x_column_filter;
BEGIN

---------------------------------------------------------------------------------
-- Initialize Working Area parameters.
---------------------------------------------------------------------------------
        x_procname :=  'PULL_TABLES';
        x_subject_area_id :=  i_subject_area_id;
        x_pull_id :=  i_pull_id;
        x_beg_subject_area_run_id :=  i_beg_subject_area_run_id;
        x_end_subject_area_run_id :=  i_end_subject_area_run_id;
        x_status :=  i_status;

        SELECT  default_value
        INTO            x_target_schema_name
        FROM            DW_DEFAULT
        WHERE           default_id = 'TARGET SCHEMA';
        SELECT  default_value
        INTO            x_dsr_schema_name
        FROM            DW_DEFAULT
        WHERE           default_id = 'DSR SCHEMA';
        SELECT  default_value
        INTO            x_db_link_name
        FROM            DW_DEFAULT
        WHERE           default_id = 'DSR DB LINK NAME';
        SELECT  default_value
        INTO            x_target
        FROM            DW_DEFAULT
        WHERE           default_id = 'TARGET ID';
        SELECT  default_value
        INTO            x_column_filter
        FROM            DW_DEFAULT
        WHERE           default_id = 'COLUMN FILTER';
---------------------------------------------------------------------------------
-- Check to see if this is a restart.  If so, get the last table_name that was
-- being loaded when the previous abend occurred.
---------------------------------------------------------------------------------
  --* Default restart flag as N (NO Restart)
  x_restart_first_pass    :=  'N';
  if x_status = 'R' then
      --* Indicate RESTART for first pass of main processing loop.
      x_restart_first_pass := 'Y';
      --* If input status indicates this is a restart, then
      --*   check to see if any tables were successfully
      --*   completed in the previous (failed) run.
      SELECT count(*)
        INTO v_complete_count
          FROM DW_TABLE_PULL_LOG
            WHERE SUBJECT_AREA_ID   = x_subject_area_id
              AND PULL_ID           = x_pull_id
              AND DW_STATUS         = 'C';
      --* If any tables were successfully completed in the
      --*   previous (failed) run, then determine which table
      --*   was the last one successfully completed.
      if v_complete_count > 0 then
          SELECT max(TABLE_NAME)
            INTO x_restart_table
              FROM DW_TABLE_PULL_LOG
                WHERE SUBJECT_AREA_ID   = x_subject_area_id
                  AND PULL_ID           = x_pull_id
                  AND DW_STATUS         = 'C';
      else
          --* NO tables were successfully completed in the previous
          --*   (failed) run -- restart with first possible table.
          x_restart_table := NULL;
      end if;
  else
      --* Input status indicates this is *NOT* a restart.
      x_restart_first_pass    :=  'N';
  end if;
---------------------------------------------------------------------------------
-- Load the TABLE_NAME cursor with the DW_TABLE.table_name(s)
---------------------------------------------------------------------------------
  OPEN CUR_TABLE_NAME;
---------------------------------------------------------------------------------
-- Select each of the table / view names from the cursor for processing.  If view
-- name is not null, load view name into x_source; otherwise, load table name into
-- x_source.  If this is a restart and it's the 1st pass through this logic,
-- read through the CUR_TABLE_NAME cursor until you reach the last table that was
-- being updated during the previous abend.
---------------------------------------------------------------------------------
  LOOP
      --* If this is a RESTART, then some extra processing is done in the
	  --*   FIRST PASS of this loop (controlled by x_restart_first_pass).
      if x_restart_first_pass = 'Y' then
          --* Reset the controlling flag.
          x_restart_first_pass    :=  'N';
	      --* If any tables were successfully completed in the
          --*   previous (failed) run, then the main processing loop must
		  --*   start with the first table after the last successfully
		  --*   completed table.  Loop thru cursor to find this table.
	      if x_restart_table is NOT NULL then
              LOOP
                  FETCH CUR_TABLE_NAME
			        into x_table_name,
                         x_view_name,
                         x_update_type;
                    EXIT WHEN x_table_name =  x_restart_table
                           OR NOT CUR_TABLE_NAME%FOUND;
              END LOOP;
          end if;
		  --* Fetch the name of the first table to actually process.
          FETCH CUR_TABLE_NAME
		    into x_table_name,
                 x_view_name,
                 x_update_type;
            EXIT WHEN NOT CUR_TABLE_NAME%FOUND;
          --* If there is already a row in DW_TABLE_PULL_LOG for this
		  --*   table (i.e. previous run abended on this table after it
		  --*   had started, and left a row in DW_TABLE_PULL_LOG), then
		  --*   use it.  If there is not already a row, call UPDATE_
		  --*   TABLE_PULL_LOG to insert a new row.
          SELECT count(*)
            INTO x_check_table_pull_log
              FROM DW_TABLE_PULL_LOG
                WHERE subject_area_id  =  x_subject_area_id
                  AND table_name       =  x_table_name
                  AND pull_id          =  x_pull_id;
          if x_check_table_pull_log = 0 then
              UPDATE_TABLE_PULL_LOG
                  ( x_subject_area_id,
                    x_table_name,
                    x_pull_id,
                    'DS',
                    0      );
          end if;
      --* THIS IS NOT THE FIRST PASS OF A RESTART!  Normal processing:
	  --*   Fetch next table name to be processed, and call UPDATE_
	  --*   TABLE_PULL_LOG to insert a new row into DW_TABLE_PULL_LOG
	  --*   for that table.
      else
          FETCH CUR_TABLE_NAME
		    into x_table_name,
                 x_view_name,
                 x_update_type;
            EXIT WHEN NOT CUR_TABLE_NAME%FOUND;
          UPDATE_TABLE_PULL_LOG
              ( x_subject_area_id,
                x_table_name,
                x_pull_id,
                'DS',
                0      );
      end if;
      if x_view_name is null then
	      x_source_name   := x_table_name;
      else
          x_source_name   := x_view_name;
      end if;
---------------------------------------------------------------------------------
-- Delete table rows from target that will be processed in this run.
---------------------------------------------------------------------------------
      DELETE_TABLE_ROWS
          ( x_subject_area_id,
            x_pull_id,
            x_beg_subject_area_run_id,
            x_end_subject_area_run_id,
            x_table_name,
            x_source_name,
            x_dsr_schema_name,
            x_target_schema_name,
            x_db_link_name,
			x_update_type   );
---------------------------------------------------------------------------------
-- Get all of the column names into a cursor.
---------------------------------------------------------------------------------
      OPEN CUR_COLUMN_NAME;
      x_column_list   := '';
---------------------------------------------------------------------------------
-- Prepare the column list for the insert statement.
---------------------------------------------------------------------------------
      LOOP
          FETCH CUR_COLUMN_NAME into x_column_name;
          EXIT WHEN NOT CUR_COLUMN_NAME%FOUND;
          x_column_list := x_column_list||','||x_column_name;
      END LOOP;
      CLOSE CUR_COLUMN_NAME;
      x_column_list   := substr(x_column_list,2);
---------------------------------------------------------------------------------
-- 	Set up and run the dynamic SQL statement to insert data to the target table.
--	If the update_type from DW_TABLE is set to "I"
--	(incremental), then only delete the rows for the subject_area_run_id(s) that
--	are being processed.  If the update_type is set to "F" (full), then delete all
--	rows from the table in anticipation of a full refresh.
---------------------------------------------------------------------------------
      if x_update_type = 'I' then
	  x_cursor_handle := DBMS_SQL.OPEN_CURSOR;

          DBMS_SQL.PARSE
              ( x_cursor_handle,
                'INSERT INTO ' || x_target_schema_name ||'.'|| x_table_name || ' (' || x_column_list || ')' || 
                ' SELECT ' || x_column_list || 
                ' FROM ' || x_dsr_schema_name ||'.' || x_source_name || x_db_link_name ||
                ' WHERE subject_area_run_id BETWEEN ' || x_beg_subject_area_run_id || 
                ' AND ' || x_end_subject_area_run_id,  DBMS_SQL.V7);

          x_row_count := DBMS_SQL.EXECUTE (x_cursor_handle);
          DBMS_SQL.CLOSE_CURSOR (x_cursor_handle);
      else
          if x_update_type = 'F' then
              x_cursor_handle := DBMS_SQL.OPEN_CURSOR;

              DBMS_SQL.PARSE
                  ( x_cursor_handle,
                    'INSERT INTO ' || x_target_schema_name||'.'|| x_table_name ||' (' || x_column_list || ')' || 
		    ' SELECT ' || x_column_list || 
		    ' FROM ' || x_dsr_schema_name ||'.' || x_source_name || x_db_link_name, DBMS_SQL.V7);

              x_row_count := DBMS_SQL.EXECUTE (x_cursor_handle);
              DBMS_SQL.CLOSE_CURSOR (x_cursor_handle);
          else
              RAISE user_exception;
          end if;
      end if;
---------------------------------------------------------------------------------
-- Update the DW_TABLE_PULL_LOG with a status of "C" (complete)
---------------------------------------------------------------------------------
      UPDATE_TABLE_PULL_LOG
          ( x_subject_area_id,
            x_table_name,
            x_pull_id,
            'C',
            x_row_count  );
  --* END OF MAIN PROCESSING LOOP
  END LOOP;
  CLOSE CUR_TABLE_NAME;
---------------------------------------------------------------------------------
-- Exception Processing
---------------------------------------------------------------------------------
        EXCEPTION
                WHEN no_data_found
                THEN
                        raise_application_error (-20001, 'Error in Stored Procedure: '
                                ||x_procname||' - Select Into failed to retrieve data');
                WHEN too_many_rows
                THEN
                        raise_application_error (-20002, 'Error in Stored Procedure: '
                                ||x_procname||' - Select Into returned too many rows');
				WHEN user_exception
				THEN
                        raise_application_error (-20003, 'Error in Stored Procedure: '
                                ||x_procname||' - DW_TABLE.update_type NOT I or F!  Table_name ---> '
								|| x_table_name);
                WHEN OTHERS
                THEN
                        raise_application_error (-20004, 'Error in Stored Procedure: '
                                ||x_procname||' - '||SQLERRM);
END PULL_TABLES;
/******************PULL_TARGET_SUBJECT_AREA********************************/
PROCEDURE PULL_TARGET_SUBJECT_AREA
        (i_subject_area_id                      IN              varchar2)
IS
---------------------------------------------------------------------------------
-- Working Area.
---------------------------------------------------------------------------------
        x_subject_area_id                       varchar2(2);
        x_pull_id                               integer;
        x_beg_subject_area_run_id               integer;
        x_end_subject_area_run_id               integer;
        x_procname                              varchar2(30);
        x_ACTA_status_count                     integer;
        x_status                                varchar2(2);
        user_exception                          EXCEPTION;
BEGIN
---------------------------------------------------------------------------------
-- Initialize Working Area parameters.
---------------------------------------------------------------------------------
        x_procname              :=  'PULL_TARGET_SUBJECT_AREA';
        x_subject_area_id       :=  i_subject_area_id;

---------------------------------------------------------------------------------
-- Update the DW_SUBJECT_AREA_PULL_LOG with a status of 'S' (start) for the
-- given subject area id.
---------------------------------------------------------------------------------
        x_status                :=  'S';
        UPDATE_SUBJECT_AREA_PULL_LOG
                (
                x_subject_area_id,
                x_status,
                x_pull_id,
                x_beg_subject_area_run_id,
                x_end_subject_area_run_id
                );
---------------------------------------------------------------------------------
-- Process for each table in the given subject area.
---------------------------------------------------------------------------------
        PULL_TABLES
                (
                x_subject_area_id,
                x_pull_id,
                x_beg_subject_area_run_id,
                x_end_subject_area_run_id,
                x_status
                );
---------------------------------------------------------------------------------
-- Update the DW_SUBJECT_AREA_PULL_LOG with a status of 'C' (completed) for the
-- given subject area id.
---------------------------------------------------------------------------------
        x_status                :=  'C';
        UPDATE_SUBJECT_AREA_PULL_LOG
                (
                x_subject_area_id,
                x_status,
                x_pull_id,
                x_beg_subject_area_run_id,
                x_end_subject_area_run_id
                );
        COMMIT;
---------------------------------------------------------------------------------
-- Exception Processing
---------------------------------------------------------------------------------
        EXCEPTION
                WHEN OTHERS
                THEN
                        raise_application_error (-20003, 'Error in Procedure: '
                                ||x_procname||' - '||SQLERRM);
END PULL_TARGET_SUBJECT_AREA;
END DSR_PULL;
/
