CREATE TABLE LEXICON.DW_DEFAULT (
       Default_ID           VARCHAR2(32) NOT NULL,
       row_insert_date      DATE NULL,
       row_insert_user_id   VARCHAR2(20) NULL,
       row_insert_task_id   VARCHAR2(35) NULL,
       row_update_date      DATE NULL,
       row_update_user_id   VARCHAR2(20) NULL,
       row_update_task_id   VARCHAR2(35) NULL,
       Default_Value        VARCHAR2(80) NULL,
	CONSTRAINT PK_DW_DEFAULT
        PRIMARY KEY (Default_ID)
        USING INDEX
    	TABLESPACE LEXICON_INDEX
)
TABLESPACE LEXICON_DATA
/

COMMENT ON COLUMN LEXICON.DW_DEFAULT.Default_ID IS 'The identifier of a system default parameter..';
COMMENT ON COLUMN LEXICON.DW_DEFAULT.row_insert_date IS 'INTERNAL - Date on which the record was created.';
COMMENT ON COLUMN LEXICON.DW_DEFAULT.row_insert_user_id IS 'INTERNAL - user id that inserts the record.';
COMMENT ON COLUMN LEXICON.DW_DEFAULT.row_insert_task_id IS 'INTERNAL - process/task id that inserts the record.';
COMMENT ON COLUMN LEXICON.DW_DEFAULT.row_update_date IS 'INTERNAL - Date on which the record was updated.';
COMMENT ON COLUMN LEXICON.DW_DEFAULT.row_update_user_id IS 'INTERNAL - user id that updates the record.';
COMMENT ON COLUMN LEXICON.DW_DEFAULT.row_update_task_id IS 'INTERNAL - process/task id that updates the record.';
COMMENT ON COLUMN LEXICON.DW_DEFAULT.Default_Value IS 'The value of a system default parameter.';

CREATE TABLE LEXICON.DW_SUBJECT_AREA_PULL_LOG (
       Subject_Area_ID      VARCHAR2(2) NOT NULL,
       Pull_ID              INTEGER NOT NULL,
       row_insert_date      DATE NULL,
       row_insert_user_id   VARCHAR2(20) NULL,
       row_insert_task_id   VARCHAR2(35) NULL,
       row_update_date      DATE NULL,
       row_update_user_id   VARCHAR2(20) NULL,
       row_update_task_id   VARCHAR2(35) NULL,
       DW_Completion_Date_Time DATE NULL,
       DW_Status            VARCHAR2(2) NULL,
       Beginning_Subject_Area_Run_ID NUMBER NULL,
       Ending_Subject_Area_Run_ID NUMBER NULL,
	CONSTRAINT PK_DW_SUBJECT_AREA_PULL_LOG
        PRIMARY KEY (Subject_Area_ID, Pull_ID)
        USING INDEX
    	TABLESPACE LEXICON_INDEX
)
TABLESPACE LEXICON_DATA
/

COMMENT ON TABLE LEXICON.DW_SUBJECT_AREA_PULL_LOG IS 'Logs the occurrence of a push of a given Subject Area''s data to a target data warehouse.';
COMMENT ON COLUMN LEXICON.DW_SUBJECT_AREA_PULL_LOG.Subject_Area_ID IS 'The identifier of a DSR subject area.';
COMMENT ON COLUMN LEXICON.DW_SUBJECT_AREA_PULL_LOG.Pull_ID IS 'Identifies a number of a push (to a target data warehouse).';
COMMENT ON COLUMN LEXICON.DW_SUBJECT_AREA_PULL_LOG.row_insert_date IS 'INTERNAL - Date on which the record was created.';
COMMENT ON COLUMN LEXICON.DW_SUBJECT_AREA_PULL_LOG.row_insert_user_id IS 'INTERNAL - user id that inserts the record.';
COMMENT ON COLUMN LEXICON.DW_SUBJECT_AREA_PULL_LOG.row_insert_task_id IS 'INTERNAL - process/task id that inserts the record.';
COMMENT ON COLUMN LEXICON.DW_SUBJECT_AREA_PULL_LOG.row_update_date IS 'INTERNAL - Date on which the record was updated.';
COMMENT ON COLUMN LEXICON.DW_SUBJECT_AREA_PULL_LOG.row_update_user_id IS 'INTERNAL - user id that updates the record.';
COMMENT ON COLUMN LEXICON.DW_SUBJECT_AREA_PULL_LOG.row_update_task_id IS 'INTERNAL - process/task id that updates the record.';
COMMENT ON COLUMN LEXICON.DW_SUBJECT_AREA_PULL_LOG.DW_Completion_Date_Time IS 'Identifies the completion date/time of a push to a target datawarehouse.';
COMMENT ON COLUMN LEXICON.DW_SUBJECT_AREA_PULL_LOG.DW_Status IS 'Indicates the status of the target datawarehouse''s "pull" of the staging tables for a given subject area (populated by the target datawarehouse).';
COMMENT ON COLUMN LEXICON.DW_SUBJECT_AREA_PULL_LOG.Beginning_Subject_Area_Run_ID IS 'Identifies the beginning Acta run number for a given push.';
COMMENT ON COLUMN LEXICON.DW_SUBJECT_AREA_PULL_LOG.Ending_Subject_Area_Run_ID IS 'Identifies the ending Acta run number for a given push.';

CREATE TABLE LEXICON.DW_TABLE_PULL_LOG (
       Subject_Area_ID      VARCHAR2(2) NOT NULL,
       table_name           VARCHAR2(30) NOT NULL,
       Pull_ID              INTEGER NOT NULL,
       row_insert_date      DATE NULL,
       row_insert_user_id   VARCHAR2(20) NULL,
       row_insert_task_id   VARCHAR2(35) NULL,
       row_update_date      DATE NULL,
       row_update_user_id   VARCHAR2(20) NULL,
       row_update_task_id   VARCHAR2(35) NULL,
       DW_Completion_Date_Time DATE NULL,
       DW_Status            VARCHAR2(2) NULL,
       Deleted_row_count    INTEGER NULL,
       Row_count            INTEGER NULL,
	CONSTRAINT PK_DW_TABLE_PULL_LOG
        PRIMARY KEY (Subject_Area_ID, table_name, Pull_ID)
        USING INDEX
    	TABLESPACE LEXICON_INDEX
)
TABLESPACE LEXICON_DATA
/

COMMENT ON COLUMN LEXICON.DW_TABLE_PULL_LOG.Subject_Area_ID IS 'The identifier of a DSR subject area.';
COMMENT ON COLUMN LEXICON.DW_TABLE_PULL_LOG.table_name IS 'Table name for which instrumentation is performed.';
COMMENT ON COLUMN LEXICON.DW_TABLE_PULL_LOG.Pull_ID IS 'Identifies a number of a push (to a target data warehouse).';
COMMENT ON COLUMN LEXICON.DW_TABLE_PULL_LOG.row_insert_date IS 'INTERNAL - Date on which the record was created.';
COMMENT ON COLUMN LEXICON.DW_TABLE_PULL_LOG.row_insert_user_id IS 'INTERNAL - user id that inserts the record.';
COMMENT ON COLUMN LEXICON.DW_TABLE_PULL_LOG.row_insert_task_id IS 'INTERNAL - process/task id that inserts the record.';
COMMENT ON COLUMN LEXICON.DW_TABLE_PULL_LOG.row_update_date IS 'INTERNAL - Date on which the record was updated.';
COMMENT ON COLUMN LEXICON.DW_TABLE_PULL_LOG.row_update_user_id IS 'INTERNAL - user id that updates the record.';
COMMENT ON COLUMN LEXICON.DW_TABLE_PULL_LOG.row_update_task_id IS 'INTERNAL - process/task id that updates the record.';
COMMENT ON COLUMN LEXICON.DW_TABLE_PULL_LOG.DW_Completion_Date_Time IS 'The data/time on which the DSR completed loading for a given table.';
COMMENT ON COLUMN LEXICON.DW_TABLE_PULL_LOG.DW_Status IS 'The status of the DW table pull (to be set by the target data warehouse as it is pulling data from a staging table).';

CREATE OR REPLACE TRIGGER LEXICON.DW_DEFAULT_INSERT
	BEFORE INSERT
	ON LEXICON.DW_DEFAULT
	FOR EACH ROW
DECLARE
BEGIN
	:NEW.ROW_INSERT_DATE := SYSDATE;
	:NEW.ROW_INSERT_USER_ID := USER;
	IF (:NEW.ROW_INSERT_TASK_ID IS NULL) THEN
		:NEW.ROW_INSERT_TASK_ID := 'UNKNOWN' ; 
	END IF;   
END;
/

CREATE OR REPLACE TRIGGER LEXICON.DW_DEFAULT_UPDATE
	BEFORE UPDATE
	ON LEXICON.DW_DEFAULT
	FOR EACH ROW
DECLARE
BEGIN
	:NEW.ROW_UPDATE_DATE := SYSDATE; 
	:NEW.ROW_UPDATE_USER_ID := USER; 
	IF (:NEW.ROW_UPDATE_TASK_ID IS NULL) THEN 
		:NEW.ROW_UPDATE_TASK_ID := 'UNKNOWN'; 
	END IF; 
END;
/


CREATE OR REPLACE TRIGGER LEXICON.DW_SUBJECT_AREA_PULLLOG_INSERT
	BEFORE INSERT
	ON LEXICON.DW_SUBJECT_AREA_PULL_LOG
	FOR EACH ROW
DECLARE
BEGIN
	:NEW.ROW_INSERT_DATE := SYSDATE;
	:NEW.ROW_INSERT_USER_ID := USER;
	IF (:NEW.ROW_INSERT_TASK_ID IS NULL) THEN
		:NEW.ROW_INSERT_TASK_ID := 'UNKNOWN' ; 
	END IF;   
END;
/

CREATE OR REPLACE TRIGGER LEXICON.DW_SUBJECT_AREA_PULLLOG_UPDATE
	BEFORE UPDATE
	ON LEXICON.DW_SUBJECT_AREA_PULL_LOG
	FOR EACH ROW
DECLARE
BEGIN
	:NEW.ROW_UPDATE_DATE := SYSDATE; 
	:NEW.ROW_UPDATE_USER_ID := USER; 
	IF (:NEW.ROW_UPDATE_TASK_ID IS NULL) THEN 
		:NEW.ROW_UPDATE_TASK_ID := 'UNKNOWN'; 
	END IF; 
END;
/


CREATE OR REPLACE TRIGGER LEXICON.DW_TABLE_PULLLOG_INSERT
	BEFORE INSERT
	ON DW_TABLE_PULL_LOG
	FOR EACH ROW
DECLARE
BEGIN
	:NEW.ROW_INSERT_DATE := SYSDATE;
	:NEW.ROW_INSERT_USER_ID := USER;
	IF (:NEW.ROW_INSERT_TASK_ID IS NULL) THEN
		:NEW.ROW_INSERT_TASK_ID := 'UNKNOWN' ; 
	END IF;   
END;
/

CREATE OR REPLACE TRIGGER LEXICON.DW_TABLE_PULLLOG_UPDATE
	BEFORE UPDATE
	ON DW_TABLE_PULL_LOG
	FOR EACH ROW
DECLARE
BEGIN
	:NEW.ROW_UPDATE_DATE := SYSDATE; 
	:NEW.ROW_UPDATE_USER_ID := USER; 
	IF (:NEW.ROW_UPDATE_TASK_ID IS NULL) THEN 
		:NEW.ROW_UPDATE_TASK_ID := 'UNKNOWN'; 
	END IF; 
END;
/

