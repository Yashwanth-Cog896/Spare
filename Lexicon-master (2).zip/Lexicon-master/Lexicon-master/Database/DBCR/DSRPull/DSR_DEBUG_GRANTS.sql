GRANT SELECT,INSERT,UPDATE,DELETE ON Lexicon.DSR_PULL_DEBUG TO Lexicon_RW_Role, Lexicon_User
/
GRANT EXECUTE ON Lexicon.DSR_Pull TO Lexicon_RW_Role, Lexicon_User
/

