CREATE OR REPLACE PROCEDURE LEXICON.CHECK_SUBJECT_AREA_NOTIF

/********************************************************************/
/* PACKAGE:  CHECK_SUBJECT_AREA_NOTIF
/*    Part of the Decision Support Repository
/*    Original Author:
/*      Marty Kinsey, Monsanto Concord, March 1999
/*
/* Inputs:  i_subject_area_id -  Subject Area Id
/*
/* Outputs: 
/*
/* Calls: SUBJECT_AREA_LOAD_STATUS- Select
/*
/* Language: English ORACLE PL/SQL
/* Platform: ORACLE
/*
/* Public procedures:
/*   CHECK_SUBJECT_AREA_NOTIF
/*     This procedure checks to see if all Acta jobs for a given subject area
/*     have completed.
/*
/* Calling sequence:
/*
/* Private procedures:
/*
/* Change log:
/*
/*
/********************************************************************/

     (i_subject_area_id            IN        varchar2)

IS

--------------------------------------------------------------------------------
-- Working Area.
--------------------------------------------------------------------------------

     x_target_id                   varchar2(15);
     x_subject_area_id             varchar2(2);
     x_last_subject_area_run_id    integer;
     x_procname                    varchar2(30);
     x_subject_area_status_count   integer;
     x_any_new_runs_count          integer;
     user_exception                EXCEPTION;

BEGIN

--------------------------------------------------------------------------------
-- Initialize Working Area parameters.
--------------------------------------------------------------------------------

     x_procname          :=  'CHECK_SUBJECT_AREA_NOTIF';
     x_subject_area_id   :=  i_subject_area_id;


     SELECT    default_value
     INTO x_target_id
     FROM DW_DEFAULT
     WHERE     default_id = 'TARGET ID';


--------------------------------------------------------------------------------
-- Retrieve the last subject_area_run_id that has been successfully processed 
-- for the given subject_area.
-- IMPORTANT NOTE:  In order for the target instances to obtain access to the 
-- SUBJECT_AREA_NOTIFICATION table on DSR instance, each target must establish
-- a private synonym to the SUBJECT_AREA_NOTIFICATION table.
--------------------------------------------------------------------------------

     SELECT    max(ENDING_SUBJECT_AREA_RUN_ID)
     INTO x_last_subject_area_run_id
     FROM DW_SUBJECT_AREA_PULL_LOG
     WHERE     subject_area_id = x_subject_area_id
     AND  dw_status = 'C';


--------------------------------------------------------------------------------
-- Check to see if ANY ACTA jobs for the Subject Area have started running.
--------------------------------------------------------------------------------

     SELECT    count(*) 
     INTO x_any_new_runs_count
     FROM SUBJECT_AREA_NOTIFICATION
     WHERE     dw_target_id    = x_target_id
     AND  subject_area_id      = x_subject_area_id
     AND  subject_area_run_id > x_last_subject_area_run_id;

     If x_any_new_runs_count = 0
     THEN
          RAISE user_exception;
     ELSE

--------------------------------------------------------------------------------
-- Check to see if ALL new ACTA jobs for the Subject Area have successfully run.
--------------------------------------------------------------------------------

          SELECT    count(*) 
          INTO x_subject_area_status_count
          FROM SUBJECT_AREA_NOTIFICATION
          WHERE     dw_target_id    = x_target_id
          AND  subject_area_id      = x_subject_area_id
          AND  subject_area_run_id > x_last_subject_area_run_id
          AND  DSR_status     != 'C';

          If x_subject_area_status_count > 0
          THEN
               RAISE user_exception;
          END IF;

     END IF;
--------------------------------------------------------------------------------
-- Exception Processing
--------------------------------------------------------------------------------

     EXCEPTION
          WHEN OTHERS
          THEN
               raise_application_error (-20003, 'Error in Package: '
                    ||x_procname||' - '||SQLERRM);


END CHECK_SUBJECT_AREA_NOTIF;
/

