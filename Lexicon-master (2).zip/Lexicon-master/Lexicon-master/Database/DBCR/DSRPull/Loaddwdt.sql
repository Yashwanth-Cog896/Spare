INSERT INTO DW_DEFAULT
	(
	DEFAULT_ID             ,
	ROW_INSERT_DATE        ,
	ROW_INSERT_USER_ID     ,
	ROW_INSERT_TASK_ID     ,
	ROW_UPDATE_DATE        ,
	ROW_UPDATE_USER_ID     ,
	ROW_UPDATE_TASK_ID     ,
	DEFAULT_VALUE          
	)
VALUES
	(
	'DSR SCHEMA',
	null,
	null,
	null,
	null,
	null,
	null,
	'DSRP'	
	);

INSERT INTO DW_DEFAULT
	(
	DEFAULT_ID             ,
	ROW_INSERT_DATE        ,
	ROW_INSERT_USER_ID     ,
	ROW_INSERT_TASK_ID     ,
	ROW_UPDATE_DATE        ,
	ROW_UPDATE_USER_ID     ,
	ROW_UPDATE_TASK_ID     ,
	DEFAULT_VALUE          
	)
VALUES
	(
	'TARGET SCHEMA',
	null,
	null,
	null,
	null,
	null,
	null,
	'LEXICON'   /*<=== TARGET MODIFICATION:  PUT IN SCHEMA NAME YOU WILL RUN PACKAGE FROM*/
	);

INSERT INTO DW_DEFAULT
	(
	DEFAULT_ID             ,
	ROW_INSERT_DATE        ,
	ROW_INSERT_USER_ID     ,
	ROW_INSERT_TASK_ID     ,
	ROW_UPDATE_DATE        ,
	ROW_UPDATE_USER_ID     ,
	ROW_UPDATE_TASK_ID     ,
	DEFAULT_VALUE          
	)
VALUES
	(
	'DSR DB LINK NAME',
	null,
	null,
	null,
	null,
	null,
	null,
	'@DSR_PULL_LINK'   /*<=== TARGET MODIFICATION:  PROVIDE DB LINK NAME (leave '@' as it is)*/
	);

INSERT INTO DW_DEFAULT
	(
	DEFAULT_ID             ,
	ROW_INSERT_DATE        ,
	ROW_INSERT_USER_ID     ,
	ROW_INSERT_TASK_ID     ,
	ROW_UPDATE_DATE        ,
	ROW_UPDATE_USER_ID     ,
	ROW_UPDATE_TASK_ID     ,
	DEFAULT_VALUE          
	)
VALUES
	(
	'TARGET ID',
	null,
	null,
	null,
	null,
	null,
	null,
	'LX'     
	);

INSERT INTO DW_DEFAULT
	(
	DEFAULT_ID             ,
	ROW_INSERT_DATE        ,
	ROW_INSERT_USER_ID     ,
	ROW_INSERT_TASK_ID     ,
	ROW_UPDATE_DATE        ,
	ROW_UPDATE_USER_ID     ,
	ROW_UPDATE_TASK_ID     ,
	DEFAULT_VALUE          
	)
VALUES
	(
	'COLUMN FILTER',
	null,
	null,
	null,
	null,
	null,
	null,
	'LXZ%'   
	);

COMMIT;
