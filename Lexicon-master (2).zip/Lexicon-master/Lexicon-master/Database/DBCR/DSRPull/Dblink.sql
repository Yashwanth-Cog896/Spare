--*************************************************
--*
--*  SAMPLE CODE FOR CREATING DATABASE LINK TO DSR
--*  SET UP A DBLINK for each DSR Oracle instane you need to access
--*
--***************************************************
--*
/*
				==== DSR: apply for userid LX_TEAM on DSRDEVL, DSRQUAL and DSRPRPD
				==== TARGET: logon to LX_TEAM@DSRDEVL with password LX_TEAM_123 and
					change the password
				==== TARGET: create userid LX_TEAM on your Oracle instance and change the password to the same as above
*/

CREATE DATABASE LINK dsrdevllink	/*<=== TARGET: CHANGE dblinkname to a unique dblinkname for access to DSRDEVEL, DSRQUAL and DSRPROD Oracle instances */
CONNECT TO LX_TEAM		    /*<=== TARGET: CHANGE userid TO LX_TEAM */
IDENTIFIED BY ag1lesl_p		/*<=== TARGET: CHANGE password to the one you created above*/
USING dsrdevl
/*<=== TARGET: CHANGE connect-string to the TNSNAME that is in your TNSNAMES.ORA file for 
					this DSR instance, or, if you are using the ONAMES server, 
					then use DSRDEVL.MONSANTO.COM, DSRQUAL.MONSANTO.COM or DSRPROD.MONSANTO.COM.
				==== TARGET: create database link or ask DBA to create database link
*/
