CREATE OR REPLACE PACKAGE LEXICON.dsr_pull
AS
/*************************************************************************
Module Name:DSR_PULL.pks

Author:Marty Kinsey

Create Date: December 1998

Overview:

 Modification History :

  $Id: DSR_PULL2.sql,v 1.1 2006-02-03 21:20:06 jaskidi Exp $
  $Log: not supported by cvs2svn $
  Revision 1.10  2005/12/15 Vamsi K Inkollu
  Uncommented the CREATE statement.

  Revision 1.3  2003/02/13 14:30:27  rktorbe
  Original DSRP code

TO RUN THE PULL PACKAGE EXECUTE THIS STATEMENT FOR EACH SUBJECT-AREA

  exec dsr_pull.pull_target_subject_area('xx') where xx is the SUBJECT_AREA

*************************************************************************
  Private procedures:
     PULL_TARGET_SUBJECT_AREA
       Given a feed data warhouse subject area ID, pull ID,
         beginning subject area run ID and ending subject area run ID,
       this procedure will insert into the appropriate data warehouse
         table(s).

     PULL_TABLES
       Given a feed data warhouse subject area ID, pull ID,
         beginning subject area run ID and ending subject area run ID,
       this procedure will insert into the appropriate data warehouse
         table(s).

     DELETE_TABLE_ROWS
       Given a feed data warhouse target ID, subject area ID, pull ID,
       beginning subject area run ID and ending subject area run ID,
         this procedure will delete any existing matching rows from the
         data warehouse.

   REVISION LOG:
     2001/02/26 - DSDUFA:  Procedure PULL_TABLES:
         Revised restart processing - errors were being caused when
         restart was for the first (or only) table within a subject
         area, because the SELECT that tried to find last successful
         table from previous run relied on a SQL%NOTFOUND against a
         MAX function to indicate that no tables had been completed
         successfully, but a grouping function (like MAX) will never
         return a SQL%NOTFOUND condition.  Restructured logic in this
         routine to use a SELECT COUNT(*) instead.
		 
  2005-12-15 Vamsi K Inkollu
          Increased the dynamic SQL length to 32000. The current max allowed.
          Removed all the existing raise_application_error calls because
                    a. They would mask the stack information (which line number actually caused the error).
                    b. Were redundant (no data found, more than one row found, etc)
          Added DSR_PULL_DEBUG table support to hold the dynamic SQL whenever
          Added EXECUTE_SQL method
          Added GET_DW_DEFAULT
		 
*******************************************************************/
     PROCEDURE pull_target_subject_area (i_subject_area_id IN VARCHAR2);

     PROCEDURE update_subject_area_pull_log (
          i_subject_area_id           IN       VARCHAR2,
          i_status                    IN OUT   VARCHAR2,
          o_pull_id                   IN OUT   INTEGER,
          o_beg_subject_area_run_id   IN OUT   INTEGER,
          o_end_subject_area_run_id   IN OUT   INTEGER
     );

     PROCEDURE update_table_pull_log (
          i_subject_area_id   IN   VARCHAR2,
          i_table_name        IN   VARCHAR2,
          i_pull_id           IN   INTEGER,
          i_status            IN   VARCHAR2,
          i_row_count         IN   INTEGER
     );

     PROCEDURE write_to_debug (x_str IN VARCHAR2);

     PROCEDURE pull_tables (
          i_subject_area_id           IN   VARCHAR2,
          i_pull_id                   IN   INTEGER,
          i_beg_subject_area_run_id   IN   INTEGER,
          i_end_subject_area_run_id   IN   INTEGER,
          i_status                    IN   VARCHAR2
     );

     PROCEDURE delete_table_rows (
          i_subject_area_id           IN   VARCHAR2,
          i_pull_id                   IN   INTEGER,
          i_beg_subject_area_run_id   IN   INTEGER,
          i_end_subject_area_run_id   IN   INTEGER,
          i_table_name                IN   VARCHAR2,
          i_source_name               IN   VARCHAR2,
          i_dsr_schema_name           IN   VARCHAR2,
          i_target_schema_name        IN   VARCHAR2,
          i_db_link_name              IN   VARCHAR2,
          i_update_type               IN   VARCHAR2
     );

     FUNCTION execute_sql (x_sqlstmt IN VARCHAR2)
          RETURN INT;

     FUNCTION get_dw_default (x_param IN VARCHAR2)
          RETURN VARCHAR2;

     -- Used by WRITE_TO_DEBUG. Note that package level variables are shared
     -- by all the procedures in a session
     g_curr_subject_area_id   VARCHAR2 (10);
     g_curr_pull_id           PLS_INTEGER;

END dsr_pull;
/

CREATE OR REPLACE PACKAGE BODY LEXICON.dsr_pull
AS
/**************************************************************************
Module Name:DSR_PULL.pkb

Author: Marty Kinsey

Create Date: December 1998

Overview:

 Modification History :

  $Id: DSR_PULL2.sql,v 1.1 2006-02-03 21:20:06 jaskidi Exp $
  $Log: not supported by cvs2svn $
  Revision 1.10  2005/12/15 Vamsi K Inkollu


  2001/02/26 - DSDUFA:  Procedure PULL_TABLES:
      Revised restart processing - errors were being caused when
      restart was for the first (or only) table within a subject
      area, because the SELECT that tried to find last successful
      table from previous run relied on a SQL%NOTFOUND against a
       MAX function to indicate that no tables had been completed
       successfully, but a grouping function (like MAX) will never
       return a SQL%NOTFOUND condition.  Restructured logic in this
       routine to use a SELECT COUNT(*) instead.

  2002-07-02 -- Ted Palmer Procedure UPDATE_SUBJECT_AREA_PULL_LOG:
       Modified this procedure so that it would get the value for
       ENDING_SUBJECT_AREA_RUN_ID from table SUBJECT_AREA_NOTIFICATION
       instead of from table SUBJECT_AREA_RUN_LOG. The old way caused
       rows to be missed on target DW table pulls that started after a
       second SAP extract schedule began before a first SAP extract
       schedule data had been pulled by its target DW; e.g.
       The NOON scheduled SAP extract
       completed but the 09:00 PM SAP extract began before a target DW
       started pulling its data for the NOON SAP extract. The 1st thing
       that happens when an SAP extract begins is that the
       SUBJECT_AREA_RUN_ID (SARID) in table SUBJECT_AREA_RUN_LOG is
       incremented. The target DW was using this incremented SARID in
       its pull but the 2nd SAP extract had not finished getting all
       of its data from SAP.
  2002-07-10  "AND (SAN.dw_status is null OR SAN.dw_status <> 'C');"
       -- Walter suggested I remove this line from the SELECT statement that
       gets the ending_SARID to make it easier for failed pull recovery.
       He is right. SAN.dw_status has been adaquately checked in other
       procedures before "the process" gets to this point.

  2005-12-15 Vamsi K Inkollu
          Increased the dynamic SQL length to 32000. The current max allowed.
          Removed all the existing raise_application_error calls because
                    a. They would mask the stack information (which line number actually caused the error).
                    b. Were redundant (no data found, more than one row found, etc)
		  Added check to ensure that the target table has the PRIMARY KEY defined
          Added DSR_PULL_DEBUG table support to hold the dynamic SQL whenever
          Added EXECUTE_SQL method
          Added GET_DW_DEFAULT
 

**************************************************************************/
     PROCEDURE update_subject_area_pull_log (
          i_subject_area_id           IN       VARCHAR2,
          i_status                    IN OUT   VARCHAR2,
          o_pull_id                   IN OUT   INTEGER,
          o_beg_subject_area_run_id   IN OUT   INTEGER,
          o_end_subject_area_run_id   IN OUT   INTEGER
     )
     IS
          x_subject_area_id              VARCHAR2 (2);
          x_status                       VARCHAR2 (2);
          x_target_id                    VARCHAR2 (2);
          x_procname                     VARCHAR2 (30);
          x_beg_subject_area_run_id      PLS_INTEGER;
          x_end_subject_area_run_id      PLS_INTEGER;
          x_new_pull_id                  PLS_INTEGER;
          x_restart_pull_count           PLS_INTEGER;
          x_pull_id                      PLS_INTEGER;
          x_any_runs_in_progress_count   PLS_INTEGER;

     BEGIN
          -----------------------------------------
		  -- Initialize Working Area parameters.
          -----------------------------------------
          x_procname := 'UPDATE_SUBJECT_AREA_PULL_LOG';
          x_subject_area_id := i_subject_area_id;
          x_status := i_status;
          x_pull_id := o_pull_id;
          x_beg_subject_area_run_id := o_beg_subject_area_run_id;
          x_end_subject_area_run_id := o_end_subject_area_run_id;
          x_any_runs_in_progress_count := 0;
          x_target_id := get_dw_default ('TARGET ID');

          ----------------------------------------------------------------------
          -- Decide whether an insert or update is to be performed.  This is determined by
          -- the following logic:  if input status = "S" (start), do an insert; otherwise
          -- do an update.
          ----------------------------------------------------------------------
          IF    (x_status != 'C')
             OR (x_status IS NULL)
          THEN
               ---------------------------------------------------------------------------------
               -- Check to see if this is a restart.  If the count from the call below is 0,
               -- this is a normal start.  Otherwise, it's a restart.
               ---------------------------------------------------------------------------------
               SELECT COUNT (0)
                 INTO x_restart_pull_count
                 FROM dw_subject_area_pull_log sapl
                WHERE sapl.subject_area_id = x_subject_area_id
                  AND dw_status != 'C';

               IF x_restart_pull_count = 0
               THEN
                    --------------------------------------------------------------------------------
                    -- Check to see if ANY ACTA jobs for the Subject Area are in the process of running.
                    --------------------------------------------------------------------------------
                    SELECT COUNT (0)
                      INTO x_any_runs_in_progress_count
                      FROM subject_area_notification
                     WHERE dw_target_id = x_target_id
                       AND subject_area_id = x_subject_area_id
                       AND dsr_status = 'S';

                    IF x_any_runs_in_progress_count > 0
                    THEN
                         raise_application_error
                              (-20001,
                                  'DSR schedule for SUBJECT_AREA_ID = '
                               || x_subject_area_id
                               || ' still in progress. Please try after some time'
                              );
                    END IF;

                    ---------------------------------------------------------------------------------
                    -- This is a normal start.  Select the last pull_id and its corresponding
                    -- ending_subject_area_run_id from DW_SUBJECT_AREA_PULL_LOG for the input
                    -- i_subject_area_id.
                    ---------------------------------------------------------------------------------
					BEGIN
	                    SELECT     sapl.ending_subject_area_run_id
	                             + 1,
	                               MAX (sapl.pull_id)
	                             + 1
	                        INTO x_beg_subject_area_run_id,
	                             x_new_pull_id
	                        FROM dw_subject_area_pull_log sapl
	                       WHERE sapl.subject_area_id = x_subject_area_id
	                         AND sapl.pull_id =
	                                  (SELECT MAX (sapl2.pull_id)
	                                     FROM dw_subject_area_pull_log sapl2
	                                    WHERE sapl2.subject_area_id =
	                                                          sapl.subject_area_id)
	                    GROUP BY sapl.subject_area_id,
	                             sapl.pull_id,
	                             sapl.ending_subject_area_run_id;
						EXCEPTION
								 WHEN NO_DATA_FOUND
								 THEN
		                        	 x_beg_subject_area_run_id := 1;
		                             x_new_pull_id := 1;							 	 
					END;

                    ---------------------------------------------------------------------------------
                    -- Get the ending_subject_area_run_id for this pull from the
                    -- DSR.SUBJECT_AREA_NOTIFICATION table.
                    ---------------------------------------------------------------------------------
                    BEGIN
                         SELECT MAX (san.subject_area_run_id)
                           INTO x_end_subject_area_run_id
                           FROM subject_area_notification san
                          WHERE (san.subject_area_id = x_subject_area_id)
                            AND (san.dw_target_id = x_target_id)
                            AND (san.dsr_status = 'C');
                    EXCEPTION
                         WHEN NO_DATA_FOUND
                         THEN
                              raise_application_error
                                   (-20002,
                                       'Unable to get ending DSR''s SUBJECT_AREA_RUN_ID from SUBJECT_AREA_NOTIFICATION for SUBJECT_AREA_ID = '
                                    || x_subject_area_id
                                    || ' TARGET_ID = '
                                    || x_target_id
                                   );
                    END;

                    ---------------------------------------------------------------------------------
                    -- Insert to the local DW_SUBJECT_AREA_PULL_LOG and Set up and run the
                    -- dynamic SQL statement to insert the new pull_id and
                    -- corresponding beginning / ending_subject_area_run_id into
                    -- DW_SUBJECT_AREA_PULL_LOG for the input i_subject_area_id.
                    ---------------------------------------------------------------------------------
                    INSERT INTO dw_subject_area_pull_log
                                (subject_area_id, pull_id, row_insert_date,
                                 row_insert_user_id, row_insert_task_id,
                                 row_update_date, row_update_user_id,
                                 row_update_task_id, dw_completion_date_time,
                                 dw_status, beginning_subject_area_run_id,
                                 ending_subject_area_run_id
                                )
                         VALUES (x_subject_area_id, x_new_pull_id, NULL,
                                 NULL, NULL,
                                 NULL, NULL,
                                 NULL, NULL,
                                 'S', x_beg_subject_area_run_id,
                                 x_end_subject_area_run_id
                                );

                    ---------------------------------------------------------------------------------
                    -- Initialize the OUT parameters with the appropriate values
                    ---------------------------------------------------------------------------------
                    IF x_beg_subject_area_run_id > x_end_subject_area_run_id
                    THEN
                         raise_application_error
                              (-20002,
                               'Target''s ending SUBJECT_AREA_RUN_ID > DSR''s max SUBJECT_AREA_RUN_ID'
                              );
                    END IF;

                    o_pull_id := x_new_pull_id;
                    o_beg_subject_area_run_id := x_beg_subject_area_run_id;
                    o_end_subject_area_run_id := x_end_subject_area_run_id;
               ELSE
                    ---------------------------------------------------------------------------------
                    -- The following logic is for a Restart status.
                    ---------------------------------------------------------------------------------
                    i_status := 'R';
                    x_status := 'R';

					SELECT sapl.beginning_subject_area_run_id,
                           sapl.ending_subject_area_run_id, sapl.pull_id
                      INTO x_beg_subject_area_run_id,
                           x_end_subject_area_run_id, x_new_pull_id
                      FROM dw_subject_area_pull_log sapl
                     WHERE sapl.subject_area_id = x_subject_area_id
                       AND dw_status IN ('S', 'R');

                    o_pull_id := x_new_pull_id;
                    o_beg_subject_area_run_id := x_beg_subject_area_run_id;
                    o_end_subject_area_run_id := x_end_subject_area_run_id;

                    UPDATE dw_subject_area_pull_log
                       SET dw_status = x_status
                     WHERE subject_area_id = x_subject_area_id
                       AND dw_status IN ('S', 'R');
               END IF;
          ELSE
               ---------------------------------------------------------------------------------
               -- The input status was not "S" or "R" which means we are updating the status.
               -- Update the local DW_SUBJECT_AREA_PULL_LOG and Set up and run the
               -- dynamic SQL statement to update the status for the new pull_id and
               -- corresponding beginning / ending_subject_area_run_id into
               -- DW_SUBJECT_AREA_PULL_LOG for the input i_subject_area_id.
               ---------------------------------------------------------------------------------
               UPDATE dw_subject_area_pull_log
                  SET dw_status = x_status,
                      dw_completion_date_time = SYSDATE
                WHERE subject_area_id = x_subject_area_id
                  AND pull_id = x_pull_id;
          END IF;

          --------------------------------------------------------------------------------
          -- Update the SUBJECT_AREA_NOTIFICATION table with the appropriate dw_status.
          -- IMPORTANT NOTE:  In order for the target instances to obtain access to the
          -- SUBJECT_AREA_NOTIFICATION table on the DSR instance, each targe must establish
          -- a private synonym to the SUBJECT_AREA_NOTIFICATION table.
          --------------------------------------------------------------------------------
          UPDATE subject_area_notification
             SET dw_status = x_status
           WHERE subject_area_id = x_subject_area_id
             AND dw_target_id = x_target_id
             AND subject_area_run_id BETWEEN x_beg_subject_area_run_id
                                         AND x_end_subject_area_run_id
             AND (   dw_status IS NULL
                  OR dw_status <> 'C');
     END update_subject_area_pull_log;

/******************UPDATE_TABLE_PULL_LOG********************************/
     PROCEDURE update_table_pull_log (
          i_subject_area_id   IN   VARCHAR2,
          i_table_name        IN   VARCHAR2,
          i_pull_id           IN   INTEGER,
          i_status            IN   VARCHAR2,
          i_row_count         IN   INTEGER
     )
     IS
          x_subject_area_id              VARCHAR2 (2);
          x_table_name                   VARCHAR2 (30);
          x_pull_id                      PLS_INTEGER;
          x_status                       VARCHAR2 (2);
          x_row_count                    PLS_INTEGER;
          x_procname                     VARCHAR2 (30);
     BEGIN
          ---------------------------------------------------------------------------------
          -- Initialize Working Area parameters.
          ---------------------------------------------------------------------------------
          x_procname := 'UPDATE_TABLE_PULL_LOG';
          x_table_name := i_table_name;
          x_subject_area_id := i_subject_area_id;
          x_pull_id := i_pull_id;
          x_status := i_status;
          x_row_count := i_row_count;

          ---------------------------------------------------------------------------------
          -- Decide whether an insert or update is to be performed.  This is determined by
          -- the following logic:  if input status = "S" (start), do an insert; otherwise
          -- do an update.
          ---------------------------------------------------------------------------------
          IF x_status = 'DS'
          THEN
               ---------------------------------------------------------------------------------
               -- The deletes are beginning.  Update DW_TABLE_PULL_LOG setting the status = 'DS'
               -- (Delete Started).
               ---------------------------------------------------------------------------------
               INSERT INTO dw_table_pull_log
                           (subject_area_id, table_name, pull_id,
                            row_insert_date, row_insert_user_id,
                            row_insert_task_id, row_update_date,
                            row_update_user_id, row_update_task_id,
                            dw_completion_date_time, dw_status,
                            deleted_row_count, row_count
                           )
                    VALUES (x_subject_area_id, x_table_name, x_pull_id,
                            NULL, NULL,
                            NULL, NULL,
                            NULL, NULL,
                            NULL, x_status,
                            0, 0
                           );
          ELSE
               IF x_status = 'IS'
               THEN
                    ---------------------------------------------------------------------------------
                    -- The deletes have just been completed.  Update the DW_TABLE_PULL_LOG with the
                    -- deleted row count and an 'IS' status (Insert started).
                    ---------------------------------------------------------------------------------
                    UPDATE dw_table_pull_log
                       SET dw_status = x_status,
                           deleted_row_count = x_row_count
                     WHERE subject_area_id = x_subject_area_id
                       AND table_name = x_table_name
                       AND pull_id = x_pull_id;
               ELSE
                    ---------------------------------------------------------------------------------
                    -- The inserts have just been completed.  Update the DW_TABLE_PULL_LOG with the
                    -- inserted row count and an 'C' status (Insert completed).
                    ---------------------------------------------------------------------------------
                    UPDATE dw_table_pull_log
                       SET dw_status = x_status,
                           row_count = x_row_count,
                           dw_completion_date_time = SYSDATE
                     WHERE subject_area_id = x_subject_area_id
                       AND table_name = x_table_name
                       AND pull_id = x_pull_id;
               END IF;
          END IF;

          COMMIT;
     END update_table_pull_log;

     PROCEDURE write_to_debug (x_str IN VARCHAR2)
     IS
          PRAGMA AUTONOMOUS_TRANSACTION;
          x_max_seq_no   INT;
		  x_max_line_length	 INT := 1000;
		  x_debug_str varchar2(4000);
     BEGIN
          x_max_seq_no := CEIL (LENGTH (x_str) / x_max_line_length);
          IF g_curr_subject_area_id IS NULL
          THEN
               g_curr_subject_area_id := 'UNKNOWN';
          END IF;

          IF g_curr_pull_id IS NULL
          THEN
               g_curr_pull_id := -1;
          END IF;

          FOR x_curr_seq_no IN 1 .. x_max_seq_no
          LOOP
		  	  NULL;
			  x_debug_str := SUBSTR (x_str, ((x_curr_seq_no - 1) * x_max_line_length) + 1, x_max_line_length);
              INSERT INTO dsr_pull_debug
                           (row_insert_date,
						   subject_area_id,
						   pull_id,
                           seq_no,
                           debug_str
                           )
                    VALUES (SYSDATE,
						    g_curr_subject_area_id,
							g_curr_pull_id,
                            x_curr_seq_no,
                            x_debug_str
                           );
          END LOOP;

          COMMIT;
	 EXCEPTION
	 		  WHEN OTHERS
			  THEN
			  	 		  ROLLBACK;
						  RAISE;
     END write_to_debug;

     FUNCTION execute_sql (x_sqlstmt IN VARCHAR2)
          RETURN INT
     IS
          x_cursor_handle   PLS_INTEGER;
          x_row_count       PLS_INTEGER;
     BEGIN
          x_cursor_handle := DBMS_SQL.open_cursor;
          DBMS_SQL.parse (x_cursor_handle, x_sqlstmt, DBMS_SQL.v7);
          x_row_count := DBMS_SQL.EXECUTE (x_cursor_handle);
          DBMS_SQL.close_cursor (x_cursor_handle);
          RETURN x_row_count;
     EXCEPTION
          WHEN OTHERS
          THEN
               write_to_debug (x_sqlstmt);
               RAISE;
     END execute_sql;

/******************DELETE_TABLE_ROWS********************************/
     PROCEDURE delete_table_rows (
          i_subject_area_id           IN   VARCHAR2,
          i_pull_id                   IN   INTEGER,
          i_beg_subject_area_run_id   IN   INTEGER,
          i_end_subject_area_run_id   IN   INTEGER,
          i_table_name                IN   VARCHAR2,
          i_source_name               IN   VARCHAR2,
          i_dsr_schema_name           IN   VARCHAR2,
          i_target_schema_name        IN   VARCHAR2,
          i_db_link_name              IN   VARCHAR2,
          i_update_type               IN   VARCHAR2
     )
     IS
---------------------------------------------------------------------------------
-- Working Area.
---------------------------------------------------------------------------------
          x_subject_area_id           VARCHAR2 (2);
          x_pull_id                   PLS_INTEGER;
          x_beg_subject_area_run_id   PLS_INTEGER;
          x_end_subject_area_run_id   PLS_INTEGER;
          x_table_name                VARCHAR2 (30);
          x_source_name               VARCHAR2 (30);
          x_dsr_schema_name           VARCHAR2 (30);
          x_target_schema_name        VARCHAR2 (30);
          x_procname                  VARCHAR2 (30);
          x_column_name               VARCHAR2 (30);
          x_column_list               VARCHAR2 (32000);
          x_row_count                 PLS_INTEGER;
          x_db_link_name              VARCHAR2 (50);
          x_update_type               VARCHAR2 (1);

          ---------------------------------------------------------------------------------
          -- Cursor to identify the Primary key columns for the delete
          ---------------------------------------------------------------------------------
          CURSOR primary_key_columns (p_table_name IN VARCHAR2, p_target_schema_name IN VARCHAR2)
          IS
               SELECT column_name
                 FROM all_cons_columns
                WHERE owner = x_target_schema_name
                  AND table_name = p_table_name
                  AND constraint_name =
                           (SELECT constraint_name
                              FROM all_constraints
                             WHERE owner = p_target_schema_name
                               AND table_name = p_table_name
                               AND constraint_type = 'P');
     BEGIN
          ---------------------------------------------------------------------------------
          -- Initialize Working Area parameters.
          ---------------------------------------------------------------------------------
          x_procname := 'DELETE_TABLE_ROWS';
          x_subject_area_id := i_subject_area_id;
          x_pull_id := i_pull_id;
          x_beg_subject_area_run_id := i_beg_subject_area_run_id;
          x_end_subject_area_run_id := i_end_subject_area_run_id;
          x_table_name := i_table_name;
          x_source_name := i_source_name;
          x_dsr_schema_name := i_dsr_schema_name;
          x_target_schema_name := i_target_schema_name;
          x_db_link_name := i_db_link_name;
          x_update_type := i_update_type;
          x_column_list := '';

          ---------------------------------------------------------------------------------
          --  Determine the Primary key columns and create a string of them
          ---------------------------------------------------------------------------------
          OPEN primary_key_columns(x_table_name, x_target_schema_name);

          LOOP
               FETCH primary_key_columns
                INTO x_column_name;

               EXIT WHEN primary_key_columns%NOTFOUND;
               x_column_list :=    x_column_list
                                || ','
                                || x_column_name;
          END LOOP;

          CLOSE primary_key_columns;
		  
		  -- Ensure that the above cursor could find the primary keys
		  IF x_column_list = '' OR x_column_list IS NULL OR LENGTH(x_column_list)=0
		  THEN
		  	  raise_application_error(-20001, 'Unable to find the PRIMARY KEY columns in table ' || x_table_name || '. Check primary key definition.'); 
		  END IF;

          x_column_list := SUBSTR (x_column_list, 2);

          ---------------------------------------------------------------------------------
          --  Set up and run the dynamic SQL statement to delete all corresponding records
          --  that will be inserted next.  If the update_type from DW_TABLE is set to "I"
          --   (incremental), then only delete the rows for the subject_area_run_id(s) that
          --   are being processed.  If the update_type is set to "F" (full), then delete all
          --   rows from the table in anticipation of a full refresh.
          ---------------------------------------------------------------------------------
          IF x_update_type = 'I'
          THEN
               x_row_count :=
                    execute_sql (   'DELETE FROM '
                                 || x_target_schema_name
                                 || '.'
                                 || x_table_name
                                 || ' WHERE ('
                                 || x_column_list
                                 || ') IN (SELECT '
                                 || x_column_list
                                 || ' FROM '
                                 || x_dsr_schema_name
                                 || '.'
                                 || x_source_name
                                 || x_db_link_name
                                 || ' WHERE subject_area_run_id BETWEEN '
                                 || x_beg_subject_area_run_id
                                 || ' AND '
                                 || x_end_subject_area_run_id
                                 || ')'
                                );
          ELSE
               IF x_update_type = 'F'
               THEN
                    x_row_count :=
                         execute_sql (   'DELETE FROM '
                                      || x_target_schema_name
                                      || '.'
                                      || x_table_name
                                     );
               ELSE
                    raise_application_error
                         (-20003,
                             'Error in Stored Procedure: '
                          || x_procname
                          || ' - DW_TABLE.update_type NOT I or F!  Table_name ---> '
                          || x_table_name
                         );
               END IF;
          END IF;

          COMMIT;
          ---------------------------------------------------------------------------------
          -- Update the DW_TABLE_PUSH_LOG with a status of "IS" (Insert Started)
          ---------------------------------------------------------------------------------
          update_table_pull_log (x_subject_area_id,
                                 x_table_name,
                                 x_pull_id,
                                 'IS',
                                 x_row_count
                                );
     END delete_table_rows;

/******************PULL_TABLES********************************/
     PROCEDURE pull_tables (
          i_subject_area_id           IN   VARCHAR2,
          i_pull_id                   IN   INTEGER,
          i_beg_subject_area_run_id   IN   INTEGER,
          i_end_subject_area_run_id   IN   INTEGER,
          i_status                    IN   VARCHAR2
     )
     IS
          x_subject_area_id           VARCHAR2 (2);
          x_pull_id                   PLS_INTEGER;
          x_beg_subject_area_run_id   PLS_INTEGER;
          x_end_subject_area_run_id   PLS_INTEGER;
          x_procname                  VARCHAR2 (30);
          x_table_name                VARCHAR2 (30);
          x_view_name                 VARCHAR2 (30);
          x_column_name               VARCHAR2 (30);
          x_column_list               VARCHAR2 (32000);
          x_row_count                 PLS_INTEGER;
          x_source_name               VARCHAR2 (30);
          x_status                    VARCHAR2 (2);
          x_restart_table             VARCHAR2 (30);
          x_restart_first_pass        VARCHAR2 (1);
          x_target_schema_name        VARCHAR2 (30);
          x_dsr_schema_name           VARCHAR2 (30);
          x_db_link_name              VARCHAR2 (50);
          x_target                    VARCHAR2 (2);
          x_column_filter             VARCHAR2 (10);
          x_check_table_pull_log      PLS_INTEGER;
          x_col_counter               PLS_INTEGER;
          x_update_type               VARCHAR2 (1);
          v_complete_count            PLS_INTEGER    := 0;
		  x_sqlstmt					  VARCHAR2(32000);

          ---------------------------------------------------------------------------------
          -- Cursor which contains DW_TABLE.table_name(s) and view_name(s).
          ---------------------------------------------------------------------------------
          CURSOR cur_table_name
          IS
               SELECT   table_name, view_name, update_type
                   FROM dw_table
                  WHERE dw_target_id = x_target
                    AND subject_area_id = x_subject_area_id
                    AND status = 'A'
               ORDER BY table_name                                ;

          ---------------------------------------------------------------------------------
          -- Cursor which contains USER_TAB_COLUMNS.column_name(s).
          ---------------------------------------------------------------------------------
          CURSOR cur_column_name
          IS
               SELECT column_name
                 FROM all_tab_columns
                WHERE table_name = x_table_name
                  AND owner = x_target_schema_name
                  AND column_name NOT LIKE x_column_filter;
     BEGIN
          ---------------------------------------------------------------------------------
          -- Initialize Working Area parameters.
          ---------------------------------------------------------------------------------
          x_procname := 'PULL_TABLES';
          x_subject_area_id := i_subject_area_id;
          x_pull_id := i_pull_id;
          x_beg_subject_area_run_id := i_beg_subject_area_run_id;
          x_end_subject_area_run_id := i_end_subject_area_run_id;
          x_status := i_status;
          x_target_schema_name := get_dw_default ('TARGET SCHEMA');
          x_dsr_schema_name := get_dw_default ('DSR SCHEMA');
          x_db_link_name := get_dw_default ('DSR DB LINK NAME');
          x_target := get_dw_default ('TARGET ID');
          x_column_filter := get_dw_default ('COLUMN FILTER');
          ---------------------------------------------------------------------------------
          -- Check to see if this is a restart.  If so, get the last table_name that was
          -- being loaded when the previous abend occurred.
          ---------------------------------------------------------------------------------
          --* Default restart flag as N (NO Restart)
          x_restart_first_pass := 'N';

          IF x_status = 'R'
          THEN
               --* Indicate RESTART for first pass of main processing loop.
               x_restart_first_pass := 'Y';

               --* If input status indicates this is a restart, then
               --*   check to see if any tables were successfully
               --*   completed in the previous (failed) run.
               SELECT COUNT (0)
                 INTO v_complete_count
                 FROM dw_table_pull_log
                WHERE subject_area_id = x_subject_area_id
                  AND pull_id = x_pull_id
                  AND dw_status = 'C';

               --* If any tables were successfully completed in the
               --*   previous (failed) run, then determine which table
               --*   was the last one successfully completed.
               IF v_complete_count > 0
               THEN
                    SELECT MAX (table_name)
                      INTO x_restart_table
                      FROM dw_table_pull_log
                     WHERE subject_area_id = x_subject_area_id
                       AND pull_id = x_pull_id
                       AND dw_status = 'C';
               ELSE
                    --* NO tables were successfully completed in the previous
                    --*   (failed) run -- restart with first possible table.
                    x_restart_table := NULL;
               END IF;
          ELSE
               --* Input status indicates this is *NOT* a restart.
               x_restart_first_pass := 'N';
          END IF;

          ---------------------------------------------------------------------------------
          -- Load the TABLE_NAME cursor with the DW_TABLE.table_name(s)
          ---------------------------------------------------------------------------------
          OPEN cur_table_name;

          ---------------------------------------------------------------------------------
          -- Select each of the table / view names from the cursor for processing.  If view
          -- name is not null, load view name into x_source; otherwise, load table name into
          -- x_source.  If this is a restart and it's the 1st pass through this logic,
          -- read through the CUR_TABLE_NAME cursor until you reach the last table that was
          -- being updated during the previous abend.
          ---------------------------------------------------------------------------------
          LOOP
               --* If this is a RESTART, then some extra processing is done in the
                --*   FIRST PASS of this loop (controlled by x_restart_first_pass).
               IF x_restart_first_pass = 'Y'
               THEN
                    --* Reset the controlling flag.
                    x_restart_first_pass := 'N';

                     --* If any tables were successfully completed in the
                    --*   previous (failed) run, then the main processing loop must
                      --*   start with the first table after the last successfully
                      --*   completed table.  Loop thru cursor to find this table.
                    IF x_restart_table IS NOT NULL
                    THEN
                         LOOP
                              FETCH cur_table_name
                               INTO x_table_name, x_view_name, x_update_type;
                              EXIT WHEN x_table_name = x_restart_table
                                    OR cur_table_name%NOTFOUND;
                         END LOOP;
                    END IF;

                    --* Fetch the name of the first table to actually process.
                    FETCH cur_table_name
                     INTO x_table_name, x_view_name, x_update_type;
                    EXIT WHEN cur_table_name%NOTFOUND;

                    --* If there is already a row in DW_TABLE_PULL_LOG for this
                      --*   table (i.e. previous run abended on this table after it
                      --*   had started, and left a row in DW_TABLE_PULL_LOG), then
                      --*   use it.  If there is not already a row, call UPDATE_
                      --*   TABLE_PULL_LOG to insert a new row.
                    SELECT COUNT (0)
                      INTO x_check_table_pull_log
                      FROM dw_table_pull_log
                     WHERE subject_area_id = x_subject_area_id
                       AND table_name = x_table_name
                       AND pull_id = x_pull_id;

                    IF x_check_table_pull_log = 0
                    THEN
                         update_table_pull_log (x_subject_area_id,
                                                x_table_name,
                                                x_pull_id,
                                                'DS',
                                                0
                                               );
                    END IF;
               --* THIS IS NOT THE FIRST PASS OF A RESTART!  Normal processing:
                --*   Fetch next table name to be processed, and call UPDATE_
                --*   TABLE_PULL_LOG to insert a new row into DW_TABLE_PULL_LOG
                --*   for that table.
               ELSE
                    FETCH cur_table_name
                     INTO x_table_name, x_view_name, x_update_type;
                    EXIT WHEN cur_table_name%NOTFOUND;
                    update_table_pull_log (x_subject_area_id,
                                           x_table_name,
                                           x_pull_id,
                                           'DS',
                                           0
                                          );
               END IF;

               IF x_view_name IS NULL
               THEN
                    x_source_name := x_table_name;
               ELSE
                    x_source_name := x_view_name;
               END IF;

          ---------------------------------------------------------------------------------
          -- Delete table rows from target that will be processed in this run.
          ---------------------------------------------------------------------------------
               delete_table_rows (x_subject_area_id,
                                  x_pull_id,
                                  x_beg_subject_area_run_id,
                                  x_end_subject_area_run_id,
                                  x_table_name,
                                  x_source_name,
                                  x_dsr_schema_name,
                                  x_target_schema_name,
                                  x_db_link_name,
                                  x_update_type
                                 );

               ---------------------------------------------------------------------------------
               -- Get all of the column names into a cursor.
               ---------------------------------------------------------------------------------
               OPEN cur_column_name;

               x_column_list := '';
               ---------------------------------------------------------------------------------
               -- Prepare the column list for the insert statement.
               ---------------------------------------------------------------------------------
               x_col_counter := 0;

               LOOP
                    FETCH cur_column_name
                     INTO x_column_name;

                    EXIT WHEN cur_column_name%NOTFOUND;

                    x_column_list := x_column_list || ',' || x_column_name;
                    x_col_counter :=   x_col_counter + 1;
					
					-- Add end EOL to help in debugging
                    IF MOD (x_col_counter, 5) = 0
                    THEN
                         x_column_list :=
                                            x_column_list
                                         || CHR (13);
                    END IF;
               END LOOP;

               CLOSE cur_column_name;

               x_column_list := SUBSTR (x_column_list, 2);

               ---------------------------------------------------------------------------------
               --   Set up and run the dynamic SQL statement to insert data to the target table.
               --   If the update_type from DW_TABLE is set to "I"
               --   (incremental), then only delete the rows for the subject_area_run_id(s) that
               --   are being processed.  If the update_type is set to "F" (full), then delete all
               --   rows from the table in anticipation of a full refresh.
               ---------------------------------------------------------------------------------
               IF x_update_type = 'I'
               THEN
			   	    x_sqlstmt := 
                                  'INSERT INTO '
                                     || x_target_schema_name
                                     || '.'
                                     || x_table_name
                                     || ' ('
                                     || x_column_list
                                     || ')'
                                     || ' SELECT '
                                     || x_column_list
                                     || ' FROM '
                                     || x_dsr_schema_name
                                     || '.'
                                     || x_source_name
                                     || x_db_link_name
                                     || ' WHERE subject_area_run_id BETWEEN '
                                     || x_beg_subject_area_run_id
                                     || ' AND '
                                     || x_end_subject_area_run_id;
                    x_row_count := execute_sql(x_sqlstmt);
               ELSE
                    IF x_update_type = 'F'
                    THEN
						 x_sqlstmt :=
						 		   	   'INSERT INTO '
                                           || x_target_schema_name
                                           || '.'
                                           || x_table_name
                                           || ' ('
                                           || x_column_list
                                           || ')'
                                           || ' SELECT '
                                           || x_column_list
                                           || ' FROM '
                                           || x_dsr_schema_name
                                           || '.'
                                           || x_source_name
                                           || x_db_link_name;
                         x_row_count := execute_sql (x_sqlstmt);
                    ELSE
                         raise_application_error
                              (-20003,
                                  'DW_TABLE.UPDATE_TYPE NOT I or F!  Table_name ---> '
                               || x_table_name
                              );
                    END IF;
               END IF;

               ---------------------------------------------------------------------------------
               -- Update the DW_TABLE_PULL_LOG with a status of "C" (complete)
               ---------------------------------------------------------------------------------
               update_table_pull_log (x_subject_area_id,
                                      x_table_name,
                                      x_pull_id,
                                      'C',
                                      x_row_count
                                     );
									 
			   commit; -- Commit the current table that has already been processed
          --* END OF MAIN PROCESSING LOOP
          END LOOP;

          CLOSE cur_table_name;
     END pull_tables;

/******************PULL_TARGET_SUBJECT_AREA********************************/
     PROCEDURE pull_target_subject_area (i_subject_area_id IN VARCHAR2)
     IS
          x_subject_area_id           VARCHAR2 (2);
          x_pull_id                   PLS_INTEGER;
          x_beg_subject_area_run_id   PLS_INTEGER;
          x_end_subject_area_run_id   PLS_INTEGER;
          x_status                    VARCHAR2 (2);
     BEGIN
          ---------------------------------------------------------------------------------
          -- Initialize Working Area parameters.
          ---------------------------------------------------------------------------------
          x_subject_area_id := i_subject_area_id;
          g_curr_subject_area_id := i_subject_area_id;
          ---------------------------------------------------------------------------------
          -- Update the DW_SUBJECT_AREA_PULL_LOG with a status of 'S' (start) for the
          -- given subject area id.
          ---------------------------------------------------------------------------------
          x_status := 'S';
          update_subject_area_pull_log (x_subject_area_id,
                                        x_status,
                                        x_pull_id,
                                        x_beg_subject_area_run_id,
                                        x_end_subject_area_run_id
                                       );
          -- Take note of the PULL_ID. This is used by WRITE_TO_DEBUG
          -- when logging debug messages
          g_curr_pull_id := x_pull_id;
          ---------------------------------------------------------------------------------
          -- Process for each table in the given subject area.
          ---------------------------------------------------------------------------------
          pull_tables (x_subject_area_id,
                       x_pull_id,
                       x_beg_subject_area_run_id,
                       x_end_subject_area_run_id,
                       x_status
                      );
          ---------------------------------------------------------------------------------
          -- Update the DW_SUBJECT_AREA_PULL_LOG with a status of 'C' (completed) for the
          -- given subject area id.
          ---------------------------------------------------------------------------------
          x_status := 'C';
          update_subject_area_pull_log (x_subject_area_id,
                                        x_status,
                                        x_pull_id,
                                        x_beg_subject_area_run_id,
                                        x_end_subject_area_run_id
                                       );
          COMMIT;
     END pull_target_subject_area;

     FUNCTION get_dw_default (x_param IN VARCHAR2)
          RETURN VARCHAR2
     IS
          x_ret_val   dw_default.DEFAULT_VALUE%TYPE;
     BEGIN
          SELECT DEFAULT_VALUE
            INTO x_ret_val
            FROM dw_default
           WHERE default_id = x_param;

			RETURN x_ret_val;

     EXCEPTION
          WHEN NO_DATA_FOUND
          THEN
               raise_application_error (-20003,
                                           'DEFAULT_ID = '
                                        || x_param
                                        || ' not configured in DW_DEFAULT table'
                                       );
          WHEN TOO_MANY_ROWS
          THEN
               raise_application_error
                                (-20003,
                                    'DEFAULT_ID = '
                                 || x_param
                                 || ' has more than one row in DW_DEFAULT table'
                                );
     END get_dw_default;

END dsr_pull;
/

