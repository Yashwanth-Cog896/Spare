CREATE OR REPLACE PACKAGE Lexicon.Unique_Vendor_Name_Maint_Pkg
IS
    PROCEDURE Sync_Vendor_Unique;
	FUNCTION Get_Vendor_Name(
		name1 Vendor.name_1%TYPE,
		name2 Vendor.name_2%TYPE,
		name3 Vendor.name_3%TYPE,
		name4 Vendor.name_4%TYPE)
		RETURN VARCHAR2;    
END;
/

CREATE OR REPLACE PACKAGE BODY Lexicon.Unique_Vendor_Name_Maint_Pkg
IS
	FUNCTION Get_Vendor_Name(
		name1 Vendor.name_1%TYPE,
		name2 Vendor.name_2%TYPE,
		name3 Vendor.name_3%TYPE,
		name4 Vendor.name_4%TYPE)
		RETURN VARCHAR2
	IS
		vendorName Vendor_Unique.vendor_unique_name%TYPE;
	BEGIN
		vendorName := TRIM(name1);
		IF SUBSTR(vendorName, LENGTH(vendorName)-1, 2) = ' &' OR
		   SUBSTR(vendorName, LENGTH(vendorName)-3, 4) = ' AND'
		THEN
			vendorName := TRIM(vendorName || ' ' || TRIM(name2));
		END IF;
		
		RETURN vendorName;
	END Get_Vendor_Name;

    FUNCTION Get_Next_Unique_Vendor_ID
        RETURN Vendor_Unique.vendor_unique_id%TYPE
    IS
        uniqueVendorID Vendor_Unique.vendor_unique_id%TYPE;
    BEGIN
        SELECT  Vendor_Unique_Pubkey_Seq.NEXTVAL
          INTO  uniqueVendorID
          FROM  DUAL;

        RETURN uniqueVendorID;
    END Get_Next_Unique_Vendor_ID;

    FUNCTION Get_Unique_Vendor_ID(
        uniqueName Vendor_Unique.vendor_unique_name%TYPE)
        RETURN Vendor_Unique.vendor_unique_id%TYPE
    IS
        uniqueVendorID Vendor_Unique.vendor_unique_id%TYPE;
    BEGIN
        SELECT  VU.vendor_unique_id
          INTO  uniqueVendorID
          FROM  Vendor_Unique VU
         WHERE  VU.vendor_unique_name = uniqueName;

        RETURN uniqueVendorID;

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN NULL;
    END Get_Unique_Vendor_ID;

    FUNCTION Get_Map_ID(
        vendorID Vendor_Unique_Map.vendor_id%TYPE)
        RETURN Vendor_Unique_Map.vendor_unique_map_id%TYPE
    IS
        mapID Vendor_Unique_Map.vendor_unique_map_id%TYPE;
    BEGIN
        SELECT  VUM.vendor_unique_map_id
          INTO  mapID
          FROM  Vendor_Unique_Map VUM
         WHERE  VUM.vendor_id = vendorID;

        RETURN  mapID;

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN NULL;
    END Get_Map_ID;



    FUNCTION Create_Unique_Vendor(
        uniqueName Vendor_Unique.vendor_unique_name%TYPE)
        RETURN Vendor_Unique.vendor_unique_id%TYPE
    IS
        uniqueVendorID Vendor_Unique.vendor_unique_id%TYPE;
        strSQL VARCHAR2(400) :=
           'INSERT ' ||
           '  INTO Vendor_Unique (vendor_unique_id, vendor_unique_name) ' ||
           'VALUES  (:id, :nm)';
    BEGIN
        uniqueVendorID := Get_Next_Unique_Vendor_ID;
        DBMS_OUTPUT.put_line(strSQL || ': ID= ' || uniqueVendorID || ' Name= ' || uniqueName);
        EXECUTE IMMEDIATE strSQL
            USING   uniqueVendorID,
                    uniqueName;

        RETURN uniqueVendorID;
    END Create_Unique_Vendor;

    PROCEDURE Remove_Unique_Vendor(
        uniqueVendorID Vendor_Unique.vendor_unique_id%TYPE)
    IS
        strSQL VARCHAR2(400) :=
           'DELETE ' ||
           '  FROM  Vendor_Unique ' ||
           ' WHERE  vendor_unique_id = :id';
    BEGIN
        DBMS_OUTPUT.put_line(strSQL || ': ID= ' || uniqueVendorID);
        EXECUTE IMMEDIATE strSQL
            USING   uniqueVendorID;
    END Remove_Unique_Vendor;

    PROCEDURE Update_Unique_Vendor(
        uniqueVendorID Vendor_Unique.vendor_unique_id%TYPE,
        uniqueVendorName Vendor_Unique.vendor_unique_name%TYPE)
    IS
        strSQL VARCHAR2(400) :=
           'UPDATE  Vendor_Unique ' ||
           '   SET  vendor_unique_name = :nm ' ||
           ' WHERE  vendor_unique_id = :id';
    BEGIN
        DBMS_OUTPUT.put_line(strSQL || ': ID= ' || uniqueVendorID || ' Name= ' || uniqueVendorName);
        EXECUTE IMMEDIATE strSQL
            USING   uniqueVendorName,
                    uniqueVendorID;
    END Update_Unique_Vendor;

    PROCEDURE Remove_Map_Entry(
        mapID Vendor_Unique_Map.vendor_unique_map_id%TYPE)
    IS
        strSQL VARCHAR2(400) :=
           'DELETE ' ||
           '  FROM  Vendor_Unique_Map ' ||
           ' WHERE  vendor_unique_map_id = :id';
    BEGIN
        DBMS_OUTPUT.put_line(strSQL || ': ID= ' || mapID);
        EXECUTE IMMEDIATE strSQL
            USING   mapID;
    END Remove_Map_Entry;

    PROCEDURE Update_Map_Entry(
        mapID Vendor_Unique_Map.vendor_unique_map_id%TYPE,
        uniqueVendorID Vendor_Unique_Map.vendor_unique_id%TYPE,
        vendorID Vendor_Unique_Map.vendor_id%TYPE)
    IS
        strSQL VARCHAR2(400) :=
           'UPDATE  Vendor_Unique_Map ' ||
           '   SET  vendor_unique_id = :uvid, ' ||
           '        vendor_id = :vid ' ||
           ' WHERE  vendor_unique_map_id = :id';
    BEGIN
        DBMS_OUTPUT.put_line(strSQL || ': UniqueID= ' || uniqueVendorID || ': VendorID= ' || vendorID || ' MapdID= ' || mapID);
        EXECUTE IMMEDIATE strSQL
            USING   uniqueVendorID,
                    vendorID,
                    mapID;
    END Update_Map_Entry;

    PROCEDURE Create_Map_Entry(
        uniqueVendorID Vendor_Unique_Map.vendor_unique_id%TYPE,
        vendorID Vendor_Unique_Map.vendor_id%TYPE)
    IS
        mapID Vendor_Unique_Map.vendor_unique_map_id%TYPE;
        strSQL VARCHAR2(400) :=
           'INSERT ' ||
           '  INTO  Vendor_Unique_Map (vendor_unique_map_id, vendor_unique_id, vendor_id) ' ||
           'VALUES (:id, :uvid, :vid)';
    BEGIN
        SELECT  VENDOR_UNIQUE_MAP_ID_SEQ.NEXTVAL
          INTO  mapID
          FROM  DUAL;
          
        DBMS_OUTPUT.put_line(strSQL || ': UniqueID= ' || uniqueVendorID || ': VendorID= ' || vendorID || ' MapdID= ' || mapID);
        EXECUTE IMMEDIATE strSQL
            USING   mapID,
                    uniqueVendorID,
                    vendorID;
    END Create_Map_Entry;

    PROCEDURE Process_Group_All_Removed(
        uniqueVendorID Vendor_Unique.vendor_unique_id%TYPE)
    IS
        numMapEntries INTEGER;
    BEGIN
        SELECT  COUNT(*)
          INTO  numMapEntries
          FROM  Vendor_Unique VU,
                Vendor_Unique_Map VUM
         WHERE  VU.vendor_unique_id = uniqueVendorID
           AND  VU.vendor_unique_id = VUM.vendor_unique_id;
         -- AND VUM.logical_delete <> 'y'

        IF numMapEntries = 0 THEN
            Remove_Unique_Vendor(uniqueVendorID);
        END IF;
    END Process_Group_All_Removed;

    PROCEDURE Process_Group_All_Updated(
        uniqueVendorID Vendor_Unique.vendor_unique_id%TYPE,
        uniqueVendorName Vendor_Unique.vendor_unique_name%TYPE)
    IS
        CURSOR curs IS
            SELECT  DISTINCT Get_Vendor_Name(V.name_1, V.name_2, V.name_3, V.name_4) AS VendorName
              FROM  Vendor_Unique_Map VUM,
                    Vendor V
             WHERE  VUM.vendor_unique_id = uniqueVendorID
               AND  VUM.vendor_id = V.vendor_id;
               -- AND VUM.logical_delete <> 'y'

        isStillUnique BOOLEAN := TRUE;
        newName Vendor_Unique.vendor_unique_name%TYPE := NULL;
    BEGIN
        FOR rec IN curs LOOP
            IF newName IS NULL THEN
                newName := rec.VendorName;
            ELSE
                isStillUnique := FALSE;
            END IF;
        END LOOP;

        IF isStillUnique AND newName <> uniqueVendorName THEN
            Update_Unique_Vendor(uniqueVendorID, newName);
        END IF;
    END Process_Group_All_Updated;

    PROCEDURE Process_Groups
    IS
        CURSOR curs IS
            SELECT  VU.vendor_unique_id, VU.vendor_unique_name
              FROM  Vendor_Unique VU;
            -- WHERE VU.logical_delete <> 'y'
    BEGIN
        FOR rec IN curs LOOP
            Process_Group_All_Removed(rec.vendor_unique_id);
            Process_Group_All_Updated(rec.vendor_unique_id, rec.vendor_unique_name);
        END LOOP;
    END Process_Groups;

    PROCEDURE Process_Remove_Actions
    IS
        CURSOR curs IS
            SELECT  VUM.vendor_unique_map_id,
                    V.vendor_id
              FROM  Vendor_Unique_Map VUM,
                    Vendor V,
                    Vendor_Carrier VC
             WHERE  VUM.vendor_id = V.vendor_id (+)
               AND  VUM.vendor_id = VC.vendor_id (+)
               AND  V.vendor_id IS NULL
               AND  VC.vendor_id IS NULL;
               -- AND VU.logical_delete <> 'y'
               -- AND VUM.logical_delete <> 'y'
    BEGIN
        FOR rec IN curs LOOP
            Remove_Map_Entry(rec.vendor_unique_map_id);
        END LOOP;
    END Process_Remove_Actions;

    PROCEDURE Process_Update(
        newName Vendor_Unique.vendor_unique_name%TYPE,
        vendorID Vendor.vendor_id%TYPE,
        uniqueVendorMapID Vendor_Unique_Map.vendor_unique_map_id%TYPE)
    IS
        uniqueVendorID Vendor_Unique.vendor_unique_id%TYPE;
    BEGIN
        uniqueVendorID := Get_Unique_Vendor_ID(newName);
        IF uniqueVendorID IS NULL THEN
            uniqueVendorID := Create_Unique_Vendor(newName);
        END IF;
        Update_Map_Entry(uniqueVendorMapID, uniqueVendorID, vendorID);
    END Process_Update;

    PROCEDURE Process_Update_Actions
    IS
        CURSOR curs IS
            SELECT  VU.vendor_unique_name,
                    VUM.vendor_unique_map_id,
                    V.vendor_id,
                    Get_Vendor_Name(V.name_1, V.name_2, V.name_3, V.name_4) AS VendorName
              FROM  Vendor_Unique VU,
                    Vendor_Unique_Map VUM,
                    Vendor V
             WHERE  VU.vendor_unique_id = VUM.vendor_unique_id
               AND  VUM.vendor_id = V.vendor_id
               AND  Get_Vendor_Name(V.name_1, V.name_2, V.name_3, V.name_4) <> VU.vendor_unique_name;
               -- AND VU.logical_delete <> 'y'
               -- AND VUM.logical_delete <> 'y'
    BEGIN
        FOR rec IN curs LOOP
            Process_Update(rec.VendorName, rec.vendor_id, rec.vendor_unique_map_id);
        END LOOP;
    END Process_Update_Actions;

    PROCEDURE Process_Insert(
        vendorID Vendor.vendor_id%TYPE,
        vendorName Vendor_Unique.vendor_unique_name%TYPE)
    IS
        mapID Vendor_Unique_Map.vendor_unique_map_id%TYPE;
        uniqueVendorID Vendor_Unique.vendor_unique_id%TYPE;
    BEGIN
        uniqueVendorID := Get_Unique_Vendor_ID(vendorName);
        IF uniqueVendorID IS NULL THEN
            uniqueVendorID := Create_Unique_Vendor(vendorName);
        END IF;

        mapID := Get_Map_ID(vendorID);
        IF mapID IS NULL THEN
            Create_Map_Entry(uniqueVendorID, vendorID);
        ELSE
            Update_Map_Entry(mapID, uniqueVendorID, vendorID);
        END IF;

    END Process_Insert;


    PROCEDURE Process_Insert_Actions
    IS
        CURSOR curs IS
            SELECT  V.vendor_id, 
			        Get_Vendor_Name(V.name_1, V.name_2, V.name_3, V.name_4) AS VendorName
              FROM  Vendor V,
                    Vendor_Unique_Map VUM
             WHERE  V.vendor_id = VUM.vendor_id (+)
               AND  VUM.vendor_id IS NULL;
    BEGIN
        FOR rec IN curs LOOP
            Process_Insert(rec.vendor_id, rec.VendorName);
        END LOOP;
    END Process_Insert_Actions;


    PROCEDURE Sync_Vendor_Unique
    IS
    BEGIN
        Process_Remove_Actions;
        Process_Groups;
        Process_Update_Actions;
        Process_Insert_Actions;
    END Sync_Vendor_Unique;
END;
/

GRANT EXECUTE ON Lexicon.Unique_Vendor_Name_Maint_Pkg TO Lexicon_User, Lexicon_Rw_Role
/

