/* subject_area_ids as of 10/31/2005   */
/* CO DA ES F2 FI FN FS J1 L2 LK M2 MM PA PC PR QM S2 SD  */

/*
INSERT INTO DW_SUBJECT_AREA_PULL_LOG
	(
	SUBJECT_AREA_ID         ,       
	PULL_ID                        ,
	ROW_INSERT_DATE                ,
	ROW_INSERT_USER_ID             ,
	ROW_INSERT_TASK_ID             ,
	ROW_UPDATE_DATE                ,
	ROW_UPDATE_USER_ID             ,
	ROW_UPDATE_TASK_ID             ,
	DW_COMPLETION_DATE_TIME        ,
	DW_STATUS                      ,
	BEGINNING_SUBJECT_AREA_RUN_ID  ,
	ENDING_SUBJECT_AREA_RUN_ID     
	)
VALUES  (	'CO',
		0,
		null,
		null,
		null,
		null,
		null,
		null,
		null,
		'C',
		0,
		0
	);
	
INSERT INTO DW_SUBJECT_AREA_PULL_LOG
	(
	SUBJECT_AREA_ID         ,       
	PULL_ID                        ,
	ROW_INSERT_DATE                ,
	ROW_INSERT_USER_ID             ,
	ROW_INSERT_TASK_ID             ,
	ROW_UPDATE_DATE                ,
	ROW_UPDATE_USER_ID             ,
	ROW_UPDATE_TASK_ID             ,
	DW_COMPLETION_DATE_TIME        ,
	DW_STATUS                      ,
	BEGINNING_SUBJECT_AREA_RUN_ID  ,
	ENDING_SUBJECT_AREA_RUN_ID     
	)
VALUES  (	'DA',
		0,
		null,
		null,
		null,
		null,
		null,
		null,
		null,
		'C',
		0,
		0
	);

INSERT INTO DW_SUBJECT_AREA_PULL_LOG
	(
	SUBJECT_AREA_ID         ,       
	PULL_ID                        ,
	ROW_INSERT_DATE                ,
	ROW_INSERT_USER_ID             ,
	ROW_INSERT_TASK_ID             ,
	ROW_UPDATE_DATE                ,
	ROW_UPDATE_USER_ID             ,
	ROW_UPDATE_TASK_ID             ,
	DW_COMPLETION_DATE_TIME        ,
	DW_STATUS                      ,
	BEGINNING_SUBJECT_AREA_RUN_ID  ,
	ENDING_SUBJECT_AREA_RUN_ID     
	)
VALUES  (	'ES',
		0,
		null,
		null,
		null,
		null,
		null,
		null,
		null,
		'C',
		0,
		0
	);


INSERT INTO DW_SUBJECT_AREA_PULL_LOG
	(
	SUBJECT_AREA_ID         ,       
	PULL_ID                        ,
	ROW_INSERT_DATE                ,
	ROW_INSERT_USER_ID             ,
	ROW_INSERT_TASK_ID             ,
	ROW_UPDATE_DATE                ,
	ROW_UPDATE_USER_ID             ,
	ROW_UPDATE_TASK_ID             ,
	DW_COMPLETION_DATE_TIME        ,
	DW_STATUS                      ,
	BEGINNING_SUBJECT_AREA_RUN_ID  ,
	ENDING_SUBJECT_AREA_RUN_ID     
	)
VALUES  (	'F2',
		0,
		null,
		null,
		null,
		null,
		null,
		null,
		null,
		'C',
		0,
		0
	);	
	
INSERT INTO DW_SUBJECT_AREA_PULL_LOG
	(
	SUBJECT_AREA_ID         ,       
	PULL_ID                        ,
	ROW_INSERT_DATE                ,
	ROW_INSERT_USER_ID             ,
	ROW_INSERT_TASK_ID             ,
	ROW_UPDATE_DATE                ,
	ROW_UPDATE_USER_ID             ,
	ROW_UPDATE_TASK_ID             ,
	DW_COMPLETION_DATE_TIME        ,
	DW_STATUS                      ,
	BEGINNING_SUBJECT_AREA_RUN_ID  ,
	ENDING_SUBJECT_AREA_RUN_ID     
	)
VALUES  (	'FI',
		0,
		null,
		null,
		null,
		null,
		null,
		null,
		null,
		'C',
		0,
		0
	);

INSERT INTO DW_SUBJECT_AREA_PULL_LOG
	(
	SUBJECT_AREA_ID         ,       
	PULL_ID                        ,
	ROW_INSERT_DATE                ,
	ROW_INSERT_USER_ID             ,
	ROW_INSERT_TASK_ID             ,
	ROW_UPDATE_DATE                ,
	ROW_UPDATE_USER_ID             ,
	ROW_UPDATE_TASK_ID             ,
	DW_COMPLETION_DATE_TIME        ,
	DW_STATUS                      ,
	BEGINNING_SUBJECT_AREA_RUN_ID  ,
	ENDING_SUBJECT_AREA_RUN_ID     
	)
VALUES  (	'FN',
		0,
		null,
		null,
		null,
		null,
		null,
		null,
		null,
		'C',
		0,
		0
	);

INSERT INTO DW_SUBJECT_AREA_PULL_LOG
	(
	SUBJECT_AREA_ID         ,       
	PULL_ID                        ,
	ROW_INSERT_DATE                ,
	ROW_INSERT_USER_ID             ,
	ROW_INSERT_TASK_ID             ,
	ROW_UPDATE_DATE                ,
	ROW_UPDATE_USER_ID             ,
	ROW_UPDATE_TASK_ID             ,
	DW_COMPLETION_DATE_TIME        ,
	DW_STATUS                      ,
	BEGINNING_SUBJECT_AREA_RUN_ID  ,
	ENDING_SUBJECT_AREA_RUN_ID     
	)
VALUES  (	'FS',
		0,
		null,
		null,
		null,
		null,
		null,
		null,
		null,
		'C',
		0,
		0
	);


INSERT INTO DW_SUBJECT_AREA_PULL_LOG
	(
	SUBJECT_AREA_ID         ,       
	PULL_ID                        ,
	ROW_INSERT_DATE                ,
	ROW_INSERT_USER_ID             ,
	ROW_INSERT_TASK_ID             ,
	ROW_UPDATE_DATE                ,
	ROW_UPDATE_USER_ID             ,
	ROW_UPDATE_TASK_ID             ,
	DW_COMPLETION_DATE_TIME        ,
	DW_STATUS                      ,
	BEGINNING_SUBJECT_AREA_RUN_ID  ,
	ENDING_SUBJECT_AREA_RUN_ID     
	)
VALUES  (	'J1',
		0,
		null,
		null,
		null,
		null,
		null,
		null,
		null,
		'C',
		0,
		0
	);

INSERT INTO DW_SUBJECT_AREA_PULL_LOG
	(
	SUBJECT_AREA_ID         ,       
	PULL_ID                        ,
	ROW_INSERT_DATE                ,
	ROW_INSERT_USER_ID             ,
	ROW_INSERT_TASK_ID             ,
	ROW_UPDATE_DATE                ,
	ROW_UPDATE_USER_ID             ,
	ROW_UPDATE_TASK_ID             ,
	DW_COMPLETION_DATE_TIME        ,
	DW_STATUS                      ,
	BEGINNING_SUBJECT_AREA_RUN_ID  ,
	ENDING_SUBJECT_AREA_RUN_ID     
	)
VALUES  (	'L2',
		0,
		null,
		null,
		null,
		null,
		null,
		null,
		null,
		'C',
		0,
		0
	);
*/

INSERT INTO DW_SUBJECT_AREA_PULL_LOG
	(
	SUBJECT_AREA_ID         ,       
	PULL_ID                        ,
	ROW_INSERT_DATE                ,
	ROW_INSERT_USER_ID             ,
	ROW_INSERT_TASK_ID             ,
	ROW_UPDATE_DATE                ,
	ROW_UPDATE_USER_ID             ,
	ROW_UPDATE_TASK_ID             ,
	DW_COMPLETION_DATE_TIME        ,
	DW_STATUS                      ,
	BEGINNING_SUBJECT_AREA_RUN_ID  ,
	ENDING_SUBJECT_AREA_RUN_ID     
	)
VALUES  (	'LK',
		0,
		null,
		null,
		null,
		null,
		null,
		null,
		null,
		'C',
		0,
		0
	);

/*INSERT INTO DW_SUBJECT_AREA_PULL_LOG
	(
	SUBJECT_AREA_ID         ,       
	PULL_ID                        ,
	ROW_INSERT_DATE                ,
	ROW_INSERT_USER_ID             ,
	ROW_INSERT_TASK_ID             ,
	ROW_UPDATE_DATE                ,
	ROW_UPDATE_USER_ID             ,
	ROW_UPDATE_TASK_ID             ,
	DW_COMPLETION_DATE_TIME        ,
	DW_STATUS                      ,
	BEGINNING_SUBJECT_AREA_RUN_ID  ,
	ENDING_SUBJECT_AREA_RUN_ID     
	)
VALUES  (	'M2',
		0,
		null,
		null,
		null,
		null,
		null,
		null,
		null,
		'C',
		0,
		0
	);

INSERT INTO DW_SUBJECT_AREA_PULL_LOG
	(
	SUBJECT_AREA_ID         ,       
	PULL_ID                        ,
	ROW_INSERT_DATE                ,
	ROW_INSERT_USER_ID             ,
	ROW_INSERT_TASK_ID             ,
	ROW_UPDATE_DATE                ,
	ROW_UPDATE_USER_ID             ,
	ROW_UPDATE_TASK_ID             ,
	DW_COMPLETION_DATE_TIME        ,
	DW_STATUS                      ,
	BEGINNING_SUBJECT_AREA_RUN_ID  ,
	ENDING_SUBJECT_AREA_RUN_ID     
	)
VALUES  (	'MM',
		0,
		null,
		null,
		null,
		null,
		null,
		null,
		null,
		'C',
		0,
		0
	);

INSERT INTO DW_SUBJECT_AREA_PULL_LOG
	(
	SUBJECT_AREA_ID         ,       
	PULL_ID                        ,
	ROW_INSERT_DATE                ,
	ROW_INSERT_USER_ID             ,
	ROW_INSERT_TASK_ID             ,
	ROW_UPDATE_DATE                ,
	ROW_UPDATE_USER_ID             ,
	ROW_UPDATE_TASK_ID             ,
	DW_COMPLETION_DATE_TIME        ,
	DW_STATUS                      ,
	BEGINNING_SUBJECT_AREA_RUN_ID  ,
	ENDING_SUBJECT_AREA_RUN_ID     
	)
VALUES  (	'PA',
		0,
		null,
		null,
		null,
		null,
		null,
		null,
		null,
		'C',
		0,
		0
	);

INSERT INTO DW_SUBJECT_AREA_PULL_LOG
	(
	SUBJECT_AREA_ID         ,       
	PULL_ID                        ,
	ROW_INSERT_DATE                ,
	ROW_INSERT_USER_ID             ,
	ROW_INSERT_TASK_ID             ,
	ROW_UPDATE_DATE                ,
	ROW_UPDATE_USER_ID             ,
	ROW_UPDATE_TASK_ID             ,
	DW_COMPLETION_DATE_TIME        ,
	DW_STATUS                      ,
	BEGINNING_SUBJECT_AREA_RUN_ID  ,
	ENDING_SUBJECT_AREA_RUN_ID     
	)
VALUES  (	'PC',
		0,
		null,
		null,
		null,
		null,
		null,
		null,
		null,
		'C',
		0,
		0
	);

INSERT INTO DW_SUBJECT_AREA_PULL_LOG
	(
	SUBJECT_AREA_ID         ,       
	PULL_ID                        ,
	ROW_INSERT_DATE                ,
	ROW_INSERT_USER_ID             ,
	ROW_INSERT_TASK_ID             ,
	ROW_UPDATE_DATE                ,
	ROW_UPDATE_USER_ID             ,
	ROW_UPDATE_TASK_ID             ,
	DW_COMPLETION_DATE_TIME        ,
	DW_STATUS                      ,
	BEGINNING_SUBJECT_AREA_RUN_ID  ,
	ENDING_SUBJECT_AREA_RUN_ID     
	)
VALUES  (	'PR',
		0,
		null,
		null,
		null,
		null,
		null,
		null,
		null,
		'C',
		0,
		0
	);

INSERT INTO DW_SUBJECT_AREA_PULL_LOG
	(
	SUBJECT_AREA_ID         ,       
	PULL_ID                        ,
	ROW_INSERT_DATE                ,
	ROW_INSERT_USER_ID             ,
	ROW_INSERT_TASK_ID             ,
	ROW_UPDATE_DATE                ,
	ROW_UPDATE_USER_ID             ,
	ROW_UPDATE_TASK_ID             ,
	DW_COMPLETION_DATE_TIME        ,
	DW_STATUS                      ,
	BEGINNING_SUBJECT_AREA_RUN_ID  ,
	ENDING_SUBJECT_AREA_RUN_ID     
	)
VALUES  (	'QM',
		0,
		null,
		null,
		null,
		null,
		null,
		null,
		null,
		'C',
		0,
		0
	);

INSERT INTO DW_SUBJECT_AREA_PULL_LOG
	(
	SUBJECT_AREA_ID         ,       
	PULL_ID                        ,
	ROW_INSERT_DATE                ,
	ROW_INSERT_USER_ID             ,
	ROW_INSERT_TASK_ID             ,
	ROW_UPDATE_DATE                ,
	ROW_UPDATE_USER_ID             ,
	ROW_UPDATE_TASK_ID             ,
	DW_COMPLETION_DATE_TIME        ,
	DW_STATUS                      ,
	BEGINNING_SUBJECT_AREA_RUN_ID  ,
	ENDING_SUBJECT_AREA_RUN_ID     
	)
VALUES  (	'S2',
		0,
		null,
		null,
		null,
		null,
		null,
		null,
		null,
		'C',
		0,
		0
	);

INSERT INTO DW_SUBJECT_AREA_PULL_LOG
	(
	SUBJECT_AREA_ID         ,       
	PULL_ID                        ,
	ROW_INSERT_DATE                ,
	ROW_INSERT_USER_ID             ,
	ROW_INSERT_TASK_ID             ,
	ROW_UPDATE_DATE                ,
	ROW_UPDATE_USER_ID             ,
	ROW_UPDATE_TASK_ID             ,
	DW_COMPLETION_DATE_TIME        ,
	DW_STATUS                      ,
	BEGINNING_SUBJECT_AREA_RUN_ID  ,
	ENDING_SUBJECT_AREA_RUN_ID     
	)
VALUES  (	'SD',
		0,
		null,
		null,
		null,
		null,
		null,
		null,
		null,
		'C',
		0,
		0
	);
*/

COMMIT;
