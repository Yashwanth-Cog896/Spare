ALTER TABLE Lexicon.Vendor_Unique
    MODIFY (
        VENDOR_UNIQUE_NAME VARCHAR2 (70)
    )
/
