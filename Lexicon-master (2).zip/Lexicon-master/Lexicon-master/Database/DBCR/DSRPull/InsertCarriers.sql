INSERT INTO Lexicon.Vendor_Carrier (vendor_carrier_id, vendor_id) VALUES (1, '0000343885');
INSERT INTO Lexicon.Vendor_Carrier (vendor_carrier_id, vendor_id) VALUES (2, '0000216092');
INSERT INTO Lexicon.Vendor_Carrier (vendor_carrier_id, vendor_id) VALUES (3, '0000230005');
INSERT INTO Lexicon.Vendor_Carrier (vendor_carrier_id, vendor_id) VALUES (4, '0000429673');
INSERT INTO Lexicon.Vendor_Carrier (vendor_carrier_id, vendor_id) VALUES (5, '0000350435');
INSERT INTO Lexicon.Vendor_Carrier (vendor_carrier_id, vendor_id) VALUES (6, '0000461752');
INSERT INTO Lexicon.Vendor_Carrier (vendor_carrier_id, vendor_id) VALUES (7, '0000370699');
