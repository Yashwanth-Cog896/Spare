INSERT INTO Lexicon.Vendor_Unique(
    Vendor_Unique_ID,
    Vendor_Unique_Name
    )
    ( 
		SELECT  Lexicon.Vendor_Unique_Pubkey_Seq.NEXTVAL,
                IQ.Vendor_Name
          FROM  (
                	SELECT  DISTINCT Lexicon.Unique_Vendor_Name_Maint_Pkg.get_vendor_name(V.name_1,V.name_2,V.name_3,V.name_4) AS Vendor_Name
                  	  FROM  Lexicon.Vendor V
--                 	 WHERE  V.name_1 <> 'UPS'
               	) IQ
    );
    
INSERT INTO Lexicon.Vendor_Unique_Map(
	Vendor_Unique_Map_ID,
	Vendor_Unique_ID,
	Vendor_ID
	)
	(
		SELECT  Lexicon.Vendor_Unique_Map_Id_Seq.NEXTVAL,
		        VU.vendor_unique_id,
		        V.vendor_id
		  FROM  Lexicon.Vendor_Unique VU,
		        Lexicon.Vendor V		        
		 WHERE  VU.vendor_unique_name = Lexicon.Unique_Vendor_Name_Maint_Pkg.get_vendor_name(V.name_1,V.name_2,V.name_3,V.name_4)
	);	
    
