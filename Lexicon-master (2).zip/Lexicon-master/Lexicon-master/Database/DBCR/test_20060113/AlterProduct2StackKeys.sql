ALTER TABLE Lexicon.Product_Name
    DROP CONSTRAINT Fk_Product_Name_Trait_Stack_Id
/

ALTER TABLE Lexicon.Product_Name
    ADD CONSTRAINT Fk_PName_Trait_Stack_Id2 
        FOREIGN KEY (Coml_Trait_Stack_Id)
        REFERENCES Lexicon.Coml_Trait_Stack2 (Coml_Trait_Stack_Id)
/

ALTER TABLE Lexicon.Product_Stage
    DROP CONSTRAINT Fk_Prod_Stage_Coml_Trt_Stck_Id
/

ALTER TABLE Lexicon.Product_Stage
    ADD CONSTRAINT Fk_PStage_Trait_Stack_Id2 
        FOREIGN KEY (Coml_Trait_Stack_Id)
        REFERENCES Lexicon.Coml_Trait_Stack2 (Coml_Trait_Stack_Id)
/

