CREATE TABLE Lexicon.Sap_Linkage_Audit (
    sap_linkage_audit_id  NUMBER                    NOT NULL,
    pubkey                VARCHAR2 (20)             NOT NULL,
    request_type          VARCHAR2 (1)              NOT NULL,
    timestamp             TIMESTAMP DEFAULT SYSDATE NOT NULL,
    result                VARCHAR2 (1000),
    audit_header_id       NUMBER,
    CONSTRAINT Sap_Linkage_Audit_Pk
        PRIMARY KEY (sap_linkage_audit_id)
        USING INDEX
        TABLESPACE  Lexicon_Audit_Index
    )
TABLESPACE Lexicon_Audit_Data
/

CREATE SEQUENCE Lexicon.Sap_Linkage_Audit_Id_Seq
  INCREMENT BY 1
  START WITH 1000
  MINVALUE 1
  MAXVALUE 999999999999999999999999999
  NOCYCLE
  NOORDER
  CACHE 20
/



