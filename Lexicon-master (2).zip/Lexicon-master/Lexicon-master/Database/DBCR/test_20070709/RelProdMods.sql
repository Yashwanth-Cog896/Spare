ALTER TABLE Lexicon.Product_Relationship ADD (
	Base_Product_Id NUMBER,
	Logical_Delete 	VARCHAR2(1)
)
/

ALTER TABLE Lexicon.Product_Relationship 
    ADD CONSTRAINT Prod_Rel_Base_Prod_FK
    FOREIGN KEY (Base_Product_Id)
    REFERENCES Lexicon.Base_Product (Base_Product_Id) 
/

CREATE INDEX Lexicon.Prod_Rel_Base_Prod_Idx 
    ON Lexicon.Product_Relationship (  Base_Product_Id ASC  ) 
    TABLESPACE Lexicon_Index
/

