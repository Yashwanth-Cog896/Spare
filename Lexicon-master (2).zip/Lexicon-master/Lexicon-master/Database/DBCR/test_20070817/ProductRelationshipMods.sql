ALTER TABLE Lexicon.Product_Relationship ADD (
   VARIETY_NAME VARCHAR2(10)
)
/