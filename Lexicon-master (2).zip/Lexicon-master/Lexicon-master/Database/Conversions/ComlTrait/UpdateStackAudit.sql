UPDATE  Lexicon.Audit_Detail
   SET  column_name = 'STACK_ABBR'
 WHERE  audit_detail_id IN (
            SELECT  AD.audit_detail_id
              FROM  Lexicon.Audit_Detail AD,
                    Lexicon.Audit_Header AH
             WHERE  AD.column_name = 'COML_TRAIT_STACK_ABBR'
               AND  AD.audit_header_id = AH.audit_header_id
               AND  AH.table_name = 'COML_TRAIT_STACK'
        );
        
UPDATE  Lexicon.Audit_Header
   SET  table_name = 'COML_TRAIT_STACK2'
 WHERE  table_name = 'COML_TRAIT_STACK';


