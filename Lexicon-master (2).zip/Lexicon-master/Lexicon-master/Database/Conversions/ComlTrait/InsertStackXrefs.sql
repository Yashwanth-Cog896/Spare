INSERT 
  INTO  Lexicon.Coml_Trait_Stack_Xref2 (
            coml_trait_stack_xref_id,
            coml_trait_name_id,
            coml_trait_stack_id
        )
        (
            SELECT  CTSX.coml_trait_stack_xref_id,
                    CTSX.coml_trait_name_id,
                    CTSX.coml_trait_stack_id
              FROM  Lexicon.Coml_Trait_Stack_Xref CTSX
        );
        
            
