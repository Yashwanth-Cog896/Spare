INSERT 
  INTO  Lexicon.Coml_Trait_Name2 (
            coml_trait_name_id, 
            trait_abbr,
            trait_desc,
            crop_id,
            company_id,
            is_active
        )
        (
            SELECT  CTN.coml_trait_name_id,
                    CTN.coml_trait_name_abbr,
                    CTN.coml_trait_name_desc,
                    CT.crop_id,
                    CTN.company_id,
                    CTN.is_active
              FROM  Lexicon.Coml_Trait_Name CTN,
                    Lexicon.Coml_Trait CT
             WHERE  CTN.coml_trait_id = CT.coml_trait_id
        );
        
