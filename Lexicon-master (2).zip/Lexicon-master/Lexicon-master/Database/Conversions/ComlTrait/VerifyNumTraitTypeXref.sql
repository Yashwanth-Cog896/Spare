SELECT  SUM(Total)
  FROM  (

SELECT  CTTX.coml_trait_id,
        CTTX.Num * CTN.Num AS Total
  FROM  (
            SELECT  coml_trait_id, 
                    COUNT(*) AS Num
              FROM  Lexicon.Coml_Trait_Type_Xref
            GROUP BY coml_trait_id
        ) CTTX,
        (
            SELECT coml_trait_id, 
                   COUNT(*) AS Num
              FROM Lexicon.Coml_Trait_Name
            GROUP BY coml_trait_id
        ) CTN
 WHERE  CTTX.coml_trait_id = CTN.coml_trait_id
)
