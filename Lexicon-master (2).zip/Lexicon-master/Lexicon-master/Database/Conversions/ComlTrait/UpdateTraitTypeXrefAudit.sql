INSERT 
  INTO  Lexicon.Audit_Header (
            audit_header_id,
            audit_operation_type,
            user_party_id,
            table_name,
            entry_date,
            primary_key_field1,
            process_name,
            audit_comment,
            audit_requestor
        )
        (
            SELECT  Lexicon.Audit_Header_Seq.NEXTVAL,
                    'I',
                    86196,
                    'COML_TRAIT_TYPE_XREF2',
                    SYSDATE,
                    CTTX.coml_trait_type_xref_id,
                    'DATA LOAD',
                    'Conversion of Coml Trait Data Model',
                    'JASKIDI'
              FROM  Lexicon.Coml_Trait_Type_Xref2 CTTX
        );
        
INSERT
  INTO  Lexicon.Audit_Detail (
            audit_detail_id,
            audit_header_id,
            column_name,
            new_value,
            old_value
        )
        (
            SELECT  Lexicon.Audit_Detail_Seq.NEXTVAL,
                    AH.audit_header_id,
                    'COML_TRAIT_TYPE_XREF_ID',
                    CTTX.coml_trait_type_xref_id,
                    NULL
              FROM  Lexicon.Audit_Header AH,
                    Lexicon.Coml_Trait_Type_Xref2 CTTX
             WHERE  AH.table_name = 'COML_TRAIT_TYPE_XREF2'
               AND  AH.audit_operation_type = 'I'
               AND  AH.primary_key_field1 = CTTX.coml_trait_type_xref_id
        );

INSERT
  INTO  Lexicon.Audit_Detail (
            audit_detail_id,
            audit_header_id,
            column_name,
            new_value,
            old_value
        )
        (
            SELECT  Lexicon.Audit_Detail_Seq.NEXTVAL,
                    AH.audit_header_id,
                    'COML_TRAIT_NAME_ID',
                    CTTX.coml_trait_name_id,
                    NULL
              FROM  Lexicon.Audit_Header AH,
                    Lexicon.Coml_Trait_Type_Xref2 CTTX
             WHERE  AH.table_name = 'COML_TRAIT_TYPE_XREF2'
               AND  AH.audit_operation_type = 'I'
               AND  AH.primary_key_field1 = CTTX.coml_trait_type_xref_id
        );
        
INSERT
  INTO  Lexicon.Audit_Detail (
            audit_detail_id,
            audit_header_id,
            column_name,
            new_value,
            old_value
        )
        (
            SELECT  Lexicon.Audit_Detail_Seq.NEXTVAL,
                    AH.audit_header_id,
                    'COML_TRAIT_TYPE_ID',
                    CTTX.coml_trait_type_id,
                    NULL
              FROM  Lexicon.Audit_Header AH,
                    Lexicon.Coml_Trait_Type_Xref2 CTTX
             WHERE  AH.table_name = 'COML_TRAIT_TYPE_XREF2'
               AND  AH.audit_operation_type = 'I'
               AND  AH.primary_key_field1 = CTTX.coml_trait_type_xref_id
        );
        
        
