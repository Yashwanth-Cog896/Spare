INSERT 
  INTO  Lexicon.Coml_Trait_Stack2 (
            coml_trait_stack_id,
            reporting_name,
            crop_id,
         	td_name,
			stack_abbr,
			stack_desc   
        )
        (     
            SELECT  CTS.coml_trait_stack_id, 
                    CTSN.reporting_name,
                    CTS.crop_id,
                    NVL(CTSN.reporting_name, CTS.coml_trait_stack_abbr),
                    CTS.coml_trait_stack_abbr,
                    CTS.coml_trait_stack_abbr
              FROM  Lexicon.Coml_Trait_Stack CTS,
                    Lexicon.Coml_Trait_Stack_Names_Vw CTSN
             WHERE  CTS.coml_trait_stack_id = CTSN.coml_trait_stack_id (+)
        );
        
