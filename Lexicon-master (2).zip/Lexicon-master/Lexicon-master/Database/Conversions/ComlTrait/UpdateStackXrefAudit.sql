UPDATE  Lexicon.Audit_Header
   SET  table_name = 'COML_TRAIT_STACK_XREF2'
 WHERE  table_name = 'COML_TRAIT_STACK_XREF';
 
