INSERT
  INTO  Lexicon.Coml_Trait_Type_Xref2 (
            coml_trait_type_xref_id,
            coml_trait_name_id,
            coml_trait_type_id
        )
        (
            SELECT  MOD(CTTX.coml_trait_type_xref_id, 100) * 100 + MOD(CTN.coml_trait_name_id, 100),
                    CTN.coml_trait_name_id,
                    CTT.coml_trait_type_id                    
              FROM  Lexicon.Coml_Trait_Type_Xref CTTX,
                    Lexicon.Coml_Trait_Name CTN,
                    Lexicon.Coml_Trait_Type CTT
             WHERE  CTTX.coml_trait_id = CTN.coml_trait_id
               AND  CTTX.coml_trait_type_id = CTT.coml_trait_type_id
        );
        
