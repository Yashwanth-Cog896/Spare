UPDATE  Lexicon.Audit_Detail
   SET  column_name = 'TRAIT_ABBR'
 WHERE  audit_detail_id IN (
            SELECT  AD.audit_detail_id
              FROM  Lexicon.Audit_Detail AD,
                    Lexicon.Audit_Header AH
             WHERE  AD.column_name = 'COML_TRAIT_NAME_ABBR'
               AND  AD.audit_header_id = AH.audit_header_id
               AND  AH.table_name = 'COML_TRAIT_NAME'
        );

UPDATE  Lexicon.Audit_Detail
   SET  column_name = 'TRAIT_DESC'
 WHERE  audit_detail_id IN (
            SELECT  AD.audit_detail_id
              FROM  Lexicon.Audit_Detail AD,
                    Lexicon.Audit_Header AH
             WHERE  AD.column_name = 'COML_TRAIT_NAME_DESC'
               AND  AD.audit_header_id = AH.audit_header_id
               AND  AH.table_name = 'COML_TRAIT_NAME'
        );
        
DELETE
  FROM  Audit_Detail
 WHERE  audit_detail_id IN (
            SELECT  AD.audit_detail_id
              FROM  Lexicon.Audit_Detail AD,
                    Lexicon.Audit_Header AH
             WHERE  AD.column_name = 'COML_TRAIT_ID'
               AND  AD.audit_header_id = AH.audit_header_id
               AND  AH.table_name = 'COML_TRAIT_NAME'
        );
        
INSERT
  INTO  Lexicon.Audit_Detail (
  			audit_detail_id,
  			audit_header_id,
  			column_name,
  			new_value,
  			old_value)
  		(
  			SELECT  Lexicon.Audit_Detail_Seq.NEXTVAL,
  			        AH.audit_header_id,
  			        'CROP_ID',
  			        CTN.crop_id,
  			        NULL
  			  FROM  Lexicon.Audit_Header AH,
  			        Lexicon.Coml_Trait_Name2 CTN
  			 WHERE  AH.table_name = 'COML_TRAIT_NAME'
  			   AND  AH.audit_operation_type = 'I'
  			   AND  AH.primary_key_field1 = CTN.coml_trait_name_id
  		);

UPDATE  Lexicon.Audit_Header
   SET  table_name = 'COML_TRAIT_NAME2'
 WHERE  table_name = 'COML_TRAIT_NAME';
 
