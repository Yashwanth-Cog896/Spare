SELECT  MOD(CTTX.coml_trait_type_xref_id, 100) * 100 + MOD(CTN.coml_trait_name_id, 100),
        COUNT(*)
  FROM  Lexicon.Coml_Trait_Type_Xref CTTX,
        Lexicon.Coml_Trait_Name CTN
 WHERE  CTTX.coml_trait_id = CTN.coml_trait_id
GROUP BY MOD(CTTX.coml_trait_type_xref_id, 100) * 100 + MOD(CTN.coml_trait_name_id, 100)
--HAVING COUNT(*) > 1

