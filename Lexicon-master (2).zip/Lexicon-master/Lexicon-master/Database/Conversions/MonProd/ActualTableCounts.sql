SELECT  'Lex PCP' AS "Table", count(*) AS "Count"
  FROM  Lexicon.Pre_Coml_Product

UNION

SELECT  'Lex Stage' AS "Table", count(*) AS "Count"
  FROM  Lexicon.Product_Stage

UNION

SELECT  'Prod Xref' AS "Table", count(*) AS "Count"
  FROM  FBS_Prod_Xref

UNION

SELECT  'Prod Name Xref' AS "Table", count(*) AS "Count"
  FROM  FBS_Prod_Name_Xref
  
UNION

SELECT  'Prod GP Action' AS "Table", count(*) AS "Count"
  FROM  Lexicon.Product_GP_Action
  


