BEGIN
    Lexicon.Audit_Pkg.Initialize_Staging_P(86196, 'DATA LOAD', 'Initial Data Load', NULL);

    INSERT 
      INTO Lex_Stage (stage_id, stage_abbr, stage_desc, order_by_num, is_coml_stage, stage_pubkey)
    VALUES (100, 'PS1', 'Pre-Commercial Testing 1st Year', 1, 'n', '100');
    
    INSERT 
      INTO Lex_Stage (stage_id, stage_abbr, stage_desc, order_by_num, is_coml_stage, stage_pubkey)
    VALUES (200, 'PS2', 'Pre-Commercial Testing 2nd Year', 2, 'n', '200');
    
    INSERT 
      INTO Lex_Stage (stage_id, stage_abbr, stage_desc, order_by_num, is_coml_stage, stage_pubkey)
    VALUES (300, 'PS3', 'Pre-Commercial Testing 3rd Year', 3, 'n', '300');
    
    INSERT 
      INTO Lex_Stage (stage_id, stage_abbr, stage_desc, order_by_num, is_coml_stage, stage_pubkey)
    VALUES (400, 'PS4', 'Pre-Commercial Testing 4th Year', 4, 'n', '400');
    
    INSERT 
      INTO Lex_Stage (stage_id, stage_abbr, stage_desc, order_by_num, is_coml_stage, stage_pubkey)
    VALUES (1100, 'CM', 'Commercial', 11, 'y', '1100');
    
    INSERT 
      INTO Lex_Stage (stage_id, stage_abbr, stage_desc, order_by_num, is_coml_stage, stage_pubkey)
    VALUES (1200, 'LNCH', 'Launch', 12, 'y', '1200');
    
    INSERT 
      INTO Lex_Stage (stage_id, stage_abbr, stage_desc, order_by_num, is_coml_stage, stage_pubkey)
    VALUES (1300, 'GROW', 'Growth', 13, 'y', '1300');
    
    INSERT 
      INTO Lex_Stage (stage_id, stage_abbr, stage_desc, order_by_num, is_coml_stage, stage_pubkey)
    VALUES (1400, 'MATR', 'Mature', 14, 'y', '1400');
    
    INSERT 
      INTO Lex_Stage (stage_id, stage_abbr, stage_desc, order_by_num, is_coml_stage, stage_pubkey)
    VALUES (1500, 'DECL', 'Decline', 15, 'y', '1500');
    
    Lexicon.Audit_Pkg.Delete_Staging_Record_P;
END;

