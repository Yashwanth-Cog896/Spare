BEGIN
    DECLARE 
		CURSOR curs IS
			SELECT  IQ.midas_product_id AS MidasProductId,
			        SPN.product_name AS PCName,
			        SP.lexicon_id AS LexiconProductId
			  FROM  Staging_Product_Name SPN,
			        Staging_Product SP,
			        (
			            SELECT  SPN.midas_product_id, 
			                    MIN(SPN.midas_product_name_id) AS Id
			              FROM  Staging_Product_Name SPN
			             WHERE  SPN.error = '*Has Commercial'
		            	   AND  SPN.is_pre_commercial_brand = 'y'
		            	GROUP BY SPN.midas_product_id
			        ) IQ
			 WHERE  SPN.midas_product_name_id = IQ.Id
			   AND  IQ.midas_product_id = SP.midas_product_id
			   AND  SP.error IS NULL
			   AND  SP.pre_commercial_name LIKE 'UNKNOWN%'
/*			   AND  SPN.product_name NOT IN
			        (
						SELECT  SP.pre_commercial_name
			        	  FROM  Staging_Product SP
					);
*/
	        updateSQL :=
    	        'UPDATE  Staging_Product' ||
        	    '   SET  pre_commercial_name = :pcn, ' ||
	            '        name_source = ''Midas PC Name'' ' ||
    	        ' WHERE  midas_product_id = :mpid';
		BEGIN
		    FOR rec IN curs LOOP
   		        EXECUTE IMMEDIATE updateSQL
	                USING   rec.PCName,
        	                rec.MidasProductId;
	        END LOOP;
		END;
END;

