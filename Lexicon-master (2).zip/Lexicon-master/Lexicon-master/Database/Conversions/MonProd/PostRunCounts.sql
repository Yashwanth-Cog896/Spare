SELECT  NVL(error, '**** Added ****') AS "Reason Not Added(Midas Prod)", COUNT(*) AS "Count"
  FROM  Staging_Product
 GROUP BY error 
 ORDER BY NVL(error, '**');

SELECT  NVL(warning, '**** No Warning ****') AS "Midas Product Warning", COUNT(*) AS "Count"
  FROM  Staging_Product
 GROUP BY warning
 ORDER BY NVL(warning, '**');

SELECT  NVL(error, '**** Added ****') AS "Reason Not Added(Midas PN)", COUNT(*) AS "Count"
  FROM  Staging_Product_Name
 GROUP BY error
 ORDER BY NVL(error, '**');

SELECT  NVL(warning, '**** No Warning ****') AS "Midas Product Name Warning", COUNT(*) AS "Count"
  FROM  Staging_Product_Name
 GROUP BY warning
 ORDER BY NVL(warning, '**');

SELECT  NVL(error, '**** Added ****') AS "Reason Not Added(Mirage)", COUNT(*) AS "Count"
  FROM  Staging_Seed_Product
 GROUP BY error
 ORDER BY NVL(error, '**');

SELECT  NVL(warning, '**** No Warning ****') AS "Mirage Product Warning", COUNT(*) AS "Count"
  FROM  Staging_Seed_Product
 GROUP BY warning
 ORDER BY NVL(warning, '**');

SELECT  NVL(name_source, 'THIS SHOULD NOT BE NULL') AS "PC Name Source", COUNT(*) AS "Count"
  FROM  Staging_Product 
 WHERE  error IS NULL
 GROUP BY name_source
--UNION
--SELECT  'z-Total' AS "PC Name Source", COUNT(*) AS "Count"
--  FROM  Staging_Product;
ORDER BY NVL(name_source, '**');

SELECT  COUNT(*) AS "Lexicon Products Added"
  FROM  Temp_Product;
  
SELECT  COUNT(*) AS "Lexicon Product Names Added"
  FROM  Temp_Prod_Name;

