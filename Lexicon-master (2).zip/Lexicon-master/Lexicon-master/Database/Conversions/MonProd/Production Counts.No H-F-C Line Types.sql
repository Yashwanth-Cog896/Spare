SELECT  '"' || P.product_id || '"' AS ProductId,
		'"' || PN.product_name_id || '"' AS ProductNameId,
		PN.name AS ProductName,
		'"' || GP.germplasm_id || '"' AS GermplasmId,
		LT.line_type_ref_id AS LineTypeRefId,
		'"' || P.crop_id || '"' AS CropId,
		Cr.name AS CropName,
		'"' || PN.brand_id || '"' AS BrandId,
		Br.name AS BrandName,
		'"' || PN.country_id AS CountryId,
		Cu.name AS CountryName,
		'"' || PN.product_stage_id || '"' AS ProductStageId,
		PS.product_stage_ref_id AS StageRefId,
		PS.name AS StageName,
		P.ref_active AS ProductRefActive,
		PN.ref_active AS ProductNameRefActive,
		PS.ref_active AS StageRefActive,
		PN.is_stage_active AS IsStageActive,
		Cr.ref_active AS CropRefActive,
		Cu.ref_active AS CountryRefActive,
		Br.ref_active AS BrandRefActive
  FROM  Midas.Product_Name PN,
        Midas.Product P,
        Midas.Crop Cr,
        Midas.Brand Br,
        Midas.Country Cu,
        Midas.Product_Stage PS,
        Midas.Company Cm,
        Midas.Product_Germplasm PGP,
        Midas.Germplasm GP,
        Midas.Line_Type LT
 WHERE  PN.ref_active = 'T'
   AND  PN.brand_id = Br.brand_id
   AND  PN.product_id = P.product_id
   AND  PN.country_id = Cu.country_id
   AND  P.ref_active = 'T'
   AND  P.crop_id = Cr.crop_id
   AND  Br.company_id = Cm.company_id
   AND  Cm.name = 'MONSANTO'
   AND  PS.product_stage_id = PN.product_stage_id
   AND  P.product_id = PGP.product_id
   AND  PGP.germplasm_id = GP.germplasm_id
   AND  GP.line_type_id = LT.line_type_id
   AND  GP.line_type_id NOT IN (89260032, 89456640, 89391104)
   AND  P.product_id NOT IN
        (SELECT  DISTINCT PGP.product_id
           FROM  Midas.Product_Germplasm PGP,
                 Midas.Germplasm GP
          WHERE  PGP.germplasm_id = GP.germplasm_id
            AND  GP.line_type_id IN (89260032, 89456640, 89391104)
        )

