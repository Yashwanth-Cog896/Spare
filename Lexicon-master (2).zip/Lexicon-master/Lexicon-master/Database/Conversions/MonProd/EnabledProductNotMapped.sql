SELECT  SSP.seed_product_id AS "Seed Product ID",
        SSP.product_Name AS "Product Name",
        SSP.bayer_code AS "Bayer Code",
        SSP.company_id AS "Company ID",
        SSP.country_code AS "Country Code",
        DECODE(SSP.is_pre_commercial_brand, 'y', 'YES', 'NO') AS "Is Pre Commercial"
  FROM  Staging_Seed_Product SSP
 WHERE  error = '*No Map Product Mirage Entry'
   AND  enabled = 'Y'
ORDER BY SSP.is_pre_commercial_brand DESC,
         SSP.seed_product_id
