SELECT  '"' || GP.germplasm_id || '"' AS GermplasmId,
		LT.line_type_ref_id AS LineTypeRefId,
		GP.line_code AS LineCode,
		'"' || P.product_id || '"'AS ProductId,
		'"' || PN.product_name_id || '"' AS ProductNameId,
		PN.name AS ProductName,
		'"' || PN.product_stage_id || '"' AS ProductStageId,
		PS.product_stage_ref_id AS StageRefId,
		'"' || P.crop_id || '"' AS CropId,
		Cr.name AS CropName,
		'"' || PN.country_id AS CountryId,
		Cu.name AS CountryName,
		'"' || PN.brand_id || '"' AS BrandId,
		Br.name AS BrandName,
		'"' || Br.company_id || '"' AS CompanyId,
		Cm.name AS CompanyName
  FROM  Midas.Germplasm GP,
        Midas.Line_Type LT,
        Midas.Product_Germplasm PGP,
        Midas.Product P,
        Midas.Crop Cr,
		Midas.Product_Name PN,
        Midas.Brand Br,
        Midas.Country Cu,
        Midas.Product_Stage PS,
        Midas.Company Cm
 WHERE  GP.line_code IS NULL 
   AND  GP.line_type_id = LT.line_type_id
   AND  (LT.line_type_ref_id = 'FINISHED' OR LT.line_type_ref_id = 'CODED')
   AND  GP.germplasm_id = PGP.germplasm_id
   AND  PGP.product_id = P.product_id
   AND  P.ref_active = 'T'
   AND  P.crop_id = Cr.crop_id
   AND  P.product_id = PN.product_id
   AND  PN.ref_active = 'T'
   AND  PN.brand_id = Br.brand_id
   AND  PN.country_id = Cu.country_id
   AND  Cr.ref_active = 'T'
   AND  Br.ref_active = 'T'
   AND  Cu.ref_active = 'T'
   AND  Br.company_id = Cm.company_id
   AND  Cm.ref_active = 'T'
--   AND  Cm.name = 'MONSANTO'
   AND  PS.product_stage_id = PN.product_stage_id

