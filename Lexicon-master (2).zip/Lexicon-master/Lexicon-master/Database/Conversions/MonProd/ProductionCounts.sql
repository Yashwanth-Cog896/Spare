--SELECT  PS.product_stage_ref_id, Count(*)
SELECT  '"' || P.product_id || '"'AS ProductId,
		'"' || PN.product_name_id || '"' AS ProductNameId,
		PN.name AS ProductName,
		'"' || PN.product_stage_id || '"' AS ProductStageId,
		PS.product_stage_ref_id AS StageRefId,
		PS.name AS StageName,
		'"' || P.crop_id || '"' AS CropId,
		Cr.name AS CropName,
		'"' || PN.country_id AS CountryId,
		Cu.name AS CountryName,
		'"' || PN.brand_id || '"' AS BrandId,
		Br.name AS BrandName,
		GPGP.NumGermplasm,
		PN.ref_active AS ProductRefActive,
		PS.ref_active AS StageRefActive,
		PN.is_stage_active AS IsStageActive,
		Cr.ref_active AS CropRefActive,
		Cu.ref_active AS CountryRefActive,
		Br.ref_active AS BrandRefActive
  FROM  Midas.Product_Name PN,
        Midas.Product P,
        Midas.Crop Cr,
        Midas.Brand Br,
        Midas.Country Cu,
        Midas.Product_Stage PS,
        Midas.Company Cm,
        (SELECT product_id,
                COUNT(*) AS NumGermplasm
           FROM Midas.Product_Germplasm
          GROUP BY product_id
        ) GPGP
 WHERE  PN.ref_active = 'T'
   AND  PN.brand_id = Br.brand_id
   AND  PN.product_id = P.product_id
   AND  PN.country_id = Cu.country_id
   AND  P.ref_active = 'T'
   AND  P.crop_id = Cr.crop_id
   AND  Cr.ref_active = 'T'
   AND  Br.ref_active = 'T'
   AND  Cu.ref_active = 'T'
   AND  Br.company_id = Cm.company_id
   AND  Cm.ref_active = 'T'
   AND  Cm.name = 'MONSANTO'
   AND  PS.product_stage_id = PN.product_stage_id
   AND  PS.ref_active = 'T'
   AND  GPGP.product_id (+)= P.product_id
--   AND  PS.product_stage_ref_id NOT IN ('CM1', 'CM2', 'CMX')
-- GROUP BY PS.product_stage_ref_id
ORDER BY P.product_id, PS.product_stage_ref_id
