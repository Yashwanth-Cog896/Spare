SELECT  SGP.germplasm_id AS "Germplasm ID",
        SGP.line_code AS "Line Code",
        SGP.line_type_ref_id AS "Line Type",
        SGP.midas_product_id AS "Midas Product ID",
        SP.pre_commercial_name AS "Lex PC Name",
		SP.name_source AS "PC Name Source"
  FROM  Staging_Germplasm SGP,
        Staging_Product SP
WHERE   SGP.line_code IS NOT NULL
  AND   SGP.midas_product_id = SP.midas_product_id
  AND   SP.error = '*Duplicate PC Name'
  AND   SP.crop_name = 'SOYBEANS'
  AND   SP.pre_commercial_name <> 'null'
ORDER BY pre_commercial_name, name_source
