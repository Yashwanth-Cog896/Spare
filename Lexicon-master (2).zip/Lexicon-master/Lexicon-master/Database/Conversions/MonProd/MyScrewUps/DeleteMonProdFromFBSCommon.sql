DELETE
  FROM  Fbs_Common.Product_Xref PX
 WHERE  PX.lexicon_product_pubkey LIKE '%09';

DELETE
  FROM  Fbs_Common.Product_Name_Xref PNX
 WHERE  PNX.lexicon_product_name_pubkey LIKE '%12';

