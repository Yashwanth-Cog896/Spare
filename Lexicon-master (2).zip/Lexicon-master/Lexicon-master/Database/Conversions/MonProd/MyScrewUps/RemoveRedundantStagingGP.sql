INSERT 
  INTO  Staging_Germplasm
        (
            SELECT  IQ.*, ROWNUM
              FROM  (                     
                        SELECT  DISTINCT 
                                SGP.midas_product_id,
                                SGP.germplasm_id,
                                SGP.line_type_ref_id,
                                SGP.line_code,
                                SGP.pedigree,
                                SGP.error,
                                SGP.warning,
                                SGP.other1
                      FROM  Staging_Germplasm SGP
                    ) IQ
        );
        
DELETE
  FROM  Staging_Germplasm
 WHERE  other2 IS NULL;

