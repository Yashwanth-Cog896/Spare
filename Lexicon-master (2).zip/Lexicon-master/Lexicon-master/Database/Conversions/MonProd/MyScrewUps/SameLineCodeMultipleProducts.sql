SELECT  SGP.germplasm_id AS "Germplasm ID",
        SGP.line_code AS "Line Code",
        SGP.line_type_ref_id AS "Line Type",
        SGP.midas_product_id AS "Midas Product ID",
        SP.pre_commercial_name AS "Lex PC Name",
		SP.name_source AS "PC Name Source"
  FROM  Staging_Germplasm SGP,
        Staging_Product SP
 WHERE  SGP.line_code IN (
                SELECT  line_code
                  FROM  
                        (
                            SELECT  SGP.line_code,
                                    SP.midas_product_id
                              FROM  Staging_Germplasm SGP,
                                    Staging_Product SP
                             WHERE  /*SGP.other1 <> 'T'
                               AND  */SGP.line_code IS NOT NULL
                               AND  SGP.midas_product_id = SP.midas_product_id
                               AND  SP.crop_name = 'SOYBEANS'
                               AND  SP.error = '*Duplicate PC Name'
--							   AND  SP.error IS NULL
            --                   AND  (SP.primary_gp_line_type = 'FINISHED' OR SP.primary_gp_line_type = 'CODED')
                            GROUP BY SGP.line_code, 
                                     SP.midas_product_id
                    )
            GROUP BY line_code
            HAVING COUNT(*) > 1
        )
--  AND  SGP.other1 <> 'T'
  AND  SGP.midas_product_id = SP.midas_product_id
ORDER BY SGP.line_code, SGP.midas_product_id
