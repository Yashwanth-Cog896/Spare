SELECT  line_code, COUNT(*)
  FROM  (
SELECT  DISTINCT GP.line_code, PGP.product_id
  FROM  Midas.Germplasm GP,
        Midas.Product_Germplasm PGP,
        Midas.Product P,
        Midas.Product_Name PN,
        Midas.Brand B
 WHERE  GP.crop_id = 65667072
   AND  GP.line_code IS NOT NULL
   AND  GP.is_deleted <> 'T'
   AND  GP.germplasm_id = PGP.germplasm_id
   AND  PGP.product_id = P.product_id
   AND  P.ref_active = 'T'
   AND  PGP.product_id = PN.product_id
   AND  PN.ref_active = 'T'
   AND  PN.brand_id = B.brand_id
   AND  B.company_id = 1313148567552
)
GROUP BY line_code
HAVING COUNT(*) > 1
