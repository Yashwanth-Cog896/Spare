SELECT  'Header Rows' AS "Name", COUNT(*) AS "Count"
  FROM  Audit_Header AH
 WHERE  AH.table_name NOT IN ('PRODUCT_GP_ACTION', 'PRODUCT_STAGE', 'PRE_COML_PRODUCT')

UNION

SELECT  'Detail Rows' AS "Name", COUNT(*) AS "Count"
  FROM  Audit_Detail AD
 WHERE  AD.audit_header_id IN (
            SELECT  AH.audit_header_id
              FROM  Audit_Header AH
             WHERE  AH.table_name NOT IN ('PRODUCT_GP_ACTION', 'PRODUCT_STAGE', 'PRE_COML_PRODUCT')
            );
