SELECT  SP.pubkey AS "Lexicon Pubkey",
        SP.pre_commercial_name AS "PC Name",
        SP.midas_product_id AS "Midas Product ID",
        SP.crop_name AS "Crop Name",
        SP.primary_gp_line_type AS "Line Type"
  FROM  Staging_Product SP,
        (
            SELECT  DISTINCT SPN.midas_product_id
              FROM  Staging_Product_Name SPN
             WHERE  SPN.is_pre_commercial_brand = 'n'
               AND  SPN.error IS NULL
               AND  SPN.lexicon_id IS NOT NULL
 
            UNION

            SELECT  DISTINCT SSP.midas_product_id
              FROM  Staging_Seed_Product SSP
             WHERE  SSP.is_pre_commercial_brand = 'n'
               AND  SSP.error IS NULL
               AND  SSP.lexicon_name_id IS NOT NULL
        ) CP
 WHERE  SP.other1 = 'n'
   AND  SP.error IS NULL
   AND  SP.primary_gp_line_type <> 'SEGPOP'
   AND  SP.midas_product_id = CP.midas_product_id
ORDER BY SP.crop_name, SP.pre_commercial_name
   
   
