SELECT  '(Comp)Products' AS "Name", COUNT(*) AS "Count"
  FROM  Fbs_Common.Product_Xref PX
 WHERE  PX.lexicon_product_pubkey NOT LIKE '%09'

UNION

SELECT  '(Comp)Product Names' AS "Name", COUNT(*) AS "Count"
  FROM  Fbs_Common.Product_Name_Xref PNX
 WHERE  PNX.lexicon_product_name_pubkey NOT LIKE '%12'
 
UNION

SELECT  '(All)Products' AS "Name", COUNT(*) AS "Count"
  FROM  Fbs_Common.Product_Xref PX

UNION

SELECT  '(All)Product Names' AS "Name", COUNT(*) AS "Count"
  FROM  Fbs_Common.Product_Name_Xref PNX
  


 

