SELECT  
        SP.pre_commercial_name AS "Lexicon Pre Commercial Name"
        ,SP.name_source AS "Name Source"
        ,SP.primary_gp_line_code AS "Line Code"
        ,'''' || SP.midas_product_id || '''' AS "Midas Product Id"
        ,'''' || SPN.midas_product_name_id || '''' AS "Midas Product Name Id"
        ,SPN.product_name AS "Midas Pre Commercial Name"
        ,SPN.brand_name AS "Midas Brand Name"
  FROM  Staging_Product SP
        ,(
            SELECT  SPN.*
              FROM  Staging_Product_Name SPN
             WHERE  NVL(SPN.error, '*Has Commercial') = '*Has Commercial'
			   AND  SPN.crop_name = 'SOYBEANS'
			   AND  SPN.is_pre_commercial_brand = 'y'
        ) SPN
 WHERE  SP.pre_commercial_name IN 
 		(
		 	'212802-04', 'DKB18-51', 'A2442', 'AG0803', 'DKB08-51',
		 	'DKB09-53', 'AG2205', 'DKB15-52', 'DKB26-53', 'AG2203',
		 	'AG2107', 'DKB10-52', 'AG1102', 'AG1501', 'AG2106'
		)
   AND  SP.midas_product_id = SPN.midas_product_id /*(+)
   AND  SPN.midas_product_id IS NULL */
ORDER BY SP.pre_commercial_name
      
