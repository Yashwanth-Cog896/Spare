SELECT  PGP.product_gp_action_id
  FROM  Lexicon.Product_GP_Action PGP,
        (
            SELECT  MIN(pgp.product_gp_action_id) id,
                    PGP.product_pubkey, 
                    PGP.gp_key
              FROM  Lexicon.Product_GP_Action PGP
           GROUP BY PGP.product_pubkey, PGP.gp_key  
        ) IQ
 WHERE  PGP.product_gp_action_id = IQ.id (+)
   AND  IQ.id IS NULL
        
          

