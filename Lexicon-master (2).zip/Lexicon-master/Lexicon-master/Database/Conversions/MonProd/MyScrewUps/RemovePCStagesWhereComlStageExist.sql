BEGIN
    Lexicon.Audit_Pkg.initialize_staging_p(22842,'DATA LOAD','Removed PC stages that have coml stages in the same country','');
    DELETE    
      FROM  Lexicon.Product_Stage PS
     WHERE  PS.product_stage_id IN 
            (
                SELECT  PS.product_stage_id
                  FROM  Lexicon.Product_Stage PS,
                        (
                            SELECT  *
                              FROM  Lexicon.Product_Stage PS
                             WHERE  PS.brand_id <> 1061
                        ) CPS
                 WHERE  PS.brand_id = 1061
                   AND  PS.product_id = CPS.product_id
                   AND  PS.country_id = CPS.country_id
            );
    Lexicon.Audit_Pkg.delete_staging_record_p;
END;


