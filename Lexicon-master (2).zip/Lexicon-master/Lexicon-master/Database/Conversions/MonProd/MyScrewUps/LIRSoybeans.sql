SELECT   SP.pre_commercial_name AS "Lexicon Pre Commercial Name"
        ,SP.name_source AS "Name Source"
        ,SP.primary_gp_line_code AS "Line Code"
        ,'''' || SP.midas_product_id || '''' AS "Midas Product Id"
        ,'''' || SPN.midas_product_name_id || '''' AS "Midas Product Name Id"
        ,SPN.product_name AS "Midas Pre Commercial Name"
        ,SPN.error AS "Has Coml Name"
  FROM  Staging_Product SP,
        (
            SELECT  SPN.*
              FROM  Staging_Product_Name SPN
             WHERE  SPN.is_pre_commercial_brand = 'y'
               AND  SPN.crop_name = 'SOYBEANS'
               AND  NVL(SPN.error, '*Has Commercial') = '*Has Commercial'
        ) SPN
 WHERE  SP.crop_name = 'SOYBEANS'
   AND  SP.error IS NULL
   AND  SP.primary_gp_is_inbred = 'y'
   AND  SP.midas_product_id = SPN.midas_product_id
   AND  SP.pre_commercial_name <> SPN.product_name
ORDER BY SP.name_source
		 ,SP.pre_commercial_name
		 ,SPN.midas_product_id
		 ,SPN.error
