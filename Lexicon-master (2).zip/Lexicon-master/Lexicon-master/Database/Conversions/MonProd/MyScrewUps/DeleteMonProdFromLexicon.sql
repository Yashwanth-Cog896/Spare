BEGIN
    DELETE  FROM  Audit_Detail AD
     WHERE  AD.audit_header_id IN (
            SELECT  AH.audit_header_id
              FROM  Audit_Header AH
             WHERE  AH.table_name = 'PRODUCT_GP_ACTION'
            );

    DELETE  FROM  Audit_Header AH
     WHERE  AH.table_name = 'PRODUCT_GP_ACTION';
END;

BEGIN
    Lexicon.Audit_Pkg.Initialize_Staging_P(86196, 'DATA LOAD', 'Initial Data Load', NULL);
    DELETE FROM  Product_GP_Action;
    Lexicon.Audit_Pkg.Delete_Staging_Record_P;
END;

BEGIN
    DELETE  FROM  Audit_Detail AD
     WHERE  AD.audit_header_id IN (
            SELECT  AH.audit_header_id
              FROM  Audit_Header AH
             WHERE  AH.table_name = 'PRODUCT_STAGE'
            );

    DELETE  FROM  Audit_Header AH
     WHERE  AH.table_name = 'PRODUCT_STAGE';
END;

BEGIN
    Lexicon.Audit_Pkg.Initialize_Staging_P(86196, 'DATA LOAD', 'Initial Data Load', NULL);
    DELETE FROM  Product_Stage;
    Lexicon.Audit_Pkg.Delete_Staging_Record_P;
END;

BEGIN
    DELETE  FROM  Audit_Detail AD
     WHERE  AD.audit_header_id IN (
            SELECT  AH.audit_header_id
              FROM  Audit_Header AH
             WHERE  AH.table_name = 'PRE_COML_PRODUCT'
            );

    DELETE  FROM  Audit_Header AH
     WHERE  AH.table_name = 'PRE_COML_PRODUCT';
END;

BEGIN
    Lexicon.Audit_Pkg.Initialize_Staging_P(86196, 'DATA LOAD', 'Initial Data Load', NULL);
    DELETE FROM  Pre_Coml_Product;
    Lexicon.Audit_Pkg.Delete_Staging_Record_P;
END;

