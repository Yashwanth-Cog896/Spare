SELECT  SPN.lexicon_id AS "Lexicon ID(Midas)",
		SP1.pre_commercial_name AS "Pre Coml Name",
        SPN.midas_product_id AS "Midas Product ID", 
        SPN.midas_product_name_id AS "Midas Product Name ID",
        SPN.crop_name AS "Crop Name",
        SPN.brand_name AS "Brand Name",
        SPN.product_name AS "Product Name",
        SPN.country_name AS "Country Name",
        SSP.seed_product_id AS "Seed Product ID",
        SSP.lexicon_name_id AS "Lexicon ID(Mirage)",
        SSP.product_name AS "Mirage Name",
        SSP.midas_product_id AS "Map Prod Mirage-Midas ID",
        SSP.error AS "Reason Not Added (Mirage)",
        SSP.other1 AS "Duplicate Group"
  FROM  Staging_Product_Name SPN,
        Staging_Product SP1,
        Staging_Seed_Product SSP,
        Staging_Brand B,
        Staging_Country C
 WHERE  SPN.lexicon_id IS NOT NULL
   AND  SPN.midas_product_id = SP1.midas_product_id
   AND  SPN.product_name = SSP.product_name
   AND  SPN.lexicon_brand_id = SSP.lexicon_brand_id
   AND  SPN.lexicon_country_id = SSP.lexicon_country_id
   AND  (SSP.lexicon_name_id IS NULL OR SSP.lexicon_name_id <> SPN.lexicon_id)
--   AND  SSP.error IS NULL
   AND  SSP.lexicon_brand_id = B.lexicon_id
   AND  SSP.lexicon_country_id = C.lexicon_id
--   AND  SSP.error like '%(Disabled)%'
ORDER BY SSP.error,
         TO_NUMBER(SSP.other1),
		 SPN.crop_name, 
         SPN.brand_name,
         SPN.product_name,
         SPN.country_name

