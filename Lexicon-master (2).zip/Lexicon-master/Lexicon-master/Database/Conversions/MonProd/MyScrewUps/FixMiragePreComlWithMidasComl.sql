BEGIN
    Lexicon.Audit_Pkg.Initialize_Staging_P(86196, 'DATA LOAD', 'Fix for pc stages exist when same coml stage exists', NULL);
	DELETE 
	  FROM  Lexicon.Product_Stage PS
	 WHERE  PS.product_stage_pubkey IN
	 		(
				SELECT  SSP.lexicon_pubkey        
				  FROM  Staging_Seed_Product SSP,
				        Staging_Product_Name SPN
				 WHERE  SSP.lexicon_name_id IS NOT NULL
				   AND  SSP.midas_product_id IS NOT NULL
				   AND  SSP.midas_product_name_id IS NULL
				   AND  SSP.midas_product_id = SPN.midas_product_id
				   AND  SSP.lexicon_brand_id = SPN.lexicon_brand_id
				   AND  SSP.lexicon_country_id = SPN.lexicon_country_id
			);
    Lexicon.Audit_Pkg.Delete_Staging_Record_P;
END;

BEGIN
	DELETE  
	  FROM  Temp_Prod_Name TPN
	 WHERE  TPN.product_stage_pubkey IN 
	 		(
				SELECT  SSP.lexicon_pubkey
				  FROM  Staging_Seed_Product SSP,
				        Staging_Product_Name SPN
				 WHERE  SSP.lexicon_name_id IS NOT NULL
				   AND  SSP.midas_product_id IS NOT NULL
				   AND  SSP.midas_product_name_id IS NULL
				   AND  SSP.midas_product_id = SPN.midas_product_id
				   AND  SSP.lexicon_brand_id = SPN.lexicon_brand_id
				   AND  SSP.lexicon_country_id = SPN.lexicon_country_id
			);

	UPDATE  Staging_Seed_Product SSP
	   SET  SSP.lexicon_name_id = NULL,
	        SSP.error = '*Midas Has Commercial'
	 WHERE  seed_product_id IN 
	 		(
				SELECT  SSP.seed_product_id
				  FROM  Staging_Seed_Product SSP,
				        Staging_Product_Name SPN
				 WHERE  SSP.lexicon_name_id IS NOT NULL
				   AND  SSP.midas_product_id IS NOT NULL
				   AND  SSP.midas_product_name_id IS NULL
				   AND  SSP.midas_product_id = SPN.midas_product_id
				   AND  SSP.lexicon_brand_id = SPN.lexicon_brand_id
				   AND  SSP.lexicon_country_id = SPN.lexicon_country_id
			);
END;        
