SELECT SP.pubkey AS "Lexicon Product Pubkey",
       SP.pre_commercial_name AS "Lex PC Name",
       SPN.product_name AS "Midas PC Name",
       SP.primary_gp_line_code AS "Midas Line Code",
       SP.midas_product_id AS "Midas Product ID"
  FROM Staging_Product SP,
       Staging_Product_Name SPN
 WHERE SP.name_source = 'Midas Coml Name'
   AND SP.crop_name = 'OSR-CANOLA'
   AND SP.midas_product_id = SPN.midas_product_id
   AND SPN.is_pre_commercial_brand = 'y'
   AND NVL(SPN.error, '*Has Commercial') = '*Has Commercial'
--   AND SP.pre_commercial_name <> SP.primary_gp_line_code

UNION 

SELECT SP.pubkey AS "Lexicon Product Pubkey",
       SP.pre_commercial_name AS "Lex PC Name",
       SPN.product_name AS "Midas PC Name",
       SP.primary_gp_line_code AS "Midas Line Code",
       SP.midas_product_id AS "Midas Product ID"
  FROM Staging_Product SP,
       (SELECT SPN.midas_product_id, SPN.product_name
          FROM Staging_Product_Name SPN
         WHERE SPN.is_pre_commercial_brand = 'y'
           AND NVL(SPN.error, '*Has Commercial') = '*Has Commercial'
       ) SPN 
 WHERE SP.name_source = 'Midas Coml Name'
   AND SP.crop_name = 'OSR-CANOLA'
   AND SP.pre_commercial_name <> SP.primary_gp_line_code
   AND SP.midas_product_id = SPN.midas_product_id (+)
   AND SPN.midas_product_id IS NULL

ORDER BY "Lex PC Name";


