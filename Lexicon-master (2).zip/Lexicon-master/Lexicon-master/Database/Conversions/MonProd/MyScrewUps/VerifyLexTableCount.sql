SELECT  COUNT(*)
  FROM  Product_GP_Action;
  
SELECT  COUNT(*)
  FROM  Audit_Header AH
 WHERE  AH.table_name IN ('Product_GP_Action');

SELECT  COUNT(*)
  FROM  Product_Stage;
  
SELECT  COUNT(*)
  FROM  Audit_Header AH
 WHERE  AH.table_name IN ('Product_Stage');

SELECT  COUNT(*)
  FROM  Pre_Coml_Product;
  
SELECT  COUNT(*)
  FROM  Audit_Header AH
 WHERE  AH.table_name IN ('Pre_Coml_Product');

