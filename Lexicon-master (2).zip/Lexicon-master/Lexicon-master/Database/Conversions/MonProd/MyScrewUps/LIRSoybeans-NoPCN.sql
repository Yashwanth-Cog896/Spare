SELECT   SP.pre_commercial_name AS "Lexicon Pre Commercial Name"
        ,SP.name_source AS "Name Source"
        ,SP.primary_gp_line_code AS "Line Code"
        ,'''' || SP.midas_product_id || '''' AS "Midas Product Id"
  FROM  Staging_Product SP
        ,(
            SELECT  SPN.midas_product_id
              FROM  Staging_Product_Name SPN
             WHERE  SPN.is_pre_commercial_brand = 'y'
               AND  SPN.crop_name = 'SOYBEANS'
        ) SPN
 WHERE  SP.crop_name = 'SOYBEANS'
   AND  SP.error IS NULL
   AND  SP.primary_gp_is_inbred = 'y'
--   AND  SP.pre_commercial_name <> SP.primary_gp_line_code
   AND  SP.midas_product_id = SPN.midas_product_id (+)
   AND  SPN.midas_product_id IS NULL
ORDER BY SP.name_source
		 ,SP.pre_commercial_name

