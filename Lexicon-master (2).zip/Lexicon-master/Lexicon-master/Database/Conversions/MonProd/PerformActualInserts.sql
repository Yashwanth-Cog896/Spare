BEGIN
    Lexicon.Audit_Pkg.Initialize_Staging_P(86196, 'DATA LOAD', 'Initial Data Load', NULL);
    Mpdl_Pkg.Actual_Prod_Inserts_P;
    Mpdl_Pkg.Actual_Name_Inserts_P;
    Mpdl_Pkg.Actual_Prod_Xref_Inserts_P;
    Mpdl_Pkg.Actual_Name_Xref_Inserts_P;
    Mpdl_Pkg.Actual_Prod_GP_Insert_P;
    Lexicon.Audit_Pkg.Delete_Staging_Record_P;
END;

/*    
    INSERT 
      INTO  Lexicon.Pre_Coml_Product
            (
            SELECT  TP.*
              FROM  Temp_Product TP
			  		,
                    (SELECT  DISTINCT TPN.product_id
                       FROM  Temp_Prod_Name TPN,
                             Temp_Prod_Name_Xref TPNX
                      WHERE  TPN.product_stage_pubkey = TPNX.lexicon_product_name_pubkey
                        AND  TPNX.mirage_product_id IS NOT NULL
                    ) IQ
             WHERE  TP.product_id = IQ.product_id
             
            );
            
    INSERT
      INTO  Lexicon.Product_Stage
            (
            SELECT  TPN.*
              FROM  Temp_Prod_Name TPN
			  		,
                    Temp_Prod_Name_Xref TPNX
             WHERE  TPN.product_stage_pubkey = TPNX.lexicon_product_name_pubkey
               AND  TPNX.mirage_product_id IS NOT NULL

            );
    
    INSERT  
      INTO  FBS_Prod_Xref
            (
            SELECT  TPX.*
              FROM  Temp_Prod_Xref TPX
			  		,
                    Lexicon.Pre_Coml_Product PCP
             WHERE  TPX.lexicon_product_pubkey = PCP.product_pubkey

            );
    
    INSERT
      INTO  FBS_Prod_Name_Xref
            (
            SELECT  TPNX.*
              FROM  Temp_Prod_Name_Xref TPNX
			  		,
                    Lexicon.Product_Stage PS
             WHERE  TPNX.lexicon_product_name_pubkey = PS.product_stage_pubkey

            );
*/



            
