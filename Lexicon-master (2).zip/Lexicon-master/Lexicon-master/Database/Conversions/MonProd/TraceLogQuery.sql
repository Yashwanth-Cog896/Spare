select *
from trace_log
where run_number in 
--(5, 6)
	(SELECT  MAX(run_number)
	   FROM  trace_log
	)
order by run_number desc, procedure_number

