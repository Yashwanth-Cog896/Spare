SELECT  '"' || P.product_id || '"' AS ProductId,
		'"' || PN.product_name_id || '"' AS ProductNameId,
		PN.name AS ProductName,
		NVL(CPGP.num_germplasm,0) AS NumGermplasm,
		NVL(CMPM.num_mirage_products,0) AS NumMirageProducts,
		'"' || P.crop_id || '"' AS CropId,
		Cr.name AS CropName,
		'"' || PN.brand_id || '"' AS BrandId,
		Br.name AS BrandName,
		'"' || PN.country_id AS CountryId,
		Cu.name AS CountryName,
		'"' || PN.product_stage_id || '"' AS ProductStageId,
		PS.product_stage_ref_id AS StageRefId,
		PS.name AS StageName,
		P.ref_active AS ProductRefActive,
		PN.ref_active AS ProductNameRefActive,
		PS.ref_active AS StageRefActive,
		PN.is_stage_active AS IsStageActive,
		Cr.ref_active AS CropRefActive,
		Cu.ref_active AS CountryRefActive,
		Br.ref_active AS BrandRefActive
  FROM  Midas.Product_Name PN,
        Midas.Product P,
        Midas.Crop Cr,
        Midas.Brand Br,
        Midas.Country Cu,
        Midas.Product_Stage PS,
        Midas.Company Cm,
        (SELECT  PGP.product_id, 
                 COUNT(*) num_germplasm
           FROM  Midas.Product_Germplasm PGP
         GROUP BY PGP.product_id
        ) CPGP,
        (SELECT  MPM.product_pk,
                 COUNT(*) num_mirage_products
           FROM  YldStg.Map_Product_Mirage MPM
         GROUP BY MPM.product_pk
		)CMPM
 WHERE  PN.ref_active = 'T'
   AND  PN.brand_id = Br.brand_id
   AND  PN.product_id = P.product_id
   AND  PN.country_id = Cu.country_id
   AND  P.ref_active = 'T'
   AND  P.crop_id = Cr.crop_id
   AND  Br.company_id = Cm.company_id
   AND  Cm.name = 'MONSANTO'
   AND  PS.product_stage_id = PN.product_stage_id
   AND  P.product_id = CPGP.product_id (+)
   AND  CPGP.num_germplasm IS NULL
   AND  P.product_id = CMPM.product_pk (+)
ORDER BY P.product_id
