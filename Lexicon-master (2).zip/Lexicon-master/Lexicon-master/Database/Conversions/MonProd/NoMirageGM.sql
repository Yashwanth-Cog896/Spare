SELECT  COUNT(*)
  FROM
(
SELECT  SP.midas_product_id
  FROM  Staging_Product SP,
        Staging_Product_Name SPN,
        Map_Product_Mirage MPM,
--        Midas_Product_Germplasm MPGP,
        Midas_Gen_Mat MGM
 WHERE  SP.lexicon_id IS NOT NULL
   AND  SP.midas_product_id = SPN.midas_product_id
   AND  SPN.lexicon_id IS NOT NULL
   AND  SPN.is_true_commercial_brand = 'y'
   AND  SP.midas_product_id = MPM.product_pk
   AND  MPM.genetic_material_pk = MGM.genetic_material_id
--   AND  SP.midas_product_id = MPGP.product_id
--   AND  MPGP.germplasm_id = MGM.germplasm_id
   AND  UPPER(MGM.source_str) LIKE '%MIRAGE%'
 GROUP BY SP.midas_product_id
);

 
