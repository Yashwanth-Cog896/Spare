UPDATE  Staging_Product
   SET  warning = error,
        error = NULL
 WHERE  midas_product_id IN
        (
            SELECT  DISTINCT SP.midas_product_id
              FROM  Staging_Product SP,
                    Midas_Product MP,
                    Midas_Product_Name MPN
             WHERE  SP.error = '*Duplicate PC Name'
               AND  NVL(SP.pre_commercial_name,'null') <> 'null'
               AND  SP.midas_product_id = MP.product_id
               AND  MP.product_id = MPN.product_id    
               AND  MP.ref_active = 'T'
               AND  MPN.ref_active = 'T' 
        );

UPDATE  Staging_Product_Name
   SET  warning = error,
        error = NULL
 WHERE  error = '*Duplicate PC Name'
   AND  midas_product_id IN 
        (
            SELECT  SP.midas_product_id
              FROM  Staging_Product SP
             WHERE  SP.warning = '*Duplicate PC Name'
        );

UPDATE  Staging_Seed_Product 
   SET  warning = error,
        error = NULL
 WHERE  error = '*Midas Product Has Error'
   AND  midas_product_id IN 
        (
            SELECT  SP.midas_product_id
              FROM  Staging_Product SP
             WHERE  SP.warning = '*Duplicate PC Name'
        );
      



