/*SELECT  '"' || P.product_id || '"'AS ProductId,
		'"' || PN.product_name_id || '"' AS ProductNameId,
		PN.name AS ProductName,
		'"' || PN.product_stage_id || '"' AS ProductStageId,
		PS.product_stage_ref_id AS StageRefId,
		PS.name AS StageName,
		'"' || P.crop_id || '"' AS CropId,
		Cr.name AS CropName,
		'"' || PN.country_id AS CountryId,
		Cu.name AS CountryName,
		'"' || PN.brand_id || '"' AS BrandId,
		Br.name AS BrandName,
		GPGP.NumGermplasm,
		PN.ref_active AS ProductRefActive,
		PS.ref_active AS StageRefActive,
		PN.is_stage_active AS IsStageActive,
		Cr.ref_active AS CropRefActive,
		Cu.ref_active AS CountryRefActive,
		Br.ref_active AS BrandRefActive
*/
SELECT  P.product_id
  FROM  Midas.Product_Name PN,
        Midas.Product P,
        Midas.Crop Cr,
        Midas.Brand Br,
        Midas.Country Cu,
        Midas.Product_Stage PS,
        Midas.Company Cm,
        (SELECT PGP.product_id,
                COUNT(*) AS NumGermplasm
           FROM Midas.Product_Germplasm PGP,
                Midas.Germplasm GP,
                Midas.Line_Type LT
          WHERE GP.germplasm_id = PGP.germplasm_id
            AND LT.line_type_id = GP.line_type_id
            AND LT.line_type_ref_id = 'FINISHED'
          GROUP BY product_id
        ) GPGP,
(
SELECT  PN.name,
        P.crop_id,
        PN.country_id
  FROM  Midas.Product_Name PN,
        Midas.Product P,
        Midas.Crop Cr,
        Midas.Brand Br,
        Midas.Country Cu,
        Midas.Product_Stage PS,
        Midas.Company Cm,
        (SELECT product_id,
                COUNT(*) AS NumGermplasm
           FROM Midas.Product_Germplasm
          GROUP BY product_id
        ) GPGP
 WHERE  PN.ref_active = 'T'
   AND  P.product_id = PN.product_id
   AND  P.ref_active = 'T'
   AND  Cr.crop_id = P.crop_id
   AND  Cr.ref_active = 'T'
   AND  Br.brand_id = PN.brand_id
   AND  Br.ref_active = 'T'
   AND  Cu.country_id = PN.country_id
   AND  Cu.ref_active = 'T'
   AND  PS.product_stage_id = PN.product_stage_id
   AND  PS.ref_active = 'T'
   AND  Cm.company_id = Br.company_id
   AND  Cm.ref_active = 'T'
   AND  Cm.name = 'MONSANTO'
   AND  Br.name = 'MONSANTO'
   AND  GPGP.product_id = P.product_id
)PCName
 WHERE  PN.ref_active = 'T'
   AND  P.product_id = PN.product_id
   AND  P.ref_active = 'T'
   AND  Cr.crop_id = P.crop_id
   AND  Cr.ref_active = 'T'
   AND  Br.brand_id = PN.brand_id
   AND  Br.ref_active = 'T'
   AND  Cu.country_id = PN.country_id
   AND  Cu.ref_active = 'T'
   AND  PS.product_stage_id = PN.product_stage_id
   AND  PS.ref_active = 'T'
   AND  Cm.company_id = Br.company_id
   AND  Cm.ref_active = 'T'
   AND  Cm.name = 'MONSANTO'
   AND  Br.name <> 'MONSANTO'
   AND  GPGP.product_id = P.product_id
   AND  PCName.name = PN.name
GROUP BY P.product_id

