SELECT  COUNT(*)
--        SP.pubkey,
--        SGP.germplasm_id
  FROM  Staging_Product SP,
        Staging_Germplasm SGP
 WHERE  SP.lexicon_id IS NOT NULL
   AND  SP.error IS NULL
   AND  SP.midas_product_id = SGP.midas_product_id
ORDER BY SP.lexicon_id
      
