BEGIN
    Lexicon.Audit_Pkg.Initialize_Staging_P(86196, 'DATA LOAD', 'Dup PC Name Data Load', NULL);
    
    INSERT 
      INTO  Lexicon.Pre_Coml_Product(
                PRODUCT_ID,
                PRODUCT_PUBKEY,
                PRE_COML_NAME,
                CROP_ID,
                LOGICAL_DELETE
            )
            (
                SELECT  TP.product_id,
                        TP.product_pubkey,
                        TP.pre_coml_name,
                        TP.crop_id,
                        'n'
                  FROM  Temp_Product TP
                 WHERE  TP.pre_coml_name like '%-DUP__'
            );
            
    INSERT 
      INTO  Lexicon.Product_Stage(
                PRODUCT_STAGE_ID,
                PRODUCT_STAGE_PUBKEY,
                PRODUCT_ID,
                COUNTRY_ID,
                BRAND_ID,
                STAGE_ID,
                COMMERCIAL_NAME,
                COMMERCIAL_MATURITY,
                IS_ACTIVE,
                COML_TRAIT_STACK_ID,
                LOGICAL_DELETE
            )
            (
                SELECT  TPN.product_stage_id,
                        TPN.product_stage_pubkey,
                        TPN.product_id,
                        TPN.country_id,
                        TPN.brand_id,
                        TPN.stage_id,
                        TPN.commercial_name,
                        TPN.commercial_maturity,
                        TPN.is_active,
                        TPN.coml_trait_stack_id,
                        'n'
                  FROM  Temp_Prod_Name TPN,
                        Temp_Product TP
                 WHERE  TPN.product_id = TP.product_id
                   AND  TP.pre_coml_name like '%-DUP__'
            );
            
    INSERT  
      INTO  FBS_Prod_Xref(
                lexicon_product_pubkey,
                midas_product_id
            )
            (
                SELECT  TPX.lexicon_product_pubkey,
                        TPX.midas_product_id
                  FROM  Temp_Prod_Xref TPX,
                        Temp_Product TP
                 WHERE  TPX.lexicon_product_pubkey = TP.product_pubkey
                   AND  TP.pre_coml_name like '%-DUP__'
            );
            
    INSERT
      INTO  FBS_Prod_Name_Xref(
                lexicon_product_name_pubkey,
                midas_product_name_id,
                mirage_product_id
            )
            (
                SELECT  TPNX.lexicon_product_name_pubkey,
                        TPNX.midas_product_name_id,
                        TPNX.mirage_product_id
                  FROM  Temp_Prod_Name_Xref TPNX,
                        Temp_Prod_Name TPN,
                        Temp_Product TP
                 WHERE  TPNX.lexicon_product_name_pubkey = TPN.product_stage_pubkey
                   AND  TPN.product_id = TP.product_id
                   AND  TP.pre_coml_name like '%-DUP__'
            );
            
    INSERT
      INTO  Lexicon.Product_GP_Action(
                PRODUCT_GP_ACTION_ID,
                PRODUCT_PUBKEY,
                GP_KEY
            )
            (
                SELECT  Lex_Prod_GP_Action_Seq.NEXTVAL,
                        SP.pubkey,
                        SGP.germplasm_id
                  FROM  Staging_Product SP,
                        Staging_Germplasm SGP
                 WHERE  SP.pre_commercial_name like '%-DUP__'
                   AND  SP.midas_product_id = SGP.midas_product_id
            );
                             
    Lexicon.Audit_Pkg.Delete_Staging_Record_P;
END;

