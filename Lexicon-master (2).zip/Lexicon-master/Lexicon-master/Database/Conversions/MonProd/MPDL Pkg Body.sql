CREATE OR REPLACE
PACKAGE BODY Ngscho.Mpdl_Pkg
IS
    traceRunNumber NUMBER := -1;

    /*
        This procedure initializes trace logging and determines the run number
        used to identify a run in the trace log.
    */
    PROCEDURE Start_Trace_P
    IS
    BEGIN
        SELECT  NVL(MAX(TL.run_number), 0) +1
          INTO  traceRunNumber
          FROM  Trace_Log TL;

        DBMS_OUTPUT.put_line('Tracing information started, run number: ' || traceRunNumber);
    END;
    
    /*
        This procedure stops trace logging and ends a given trace number.
    */
    PROCEDURE End_Trace_P
    IS
    BEGIN
        DBMS_OUTPUT.put_line('Tracing information completed, run number: ' || traceRunNumber);
        traceRunNumber := -1;
    END;
    
    /*
        This private procedure output the starting time of the producedure
        identified by the named that is passed into this procedure.
    */
    PROCEDURE Procedure_Start_Trace_P(
        inProcedureName VARCHAR2)
    IS
        procNumber NUMBER;
    BEGIN
        IF traceRunNumber IS NULL OR traceRunNumber = -1 THEN
            DBMS_OUTPUT.put_line(inProcedureName || ' started at ' || TO_CHAR(SYSDATE, 'HH24:MI:SS'));
        ELSE
            SELECT  NVL(MAX(procedure_number),0) + 1
              INTO  procNumber
              FROM  Trace_Log
             WHERE  run_number = traceRunNumber;
             
            INSERT
              INTO  Trace_Log (run_number, procedure_number, procedure_name, start_time)
            VALUES  (traceRunNumber, procNumber, inProcedureName, SYSDATE);
            COMMIT;
        END IF;
    END Procedure_Start_Trace_P;

    /*
        This private procedure output the ending time of the producedure
        identified by the named that is passed into this procedure.
    */
    PROCEDURE Procedure_End_Trace_P(
        inProcedureName VARCHAR2)
    IS
    BEGIN
        IF traceRunNumber IS NULL OR traceRunNumber = -1 THEN
            DBMS_OUTPUT.put_line(inProcedureName || '  ended  at ' || TO_CHAR(SYSDATE, 'HH24:MI:SS'));
        ELSE
            UPDATE  Trace_Log
               SET  end_time =  SYSDATE
             WHERE  run_number = traceRunNumber
               AND  procedure_name = inProcedureName;
            COMMIT;
        END IF;
    END Procedure_End_Trace_P;

    /*
        This procedure removes all records from the staging tables
    */
    PROCEDURE Truncate_Conversion_Tables_P
    IS
    BEGIN
        Procedure_Start_Trace_P('Truncate_Conversion_Tables_P');

        DELETE FROM Staging_Crop;
        DELETE FROM Staging_Bayer_Code;
        DELETE FROM Staging_Brand;
        DELETE FROM Staging_Country;
        DELETE FROM Staging_Stage;
        DELETE FROM Staging_Product_Name;
        DELETE FROM Staging_Product;
        DELETE FROM Staging_Germplasm;
        DELETE FROM Staging_Seed_Product;
        DELETE FROM Temp_Prod_Name;
        DELETE FROM Temp_Product;
        DELETE FROM Temp_Prod_Name_Xref;
        DELETE FROM Temp_Prod_Xref;

        COMMIT;
        Procedure_End_Trace_P('Truncate_Conversion_Tables_P');
    END Truncate_Conversion_Tables_P;

    /*
        This procedure loads crop information from the various systems into
        the crop staging tables.  These tables act as cross reference for
        converted crop ids from one system to another, but have the advantage
        of being located in a single instance.
    */
    PROCEDURE Load_Crop_Staging_P
    IS
        TYPE CropArray IS
            TABLE OF Staging_Crop%ROWTYPE
            INDEX BY BINARY_INTEGER;

        crops CropArray;
    BEGIN
        Procedure_Start_Trace_P('Load_Crop_Staging_P');

        SELECT  LC.crop_id,
                MC.crop_id,
                UPPER(MC.name),
                NULL AS Other
        BULK COLLECT INTO crops
          FROM  Midas_Crop MC,
                Lex_Crop LC
         WHERE  LC.crop_name (+)= UPPER(MC.name)
           AND  MC.ref_active = 'T';
          
        FORALL idx IN crops.FIRST .. crops.LAST
            INSERT INTO Staging_Crop
            VALUES crops(idx);

        COMMIT;
        Procedure_End_Trace_P('Load_Crop_Staging_P');
    END Load_Crop_Staging_P;

    /*
        This procedure loads bayer code information from the various systems into
        the bayer code staging tables.  These tables act as cross reference for
        converted crop ids from one system to another, but have the advantage
        of being located in a single instance.
    */
    PROCEDURE Load_Bayer_Code_Staging_P
    IS
        TYPE BayerCodeArray IS
            TABLE OF Staging_Bayer_Code%ROWTYPE
            INDEX BY BINARY_INTEGER;

        bayerCodes BayerCodeArray;
    BEGIN
        Procedure_Start_Trace_P('Load_Bayer_Code_Staging_P');

        SELECT  DISTINCT
                SC.lexicon_crop_id,
                MC.midas_crop_id,
                TRIM(MC.mirage_bayer_code),
                MC.is_midas_product_crop,
                NULL AS Other
        BULK COLLECT INTO bayerCodes
          FROM  Mirage_Crop MC,
                Staging_Crop SC
         WHERE  MC.midas_crop_id = SC.midas_crop_id;

        FORALL idx IN bayerCodes.FIRST .. bayerCodes.LAST
            INSERT INTO Staging_Bayer_Code
            VALUES bayerCodes(idx);

        COMMIT;
        Procedure_End_Trace_P('Load_Bayer_Code_Staging_P');
    END Load_Bayer_Code_Staging_P;
    
    /*
        This procedure loads brand information from the various systems into
        the brand staging tables.  These tables act as cross reference for
        converted brand ids from one system to another, but have the advantage
        of being located in a single instance.
    */
    PROCEDURE Load_Brand_Staging_P
    IS
        TYPE BrandArray IS
            TABLE OF Staging_Brand%ROWTYPE
            INDEX BY BINARY_INTEGER;

        brands BrandArray;
    BEGIN
        Procedure_Start_Trace_P('Load_Brand_Staging_P');

        SELECT  LB.brand_id,
                MB.brand_id,
                FBX.mirage_company_id,
                MB.name,
                FBX.lexicon_brand_pubkey,
                DECODE (MB.name, 'MONSANTO', 'y', 'n'),
                DECODE (MB.name, 'MONSANTO', 'n', 'HOLDENS''S', 'n', 'CORN STATES', 'n', 'CORN STATES INTERNATIONAL', 'n', 'y'),
                NULL AS Other
        BULK COLLECT INTO brands
          FROM  Midas_Brand MB,
                Midas_Company MC,
                FBS_Brand FBX,
                Lex_Brand LB
         WHERE  MB.ref_active = 'T'
           AND  MB.company_id = MC.company_id
           AND  MC.ref_active = 'T'
           AND  UPPER(MC.name) = 'MONSANTO'
           AND  MB.brand_id = FBX.midas_brand_id (+)
           AND  FBX.lexicon_brand_pubkey = LB.brand_pubkey (+);
          
        FORALL idx IN brands.FIRST .. brands.LAST
            INSERT INTO Staging_Brand
            VALUES brands(idx);

        COMMIT;
        Procedure_End_Trace_P('Load_Brand_Staging_P');
    END Load_Brand_Staging_P;

    /*
        This procedure loads country information from the various systems into
        the country staging tables.  These tables act as cross reference for
        converted country ids from one system to another, but have the advantage
        of being located in a single instance.
    */
    PROCEDURE Load_Country_Staging_P
    IS
        TYPE CountryArray IS
            TABLE OF Staging_Country%ROWTYPE
            INDEX BY BINARY_INTEGER;

        countries CountryArray;
    BEGIN
        Procedure_Start_Trace_P('Load_Country_Staging_P');

        SELECT  LC.country_id,
                MC.country_id,
                FCX.mirage_country_code,
                MC.name,
                FCX.lexicon_country_pubkey,
                NULL AS Other
        BULK COLLECT INTO countries
          FROM  Midas_Country MC,
                FBS_Country FCX,
                Lex_Country LC
         WHERE  MC.ref_active = 'T'
           AND  MC.country_id = FCX.midas_country_id (+)
           AND  FCX.lexicon_country_pubkey = LC.country_pubkey (+);

        FORALL idx IN countries.FIRST .. countries.LAST
            INSERT INTO Staging_Country
            VALUES countries(idx);

        COMMIT;
        Procedure_End_Trace_P('Load_Country_Staging_P');
    END Load_Country_Staging_P;
    
    /*
        This private procedure creates the mapping from Midas Ref ID to
        Lexicon stage id.  This mapping helps in making determination on
        whether a product stage(name) record in Lexicon will be active based
        on the Midas stage.
    */
    PROCEDURE Load_Stage_Staging_Row_P(
        InMidasRefId Staging_Stage.midas_ref_id%TYPE,
        InLexPCStageName Lex_Stage.stage_abbr%TYPE,
        InLexComlStageName Lex_Stage.stage_abbr%TYPE,
        InIsActiveInLex Staging_Stage.lex_stage_active%TYPE)
    IS
        lexPCStageId Staging_Stage.lex_pc_stage_id%TYPE;
        lexComlStageId Staging_Stage.lex_coml_stage_id%TYPE;
    BEGIN
        SELECT  LS.stage_id
          INTO  lexPCStageId
          FROM  Lex_Stage LS
         WHERE  LS.stage_abbr = InLexPCStageName;

        SELECT  LS.stage_id
          INTO  lexComlStageId
          FROM  Lex_Stage LS
         WHERE  LS.stage_abbr = InLexComlStageName;

        INSERT  INTO  Staging_Stage
        VALUES  (NULL, InMidasRefId, lexPCStageId, lexComlStageId, InIsActiveInLex);
    END;
    
    /*
        This procedure loads stage information from the various systems into
        the stage staging tables.  These tables act as cross reference for
        converted stage ids from one system to another, but have the advantage
        of being located in a single instance.  
    */
    PROCEDURE Load_Stage_Staging_P
    IS
/*
        CURSOR curs IS
            SELECT  MS.product_stage_ref_id AS StageRefId,
                    MS.product_stage_id AS MidasStageId
              FROM  Midas_Product_Stage MS;
              
        updateSQL VARCHAR2(400);
*/
    BEGIN
        Procedure_Start_Trace_P('Load_Stage_Staging_P');

        Load_Stage_Staging_Row_P('CM1',  'PS1', 'CM', 'y');
        Load_Stage_Staging_Row_P('CM2',  'PS1', 'CM', 'y');
        Load_Stage_Staging_Row_P('CMX',  'PS1', 'CM', 'n');
        Load_Stage_Staging_Row_P('CP1',  'PS1', 'CM', 'y');
        Load_Stage_Staging_Row_P('CP2',  'PS1', 'CM', 'y');
        Load_Stage_Staging_Row_P('CPX',  'PS1', 'CM', 'n');
        Load_Stage_Staging_Row_P('DEL',  'PS1', 'CM', 'n');
        Load_Stage_Staging_Row_P('OLD1', 'PS1', 'CM', 'n');
        Load_Stage_Staging_Row_P('OLD2', 'PS1', 'CM', 'y');
        Load_Stage_Staging_Row_P('OLD3', 'PS1', 'CM', 'y');
        Load_Stage_Staging_Row_P('OLD4', 'PS1', 'CM', 'y');
        Load_Stage_Staging_Row_P('OLD5', 'PS1', 'CM', 'y');
        Load_Stage_Staging_Row_P('OLD6', 'PS1', 'CM', 'y');
        Load_Stage_Staging_Row_P('OLD7', 'PS1', 'CM', 'y');
        Load_Stage_Staging_Row_P('PM1X', 'PS1', 'CM', 'n');
        Load_Stage_Staging_Row_P('PM2X', 'PS2', 'CM', 'n');
        Load_Stage_Staging_Row_P('PM3X', 'PS3', 'CM', 'n');
        Load_Stage_Staging_Row_P('PMC1', 'PS1', 'CM', 'y');
        Load_Stage_Staging_Row_P('PMC2', 'PS2', 'CM', 'y');
        Load_Stage_Staging_Row_P('PMC3', 'PS3', 'CM', 'y');
        Load_Stage_Staging_Row_P('PMCX', 'PS1', 'CM', 'n');
        Load_Stage_Staging_Row_P('PCM4', 'PS4', 'CM', 'y');
        Load_Stage_Staging_Row_P('P',    'PS1', 'CM', 'y');
        Load_Stage_Staging_Row_P('PI',   'PS1', 'CM', 'y');
        Load_Stage_Staging_Row_P('PX',   'PS1', 'CM', 'n');
        Load_Stage_Staging_Row_P('R1',   'PS1', 'CM', 'y');
        Load_Stage_Staging_Row_P('R2',   'PS1', 'CM', 'y');
        Load_Stage_Staging_Row_P('RES',  'PS1', 'CM', 'y');
        Load_Stage_Staging_Row_P('CB',   'PS1', 'CM', 'y');
/*
        updateSQL :=
            'UPDATE  Lex_Stage ' ||
            '   SET  midas_stage_id = :mid ' ||
            ' WHERE  midas_ref_id = :ref';
            
        FOR rec IN curs LOOP
            EXECUTE IMMEDIATE updateSQL
                USING   rec.MidasStageId,
                        rec.StageRefId;
        END LOOP;
*/
        COMMIT;
        Procedure_End_Trace_P('Load_Stage_Staging_P');
    END Load_Stage_Staging_P;
    
    /*
        This procedure loads all of the Monsanto company product name entries
        from Midas into the product name staging table.  This table is used as
        the basis for many of the following data conversion methods.  The
        validity and any Lexicon specific information of each entry is
        determined in later methods.
    */
    PROCEDURE Load_Names_Staging_P
    IS
        TYPE ProductNameArray IS
            TABLE OF Staging_Product_Name%ROWTYPE
            INDEX BY BINARY_INTEGER;

        names ProductNameArray;
    BEGIN
        Procedure_Start_Trace_P('Load_Names_Staging_P');

        SELECT  NULL AS LexiconId,
                NULL AS Pubkey,
                P.product_id MidasProductId,
                P.ref_active ProductRefActive,
                PN.product_name_id AS MidasProductNameId,
		        PN.name AS ProductName,
                P.crop_id AS MidasCropId,
                UPPER(Cr.name) AS CropName,
                Cr.ref_active AS CropRefActive,
                NULL AS LexiconBrandId,
                PN.brand_id AS MidasBrandId,
                UPPER(Br.name) AS BrandName,
                Br.ref_active AS BrandRefActive,
                NULL AS PreComlBrand,
                NULL AS TrueComlBrand,
                Cm.ref_active AS CompanyRefActive,
                NULL AS LexiconCountryId,
                PN.country_id AS MidasCountryId,
                UPPER(Cu.name) AS CountryName,
                Cu.ref_active AS CountryRefActive,
                NULL AS LexiconStageId,
                'y' AS LexiconStageActiveFlag,
		        PN.product_stage_id AS MidasStageId,
		        PS.product_stage_ref_id AS MidasStageRefId,
		        PS.ref_active AS StageRefActive,
                PN.is_stage_active AS IsStageActive,
                NULL AS ComlName,
                NULL AS ComlEquivId,
                NULL AS Error,
                NULL AS Warning,
                NULL AS Other1,
                NULL AS Other2,
                NULL AS Other3
        BULK COLLECT INTO names
          FROM  Midas_Product_Name PN,
                Midas_Product P,
                Midas_Crop Cr,
                Midas_Brand Br,
                Midas_Country Cu,
                Midas_Product_Stage PS,
                Midas_Company Cm
         WHERE  PN.ref_active = 'T'
           AND  PN.brand_id = Br.brand_id
           AND  PN.product_id = P.product_id
           AND  PN.country_id = Cu.country_id
           AND  PN.product_stage_id = PS.product_stage_id
           AND  P.crop_id = Cr.crop_id
           AND  Br.company_id = Cm.company_id
           AND  Cm.name = 'MONSANTO';

        FORALL idx IN names.FIRST .. names.LAST
            INSERT INTO Staging_Product_Name
            VALUES names(idx);

        COMMIT;
        Procedure_End_Trace_P('Load_Names_Staging_P');
    END Load_Names_Staging_P;
    
    /*
        This procedure loads all of the distinct products found in the product
        name staging table.  The validity and any Lexicon specific information
        of each entry is determined in later methods.
    */
    PROCEDURE Load_Product_Staging_P
    IS
        TYPE ProductArray IS
            TABLE OF Staging_Product%ROWTYPE
            INDEX BY BINARY_INTEGER;

        products ProductArray;
    BEGIN
        Procedure_Start_Trace_P('Load_Product_Staging_P');

        SELECT  DISTINCT
                NULL AS LexiconId,
                NULL AS Pubkey,
                NULL AS PreCommercialName,
                NULL AS NameSource,
                midas_product_id AS MidasProductId,
                product_ref_active AS ProductRefActive,
                NULL AS LexiconCropId,
                midas_crop_id AS MidasCropId,
                crop_name AS CropName,
                crop_ref_active AS CropRefActive,
                NULL AS PrimaryGPLineType,
                NULL AS PrimaryGPLineCode,
                NULL AS PrimaryGPIsInbred,
                NULL AS Error,
                NULL AS Warning,
                NULL AS Other1,
                NULL AS Other2,
                NULL AS Other3
        BULK COLLECT INTO products
          FROM  Staging_Product_Name;

        FORALL idx IN products.FIRST .. products.LAST
            INSERT INTO Staging_Product
            VALUES products(idx);

        COMMIT;
        Procedure_End_Trace_P('Load_Product_Staging_P');
    END Load_Product_Staging_P;

    /*
        Loads all germplasm associated with all Monsanto products found in
        Midas into the germplasm staging table.  The validity of each entry is
        determined in later methods.
    */
    PROCEDURE Load_Germplasm_Staging_P
    IS
        TYPE GermplasmArray IS
            TABLE OF Staging_Germplasm%ROWTYPE
            INDEX BY BINARY_INTEGER;

        germplasms GermplasmArray;
    BEGIN
        Procedure_Start_Trace_P('Load_Germplasm_Staging_P');

        SELECT  P.product_id AS MidasProductId,
                GP.germplasm_id AS MidasGermplasmId,
                LT.line_type_ref_id AS LineType,
                GP.line_code AS LineCode,
                GP.pedigree_name AS Pedigree,
                NULL AS Error,
                NULL AS Warning,
                GP.is_finished_or_finished_child AS Other1,
                NULL AS Other2
        BULK COLLECT INTO germplasms
          FROM  Midas_Product_Name PN,
                Midas_Product P,
                Midas_Crop Cr,
                Midas_Brand Br,
                Midas_Country Cu,
                Midas_Product_Stage PS,
                Midas_Company Cm,
                Midas_Product_Germplasm PGP,
                Midas_Germplasm GP,
                Midas_Line_Type LT
         WHERE  PN.ref_active = 'T'
           AND  PN.brand_id = Br.brand_id
           AND  PN.product_id = P.product_id
           AND  PN.country_id = Cu.country_id
           AND  PN.product_stage_id = PS.product_stage_id
           AND  Br.ref_active = 'T'
           AND  P.ref_active = 'T'
           AND  P.crop_id = Cr.crop_id
           AND  Cr.ref_active = 'T'
           AND  Cu.ref_active = 'T'
           AND  Br.company_id = Cm.company_id
           AND  Cm.ref_active = 'T'
           AND  Cm.name = 'MONSANTO'
           AND  P.product_id = PGP.product_id
           AND  PGP.germplasm_id = GP.germplasm_id
           AND  GP.line_type_id = LT.line_type_id;

        FORALL idx IN germplasms.FIRST .. germplasms.LAST
            INSERT INTO Staging_Germplasm
            VALUES germplasms(idx);

        COMMIT;
        Procedure_End_Trace_P('Load_Germplasm_Staging_P');
    END Load_Germplasm_Staging_P;
    
    /*
        This procedure loads all of the Monsanto company seed product entries
        from Mirage into the seed product name staging table.  This table is used 
        as the basis for many of the following data conversion methods.  The
        validity and any Lexicon specific information of each entry is
        determined in later methods.
    */
    PROCEDURE Load_Seed_Products_Staging_P
    IS
        TYPE SeedProductArray IS
            TABLE OF Staging_Seed_Product%ROWTYPE
            INDEX BY BINARY_INTEGER;

        seedProducts SeedProductArray;
    BEGIN
        Procedure_Start_Trace_P('Load_Seed_Products_Staging_P');
        
        SELECT  MSP.product_id AS SeedProductId,
                NULL AS MidasProductId,
                NULL AS MidasProductNameId,
                NULL AS LexiconNameId,
                NULL AS LexiconPubkey,
                MSP.product_name AS ProductName,
                TRIM(MSP.crop_bayer_code) AS BayerCode,
                NULL AS LexiconCropId,
                MSP.company_id AS MirageCompanyId,
                SB.lexicon_id AS LexiconBrandId,
                SB.is_pre_commercial AS IsPreCommercialBrand,
                MSP.country_code AS MirageCountryCode,
                NULL AS LexiconCountryId,
                MSP.enabled AS EnabledFlag,
                MSP.equivalent_product_id AS EquivalentProductId,
                NULL AS ComlEquivalentId,
                NULL AS Error,
                NULL AS Warning,
                NULL AS Other1,
                NULL AS Other2,
                NULL AS Other3
        BULK COLLECT INTO seedProducts
          FROM  Mirage_Seed_Product MSP,
                Staging_Brand SB
         WHERE  MSP.company_id = SB.mirage_company_id;
         
        FORALL idx IN seedProducts.FIRST .. seedProducts.LAST
            INSERT INTO Staging_Seed_Product
            VALUES seedProducts(idx);

        COMMIT;
        Procedure_End_Trace_P('Load_Seed_Products_Staging_P');
    END Load_Seed_Products_Staging_P;
    
    /*
        This procedure load the maturity and attributes from yield mart into
        the product name staging rows.
    */
    PROCEDURE Load_Product_Attributes_P
    IS
        CURSOR curs IS
            SELECT  YPA.product_name_pk AS ProductNameId,
                    YPA.relative_maturity AS Maturity,
                    YA.name AS StackName
              FROM  YM_Prod_Attr YPA,
                    YM_Attribute YA
             WHERE  YPA.attribute_pk = YA.attribute_pk (+);

        stackName YM_Attribute.name%TYPE;
        updateSQL VARCHAR2(400);
    BEGIN
        Procedure_Start_Trace_P('Load_Product_Attributes_P');

        updateSQL :=
            'UPDATE  Staging_Product_Name ' ||
            '   SET  other1 = :mat, ' ||
            '        other2 = :sn ' ||
            ' WHERE  midas_product_name_id = :pnid';

        FOR rec IN curs LOOP
            IF rec.StackName IS NULL OR
               rec.StackName = 'NON-TRANSGENIC' OR
               rec.StackName = 'CONV' OR
               rec.StackName = 'UNK'
            THEN
                stackName := NULL;
            ELSIF rec.StackName = 'RR FLEX' THEN
                stackName := 'RRF';
            ELSE
                stackName := rec.StackName;
            END IF;
            
            EXECUTE IMMEDIATE updateSQL
                USING  rec.Maturity,
                       stackName,
                       rec.ProductNameId;
        END LOOP;

        COMMIT;
        Procedure_End_Trace_P('Load_Product_Attributes_P');
    END Load_Product_Attributes_P;

    /*
        Validates the germplasm entries in the germplasm staging table.
        1) Validates that the germplasm associated with a given product are
           consistent (i.e. all Hybrid or all Inbred line types)
        2) Determines the line code of the finished germplasm with lowest id or
           if no finished germplasm are available, the line code of the
           germplasm of lowest coded germplasm.
    */
    PROCEDURE Validate_Germplasm_P
    IS
        TYPE ProductRecord IS RECORD
        (
            productId Midas_Product.product_id%TYPE,
            primaryLineType Midas_Line_Type.line_type_ref_id%TYPE,
            primaryLineCode Midas_Germplasm.line_code%TYPE,
            isInbred Staging_Product.primary_gp_is_inbred%TYPE := 'n',
            hasOneFinished Midas_Germplasm.is_finished_or_finished_child%TYPE := 'n',
            isInvalid BOOLEAN := FALSE
        );

        TYPE ProductArray IS
            TABLE OF ProductRecord
            INDEX BY BINARY_INTEGER;

        CURSOR curs IS
            SELECT  GP.midas_product_id AS ProductId,
                    GP.line_type_ref_id AS LineType,
                    GP.line_code AS LineCode,
                    GP.other1 AS IsFinished
              FROM  Staging_Germplasm GP
             ORDER BY GP.midas_product_id;

        products ProductArray;
        numProducts NUMBER := 0;
        updateSQL VARCHAR2(400);
        error VARCHAR2(4000);
    BEGIN
        Procedure_Start_Trace_P('Validate_Germplasm_P');

        FOR rec in curs LOOP
            IF numProducts = 0 OR products(numProducts).productId <> rec.ProductId THEN
                numProducts := numProducts +1;
                products(numProducts).productId := rec.ProductId;
            END IF;

            IF products(numProducts).isInvalid = FALSE THEN
            
                IF products(numProducts).hasOneFinished = 'n' AND rec.IsFinished = 'T' THEN
                   products(numProducts).hasOneFinished := 'y';
                END IF;

                IF rec.LineType = 'HYBRID' THEN
                    IF products(numProducts).primaryLineType IS NULL OR
                       (products(numProducts).primaryLineType <> 'FINISHED' AND
                        products(numProducts).primaryLineType <> 'CODED')
                    THEN
                       products(numProducts).primaryLineType := rec.LineType;
                    ELSE
                        products(numProducts).isInvalid := TRUE;
                    END IF;

                ELSIF rec.LineType = 'CODED' THEN
                    IF products(numProducts).primaryLineType IS NULL OR
                       (products(numProducts).primaryLineType <> 'FINISHED' AND
                        products(numProducts).primaryLineType <> 'HYBRID')
                    THEN
                        products(numProducts).primaryLineType := 'CODED';
                        products(numProducts).isInbred := 'y';
                    ELSIF products(numProducts).primaryLineType = 'HYBRID'
                    THEN
                        products(numProducts).isInvalid := TRUE;
                    END IF;

                    IF products(numProducts).primaryLineType = 'CODED' AND
                       products(numProducts).primaryLineCode IS NULL
                    THEN
                        products(numProducts).primaryLineCode := rec.LineCode;
                    END IF;

                ELSIF rec.LineType = 'FINISHED' THEN
                    IF products(numProducts).primaryLineType IS NULL OR
                       products(numProducts).primaryLineType <> 'HYBRID'
                    THEN
                        products(numProducts).primaryLineType := 'FINISHED';
                        products(numProducts).isInbred := 'y';
                    END IF;

                    IF products(numProducts).primaryLineType = 'HYBRID'
                    THEN
                        products(numProducts).isInvalid := TRUE;
                    ELSIF products(numProducts).primaryLineType = 'FINISHED' AND
                          products(numProducts).primaryLineCode IS NULL
                    THEN
                        products(numProducts).primaryLineCode := rec.LineCode;
                    END IF;

                ELSE
                    products(numProducts).primaryLineType := rec.LineType;
                END IF;
            END IF;
        END LOOP;

        updateSQL :=
            'UPDATE  Staging_Product ' ||
            '  SET  primary_gp_line_type = :lt, ' ||
            '       primary_gp_line_code = :lc, ' ||
            '       primary_gp_is_inbred = :if, ' ||
            '       other1 = :isfin, ' ||
            '       warning = warning || :e ' ||
            'WHERE  midas_product_id = :mpid';

        FOR idx IN products.FIRST .. products.LAST LOOP
            IF products(idx).isInvalid = TRUE THEN
                error := INCONSISTENT_GP_ERROR;
                products(idx).primaryLineType := NULL;
                products(idx).primaryLineCode := NULL;
            ELSIF products(idx).primaryLineType IS NULL THEN
                error := NON_ASSIGNABLE_GP_ERROR;
            ELSE
                error := NULL;
            END IF;

            EXECUTE IMMEDIATE updateSQL
                USING  products(idx).primaryLineType,
                       products(idx).primaryLineCode,
                       products(idx).isInbred,
                       products(idx).hasOneFinished,
                       error,
                       products(idx).productId;
        END LOOP;

        COMMIT;
        Procedure_End_Trace_P('Validate_Germplasm_P');
    END Validate_Germplasm_P;

    /*
        Validates the product entries in the product staging table.
        1) Validates that the product is active
        2) Validates that the crop is active
        3) Validates that the crop is a valid Lexicon crop
        4) Validates that there is at least 1 germplasm associated with it
        5) Determines the lexicon crop id of all valid entries
    */
    PROCEDURE Validate_Product_P
    IS
        CURSOR curs IS
            SELECT  SP.midas_product_id AS MidasProductId,
                    SP.product_ref_active AS ProductRefActive,
                    SP.crop_ref_active AS CropRefActive,
                    SC.lexicon_crop_id AS LexiconCropId,
                    SG.midas_product_id AS gpProductId,
                    SP.error AS ProductError
              FROM  Staging_Product SP,
                    Staging_Crop SC,
                   (SELECT  DISTINCT midas_product_id
                      FROM  Staging_Germplasm SG
                   )SG
             WHERE  SP.midas_product_id = SG.midas_product_id (+)
               AND  SP.midas_crop_id = SC.midas_crop_id (+);

        updateSQL VARCHAR2(400);
        error VARCHAR2(4000);
    BEGIN
        Procedure_Start_Trace_P('Validate_Product_P');

        updateSQL :=
            'UPDATE  Staging_Product' ||
            '   SET  error = :e, ' ||
            '        lexicon_crop_id = :c ' ||
            ' WHERE  midas_product_id = :p';
            
        FOR rec IN curs LOOP
            error := rec.ProductError;
            IF rec.ProductRefActive <> 'T' THEN
                error := NVL(error, '') || INACTIVE_PRODUCT_ERROR;
            END IF;

            IF rec.LexiconCropId IS NULL THEN
                error := NVL(error, '') || NOT_LEXICON_CROP_ERROR;
            ELSIF rec.CropRefActive <> 'T' THEN
                error := NVL(error, '') || INACTIVE_CROP_ERROR;
            END IF;
            
            IF rec.gpProductId IS NULL THEN
                error := NVL(error, '') || NO_GERMPLASM_ERROR;
            END IF;
            
            EXECUTE IMMEDIATE updateSQL
                USING   error,
                        rec.LexiconCropId,
                        rec.MidasProductId;
        END LOOP;

        COMMIT;
        Procedure_End_Trace_P('Validate_Product_P');
    END Validate_Product_P;
    
    /*
        Validates the product name entries in the product name staging table.
        1) Validates that the brand is active
        2) Validates that the country is active
        3) Validates that the brand is a valid Lexicon brand
        4) Validates that the country is a valid Lexicon country
        5) Translates the stage into a valid Lexicon stage
        6) Determines the Lexicon brand id
        7) Determines the Lexicon country id
        8) Determines the Lexicon stage id
        9) Determines whether the entry is active in Lexicon
    */
    PROCEDURE Validate_Product_Name_P
    IS
        CURSOR curs IS
            SELECT  SPN.midas_product_name_id AS MidasProductNameId,
                    SPN.brand_ref_active AS BrandRefActive,
                    SB.lexicon_id AS LexiconBrandId,
                    SB.is_pre_commercial AS IsPreComlBrand,
                    SB.is_true_commercial AS IsTrueComlBrand,
                    SPN.country_ref_active AS CountryRefActive,
                    SC.lexicon_id AS LexiconCountryId,
                    SS.lex_pc_stage_id AS LexiconPCStageId,
                    SS.lex_coml_stage_id AS LexiconComlStageId,
                    SS.lex_stage_active AS LexiconStageActive,
                    SPN.error AS Error,
                    SP.error AS ProductError
              FROM  Staging_Product_Name SPN,
                    Staging_Brand SB,
                    Staging_Country SC,
                    Staging_Product SP,
                    Staging_Stage SS
             WHERE  SPN.midas_product_id = SP.midas_product_id
               AND  SPN.midas_country_id = SC.midas_id (+)
               AND  SPN.midas_brand_id = SB.midas_id (+)
               AND  SPN.midas_stage_ref_id = SS.midas_ref_id (+);

        updateSQL VARCHAR2(400);
        error VARCHAR2(4000);
        stageID Lex_Stage.stage_id%TYPE;
    BEGIN
        Procedure_Start_Trace_P('Validate_Product_Name_P');

        updateSQL :=
            'UPDATE  Staging_Product_Name' ||
            '   SET  error = :e, ' ||
            '        lexicon_brand_id = :b, ' ||
            '        is_pre_commercial_brand = :ispc, ' ||
            '        is_true_commercial_brand = :istc, ' ||
            '        lexicon_country_id = :c, ' ||
            '        lexicon_stage_id = :lsid, ' ||
            '        lexicon_stage_active_flag = :lsaf ' ||
            ' WHERE  midas_product_name_id = :p';

        FOR rec IN curs LOOP
            error := NULL;
            IF rec.ProductError IS NOT NULL THEN
                error := PRODUCT_HAS_ERROR;
            END IF;
            
            IF rec.LexiconBrandId IS NULL THEN
                error := NVL(error, '') || NOT_LEXICON_BRAND_ERROR;
            ELSIF rec.BrandRefActive <> 'T' THEN
                error := NVL(error, '') || INACTIVE_BRAND_ERROR;
            END IF;

            IF rec.LexiconCountryId IS NULL THEN
                error := NVL(error, '') || NOT_LEXICON_COUNTRY_ERROR;
            ELSIF rec.CountryRefActive <> 'T' THEN
                error := NVL(error, '') || INACTIVE_COUNTRY_ERROR;
            END IF;
            
            IF rec.LexiconPCStageId IS NULL THEN
                error := NVL(error, '') || NOT_LEXICON_STAGE_ERROR;
            END IF;
            
            IF NVL(rec.IsPreComlBrand, 'y') = 'y' THEN
                stageId := rec.LexiconPCStageId;
            ELSE
                stageId := rec.LexiconComlStageId;
            END IF;

            EXECUTE IMMEDIATE updateSQL
                USING   error,
                        rec.LexiconBrandId,
                        rec.IsPreComlBrand,
                        rec.IsTrueComlBrand,
                        rec.LexiconCountryId,
                        stageId,
                        rec.LexiconStageActive,
                        rec.MidasProductNameId;
        END LOOP;

        COMMIT;
        Procedure_End_Trace_P('Validate_Product_Name_P');
    END Validate_Product_Name_P;
    
    /*
        Validates the seed product entries in the seed product staging table.
        1) Validates that the bayer code is tied to a crop found in Lexicon
        2) Validates that the company is a valid Lexicon brand
        3) Validates that the country is a valid Lexicon country
        4) Determines the Lexicon brand id
        5) Determines the Lexicon country id
    */
    PROCEDURE Validate_Seed_Product_P
    IS
        CURSOR curs IS
            SELECT  SSP.seed_product_id AS SeedProductId,
                    SBC.lexicon_crop_id AS LexiconCropId,
                    SC.lexicon_id AS LexiconCountryId,
                    SSP.error AS Error
              FROM  Staging_Seed_Product SSP,
                    Staging_Country SC,
                    Staging_Bayer_Code SBC
             WHERE  SSP.bayer_code = SBC.mirage_bayer_code (+)
               AND  SSP.country_code = SC.mirage_code (+);

        updateSQL VARCHAR2(400);
        error VARCHAR2(4000);
    BEGIN
        Procedure_Start_Trace_P('Validate_Seed_Product_P');

        updateSQL :=
            'UPDATE  Staging_Seed_Product' ||
            '   SET  error = :e, ' ||
            '        lexicon_crop_id = :crid, ' ||
            '        lexicon_country_id = :coid ' ||
            ' WHERE  seed_product_id = :spid';

        FOR rec IN curs LOOP
            error := rec.Error;

            IF rec.LexiconCropId IS NULL THEN
                error := NVL(error, '') || INVALID_BAYER_CODE_ERROR;
            END IF;

            IF rec.LexiconCountryId IS NULL THEN
                error := NVL(error, '') || INVALID_MIRAGE_COUNTRY_ERROR;
            END IF;

            EXECUTE IMMEDIATE updateSQL
                USING   error,
                        rec.LexiconCropId,
                        rec.LexiconCountryId,
                        rec.SeedProductId;
        END LOOP;

        COMMIT;
        Procedure_End_Trace_P('Validate_Seed_Product_P');
    END Validate_Seed_Product_P;
    
    /*
        This procedure determines whether a valid mirage seed product has a
        link to a midas product via map product mirage.  This information will
        be used to synchronize the FBS Common tables and potentially add
        additional product name(stage) records to Lexicon.
    */
    PROCEDURE Determine_SP_Midas_Link_P
    IS
        CURSOR curs IS
            SELECT  SSP.seed_product_id AS SeedProductId,
                    MPM.product_pk AS MappedProductId,
                    SP.midas_product_id AS MidasProductId,
                    SSP.error AS Error,
                    SSP.enabled AS Enabled
              FROM  Staging_Seed_Product SSP,
                    Map_Product_Mirage MPM,
                    Staging_Product SP
             WHERE  SSP.seed_product_id = MPM.seed_product_id (+)
               AND  MPM.product_pk = SP.midas_product_id (+);

        updateSQL VARCHAR2(400);
        error VARCHAR2(100);
        midasID Map_Product_Mirage.product_pk%TYPE;
    BEGIN
        Procedure_Start_Trace_P('Determine_SP_Midas_Link_P');

        updateSQL :=
            'UPDATE  Staging_Seed_Product' ||
            '   SET  midas_product_id = :mpid, ' ||
            '        error = :e ' ||
            ' WHERE  seed_product_id = :spid';

        FOR rec IN curs LOOP
            IF rec.MappedProductId IS NULL THEN
                IF rec.Enabled = 'Y' THEN
                    error := NO_MAP_PROD_MIRAGE_ENTRY_ERROR || '(Enabled)' || rec.Error;
                ELSE
                    error := NO_MAP_PROD_MIRAGE_ENTRY_ERROR || '(Disabled)' || rec.Error;
                END IF;
            ELSIF rec.MidasProductId IS NULL THEN
                IF rec.Enabled = 'Y' THEN
                    error := INVALID_MAP_PROD_MIRAGE_ENTRY || '(Enabled)' || rec.Error;
                ELSE
                    error := INVALID_MAP_PROD_MIRAGE_ENTRY || '(Disabled)' || rec.Error;
                END IF;
            ELSE
                error := rec.Error;
            END IF;

            EXECUTE IMMEDIATE updateSQL
                USING   rec.MidasProductId,
                        error,
                        rec.SeedProductId;
        END LOOP;

        COMMIT;
        Procedure_End_Trace_P('Determine_SP_Midas_Link_P');
    END Determine_SP_Midas_Link_P;
    
    /*
        This procedure validates that there are no duplicate seed products
        with the same bayer code, brand, and country.
    */
    PROCEDURE Validate_No_Dup_Seed_Product_P
    IS
        CURSOR curs IS
            SELECT  SSP.seed_product_id AS SeedProductId,
                    SSP.enabled AS Enabled,
                    GQ.GroupNumber
              FROM  Staging_Seed_Product SSP,
                    (SELECT  GQI.*, ROWNUM AS GroupNumber
                       FROM
                            (SELECT  SSP.midas_product_id,
                                     SSP.bayer_code,
                                     SSP.country_code,
                                     SSP.company_id
                               FROM  Staging_Seed_Product SSP
                              WHERE  SSP.midas_product_id IS NOT NULL
                                AND  SSP.error IS NULL
                            GROUP BY SSP.midas_product_id,
                                     SSP.bayer_code,
                                     SSP.country_code,
                                     SSP.company_id
                             HAVING  COUNT(*) > 1
                            ) GQI
                    )GQ
             WHERE  SSP.midas_product_id = GQ.midas_product_id
               AND  SSP.bayer_code = GQ.bayer_code
               AND  SSP.country_code = GQ.country_code
               AND  SSP.company_id = GQ.company_id;
               
        CURSOR curs2 IS
            SELECT  SSP.seed_product_id AS SeedProductId,
                    GQ.GroupNumber
              FROM  Staging_Seed_Product SSP,
                    (SELECT  SSP.other1 AS GroupNumber
                       FROM  Staging_Seed_Product SSP
                      WHERE  SSP.other1 IS NOT NULL
                        AND  SSP.enabled = 'Y'
                    GROUP BY SSP.other1
                     HAVING  COUNT(*) = 1
                    ) GQ
             WHERE  SSP.other1 = GQ.GroupNumber
               AND  SSP.enabled = 'Y';

        error VARCHAR2(100);
        updateSQL VARCHAR2(400);
    BEGIN
        Procedure_Start_Trace_P('Validate_No_Dup_Seed_Product_P');

        updateSQL :=
            'UPDATE  Staging_Seed_Product' ||
            '   SET  error = :e, ' ||
            '        other1 = :gn ' ||
            ' WHERE  seed_product_id = :spid';

        FOR rec IN curs LOOP
            IF rec.Enabled = 'Y' THEN
                error := DUP_SEED_PROD_ERROR || '(Enabled)';
            ELSE
                error := DUP_SEED_PROD_ERROR || '(Disabled)';
            END IF;
                
            EXECUTE IMMEDIATE updateSQL
                USING   error,
                        rec.GroupNumber,
                        rec.SeedProductId;
        END LOOP;
        
        error := NULL;
        FOR rec IN curs2 LOOP
            EXECUTE IMMEDIATE updateSQL
                USING   error,
                        rec.GroupNumber,
                        rec.SeedProductId;
        END LOOP;

        COMMIT;
        Procedure_End_Trace_P('Validate_No_Dup_Seed_Product_P');
    END Validate_No_Dup_Seed_Product_P;
    
    /*
        This private function translates a stack name/lexicon crop id into
        a lexicon trait stack id.  If none is found a NO_DATA_FOUND exception
        is thrown.
    */
    FUNCTION Get_Trait_Stack_Id_F(
        InStackName Lex_Stack_Name.value%TYPE,
        InCropId Lex_Stack_Name.crop_id%TYPE)
    RETURN Lex_Stack_Name.coml_trait_stack_id%TYPE
    IS
        stackId Lex_Stack_Name.coml_trait_stack_id%TYPE;
    BEGIN
        SELECT  LSN.coml_trait_stack_id
          INTO  stackId
          FROM  Lex_Stack_Name LSN
         WHERE  LSN.value = InStackName
           AND  LSN.crop_id = InCropId;

        RETURN stackID;
    END Get_Trait_Stack_Id_F;

    /*
        This procedure attempts to match the stack names loaded from yield mart
        to a trait stack id in lexicon.  If it is unable to find a match based
        on the stack name and the crop a warning is generated.
    */
    PROCEDURE Validate_Product_Attributes_P
    IS
        CURSOR curs IS
            SELECT  SPN.midas_product_name_id AS ProductNameId,
                    SP.lexicon_crop_id AS CropId,
                    SPN.other2 AS StackName,
                    SSP.enabled AS MirageEnabled
              FROM  Staging_Product_Name SPN,
                    Staging_Product SP,
                    Staging_Seed_Product SSP
             WHERE  SPN.other2 IS NOT NULL
               AND  SPN.midas_product_id = SP.midas_product_id
               AND  SPN.midas_product_name_id = SSP.midas_product_name_id (+);

        error VARCHAR2(100);
        updateSQL VARCHAR2(400);
        stackID Lex_Stack_Name.coml_trait_stack_id%TYPE;
    BEGIN
        Procedure_Start_Trace_P('Validate_Product_Attributes_P');
        
        updateSQL :=
            'UPDATE  Staging_Product_Name ' ||
            '   SET  other3 = :stid, ' ||
            '        warning = :err ' ||
            ' WHERE  midas_product_name_id = :pnid';
            
        FOR rec IN curs LOOP
            BEGIN
                stackId := Get_Trait_Stack_Id_F(rec.StackName, rec.CropId);
                error := NULL;
                
                EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                        stackId := NULL;
                        error := INVALID_TRAIT_STACK;
                        
                        IF rec.MirageEnabled IS NULL THEN
                            error := error || '(Not In Mirage)';
                        ELSIF rec.MirageEnabled = 'Y' THEN
                            error := error || '(Enabled)';
                        ELSIF rec.MirageEnabled = 'N' THEN
                            error := error || '(Disabled)';
                        END IF;
            END;
            
            EXECUTE IMMEDIATE updateSQL
                USING   stackId,
                        error,
                        rec.ProductNameId;
        END LOOP;

        COMMIT;
        Procedure_End_Trace_P('Validate_Product_Attributes_P');
    END Validate_Product_Attributes_P;
    
    /*
        This procudure validates that for every valid product there is at
        least 1 valid product name.
    */
    PROCEDURE Validate_Has_Valid_Name_P
    IS
        CURSOR curs IS
            SELECT  SP.midas_product_id AS MidasProductId
              FROM  Staging_Product SP,
                    (SELECT  DISTINCT
                             SPN.midas_product_id
                       FROM  Staging_Product_Name SPN
                      WHERE  SPN.error IS NULL
                    ) VSPN
             WHERE  SP.error IS NULL
               AND  SP.midas_product_id = VSPN.midas_product_id (+)
               AND  VSPN.midas_product_id IS NULL;
               
        updateSQL VARCHAR2(400);
    BEGIN
        Procedure_Start_Trace_P('Validate_Has_Valid_Name_P');

        updateSQL :=
            'UPDATE  Staging_Product ' ||
            '   SET  error = :pcn ' ||
            ' WHERE  midas_product_id = :mpid';

        FOR rec IN curs LOOP
            EXECUTE IMMEDIATE updateSQL
                USING   NO_VALID_NAME_ERROR,
                        rec.MidasProductId;
        END LOOP;

        COMMIT;
        Procedure_End_Trace_P('Validate_Has_Valid_Name_P');
    END Validate_Has_Valid_Name_P;


    PROCEDURE PC_Name_From_PC_Entry_P
    IS
        CURSOR curs IS
            SELECT  SPN.midas_product_id AS MidasProductId,
                    SPN.product_name AS PCName
              FROM  Staging_Product_Name SPN,
                    (
                        SELECT  MIN(SPN.midas_product_name_id) AS Id
                          FROM  Staging_Product_Name SPN
                         WHERE  NVL(SPN.error, '*Has Commercial') = '*Has Commercial'
                           AND  SPN.is_pre_commercial_brand = 'y'
                         GROUP BY SPN.midas_product_id
                    ) IQ
             WHERE  SPN.midas_product_name_id = IQ.Id;

        updateSQL VARCHAR2(400);
    BEGIN
        Procedure_Start_Trace_P('PC_Name_From_PC_Entry_P');

        updateSQL :=
            'UPDATE  Staging_Product' ||
            '   SET  pre_commercial_name = :pcn, ' ||
            '        name_source = :ns ' ||
            ' WHERE  midas_product_id = :mpid';

        FOR rec IN curs LOOP
            EXECUTE IMMEDIATE updateSQL
                USING   rec.PCName,
                        MIDAS_PC_NAME_SOURCE,
                        rec.MidasProductId;
        END LOOP;

        COMMIT;
        Procedure_End_Trace_P('PC_Name_From_PC_Entry_P');
    END PC_Name_From_PC_Entry_P;
    
    PROCEDURE PC_Name_From_Mirage_PC_Entry_P
    IS
        CURSOR curs IS
            SELECT  SP.midas_product_id AS MidasProductId,
                    SSP.product_name AS PCName
              FROM  Staging_Product SP,
                    Staging_Seed_Product SSP
             WHERE  SP.error IS NULL
               AND  SP.pre_commercial_name IS NULL
               AND  NVL(SSP.error, '*Has Commercial') = '*Has Commercial'
               AND  SP.midas_product_id = SSP.midas_product_id
               AND  SSP.is_pre_commercial_brand = 'y'
             ORDER BY SSP.seed_product_id DESC;

        updateSQL VARCHAR2(400);
    BEGIN
        Procedure_Start_Trace_P('PC_Name_From_Mirage_PC_Entry_P');

        updateSQL :=
            'UPDATE  Staging_Product' ||
            '   SET  pre_commercial_name = :pcn, ' ||
            '        name_source = :ns ' ||
            ' WHERE  midas_product_id = :mpid';

        FOR rec IN curs LOOP
            EXECUTE IMMEDIATE updateSQL
                USING   rec.PCName,
                        MIRAGE_PC_NAME_SOURCE,
                        rec.MidasProductId;
        END LOOP;

        COMMIT;
        Procedure_End_Trace_P('PC_Name_From_Mirage_PC_Entry_P');
    END PC_Name_From_Mirage_PC_Entry_P;

    PROCEDURE PC_Name_From_Coml_Entry_P
    IS
        CURSOR curs IS
            SELECT  SPN.midas_product_id AS MidasProductId,
                    SPN.product_name AS PCName
              FROM  Staging_Product_Name SPN,
                    (
                        SELECT  MIN(SPN.midas_product_name_id) AS Id
                          FROM  Staging_Product_Name SPN,
                                Staging_Product SP
                         WHERE  SPN.error IS NULL
                           AND  SPN.is_true_commercial_brand = 'y'
                           AND  SPN.crop_name <> 'CORN'
                           AND  SPN.midas_product_id = SP.midas_product_id
                           AND  SP.error IS NULL
                           AND  SP.primary_gp_is_inbred = 'y'
                         GROUP BY SPN.midas_product_id
                    ) IQ
             WHERE  SPN.midas_product_name_id = IQ.Id;

        updateSQL VARCHAR2(400);
    BEGIN
        Procedure_Start_Trace_P('PC_Name_From_Coml_Entry_P');

        updateSQL :=
            'UPDATE  Staging_Product' ||
            '   SET  pre_commercial_name = :pcn, ' ||
            '        name_source = :ns ' ||
            ' WHERE  midas_product_id = :mpid';

        FOR rec IN curs LOOP
            EXECUTE IMMEDIATE updateSQL
                USING   rec.PCName,
                        MIDAS_COML_NAME_SOURCE,
                        rec.MidasProductId;
        END LOOP;

        COMMIT;
        Procedure_End_Trace_P('PC_Name_From_Coml_Entry_P');
    END PC_Name_From_Coml_Entry_P;
    
    PROCEDURE PC_Name_From_Line_Code_P
    IS
        CURSOR curs IS
            SELECT  SPN.midas_product_id AS MidasProductId,
                    SP.primary_gp_line_code AS PCName
              FROM  Staging_Product_Name SPN,
                    (
                        SELECT  MIN(SPN.midas_product_name_id) AS Id
                          FROM  Staging_Product_Name SPN,
                                Staging_Product SP
                         WHERE  SPN.error IS NULL
                           AND  SPN.midas_product_id = SP.midas_product_id
                           AND  SP.error IS NULL
                           AND  SP.pre_commercial_name IS NULL
                           AND  SP.primary_gp_is_inbred = 'y'
                         GROUP BY SPN.midas_product_id
                    ) IQ,
                    Staging_Product SP
             WHERE  SPN.midas_product_name_id = IQ.Id
               AND  SPN.midas_product_id = SP.midas_product_id;

        updateSQL VARCHAR2(400);
        error VARCHAR2(4000);
    BEGIN
        Procedure_Start_Trace_P('PC_Name_From_Line_Code_P');

        updateSQL :=
            'UPDATE  Staging_Product' ||
            '   SET  pre_commercial_name = :pcn,' ||
            '        name_source = :ns, ' ||
            '        error = :e ' ||
            ' WHERE  midas_product_id = :mpid';

        FOR rec IN curs LOOP
            IF rec.PCName IS NULL THEN
                error := FUFGP_ERROR;
            ELSE
                error := NULL;
            END IF;
            
            EXECUTE IMMEDIATE updateSQL
                USING   rec.PCName,
                        LINE_CODE_NAME_SOURCE,
                        error,
                        rec.MidasProductId;
        END LOOP;

        COMMIT;
        Procedure_End_Trace_P('PC_Name_From_Line_Code_P');
    END PC_Name_From_Line_Code_P;

    PROCEDURE PC_Name_From_Unknown_P
    IS
        CURSOR curs IS
            SELECT  SP.midas_product_id AS MidasProductId
              FROM  Staging_Product SP
             WHERE  SP.error IS NULL
               AND  SP.pre_commercial_name IS NULL
               AND  SP.primary_gp_is_inbred = 'n';

        counter NUMBER := 0 ;
        updateSQL VARCHAR2(400);
    BEGIN
        Procedure_Start_Trace_P('PC_Name_From_Unknown_P');

        updateSQL :=
            'UPDATE  Staging_Product' ||
            '   SET  pre_commercial_name = :pcn,' ||
            '        name_source = :ns ' ||
            ' WHERE  midas_product_id = :mpid';

        FOR rec IN curs LOOP
            counter := counter +1;
            EXECUTE IMMEDIATE updateSQL
                USING   'UNKNOWN' || TO_CHAR(counter),
                        NAME_SOURCE_NOTFOUND,
                        rec.MidasProductId;
        END LOOP;

        COMMIT;
        Procedure_End_Trace_P('PC_Name_From_Unknown_P');
    END PC_Name_From_Unknown_P;
    
    /*
        This procedure determines finds all duplicate pre commercial names
        that were determined in the above procedures and mark them as errors.
    */
    PROCEDURE Validate_Dup_PCName_P
    IS
        CURSOR curs IS
            SELECT  SP.pre_commercial_name AS PCName,
                    SP.midas_product_id AS MidasProductId,
                    SPN.midas_product_name_id AS MidasProductNameId
              FROM  Staging_Product SP,
                    Staging_Product_Name SPN,
                    (
                    SELECT  SP.pre_commercial_name
                      FROM  Staging_Product SP
                     WHERE  (SP.error IS NULL OR SP.error = '*Duplicate PC Name')
                    GROUP BY SP.pre_commercial_name
                    HAVING COUNT(*) > 1
                    ) GSP
             WHERE  SP.pre_commercial_name = GSP.pre_commercial_name
               AND  (SP.error IS NULL OR SP.error = '*Duplicate PC Name')
               AND  SP.midas_product_id = SPN.midas_product_id
               AND  SPN.error IS NULL;

        updateSQL1 VARCHAR2(400);
        updateSQL2 VARCHAR2(400);
    BEGIN
        Procedure_Start_Trace_P('Validate_Dup_PCName_P');

        updateSQL1 :=
            'UPDATE  Staging_Product' ||
            '   SET  error = :e, ' ||
            '        lexicon_id = NULL, ' ||
            '        pubkey = NULL ' ||
            ' WHERE  midas_product_id = :mpid';

        updateSQL2 :=
            'UPDATE  Staging_Product_Name' ||
            '   SET  error = :e, ' ||
            '        lexicon_id = NULL, ' ||
            '        pubkey = NULL ' ||
            ' WHERE  midas_product_name_id = :mpnid';
            
        FOR rec IN curs LOOP
            EXECUTE IMMEDIATE updateSQL1
                USING   DUP_PCNAME,
                        rec.MidasProductId;

            EXECUTE IMMEDIATE updateSQL2
                USING   DUP_PCNAME,
                        rec.MidasProductNameId;
        END LOOP;

        COMMIT;
        Procedure_End_Trace_P('Validate_Dup_PCName_P');

    END Validate_Dup_PCName_P;
    
    /*
        If I told you I'd have to kill you
    */
    PROCEDURE Map_Mir_Has_Midas_Prod_Error_P
    IS
        CURSOR  curs IS
            SELECT  SSP.seed_product_id AS SeedProductId
              FROM  Staging_Seed_Product SSP,
                    Staging_Product SP
             WHERE  SSP.error IS NULL
               AND  SSP.lexicon_name_id IS NOT NULL
               AND  SSP.midas_product_name_id IS NULL
               AND  SSP.midas_product_id = SP.midas_product_id
               AND  SP.error IS NOT NULL;
        updateSQL VARCHAR2(400);
    BEGIN
        Procedure_Start_Trace_P('Map_Mir_Has_Midas_Prod_Error_P');

        updateSQL :=
            'UPDATE  Staging_Seed_Product' ||
            '   SET  error = :err, ' ||
            '        lexicon_name_id = NULL ' ||
            ' WHERE  seed_product_id = :spid';
            
        FOR rec IN curs LOOP
            EXECUTE IMMEDIATE updateSQL
                USING   PRODUCT_HAS_ERROR,
                        rec.SeedProductId;
        END LOOP;

        COMMIT;
        
        Procedure_End_Trace_P('Map_Mir_Has_Midas_Prod_Error_P');
    END Map_Mir_Has_Midas_Prod_Error_P;

    /*
        This procedure determines whether a valid pre commercial seed product
        entry has a commercial seed product entry (i.e. an entry that has the
        same product id and country id).  Those entries that have commercial
        equivalent will not be added to Lexicon.
    */
    PROCEDURE Determine_Mirage_Coml_Equiv_P
    IS
        CURSOR cursPCN IS
            SELECT  SSP.*
              FROM  Staging_Seed_Product SSP
             WHERE  SSP.error IS NULL
               AND  SSP.is_pre_commercial_brand = 'y'
              ORDER BY SSP.midas_product_id, SSP.country_code;

        CURSOR cursCN IS
            SELECT  SSP.*
              FROM  Staging_Seed_Product SSP
             WHERE  SSP.error IS NULL
               AND  SSP.is_pre_commercial_brand = 'n'
              ORDER BY SSP.midas_product_id, SSP.country_code;

        recPCN Staging_Seed_Product%ROWTYPE;
        recCN  Staging_Seed_Product%ROWTYPE;

        updateSQL VARCHAR2(400);
    BEGIN
        Procedure_Start_Trace_P('Determine_Mirage_Coml_Equiv_P');

        updateSQL :=
            'UPDATE  Staging_Seed_Product' ||
            '   SET  commercial_equivalent_id = :eid, ' ||
            '        error = :err ' ||
            ' WHERE  seed_product_id = :spid';

        OPEN cursPCN;
        OPEN cursCN;
        FETCH cursPCN INTO recPCN;
        FETCH cursCN INTO recCN;

        LOOP
            EXIT WHEN cursPCN%NOTFOUND;
            EXIT WHEN cursCN%NOTFOUND;

            IF recPCN.midas_product_id < recCN.midas_product_id THEN
                FETCH cursPCN INTO recPCN;
            ELSIF recCN.midas_product_id < recPCN.midas_product_id THEN
                FETCH cursCN INTO recCN;
            ELSE
                IF recPCN.country_code < recCN.country_code THEN
                    FETCH cursPCN INTO recPCN;
                ELSIF recCN.country_code < recPCN.country_code THEN
                    FETCH cursCN INTO recCN;
                ELSE
                    EXECUTE IMMEDIATE updateSQL
                        USING   recCN.seed_product_id,
                                HAS_COML_VERSION_WARN,
                                recPCN.seed_product_id;
                    FETCH cursPCN INTO recPCN;
                    FETCH cursCN INTO recCN;
                END IF;
            END IF;
        END LOOP;

        COMMIT;
        Procedure_End_Trace_P('Determine_Mirage_Coml_Equiv_P');
    END Determine_Mirage_Coml_Equiv_P;

    /*
        This procedure determines whether a valid pre commercial product name
        entry has a commercial product name entry (i.e. an entry that has the
        same product id and country id).  Those entries that have commercial
        equivalent will not be added to Lexicon (or FBS Common or Mirage)
    */
    PROCEDURE Determine_Coml_Equiv_P
    IS
        CURSOR cursPCN IS
            SELECT  SPN.*
              FROM  Staging_Product_Name SPN
             WHERE  SPN.error IS NULL
               AND  SPN.is_pre_commercial_brand = 'y'
              ORDER BY SPN.midas_product_id, SPN.midas_country_id;

        CURSOR cursCN IS
            SELECT  SPN.*
              FROM  Staging_Product_Name SPN
             WHERE  SPN.error IS NULL
               AND  SPN.is_pre_commercial_brand = 'n'
              ORDER BY SPN.midas_product_id, SPN.midas_country_id;

        recPCN Staging_Product_Name%ROWTYPE;
        recCN  Staging_Product_Name%ROWTYPE;

        updateSQL VARCHAR2(400);
    BEGIN
        Procedure_Start_Trace_P('Determine_Coml_Equiv_P');

        updateSQL :=
            'UPDATE  Staging_Product_Name' ||
            '   SET  commercial_equivalent_id = :eid, ' ||
            '        error = :err ' ||
            ' WHERE  midas_product_name_id = :mpid';

        OPEN cursPCN;
        OPEN cursCN;
        FETCH cursPCN INTO recPCN;
        FETCH cursCN INTO recCN;
        
        LOOP
            EXIT WHEN cursPCN%NOTFOUND;
            EXIT WHEN cursCN%NOTFOUND;
            
            IF recPCN.midas_product_id < recCN.midas_product_id THEN
                FETCH cursPCN INTO recPCN;
            ELSIF recCN.midas_product_id < recPCN.midas_product_id THEN
                FETCH cursCN INTO recCN;
            ELSE
                IF recPCN.midas_country_id < recCN.midas_country_id THEN
                    FETCH cursPCN INTO recPCN;
                ELSIF recCN.midas_country_id < recPCN.midas_country_id THEN
                    FETCH cursCN INTO recCN;
                ELSE
                    EXECUTE IMMEDIATE updateSQL
                        USING   recCN.midas_product_name_id,
                                HAS_COML_VERSION_WARN,
                                recPCN.midas_product_name_id;
                    FETCH cursPCN INTO recPCN;
                    FETCH cursCN INTO recCN;
                END IF;
            END IF;
        END LOOP;

        COMMIT;
        Procedure_End_Trace_P('Determine_Coml_Equiv_P');
    END Determine_Coml_Equiv_P;
    
    /*
        This procedure determines whether a valid mirage seed product has a
        link to a midas product name via matching midas product id, 
        brand, and country.  Matching brand and country are determined by
        matching lexicon ids in the respective staging tables.  This information
        is used to initialize the FBS Common product tables in a later method.
        If the names don't match then a warning is generated.
    */
    PROCEDURE Determine_SP_PN_Link_P
    IS
        CURSOR curs IS
            SELECT  SPN.midas_product_name_id AS MidasProductNameId,
                    SSP.seed_product_id AS SeedProductId,
                    SPN.product_name AS MidasName,
                    SSP.product_name AS MirageName
              FROM  Staging_Product_Name SPN,
                    Staging_Seed_Product SSP
             WHERE  SPN.error IS NULL
               AND  SPN.midas_product_id = SSP.midas_product_id
               AND  SPN.lexicon_country_id = SSP.lexicon_country_id
               AND  SPN.lexicon_brand_id = SSP.lexicon_brand_id
               AND  SSP.error IS NULL;

        warning VARCHAR2(100);
        updateSQL VARCHAR2(400);
    BEGIN
        Procedure_Start_Trace_P('Determine_SP_PN_Link_P');

        updateSQL :=
            'UPDATE  Staging_Seed_Product' ||
            '   SET  midas_product_name_id = :mpid, ' ||
            '        warning = :warn ' ||
            ' WHERE  seed_product_id = :spid';

        FOR rec IN curs LOOP
            IF rec.MidasName = rec.MirageName THEN
                warning := NULL;
            ELSE
                warning := NAME_MISMATCH_WARN;
            END IF;
            
            EXECUTE IMMEDIATE updateSQL
                USING   rec.MidasProductNameId,
                        warning,
                        rec.SeedProductId;
        END LOOP;

        COMMIT;
        Procedure_End_Trace_P('Determine_SP_PN_Link_P');
    END Determine_SP_PN_Link_P;
    
    /*
        This procedure finds all valid commercial Mirage products that are
        linked to Midas products in Map Product Mirage but have no corresponding
        valid commercial Midas Product Name entry (ie same product id,
        same country, same brand)
    */
    PROCEDURE Determine_Unmatch_Mirage_Com_P
    IS
        CURSOR curs IS
            SELECT  SSP.seed_product_id AS SeedProductId,
                    SSP.enabled AS Enabled
              FROM  Staging_Seed_Product SSP
             WHERE  SSP.error IS NULL
               AND  SSP.midas_product_id IS NOT NULL
               AND  SSP.midas_product_name_id IS NULL
               AND  SSP.is_pre_commercial_brand = 'n';

        error VARCHAR2(100);
        updateSQL VARCHAR2(400);
    BEGIN
        Procedure_Start_Trace_P('Determine_Unmatch_Mirage_Com_P');

        updateSQL :=
            'UPDATE  Staging_Seed_Product' ||
            '   SET  error = :e ' ||
            ' WHERE  seed_product_id = :spid';

        FOR rec IN curs LOOP
            IF rec.Enabled = 'Y' THEN
                error := NO_MIDAS_COML_ERROR || '(Enabled)';
            ELSE
                error := NO_MIDAS_COML_ERROR || '(Disabled)';
            END IF;
            
            EXECUTE IMMEDIATE updateSQL
                USING   error,
                        rec.SeedProductId;
        END LOOP;

        COMMIT;
        Procedure_End_Trace_P('Determine_Unmatch_Mirage_Com_P');
    END Determine_Unmatch_Mirage_Com_P;
    
    /*
    
    */
    PROCEDURE Determine_Mir_PCN_Midas_Coml_P
    IS
        CURSOR curs IS
            SELECT  SSP.seed_product_id AS SeedProductId
			  FROM  Staging_Seed_Product SSP,
			        Staging_Product_Name SPN
			 WHERE  SSP.lexicon_name_id IS NOT NULL
			   AND  SSP.midas_product_id IS NOT NULL
			   AND  SSP.midas_product_name_id IS NULL
			   AND  SSP.is_pre_commercial_brand = 'y'
			   AND  SSP.midas_product_id = SPN.midas_product_id
			   AND  SSP.lexicon_country_id = SPN.lexicon_country_id
			   AND  SPN.is_pre_commercial_brand = 'n';
			
	   updateSQL VARCHAR2(400);
    BEGIN
        Procedure_Start_Trace_P('Determine_Mir_PCN_Midas_Coml_P');

        updateSQL :=
            'UPDATE  Staging_Seed_Product' ||
            '   SET  lexicon_name_id = NULL, ' ||
            '        lexicon_pubkey = NULL, ' ||
            '        error = :e ' ||
            ' WHERE  seed_product_id = :spid';

        FOR rec IN curs LOOP
            EXECUTE IMMEDIATE updateSQL
                USING   HAS_COML_VERSION_WARN,
                        rec.SeedProductId;
        END LOOP;

        COMMIT;
        Procedure_End_Trace_P('Determine_Mir_PCN_Midas_Coml_P');
    END Determine_Mir_PCN_Midas_Coml_P;

    /*
        This procedure assigns a lexicon id and public key to all valid
        product entries in the staging table.
    */
    PROCEDURE Assign_Lexicon_Products_P
    IS
        CURSOR curs IS
            SELECT  SP.midas_product_id AS MidasProductId,
                    Lex_Product_Id_Seq.NEXTVAL AS LexiconProductId,
                    Lex_Product_Pubkey_Seq.NEXTVAL AS Pubkey
              FROM  Staging_Product SP
             WHERE  SP.error IS NULL;

        updateSQL VARCHAR2(400);
        
    BEGIN
        Procedure_Start_Trace_P('Assign_Lexicon_Products_P');

        updateSQL :=
            'UPDATE  Staging_Product' ||
            '   SET  lexicon_id = :lpid, ' ||
            '        pubkey = :pk ' ||
            ' WHERE  midas_product_id = :mpid';

        FOR rec IN curs LOOP
            EXECUTE IMMEDIATE updateSQL
                USING   rec.LexiconProductId,
                        rec.Pubkey,
                        rec.MidasProductId;
        END LOOP;

        COMMIT;
        Procedure_End_Trace_P('Assign_Lexicon_Products_P');
    END Assign_Lexicon_Products_P;
    
    /*
        This procedure assigns a lexicon id and public key to all valid
        product name entries in the staging table.
    */
    PROCEDURE Assign_Lex_Names_From_Midas_P
    IS
        CURSOR curs IS
            SELECT  SPN.midas_product_name_id AS MidasProdNameId,
                    SPN.product_name AS ProductName
              FROM  Staging_Product_Name SPN
             WHERE  SPN.error IS NULL;

        updateSQL VARCHAR2(400);
        prodNameID NUMBER;
        pubkey VARCHAR2(20);
    BEGIN
        Procedure_Start_Trace_P('Assign_Lex_Names_From_Midas_P');

        updateSQL :=
            'UPDATE  Staging_Product_Name' ||
            '   SET  lexicon_id = :lpid, ' ||
            '        pubkey = :pk, ' ||
            '        commercial_name = :cn ' ||
            ' WHERE  midas_product_name_id = :mpid';

        FOR rec IN curs LOOP
            SELECT Lex_Prod_Name_Id_Seq.NEXTVAL INTO prodNameID FROM DUAL;
            SELECT Lex_Prod_Name_Pubkey_Seq.NEXTVAL INTO pubkey FROM DUAL;
            
            EXECUTE IMMEDIATE updateSQL
                USING   prodNameID,
                        pubkey,
                        rec.ProductName,
                        rec.MidasProdNameId;
        END LOOP;

        COMMIT;
        Procedure_End_Trace_P('Assign_Lex_Names_From_Midas_P');
    END Assign_Lex_Names_From_Midas_P;
    
    /*
        This procedure assigns a lexicon id and public key to all valid pre
        commercial Mirage seed product entries in the staging table that aren't
        already with a Mirage valid commercial name entry or with a valid Midas
        product name entry.
    */
    PROCEDURE Assign_Lex_Names_From_Mirage_P
    IS
        CURSOR curs IS
            SELECT  SSP.seed_product_id AS SeedProductId
              FROM  Staging_Seed_Product SSP
             WHERE  SSP.error IS NULL
               AND  SSP.midas_product_name_id IS NULL
               AND  SSP.is_pre_commercial_brand = 'y';

        updateSQL VARCHAR2(400);
        prodNameID NUMBER;
        pubkey VARCHAR2(20);
    BEGIN
        Procedure_Start_Trace_P('Assign_Lex_Names_From_Mirage_P');

        updateSQL :=
            'UPDATE  Staging_Seed_Product' ||
            '   SET  lexicon_name_id = :lpid, ' ||
            '        lexicon_pubkey = :pk ' ||
            ' WHERE  seed_product_id = :spid';

        FOR rec IN curs LOOP
            SELECT Lex_Prod_Name_Id_Seq.NEXTVAL INTO prodNameID FROM DUAL;
            SELECT Lex_Prod_Name_Pubkey_Seq.NEXTVAL INTO pubkey FROM DUAL;

            EXECUTE IMMEDIATE updateSQL
                USING   prodNameID,
                        pubkey,
                        rec.SeedProductId;
        END LOOP;

        COMMIT;
        Procedure_End_Trace_P('Assign_Lex_Names_From_Mirage_P');
    END Assign_Lex_Names_From_Mirage_P;
    
    /*
        This procedure set the lexicon product name id in the seed product
        staging table for products that were found and valid in both Midas
        and Mirage.
    */
    PROCEDURE Link_Common_Names_P
    IS
        CURSOR curs IS
            SELECT  SPN.lexicon_id AS LexiconProductNameId,
                    SPN.pubkey AS Pubkey,
                    SSP.seed_product_id AS SeedProductId
              FROM  Staging_Product_Name SPN,
                    Staging_Seed_Product SSP
             WHERE  SPN.error IS NULL
               AND  SPN.lexicon_id IS NOT NULL
               AND  SPN.midas_product_name_id = SSP.midas_product_name_id
               AND  SSP.error IS NULL;

        updateSQL VARCHAR2(400);
    BEGIN
        Procedure_Start_Trace_P('Link_Common_Names_P');

        updateSQL :=
            'UPDATE  Staging_Seed_Product' ||
            '   SET  lexicon_name_id = :lpid, ' ||
            '        lexicon_pubkey = :pk ' ||
            ' WHERE  seed_product_id = :spid';

        FOR rec IN curs LOOP
            EXECUTE IMMEDIATE updateSQL
                USING   rec.LexiconProductNameId,
                        rec.Pubkey,
                        rec.SeedProductId;
        END LOOP;

        COMMIT;
        Procedure_End_Trace_P('Link_Common_Names_P');
    END Link_Common_Names_P;

    /*
        This procedure insert products into the temporary lexicon database from staging
    */
    PROCEDURE Insert_Lexicon_Products_P
    IS
        TYPE ProductArray IS
            TABLE OF Lex_Product%ROWTYPE
            INDEX BY BINARY_INTEGER;

        products ProductArray;
    BEGIN
        Procedure_Start_Trace_P('Insert_Lexicon_Products_P');
        
        SELECT  SP.lexicon_id,
                SP.pubkey,
                SP.pre_commercial_name,
                SP.lexicon_crop_id,
                NULL AS USTV_Name
        BULK COLLECT INTO products
          FROM  Staging_Product SP
         WHERE  SP.error IS NULL
           AND  SP.pre_commercial_name IS NOT NULL;

        FORALL idx IN products.FIRST .. products.LAST
            INSERT INTO Temp_Product
            VALUES products(idx);

        COMMIT;

        Procedure_End_Trace_P('Insert_Lexicon_Products_P');
    END Insert_Lexicon_Products_P;

    /*
        This procedure insert names into the temporary lexicon table from staging
    */
    PROCEDURE Insert_Lexicon_Midas_Names_P
    IS
        TYPE NameArray IS
            TABLE OF Lex_Prod_Name%ROWTYPE
            INDEX BY BINARY_INTEGER;

        names NameArray;
    BEGIN
        Procedure_Start_Trace_P('Insert_Lexicon_Midas_Names_P');

        SELECT  SPN.lexicon_id AS ProductNameId,
                SPN.pubkey AS PublicKey,
                SP.lexicon_id AS ProductId,
                SPN.lexicon_country_id AS CountryId,
                SPN.lexicon_brand_id AS BrandId,
                SPN.lexicon_stage_id AS StageId,
                DECODE(SPN.is_pre_commercial_brand, 'y', NULL, SPN.product_name) AS CommercialName,
                NULL AS TestName,
                NULL AS OECDName,
                SPN.other1 AS ComlMaturity,
                SPN.lexicon_stage_active_flag AS IsActive,
                SPN.other3 AS StackId
        BULK COLLECT INTO names
          FROM  Staging_Product_Name SPN,
                Staging_Product SP
         WHERE  SPN.error IS NULL
           AND  SPN.midas_product_id = SP.midas_product_id
           AND  SPN.lexicon_id IS NOT NULL;
           

        FORALL idx IN names.FIRST .. names.LAST
            INSERT INTO Temp_Prod_Name
            VALUES names(idx);

        COMMIT;

        Procedure_End_Trace_P('Insert_Lexicon_Midas_Names_P');
    END Insert_Lexicon_Midas_Names_P;
    
    /*
        This procedure insert names into the temporary lexicon table from Mirage staging
    */
    PROCEDURE Insert_Mirage_Only_Names_P
    IS
        TYPE NameArray IS
            TABLE OF Lex_Prod_Name%ROWTYPE
            INDEX BY BINARY_INTEGER;

        names NameArray;
    BEGIN
        Procedure_Start_Trace_P('Insert_Mirage_Only_Names_P');

        SELECT  SSP.lexicon_name_id AS ProductNameId,
                SSP.lexicon_pubkey AS PublicKey,
                SP.lexicon_id AS ProductId,
                SSP.lexicon_country_id AS CountryId,
                SSP.lexicon_brand_id AS BrandId,
                SS.lex_pc_stage_id AS StageId,
                DECODE(SSP.is_pre_commercial_brand, 'y', NULL, SSP.product_name) AS CommercialName,
                NULL AS TestName,
                NULL AS OECDName,
                NULL AS ComlMaturity,
                LOWER(SSP.enabled) AS IsActive,
                NULL AS StackId
        BULK COLLECT INTO names
          FROM  Staging_Seed_Product SSP,
                Staging_Product SP,
                Staging_Stage SS
         WHERE  SSP.error IS NULL
           AND  SSP.midas_product_id = SP.midas_product_id
           AND  SSP.lexicon_name_id IS NOT NULL
           AND  SSP.midas_product_name_id IS NULL
           AND  SS.midas_ref_id = 'PMC1';

        FORALL idx IN names.FIRST .. names.LAST
            INSERT INTO Temp_Prod_Name
            VALUES names(idx);

        COMMIT;

        Procedure_End_Trace_P('Insert_Mirage_Only_Names_P');
    END Insert_Mirage_Only_Names_P;
    
    /*
        This procedure insert products into the temporary fbs common mapping table
    */
    PROCEDURE Insert_FBS_Common_Products_P
    IS
        TYPE ProductArray IS
            TABLE OF FBS_Prod_Xref%ROWTYPE
            INDEX BY BINARY_INTEGER;

        products ProductArray;
    BEGIN
        Procedure_Start_Trace_P('Insert_FBS_Common_Products_P');

        SELECT  SP.pubkey AS PublicKey,
                SP.midas_product_id AS MidasProductId
        BULK COLLECT INTO products
          FROM  Staging_Product SP
         WHERE  SP.error IS NULL
           AND  SP.pubkey IS NOT NULL
           AND  SP.midas_product_id IS NOT NULL;

        FORALL idx IN products.FIRST .. products.LAST
            INSERT INTO Temp_Prod_Xref
            VALUES products(idx);

        COMMIT;

        Procedure_End_Trace_P('Insert_FBS_Common_Products_P');
    END Insert_FBS_Common_Products_P;

    /*
        This procedure insert product names into the temporary fbs common mapping table
    */
    PROCEDURE Insert_FBS_Common_Names_P
    IS
        TYPE NameArray IS
            TABLE OF FBS_Prod_Name_Xref%ROWTYPE
            INDEX BY BINARY_INTEGER;

        names NameArray;
    BEGIN
        Procedure_Start_Trace_P('Insert_FBS_Common_Names_P');

        SELECT  *
        BULK COLLECT INTO names
          FROM  (
                SELECT  SPN.pubkey AS PublicKey,
                        SPN.midas_product_name_id AS MidasProductNameId,
                        SSP.seed_product_id AS SeedProductId
                  FROM  Staging_Product_Name SPN,
                        Staging_Seed_Product SSP
                 WHERE  SPN.error IS NULL
                   AND  SPN.pubkey IS NOT NULL
                   AND  SPN.pubkey = SSP.lexicon_pubkey (+)

                UNION
                
                SELECT  SSP.lexicon_pubkey AS PublicKey,
                        NULL AS MidasProductNameId,
                        SSP.seed_product_id AS SeedProductId
                  FROM  Staging_Seed_Product SSP
                 WHERE  SSP.error IS NULL
                   AND  SSP.lexicon_pubkey IS NOT NULL
                   AND  SSP.midas_product_name_id IS NULL
                );

        FORALL idx IN names.FIRST .. names.LAST
            INSERT INTO Temp_Prod_Name_Xref
            VALUES names(idx);

        COMMIT;

        Procedure_End_Trace_P('Insert_FBS_Common_Names_P');
    END Insert_FBS_Common_Names_P;



    /*************************************************************************
            The following procedures perform the acutal inserts
    *************************************************************************/

    /*
        This procedure performs the actual insert into the non temp product table
    */
    PROCEDURE Actual_Prod_Inserts_P
    IS
        TYPE ProductArray IS
            TABLE OF Temp_Product%ROWTYPE
            INDEX BY BINARY_INTEGER;

        products ProductArray;
    BEGIN
        Procedure_Start_Trace_P('Actual_Prod_Inserts_P');

        SELECT  *
        BULK COLLECT INTO products
          FROM  Temp_Product;

        FORALL idx IN products.FIRST .. products.LAST
            INSERT INTO Lexicon.Pre_Coml_Product
            VALUES products(idx);

        Procedure_End_Trace_P('Actual_Prod_Inserts_P');
    END Actual_Prod_Inserts_P;

    /*
        This procedure performs the actual inserts into the non temp product name table
    */
    PROCEDURE Actual_Name_Inserts_P
    IS
        TYPE ProductNameArray IS
            TABLE OF Temp_Prod_Name%ROWTYPE
            INDEX BY BINARY_INTEGER;

        names ProductNameArray;
    BEGIN
        Procedure_Start_Trace_P('Actual_Name_Inserts_P');

        SELECT  *
        BULK COLLECT INTO names
          FROM  Temp_Prod_Name;

        FORALL idx IN names.FIRST .. names.LAST
            INSERT INTO Lexicon.Product_Stage
            VALUES names(idx);

        Procedure_End_Trace_P('Actual_Name_Inserts_P');
    END Actual_Name_Inserts_P;

    /*
        This procedure performs the actual insert into the non temp product xref mapping table
    */
    PROCEDURE Actual_Prod_Xref_Inserts_P
    IS
/*
        TYPE ProductArray IS
            TABLE OF FBS_Prod_Xref%ROWTYPE
            INDEX BY BINARY_INTEGER;

        products ProductArray;
*/
        CURSOR curs IS
            SELECT  *
              FROM  Temp_Prod_Xref;
              
        insertSQL VARCHAR2(400) :=
            'INSERT ' ||
            '  INTO FBS_Prod_Xref(Lexicon_Product_Pubkey, Midas_Product_Id)' ||
            'VALUES (:lpk, :mpid)';
    BEGIN
        Procedure_Start_Trace_P('Actual_Prod_Xref_Inserts_P');

/*        SELECT  *
        BULK COLLECT INTO products
          FROM  Temp_Prod_Xref;

        FORALL idx IN products.FIRST .. products.LAST
            INSERT INTO FBS_Prod_Xref
            VALUES products(idx);
*/
        FOR rec IN curs LOOP
            EXECUTE IMMEDIATE insertSQL
                USING   rec.Lexicon_Product_Pubkey,
                        rec.Midas_Product_Id;
        END LOOP;
        
        Procedure_End_Trace_P('Actual_Prod_Xref_Inserts_P');
    END Actual_Prod_Xref_Inserts_P;

    /*
        This procedure performs the actual inserts into the non temp product name xref mapping table
    */
    PROCEDURE Actual_Name_Xref_Inserts_P
    IS
/*
        TYPE ProductNameArray IS
            TABLE OF FBS_Prod_Name_Xref%ROWTYPE
            INDEX BY BINARY_INTEGER;

        names ProductNameArray;
*/
        CURSOR curs IS
            SELECT  *
              FROM  Temp_Prod_Name_Xref;

        insertSQL VARCHAR2(400) :=
            'INSERT ' ||
            '  INTO FBS_Prod_Name_Xref(Lexicon_Product_Name_Pubkey, Midas_Product_Name_Id, Mirage_Product_Id)' ||
            'VALUES (:lpk, :mpid, :spid)';
    BEGIN
        Procedure_Start_Trace_P('Actual_Name_Xref_Inserts_P');
/*
        SELECT  *
        BULK COLLECT INTO names
          FROM  Temp_Prod_Name_Xref;

        FORALL idx IN names.FIRST .. names.LAST
            INSERT INTO FBS_Prod_Name_Xref
            VALUES names(idx);
*/

        FOR rec IN curs LOOP
            EXECUTE IMMEDIATE insertSQL
                USING   rec.Lexicon_Product_Name_Pubkey,
                        rec.Midas_Product_Name_Id,
                        rec.Mirage_Product_Id;
        END LOOP;

        Procedure_End_Trace_P('Actual_Name_Xref_Inserts_P');
    END Actual_Name_Xref_Inserts_P;
    
    /*
        This procedure performs the actual insert into the actual product gp table
    */
    PROCEDURE Actual_Prod_GP_Insert_P
    IS
/*        TYPE ProductGPArray IS
            TABLE OF Lexicon.Product_GP_Action%ROWTYPE
            INDEX BY BINARY_INTEGER;

        entries ProductGPArray;
*/
        CURSOR curs IS
            SELECT  SP.pubkey,
                    SGP.germplasm_id
              FROM  Staging_Product SP,
                    Staging_Germplasm SGP
             WHERE  SP.lexicon_id IS NOT NULL
               AND  SP.error IS NULL
               AND  SP.midas_product_id = SGP.midas_product_id;

        counter NUMBER := 0;
        insertSQL VARCHAR2(400) :=
            'INSERT ' ||
            '  INTO Lexicon.Product_GP_Action(Product_Gp_Action_Id, Product_Pubkey, Gp_Key)' ||
            'VALUES (:id, :lpk, :gpid)';
    BEGIN
        Procedure_Start_Trace_P('Actual_Prod_GP_Insert_P');
/*
        FORALL idx IN entries.FIRST .. entries.LAST
        BEGIN
            INSERT INTO Lexicon.Product_GP_Action
            VALUES entries(idx);
        END;
*/

        FOR rec IN curs LOOP
            counter := counter +1;
            EXECUTE IMMEDIATE insertSQL
                USING   counter,
                        rec.pubkey,
                        rec.germplasm_id;
        END LOOP;

        Procedure_End_Trace_P('Actual_Prod_GP_Insert_P');
    END Actual_Prod_GP_Insert_P;


END MPDL_PKG;
/


