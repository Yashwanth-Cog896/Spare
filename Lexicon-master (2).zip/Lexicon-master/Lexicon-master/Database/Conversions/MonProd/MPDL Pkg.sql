CREATE OR REPLACE
PACKAGE Ngscho.Mpdl_Pkg
  IS
    /***** Validation Errors/Warning Constants *****/
    -- The ref active flag of the product is not set to true
    INACTIVE_PRODUCT_ERROR VARCHAR2(100)    := '*Inactive Product';

    -- The ref active flag of the crop is not set to true
    INACTIVE_CROP_ERROR VARCHAR2(100)       := '*Inactive Crop';

    -- The crop is not a valid Lexicon major crop
    NOT_LEXICON_CROP_ERROR VARCHAR2(100)    := '*Invalid Crop';

    -- There are no germplasms associated with this product
    NO_GERMPLASM_ERROR VARCHAR2(100)        := '*No Germplasms';
    
    -- If a product has an error the product name is also an error state
    PRODUCT_HAS_ERROR VARCHAR2(100)        := '*Midas Product Has Error';

    -- The ref active flag of the brand is not set to true
    INACTIVE_BRAND_ERROR VARCHAR2(100)      := '*Inactive Brand';

    -- The brand is not a valid Lexicon Monsanto brand
    NOT_LEXICON_BRAND_ERROR VARCHAR2(100)   := '*Invalid Brand';

    -- The ref active flag of the country is not set to true
    INACTIVE_COUNTRY_ERROR VARCHAR2(100)    := '*Inactive Country';

    -- The country is not a valid Lexicon country
    NOT_LEXICON_COUNTRY_ERROR VARCHAR2(100) := '*Invalid Country';

    -- The product stage is not a valid Lexicon stage
    NOT_LEXICON_STAGE_ERROR VARCHAR2(100)   := '*Invalid Stage';
    
    -- The germplasm associated with this product are inconsistent
    INCONSISTENT_GP_ERROR VARCHAR2(100)     := '*Inconsistent Line Types';

    -- The are no germplasm associated with this product that are HYBRID, FINISHED, or CODED
    NON_ASSIGNABLE_GP_ERROR VARCHAR2(100)   := '*No Assignable Germplasm';
    
    -- None of the product name entries associated with this product are valid
    NO_VALID_NAME_ERROR VARCHAR2(100)       := '*No Valid Names';
    
    -- An inbred product has no pre commercial or commercial names and all of
    -- germplasm associated with this product have null line codes
    FUFGP_ERROR VARCHAR2(100)               := '*FUFGP';
    
    -- The bayer code is not linked to a valid Major Lexicon crop
    INVALID_BAYER_CODE_ERROR VARCHAR2(100)  := '*Invalid Bayer Code';

    -- The country is not linked to a valid Lexicon country
    INVALID_MIRAGE_COUNTRY_ERROR VARCHAR2(100)  := '*Invalid Mirage Country';
    
    -- There is two(or more) seed products that have the same bayer code,
    -- company, and country (but presumably a different name)
    DUP_SEED_PROD_ERROR VARCHAR2(100)       := '*Duplicate Seed Product';
    
    -- The Mirage product is not linked to a Midas product in Map Product Mirage
    -- While this isn't strictly an error, it prevents this seed product from
    -- being linked to Midas product down the road.
    NO_MAP_PROD_MIRAGE_ENTRY_ERROR VARCHAR2(100) := '*No Map Product Mirage Entry';
    
    -- The Mirage product is not linked to a Midas product in Map Product Mirage
    -- While this isn't strictly an error, it prevents this seed product from
    -- being linked to Midas product down the road.
    INVALID_MAP_PROD_MIRAGE_ENTRY VARCHAR2(100) := '*Invalid Map Product Mirage Entry';

    -- The commercial product name exists in Mirage is mapped to a Midas product
    -- id in Map Product Mirage but that product doesn't not have commercial
    -- name for this country and brand.
    NO_MIDAS_COML_ERROR VARCHAR2(100) := '*No Midas Commercial';
    
    -- The Mirage product name doesn't match the Midas product name even though
    -- the mirage seed product was mapped to the Midas product in Map Product
    -- Mirage and the country and brand matches.
    NAME_MISMATCH_WARN VARCHAR2(100) := '*Name mismatch';
    
    -- The pre commercial product has commercial version for the same
    -- country and brand.  This isn't it error, but the pre commercial name will
    -- not be sent to lexicon.
    HAS_COML_VERSION_WARN VARCHAR2(100) := '*Has Commercial';
    
    -- The combination of trait attributes and crop could not matched in the
    -- lexicon trait stack name xref table. This isn't an error, but these
    -- differences will need to be reconsiled.
    INVALID_TRAIT_STACK VARCHAR2(100) := '*Invalid Trait Stack';
    
    -- If there are 2 or more products that have the same pre commercial name
    DUP_PCNAME VARCHAR2(100) := '*Duplicate PC Name';
    
    /***** Pre Commercial Name Source Constants *****/
    -- The source for the pre commercial name was a Midas pre commercial name record
    MIDAS_PC_NAME_SOURCE VARCHAR2(50) := 'Midas PC Name';
    
    -- The source for the pre commercial name was a Mirage pre commercial name record
    MIRAGE_PC_NAME_SOURCE VARCHAR2(50) := 'Mirage PC Name';

    -- The source for the pre commercial name was a Midas commercial name record
    MIDAS_COML_NAME_SOURCE VARCHAR2(50) := 'Midas Coml Name';

    -- The source for the pre commercial name was the germplasm line code
    LINE_CODE_NAME_SOURCE VARCHAR2(50) := 'Line Code';
    
    -- The source for the pre commercial name was not found so the name that is
    -- used is the literal unknown plus a sequence number
    NAME_SOURCE_NOTFOUND VARCHAR2(50) := 'Unknown';



    /*
        This procedure initializes trace logging and determines the run number
        used to identify a run in the trace log.
    */
    PROCEDURE Start_Trace_P;
    
    /*
        This procedure stops trace logging and ends a given trace number.
    */
    PROCEDURE End_Trace_P;
    
    /*
        This procedure removes all records from the staging tables
    */
    PROCEDURE Truncate_Conversion_Tables_P;
    
    /*
        This procedure loads crop information from the various systems into
        the crop staging tables.  These tables act as cross reference for
        converted crop ids from one system to another, but have the advantage
        of being located in a single instance.
    */
    PROCEDURE Load_Crop_Staging_P;
    
    /*
        This procedure loads bayer code information from the various systems into
        the bayer code staging tables.  These tables act as cross reference for
        converted crop ids from one system to another, but have the advantage
        of being located in a single instance.
    */
    PROCEDURE Load_Bayer_Code_Staging_P;

    /*
        This procedure loads brand information from the various systems into
        the brand staging tables.  These tables act as cross reference for
        converted brand ids from one system to another, but have the advantage
        of being located in a single instance.
    */
    PROCEDURE Load_Brand_Staging_P;

    /*
        This procedure loads country information from the various systems into
        the country staging tables.  These tables act as cross reference for
        converted country ids from one system to another, but have the advantage
        of being located in a single instance.
    */
    PROCEDURE Load_Country_Staging_P;

    /*
        This procedure loads stage information from the various systems into
        the stage staging tables.  These tables act as cross reference for
        converted stage ids from one system to another, but have the advantage
        of being located in a single instance.
    */
    PROCEDURE Load_Stage_Staging_P;

    /*
        This procedure loads all of the Monsanto company product name entries
        from Midas into the product name staging table.  This table is used as
        the basis for many of the following data conversion methods.  The
        validity and any Lexicon specific information of each entry is
        determined in later methods.
    */
    PROCEDURE Load_Names_Staging_P;

    /*
        This procedure loads all of the distinct products found in the product
        name staging table.  The validity and any Lexicon specific information
        of each entry is determined in later methods.
    */
    PROCEDURE Load_Product_Staging_P;
    
    /*
        Loads all germplasm associated with all Monsanto products found in
        Midas into the germplasm staging table.  The validity of each entry is
        determined in later methods.
    */
    PROCEDURE Load_Germplasm_Staging_P;

    /*
        This procedure loads all of the Monsanto company seed product entries
        from Mirage into the seed product name staging table.  This table is used
        as the basis for many of the following data conversion methods.  The
        validity and any Lexicon specific information of each entry is
        determined in later methods.
    */
    PROCEDURE Load_Seed_Products_Staging_P;

    /*
        This procedure load the maturity and attributes from yield mart into
        the product name staging rows.
    */
    PROCEDURE Load_Product_Attributes_P;

    /*
        Validates the germplasm entries in the germplasm staging table.
        1) Validates that the germplasm associated with a given product are
           consistent (i.e. all Hybrid or all Inbred line types)
        2) Determines the line code of the finished germplasm with lowest id or
           if no finished germplasm are available, the line code of the
           germplasm of lowest coded germplasm.
    */
    PROCEDURE Validate_Germplasm_P;
    
    /*
        Validates the product entries in the product staging table.
        1) Validates that the product is active
        2) Validates that the crop is active
        3) Validates that the crop is a valid Lexicon crop
        4) Validates that there is at least 1 germplasm associated with it
        5) Determines the lexicon crop id of all valid entries
    */
    PROCEDURE Validate_Product_P;

    /*
        Validates the product name entries in the product name staging table.
        1) Validates that the brand is active
        2) Validates that the country is active
        3) Validates that the brand is a valid Lexicon brand
        4) Validates that the country is a valid Lexicon country
        5) Translates the stage into a valid Lexicon stage
        6) Determines the Lexicon brand id
        7) Determines the Lexicon country id
        8) Determines the Lexicon stage id
        9) Determines whether the entry is active in Lexicon
    */
    PROCEDURE Validate_Product_Name_P;
    
    /*
        Validates the seed product entries in the seed product staging table.
        1) Validates that the bayer code is tied to a crop found in Lexicon
        2) Validates that the company is a valid Lexicon brand
        3) Validates that the country is a valid Lexicon country
        4) Determines the Lexicon brand id
        5) Determines the Lexicon country id
    */
    PROCEDURE Validate_Seed_Product_P;
    
    /*
        This procedure validates that there are no duplicate seed products
        with the same bayer code, brand, and country.
    */
    PROCEDURE Validate_No_Dup_Seed_Product_P;
    
    /*
        This procedure attempts to match the stack names loaded from yield mart
        to a trait stack id in lexicon.  If it is unable to find a match based
        on the stack name and the crop a warning is generated.
    */
    PROCEDURE Validate_Product_Attributes_P;
    
    /*
        This procudure validates that for every valid product there is at
        least 1 valid product name.
    */
    PROCEDURE Validate_Has_Valid_Name_P;

    /*
    */
    PROCEDURE PC_Name_From_PC_Entry_P;
    PROCEDURE PC_Name_From_Mirage_PC_Entry_P;
    PROCEDURE PC_Name_From_Coml_Entry_P;
    PROCEDURE PC_Name_From_Line_Code_P;
    PROCEDURE PC_Name_From_Unknown_P;
    
    /*
        This procedure determines finds all duplicate pre commercial names
        that were determined in the above procedures and mark them as errors.
    */
    PROCEDURE Validate_Dup_PCName_P;

    /*
        If I told you I'd have to kill you
    */
    PROCEDURE Map_Mir_Has_Midas_Prod_Error_P;

    /*
        This procedure determines whether a valid mirage seed product has a
        link to a midas product via map product mirage.  This information will
        be used to synchronize the FBS Common tables and potentially add
        additional product name(stage) records to Lexicon.
    */
    PROCEDURE Determine_SP_Midas_Link_P;
    
    /*
        This procedure determines whether a valid pre commercial seed product
        entry has a commercial seed product entry (i.e. an entry that has the
        same product id and country id).  Those entries that have commercial
        equivalent will not be added to Lexicon.
    */
    PROCEDURE Determine_Mirage_Coml_Equiv_P;
    
    /*
        This procedure determines whether a valid pre commercial product name
        entry has a commercial product name entry (i.e. an entry that has the
        same product id and country id).  Those entries that have commercial
        equivalent will not be added to Lexicon (or FBS Common or Mirage)
    */
    PROCEDURE Determine_Coml_Equiv_P;
    
    /*
        This procedure determines whether a valid mirage seed product has a
        link to a midas product name via matching midas product id, product name,
        brand, and country.  Matching brand and country are determined by
        matching lexicon ids in the respective staging tables.  This information
        is used to initialize the FBS Common product tables in a later method.
    */
    PROCEDURE Determine_SP_PN_Link_P;
    
    /*
        This procedure finds all valid commercial Mirage products that are
        linked to Midas products in Map Product Mirage but have no corresponding
        valid commercial Midas Product Name entry (ie same product id,
        same country, same brand)
    */
    PROCEDURE Determine_Unmatch_Mirage_Com_P;
    
    /*
        This procedure finds all Mirage pre commercial products that don't
        have commercial versions for a country in Mirage, but does have a
        commercial version for that country in Midas
    */
    PROCEDURE Determine_Mir_PCN_Midas_Coml_P;

    
    /*
        This procedure assigns a lexicon id and public key to all valid
        product entries in the staging table.
    */
    PROCEDURE Assign_Lexicon_Products_P;

    /*
        This procedure assigns a lexicon id and public key to all valid
        product name entries in the staging table.
    */
    PROCEDURE Assign_Lex_Names_From_Midas_P;

    /*
        This procedure assigns a lexicon id and public key to all valid pre
        commercial Mirage seed product entries in the staging table that aren't
        already with a Mirage valid commercial name entry or with a valid Midas
        product name entry.
    */
    PROCEDURE Assign_Lex_Names_From_Mirage_P;

    /*
        This procedure set the lexicon product name id in the seed product
        staging table for products that were found and valid in both Midas
        and Mirage.
    */
    PROCEDURE Link_Common_Names_P;
    
    /*
        This procedure insert products into the lexicon database from staging
    */
    PROCEDURE Insert_Lexicon_Products_P;
    
    /*
        This procedure insert names into the lexicon database from staging
    */
    PROCEDURE Insert_Lexicon_Midas_Names_P;
    
    /*
        This procedure insert names into the lexicon database from Mirage staging
    */
    PROCEDURE Insert_Mirage_Only_Names_P;
    
    /*
        This procedure insert products into the fbs common mapping table
    */
    PROCEDURE Insert_FBS_Common_Products_P;
    
    /*
        This procedure insert product names into the fbs common mapping table
    */
    PROCEDURE Insert_FBS_Common_Names_P;
    
    
    /*************************************************************************
            The following procedures perform the acutal inserts
    *************************************************************************/
    PROCEDURE Actual_Prod_Inserts_P;
    PROCEDURE Actual_Name_Inserts_P;
    PROCEDURE Actual_Prod_Xref_Inserts_P;
    PROCEDURE Actual_Name_Xref_Inserts_P;
    PROCEDURE Actual_Prod_GP_Insert_P;
END MPDL_PKG;
/


