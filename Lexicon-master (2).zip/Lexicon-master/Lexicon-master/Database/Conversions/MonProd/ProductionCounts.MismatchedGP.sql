SELECT  '"' || P.product_id || '"'AS ProductId,
		Cr.name AS CropName,
		'"' || GP.germplasm_id || '"' AS GermplasmId,
		GP.pedigree_name AS Pedigree,
		LT.line_type_ref_id AS LineTypeRefId
  FROM  Midas.Product P,
        Midas.Crop Cr,
        Midas.Product_Germplasm PGP,
        Midas.Germplasm GP,
        Midas.Line_Type LT,
        (SELECT  DISTINCT P.product_id
           FROM  Midas.Product P,
                 Midas.Product_Name PN,
                 Midas.Brand Br,
                 Midas.Company Cm
          WHERE  P.ref_active = 'T'
            AND  P.product_id = PN.product_id
          	AND  PN.ref_active = 'T'
		    AND  PN.brand_id = Br.brand_id
		    AND  Br.ref_active = 'T'
		    AND  Br.company_id = Cm.company_id
		    AND  Cm.ref_active = 'T'
		    AND  Cm.name = 'MONSANTO'
		) MonProdName,                 
        (SELECT  DISTINCT P.product_id
           FROM  Midas.Product P,
                 Midas.Product_Germplasm PGP,
                 Midas.Germplasm GP,
                 Midas.Line_Type LT
		  WHERE  P.ref_active = 'T'
		    AND  P.product_id = PGP.product_id
		    AND  PGP.germplasm_id = GP.germplasm_id
		    AND  GP.line_type_id = LT.line_type_id
		    AND  LT.line_type_ref_id = 'HYBRID'
		) Hybrids,
        (SELECT  DISTINCT P.product_id
           FROM  Midas.Product P,
                 Midas.Product_Germplasm PGP,
                 Midas.Germplasm GP,
                 Midas.Line_Type LT
		  WHERE  P.ref_active = 'T'
		    AND  P.product_id = PGP.product_id
		    AND  PGP.germplasm_id = GP.germplasm_id
		    AND  GP.line_type_id = LT.line_type_id
		    AND  (LT.line_type_ref_id = 'FINISHED' OR LT.line_type_ref_id = 'CODED')
		) Inbreds
 WHERE  P.product_id = PGP.product_id
   AND  P.crop_id = Cr.crop_id
   AND  PGP.germplasm_id = GP.germplasm_id
   AND  GP.line_type_id = LT.line_type_id
   AND  P.product_id = Hybrids.product_id
   AND  P.product_id = Inbreds.product_id
   AND  P.product_id = MonProdName.product_id
ORDER BY P.product_id
