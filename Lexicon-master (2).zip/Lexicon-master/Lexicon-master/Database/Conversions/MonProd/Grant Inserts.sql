GRANT INSERT ON Lexicon.Pre_Coml_Product TO Ngscho
/

GRANT INSERT ON Lexicon.Product_Stage TO Ngscho
/

