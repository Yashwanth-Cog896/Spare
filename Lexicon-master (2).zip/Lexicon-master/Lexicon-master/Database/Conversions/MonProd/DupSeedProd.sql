SELECT  SSP.other1 AS "Group Number", 
        SSP.seed_product_id AS "Seed Product ID", 
	    SSP.product_name AS "Proudct Name", 
	    SSP.bayer_code AS "Bayer Code", 
	    SSP.company_id AS "Company ID", 
	    SSP.country_code AS "Country Code",
	    '''' || SSP.midas_product_id || '''' AS "Midas Product ID"
  FROM  Staging_Seed_Product SSP
 WHERE  SSP.other1 IS NOT NULL
   AND  SSP.error LIKE '*Dup%'
   AND  SSP.enabled = 'Y'
ORDER BY TO_NUMBER(SSP.other1);

/*
UPDATE  Staging_Seed_Product
   SET  error = '*Duplicate Seed Product(Disabled)'
 WHERE  other1 IS NOT NULL
   AND  enabled = 'N';
   
UPDATE  Staging_Seed_Product
   SET  error = '*Duplicate Seed Product(Enabled)'
 WHERE  other1 IS NOT NULL
   AND  enabled = 'Y';   
*/
