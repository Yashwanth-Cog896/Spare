SELECT  '''' || SPN.midas_product_id || '''' "Midas Product ID",
        '''' || SPN.midas_product_name_id || '''' "Midas Product Name ID",
        SSP.seed_product_id AS "Seed Product ID",
        SPN.product_name AS "Midas Name",
        SSP.product_Name AS "Mirage Name",
        SPN.crop_name AS "Crop Name",
        SPN.brand_name AS "Brand Name",
        SPN.country_name AS "Country Name",
        DECODE(SSP.enabled, 'Y', 'YES', 'NO') AS "Enabled"
  FROM  Staging_Product_Name SPN, 
        Staging_Seed_Product SSP
 WHERE  SPN.lexicon_id = SSP.lexicon_name_id
   AND  SSP.warning = '*Name mismatch'
ORDER BY SSP.enabled DESC;

SELECT  *
  FROM  Staging_Seed_Product SSP
 WHERE  SSP.warning IS NOT NULL;
 
 
