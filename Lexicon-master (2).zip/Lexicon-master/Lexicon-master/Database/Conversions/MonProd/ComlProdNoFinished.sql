SELECT  '''' || SP.midas_product_id || '''' AS "Midas Product ID",
        SP.crop_name AS "Crop Name"
  FROM  Staging_Product SP,
        (SELECT  DISTINCT SPN.midas_product_id
           FROM  Staging_Product_Name SPN 
          WHERE  SPN.error IS NULL
            AND  SPN.is_true_commercial_brand = 'y'
        ) GSPN
 WHERE  SP.midas_product_id = GSPN.midas_product_id
   AND  SP.primary_gp_line_type = 'HYBRID'
   AND  SP.other1 = 'n'
 ORDER BY SP.crop_name, SP.midas_product_id
   

