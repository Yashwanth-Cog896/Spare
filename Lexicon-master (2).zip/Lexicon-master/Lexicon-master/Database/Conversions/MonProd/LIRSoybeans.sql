SELECT  
--        DISTINCT
        SP.pre_commercial_name AS "Lexicon Pre Commercial Name"
        ,SP.primary_gp_line_code AS "Line Code"
        ,SP.midas_product_id AS "Midas Product Id"
        ,SPN.midas_product_name_id AS "Midas Product Name Id"
        ,SPN.product_name AS "Midas Pre Commercial Name"
        ,SPN.brand_name AS "Midas Brand Name"
  FROM  Staging_Product SP
        ,(
            SELECT  SPN.*
              FROM  Staging_Product_Name SPN
             WHERE  NVL(SPN.error, '*Has Commercial') = '*Has Commercial'
			   AND  SPN.crop_name = 'SOYBEANS'
			   AND  SPN.is_pre_commercial_brand = 'y'
        ) SPN
 WHERE  SP.error IS NULL
   AND  SP.crop_name = 'SOYBEANS'
--   AND  SP.name_source = 'Midas Coml Name'
   AND  SP.primary_gp_line_code IS NOT NULL
   AND  SP.midas_product_id = SPN.midas_product_id (+)
   AND  SPN.midas_product_id IS NULL
ORDER BY SP.pre_commercial_name
      
