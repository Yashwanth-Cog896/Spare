SELECT  SPN.error AS "Error", 
        '''' || SPN.midas_product_id || '''' AS "Midas Product Id",
        '''' || SPN.midas_product_name_id || '''' AS "Midas Product Name Id",
        '''' || SPN.midas_brand_id || '''' AS "Midas Brand Id",
        B.name AS "Midas Brand",
        B.ref_active AS "Brand Active"
  FROM  Staging_Product_Name SPN,
        Midas_Brand B
 WHERE  SPN.midas_brand_id = B.brand_id
   AND  SPN.error like '%Invalid Brand%'
ORDER BY SPN.error, 
         B.name,
		 SPN.midas_product_id, 
		 SPN.midas_product_name_id;


 
 

