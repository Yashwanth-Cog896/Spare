BEGIN
  Mpdl_Pkg.Start_Trace_P;
  BEGIN
    Mpdl_Pkg.Truncate_Conversion_Tables_P;

    Mpdl_Pkg.Load_Crop_Staging_P;
    Mpdl_Pkg.Load_Bayer_Code_Staging_P;
    Mpdl_Pkg.Load_Brand_Staging_P;
    Mpdl_Pkg.Load_Country_Staging_P;
    Mpdl_Pkg.Load_Stage_Staging_P;

    Mpdl_Pkg.Load_Names_Staging_P;
    Mpdl_Pkg.Load_Product_Staging_P;
    Mpdl_Pkg.Load_Germplasm_Staging_P;
    Mpdl_Pkg.Load_Seed_Products_Staging_P;
    Mpdl_Pkg.Load_Product_Attributes_P;

    Mpdl_Pkg.Validate_Germplasm_P;
    Mpdl_Pkg.Validate_Product_P;
    Mpdl_Pkg.Validate_Product_Name_P;
    Mpdl_Pkg.Validate_Has_Valid_Name_P;
    Mpdl_Pkg.Validate_Seed_Product_P;
    Mpdl_Pkg.Determine_SP_Midas_Link_P;
    Mpdl_Pkg.Validate_No_Dup_Seed_Product_P;

    Mpdl_Pkg.Determine_Coml_Equiv_P;
    Mpdl_Pkg.Determine_Mirage_Coml_Equiv_P;
    Mpdl_Pkg.Determine_SP_PN_Link_P;
    Mpdl_Pkg.Determine_Unmatch_Mirage_Com_P;
    Mpdl_Pkg.Determine_Mir_PCN_Midas_Coml_P;
    Mpdl_Pkg.Validate_Product_Attributes_P;

    Mpdl_Pkg.Assign_Lexicon_Products_P;
    Mpdl_Pkg.Assign_Lex_Names_From_Midas_P;
    Mpdl_Pkg.Assign_Lex_Names_From_Mirage_P;
    Mpdl_Pkg.Link_Common_Names_P;

    Mpdl_Pkg.PC_Name_From_PC_Entry_P;
    Mpdl_Pkg.PC_Name_From_Mirage_PC_Entry_P;
    Mpdl_Pkg.PC_Name_From_Coml_Entry_P;
    Mpdl_Pkg.PC_Name_From_Line_Code_P;
    Mpdl_Pkg.PC_Name_From_Unknown_P;
    Mpdl_Pkg.Validate_Dup_PCName_P;
    Mpdl_Pkg.Map_Mir_Has_Midas_Prod_Error_P;
	
    Mpdl_Pkg.Insert_Lexicon_Products_P;
    Mpdl_Pkg.Insert_Lexicon_Midas_Names_P;
    Mpdl_Pkg.Insert_Mirage_Only_Names_P;
    Mpdl_Pkg.Insert_FBS_Common_Products_P;
    Mpdl_Pkg.Insert_FBS_Common_Names_P;
  END;
  Mpdl_Pkg.End_Trace_P;

END;




