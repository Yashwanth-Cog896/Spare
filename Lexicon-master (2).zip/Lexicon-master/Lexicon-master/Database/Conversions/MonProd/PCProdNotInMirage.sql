SELECT  '''' || SPN.midas_product_id || '''' AS "Midas Product Id",
        '''' || SPN.midas_product_name_id  || '''' AS "Midas Product Name Id",
        SPN.product_name AS "Product Name",
        SPN.crop_name AS "Crop Name",
		SPN.brand_name AS "Brand Name",
		SPN.country_name AS "Country Name"
  FROM  Staging_Product_Name SPN,
        Temp_Prod_Name TPN,
        Staging_Seed_Product SSP
 WHERE  SPN.is_pre_commercial_brand = 'y'
   AND  SPN.pubkey = TPN.product_stage_pubkey
   AND	SPN.lexicon_id = SSP.lexicon_name_id (+)
   AND  SSP.seed_product_id IS NULL
   AND  ROWNUM < 100;
   

  
  
