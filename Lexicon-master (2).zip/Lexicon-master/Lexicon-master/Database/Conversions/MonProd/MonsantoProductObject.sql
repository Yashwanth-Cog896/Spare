CREATE TABLE Lexicon.Stage
    (Stage_Id                       NUMBER NOT NULL,
    Stage_Abbr                     VARCHAR2(4) NOT NULL,
    Stage_Desc                     VARCHAR2(50) NOT NULL,
    Order_By_Num                   NUMBER,
    Is_Coml_Stage                  VARCHAR2(1) NOT NULL,
    Stage_Pubkey                   VARCHAR2(20) NOT NULL
  ,
  CONSTRAINT STAGE_PK
  PRIMARY KEY (Stage_Id)
  USING INDEX
  TABLESPACE  Lexicon_Index)
  TABLESPACE  Lexicon_Data
/

GRANT DELETE ON Lexicon.Stage TO Lexicon_User
/
GRANT INSERT ON Lexicon.Stage TO Lexicon_User
/
GRANT SELECT ON Lexicon.Stage TO Lexicon_User
/
GRANT UPDATE ON Lexicon.Stage TO Lexicon_User
/
GRANT DELETE ON Lexicon.Stage TO Ngscho
/
GRANT INSERT ON Lexicon.Stage TO Ngscho
/
GRANT SELECT ON Lexicon.Stage TO Ngscho
/
GRANT UPDATE ON Lexicon.Stage TO Ngscho
/


ALTER TABLE Lexicon.Stage
ADD CONSTRAINT Stage_Ak1 UNIQUE (Stage_Abbr)
USING INDEX
  TABLESPACE  Lexicon_Index
/

ALTER TABLE Lexicon.Stage
ADD CONSTRAINT True_Or_False_Stage CHECK (is_coml_stage IN ('y', 'n'))
/

ALTER TABLE Lexicon.Stage
ADD CONSTRAINT Stage_Ak3 UNIQUE (Stage_Pubkey)
USING INDEX
  TABLESPACE  Lexicon_Index
/

ALTER TABLE Lexicon.Stage
ADD CONSTRAINT Stage_Unique_Order_By_Num UNIQUE (Order_By_Num)
USING INDEX
  TABLESPACE  Lexicon_Data
/

CREATE TRIGGER Lexicon.Stage_Trg
 AFTER
  INSERT OR DELETE OR UPDATE
 ON Lexicon.Stage
REFERENCING NEW AS NEW OLD AS OLD
 FOR EACH ROW
DECLARE
  lOperationType CHAR(1);
  lPrimaryKeyPosition INTEGER := 1;
  lTableName VARCHAR2(30) := 'STAGE';
  lAuditDetailArray Audit_Pkg.Audit_Detail_Array_Type;

BEGIN
  IF Audit_Pkg.Do_Audit_Table_F(lTableName) THEN

    IF INSERTING THEN lOperationType := Audit_Pkg.INSERT_OPERATION;
    ELSIF UPDATING THEN lOperationType := Audit_Pkg.UPDATE_OPERATION;
    ELSIF DELETING THEN lOperationType := Audit_Pkg.DELETE_OPERATION;
    ELSE lOperationType := NULL;
    END IF;

    lAuditDetailArray(1) := Audit_Pkg.Create_Detail_Record_F('STAGE_ID', :NEW.STAGE_ID, :OLD.STAGE_ID);
    lAuditDetailArray(2) := Audit_Pkg.Create_Detail_Record_F('STAGE_ABBR', :NEW.STAGE_ABBR, :OLD.STAGE_ABBR);
    lAuditDetailArray(3) := Audit_Pkg.Create_Detail_Record_F('STAGE_DESC', :NEW.STAGE_DESC, :OLD.STAGE_DESC);
    lAuditDetailArray(4) := Audit_Pkg.Create_Detail_Record_F('ORDER_BY_NUM', :NEW.ORDER_BY_NUM, :OLD.ORDER_BY_NUM);
    lAuditDetailArray(5) := Audit_Pkg.Create_Detail_Record_F('IS_COML_STAGE', :NEW.IS_COML_STAGE, :OLD.IS_COML_STAGE);
    lAuditDetailArray(6) := Audit_Pkg.Create_Detail_Record_F('STAGE_PUBKEY', :NEW.STAGE_PUBKEY, :OLD.STAGE_PUBKEY);

    Audit_Pkg.Write_Audit_P(lTableName , lOperationType, lPrimaryKeyPosition, lAuditDetailArray);
  END IF;
END;
/

CREATE TABLE Lexicon.Pre_Coml_Product
    (Product_Id                     NUMBER NOT NULL,
    Product_Pubkey                 VARCHAR2(20) NOT NULL,
    Pre_Coml_Name                  VARCHAR2(40) NOT NULL,
    Crop_Id                        NUMBER NOT NULL,
    Ustv_Name                      VARCHAR2(40)
  ,
  CONSTRAINT PRE_COML_PRODUCT_PK
  PRIMARY KEY (Product_Id)
  USING INDEX
  TABLESPACE  Lexicon_Index)
  TABLESPACE  Lexicon_Data
/

GRANT DELETE ON Lexicon.Pre_Coml_Product TO Lexicon_User
/
GRANT INSERT ON Lexicon.Pre_Coml_Product TO Lexicon_User
/
GRANT SELECT ON Lexicon.Pre_Coml_Product TO Lexicon_User
/
GRANT UPDATE ON Lexicon.Pre_Coml_Product TO Lexicon_User
/
GRANT DELETE ON Lexicon.Pre_Coml_Product TO Ngscho
/
GRANT INSERT ON Lexicon.Pre_Coml_Product TO Ngscho
/
GRANT SELECT ON Lexicon.Pre_Coml_Product TO Ngscho
/
GRANT UPDATE ON Lexicon.Pre_Coml_Product TO Ngscho
/


ALTER TABLE Lexicon.Pre_Coml_Product
ADD CONSTRAINT Pre_Coml_Product_Ak1 UNIQUE (Product_Pubkey)
USING INDEX
  TABLESPACE  Lexicon_Index
/

ALTER TABLE Lexicon.Pre_Coml_Product
ADD CONSTRAINT Pre_Coml_Product_Ak2 UNIQUE (Ustv_Name)
USING INDEX
  TABLESPACE  Lexicon_Index
/

ALTER TABLE Lexicon.Pre_Coml_Product
ADD CONSTRAINT Pre_Coml_Product_Ak3 UNIQUE (Pre_Coml_Name)
USING INDEX
  TABLESPACE  Lexicon_Index
/


CREATE TRIGGER Lexicon.Pre_Coml_Product_Trg
 AFTER
  INSERT OR DELETE OR UPDATE
 ON Lexicon.Pre_Coml_Product
REFERENCING NEW AS NEW OLD AS OLD
 FOR EACH ROW
DECLARE
  lOperationType CHAR(1);
  lPrimaryKeyPosition INTEGER := 1;
  lTableName VARCHAR2(30) := 'PRE_COML_PRODUCT';
  lAuditDetailArray Audit_Pkg.Audit_Detail_Array_Type;

BEGIN
  IF Audit_Pkg.Do_Audit_Table_F(lTableName) THEN

    IF INSERTING THEN lOperationType := Audit_Pkg.INSERT_OPERATION;
    ELSIF UPDATING THEN lOperationType := Audit_Pkg.UPDATE_OPERATION;
    ELSIF DELETING THEN lOperationType := Audit_Pkg.DELETE_OPERATION;
    ELSE lOperationType := NULL;
    END IF;

    lAuditDetailArray(1) := Audit_Pkg.Create_Detail_Record_F('PRODUCT_ID', :NEW.PRODUCT_ID, :OLD.PRODUCT_ID);
    lAuditDetailArray(2) := Audit_Pkg.Create_Detail_Record_F('PRODUCT_PUBKEY', :NEW.PRODUCT_PUBKEY, :OLD.PRODUCT_PUBKEY);
    lAuditDetailArray(3) := Audit_Pkg.Create_Detail_Record_F('PRE_COML_NAME', :NEW.PRE_COML_NAME, :OLD.PRE_COML_NAME);
    lAuditDetailArray(4) := Audit_Pkg.Create_Detail_Record_F('CROP_ID', :NEW.CROP_ID, :OLD.CROP_ID);
    lAuditDetailArray(5) := Audit_Pkg.Create_Detail_Record_F('USTV_NAME', :NEW.USTV_NAME, :OLD.USTV_NAME);

    Audit_Pkg.Write_Audit_P(lTableName , lOperationType, lPrimaryKeyPosition, lAuditDetailArray);
  END IF;
END;
/

ALTER TABLE Lexicon.Pre_Coml_Product
ADD CONSTRAINT Fk_Pcp_Crop_Cropid FOREIGN KEY (Crop_Id)
REFERENCES LEXICON.Crop (Crop_Id)
/

CREATE TABLE Lexicon.Product_Stage
    (Product_Stage_Id               NUMBER NOT NULL,
    Product_Stage_Pubkey           VARCHAR2(20) NOT NULL,
    Product_Id                     NUMBER NOT NULL,
    Country_Id                     NUMBER NOT NULL,
    Brand_Id                       NUMBER NOT NULL,
    Stage_Id                       NUMBER NOT NULL,
    Commercial_Name                VARCHAR2(40),
    Test_Name                      VARCHAR2(40),
    Oecd_Reqd_Name                 VARCHAR2(40),
    Commercial_Maturity            NUMBER(6,1),
    Is_Active                      VARCHAR2(1) NOT NULL,
    Coml_Trait_Stack_Id            NUMBER
  ,
  CONSTRAINT PRODUCT_STAGE_PK
  PRIMARY KEY (Product_Stage_Id)
  USING INDEX
  TABLESPACE  Lexicon_Index)
  TABLESPACE  Lexicon_Data
/

GRANT DELETE ON Lexicon.Product_Stage TO Lexicon_User
/
GRANT INSERT ON Lexicon.Product_Stage TO Lexicon_User
/
GRANT SELECT ON Lexicon.Product_Stage TO Lexicon_User
/
GRANT UPDATE ON Lexicon.Product_Stage TO Lexicon_User
/
GRANT DELETE ON Lexicon.Product_Stage TO Ngscho
/
GRANT INSERT ON Lexicon.Product_Stage TO Ngscho
/
GRANT SELECT ON Lexicon.Product_Stage TO Ngscho
/
GRANT UPDATE ON Lexicon.Product_Stage TO Ngscho
/



ALTER TABLE Lexicon.Product_Stage
ADD CONSTRAINT Product_Stage_Ak1 UNIQUE (Product_Stage_Pubkey)
USING INDEX
  TABLESPACE  Lexicon_Index
/

ALTER TABLE Lexicon.Product_Stage
ADD CONSTRAINT Product_Stage_Ak2 UNIQUE (Product_Id, Country_Id, Brand_Id)
USING INDEX
  TABLESPACE  Lexicon_Index
/


ALTER TABLE Lexicon.Product_Stage
ADD CONSTRAINT Trueorfalseps CHECK (is_active IN ('y', 'n'))
/




CREATE TRIGGER Lexicon.Product_Stage_Trg
 AFTER
  INSERT OR DELETE OR UPDATE
 ON Lexicon.Product_Stage
REFERENCING NEW AS NEW OLD AS OLD
 FOR EACH ROW
DECLARE
  lOperationType CHAR(1);
  lPrimaryKeyPosition INTEGER := 2;
  lTableName VARCHAR2(30) := 'PRODUCT_STAGE';
  lAuditDetailArray Audit_Pkg.Audit_Detail_Array_Type;

BEGIN
  IF Audit_Pkg.Do_Audit_Table_F(lTableName) THEN

    IF INSERTING THEN lOperationType := Audit_Pkg.INSERT_OPERATION;
    ELSIF UPDATING THEN lOperationType := Audit_Pkg.UPDATE_OPERATION;
    ELSIF DELETING THEN lOperationType := Audit_Pkg.DELETE_OPERATION;
    ELSE lOperationType := NULL;
    END IF;

    lAuditDetailArray(1) := Audit_Pkg.Create_Detail_Record_F('COML_TRAIT_STACK_ID', :NEW.COML_TRAIT_STACK_ID, :OLD.COML_TRAIT_STACK_ID);
    lAuditDetailArray(2) := Audit_Pkg.Create_Detail_Record_F('PRODUCT_STAGE_ID', :NEW.PRODUCT_STAGE_ID, :OLD.PRODUCT_STAGE_ID);
    lAuditDetailArray(3) := Audit_Pkg.Create_Detail_Record_F('PRODUCT_STAGE_PUBKEY', :NEW.PRODUCT_STAGE_PUBKEY, :OLD.PRODUCT_STAGE_PUBKEY);
    lAuditDetailArray(4) := Audit_Pkg.Create_Detail_Record_F('PRODUCT_ID', :NEW.PRODUCT_ID, :OLD.PRODUCT_ID);
    lAuditDetailArray(5) := Audit_Pkg.Create_Detail_Record_F('COUNTRY_ID', :NEW.COUNTRY_ID, :OLD.COUNTRY_ID);
    lAuditDetailArray(6) := Audit_Pkg.Create_Detail_Record_F('BRAND_ID', :NEW.BRAND_ID, :OLD.BRAND_ID);
    lAuditDetailArray(7) := Audit_Pkg.Create_Detail_Record_F('STAGE_ID', :NEW.STAGE_ID, :OLD.STAGE_ID);
    lAuditDetailArray(8) := Audit_Pkg.Create_Detail_Record_F('COMMERCIAL_NAME', :NEW.COMMERCIAL_NAME, :OLD.COMMERCIAL_NAME);
    lAuditDetailArray(9) := Audit_Pkg.Create_Detail_Record_F('TEST_NAME', :NEW.TEST_NAME, :OLD.TEST_NAME);
    lAuditDetailArray(10) := Audit_Pkg.Create_Detail_Record_F('OECD_REQD_NAME', :NEW.OECD_REQD_NAME, :OLD.OECD_REQD_NAME);
    lAuditDetailArray(11) := Audit_Pkg.Create_Detail_Record_F('COMMERCIAL_MATURITY', :NEW.COMMERCIAL_MATURITY, :OLD.COMMERCIAL_MATURITY);
    lAuditDetailArray(12) := Audit_Pkg.Create_Detail_Record_F('IS_ACTIVE', :NEW.IS_ACTIVE, :OLD.IS_ACTIVE);

    Audit_Pkg.Write_Audit_P(lTableName , lOperationType, lPrimaryKeyPosition, lAuditDetailArray);
  END IF;
END;
/

ALTER TABLE Lexicon.Product_Stage
ADD CONSTRAINT Fk_Prod_Stage_Coml_Trt_Stck_Id FOREIGN KEY (Coml_Trait_Stack_Id)
REFERENCES LEXICON.Coml_Trait_Stack (Coml_Trait_Stack_Id)
/
ALTER TABLE Lexicon.Product_Stage
ADD CONSTRAINT Fk_Ps_Pcprod_Prodid FOREIGN KEY (Product_Id)
REFERENCES LEXICON.Pre_Coml_Product (Product_Id)
/
ALTER TABLE Lexicon.Product_Stage
ADD CONSTRAINT Fk_Ps_Country_Countryid FOREIGN KEY (Country_Id)
REFERENCES LEXICON.Country (Country_Id)
/
ALTER TABLE Lexicon.Product_Stage
ADD CONSTRAINT Fk_Ps_Brand_Brandid FOREIGN KEY (Brand_Id)
REFERENCES LEXICON.Brand (Brand_Id)
/
ALTER TABLE Lexicon.Product_Stage
ADD CONSTRAINT Fk_Ps_Stage_Stageid FOREIGN KEY (Stage_Id)
REFERENCES LEXICON.Stage (Stage_Id)
/

CREATE SEQUENCE Lexicon.Pre_Coml_Product_Id_Seq
  INCREMENT BY 1
  START WITH 1000
  MINVALUE 1
  MAXVALUE 999999999999999999999999999
  NOCYCLE
  NOORDER
  CACHE 30
/

GRANT SELECT ON Lexicon.Pre_Coml_Product_Id_Seq TO Lexicon_User
/
GRANT SELECT ON Lexicon.Pre_Coml_Product_Id_Seq TO Ngscho
/

CREATE SEQUENCE Lexicon.Pre_Coml_Product_Pubkey_Seq
  INCREMENT BY 100
  START WITH 1009
  MINVALUE 1
  MAXVALUE 999999999999999999999999999
  NOCYCLE
  NOORDER
  CACHE 30
/

GRANT SELECT ON Lexicon.Pre_Coml_Product_Pubkey_Seq TO Lexicon_User
/
GRANT SELECT ON Lexicon.Pre_Coml_Product_Pubkey_Seq TO Ngscho
/

CREATE SEQUENCE Lexicon.Product_Stage_Id_Seq
  INCREMENT BY 1
  START WITH 1000
  MINVALUE 1
  MAXVALUE 999999999999999999999999999
  NOCYCLE
  NOORDER
  CACHE 30
/

GRANT SELECT ON Lexicon.Product_Stage_Id_Seq TO Lexicon_User
/
GRANT SELECT ON Lexicon.Product_Stage_Id_Seq TO Ngscho
/

CREATE SEQUENCE Lexicon.Product_Stage_Pubkey_Seq
  INCREMENT BY 100
  START WITH 1012
  MINVALUE 1
  MAXVALUE 999999999999999999999999999
  NOCYCLE
  NOORDER
  CACHE 30
/

GRANT SELECT ON Lexicon.Product_Stage_Pubkey_Seq TO Lexicon_User
/
GRANT SELECT ON Lexicon.Product_Stage_Pubkey_Seq TO Ngscho
/

