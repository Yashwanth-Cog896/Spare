SELECT  SSP.seed_product_id AS "Seed Product ID",
        SSP.product_Name AS "Product Name",
        SSP.bayer_code AS "Bayer Code",
        SSP.company_id AS "Company ID",
        SSP.country_code AS "Country Code",
        DECODE(SSP.enabled, 'Y', 'YES', 'NO') AS "Enabled",
        '''' || SSP.midas_product_id || '''' "Midas Product ID"
  FROM  Staging_Seed_Product SSP
 WHERE  SSP.error = '*No Midas Commercial'
ORDER BY SSP.enabled DESC, 
         SSP.seed_product_id;
 
