BEGIN
    DECLARE
        CURSOR prodCurs IS 
            SELECT  SP.*
              FROM  Staging_Product SP
             WHERE  SP.warning = '*Duplicate PC Name'
             ORDER  BY SP.pre_commercial_name;
             
        CURSOR nameCurs IS
            SELECT  SPN.*
              FROM  Staging_Product_Name SPN
             WHERE  SPN.warning = '*Duplicate PC Name';
             
        idx INTEGER := 0;
    BEGIN
        FOR rec IN prodCurs LOOP
            idx := idx + 1;
            UPDATE  Staging_Product
               SET  pre_commercial_name = pre_commercial_name || '-DUP' || TRIM(TO_CHAR(idx, '09'))
             WHERE  midas_product_id = rec.midas_product_id;
        END LOOP;
        
        FOR rec IN nameCurs LOOP
            UPDATE  Staging_Product_Name
               SET  lexicon_id = Lex_Prod_Name_Id_Seq.NEXTVAL,
                    pubkey = Lex_Prod_Name_Pubkey_Seq.NEXTVAL
             WHERE  midas_product_name_id = rec.midas_product_name_id;
        END LOOP;
    END;
END;
