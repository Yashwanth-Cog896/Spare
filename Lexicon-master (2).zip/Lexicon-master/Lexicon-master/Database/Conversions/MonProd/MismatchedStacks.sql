SELECT  SPN.crop_name AS "Crop Name",
        SPN.other2 AS "Stack Name",
		'''' || SPN.midas_product_name_id || '''' AS "Midas Product Name Id",        
		SPN.product_name AS "Product Name",
		SPN.brand_name AS "Brand Name",
		SPN.country_name AS "Country Name",
		SSP.seed_product_id AS "Seed Product Id"
  FROM  Staging_Product_Name SPN,
        Staging_Seed_Product SSP
 WHERE  SPN.error IS NULL
   AND  SPN.other2 IS NOT NULL
   AND  SPN.other3 IS NULL
   AND  SPN.lexicon_id = SSP.lexicon_name_id (+)
 ORDER BY SPN.crop_name,
          SPN.other2,
          SPN.midas_product_name_id
