CREATE TABLE Lexicon.Mpdl_Bayer_Code
    (Lexicon_Crop_Id                NUMBER,
    Midas_Crop_Id                  NUMBER,
    Mirage_Bayer_Code              VARCHAR2(6),
    Is_Midas_Crop                  VARCHAR2(1),
    Other1                         VARCHAR2(100))
  TABLESPACE  Lexicon_Data
/

GRANT DELETE ON Lexicon.Mpdl_Bayer_Code TO Ngscho
/
GRANT INSERT ON Lexicon.Mpdl_Bayer_Code TO Ngscho
/
GRANT SELECT ON Lexicon.Mpdl_Bayer_Code TO Ngscho
/
GRANT UPDATE ON Lexicon.Mpdl_Bayer_Code TO Ngscho
/

CREATE TABLE Lexicon.Mpdl_Brand
    (Lexicon_Id                     NUMBER,
    Midas_Id                       NUMBER,
    Mirage_Company_Id              NUMBER,
    Brand_Name                     VARCHAR2(50),
    Public_Key                     VARCHAR2(20),
    Is_Pre_Commercial              VARCHAR2(1) DEFAULT 'n',
    Is_True_Commercial             VARCHAR2(1) DEFAULT 'y',
    Other1                         VARCHAR2(100))
  TABLESPACE  Lexicon_Data
/

GRANT DELETE ON Lexicon.Mpdl_Brand TO Ngscho
/
GRANT INSERT ON Lexicon.Mpdl_Brand TO Ngscho
/
GRANT SELECT ON Lexicon.Mpdl_Brand TO Ngscho
/
GRANT UPDATE ON Lexicon.Mpdl_Brand TO Ngscho
/


CREATE UNIQUE INDEX Lexicon.Mpdl_Brand_Idx_Mirage_Id ON Lexicon.Mpdl_Brand
  (
    Mirage_Company_Id               ASC
  )
  TABLESPACE  Lexicon_Index
/

CREATE UNIQUE INDEX Lexicon.Mpdl_Brand_Idx_Name ON Lexicon.Mpdl_Brand
  (
    Brand_Name                      ASC
  )
  TABLESPACE  Lexicon_Index
/

CREATE UNIQUE INDEX Lexicon.Mpdl_Brand_Idx_Midas_Id ON Lexicon.Mpdl_Brand
  (
    Midas_Id                        ASC
  )
  TABLESPACE  Lexicon_Index
/

CREATE TABLE Lexicon.Mpdl_Country
    (Lexicon_Id                     NUMBER,
    Midas_Id                       NUMBER,
    Mirage_Code                    VARCHAR2(50),
    Country_Name                   VARCHAR2(50),
    Public_Key                     VARCHAR2(20),
    Other1                         VARCHAR2(100))
  TABLESPACE  Lexicon_Data
/

GRANT DELETE ON Lexicon.Mpdl_Country TO Ngscho
/
GRANT INSERT ON Lexicon.Mpdl_Country TO Ngscho
/
GRANT SELECT ON Lexicon.Mpdl_Country TO Ngscho
/
GRANT UPDATE ON Lexicon.Mpdl_Country TO Ngscho
/


CREATE UNIQUE INDEX Lexicon.Mpdl_Country_Idx_Lex_Id ON Lexicon.Mpdl_Country
  (
    Lexicon_Id                      ASC
  )
  TABLESPACE  Lexicon_Index
/

CREATE UNIQUE INDEX Lexicon.Mpdl_Country_Idx_Midas_Id ON Lexicon.Mpdl_Country
  (
    Midas_Id                        ASC
  )
  TABLESPACE  Lexicon_Index
/

CREATE TABLE Lexicon.Mpdl_Crop
    (Lexicon_Crop_Id                NUMBER,
    Midas_Crop_Id                  NUMBER,
    Crop_Name                      VARCHAR2(50),
    Other1                         VARCHAR2(100))
  TABLESPACE  Lexicon_Data
/

GRANT DELETE ON Lexicon.Mpdl_Crop TO Ngscho
/
GRANT INSERT ON Lexicon.Mpdl_Crop TO Ngscho
/
GRANT SELECT ON Lexicon.Mpdl_Crop TO Ngscho
/
GRANT UPDATE ON Lexicon.Mpdl_Crop TO Ngscho
/


CREATE UNIQUE INDEX Lexicon.Mpdl_Crop_Idx_Midas_Id ON Lexicon.Mpdl_Crop
  (
    Midas_Crop_Id                   ASC
  )
  TABLESPACE  Lexicon_Index
/

CREATE TABLE Lexicon.Mpdl_Germplasm
    (Midas_Product_Id               NUMBER,
    Germplasm_Id                   NUMBER,
    Line_Type_Ref_Id               VARCHAR2(20),
    Line_Code                      VARCHAR2(4000),
    Pedigree                       VARCHAR2(4000),
    Error                          VARCHAR2(4000),
    Warning                        VARCHAR2(4000),
    Other1                         VARCHAR2(100),
    Other2                         VARCHAR2(100))
  TABLESPACE  Lexicon_Data
/

GRANT DELETE ON Lexicon.Mpdl_Germplasm TO Ngscho
/
GRANT INSERT ON Lexicon.Mpdl_Germplasm TO Ngscho
/
GRANT SELECT ON Lexicon.Mpdl_Germplasm TO Ngscho
/
GRANT UPDATE ON Lexicon.Mpdl_Germplasm TO Ngscho
/


CREATE INDEX Lexicon.Mpdl_Germplasm_Idx_Product_Id ON Lexicon.Mpdl_Germplasm
  (
    Midas_Product_Id                ASC
  )
  TABLESPACE  Lexicon_Index
/

CREATE INDEX Lexicon.Mpdl_Gp_Idx_Pedigree ON Lexicon.Mpdl_Germplasm
  (
    Pedigree                        ASC
  )
  TABLESPACE  Lexicon_Index
/

CREATE TABLE Lexicon.Mpdl_Product
    (Lexicon_Id                     NUMBER,
    Pubkey                         VARCHAR2(20),
    Pre_Commercial_Name            VARCHAR2(50),
    Name_Source                    VARCHAR2(50),
    Midas_Product_Id               NUMBER,
    Product_Ref_Active             VARCHAR2(1),
    Lexicon_Crop_Id                NUMBER,
    Midas_Crop_Id                  NUMBER,
    Crop_Name                      VARCHAR2(50),
    Crop_Ref_Active                VARCHAR2(1),
    Primary_Gp_Line_Type           VARCHAR2(20),
    Primary_Gp_Line_Code           VARCHAR2(4000),
    Primary_Gp_Is_Inbred           VARCHAR2(1),
    Error                          VARCHAR2(4000),
    Warning                        VARCHAR2(4000),
    Other1                         VARCHAR2(100),
    Other2                         VARCHAR2(100),
    Other3                         VARCHAR2(100))
  TABLESPACE  Lexicon_Data
/

GRANT DELETE ON Lexicon.Mpdl_Product TO Ngscho
/
GRANT INSERT ON Lexicon.Mpdl_Product TO Ngscho
/
GRANT SELECT ON Lexicon.Mpdl_Product TO Ngscho
/
GRANT UPDATE ON Lexicon.Mpdl_Product TO Ngscho
/


CREATE UNIQUE INDEX Lexicon.Mpdl_Product_Idx_Midas_Id ON Lexicon.Mpdl_Product
  (
    Midas_Product_Id                ASC
  )
  TABLESPACE  Lexicon_Index
/

CREATE INDEX Lexicon.Mpdl_Product_Idx_Mids ON Lexicon.Mpdl_Product
  (
    Midas_Product_Id                ASC,
    Midas_Crop_Id                   ASC
  )
  TABLESPACE  Lexicon_Index
/

CREATE TABLE Lexicon.Mpdl_Product_Name
    (Lexicon_Id                     NUMBER,
    Pubkey                         VARCHAR2(20),
    Midas_Product_Id               NUMBER,
    Product_Ref_Active             VARCHAR2(1),
    Midas_Product_Name_Id          NUMBER,
    Product_Name                   VARCHAR2(50),
    Midas_Crop_Id                  NUMBER,
    Crop_Name                      VARCHAR2(50),
    Crop_Ref_Active                VARCHAR2(1),
    Lexicon_Brand_Id               NUMBER,
    Midas_Brand_Id                 NUMBER,
    Brand_Name                     VARCHAR2(50),
    Brand_Ref_Active               VARCHAR2(1),
    Is_Pre_Commercial_Brand        VARCHAR2(1),
    Is_True_Commercial_Brand       VARCHAR2(1),
    Company_Ref_Active             VARCHAR2(1),
    Lexicon_Country_Id             NUMBER,
    Midas_Country_Id               NUMBER,
    Country_Name                   VARCHAR2(50),
    Country_Ref_Active             VARCHAR2(1),
    Lexicon_Stage_Id               NUMBER,
    Lexicon_Stage_Active_Flag      VARCHAR2(1),
    Midas_Stage_Id                 NUMBER,
    Midas_Stage_Ref_Id             VARCHAR2(20),
    Stage_Ref_Active               VARCHAR2(1),
    Midas_Is_Stage_Active          VARCHAR2(1),
    Commercial_Name                VARCHAR2(50),
    Commercial_Equivalent_Id       NUMBER,
    Error                          VARCHAR2(4000),
    Warning                        VARCHAR2(4000),
    Other1                         VARCHAR2(100),
    Other2                         VARCHAR2(100),
    Other3                         VARCHAR2(100))
  TABLESPACE  Lexicon_Data
/

GRANT DELETE ON Lexicon.Mpdl_Product_Name TO Ngscho
/
GRANT INSERT ON Lexicon.Mpdl_Product_Name TO Ngscho
/
GRANT SELECT ON Lexicon.Mpdl_Product_Name TO Ngscho
/
GRANT UPDATE ON Lexicon.Mpdl_Product_Name TO Ngscho
/


CREATE UNIQUE INDEX Lexicon.Mpdl_Product_Name_Idx_Midas_Id ON Lexicon.Mpdl_Product_Name
  (
    Midas_Product_Name_Id           ASC
  )
  TABLESPACE  Lexicon_Index
/

CREATE UNIQUE INDEX Lexicon.Mpdl_Product_Name_Idx_Mids ON Lexicon.Mpdl_Product_Name
  (
    Midas_Product_Name_Id           ASC,
    Midas_Country_Id                ASC,
    Midas_Brand_Id                  ASC
  )
  TABLESPACE  Lexicon_Index
/

CREATE TABLE Lexicon.Mpdl_Product_Name_Xref
    (Lexicon_Product_Name_Pubkey    VARCHAR2(20) NOT NULL,
    Midas_Product_Name_Id          NUMBER(*,0),
    Mirage_Product_Id              NUMBER
  ,
  CONSTRAINT MPDL_PRODUCT_NAME_XREF_PK
  PRIMARY KEY (Lexicon_Product_Name_Pubkey)
  USING INDEX
  TABLESPACE  Lexicon_Index)
  TABLESPACE  Lexicon_Data
/

GRANT DELETE ON Lexicon.Mpdl_Product_Name_Xref TO Ngscho
/
GRANT INSERT ON Lexicon.Mpdl_Product_Name_Xref TO Ngscho
/
GRANT SELECT ON Lexicon.Mpdl_Product_Name_Xref TO Ngscho
/
GRANT UPDATE ON Lexicon.Mpdl_Product_Name_Xref TO Ngscho
/

CREATE TABLE Lexicon.Mpdl_Product_Xref
    (Lexicon_Product_Pubkey         VARCHAR2(20) NOT NULL,
    Midas_Product_Id               NUMBER(*,0)
  ,
  CONSTRAINT MPDL_PRODUCT_XREF_PK
  PRIMARY KEY (Lexicon_Product_Pubkey)
  USING INDEX
  TABLESPACE  Lexicon_Index)
  TABLESPACE  Lexicon_Data
/

GRANT DELETE ON Lexicon.Mpdl_Product_Xref TO Ngscho
/
GRANT INSERT ON Lexicon.Mpdl_Product_Xref TO Ngscho
/
GRANT SELECT ON Lexicon.Mpdl_Product_Xref TO Ngscho
/
GRANT UPDATE ON Lexicon.Mpdl_Product_Xref TO Ngscho
/

CREATE TABLE Lexicon.Mpdl_Seed_Product
    (Seed_Product_Id                NUMBER,
    Midas_Product_Id               NUMBER,
    Midas_Product_Name_Id          NUMBER,
    Lexicon_Name_Id                NUMBER,
    Lexicon_Pubkey                 VARCHAR2(50),
    Product_Name                   VARCHAR2(50),
    Bayer_Code                     VARCHAR2(6),
    Lexicon_Crop_Id                NUMBER,
    Company_Id                     NUMBER,
    Lexicon_Brand_Id               NUMBER,
    Is_Pre_Commercial_Brand        VARCHAR2(1),
    Country_Code                   VARCHAR2(3),
    Lexicon_Country_Id             NUMBER,
    Enabled                        VARCHAR2(1),
    Reverse_Equivalent_Id          NUMBER,
    Commercial_Equivalent_Id       NUMBER,
    Error                          VARCHAR2(4000),
    Warning                        VARCHAR2(4000),
    Other1                         VARCHAR2(100),
    Other2                         VARCHAR2(100),
    Other3                         VARCHAR2(100))
  TABLESPACE  Lexicon_Data
/

GRANT DELETE ON Lexicon.Mpdl_Seed_Product TO Ngscho
/
GRANT INSERT ON Lexicon.Mpdl_Seed_Product TO Ngscho
/
GRANT SELECT ON Lexicon.Mpdl_Seed_Product TO Ngscho
/
GRANT UPDATE ON Lexicon.Mpdl_Seed_Product TO Ngscho
/


CREATE INDEX Lexicon.Mpdl_Seed_Prod_Idx_Bcc ON Lexicon.Mpdl_Seed_Product
  (
    Bayer_Code                      ASC,
    Country_Code                    ASC,
    Company_Id                      ASC
  )
  TABLESPACE  Lexicon_Index
/

CREATE UNIQUE INDEX Lexicon.Mpdl_Seed_Prod_Idx_Spid ON Lexicon.Mpdl_Seed_Product
  (
    Seed_Product_Id                 ASC
  )
  TABLESPACE  Lexicon_Index
/

CREATE TABLE Lexicon.Mpdl_Stage
    (Midas_Stage_Id                 NUMBER,
    Midas_Ref_Id                   VARCHAR2(50),
    Lex_Pc_Stage_Id                NUMBER,
    Lex_Coml_Stage_Id              NUMBER,
    Lex_Stage_Active               VARCHAR2(1))
  TABLESPACE  Lexicon_Data
/

GRANT DELETE ON Lexicon.Mpdl_Stage TO Ngscho
/
GRANT INDEX ON Lexicon.Mpdl_Stage TO Ngscho
/
GRANT INSERT ON Lexicon.Mpdl_Stage TO Ngscho
/
GRANT SELECT ON Lexicon.Mpdl_Stage TO Ngscho
/
GRANT UPDATE ON Lexicon.Mpdl_Stage TO Ngscho
/


CREATE UNIQUE INDEX Lexicon.Mpdl_Stage_Idx_Ref_Id ON Lexicon.Mpdl_Stage
  (
    Midas_Ref_Id                    ASC
  )
  TABLESPACE  Lexicon_Index
/

CREATE TABLE Lexicon.Mpdl_Temp_Pcp
    (Product_Id                     NUMBER NOT NULL,
    Product_Pubkey                 VARCHAR2(20) NOT NULL,
    Pre_Coml_Name                  VARCHAR2(40) NOT NULL,
    Crop_Id                        NUMBER NOT NULL,
    Ustv_Name                      VARCHAR2(40)
  ,
  CONSTRAINT MPDL_PCP_PK
  PRIMARY KEY (Product_Id)
  USING INDEX
  TABLESPACE  Lexicon_Index)
  TABLESPACE  Lexicon_Data
/

GRANT DELETE ON Lexicon.Mpdl_Temp_Pcp TO Ngscho
/
GRANT INSERT ON Lexicon.Mpdl_Temp_Pcp TO Ngscho
/
GRANT SELECT ON Lexicon.Mpdl_Temp_Pcp TO Ngscho
/
GRANT UPDATE ON Lexicon.Mpdl_Temp_Pcp TO Ngscho
/


ALTER TABLE Lexicon.Mpdl_Temp_Pcp
ADD CONSTRAINT Mpdl_Pcpt_Ak1 UNIQUE (Product_Pubkey)
USING INDEX
  TABLESPACE  Lexicon_Index
/

ALTER TABLE Lexicon.Mpdl_Temp_Pcp
ADD CONSTRAINT Mpdl_Pcp_Ak2 UNIQUE (Ustv_Name)
USING INDEX
  TABLESPACE  Lexicon_Index
/


ALTER TABLE Lexicon.Mpdl_Temp_Pcp
ADD CONSTRAINT Fk_Mdpl_Pcp_Crop_Cropid FOREIGN KEY (Crop_Id)
REFERENCES LEXICON.Crop (Crop_Id)
/

CREATE TABLE Lexicon.Mpdl_Temp_Stage
    (Product_Stage_Id               NUMBER NOT NULL,
    Product_Stage_Pubkey           VARCHAR2(20) NOT NULL,
    Product_Id                     NUMBER NOT NULL,
    Country_Id                     NUMBER NOT NULL,
    Brand_Id                       NUMBER NOT NULL,
    Stage_Id                       NUMBER NOT NULL,
    Commercial_Name                VARCHAR2(40),
    Test_Name                      VARCHAR2(40),
    Oecd_Reqd_Name                 VARCHAR2(40),
    Commercial_Maturity            NUMBER(6,1),
    Is_Active                      VARCHAR2(1) NOT NULL,
    Coml_Trait_Stack_Id            NUMBER
  ,
  CONSTRAINT MPDL_TEMP_STAGE_PK
  PRIMARY KEY (Product_Stage_Id)
  USING INDEX
  TABLESPACE  Lexicon_Index)
  TABLESPACE  Lexicon_Data
/

GRANT DELETE ON Lexicon.Mpdl_Temp_Stage TO Ngscho
/
GRANT INSERT ON Lexicon.Mpdl_Temp_Stage TO Ngscho
/
GRANT SELECT ON Lexicon.Mpdl_Temp_Stage TO Ngscho
/
GRANT UPDATE ON Lexicon.Mpdl_Temp_Stage TO Ngscho
/


ALTER TABLE Lexicon.Mpdl_Temp_Stage
ADD CONSTRAINT Mpdl_Temp_Stage_Ak1 UNIQUE (Product_Stage_Pubkey)
USING INDEX
  TABLESPACE  Lexicon_Index
/

ALTER TABLE Lexicon.Mpdl_Temp_Stage
ADD CONSTRAINT Mpdl_Temp_Stage_Ak2 UNIQUE (Product_Id, Country_Id, Brand_Id)
USING INDEX
  TABLESPACE  Lexicon_Index
/





ALTER TABLE Lexicon.Mpdl_Temp_Stage
ADD CONSTRAINT Trueorfalseps2 CHECK (is_active IN ('y', 'n'))
/


ALTER TABLE Lexicon.Mpdl_Temp_Stage
ADD CONSTRAINT Fk_Ps_Pcprod_Prodid2 FOREIGN KEY (Product_Id)
REFERENCES LEXICON.Mpdl_Temp_Pcp (Product_Id)
/
ALTER TABLE Lexicon.Mpdl_Temp_Stage
ADD CONSTRAINT Fk_Ps_Country_Countryid2 FOREIGN KEY (Country_Id)
REFERENCES LEXICON.Country (Country_Id)
/
ALTER TABLE Lexicon.Mpdl_Temp_Stage
ADD CONSTRAINT Fk_Ps_Brand_Brandid2 FOREIGN KEY (Brand_Id)
REFERENCES LEXICON.Brand (Brand_Id)
/
ALTER TABLE Lexicon.Mpdl_Temp_Stage
ADD CONSTRAINT Fk_Ps_Stage_Stageid2 FOREIGN KEY (Stage_Id)
REFERENCES LEXICON.Stage (Stage_Id)
/
ALTER TABLE Lexicon.Mpdl_Temp_Stage
ADD CONSTRAINT Fk_Prod_Stage_Ctst_Id2 FOREIGN KEY (Coml_Trait_Stack_Id)
REFERENCES LEXICON.Coml_Trait_Stack (Coml_Trait_Stack_Id)
/

CREATE TABLE Lexicon.Mpdl_Trace_Log
    (Run_Number                     NUMBER NOT NULL,
    Procedure_Number               NUMBER,
    Procedure_Name                 VARCHAR2(32) NOT NULL,
    Start_Time                     TIMESTAMP (6),
    End_Time                       TIMESTAMP (6)
  ,
  CONSTRAINT MPDL_TRACE_PK
  PRIMARY KEY (Run_Number, Procedure_Name)
  USING INDEX
  TABLESPACE  Lexicon_Index)
  TABLESPACE  Lexicon_Data
/

GRANT DELETE ON Lexicon.Mpdl_Trace_Log TO Ngscho
/
GRANT INSERT ON Lexicon.Mpdl_Trace_Log TO Ngscho
/
GRANT SELECT ON Lexicon.Mpdl_Trace_Log TO Ngscho
/
GRANT UPDATE ON Lexicon.Mpdl_Trace_Log TO Ngscho
/


