SELECT  SP.pre_commercial_name AS "Pre Commercial Name", 
        SP.name_source AS "Name Source", 
        '''' || SP.midas_product_id || '''' AS "Midas Product Id",
        '''' || SPN.midas_product_name_id || '''' AS "Product Name Id",
        SPN.product_name AS "Midas Name",
        SSP.seed_product_id "Seed Product Id",
        SSP.product_name AS "Mirage Name",
        SP.crop_name "Crop",
        SPN.brand_name AS "Brand",
        SPN.country_name AS "Country",
        DECODE(NVL(SSP.seed_product_id, ''), '', 'Not In Mirage', 
			DECODE(NVL(SSP.error,''), '*Has Commercial', 'Yes', 'No')) 
				AS "Has Mirage Coml Name"
  FROM  Staging_Product SP,
        Staging_Product_Name SPN,
        Staging_Seed_Product SSP
 WHERE  SP.error = '*Duplicate PC Name'
   AND  SP.midas_product_id = SPN.midas_product_id
   AND  SPN.error = '*Duplicate PC Name'
   AND  SPN.midas_product_name_id = SSP.midas_product_name_id (+)

UNION 

SELECT  SP.pre_commercial_name AS "Pre Commercial Name", 
        SP.name_source AS "Name Source", 
        '''' || SP.midas_product_id || '''' AS "Midas Product Id",
        NULL AS "Product Name Id",
        NULL AS "Midas Name",
        SSP.seed_product_id "Seed Product Id",
        SSP.product_name AS "Mirage Name",
        SP.crop_name "Crop",
        SB.brand_name AS "Brand",
        UPPER(SC.country_name) AS "Country",
        DECODE(NVL(SSP.seed_product_id, ''), '', 'Not In Mirage', 
			DECODE(NVL(SSP.error,''), '*Has Commercial', 'Yes', 'No')) 
				AS "Has Mirage Coml Name"
  FROM  Staging_Product SP,
        Staging_Seed_Product SSP,
        Staging_Brand SB,
        Staging_Country SC
 WHERE  SP.error = '*Duplicate PC Name'
   AND  SP.midas_product_id = SSP.midas_product_id
   AND  SSP.midas_product_name_id IS NULL
   AND  NVL(SSP.error, '*Has Commercial') = '*Has Commercial'
   AND  SSP.company_id = SB.mirage_company_id
   AND  SSP.country_code = SC.mirage_code

ORDER BY "Pre Commercial Name", 
         "Midas Product Id",
         "Country",
         "Midas Name"
  
