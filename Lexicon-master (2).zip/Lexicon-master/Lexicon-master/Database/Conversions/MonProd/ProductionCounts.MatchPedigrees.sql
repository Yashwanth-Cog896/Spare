SELECT  BIQ.pedigree_name AS PedigreeName, 
        '"' || P.product_id || '"' AS ProductId,
        '"' || BIQ.germplasm_id || '"' AS GermplasmId
  FROM  Midas.Product P,
        Midas.Product_Name PN,
        Midas.Brand B,
        Midas.Company C,
		(SELECT DISTINCT 
		        P.product_id, 
		        GP.pedigree_name,
		        GP.germplasm_id,
		        Other.product_id other_product_id
		  FROM  Midas.Germplasm GP,
		        Midas.Product_Germplasm PGP,
		        Midas.Product P,
		        Midas.Product_Name PN,
		        Midas.Brand B,
		        Midas.Company C,
		        (SELECT  GP.pedigree_name,
		                 PGP.product_id
		           FROM  Midas.Germplasm GP,
		                 Midas.Product_Germplasm PGP,
		                 Midas.Product P,
		                 Midas.Product_Name PN,
		                 Midas.Brand B,
		                 Midas.Company C
		          WHERE  GP.germplasm_id = PGP.germplasm_id
		            AND  GP.pedigree_name IS NOT NULL
		            AND  GP.germplasm_id = PGP.germplasm_id
		            AND  PGP.product_id = P.product_id
		            AND  P.ref_active = 'T'
		            AND  PGP.product_id = PN.product_id
		            AND  PN.ref_active = 'T'
		            AND  PN.brand_id = B.brand_id
		            AND  B.ref_active = 'T'
		            AND  B.company_id = C.company_id
		            AND  C.name = 'MONSANTO'
		        ) Other
		 WHERE  GP.pedigree_name IS NOT NULL
		   AND  GP.germplasm_id = PGP.germplasm_id
		   AND  PGP.product_id = P.product_id
		   AND  P.ref_active = 'T'
		   AND  PGP.product_id = PN.product_id
		   AND  PN.ref_active = 'T'
		   AND  PN.brand_id = B.brand_id
		   AND  B.ref_active = 'T'
		   AND  B.company_id = C.company_id
		   AND  C.name = 'MONSANTO'
		   AND  GP.pedigree_name = Other.pedigree_name
		   AND  PGP.product_id <> Other.product_id
		 ORDER  BY GP.pedigree_name
		) BIQ
 WHERE  P.product_id = BIQ.product_id
   AND  P.ref_active = 'T'
   AND  P.product_id = PN.product_id
   AND  PN.ref_active = 'T'
   AND  PN.brand_id = B.brand_id
   AND  B.ref_active = 'T'
   AND  B.company_id = C.company_id
   AND  C.name = 'MONSANTO'
 GROUP  BY BIQ.pedigree_name, 
           P.product_id,
           BIQ.germplasm_id
           
		   


