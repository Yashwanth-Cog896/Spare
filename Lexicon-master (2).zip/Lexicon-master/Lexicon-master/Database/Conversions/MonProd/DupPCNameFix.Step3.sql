INSERT 
  INTO  Temp_Product(
            PRODUCT_ID,
            PRODUCT_PUBKEY,
            PRE_COML_NAME, 
            CROP_ID
        )
        ( 
            SELECT  SP.lexicon_id,
                    SP.pubkey,
                    SP.pre_commercial_name,
                    SP.lexicon_crop_id
              FROM  Staging_Product SP
             WHERE  SP.warning = '*Duplicate PC Name'
			   AND  SP.pre_commercial_name like '%-DUP__'
        );

INSERT 
  INTO  Temp_Prod_Name(
            PRODUCT_STAGE_ID, 
            PRODUCT_STAGE_PUBKEY,
            PRODUCT_ID,
            COUNTRY_ID,
            BRAND_ID,
            STAGE_ID,
            COMMERCIAL_NAME,
            COMMERCIAL_MATURITY,
            IS_ACTIVE,
            COML_TRAIT_STACK_ID
        )
  		(
	        SELECT  SPN.lexicon_id AS ProductNameId,
    	            SPN.pubkey AS PublicKey,
        	        SP.lexicon_id AS ProductId,
            	    SPN.lexicon_country_id AS CountryId,
	                SPN.lexicon_brand_id AS BrandId,
    	            SPN.lexicon_stage_id AS StageId,
        	        DECODE(SPN.is_pre_commercial_brand, 'y', NULL, SPN.product_name) AS CommercialName,
	                SPN.other1 AS ComlMaturity,
	                SPN.lexicon_stage_active_flag AS IsActive,
	                SPN.other3 AS StackId
	          FROM  Staging_Product_Name SPN,
    	            Staging_Product SP
	         WHERE  SPN.warning = '*Duplicate PC Name'
			   AND  SPN.midas_product_id = SP.midas_product_id 
			   AND  SP.pre_commercial_name like '%-DUP__'
	    );

INSERT 
  INTO  Temp_Prod_Xref(
            LEXICON_PRODUCT_PUBKEY,
            MIDAS_PRODUCT_ID
        )  		
  		(
	        SELECT  SP.pubkey AS PublicKey,
    	            SP.midas_product_id AS MidasProductId
        	  FROM  Staging_Product SP
             WHERE  SP.warning = '*Duplicate PC Name'
			   AND  SP.pre_commercial_name like '%-DUP__'
		);

INSERT
  INTO  Temp_Prod_Name_Xref(
            LEXICON_PRODUCT_NAME_PUBKEY,
            MIDAS_PRODUCT_NAME_ID,
            MIRAGE_PRODUCT_ID
        )
  		(
			SELECT  SPN.pubkey AS PublicKey,
        	        SPN.midas_product_name_id AS MidasProductNameId,
                    NULL AS SeedProductId
	          FROM  Staging_Product_Name SPN,
    	            Staging_Product SP
	         WHERE  SPN.warning = '*Duplicate PC Name'
			   AND  SPN.midas_product_id = SP.midas_product_id 
			   AND  SP.pre_commercial_name like '%-DUP__'
		);  		
