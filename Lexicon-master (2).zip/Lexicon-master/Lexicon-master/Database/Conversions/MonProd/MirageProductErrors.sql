SELECT  NVL(SSP.error, SSP.warning) AS "Error/Warning",
        '''' || SSP.seed_product_id || '''' AS "Seed Product Id",
        '''' || SSP.midas_product_id || ''''  AS "Midas Product Id",
        SSP.product_name AS "Product Name",
        SSP.bayer_code AS "Bayer Code",
        Cmp.company_name AS "Company Name",
        Cnt.country_name AS "Country Name",
        SSP.enabled AS "Enabled"
  FROM  Staging_Seed_Product SSP,
        Mirage2.companies@ceregn.monsanto.com Cmp,
        Mirage2.countries@ceregn.monsanto.com Cnt
 WHERE  (SSP.error IS NOT NULL OR SSP.warning IS NOT NULL)
   AND  SSP.error <> '*Has Commercial'
   AND  SSP.company_id = Cmp.company_id
   AND  SSP.country_code = Cnt.country_code
ORDER BY SSP.error, 
         SSP.warning, 
         SSP.midas_product_id,
         SSP.bayer_code,
         Cmp.company_name,
         Cnt.country_name,
         SSP.product_name

 
