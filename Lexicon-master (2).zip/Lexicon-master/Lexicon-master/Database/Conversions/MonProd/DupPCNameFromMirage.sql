SELECT  SP.pre_commercial_name,
        SP.name_source,
        SP.midas_product_id,
        MIN(NVL(SSP.seed_product_id, 0))
  FROM  Staging_Product SP,
        Staging_Seed_Product SSP
 WHERE  SP.pre_commercial_name IN 
        (
        SELECT  SP.pre_commercial_name
          FROM  Staging_Seed_Product SSP,
                Staging_Product SP
         WHERE  SSP.error = '*Midas Product Has Error'
           AND  SP.error = '*Duplicate PC Name'
           AND  SSP.midas_product_id = SP.midas_product_id
        )
   AND  SP.midas_product_id = SSP.midas_product_id (+)
GROUP BY SP.pre_commercial_name, SP.name_source, SP.midas_product_id

