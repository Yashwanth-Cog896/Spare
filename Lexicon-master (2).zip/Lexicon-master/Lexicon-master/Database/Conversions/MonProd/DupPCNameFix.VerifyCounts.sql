SELECT *
  FROM Lexicon.Pre_Coml_Product PCP
 WHERE PCP.pre_coml_name like '%-DUP__';
 
SELECT *
  FROM Lexicon.Product_Stage PS,
       Lexicon.Pre_Coml_Product PCP
 WHERE PS.product_id = PCP.product_id 
   AND PCP.pre_coml_name like '%-DUP__';
   
SELECT *
  FROM Lexicon.Product_GP_Action PGPA,
       Lexicon.Pre_Coml_Product PCP
 WHERE PGPA.product_pubkey = PCP.product_pubkey
   AND PCP.pre_coml_name like '%-DUP__';
   
SELECT *
  FROM FBS_Prod_Xref PX,
       Lexicon.Pre_Coml_Product PCP
 WHERE PX.lexicon_product_pubkey = PCP.product_pubkey
   AND PCP.pre_coml_name like '%-DUP__';  
   
SELECT *
  FROM FBS_Prod_Name_Xref PNX,
       Lexicon.Product_Stage PS,
       Lexicon.Pre_Coml_Product PCP
 WHERE PNX.lexicon_product_name_pubkey = PS.product_stage_pubkey
   AND PS.product_id = PCP.product_id 
   AND PCP.pre_coml_name like '%-DUP__';
       
