BEGIN
    DECLARE
        partyID      NUMBER;
        loginName    VARCHAR2(100) := 'JASKIDI';
        process      VARCHAR2(100) := 'DATA LOAD';
        auditComment VARCHAR2(100) := 'Initial load of data';
        requestor    VARCHAR2(100) := 'TENEUM';
        
    BEGIN
        SELECT  object_id
          INTO  partyID
          FROM  Mon_Ldap_Security.Monsanto_Secure_User 
         WHERE  UPPER(user_name) = loginName;

        Lexicon.Audit_Pkg.initialize_staging_p(partyID, process, auditcomment, requestor);

insert into Storage_Condition(STORAGE_CONDITION_ID, STORAGE_CONDITION, Active_Status) VALUES (STORAGE_COND_ID_SEQ.nextval,unistr('- 10\00B0C'),'y');
insert into Storage_Condition(STORAGE_CONDITION_ID, STORAGE_CONDITION, Active_Status) VALUES (STORAGE_COND_ID_SEQ.nextval,unistr('- 20\00B0C'),'y');
insert into Storage_Condition(STORAGE_CONDITION_ID, STORAGE_CONDITION, Active_Status) VALUES (STORAGE_COND_ID_SEQ.nextval,unistr('- 20\00B0C / 25%RH'),'y');
insert into Storage_Condition(STORAGE_CONDITION_ID, STORAGE_CONDITION, Active_Status) VALUES (STORAGE_COND_ID_SEQ.nextval,unistr('- 30\00B0C'),'y');
insert into Storage_Condition(STORAGE_CONDITION_ID, STORAGE_CONDITION, Active_Status) VALUES (STORAGE_COND_ID_SEQ.nextval,unistr('- 80\00B0C'),'y');
insert into Storage_Condition(STORAGE_CONDITION_ID, STORAGE_CONDITION, Active_Status) VALUES (STORAGE_COND_ID_SEQ.nextval,unistr('0\00B0C'),'y');
insert into Storage_Condition(STORAGE_CONDITION_ID, STORAGE_CONDITION, Active_Status) VALUES (STORAGE_COND_ID_SEQ.nextval,unistr('1-6\00B0C'),'y');
insert into Storage_Condition(STORAGE_CONDITION_ID, STORAGE_CONDITION, Active_Status) VALUES (STORAGE_COND_ID_SEQ.nextval,unistr('20\00B0C'),'y');
insert into Storage_Condition(STORAGE_CONDITION_ID, STORAGE_CONDITION, Active_Status) VALUES (STORAGE_COND_ID_SEQ.nextval,unistr('25\00B0C'),'y');
insert into Storage_Condition(STORAGE_CONDITION_ID, STORAGE_CONDITION, Active_Status) VALUES (STORAGE_COND_ID_SEQ.nextval,unistr('35\00B0C'),'y');
insert into Storage_Condition(STORAGE_CONDITION_ID, STORAGE_CONDITION, Active_Status) VALUES (STORAGE_COND_ID_SEQ.nextval,unistr('35-100\00B0F'),'y');
insert into Storage_Condition(STORAGE_CONDITION_ID, STORAGE_CONDITION, Active_Status) VALUES (STORAGE_COND_ID_SEQ.nextval,unistr('4\00B0C'),'y');
insert into Storage_Condition(STORAGE_CONDITION_ID, STORAGE_CONDITION, Active_Status) VALUES (STORAGE_COND_ID_SEQ.nextval,unistr('4\00B0C / 35%RH'),'y');
insert into Storage_Condition(STORAGE_CONDITION_ID, STORAGE_CONDITION, Active_Status) VALUES (STORAGE_COND_ID_SEQ.nextval,unistr('50\00B0C'),'y');
insert into Storage_Condition(STORAGE_CONDITION_ID, STORAGE_CONDITION, Active_Status) VALUES (STORAGE_COND_ID_SEQ.nextval,unistr('55\00B0C'),'y');
insert into Storage_Condition(STORAGE_CONDITION_ID, STORAGE_CONDITION, Active_Status) VALUES (STORAGE_COND_ID_SEQ.nextval,unistr('60\00B0C'),'y');
insert into Storage_Condition(STORAGE_CONDITION_ID, STORAGE_CONDITION, Active_Status) VALUES (STORAGE_COND_ID_SEQ.nextval,unistr('Ambient'),'y');
insert into Storage_Condition(STORAGE_CONDITION_ID, STORAGE_CONDITION, Active_Status) VALUES (STORAGE_COND_ID_SEQ.nextval,unistr('Ambient Desiccated'),'y');
insert into Storage_Condition(STORAGE_CONDITION_ID, STORAGE_CONDITION, Active_Status) VALUES (STORAGE_COND_ID_SEQ.nextval,unistr('Ambient Lab Temperature'),'y');
insert into Storage_Condition(STORAGE_CONDITION_ID, STORAGE_CONDITION, Active_Status) VALUES (STORAGE_COND_ID_SEQ.nextval,unistr('Ambient Under Nitrogen'),'y');
insert into Storage_Condition(STORAGE_CONDITION_ID, STORAGE_CONDITION, Active_Status) VALUES (STORAGE_COND_ID_SEQ.nextval,unistr('dry ice'),'y');
insert into Storage_Condition(STORAGE_CONDITION_ID, STORAGE_CONDITION, Active_Status) VALUES (STORAGE_COND_ID_SEQ.nextval,unistr('Freeze'),'y');
insert into Storage_Condition(STORAGE_CONDITION_ID, STORAGE_CONDITION, Active_Status) VALUES (STORAGE_COND_ID_SEQ.nextval,unistr('Freeze Desiccated'),'y');
insert into Storage_Condition(STORAGE_CONDITION_ID, STORAGE_CONDITION, Active_Status) VALUES (STORAGE_COND_ID_SEQ.nextval,unistr('Refrigerate'),'y');
insert into Storage_Condition(STORAGE_CONDITION_ID, STORAGE_CONDITION, Active_Status) VALUES (STORAGE_COND_ID_SEQ.nextval,unistr('Refrigerate Desiccated'),'y');
insert into Storage_Condition(STORAGE_CONDITION_ID, STORAGE_CONDITION, Active_Status) VALUES (STORAGE_COND_ID_SEQ.nextval,unistr('wet ice'),'y');

Lexicon.Audit_pkg.delete_staging_record_p;
    END;
END;