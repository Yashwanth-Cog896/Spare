BEGIN
    DECLARE
        partyID      NUMBER;
        loginName    VARCHAR2(100) := 'JASKIDI';
        process      VARCHAR2(100) := 'DATA LOAD';
        auditComment VARCHAR2(100) := 'Initial load of data';
        requestor    VARCHAR2(100) := 'TENEUM';
        
    BEGIN
        SELECT  object_id
          INTO  partyID
          FROM  Mon_Ldap_Security.Monsanto_Secure_User 
         WHERE  UPPER(user_name) = loginName;

        Lexicon.Audit_Pkg.initialize_staging_p(partyID, process, auditcomment, requestor);

insert into Shipping_Condition(SHIPPING_CONDITION_ID, SHIPPING_CONDITION, Active_Status) VALUES (SHIPPING_CONDITION_ID_SEQ.nextval,'Ambient Temp.','y');
insert into Shipping_Condition(SHIPPING_CONDITION_ID, SHIPPING_CONDITION, Active_Status) VALUES (SHIPPING_CONDITION_ID_SEQ.nextval,'Cool on Ice','y');
insert into Shipping_Condition(SHIPPING_CONDITION_ID, SHIPPING_CONDITION, Active_Status) VALUES (SHIPPING_CONDITION_ID_SEQ.nextval,'Freezer Truck','y');
insert into Shipping_Condition(SHIPPING_CONDITION_ID, SHIPPING_CONDITION, Active_Status) VALUES (SHIPPING_CONDITION_ID_SEQ.nextval,'Frozen on Dry Ice','y');

Lexicon.Audit_pkg.delete_staging_record_p;
    END;
END;