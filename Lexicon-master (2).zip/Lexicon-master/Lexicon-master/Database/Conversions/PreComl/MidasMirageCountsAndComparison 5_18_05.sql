/*
Comparison of Mirage and Midas as linked by mapping table
*/

select d.company_name as MIRAGE_BRAND,
	   f.name 		  as Midas_BRAND,
	   f.ref_active   as BRAND_REF_ACTIVE,
	   a.product_name as MIRAGE_PRODUCT_NAME,
	   c.name as MIDAS_PRODUCT_NAME,
	   a.CROP_BAYER_CODE as MIRAGE_CROP,
	   g.name 			 as MIDAS_CROP,
	   a.product_id      as MIRAGE_PK,
	   b.product_pk		 as MIDAS_PK
from mirage2.seed_products@ceregn_yldmart a,yldstg.map_product_mirage b, midas.product_name c,
	 mirage2.companies@ceregn_yldmart d, midas.product e, midas.brand f, midas.crop g
where a.product_id = b.seed_product_id
and	  b.product_pk = c.product_id
and	  a.company_id = d.company_id
and	  c.product_id = e.product_id
and   c.brand_id = f.brand_id
and	  e.crop_id = g.crop_id
and   c.ref_active = 'T'


--MIDAS:  How many unique pre-commercial names

select count(distinct a.name) from midas.product_name a, midas.brand b
where a.BRAND_ID = b.brand_id
and b.brand_id =1313179172864 
and a.ref_active = 'T'

--MIDAS:  How many unique commercial names
select count(distinct a.name) from midas.product_name a, midas.brand b
where a.BRAND_ID = b.brand_id
and a.brand_id <>1313179172864
and b.company_id = 1313148567552
and a.ref_active = 'T'

--MIRAGE:  How many unique pre-commercial names
select count( distinct product_name)
from mirage2.seed_products@ceregn_yldmart where company_id = 67
and enabled = 'Y'

--MIRAGE:  How many unique commercial names
select count( distinct product_name)
from mirage2.seed_products@ceregn_yldmart a, mirage2.companies@ceregn_yldmart b 
where a.company_id = b.company_id
and enabled = 'Y'
and company_name in (
'DEKALB',
'CORN STATES INTERNATIONAL',
'AGROCERES',
'ASGROW',
'CARNIA',
'SENSAKO',
'CERES',
'FIRST LINE',
'HARTZ',
'CORN STATES',
'MONSOY',
'HOLDEN''S',
'TITANIUM',
'NUTRILINE'
)
