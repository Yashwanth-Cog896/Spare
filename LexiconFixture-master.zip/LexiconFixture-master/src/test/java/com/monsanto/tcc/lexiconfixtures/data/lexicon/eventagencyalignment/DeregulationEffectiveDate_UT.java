package com.monsanto.tcc.lexiconfixtures.data.lexicon.eventagencyalignment;

import org.junit.Test;
import static org.junit.Assert.assertThat;
import static org.hamcrest.core.Is.is;

import java.util.Calendar;
import java.util.Date;

/**
 * nbwald - Feb 16, 2009 2:07:42 PM
 */
public class DeregulationEffectiveDate_UT
{
   @Test
   public void testParse()
      throws Exception
   {
      Date date = DeregulationEffectiveDate.asDate("2009-02-20");

      Calendar calendar = Calendar.getInstance();
      calendar.set(Calendar.YEAR, 2009);
      calendar.set(Calendar.MONTH, Calendar.FEBRUARY);
      calendar.set(Calendar.DAY_OF_MONTH, 20);
      calendar.set(Calendar.HOUR_OF_DAY, 0);
      calendar.set(Calendar.MINUTE, 0);
      calendar.set(Calendar.SECOND, 0);
      calendar.set(Calendar.MILLISECOND, 0);

      assertThat(date, is(calendar.getTime()));
   }
}
