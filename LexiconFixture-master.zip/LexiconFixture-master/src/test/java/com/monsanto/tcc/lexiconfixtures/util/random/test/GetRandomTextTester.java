/*
 GetRandomText_UT was created on Nov 6, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.util.random.test;

import com.monsanto.tcc.lexiconfixtures.util.random.GetRandomText;
import junit.framework.TestCase;
import java.util.Arrays;
import java.util.List;

/**
 * nbwald Nov 6, 2007 3:42:02 PM
 */
public class GetRandomTextTester
   extends TestCase
{
   private static final List<Character> alphabet = Arrays.asList
      ('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z');

   public void testTextLengthDefaultsToNineCharacters()
      throws Exception
   {
      GetRandomText textFixture = new GetRandomText();
      textFixture.reset();
      String result = textFixture.text();

      assertEquals(9, result.length());
      assertTrue( allCharactersInResultAreInAlphabet(result) );
   }

   public void testTextLengthModified()
      throws Exception
   {
      GetRandomText textFixture = new GetRandomText();
      textFixture.reset();
      textFixture.length = 100;
      String result = textFixture.text();

      assertEquals(100, result.length());
      assertTrue( allCharactersInResultAreInAlphabet(result) );
   }

   public void testSpecifyPrefix()
      throws Exception
   {
      GetRandomText textFixture = new GetRandomText();
      textFixture.reset();
      textFixture.prefix = "!";
      String result = textFixture.text();

      assertTrue(result.startsWith("!"));
   }

   public void testPrefixCountsTowardsLength()
      throws Exception
   {
      GetRandomText textFixture = new GetRandomText();
      textFixture.reset();
      textFixture.length = 5;
      textFixture.prefix = "!";
      String result = textFixture.text();

      assertTrue(result.startsWith("!"));
      assertEquals(5, result.length());
   }

   private boolean allCharactersInResultAreInAlphabet(String result) {
      for (int i=0; i<result.length(); i++) {
         if(!alphabet.contains(result.charAt(i))) {
            return false;
         }
      }
      return true;
   }
}