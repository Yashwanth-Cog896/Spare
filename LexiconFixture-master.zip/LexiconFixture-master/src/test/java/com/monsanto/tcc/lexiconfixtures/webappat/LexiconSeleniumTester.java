/*
 LexiconSeleniumTester was created on May 29, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.webappat;

/**
 * nbwald May 29, 2007 4:53:25 PM
 */
public class LexiconSeleniumTester
//   extends LexiconSeleniumBasedTestCase
{
//   protected LexiconSelenium selenium;
//   private SeleniumServerWrapper serverWrapper = new SeleniumServerWrapper();
//   protected static final String MAX_WAIT_TIME_IN_MS = "60000";
//
//   public void setUp()
//      throws Exception
//   {
//      serverWrapper.startServer();
//      selenium = new LexiconSelenium("localhost", SeleniumServerWrapper.SELENIUM_SERVER_PORT, "*iehta", "http://w3devel.kerberos.monsanto.com/");
//      selenium.start();
//   }
//
//   public void tearDown()
//      throws Exception
//   {
//      selenium.stop();
//      serverWrapper.stopServer();
//   }
//
//   public void test()
//      throws Exception
//   {
//      selenium.open("http://w3devel.kerberos.monsanto.com/lexicon-app/LexiconSelenium.jsp");
//      selenium.waitForPageToLoad(MAX_WAIT_TIME_IN_MS);
//
//      assertFalse( selenium.isFieldEditable("plainTextField") );
//      assertTrue( selenium.isFieldEditable("enabledControlField") );
//      assertTrue( selenium.isFieldEditable("enabledControl") );
//      assertFalse( selenium.isFieldEditable("disabledControlField") );
//      assertFalse( selenium.isFieldEditable("disabledControl") );
//   }
}