package com.monsanto.tcc.lexiconfixtures.util.test;

import com.monsanto.tcc.lexiconfixtures.util.ColumnFixtureResetter;
import fit.ColumnFixture;
import junit.framework.TestCase;

/**
 * nbwald - Mar 24, 2008 12:29:37 PM
 */
public class ColumnFixtureResetter_UT
   extends TestCase
{
   public void testReset()
      throws Exception
   {
      MockColumnFixture mockColumnFixture = new MockColumnFixture();
      mockColumnFixture.fieldA = "SOME VALUE";
      mockColumnFixture.fieldB = "SOME OTHER VALUE";
      mockColumnFixture.primitiveBooleanA = false;
      mockColumnFixture.primitiveBooleanB = true;
      mockColumnFixture.primitiveLongA = 42;
      mockColumnFixture.primitiveLongB = 613;

      ColumnFixtureResetter.reset(mockColumnFixture);

      assertNull(mockColumnFixture.fieldA);
      assertNull(mockColumnFixture.fieldB);
      assertFalse(mockColumnFixture.primitiveBooleanA);
      assertFalse(mockColumnFixture.primitiveBooleanB);
      assertEquals(0, mockColumnFixture.primitiveLongA);
      assertEquals(0, mockColumnFixture.primitiveLongB);
   }

   // Must be public for ColumnFixtureResetter to access class reflectively without special java policy permissions
   public class MockColumnFixture
      extends ColumnFixture
   {
      public Object fieldA;
      public Object fieldB;
      public boolean primitiveBooleanA;
      public boolean primitiveBooleanB;
      public long primitiveLongA;
      public long primitiveLongB;
   }
}
