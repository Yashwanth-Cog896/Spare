/*
 HtmlTableRowParserTester was created on Apr 18, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.webappat;

/**
 * nbwald Apr 18, 2007 10:47:23 AM
 */
public class HtmlTableRowParserTester
//   extends LexiconSeleniumBasedTestCase
{
/*   public void setUp()
      throws Exception
   {
      super.setUp();
      selenium.start();
   }

   public void testParseHeader()
      throws Exception
   {
      selenium.open("http://w3devel.kerberos.monsanto.com/lexicon-app/HtmlTableRowParserTester.jsp");
      selenium.waitForPageToLoad(MAX_WAIT_TIME_IN_MS);

      HtmlTableRowParser rowParser = new HtmlTableRowParser(selenium, "headerRow");
      String[] rowValues = rowParser.getRow();

      assertNotNull(rowValues);
      assertEquals(6, rowValues.length);
      assertEquals("Check Box", rowValues[0]);
      assertEquals("Action Icons", rowValues[1]);
      assertEquals("Select Input", rowValues[2]);
      assertEquals("Text Input", rowValues[3]);
      assertEquals("Plain Text", rowValues[4]);
      assertEquals("Linked Header", rowValues[5]);
   }

   public void testParseRowOne()
      throws Exception
   {
      selenium.open("http://w3devel.kerberos.monsanto.com/lexicon-app/HtmlTableRowParserTester.jsp");
      selenium.waitForPageToLoad(MAX_WAIT_TIME_IN_MS);

      HtmlTableRowParser rowParser = new HtmlTableRowParser(selenium, "firstRow");
      String[] rowValues = rowParser.getRow();

      assertNotNull(rowValues);
      assertEquals(6, rowValues.length);
      assertEquals("unchecked", rowValues[0]);
      assertEquals("[edit][delete]", rowValues[1]);
      assertEquals("Option One", rowValues[2]);
      assertEquals("", rowValues[3]);
      assertEquals("Text One", rowValues[4]);
      assertEquals("Link One", rowValues[5]);
   }

   public void testParseRowTwo()
      throws Exception
   {
      selenium.open("http://w3devel.kerberos.monsanto.com/lexicon-app/HtmlTableRowParserTester.jsp");
      selenium.waitForPageToLoad(MAX_WAIT_TIME_IN_MS);

      HtmlTableRowParser rowParser = new HtmlTableRowParser(selenium, "secondRow");
      String[] rowValues = rowParser.getRow();

      assertNotNull(rowValues);
      assertEquals(6, rowValues.length);
      assertEquals("checked", rowValues[0]);
      assertEquals("[undo]", rowValues[1]);
      assertEquals("Option Two", rowValues[2]);
      assertEquals("Text Input Text", rowValues[3]);
      assertEquals("", rowValues[4]);
      assertEquals("Link Two", rowValues[5]);
   }

   public void testParseRowThree()
      throws Exception
   {
      selenium.open("http://w3devel.kerberos.monsanto.com/lexicon-app/HtmlTableRowParserTester.jsp");
      selenium.waitForPageToLoad(MAX_WAIT_TIME_IN_MS);

      HtmlTableRowParser rowParser = new HtmlTableRowParser(selenium, "thirdRow");
      String[] rowValues = rowParser.getRow();

      assertNotNull(rowValues);
      assertEquals(6, rowValues.length);
      assertEquals("checked", rowValues[0]);
      assertEquals("[edit][delete]", rowValues[1]);
      assertEquals("Option One, Option Three", rowValues[2]);
      assertEquals("", rowValues[3]);
      assertEquals("1", rowValues[4]);
      assertEquals("Link Three", rowValues[5]);
   }
*/
}