package com.monsanto.tcc.lexiconfixtures.data.lexicon.baseproduct.test;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreEntityExistsQuery;
import com.monsanto.tcc.lexiconcommon.db.test.LexiconDataTestCase;
import com.monsanto.tcc.lexiconfixtures.data.lexicon.baseproduct.CheckBaseProduct;
import com.monsanto.tcc.lexiconfixtures.data.lexicon.baseproduct.CreateBaseProduct;
import com.monsanto.tcc.lexiconfixtures.data.lexicon.baseproduct.RemoveBaseProduct;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jun 27, 2007
 * Time: 3:54:49 PM
 */
public class CreateBaseProduct_UT
   extends LexiconDataTestCase
{
   private static final String BASE_MANF_NAME = "BASEMANFNAME";
   private static final int PRODUCT_ID = -1;

   public void testInsertARow()
      throws Exception
   {
      CreateBaseProduct createFixture = new CreateBaseProduct();
      createFixture.baseProductId = PRODUCT_ID;
      createFixture.baseManufacturingName = BASE_MANF_NAME;
      createFixture.cropName = "CORN";
      createFixture.parentProduct = true;

      CheckBaseProduct checkFixture = new CheckBaseProduct();
      checkFixture.baseManufacturingName = BASE_MANF_NAME;
      checkFixture.cropName = "CORN";
      checkFixture.parentProduct = true;

      RemoveBaseProduct removeFixture = new RemoveBaseProduct();
      removeFixture.baseManufacturingName = BASE_MANF_NAME;

      assertTrue(createFixture.created());
      assertTrue(checkFixture.exists());
      assertTrue(rowExists());
      assertTrue(removeFixture.removed());
      assertFalse(checkFixture.exists());
      assertFalse(rowExists());
   }

   private boolean rowExists()
      throws WrappingException
   {
      return new RowWasCreatedQuery(BASE_MANF_NAME).entityExists();
   }

   class RowWasCreatedQuery
      extends AbstractPersistentStoreEntityExistsQuery
   {
      private final String manfName;

      public RowWasCreatedQuery(final String manfName) {
         this.manfName = manfName;
      }
      protected String getSQL()
         throws WrappingException
      {
         return "SELECT * FROM Lexicon.Base_Product WHERE base_manufacturing_name = ?";
      }
      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[] { manfName };
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new LexiconConnectionFactoryProperties();
      }
   }
}
