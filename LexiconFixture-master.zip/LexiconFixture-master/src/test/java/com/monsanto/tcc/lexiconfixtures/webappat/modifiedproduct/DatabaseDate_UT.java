package com.monsanto.tcc.lexiconfixtures.webappat.modifiedproduct;

import junit.framework.TestCase;

import java.util.Date;
import java.util.GregorianCalendar;

/**
 * nbwald - Sep 15, 2008 6:47:41 PM
 */
public class DatabaseDate_UT
   extends TestCase
{
   private static final int ONE_SECOND_IN_MILLISECONDS = 1000;

   public void testParse()
      throws Exception
   {
      DatabaseDate databaseDate = new DatabaseDate();
      Date date = databaseDate.parse("2008/09/15:18:46:44");

      GregorianCalendar expectedCalendar = new GregorianCalendar();
      expectedCalendar.set(2008, GregorianCalendar.SEPTEMBER, 15, 18, 46, 44);
      Date expectedDate = expectedCalendar.getTime();

      assertTrue(Math.abs(expectedDate.getTime() - date.getTime()) < ONE_SECOND_IN_MILLISECONDS);
   }

   public void testRender()
      throws Exception
   {
      GregorianCalendar expectedCalendar = new GregorianCalendar();
      expectedCalendar.set(2008, GregorianCalendar.SEPTEMBER, 15, 8, 6, 4);
      Date expectedDate = expectedCalendar.getTime();

      DatabaseDate databaseDate = new DatabaseDate();
      String timeString = databaseDate.render(expectedDate);

      assertEquals("2008/09/15:08:06:04", timeString);
   }
}
