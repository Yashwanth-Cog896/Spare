package com.monsanto.tcc.lexiconfixtures.selenium;

import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 20, 2006
 * Time: 11:16:40 AM
 */

// NOTE: This class is duplicated in the lexicon-app project.
public abstract class LexiconSeleniumBasedTestCase
   extends TestCase
{
   protected LexiconSelenium selenium;
   private SeleniumServerWrapper serverWrapper = new SeleniumServerWrapper();
   protected static final String MAX_WAIT_TIME_IN_MS = "60000";

   public void setUp()
      throws Exception
   {
      super.setUp();
      serverWrapper.startServer();
      selenium = new LexiconSelenium("localhost", SeleniumServerWrapper.SELENIUM_SERVER_PORT, "*iehta", "http://w3devel.kerberos.monsanto.com");
   }

   public void tearDown()
      throws Exception
   {
      selenium.stop();
      serverWrapper.stopServer();
      super.tearDown();
   }

}
