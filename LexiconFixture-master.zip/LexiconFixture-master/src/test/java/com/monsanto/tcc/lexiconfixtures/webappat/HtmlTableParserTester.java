package com.monsanto.tcc.lexiconfixtures.webappat;

import com.monsanto.tcc.lexiconfixtures.selenium.LexiconSeleniumBasedTestCase;

/**
 * Created by IntelliJ IDEA.
 * User: PJBERRY
 * Date: Mar 31, 2007
 * Time: 2:19:15 PM
 */
public class HtmlTableParserTester
   extends LexiconSeleniumBasedTestCase
{
   public void setUp()
      throws Exception
   {
      super.setUp();
      selenium.start();
      selenium.open("http://w3devel.kerberos.monsanto.com/lexicon-app/HtmlTableParserTester.jsp");
      selenium.waitForPageToLoad(MAX_WAIT_TIME_IN_MS);
   }

   public void testGetTable_A()
      throws Exception
   {
      HtmlTableParser parser = new HtmlTableParser(selenium, "testTableA");

      String[][] table = parser.getTable();
      assertEquals("Check Box", table[0][0]);
      assertEquals("Action Icons", table[0][1]);
      assertEquals("Select Input", table[0][2]);
      assertEquals("Text Input", table[0][3]);
      assertEquals("Plain Text", table[0][4]);
      assertEquals("UL List", table[0][5]);

      assertEquals("unchecked", table[1][0]);
      assertEquals("[edit][delete]", table[1][1]);
      assertEquals("Option One", table[1][2]);
      assertEquals("", table[1][3]);
      assertEquals("Text One", table[1][4]);
      assertEquals("", table[1][5]);

      assertEquals("checked", table[2][0]);
      assertEquals("[undo]", table[2][1]);
      assertEquals("Option Two", table[2][2]);
      assertEquals("Text Input Text", table[2][3]);
      assertEquals("", table[2][4]);
      assertEquals("item one", table[2][5]);

      assertEquals("checked", table[3][0]);
      assertEquals("", table[3][1]);
      assertEquals("Option One, Option Three", table[3][2]);
      assertEquals("", table[3][3]);
      assertEquals("", table[3][4]);
      assertEquals("item one, item two", table[3][5]);

      assertEquals("checked", table[4][0]);
      assertEquals("[undo]", table[4][1]);
      assertEquals("", table[4][2]);
      assertEquals("", table[4][3]);
      assertEquals("", table[4][4]);
      assertEquals("item one, item two", table[4][5]);
   }

   public void testGetTable_B()
      throws Exception
   {
      HtmlTableParser parser = new HtmlTableParser(selenium, "testTableB");
      String[][] table = parser.getTable();

      assertNotNull(table);
      assertEquals("LinkedText", table[0][0]);
      assertEquals("LinkedTextValue", table[1][0]);
   }
}
