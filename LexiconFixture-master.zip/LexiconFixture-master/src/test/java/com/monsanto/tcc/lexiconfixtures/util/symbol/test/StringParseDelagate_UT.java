/*
 StringParseDelagate_UT was created on Jun 20, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.util.symbol.test;

import com.monsanto.tcc.lexiconfixtures.util.symbol.StringParseDelagate;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolProcessingParseDelagate;
import fit.Fixture;
import junit.framework.TestCase;

/**
 * nbwald Jun 20, 2007 11:15:30 AM
 */
public class StringParseDelagate_UT
   extends TestCase
{
   private static final String SYMBOL_PREFIX = SymbolProcessingParseDelagate.SYMBOL_PREFIX;
   private static final String SYMBOL_A = SYMBOL_PREFIX + "symbolA";
   private static final String SYMBOL_B = SYMBOL_PREFIX + "symbolB";
   private static final String SYMBOL_C = SYMBOL_PREFIX + "symbolC";
   private static final String VALUE_A = "ValueA";
   private static final String VALUE_B = "ValueB";
   private static final String VALUE_C = "ValueC";

   protected void setUp()
      throws Exception
   {
      super.setUp();
      Fixture.setSymbol(SYMBOL_A, VALUE_A);
      Fixture.setSymbol(SYMBOL_B, VALUE_B);
      Fixture.setSymbol(SYMBOL_C, VALUE_C);
   }

   public void testSimpleString()
      throws Exception
   {
      StringParseDelagate parser = new StringParseDelagate();
      String result = parser.parse("SomeString");

      assertEquals("SomeString", result);
   }

   public void testSingleSymbol()
      throws Exception
   {
      StringParseDelagate parser = new StringParseDelagate();
      String result = parser.parse(SYMBOL_A);

      assertEquals(VALUE_A, result);
   }

   public void testSingleUnregisteredSymbol()
      throws Exception
   {
      StringParseDelagate parser = new StringParseDelagate();
      String result = parser.parse(SYMBOL_PREFIX + "someUnregisteredVariable");

      assertEquals("null", result);
   }

   public void testCSVOfVariables()
      throws Exception
   {
      StringParseDelagate parser = new StringParseDelagate();
      String result = parser.parse(SYMBOL_A + "," + SYMBOL_B + "," + SYMBOL_C);

      assertEquals(VALUE_A + "," + VALUE_B + "," + VALUE_C, result);
   }

   public void testSpacedCSVofVariables_RetainsSpacing()
      throws Exception
   {
      StringParseDelagate parser = new StringParseDelagate();
      String result = parser.parse("   " + SYMBOL_A + "  , " + SYMBOL_B + ", " + SYMBOL_C);

      assertEquals("   " + VALUE_A + "  , " + VALUE_B + ", " + VALUE_C, result);
   }

   public void testXPathIsNotAffected()
      throws Exception
   {
      StringParseDelagate parser = new StringParseDelagate();
      String result = parser.parse("xpath=//img[contains(@src, '/lexicon-app/images/edit.gif')]");

      assertEquals("xpath=//img[contains(@src, '/lexicon-app/images/edit.gif')]", result);
   }
}