package com.monsanto.tcc.lexiconfixtures.data.midas.util.test;

import com.monsanto.tcc.lexiconfixtures.data.midas.util.MidasBoolean;
import junit.framework.TestCase;

/**
 * nbwald - Mar 24, 2008 12:44:58 PM
 */
public class MidasBoolean_UT
   extends TestCase
{
   public void testToString()
      throws Exception
   {
      assertEquals("T", MidasBoolean.toString(true));
      assertEquals("F", MidasBoolean.toString(false));
   }
}
