package com.monsanto.tcc.lexiconfixtures.serviceat.agency;

import com.monsanto.tcc.lexiconcommon.ArrayUtils;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingRowFixture;
import com.monsanto.tps.lexicon.agency.Agency;
import com.monsanto.tps.lexicon.agency.AgencyDepartment;

import java.util.ArrayList;
import java.util.List;

/**
 * rrchak1 - Oct 23, 2008 4:14:34 PM
 */
public class AgencyAdaptorRowFixture
   extends SymbolAcceptingRowFixture
{
   private final Agency[] agencies;

   public AgencyAdaptorRowFixture(Agency[] agencies) {
      this.agencies=agencies;
   }

   public Object[] query()
      throws Exception  // get rows to be compared
   {
      return buildAgencyAdaptors();
   }

   private AgencyAdaptor[] buildAgencyAdaptors() {
      List<AgencyAdaptor> adaptors = new ArrayList<AgencyAdaptor>();
      for (Agency agency : agencies) {
         addAgencyAdaptors(adaptors, agency);
      }
      return adaptors.toArray(new AgencyAdaptor[adaptors.size()]);
   }

   private void addAgencyAdaptors(List<AgencyAdaptor> adaptors, Agency agency) {
      AgencyDepartment[] departments = getDepartments(agency);
      for (AgencyDepartment department : departments) {
            adaptors.add(new AgencyAdaptor(agency, department));
      }
   }

   private AgencyDepartment[] getDepartments(Agency agency) {
      AgencyDepartment[] departments = agency.getDepartments().toArray(new AgencyDepartment[agency.getDepartments().size()]);
      return ArrayUtils.hasItems(departments) ? departments : EmptyAgencyDepartmentRecord.get();

   }

   public Class getTargetClass()             // get expected type of row
   {
      return AgencyAdaptor.class;
   }
}
