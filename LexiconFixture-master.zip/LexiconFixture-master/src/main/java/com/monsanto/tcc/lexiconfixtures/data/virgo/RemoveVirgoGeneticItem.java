package com.monsanto.tcc.lexiconfixtures.data.virgo;

import com.monsanto.tcc.lexiconfixtures.data.factories.virgo.VirgoConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * User: pjberry
 * Date: Aug 1, 2007
 * Time: 5:21:44 PM
 */
public class RemoveVirgoGeneticItem
   extends SymbolAcceptingColumnFixture
{
   public String key;

   public boolean removed()
      throws WrappingException
   {
      PersistentStoreConnection conn = new VirgoConnectionFactory().getConnection();
      try {
         return deleteGeneticItem(conn) == 1;
      }
      finally{
         conn.close();
      }
   }

   private int deleteGeneticItem(PersistentStoreConnection conn)
      throws WrappingException
   {
      String sql = "DELETE FROM VIRGO_GENETIC_ITEM GI WHERE GI.it_key = ?";
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, key);
         return stmt.executeDelete();
      }
      finally {
         stmt.close();
      }
   }
}
