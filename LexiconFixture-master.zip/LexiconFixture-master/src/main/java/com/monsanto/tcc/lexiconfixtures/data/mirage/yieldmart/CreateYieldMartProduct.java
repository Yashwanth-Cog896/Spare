package com.monsanto.tcc.lexiconfixtures.data.mirage.yieldmart;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreInsert;
import com.monsanto.tcc.lexiconfixtures.data.factories.yieldmart.YieldMartConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Mar 21, 2007
 * Time: 12:37:45 PM
 * To change this template use File | Settings | File Templates.
 */
public class CreateYieldMartProduct
   extends SymbolAcceptingColumnFixture
{
   public Integer seedProductId;
   public String productName;
   public Long geneticMaterialId;

   public boolean created()
      throws WrappingException
   {
      int recordsCreated = createFakeData();
      return (recordsCreated == 1);
   }

   private int createFakeData()
      throws WrappingException
   {
      MapProductMirageInsert dataMod = new MapProductMirageInsert(seedProductId, productName, geneticMaterialId);
      return dataMod.performInsert();
   }
}

class MapProductMirageInsert
   extends AbstractPersistentStoreInsert
{
   public final Integer seedProductId;
   public final String productName;
   public final Long geneticMaterialId;

   public MapProductMirageInsert(Integer seedProductId, String productName, Long geneticMaterialId) {
      this.seedProductId = seedProductId;
      this.productName = productName;
      this.geneticMaterialId = geneticMaterialId;
   }
   protected String getSQL()
      throws WrappingException
   {
      return "INSERT INTO YldStg.Map_Product_Mirage(" +
         "seed_product_id, mirage_name, genetic_material_pk) VALUES(?, ?, ?)";
   }
   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { seedProductId, productName, geneticMaterialId };
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new YieldMartConnectionFactoryProperties();
   }
}
