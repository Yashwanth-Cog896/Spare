package com.monsanto.tcc.lexiconfixtures.util.preference;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tcc.lexiconfixtures.util.UserHelper;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import java.util.List;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jun 28, 2007
 * Time: 1:48:11 PM
 */
class UserPreferenceValuesQuery
   extends AbstractPersistentStoreMultiRowQuery
{
   private final String prefName;
   public UserPreferenceValuesQuery(String prefName) {
      this.prefName = prefName;
   }
   public List<String> getList() throws WrappingException {
      return super.getList();
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row) throws WrappingException {
      return row.getString(1);
   }
   protected Object[] getBindVariables() throws WrappingException {
      return new Object[]  {UserHelper.getCurrentUserLoginId(), prefName };
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
   protected String getSQL()
      throws WrappingException
   {
      return "SELECT value FROM Lexicon.User_Preference_Value WHERE user_preference_id = (" +
               "SELECT user_preference_id FROM  Lexicon.User_Preference " +
               "WHERE user_login_id = ? AND  preference_definition_name = ?" +
             ")";

   }
}
