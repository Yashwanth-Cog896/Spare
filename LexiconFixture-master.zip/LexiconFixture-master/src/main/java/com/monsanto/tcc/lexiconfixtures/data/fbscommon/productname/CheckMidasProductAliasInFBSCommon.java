package com.monsanto.tcc.lexiconfixtures.data.fbscommon.productname;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconfixtures.data.factories.fbs.FBSCommonConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.data.midas.productname.MidasProductNameIdByCriteriaQuery;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.EmptyResultSetException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetSingleResult;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Dec 18, 2006
 * Time: 1:43:19 PM
 * To change this template use File | Settings | File Templates.
 */
public class CheckMidasProductAliasInFBSCommon
   extends SymbolAcceptingColumnFixture
{
   public String midasPrecomlName;
   public String midasProductName;
   public String midasBrand;
   public String midasCountry;

   public boolean exists()
      throws WrappingException, EmptyResultSetException
   {
      MidasProductNameIdByCriteriaQuery query =
         new MidasProductNameIdByCriteriaQuery(midasPrecomlName, midasProductName, midasBrand, midasCountry);
      Long midasProductAliasId = query.getProductNameId();

      int numOfEntries = getNumOfEntriesWithProductAliasId(midasProductAliasId);
      return numOfEntries > 0;
   }

   private int getNumOfEntriesWithProductAliasId(Long midasProductAliasId)
      throws WrappingException, EmptyResultSetException
   {
      FBSCommonConnectionFactory connectionFactory = new FBSCommonConnectionFactory();
      PersistentStoreConnection conn = connectionFactory.getConnection();
      String sql = getSQL();
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, midasProductAliasId);
         PersistentStoreResultSetSingleResult resultSet = stmt.executeQuery().getSingleResult();
         return resultSet.getInt(1);
      }
      finally {
         stmt.close();
         conn.close();
      }
   }

   private String getSQL()
      throws WrappingException
   {
      SQLPropFile sqlPropFile = new SQLPropFile(FBSCommonProductNameFixtureSQL.class);
      return sqlPropFile.getSQL(FBSCommonProductNameFixtureSQL.SELECT_NUM_OF_PROD_NAME_XREF_MATCHING_MIDAS_ALIAS_ID);
   }
}
