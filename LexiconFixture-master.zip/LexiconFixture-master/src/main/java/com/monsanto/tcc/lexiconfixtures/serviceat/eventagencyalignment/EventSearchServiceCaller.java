package com.monsanto.tcc.lexiconfixtures.serviceat.eventagencyalignment;

import com.monsanto.tps.lexicon.event.EventInfo;
import com.monsanto.tps.lexicon.event.EventSearchService;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * nbwald - Feb 16, 2009 3:33:30 PM
 */
public class EventSearchServiceCaller
{
   public EventInfo findByEventAndCrop(String eventName, String crop) {
      return getService().findByEventAndCrop(eventName, crop);
   }

   public EventInfo[] findByEventsAndCrop(String[] eventNames, String cropName) {
      return getService().findByEventsAndCrop(eventNames, cropName);
   }

   public EventInfo findByMonNumber(String monNumberValue) {
      return getService().findByMonNumber(monNumberValue);
   }

   public EventInfo[] findByMonNumbers(String[] monNumberValues) {
      return getService().findByMonNumbers(monNumberValues);
   }

   public EventInfo[] findByEventAgencyAlignmentPubkey(String[] eventAgencyAlignmentPubkey) {
      return getService().findByEventAgencyAlignmentPubkey(eventAgencyAlignmentPubkey);
   }

   public EventInfo[] findByAgencyAbbr(String[] agencyAbbr) {
      return getService().findByAgencyAbbr(agencyAbbr);
   }

   private EventSearchService getService() {
      ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("/com/monsanto/tcc/lexiconfixtures/serviceat/eventagencyalignment/eventSearchServiceCaller.xml");
      return (EventSearchService) context.getBean("service");
   }
}