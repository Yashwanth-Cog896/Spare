package com.monsanto.tcc.lexiconfixtures.data.mirage.product;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconfixtures.data.factories.mirage.MirageConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.data.mirage.MirageSQLUtils;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 7, 2006
 * Time: 5:26:18 PM
 * To change this template use File | Settings | File Templates.
 */
public class CreateMirageProduct
   extends SymbolAcceptingColumnFixture
{
   public Long productId;
   public String bayerCode;
   public String company;
   public String country;
   public String productName;
   public String commercialTrait;
   public boolean enabled;

   private SQLPropFile sqlPropFile = new SQLPropFile(MirageProductFixtureSQL.class);

   public boolean created()
      throws WrappingException
   {
      MirageConnectionFactory connectionFactory = new MirageConnectionFactory();
      PersistentStoreConnection conn = connectionFactory.getConnection();
      try {
         int numInserted = insertFakeData(conn);
         return numInserted == 1;
      }
      finally {
         conn.close();
      }
   }

   private int insertFakeData(PersistentStoreConnection conn)
      throws WrappingException
   {
      String sql = sqlPropFile.getSQL(MirageProductFixtureSQL.INSERT_PRODUCT);

      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, productId);
         stmt.setParam(2, StringUtils.toUpperCaseNull(company));
         stmt.setParam(3, productName);
         stmt.setParam(4, MirageSQLUtils.buildBayerCodeForDB(bayerCode));
         stmt.setParam(5, StringUtils.toUpperCaseNull(country));
         stmt.setParam(6, StringUtils.toUpperCaseNull(commercialTrait));
         stmt.setParam(7, enabled ? "Y" :"N");
         return stmt.executeInsert();
      }
      finally {
         stmt.close();
      }
   }
}

