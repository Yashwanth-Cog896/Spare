/*
 CheckLexiconBrand was created on Apr 16, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.data.lexicon.brand;

import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.EmptyResultSetException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetSingleResult;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.dbdataservices.SQLUtil;

/**
 * nbwald Apr 16, 2007 12:26:14 PM
 */
public class CheckLexiconBrand
   extends SymbolAcceptingColumnFixture
{
   public String brandName;
   public String brandAbbr;
   public boolean active;
   public boolean tdRestricted;
   public String companyName;

   public boolean exists()
      throws WrappingException
   {
      LexiconConnectionFactory connectionFactory = new LexiconConnectionFactory();
      PersistentStoreConnection conn = connectionFactory.getConnection();
      try {
         return matchingBrands(conn) == 1;
      }
      finally {
         conn.close();
      }
   }

   private int matchingBrands(PersistentStoreConnection conn)
      throws WrappingException
   {
      PersistentStoreStatement statement = conn.prepareStatement(getSQL());
      try {
         statement.setParam(1, brandName);
         statement.setParam(2, brandAbbr);
         statement.setParam(3, SQLUtil.booleanToString(active));
         statement.setParam(4, SQLUtil.booleanToString(tdRestricted));
         statement.setParam(5, companyName);
         PersistentStoreResultSetSingleResult result = statement.executeQuery().getSingleResult();
         return result.getInt(1);
      }
      catch (EmptyResultSetException e) {
         return 0;
      } finally {
         statement.close();
      }
   }

   private String getSQL() {
      return
         "     SELECT count(*)" +
         "       FROM Lexicon.Brand B" +
         " INNER JOIN Lexicon.Company CO" +
         "         ON B.company_id = CO.company_id" +
         "      WHERE B.brand_name = ?" +
         "        AND B.brand_abbr = ?" +
         "        AND B.is_active = ?" +
         "        AND B.td_restricted = ?" +
         "        AND CO.company_name = ?";
   }
}