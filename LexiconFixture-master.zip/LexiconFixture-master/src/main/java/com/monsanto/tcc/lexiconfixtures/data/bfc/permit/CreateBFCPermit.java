package com.monsanto.tcc.lexiconfixtures.data.bfc.permit;

import com.monsanto.tcc.lexiconfixtures.data.factories.bfc.BFCConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * User: pjberry
 * Date: Aug 3, 2007
 * Time: 8:17:45 AM
 */
public class CreateBFCPermit
   extends SymbolAcceptingColumnFixture
{
   public Long permitId;
   public String monsantoId;
   public String agencyId;
   public String status;
   public String crop;
   public String effective;
   public String expired;

   public boolean created()
      throws WrappingException, ParseException
   {
      return performInsert() == 1;
   }

   private int performInsert()
      throws WrappingException
   {
      PersistentStoreConnection conn = new BFCConnectionFactory().getConnection();
      String sql = getSQL();
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, permitId);
         stmt.setParam(2, monsantoId);
         stmt.setParam(3, agencyId);
         stmt.setParam(4, status);
         stmt.setParam(5, crop);
         stmt.setParam(6, parseStringAsDate(effective));
         stmt.setParam(7, parseStringAsDate(expired));
         return stmt.executeInsert();
      }
      finally {
         stmt.close();
         conn.close();
      }
   }

   private String getSQL()
      throws WrappingException
   {
      return
         "INSERT INTO Regulatory.permit " +
            "(permit_id, monsanto_id, agency_id, status, crop_id, effective, expired) " +
            "VALUES " +
            "(?, ?, ?, ?, (SELECT C.crop_id FROM Regulatory.crop C WHERE UPPER(C.common_name) = UPPER(?)), ?, ?)";
   }

   private Date parseStringAsDate(String dateString)
   {
      SimpleDateFormat formatter = new SimpleDateFormat("M/d/yyyy");
      try {
         return dateString == null ? null : formatter.parse(dateString);
      }
      catch (ParseException e) {
         throw new RuntimeException(e.getMessage());
      }
   }

}
