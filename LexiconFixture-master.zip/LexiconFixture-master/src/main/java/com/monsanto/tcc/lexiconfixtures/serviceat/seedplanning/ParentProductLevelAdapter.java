package com.monsanto.tcc.lexiconfixtures.serviceat.seedplanning;

import com.monsanto.tcc.lexiconcommon.service.ProductParentGermplasmDocTags;
import com.monsanto.XMLUtil.DOMUtil;
import org.w3c.dom.Node;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Feb 14, 2007
 * Time: 9:15:14 AM
 * To change this template use File | Settings | File Templates.
 */
public class ParentProductLevelAdapter
{
   public String role;
   public String childProductPubkey;
   public String parentProductPubkey;
   public String precommercialName;
   public String crop;
   public boolean isDeleted;
   public String manufacturingName;
   public String traitVersion;
   public String productionStatus;
   public String inbredHybrid;
   public String origin;
   public String lineCode;

   public ParentProductLevelAdapter(String childProductPubkey, Node parentNode) {
      this.childProductPubkey = childProductPubkey;
      this.role = DOMUtil.getChildValue(parentNode, ProductParentGermplasmDocTags.ROLE_ELEM_NAME);
      this.parentProductPubkey = DOMUtil.getAttribute(parentNode, ProductParentGermplasmDocTags.PRODUCT_ELEM_NAME, ProductParentGermplasmDocTags.PUBKEY_ATTR_NAME);
      this.precommercialName = parsePreCommericalName(parentNode);
      this.crop = parseCrop(parentNode);
      this.isDeleted = parseIsDeleted(parentNode);
      parseProductRelationshipAttributes(parentNode);
      this.inbredHybrid = parseInbredHybrid(parentNode);
      this.origin = parseOrigin(parentNode);
      this.lineCode = parseLineCode(parentNode);
   }

   private String parsePreCommericalName(Node parentNode) {
      return DOMUtil.getChildValue(getProductNode(parentNode), ProductParentGermplasmDocTags.PRE_COML_NAME_ELEM_NAME);
   }

   private String parseCrop(Node parentNode) {
      return DOMUtil.getChildValue(getProductNode(parentNode), ProductParentGermplasmDocTags.CROP_ELEM_NAME);
   }

   private boolean parseIsDeleted(Node parentNode) {
      String booleanAsString = DOMUtil.getChildValue(getProductNode(parentNode), ProductParentGermplasmDocTags.LOGICALLY_DELETED_ELEM_NAME);
      return Boolean.valueOf(booleanAsString).booleanValue();
   }

   private String parseInbredHybrid(Node parentNode) {
      return DOMUtil.getChildValue(getProductNode(parentNode), ProductParentGermplasmDocTags.INBRED_HYBRID_ELEM_NAME);
   }

   private void parseProductRelationshipAttributes(Node parentNode) {
      Node relationshipAttributes = DOMUtil.getChild(getProductNode(parentNode), ProductParentGermplasmDocTags.RELATIONSHIP_ATTRIBUTES_ELEM_NAME);
      if(relationshipAttributes != null) {
         this.manufacturingName = DOMUtil.getChildValue(relationshipAttributes, ProductParentGermplasmDocTags.MANF_NAME_ELEM_NAME);
         this.traitVersion = DOMUtil.getChildValue(relationshipAttributes, ProductParentGermplasmDocTags.TRAIT_VERSION_ELEM_NAME);
         this.productionStatus = DOMUtil.getChildValue(relationshipAttributes, ProductParentGermplasmDocTags.PROD_STATUS_ELEM_NAME);
      }
   }

   private String parseOrigin(Node parentNode) {
      Node[] germplasm = getGermplasmNodes(parentNode);
      StringBuffer sb = new StringBuffer();
      for (int i = 0; i < germplasm.length; i++) {
         if(i > 0) sb.append(", ");
         Node[] originNodes = DOMUtil.getChildren(germplasm[i], ProductParentGermplasmDocTags.ORIGIN_ELEM_NAME);
         String csvList = buildCSVList(originNodes);
         if(csvList != null) sb.append(csvList);
      }
      return sb.length() != 0 ? sb.toString() : null;
   }

   private String parseLineCode(Node parentNode) {
      Node[] germplasm = getGermplasmNodes(parentNode);
      StringBuffer sb = new StringBuffer();
      for (int i = 0; i < germplasm.length; i++) {
         if(i > 0) sb.append(", ");
         Node[] lineCodeNodes = DOMUtil.getChildren(germplasm[i], ProductParentGermplasmDocTags.LINE_CODE_ELEM_NAME);
         String csvList = buildCSVList(lineCodeNodes);
         if(csvList != null) sb.append(csvList);
      }
      return sb.length() != 0 ? sb.toString() : null;
   }

   private String buildCSVList(Node[] nodes) {
      StringBuffer sb = new StringBuffer();
      for (int j = 0; j < nodes.length; j++) {
         if(j > 0) sb.append(", ");
         sb.append(DOMUtil.getTextValue(nodes[j]));
      }
      return sb.length() != 0 ? sb.toString() : null;
   }

   private Node[] getGermplasmNodes(Node parentNode) {
      Node productNode = getProductNode(parentNode);
      Node germplasmsNode = DOMUtil.getChild(productNode, ProductParentGermplasmDocTags.GERMPLASMS_ELEM_NAME);
      return DOMUtil.getChildren(germplasmsNode, ProductParentGermplasmDocTags.GERMPLASM_ELEM_NAME);
   }

   private Node getProductNode(Node parentNode) {
      return DOMUtil.getChild(parentNode, ProductParentGermplasmDocTags.PRODUCT_ELEM_NAME);
   }
}
