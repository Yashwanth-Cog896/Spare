/*
 ProductAliasReportScreenOnlyGUIFixture was created on Mar 6, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.webappat.productaliasreport;

import com.monsanto.tcc.lexiconfixtures.selenium.LexiconSelenium;
import com.monsanto.tcc.lexiconfixtures.webappat.SeleniumFixture;

/**
 * nbwald Mar 6, 2007 9:02:54 AM
 *
 * Don't copy this test paradigm
 */
public class ProductAliasReportScreenOnlyGUIFixture
   extends SeleniumFixture
{
   public String nameType() {
      LexiconSelenium selenium = getSelenium();
      return selenium.getValue("name=nameType");
   }

   public String activeOnly() {
      LexiconSelenium selenium = getSelenium();
      return selenium.getValue("name=activeOnly");
   }

   public String traitAnd() {
      LexiconSelenium selenium = getSelenium();
      return selenium.getValue("name=traitAnd");
   }

   public String productType() {
      LexiconSelenium selenium = getSelenium();
      return selenium.getValue("name=productType");
   }

   public String productNames() {
      LexiconSelenium selenium = getSelenium();
      return selenium.getValue("id=productNameList");
   }

   public String comlTraits() {
      LexiconSelenium selenium = getSelenium();
      return selenium.getValue("name=comlTraits");
   }

   public boolean setOptionFor(String value, String radioButtonLocator) {
      LexiconSelenium selenium = getSelenium();
      selenium.check(radioButtonLocator);
      return true;
   }

   public boolean selectFor(String optionLocator, String selectLocator) {
      LexiconSelenium selenium = getSelenium();
      selenium.select(selectLocator, "value=" + optionLocator);
      return true;
   }

   public boolean clickAndWaitForPageToLoad(String thingToClick) {
      String actualThingToClick = "run".equalsIgnoreCase(thingToClick) ? "runButton" : thingToClick;
      return super.clickAndWaitForPageToLoad(actualThingToClick);
   }

   public boolean resetSearch() {
      LexiconSelenium selenium = getSelenium();
      selenium.click("id=resetButton");
      return true;
   }

   public String fieldIs(String locator)
   {
      LexiconSelenium selenium = getSelenium();
      return selenium.getText(locator);
   }

   public boolean uncheck(String checkboxLocator) {
      LexiconSelenium selenium = getSelenium();
      selenium.uncheck(checkboxLocator);
      return true;
   }
}