package com.monsanto.tcc.lexiconfixtures.data.lexicon.trait;

import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactory;
import com.monsanto.tcc.lexiconcommon.db.test.LexiconTestTools;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * User: pjberry
 * Date: May 25, 2007
 * Time: 10:44:33 AM
 */
public class RemoveLexiconComlTraitStack
  extends SymbolAcceptingColumnFixture
{
   public Long comlTraitStackId;

   public boolean removed()
      throws WrappingException
   {
      LexiconConnectionFactory connectionFactory = new LexiconConnectionFactory();
      PersistentStoreConnection conn = connectionFactory.getConnection();
      LexiconTestTools.FITNESSE_TEST_AUDITOR.initializeStaging(conn);
      try {
         int numRemoved = remove(conn);
         return numRemoved == 1;
      }
      finally {
         LexiconTestTools.FITNESSE_TEST_AUDITOR.removeStaging(conn);
         conn.close();
      }
   }

   private int remove(PersistentStoreConnection conn)
      throws WrappingException
   {
      String sql = "DELETE FROM Lexicon.Coml_Trait_Stack2 CTS WHERE CTS.coml_trait_stack_id = ?";
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, comlTraitStackId);
         return stmt.executeDelete();
      }
      finally {
         stmt.close();
      }
   }
}