package com.monsanto.tcc.lexiconfixtures.data.bfc.permitconsttrans;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreDelete;
import com.monsanto.tcc.lexiconfixtures.data.factories.bfc.BFCConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * User: pjberry
 * Date: Aug 3, 2007
 * Time: 1:14:06 PM
 */
public class RemoveBFCPermitConstTrans
   extends SymbolAcceptingColumnFixture
{
   public Long permitId;
   public String transCode;

   public boolean removed()
      throws WrappingException
   {
      BFCPermitConstTransRemoval removal = new BFCPermitConstTransRemoval();
      return removal.performDelete() == 1;
   }

   private class BFCPermitConstTransRemoval
      extends AbstractPersistentStoreDelete
   {
      protected String getSQL()
         throws WrappingException
      {
         return "DELETE FROM Regulatory.permit_const_trans PCT WHERE PCT.permit_id = ? AND PCT.trans_code = ?";
      }

      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[]{permitId, transCode};
      }

      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new BFCConnectionFactoryProperties();
      }
   }
}
