package com.monsanto.tcc.lexiconfixtures.data.midas.germplasm;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreDelete;
import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 7, 2006
 * Time: 4:14:36 PM
 * To change this template use File | Settings | File Templates.
 */
public class RemoveGermplasm
   extends SymbolAcceptingColumnFixture
{
   public Long germplasmId;

   public boolean removed()
      throws WrappingException
   {
      MidasGermplasmDelete dataMod = new MidasGermplasmDelete();
      return dataMod.performDelete() == 1;
   }

   class MidasGermplasmDelete
      extends AbstractPersistentStoreDelete
   {
      protected String getSQL() throws WrappingException {
         return new SQLPropFile(GermplasmFixtureSQL.class).getSQL(GermplasmFixtureSQL.DELETE_GERMPLASM);
      }
      protected Object[] getBindVariables() throws WrappingException {
         return new Object[] { germplasmId };
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new MidasConnectionFactoryProperties();
      }
   }
}

