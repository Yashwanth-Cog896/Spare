package com.monsanto.tcc.lexiconfixtures.data.lexicon.product;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Apr 26, 2007
 * Time: 10:48:03 AM
 * To change this template use File | Settings | File Templates.
 */
public class CheckProductVarietyName
   extends SymbolAcceptingColumnFixture
{
   public String precomlName;
   public String varietyName;

   public void reset()
      throws Exception
   {
      super.reset();
      precomlName = null;
      varietyName = null;
   }

   public boolean varietyNameExists()
      throws WrappingException
   {
      String observedVarietyName = new ProductVarietyNameQuery().getVarietyName();
      return !StringUtils.isNullOrEmpty(observedVarietyName);
   }
   
   public boolean matches()
      throws WrappingException
   {
      String observedVarietyName = new ProductVarietyNameQuery().getVarietyName();
      return StringUtils.areEqual(varietyName, observedVarietyName);
   }

   class ProductVarietyNameQuery
      extends AbstractPersistentStoreSingleResultQuery
   {
      public String getVarietyName()
         throws WrappingException
      {
         return (String)execute();
      }
      protected Object createObjectFromRow(PersistentStoreResultSetRow row)
         throws WrappingException
      {
         return row.getString(1);
      }
      public String getSQL()
         throws WrappingException
      {
         return new SQLPropFile(LexiconProductFixtureSQL.class).
            getSQL(LexiconProductFixtureSQL.SELECT_PRODUCT_VARIETY_NAME);
      }
      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[] { precomlName };
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new LexiconConnectionFactoryProperties();
      }
   }
}
