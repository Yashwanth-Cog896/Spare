package com.monsanto.tcc.lexiconfixtures.webappat;

import com.monsanto.Util.StringUtils;
import fitlibrary.SetFixture;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Mar 29, 2007
 * Time: 4:17:10 PM
 * To change this template use File | Settings | File Templates.
 */
public class UnorderedListElementsFixture
        extends SetFixture
{
   public UnorderedListElementsFixture(String[] messages) {
      List list = new ArrayList();
      for (int i = 0; i < messages.length; i++) {
         String message = messages[i];
         if(!StringUtils.isNullOrEmpty(message)) {
            list.add(new Message(message.trim()));
         }
      }
      setActualCollection(list);
   }

   public class Message {
      public String message;

      public Message(String message) {
         this.message = message;
      }
   }
}
