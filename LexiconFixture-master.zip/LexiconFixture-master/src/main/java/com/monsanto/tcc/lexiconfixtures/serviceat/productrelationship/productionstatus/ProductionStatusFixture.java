package com.monsanto.tcc.lexiconfixtures.serviceat.productrelationship.productionstatus;

import com.monsanto.tcc.lexiconfixtures.util.symbol.SafeSortSymbolAcceptingRowFixture;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingDoFixture;
import com.monsanto.tps.lexiconpos.product.relationship.service.ProductRelationshipService;
import com.monsanto.tps.lexicon.precommercialproduct.ProductionStatusUpdateRequest;
import com.monsanto.tps.lexicon.precommercialproduct.ProductionStatusUpdateResponse;
import com.monsanto.tps.lexicon.precommercialproduct.UpdateStatusResponse;
import fit.Fixture;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;
import java.util.ArrayList;

/**
 * rrchak1 - Sep 12, 2008 9:50:53 AM
 */
public class ProductionStatusFixture
   extends SymbolAcceptingDoFixture
{
   private ProductionStatusUpdateRequestBuilderFixture requestFixture = new ProductionStatusUpdateRequestBuilderFixture();
   private ProductionStatusUpdateResponse response;

   public Fixture requests() {
      return requestFixture;
   }

   public void update() {
      ProductionStatusUpdateRequest[] productionStatusUpdateRequests = requestFixture.getRequests();
      response = callService(productionStatusUpdateRequests);
   }

   private ProductionStatusUpdateResponse callService(ProductionStatusUpdateRequest[] productionStatusUpdateRequests) {
      return getClient().updateProductionStatus(productionStatusUpdateRequests);
   }

   private ProductRelationshipService getClient() {
      String configLocation = "/com/monsanto/tcc/lexiconfixtures/client.xml";
      ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(configLocation);
      return (ProductRelationshipService) context.getBean("productionStatusService");
   }

   public long numberOfUpdatesMade() {
      return successfulUpdates() + failedUpdates();
   }

   public long successfulUpdates() {
      return response.getSuccessCount();
   }

   public long failedUpdates() {
      return response.getFailureCount();
   }

   public Fixture failedProductPubkeys() {
      return new SafeSortSymbolAcceptingRowFixture() {
         public Class getTargetClass() {
            return Pubkey.class;
         }

         public Object[] query()
            throws Exception
         {
            return getPubkeys();
         }
      };
   }

   private Pubkey[] getPubkeys() {
      UpdateStatusResponse[] updateStatusResponses = response.getUpdateResponseList();
      return updateStatusResponses == null ? new Pubkey[0] : getPubkeys(updateStatusResponses);
   }

   private Pubkey[] getPubkeys(UpdateStatusResponse[] responses) {
      List<Pubkey> pubkeys = new ArrayList<Pubkey>();
      for (UpdateStatusResponse response : responses) {
         pubkeys.add(new Pubkey(response.getProductPubkey()));
      }
      return pubkeys.toArray(new Pubkey[pubkeys.size()]);
   }
}
