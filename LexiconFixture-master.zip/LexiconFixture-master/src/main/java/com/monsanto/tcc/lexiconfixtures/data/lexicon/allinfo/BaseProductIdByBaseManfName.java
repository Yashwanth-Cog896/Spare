/*
 BaseProductIdByBaseManfName was created on Jul 17, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo;

import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald Jul 17, 2007 2:32:48 PM
 */
public class BaseProductIdByBaseManfName
   extends AbstractPersistentStoreSingleResultQuery
{
   private final String baseManufacturingName;

   public BaseProductIdByBaseManfName(String baseManufacturingName) {
      this.baseManufacturingName = baseManufacturingName;
   }

   public Long getId()
      throws WrappingException
   {
      return (Long) execute();
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return row.getLONG(1);
   }

   protected String getSQL()
      throws WrappingException
   {
      return "SELECT base_product_id FROM Lexicon.Base_Product WHERE base_manufacturing_name = ?";
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { baseManufacturingName };
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
}