package com.monsanto.tcc.lexiconfixtures.util.random;

import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Mar 22, 2007
 * Time: 9:50:53 AM
 * To change this template use File | Settings | File Templates.
 */
public abstract class RandomValueColumnFixture
   extends SymbolAcceptingColumnFixture
{

   public static final int STD_MIN = 100000000;
   public static final int STD_MAX = 999999999;

   public int minValue = STD_MIN;
   public int maxValue = STD_MAX;
   
   private int range() {
      return maxValue - minValue;
   }

   protected int getIntValue() {
      return (int)(Math.random() * range()) + minValue;
   }
}
