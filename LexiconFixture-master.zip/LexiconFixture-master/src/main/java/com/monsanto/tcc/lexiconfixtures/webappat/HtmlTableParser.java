package com.monsanto.tcc.lexiconfixtures.webappat;

import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tcc.lexiconfixtures.selenium.LexiconSelenium;
import com.monsanto.testutil.DocumentFromHTMLBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: PJBERRY
 * Date: Apr 1, 2007
 * Time: 6:47:21 PM
 */
public class HtmlTableParser
{
   private final Document tableDoc;
   private final LexiconSelenium selenium;

   public HtmlTableParser(LexiconSelenium selenium, String locator)
      throws IOException, ParserConfigurationException, SAXException
   {
      String tableHtml = selenium.getEval("{this.page().findElement('"+ locator +"').innerHTML}");
      DocumentFromHTMLBuilder docBuilder = new DocumentFromHTMLBuilder();
      this.tableDoc = docBuilder.getWellFormedXMLDocumentFromXMLString(tableHtml);
      this.selenium = selenium;
   }

   public String[][] getTable() {
      String[] headerRow = getHeaderRow();
      String[][] tableData = getTableData();
      return assembleTable(headerRow, tableData);
   }

   private String[][] assembleTable(String[] headerRow, String[][] tableData)
   {
      String[][] tableGrid = new String[tableData.length + 1][headerRow.length];
      tableGrid[0] = headerRow;
      for (int i = 1; i < tableGrid.length; i++) {
         tableGrid[i] = tableData[i - 1];
      }
      return tableGrid;
   }

   private String[] getHeaderRow()
   {
      Node body = DOMUtil.getChild(tableDoc.getDocumentElement(), "body");
      Node thead = DOMUtil.getChild(body, "thead");
      Node tr = DOMUtil.getChild(thead, "tr");
      Node[] cells = DOMUtil.getChildren(tr, "th");

      List cellValues = new ArrayList();
      for (int i = 0; i < cells.length; i++) {
         Node cell = cells[i];
         cellValues.add(DOMUtil.getTextValue(cell));
      }
      return (String[])cellValues.toArray(new String[cellValues.size()]);
   }

   private String[][] getTableData()
   {
      Node body = DOMUtil.getChild(tableDoc.getDocumentElement(), "body");
      Node tbody = DOMUtil.getChild(body, "tbody");
      Node[] tableRows = DOMUtil.getChildren(tbody, "tr");

      List tableData = new ArrayList();
      for (int i = 0; i < tableRows.length; i++) {
         Node tableRow = tableRows[i];
         tableData.add(parseRow(tableRow));
      }

      String[][] retVal = new String[tableData.size()][((String[])tableData.get(0)).length];
      for (int i = 0; i < retVal.length; i++) {
         retVal[i] = (String[])tableData.get(i);
      }

      return retVal;
   }

   private String[] parseRow(Node tableRow) {
      Node[] cells = DOMUtil.getChildren(tableRow, "td");
      List cellValues = new ArrayList();
      for (int i = 0; i < cells.length; i++) {
         Node cell = cells[i];
         cellValues.add(getStringRepresentationOfCell(cell));
      }
      return (String[])cellValues.toArray(new String[cellValues.size()]);
   }

   private String getStringRepresentationOfCell(Node cell)
   {
      String cellAsString = "";

      cellAsString += parseInputsInCell(cell);
      cellAsString += parseSingleSelectsInCell(cell);
      cellAsString += parseLinksInCell(cell);
      cellAsString += parseImagesInCell(cell);
//      cellAsString += parseLinksWithImageInCell(cell);
      cellAsString += parseListInCell(cell);
      cellAsString += getCellText(cell);

      return cellAsString;
   }

   private String getCellText(Node cell) {
      String text = DOMUtil.getTextValue(cell);
      if(text == null || text.charAt(0) == '\u00A0' ) {
         return "";
      }
      else {
         return text;
      }
   }

   private String parseImagesInCell(Node cell) {
      String imagesAsString = "";
      Node[] images = DOMUtil.getChildren(cell, "img");
      for (int i = 0; i < images.length; i++) {
         Node image = images[i];
         String src = DOMUtil.getAttribute((Element)image, "src");
         imagesAsString += "[" + LexiconImages.iconFromImageSource(src) + "]";
      }
      return imagesAsString;
   }

   private String parseLinksInCell(Node cell) {
      String representation = "";
      Node[] linkNodes = DOMUtil.getChildren(cell, "a");
      for (Node linkNode : linkNodes) {
         representation += getStringRepresentationOfCell(linkNode);
      }
      return representation;
   }

   private String parseSingleSelectsInCell(Node cell)
   {
      String selectsAsString = "";
      Node[] selects = DOMUtil.getChildren(cell, "select");
      for (int i = 0; i < selects.length; i++) {
         Node select = selects[i];
         selectsAsString += getStringRepresentationOfSelect(select);
      }
      return selectsAsString;
   }

   private String parseInputsInCell(Node cell)
   {
      String inputsAsString = "";
      Node[] inputs = DOMUtil.getChildren(cell, "input");
      for (int i = 0; i < inputs.length; i++) {
         Node input = inputs[i];
         inputsAsString += getStringRepresentationOfInput(input);
      }
      return inputsAsString;
   }

   private String parseListInCell(Node cell) {
      String listAsString = "";
      Node ul = DOMUtil.getChild(cell, "ul");
      if (ul != null) {
         Node[] listMembers = DOMUtil.getChildren(ul, "li");
         for (int i = 0; i < listMembers.length; i++) {
            Node li = listMembers[i];
            if(i > 0) {
               listAsString += ", ";
            }
            listAsString += DOMUtil.getTextValue(li).replace('\u00A0', ' ').trim();
         }
      }
      return listAsString;
   }

   private String getStringRepresentationOfSelect(Node select) {
      String name = DOMUtil.getAttribute((Element)select, "name");
      boolean multiSelect = DOMUtil.getAttribute((Element) select, "multiple") != null;
      return multiSelect ? getSelectedLabelsAsCsv(name) : selenium.getSelectedLabel(name);
   }

   private String getSelectedLabelsAsCsv(String name) {
      String[] labels = getSelectedLabels(name);
      StringBuffer labelCsv = new StringBuffer();
      for (int i = 0; i < labels.length; i++) {
         if(i > 0) {
            labelCsv.append(", ");
         }
         labelCsv.append(labels[i]);
      }
      return labelCsv.toString();
   }

   private String[] getSelectedLabels(String name) {
      return selenium.isSomethingSelected(name) ? selenium.getSelectedLabels(name) : new String[0];
   }

   private String getStringRepresentationOfInput(Node input)
   {
      String type = DOMUtil.getAttribute((Element)input, "type");
      String name = DOMUtil.getAttribute((Element)input, "name");
      String inputValue = null;
      if(type == null) {
         inputValue = selenium.getValue(name);
      }
      else if(type.equals("checkbox")) {
         inputValue = getCheckBoxRepresentation(selenium.getValue(name));
      }
      return inputValue;
   }

   private String getCheckBoxRepresentation(String value) {
      return "on".equals(value) ? "checked" : "unchecked";
   }
}