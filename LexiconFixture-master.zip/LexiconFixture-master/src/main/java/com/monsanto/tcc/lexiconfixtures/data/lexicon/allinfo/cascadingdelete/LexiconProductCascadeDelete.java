/*
 LexiconProductCascadeDelete was created on Jul 17, 2007 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo.cascadingdelete;

import com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo.cascadingdelete.query.id.LexiconProductCountryIdsByLexiconProductId;
import com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo.cascadingdelete.query.delete.LexiconProductDelete;
import com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo.cascadingdelete.query.delete.AbstractLexiconDeleteByIDDataMod;
import com.monsanto.Util.Exceptions.WrappingException;
import java.util.List;

/**
 * nbwald Jul 17, 2007 12:23:35 PM
 */
public class LexiconProductCascadeDelete
   extends AbstractCascadingDelete
{
   private final long productId;

   public LexiconProductCascadeDelete(long productId) {
      this.productId = productId;
   }

   protected boolean removeDependencies()
      throws WrappingException
   {
      List<Long> aliasIds = getDependentProductAliases();
      return removeDependentProductAliases(aliasIds);
   }

   protected AbstractLexiconDeleteByIDDataMod getSelfDeleter() {
      return new LexiconProductDelete(productId);
   }

   private List<Long> getDependentProductAliases()
      throws WrappingException
   {
      LexiconProductCountryIdsByLexiconProductId aliasQuery = new LexiconProductCountryIdsByLexiconProductId(productId);
      return aliasQuery.getIds();
   }

   private boolean removeDependentProductAliases(List<Long> aliasIds)
      throws WrappingException
   {
      boolean removed = true;
      for (long aliasId : aliasIds) {
         LexiconProductCountryCascadeDelete dependentRemover = new LexiconProductCountryCascadeDelete(aliasId);
         removed &= dependentRemover.remove();
      }
      return removed;
   }
}