package com.monsanto.tcc.lexiconfixtures.data.lexicon.baseproduct;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.LexiconDataFixtureDelete;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jun 28, 2007
 * Time: 12:26:26 PM
 */
public class RemoveBaseProduct
   extends SymbolAcceptingColumnFixture
{
   public String baseManufacturingName;

   public boolean removed()
      throws WrappingException
   {
      final BaseProductDelete dataMod = new BaseProductDelete(baseManufacturingName);
      return dataMod.performDelete() == 1;
   }

   class BaseProductDelete
      extends LexiconDataFixtureDelete
   {
      private final String baseManufacturingName;

      public BaseProductDelete(String baseManufacturingName) {
         this.baseManufacturingName = baseManufacturingName;
      }

      protected String getSQL()
         throws WrappingException
      {
         return new SQLPropFile(BaseProductFixtureSQL.class).getSQL(BaseProductFixtureSQL.DELETE_BASE_PRODUCT);
      }

      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[] {baseManufacturingName};
      }

      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new LexiconConnectionFactoryProperties();
      }
   }
}
