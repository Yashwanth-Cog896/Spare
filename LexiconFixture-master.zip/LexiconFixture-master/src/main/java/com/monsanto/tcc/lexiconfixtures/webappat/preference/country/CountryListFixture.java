/*
 CountryListFixture was created on Mar 15, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.webappat.preference.country;

import com.monsanto.tcc.lexiconfixtures.util.preference.UserPreferencesTestTool;
import fitnesse.fixtures.TableFixture;
import java.util.ArrayList;
import java.util.List;

/**
 * nbwald Mar 15, 2007 10:04:20 AM
 * <p/>
 * Sample table:
 * |Primary Country List|
 * |FRA|
 * |HUN|
 * |ITA|
 * <p/>
 * See LexiconWiki.LexiconAcceptanceTests.
 * MonsantoProductAssignGermplasmTests.
 * MonsantoProductAssignGermplasmUiTests.
 * AddCountriesToAssignToPreComlProduct
 */
public abstract class CountryListFixture
   extends TableFixture
{
   protected abstract void setCurrentUsersPreferenceCountries(List countryPreferenceValues)
      throws Exception;

   protected void doStaticTable(int numCountries) {
      List countryAbbrs = getCountryAbbreviations(numCountries);
      try {
         saveCountryPreferences(countryAbbrs);
      }
      catch (Exception e) {
         e.printStackTrace();
         throw new RuntimeException(e);
      }
   }

   private List getCountryAbbreviations(int numCountries) {
      List countryAbbrs = new ArrayList(numCountries);
      for (int r = 0; r < numCountries; r++) {
         countryAbbrs.add(getText(r, 0));
      }
      return countryAbbrs;
   }

   private void saveCountryPreferences(List countryAbbrs)
      throws Exception
   {
      List preferenceValues = createPrefValuesList(countryAbbrs);
      setCurrentUsersPreferenceCountries(preferenceValues);
   }

   private List createPrefValuesList(List countryAbbrs)
      throws Exception
   {
      List preferenceValues = new ArrayList();
      for (int i = 0; i < countryAbbrs.size(); i++) {
         preferenceValues.add(
            UserPreferencesTestTool.
               getCountryPreferenceValueFromAbbr(
                  (String)countryAbbrs.get(i)));
         right(i, 0);
      }
      return preferenceValues;
   }
}