package com.monsanto.tcc.lexiconfixtures.data.lexicon.trait;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * User: pjberry
 * Date: May 23, 2007
 * Time: 4:02:20 PM
 */
public class DeleteComlTraitStackByCropAndStackAbbreviation
{
   public int removeStackInfo(PersistentStoreConnection conn, String crop, String stackAbbr)
      throws WrappingException
   {
      String sql = getSQL();
      PersistentStoreStatement statement = conn.prepareStatement(sql);
      try {
         statement.setParam(1, crop);
         statement.setParam(2, stackAbbr);
         return statement.executeDelete();
      }
      finally {
         statement.close();
      }
   }

   private String getSQL() {
      return
         "DELETE " +
            "FROM " +
            "Lexicon.Coml_Trait_Stack2 CTS " +
            "WHERE " +
            "CTS.crop_id = (SELECT C.crop_id FROM Lexicon.Crop C WHERE UPPER(C.crop_name) = UPPER(?)) " +
            "AND " +
            "CTS.stack_abbr = ?";
   }

}
