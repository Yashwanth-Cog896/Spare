package com.monsanto.tcc.lexiconfixtures.webappat.preference.crop;

import com.monsanto.tcc.lexiconcommon.PreferenceNames;
import com.monsanto.tcc.lexiconfixtures.util.preference.UserPreferencesTestTool;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jul 2, 2007
 * Time: 2:31:24 PM
 */
public class CropPrefStorageTool
{
   private String cropName;

   public boolean saveCropPreference()
      throws Exception
   {
      cropName = UserPreferencesTestTool.getCurrentPreferenceDefaultValue(PreferenceNames.CROP_NAME_PREF_NAME);
      return true;
   }

   public boolean restoreCropPreference()
      throws Exception
   {
      UserPreferencesTestTool.setCurrentUsersDefaultPreferenceValue(PreferenceNames.CROP_NAME_PREF_NAME, cropName);
      return true;
   }
}
