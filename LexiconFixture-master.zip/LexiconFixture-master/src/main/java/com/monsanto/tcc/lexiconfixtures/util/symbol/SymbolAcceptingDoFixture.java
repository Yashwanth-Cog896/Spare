/*
 SymbolAcceptingDoFixture was created on Sep 10, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.util.symbol;

import fitlibrary.DoFixture;

/**
 * nbwald Sep 10, 2007 9:56:23 AM
 */
public class SymbolAcceptingDoFixture
   extends DoFixture
{
   public SymbolAcceptingDoFixture() {
      registerParseDelegate(String.class, new StringParseDelagate());
      registerParseDelegate(Long.class, new LongParseDelagate());
      registerParseDelegate(Integer.class, new IntegerParseDelegate());
   }
}