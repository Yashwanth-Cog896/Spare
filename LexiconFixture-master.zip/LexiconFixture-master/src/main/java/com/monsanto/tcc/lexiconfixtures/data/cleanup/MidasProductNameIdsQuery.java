package com.monsanto.tcc.lexiconfixtures.data.cleanup;

import com.monsanto.tcc.lexiconcommon.db.SqlUtilities;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import java.util.List;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jun 6, 2007
 * Time: 5:10:25 PM
 */
public class MidasProductNameIdsQuery
   extends AbstractPersistentStoreMultiRowQuery
{
   private List productIds;
   public MidasProductNameIdsQuery() {
   }
   public MidasProductNameIdsQuery(final List productIds) {
      this.productIds = productIds;
   }

   public List getIdList() throws WrappingException {
      return super.getList();
   }
   protected Object createObjectFromRow(PersistentStoreResultSetRow row) throws WrappingException {
      return row.getString(1);
   }

   protected Object[] getBindVariables() throws WrappingException {
      return new Object[0];
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MidasConnectionFactoryProperties();
   }

   protected String getSQL()
      throws WrappingException
   {
      if (productIds == null) {
         productIds = new MidasProductIdsQuery().getIdList();
      }
      return "SELECT product_name_id " +
         "FROM Midas.Product_Name PN " +
         "WHERE " + SqlUtilities.makeInListOfNumerics("PN.product_id", productIds);
   }
}
