package com.monsanto.tcc.lexiconfixtures.util;

import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.KerberosServletSecurity.MonsantoAuthFilter;
import com.monsanto.Util.EnvironmentHelper;
import com.monsanto.Util.EnvironmentHelperException;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 7, 2006
 * Time: 10:45:10 AM
 */
public class EnvironmentFixture
   extends SymbolAcceptingColumnFixture
{
   public String environment;
   public String moncryptjvLocation;

   public boolean set()
      throws EnvironmentHelperException
   {
      System.setProperty(EnvironmentHelper.sf_cstrSystem, environment);
      System.setProperty(MonsantoAuthFilter.MONCRYPTJV_PROPERTY, moncryptjvLocation);
      return true;
   }
}
