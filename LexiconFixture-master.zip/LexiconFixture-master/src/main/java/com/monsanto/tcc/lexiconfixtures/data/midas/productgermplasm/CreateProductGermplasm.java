package com.monsanto.tcc.lexiconfixtures.data.midas.productgermplasm;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreInsert;
import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 7, 2006
 * Time: 4:44:19 PM
 * To change this template use File | Settings | File Templates.
 */
public class CreateProductGermplasm
   extends SymbolAcceptingColumnFixture
{
   public Long productGermplasmId;
   public Long germplasmId;
   public Long productId;

   public boolean created()
      throws WrappingException
   {
      MidasProdGermplasmInsert dataMod = new MidasProdGermplasmInsert();
      return dataMod.performInsert() == 1;
   }

   class MidasProdGermplasmInsert
      extends AbstractPersistentStoreInsert
   {
      protected String getSQL() throws WrappingException {
         return new SQLPropFile(ProductGermplasmFixtureSQL.class).
            getSQL(ProductGermplasmFixtureSQL.INSERT_PRODUCT_GERMPLASM);
      }
      protected Object[] getBindVariables() throws WrappingException {
         return new Object[] { productGermplasmId, productId, germplasmId };
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new MidasConnectionFactoryProperties();
      }
   }
}


