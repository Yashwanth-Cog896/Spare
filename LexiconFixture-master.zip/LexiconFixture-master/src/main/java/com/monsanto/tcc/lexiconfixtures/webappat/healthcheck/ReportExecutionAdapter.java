/*
 ReportExecutionAdapter was created on Mar 30, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.webappat.healthcheck;

/**
 * nbwald Mar 30, 2007 12:44:26 PM
 */
public class ReportExecutionAdapter {
   public String reportName;
   public String reportContents;
}