package com.monsanto.tcc.lexiconfixtures.data.lexicon.trait;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * User: pjberry
 * Date: May 23, 2007
 * Time: 4:11:59 PM
 */
public class DeleteComlTraitStackXrefsByComlTraitStackId
{
   public int delete(PersistentStoreConnection conn, Long stackId)
      throws WrappingException
   {
      String sql = getSql();
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, stackId);
         return stmt.executeDelete();
      }
      finally {
         stmt.close();
      }
   }

   private String getSql() {
      return "DELETE FROM Lexicon.Coml_Trait_Stack_Xref2 CTSX WHERE CTSX.coml_trait_stack_id = ?";
   }
}
