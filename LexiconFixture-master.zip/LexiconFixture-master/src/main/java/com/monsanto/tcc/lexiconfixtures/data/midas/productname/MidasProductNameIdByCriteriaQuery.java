package com.monsanto.tcc.lexiconfixtures.data.midas.productname;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Dec 15, 2006
 * Time: 11:49:43 AM
 * To change this template use File | Settings | File Templates.
 */
public class MidasProductNameIdByCriteriaQuery
   extends AbstractPersistentStoreSingleResultQuery
{
   private final String preComlName;
   private final String productName;
   private final String brandName;
   private final String countryName;

   public MidasProductNameIdByCriteriaQuery(String precomlName, String productName, String brandName, String countryName) {
      this.preComlName = precomlName;
      this.productName = productName;
      this.brandName = StringUtils.toUpperCaseNull(brandName);
      this.countryName = StringUtils.toUpperCaseNull((countryName));
   }

   public Long getProductNameId() throws WrappingException {
      return (Long)execute();
   }
   protected Object createObjectFromRow(PersistentStoreResultSetRow row) throws WrappingException {
      return row.getLONG(1);
   }
   protected String getSQL() throws WrappingException {
      return new SQLPropFile(MidasProductNameFixtureSQL.class).getSQL(
         MidasProductNameFixtureSQL.SELECT_PRODUCT_NAME_ID_BY_CRITERIA);
   }
   protected Object[] getBindVariables() throws WrappingException {
      return new Object[] {preComlName, productName, brandName, countryName};
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MidasConnectionFactoryProperties();
   }
}
