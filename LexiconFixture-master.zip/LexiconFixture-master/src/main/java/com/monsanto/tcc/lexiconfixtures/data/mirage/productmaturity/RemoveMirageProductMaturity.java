package com.monsanto.tcc.lexiconfixtures.data.mirage.productmaturity;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconfixtures.data.factories.mirage.MirageConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.data.mirage.product.MirageProductIdLookup;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Jan 29, 2007
 * Time: 10:43:24 AM
 * To change this template use File | Settings | File Templates.
 */
public class RemoveMirageProductMaturity
   extends SymbolAcceptingColumnFixture
{
   public String productName;
   public String company;
   public String bayerCode;
   public String country;
   public String maturityRating;

   private SQLPropFile sqlPropFile = new SQLPropFile(MirageProductMaturitySQL.class);

   public boolean removed()
      throws WrappingException
   {
      MirageConnectionFactory connectionFactory = new MirageConnectionFactory();
      PersistentStoreConnection conn = connectionFactory.getConnection();
      try {
         int numRemoved = removeData(conn);
         return numRemoved == 1;
      }
      finally {
         conn.close();
      }
   }

   private int removeData(PersistentStoreConnection conn)
      throws WrappingException
   {
      String sql = sqlPropFile.getSQL(MirageProductMaturitySQL.DELETE_MATURITY_BY_PRODUCT_ID);
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, getProductIdByAttributes());
         return stmt.executeDelete();
      }
      finally {
         stmt.close();
      }
   }

   private Long getProductIdByAttributes()
      throws WrappingException
   {
      MirageProductIdLookup lookup = new MirageProductIdLookup(productName, company, country, bayerCode);
      return lookup.getProductId();
   }
}

