package com.monsanto.tcc.lexiconfixtures.data.midas.productname;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreEntityExistsQuery;
import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jun 15, 2007
 * Time: 11:58:45 AM
 */
public class MidasProductNameExistsByPCNameNameBrandCountryRefactiveQuery
   extends AbstractPersistentStoreEntityExistsQuery
{
   private final String preComlName;
   private final String productName;
   private final String brandName;
   private final String countryName;
   private final String refActive;

   public MidasProductNameExistsByPCNameNameBrandCountryRefactiveQuery(final String preComlName, final String productName,
      final String brandName, final String countryName, final boolean refActive)
   {
      this.preComlName = preComlName;
      this.productName = productName;
      this.brandName = brandName;
      this.countryName = countryName;
      this.refActive = refActive ? "T" : "F";
   }

   protected String getSQL() throws WrappingException {
      return new SQLPropFile(MidasProductNameFixtureSQL.class).getSQL(
         MidasProductNameFixtureSQL.CHECK_PRODUCT_NAME_EXISTS_BY_PCNAME_NAME_BRAND_COUNTRY_REF_ACTIVE_QUERY);
   }
   protected Object[] getBindVariables() throws WrappingException {
      return new Object[] {preComlName, productName, brandName, countryName, refActive};
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MidasConnectionFactoryProperties();
   }
}
