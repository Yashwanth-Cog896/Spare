package com.monsanto.tcc.lexiconfixtures.data.lexicon.productname;

import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Feb 16, 2007
 * Time: 4:51:10 PM
 * To change this template use File | Settings | File Templates.
 */
public class RemoveLexiconCompetitiveProductName
   extends SymbolAcceptingColumnFixture
{
   public String productNamePubkey;

   public boolean removed()
      throws WrappingException
   {
      RemoveLexiconCompetitiveProductAliasByAliasPubkey removeByAliasPubkey = new RemoveLexiconCompetitiveProductAliasByAliasPubkey(productNamePubkey);
      return removeByAliasPubkey.remove() == 1;
   }
}
