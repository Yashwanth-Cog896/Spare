package com.monsanto.tcc.lexiconfixtures.data.lexicon.product;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 13, 2006
 * Time: 9:20:02 AM
 * To change this template use File | Settings | File Templates.
 */
public interface LexiconProductFixtureSQL
{
   String INSERT_PRODUCT = "InsertProduct";
   String INSERT_COMPETITIVE_PRODUCT = "InsertCompetitiveProduct";
   String DELETE_PRODUCT = "DeleteProduct";
   String DELETE_COMPETITIVE_PRODUCT = "DeleteCompetitiveProduct";
   String SELECT_PRODUCT_PUBKEY = "SelectProductPubkey";
   String SELECT_BY_MATCHING = "SelectByMatching";
   String SELECT_PRODUCT_VARIETY_NAME = "SelectProductVarietyName";
}
