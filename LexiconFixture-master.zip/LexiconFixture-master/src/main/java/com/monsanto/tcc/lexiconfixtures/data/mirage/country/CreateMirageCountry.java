package com.monsanto.tcc.lexiconfixtures.data.mirage.country;

import com.monsanto.tcc.lexiconfixtures.data.factories.mirage.MirageConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Apr 24, 2007
 * Time: 11:30:58 AM
 * To change this template use File | Settings | File Templates.
 */
public class CreateMirageCountry
   extends SymbolAcceptingColumnFixture
{
   public int countryCode;
   public String countryName;
   public String countryAbbr;
   public String regionCode;

   public boolean created()
      throws WrappingException {
      PersistentStoreConnection conn = new MirageConnectionFactory().getConnection();
      try {
         return createCountry(conn) == 1;
      }
      finally {
         conn.close();
      }
   }

   private int createCountry(PersistentStoreConnection conn)
      throws WrappingException
   {
      PersistentStoreStatement statement = conn.prepareStatement(getSQL());
      try {
         bindSQLParams(statement);
         return statement.executeInsert();
      }
      finally {
         statement.close();
      }
   }

   private void bindSQLParams(PersistentStoreStatement statement) throws WrappingException {
      statement.setParam(1, countryCode);
      statement.setParam(2, countryName);
      statement.setParam(3, countryAbbr);
      statement.setParam(4, regionCode);
   }

   private String getSQL() {
      return "INSERT INTO Mirage2.Countries " +
         "(country_code, country_name, country_abbrev, region_code) " +
         "VALUES " +
         "(?, ?, ?, ?)";
   }
}