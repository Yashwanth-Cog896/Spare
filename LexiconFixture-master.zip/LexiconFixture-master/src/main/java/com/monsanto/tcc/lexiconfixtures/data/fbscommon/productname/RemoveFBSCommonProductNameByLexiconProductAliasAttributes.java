package com.monsanto.tcc.lexiconfixtures.data.fbscommon.productname;

import com.monsanto.tcc.lexiconfixtures.data.lexicon.productname.LexiconProductAliasPubkeyLookup;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Dec 18, 2006
 * Time: 2:09:46 PM
 * To change this template use File | Settings | File Templates.
 */
public class RemoveFBSCommonProductNameByLexiconProductAliasAttributes
{
   private String lexiconPrecomlName;
   private String lexiconCommercialName;
   private String lexiconBrand;
   private String lexiconCountry;

   public RemoveFBSCommonProductNameByLexiconProductAliasAttributes(
      String lexiconPrecomlName,
      String lexiconCommercialName,
      String lexiconBrand,
      String lexiconCountry)
   {
      this.lexiconPrecomlName = lexiconPrecomlName;
      this.lexiconCommercialName = lexiconCommercialName;
      this.lexiconBrand = lexiconBrand;
      this.lexiconCountry = lexiconCountry;
   }

   public int remove()
      throws WrappingException
   {
      RemoveFBSCommonProductNameByPubkey dataMod = new RemoveFBSCommonProductNameByPubkey(getLexiconProductAliasPubkey());
      return dataMod.performDelete();
   }

   private String getLexiconProductAliasPubkey()
      throws WrappingException
   {
      LexiconProductAliasPubkeyLookup lookup =
         new LexiconProductAliasPubkeyLookup(
            lexiconPrecomlName, lexiconCommercialName, lexiconBrand, lexiconCountry);
      return lookup.getPubkey();
   }
}
