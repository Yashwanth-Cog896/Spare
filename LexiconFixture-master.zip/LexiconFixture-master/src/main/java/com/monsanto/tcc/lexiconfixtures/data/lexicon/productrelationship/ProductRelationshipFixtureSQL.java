package com.monsanto.tcc.lexiconfixtures.data.lexicon.productrelationship;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 14, 2006
 * Time: 3:07:09 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ProductRelationshipFixtureSQL
{
   String DELETE_PRODUCT_RELATIONSHIP = "DeleteProductRelationship";
   String DELETE_PRODUCT_RELATIONSHIP_XREF = "DeleteProductRelationshipXref";
   String INSERT_PRODUCT_RELATIONSHIP_XREF = "InsertProductRelationshipXref";
   String CHECK_PRODUCT_IN_RELATIONSHIP = "SelectCountByManfNameAndPCName";
   String PUBKEY_BY_MANF_NAME = "PubkeyByManfName";
}
