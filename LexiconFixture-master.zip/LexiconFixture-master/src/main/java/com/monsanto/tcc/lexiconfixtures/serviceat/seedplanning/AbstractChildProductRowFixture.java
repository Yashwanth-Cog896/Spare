/*
 AbstractChildProductRowFixture was created on Jul 6, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.serviceat.seedplanning;

import com.monsanto.tcc.lexiconcommon.xml.LexiconXPathSelector;
import com.monsanto.tcc.lexiconcommon.xml.SingleNamespaceContext;
import com.monsanto.tcc.lexiconcommon.service.ProductParentGermplasmDocTags;
import fit.RowFixture;
import org.w3c.dom.Node;
import org.w3c.dom.Document;
import java.util.List;
import com.monsanto.XMLUtil.DOMUtil;

/**
 * nbwald Jul 6, 2007 2:20:02 PM
 */
public abstract class AbstractChildProductRowFixture
   extends RowFixture
{
   private Document responseDocument;

   protected AbstractChildProductRowFixture(Document responseDocument) {
      this.responseDocument = responseDocument;
   }

   public Object[] query()
      throws Exception
   {
      LexiconXPathSelector selector = new LexiconXPathSelector(
         new SingleNamespaceContext(ProductParentGermplasmDocTags.PRODUCT_PARENT_NAMESPACE));

      /* Note that because the response document may or may not have relationship information, we
         need to jump directly to product (qualified by a preceding 'products' element so we only
         find child level products).
       */
      List<Node> childProductNodes = selector.selectNodeList(responseDocument,
//         "/ns:" + ProductParentGermplasmDocTags.RESPONSE_ELEM_NAME +
//         "/ns:" + ProductParentGermplasmDocTags.PRODUCT_RELATIONSHIP_ELEM_NAME +
         "//ns:" + ProductParentGermplasmDocTags.PRODUCTS_ELEM_NAME +
         "/ns:" + ProductParentGermplasmDocTags.PRODUCT_ELEM_NAME);

      return query(childProductNodes);
   }

   protected abstract Object[] query(List<Node> childProductNodes);
}