package com.monsanto.tcc.lexiconfixtures.webappat.userpreference;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Apr 3, 2007
 * Time: 3:34:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class CountryAdapter
{
   public String country;

   public CountryAdapter(String country) {
      this.country = country;
   }
}
