package com.monsanto.tcc.lexiconfixtures.data.lexicon.baseproduct;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreEntityExistsQuery;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dbdataservices.SQLUtil;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jun 28, 2007
 * Time: 12:29:03 PM
 */
public class CheckBaseProduct
   extends SymbolAcceptingColumnFixture
{
   public String baseManufacturingName;
   public String cropName;
   public boolean parentProduct;

   public boolean exists()
      throws WrappingException
   {
      final BaseProductExists dataMod = new BaseProductExists();
      return dataMod.entityExists();
   }

   class BaseProductExists
      extends AbstractPersistentStoreEntityExistsQuery
   {
      protected String getSQL()
         throws WrappingException
      {
         return new SQLPropFile(BaseProductFixtureSQL.class).getSQL(BaseProductFixtureSQL.SELECT_BASE_PRODUCT);
      }
      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[]{baseManufacturingName, cropName, SQLUtil.booleanToString(parentProduct)};
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new LexiconConnectionFactoryProperties();
      }
   }
}
