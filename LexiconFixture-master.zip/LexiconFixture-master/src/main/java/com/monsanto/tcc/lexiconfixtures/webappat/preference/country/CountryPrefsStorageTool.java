package com.monsanto.tcc.lexiconfixtures.webappat.preference.country;

import com.monsanto.tcc.lexiconcommon.PreferenceNames;
import com.monsanto.tcc.lexiconfixtures.util.preference.UserPreferencesTestTool;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Apr 3, 2007
 * Time: 2:26:12 PM
 * To change this template use File | Settings | File Templates.
 */
public class CountryPrefsStorageTool
{
   private List primaryCountries;
   private List secondaryCountries;

   public boolean saveCountryPreferences()
      throws Exception
   {
      primaryCountries = UserPreferencesTestTool.getCurrentPreferenceValues(
         PreferenceNames.PRIMARY_COUNTRY_PREF_NAME);
      secondaryCountries = UserPreferencesTestTool.getCurrentPreferenceValues(
         PreferenceNames.SECONDARY_COUNTRY_PREF_NAME);
      return true;
   }

   public boolean restoreCountryPreferences()
      throws Exception
   {
      UserPreferencesTestTool.setCurrentUsersPreferenceValues(
         PreferenceNames.PRIMARY_COUNTRY_PREF_NAME, primaryCountries);
      UserPreferencesTestTool.setCurrentUsersPreferenceValues(
         PreferenceNames.SECONDARY_COUNTRY_PREF_NAME, secondaryCountries);
      return true;
   }
}
