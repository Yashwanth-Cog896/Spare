/*
 SeedProductAdapter was created on Feb 14, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.serviceat.seedproduct;

import com.monsanto.tcc.lexiconcommon.service.aggregateproduct.AggregateProductSchemaConstants;
import com.monsanto.XMLUtil.DOMUtil;
import org.w3c.dom.Element;

/**
 * nbwald Feb 14, 2007 4:27:46 PM
 */
public class SeedProductAdapter {
   public String namePubkey;
   public String productName;
   public String productPubkey;
   public String cropPubkey;
   public String cropName;
   public String brandPubkey;
   public String brandName;
   public String countryPubkey;
   public String countryName;
   public String precommercialName;

   public SeedProductAdapter(Element productElem) {
      this.namePubkey = DOMUtil.getAttribute(productElem, AggregateProductSchemaConstants.PRODUCT_NAME_PUBKEY_ELEM_NAME);
      this.productName = DOMUtil.getChildValue(productElem, AggregateProductSchemaConstants.NAME_ELEM_NAME);
      this.productPubkey = DOMUtil.getChildValue(productElem, AggregateProductSchemaConstants.PRODUCT_PUBKEY_ELEM_NAME);
      this.cropPubkey = DOMUtil.getChildValue(productElem, AggregateProductSchemaConstants.CROP_PUBKEY_ELEM_NAME);
      this.cropName = DOMUtil.getChildValue(productElem, AggregateProductSchemaConstants.CROP_NAME_ELEM_NAME);
      this.brandPubkey = DOMUtil.getChildValue(productElem, AggregateProductSchemaConstants.BRAND_PUBKEY_ELEM_NAME);
      this.brandName = DOMUtil.getChildValue(productElem, AggregateProductSchemaConstants.BRAND_NAME_ELEM_NAME);
      this.countryPubkey = DOMUtil.getChildValue(productElem, AggregateProductSchemaConstants.COUNTRY_PUBKEY_ELEM_NAME);
      this.countryName = DOMUtil.getChildValue(productElem, AggregateProductSchemaConstants.COUNTRY_NAME_ELEM_NAME);
      this.precommercialName = DOMUtil.getChildValue(productElem, AggregateProductSchemaConstants.PRE_COML_NAME_ELEM_NAME);
   }
}