package com.monsanto.tcc.lexiconfixtures.data.midas.germplasm;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreEntityExistsQuery;
import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jun 22, 2007
 * Time: 5:37:47 PM
 */
public class CheckGermplasm
   extends SymbolAcceptingColumnFixture
{
   public Long germplasmId;

   public boolean exists()
      throws WrappingException
   {
      MidasGermplasmExistsQuery query = new MidasGermplasmExistsQuery();
      return query.entityExists();
   }

   class MidasGermplasmExistsQuery
      extends AbstractPersistentStoreEntityExistsQuery
   {
      protected String getSQL() throws WrappingException {
         return new SQLPropFile(GermplasmFixtureSQL.class).getSQL(GermplasmFixtureSQL.SELECT_GERMPLASM);
      }
      protected Object[] getBindVariables() throws WrappingException {
         return new Object[] { germplasmId };
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new MidasConnectionFactoryProperties();
      }
   }
}
