package com.monsanto.tcc.lexiconfixtures.data.midas.productname;

import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 21, 2006
 * Time: 10:21:03 AM
 * To change this template use File | Settings | File Templates.
 */
public class MidasProductNameTranslator
   extends SymbolAcceptingColumnFixture
{
   public String precomlName;
   public String productName;
   public String country;
   public String brand;

   public Long productNameId() throws WrappingException {
      return new MidasProductNameIdByCriteriaQuery(precomlName, productName, brand, country).getProductNameId();
   }
}
