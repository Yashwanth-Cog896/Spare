package com.monsanto.tcc.lexiconfixtures.data.lexicon.configuration;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.LexiconDataFixtureInsert;

/**
 * nbwald - Sep 22, 2008 11:54:17 AM
 */
public class CropConfigurationInsert
   extends LexiconDataFixtureInsert
{
   private final String cropName;
   private final String cropConfigurationName;

   public CropConfigurationInsert(String cropConfigurationName, String cropName) {
      this.cropConfigurationName = cropConfigurationName;
      this.cropName = cropName;
   }

   protected String getSQL()
      throws WrappingException
   {
      final String CONFIGURATION_BY_NAME = "(SELECT CT.configuration_type_id FROM Lexicon.Configuration_Type CT WHERE CT.configuration_type_name = ?)";
      final String CROP_BY_NAME = "(SELECT C.crop_id FROM Lexicon.Crop C WHERE UPPER(C.crop_name) = UPPER(?))";

      return
         "INSERT INTO Lexicon.Configuration_Crop " +
         "(configuration_type_id, crop_id) " +
         " values " +
         "(" + CONFIGURATION_BY_NAME + ", " + CROP_BY_NAME + ")";

   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { cropConfigurationName, cropName };
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
}
