/*
 HttpUnitFixture was created on Jun 12, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.webappat;

import com.meterware.httpunit.Button;
import com.meterware.httpunit.HTMLElement;
import com.meterware.httpunit.HttpUnitOptions;
import com.meterware.httpunit.SubmitButton;
import com.meterware.httpunit.UploadFileSpec;
import com.meterware.httpunit.WebConversation;
import com.meterware.httpunit.WebForm;
import com.meterware.httpunit.WebRequest;
import com.meterware.httpunit.WebResponse;
import com.monsanto.tcc.lexiconcommon.file.excel.ExcelReader;
import com.monsanto.tcc.lexiconcommon.test.LexiconATBase;
import com.monsanto.tcc.lexiconfixtures.util.approle.AppRoleTestToolsFixtureMixin;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingDoFixture;
import com.monsanto.tcc.lexiconfixtures.webappat.excel.TestExcelFile;
import com.monsanto.tcc.lexiconfixtures.webappat.excel.screenfixture.HttpUnitUtils;
import com.monsanto.tcc.lexiconfixtures.webappat.productaliasreport.ExcelSpreadSheetFixture;
import fit.Fixture;
import org.xml.sax.SAXException;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.security.PrivilegedActionException;

/**
 * nbwald Jun 12, 2007 12:31:00 PM
 */
public class HttpUnitFixture
   extends SymbolAcceptingDoFixture
{
   private KerberizedWebInteraction interaction;
   private WebConversation conversation;
   private WebResponse currentPage;

   private AppRoleTestToolsFixtureMixin roles = new AppRoleTestToolsFixtureMixin();

   public boolean connect()
      throws Exception
   {
      interaction = new KerberizedWebInteraction("HttpUnitFixture");
      tryToSetupMultipleTimes();
      return succeededToSetUp() || setup(interaction);
   }

   private void tryToSetupMultipleTimes()
      throws Exception
   {
      final int MAX_TRIES = 5;
      final int TWO_SECONDS = 2000;
      for (int currentTry = 0; currentTry < MAX_TRIES; currentTry++) {
         System.out.println("currentTry = " + currentTry);
         if(tryToSetup(interaction)) {
            break;
         }
         Thread.sleep(TWO_SECONDS);
      }
   }

   private boolean succeededToSetUp() {
      return conversation != null;
   }

   private boolean tryToSetup(KerberizedWebInteraction interaction)
      throws Exception
   {
      try {
         return setup(interaction);
      }
      catch (PrivilegedActionException e) {
         interaction.tearDown();
         return false;
      }
   }

   private boolean setup(KerberizedWebInteraction interaction)
      throws Exception
   {
      interaction.setUp();
      conversation = interaction.getConversation();
      return true;
   }

   public boolean disconnect()
      throws Exception
   {
      interaction.tearDown();
      return true;
   }

   public boolean clickLinkWithHeading(String link, String heading)
      throws IOException, SAXException
   {
      if("Monsanto Product".equals(heading) && "Product Report".equals(link)) {
         currentPage = conversation.getResponse(interaction.getServletURL("ProductAliasGateway"));
      } else {
         throw new RuntimeException("Cannot Find Requested Link");
      }
      return true;
   }

   public boolean click(String thingToClick)
      throws IOException, SAXException
   {
      if("reset".equalsIgnoreCase(thingToClick)) {
         HttpUnitOptions.setScriptingEnabled(true);
         HttpUnitOptions.setExceptionsThrownOnScriptError(true);
         Button resetButton = getQueryPanelForm().getButtonWithID("resetButton");
         resetButton.click();
         return true;
      }
      else if("showGermplasm".equalsIgnoreCase(thingToClick)) {
         toggleCheckbox("showGermplasm");
         return true;
      }
      return false;
   }

   public boolean clickWaitForPageToLoad(String thingToClick)
      throws Exception
   {
      if("querySubmitBtn".equalsIgnoreCase(thingToClick) || "runButton".equalsIgnoreCase(thingToClick)) {
         currentPage = HttpUnitUtils.submitForm(getQueryPanelForm(), thingToClick);
         return true;
      }
      else if ("Download Excel Report".equalsIgnoreCase(thingToClick)) {
         WebForm excelReportForm = currentPage.getFormWithName("excelReportForm");
         currentPage = excelReportForm.submit();
         return true;
      }
      return false;
   }

   private SubmitButton findRealSubmitButtonForForm(WebForm form, String thingToClick) {
      SubmitButton submitButton = form.getSubmitButtonWithID(thingToClick);
      if(submitButton == null) {
         submitButton = form.getSubmitButton(thingToClick);
      }
      return submitButton;
   }

   public String fieldIs(String elementId)
      throws SAXException
   {
      HTMLElement element = findElement(elementId);
      if(fieldIsEditable(elementId)) {
         return element.getAttribute("value");
      }
      else {
         return element.getText();
      }
   }

   public boolean fieldExists(String elementId)
      throws SAXException
   {
      HTMLElement element = currentPage.getElementWithID(elementId);
      return element != null;
   }

   private void toggleCheckbox(String checkboxName)
      throws SAXException
   {
      WebForm form = getQueryPanelForm();
      boolean isChecked = form.getParameterValue(checkboxName) != null;
      form.setCheckbox(checkboxName, !isChecked);
   }

   public boolean enterFor(String value, String textInputIdentifier)
      throws IOException, SAXException
   {
      WebForm queryPanelForm = getQueryPanelForm();
      queryPanelForm.setParameter(textInputIdentifier, value);
      return true;
   }

   public boolean selectFor(String option, String select)
      throws SAXException
   {
      WebForm queryPanelForm = getQueryPanelForm();
      queryPanelForm.setParameter(select, option);
      return true;
   }

   public Fixture checkExcelSpreadsheet()
      throws IOException
   {
      InputStream excelStream = currentPage.getInputStream();
      try {
         ExcelReader excelReader = new ExcelReader(excelStream);
         return new ExcelSpreadSheetFixture(excelReader);
      }
      finally {
         excelStream.close();
      }
   }

   public boolean saveApplicationRoles()
      throws Exception
   {
      return roles.saveApplicationRoles();
   }

   public boolean restoreApplicationRoles()
      throws Exception
   {
      return roles.restoreApplicationRoles();
   }

   public Fixture setApplicationRole() {
      return roles.setApplicationRole();
   }

   private WebForm getQueryPanelForm()
      throws SAXException
   {
      return currentPage.getFormWithName("monProdStageQuery");
   }

   class KerberizedWebInteraction
      extends LexiconATBase
   {
      KerberizedWebInteraction(String name) {
         super(name);
      }

      public String getServletPathBase() {
         return super.getServletPathBase();
      }
   }

   // Template upload stuff
   public boolean gotoServlet(String servletName)
      throws IOException, SAXException
   {
      WebRequest request = interaction.simplePostRequest(interaction.getServletPathBase() + servletName);
      currentPage = conversation.getResponse(request);
      return true;
   }

   public boolean onFormEnterExcelTestFileForAndSubmit(String formName, String inputName)
      throws SAXException, IOException
   {
      WebForm form = currentPage.getFormWithName(formName);
      UploadFileSpec[] fileSpecs = buildUploadFileSpecs(TestExcelFile.getTestExcelFilePathAndName());
      form.setParameter(inputName, fileSpecs);
      currentPage = form.submit();
      return true;
   }

   public String rowIsColor(String rowId)
      throws SAXException
   {
      String className = findElement(rowId).getClassName();
      return UIFixtureUtils.colorFromClassName(className);
   }

   public boolean fieldIsEditable(String elementIdentifier)
      throws SAXException
   {
      String tagName = findElement(elementIdentifier).getTagName();
      return "SELECT".equalsIgnoreCase(tagName) || "INPUT".equalsIgnoreCase(tagName);
   }

   public boolean textExists(String textToFind)
      throws IOException
   {
      return currentPage.getText().contains(textToFind);
   }

   public String titleIs()
      throws SAXException
   {
      return currentPage.getTitle();
   }

   private HTMLElement findElement(String elementIdentifier)
      throws SAXException
   {
      HTMLElement element = findElementById(elementIdentifier);
      if(element != null) {
         return element;
      }
      else {
         return findElementByName(elementIdentifier);
      }
   }

   private HTMLElement findElementById(String elementIdentifier)
      throws SAXException
   {
      return currentPage.getElementWithID(elementIdentifier);
   }

   private HTMLElement findElementByName(String elementIdentifier)
      throws SAXException
   {
      HTMLElement element = findFirstElementWithName(elementIdentifier);
      if(element == null) {
         throw new RuntimeException("Cannot Find An Element with id/name of " + elementIdentifier);
      } else {
         return element;
      }
   }

   private HTMLElement findFirstElementWithName(String elementName)
      throws SAXException
   {
      try {
         return currentPage.getElementsWithName(elementName)[0];
      }
      catch (ArrayIndexOutOfBoundsException e) {
         throw new RuntimeException("Cannot Find An Element with id/name of " + elementName);
      }
   }

   private UploadFileSpec[] buildUploadFileSpecs(String fileName) {
      File file = new File(fileName);
      UploadFileSpec[] fileSpecs = new UploadFileSpec[1];
      fileSpecs[0] = new UploadFileSpec(file);
      return fileSpecs;
   }
}