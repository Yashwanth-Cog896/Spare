package com.monsanto.tcc.lexiconfixtures.util.approle.tpssecurity;

import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreInsert;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.data.factories.spsecurity.SpsecurityConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.random.GetRandomId;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald - Jul 14, 2009 11:42:57 AM
*/
public class NewSecurityGroupDataMod
   extends AbstractPersistentStoreInsert
{
   private final String groupName;
   private final long groupId;

   public NewSecurityGroupDataMod(String groupName) {
      this.groupName = groupName;
      this.groupId = new GetRandomId().value();
   }

   protected String getSQL()
      throws WrappingException
   {
      return 
         " INSERT INTO FBS_Common.SPS_Context_Priv_Group" +
         " (context_priv_group_id, environment_id, name, description)" +
         " VALUES" +
         " (?, (SELECT environment_id FROM FBS_Common.SPS_Environment WHERE name = 'LEXICON' and active = 'T'), ?, 'Fake Lexicon group created for testing purposes.  May be deleted if no tests are running.')";
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { groupId, groupName };
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new SpsecurityConnectionFactoryProperties();
   }
}
