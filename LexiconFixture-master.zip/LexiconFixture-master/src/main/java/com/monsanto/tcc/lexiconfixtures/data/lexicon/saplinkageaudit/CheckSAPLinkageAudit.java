package com.monsanto.tcc.lexiconfixtures.data.lexicon.saplinkageaudit;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * User: pjberry
 * Date: Jul 19, 2007
 * Time: 12:40:52 PM
 */
public class CheckSAPLinkageAudit
   extends SymbolAcceptingColumnFixture
{
   public String pubkey;
   public String requestType;
   public String date;
   public String timeRangeSeconds;

   public boolean exists()
      throws WrappingException
   {
      SAPLinkageAuditEntriesCountByAttributesQuery query = new SAPLinkageAuditEntriesCountByAttributesQuery();
      return query.getCount() > 0;
   }

   private class SAPLinkageAuditEntriesCountByAttributesQuery
      extends AbstractPersistentStoreSingleResultQuery
   {
      public int getCount()
         throws WrappingException
      {
         return (Integer) execute();
      }

      protected Object createObjectFromRow(PersistentStoreResultSetRow row)
         throws WrappingException
      {
         return row.getInt(1);
      }

      protected String getSQL()
         throws WrappingException
      {
         return
            "SELECT COUNT(*) " +
               "FROM " +
               "  Lexicon.Sap_Linkage_Audit SLA " +
               "WHERE " +
               "  SLA.pubkey = ? " +
               "  AND " +
               "  SLA.request_type = ?" +
               "  AND " +
               "  SLA.timestamp >= TO_DATE(?, 'yyyy/mm/dd:hh24:mi:ss') " +
               "  AND " +
               "  SLA.timestamp <= (SELECT TO_DATE(?, 'yyyy/mm/dd:hh24:mi:ss') + ?/86400 FROM DUAL)";
      }

      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[] { pubkey, requestType, date, date, timeRangeSeconds };
      }

      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new LexiconConnectionFactoryProperties();
      }
   }
}
