package com.monsanto.tcc.lexiconfixtures.serviceat.person;

import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import static com.monsanto.tcc.lexiconfixtures.serviceat.person.CsvToLongs.convert;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingRowFixture;
import com.monsanto.tps.lexicon.person.PersonRecord;
import com.monsanto.tps.lexicon.person.service.People;
import com.monsanto.tps.lexicon.person.service.PeopleImpl;
import fit.Fixture;
import fitlibrary.DoFixture;
import org.ietf.jgss.GSSException;

/**
 * nbwald - May 23, 2008 12:04:54 PM
 */
public class PersonFixture extends DoFixture {

   private PersonRecord[] personRecords;
   private String errorMessage;

   public boolean findPeopleWithNetworkIds(String networkIdCSV) throws Exception {
      try {
         personRecords = getClient().findPeopleByNetworkIds(networkIdCSV.split(","));
      } catch (IllegalArgumentException e) {
         errorMessage = e.getMessage();
      }
      return true;
   }

   public boolean findPeopleWithPartyIds(String partyIdCSV) throws Exception {
      try {
         personRecords = getClient().findPeopleByPartyIds(convert(partyIdCSV, "Party Ids"));
      } catch (IllegalArgumentException e) {
         errorMessage = e.getMessage();
      }
      return true;
   }

   private People getClient() throws GSSException {
      return new PeopleImpl(new KerberosStandaloneCredential());
   }

   public String errorMessage() {
      return errorMessage;
   }

   public Fixture checkResults() {
      return new SymbolAcceptingRowFixture() {
         public Class<?> getTargetClass() {
            return PersonRecordAdapter.class;
         }

         public Object[] query()
                 throws Exception {
            return buildPersonRecordAdapters();
         }

      };
   }

   public int numberOfPeopleFound() {
      return personRecords.length;
   }

   private PersonRecordAdapter[] buildPersonRecordAdapters() {
      PersonRecordAdapter[] personRecordAdapters = new PersonRecordAdapter[personRecords.length];
      for (int i = 0; i < personRecords.length; i++) {
         personRecordAdapters[i] = new PersonRecordAdapter(personRecords[i]);
      }
      return personRecordAdapters;
   }
}
