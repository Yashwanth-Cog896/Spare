package com.monsanto.tcc.lexiconfixtures.util.random;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Mar 22, 2007
 * Time: 10:13:23 AM
 * To change this template use File | Settings | File Templates.
 */
public class GetRandomName
   extends RandomValueColumnFixture
{
   public String base;

   public void reset()
      throws Exception
   {
      base = "";
   }

   public String name() {
      return base + "FT-" + getIntValue();
   }
}
