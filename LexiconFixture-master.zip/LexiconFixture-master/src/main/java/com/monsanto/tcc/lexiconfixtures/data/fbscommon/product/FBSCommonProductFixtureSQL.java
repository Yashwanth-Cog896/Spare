package com.monsanto.tcc.lexiconfixtures.data.fbscommon.product;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 13, 2006
 * Time: 8:55:52 AM
 * To change this template use File | Settings | File Templates.
 */
public interface FBSCommonProductFixtureSQL
{
   String INSERT_PRODUCT = "InsertProduct";
   String DELETE_PRODUCT = "DeleteProduct";
}
