package com.monsanto.tcc.lexiconfixtures.data.lexicon.trait;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * User: pjberry
 * Date: Sep 19, 2007
 * Time: 4:32:55 PM
 */
public class ComlTraitNameIdByTraitAbbreviationQuery
   extends AbstractPersistentStoreSingleResultQuery
{
   private final String traitAbbreviation;

   public ComlTraitNameIdByTraitAbbreviationQuery(String traitAbbreviation) {
      this.traitAbbreviation = traitAbbreviation;
   }

   public Long getComlTraitNameId()
      throws WrappingException
   {
      return (Long)execute();
   }

   public Long getComlTraitNameId(PersistentStoreConnection conn)
      throws WrappingException
   {
      return (Long)execute(conn);
   }


   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return row.getLONG(1);
   }

   protected String getSQL()
      throws WrappingException
   {
      return "SELECT CTN.coml_trait_name_id FROM Lexicon.Coml_Trait_Name2 CTN WHERE CTN.trait_abbr = ?";
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[]{traitAbbreviation};
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
}
