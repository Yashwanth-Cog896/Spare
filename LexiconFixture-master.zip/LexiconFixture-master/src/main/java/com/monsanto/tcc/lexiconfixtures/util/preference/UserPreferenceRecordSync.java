package com.monsanto.tcc.lexiconfixtures.util.preference;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreInsert;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreRecordSync;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreUpdate;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jul 2, 2007
 * Time: 4:28:25 PM
 */
public class UserPreferenceRecordSync
   extends AbstractPersistentStoreRecordSync
{
   private final String prefName;
   private final String defaultValue;

   public UserPreferenceRecordSync(final String prefName, final String defaultValue) {
      this.prefName = prefName;
      this.defaultValue = defaultValue;
   }
   protected AbstractPersistentStoreInsert getInsertDataMod() {
      return new InsertUserPreference(prefName, defaultValue);
   }
   protected AbstractPersistentStoreUpdate getUpdateDataMod() {
      return new UpdateUserPreference(prefName, defaultValue);
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
}
