package com.monsanto.tcc.lexiconfixtures.data.mirage.allinfo;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.data.factories.yieldmart.YieldMartConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreDelete;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Mar 19, 2007
 * Time: 3:26:42 PM
 * To change this template use File | Settings | File Templates.
 */
class DeleteYieldMartProductByMirageId
   extends AbstractPersistentStoreDelete
{
   private final Long productId;

   public DeleteYieldMartProductByMirageId(Long productId) {
      this.productId = productId;
   }

   protected String getSQL()
      throws WrappingException
   {
      return "DELETE FROM Yldstg.Map_Product_Mirage MPM WHERE MPM.seed_product_id = ?";
   }
   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { productId };
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new YieldMartConnectionFactoryProperties();
   }
}
