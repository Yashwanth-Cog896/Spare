package com.monsanto.tcc.lexiconfixtures.data.cleanup;

import com.monsanto.tcc.lexiconcommon.db.SqlUtilities;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import java.util.List;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jun 6, 2007
 * Time: 4:47:30 PM
 */
public class GermplasmIdsQuery
   extends AbstractPersistentStoreMultiRowQuery
{
   private List productIds;
   public GermplasmIdsQuery() {
   }
   public GermplasmIdsQuery(final List productIds) {
      this.productIds = productIds;
   }

   public List getIdList()
      throws WrappingException
   {
      return super.getList();
   }
   protected Object createObjectFromRow(PersistentStoreResultSetRow row) throws WrappingException {
      return row.getString(1);
   }
   protected Object[] getBindVariables() throws WrappingException {
      return new Object[0];
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MidasConnectionFactoryProperties();
   }

   protected String getSQL()
      throws WrappingException
   {
      if (productIds == null) {
         productIds = new MidasProductIdsQuery().getIdList();
      }
      final String sql =
         "SELECT GP.germplasm_id " +
         " FROM Midas.Germplasm GP " +
         " WHERE " + DeleteRandomValueData.getNumberClause("GP.germplasm_id") +
         " UNION " +
         " SELECT PGP.germplasm_id " +
         " FROM Midas.Product_Germplasm PGP " +
         " WHERE " + SqlUtilities.makeInListOfNumerics("PGP.product_id", productIds);
      System.out.println(sql);
      return sql;
   }
}
