package com.monsanto.tcc.lexiconfixtures.data.virgo;

import com.monsanto.tcc.lexiconcommon.db.test.VirgoTestTools;
import com.monsanto.tcc.lexiconfixtures.data.factories.virgo.VirgoConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;

/**
 * User: pjberry
 * Date: Aug 1, 2007
 * Time: 4:25:09 PM
 */
public class CreateVirgoGeneticItem
   extends SymbolAcceptingColumnFixture
{
   public String key; 	
   public String event ;
   public String generation;
   public String construct;
   public String variety;
   public String crop;

   public boolean created()
      throws WrappingException
   {
      PersistentStoreConnection conn = new VirgoConnectionFactory().getConnection();
      try {
         int numInserted = VirgoTestTools.insertFakeGeneticItem(key, event, construct, variety, generation, crop.toUpperCase(), conn);
         return numInserted == 1;         
      }
      finally {
         conn.close();
      }
   }
}
