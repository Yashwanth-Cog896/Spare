package com.monsanto.tcc.lexiconfixtures.data.mirage.product;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreEntityExistsQuery;
import com.monsanto.tcc.lexiconfixtures.data.factories.mirage.MirageConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.data.mirage.MirageSQLUtils;
import com.monsanto.tcc.lexiconfixtures.util.ColumnFixtureResetter;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Dec 14, 2006
 * Time: 3:58:29 PM
 */
public class CheckMirageProduct
   extends SymbolAcceptingColumnFixture
{
   public String productName;
   public String company;
   public String bayerCode;
   public String commercialTrait;
   public boolean enabled;
   public String country;

   public void reset()
      throws Exception
   {
      ColumnFixtureResetter.reset(this);
   }

   public boolean exists()
      throws WrappingException
   {
      final MirageProductExistsQuery query = new MirageProductExistsQuery();
      return query.entityExists();
   }

   class MirageProductExistsQuery
      extends AbstractPersistentStoreEntityExistsQuery
   {
      protected String getSQL() throws WrappingException {
         return new SQLPropFile(MirageProductFixtureSQL.class).
            getSQL(MirageProductFixtureSQL.CHECK_MIRAGE_PROD_EXISTS);
      }
      protected Object[] getBindVariables() throws WrappingException {
         return new Object[] {
            productName,
            StringUtils.toUpperCaseNull(company),
            StringUtils.toUpperCaseNull(country),
            enabled ? "Y" : "N",
            MirageSQLUtils.buildBayerCodeForDB(bayerCode),
            StringUtils.toUpperCaseNull(commercialTrait)
         };
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new MirageConnectionFactoryProperties();
      }
   }
}
