/*
	 SubcountryFixture was created on Jun 11, 2008 using Monsanto
	 resources and is the sole property of Monsanto.  Any duplication of the
	 code and/or logic is a direct infringement of Monsanto's copyright.
	*/
package com.monsanto.tcc.lexiconfixtures.serviceat.geography;

import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import static com.monsanto.Util.StringUtils.getLineSeparator;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingRowFixture;
import com.monsanto.tps.lexicon.geography.service.Subcountries;
import com.monsanto.tps.lexicon.geography.service.SubcountriesImpl;
import com.monsanto.tps.lexicon.geography.subcountry.Subcountry;
import fit.Fixture;
import fitlibrary.DoFixture;
import org.ietf.jgss.GSSException;

/**
 * Filename:    $RCSfile: SubcountryFixture.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ggshiv $    	 On:	$Date: 2008-08-12 06:42:09 $
 *
 * @author MMR
 * @version $Revision: 1.8 $
 */
public class SubcountryFixture extends DoFixture {

   private Subcountry[] subCountries;
   private String errorMessage;

   public boolean findSubcountriesWithIsoCodeAndSubcountryName(String isoCode, String subcountryName) throws Exception {
      try {
         subCountries = getClient().findSubcountriesByName(isoCode, subcountryName);
      } catch (IllegalArgumentException e) {
         errorMessage = e.getMessage();
      }
      return true;
   }

   private Subcountries getClient() throws GSSException {
      return new SubcountriesImpl(new KerberosStandaloneCredential());
   }

   public boolean findSubcountriesWithIsoCodeAndAbbreviation(String isoCode, String abbreviationCSV) throws Exception {
      try {
         subCountries = getClient().findSubcountriesByAbbreviation(isoCode, abbreviationCSV.split(","));
      } catch (IllegalArgumentException e) {
         errorMessage = e.getMessage();
      }
      return true;
   }

   public int numberOfSubcountriesFound() {
      return subCountries == null ? 0 : subCountries.length;
   }

   public String errorMessage() {
      return errorMessage.replaceAll(getLineSeparator(), " ");
   }

   public Fixture checkResults() {
      return new SymbolAcceptingRowFixture() {
         public Class<?> getTargetClass() {
            return SubcountryResponseAdaptor.class;
         }

         public Object[] query()
                 throws Exception {
            return buildSubcountryResponseAdaptors();
         }
      };
   }

   private SubcountryResponseAdaptor[] buildSubcountryResponseAdaptors() {
      SubcountryResponseAdaptor[] adaptors = new SubcountryResponseAdaptor[subCountries.length];
      for (int i = 0; i < subCountries.length; i++) {
         adaptors[i] = new SubcountryResponseAdaptor(subCountries[i]);
      }
      return adaptors;
   }

}
