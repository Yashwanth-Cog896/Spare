package com.monsanto.tcc.lexiconfixtures.data.lexicon.product;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Apr 3, 2007
 * Time: 12:12:23 PM
 * To change this template use File | Settings | File Templates.
 */
public class LexiconMonsantoProductPubkeyPreComlNameQuery
   extends AbstractPersistentStoreSingleResultQuery
{
   private final String precomlName;

   public LexiconMonsantoProductPubkeyPreComlNameQuery(String precomlName) {
      this.precomlName = precomlName;
   }

   public String getPubkey()
      throws WrappingException
   {
      return (String)execute();
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return row.getString(1);
   }
   protected String getSQL() {
      return "SELECT PCP.product_pubkey FROM Lexicon.Pre_Coml_Product PCP " +
         "WHERE UPPER(PCP.pre_coml_name) = UPPER(?)";
   }
   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { precomlName } ;
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
}
