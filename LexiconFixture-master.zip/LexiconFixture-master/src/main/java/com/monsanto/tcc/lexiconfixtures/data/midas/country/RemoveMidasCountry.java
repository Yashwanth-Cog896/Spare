package com.monsanto.tcc.lexiconfixtures.data.midas.country;

import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Apr 23, 2007
 * Time: 5:21:55 PM
 * To change this template use File | Settings | File Templates.
 */
public class RemoveMidasCountry
   extends SymbolAcceptingColumnFixture
{
   public String countryName;

   public boolean removed()
      throws WrappingException
   {
      PersistentStoreConnection conn = new MidasConnectionFactory().getConnection();
      try {
         return countriesRemoved(conn) == 1;
      }
      finally {
         conn.close();
      }
   }

   private int countriesRemoved(PersistentStoreConnection conn)
      throws WrappingException
   {
      PersistentStoreStatement statement = conn.prepareStatement(getSQL());
      try {
         statement.setParam(1, countryName);
         return statement.executeDelete();
      }
      finally {
         statement.close();
      }
   }

   private String getSQL() {
      return "DELETE FROM Midas.Country C WHERE C.name = ?";
   }
}
