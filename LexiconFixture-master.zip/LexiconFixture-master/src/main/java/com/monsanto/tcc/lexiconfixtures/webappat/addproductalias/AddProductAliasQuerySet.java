package com.monsanto.tcc.lexiconfixtures.webappat.addproductalias;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Dec 21, 2006
 * Time: 9:02:21 AM
 * To change this template use File | Settings | File Templates.
 */
public class AddProductAliasQuerySet
{
   public String getProductPubkey(String preComlName) throws WrappingException {
      return new ProductPubkeyFromPCNameQuery(preComlName).getPubkey();
   }

   public String getBrandPubkey(String brandName) throws WrappingException {
      return new BrandPubkeyFromNameQuery(brandName).getPubkey();
   }

   public String getCountryPubkey(String countryAbbr) throws WrappingException {
      return new CountryPubkeyFromAbbrQuery(countryAbbr).getPubkey();
   }

   public String getStageTypePubkey(String stage) throws WrappingException {
      return new StageTypePubkeyFromAbbrQuery(stage).getPubkey();
   }

   public String getTraitStackPubkey(String preComlName, String commercialTrait)
      throws WrappingException
   {
      return new StackPubkeyFromAbbrQuery(preComlName, commercialTrait).getPubkey();
   }
}

class ProductPubkeyFromPCNameQuery
   extends AbstractPersistentStoreSingleResultQuery
{
   private final String preComlName;
   public ProductPubkeyFromPCNameQuery(String preComlName) {
      this.preComlName = preComlName;
   }
   protected String getPubkey()
      throws WrappingException
   {
      return (String)execute();
   }
   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return row.getString(1);
   }
   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { preComlName };
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
   protected String getSQL()
      throws WrappingException
   {
      return "SELECT  product_pubkey FROM Lexicon.pre_coml_product WHERE  pre_coml_name = ?";
   }
}

class BrandPubkeyFromNameQuery
   extends AbstractPersistentStoreSingleResultQuery
{
   private final String brandName;
   public BrandPubkeyFromNameQuery(String brandName) {
      this.brandName = brandName;
   }
   protected String getPubkey()
      throws WrappingException
   {
      return (String)execute();
   }
   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return row.getString(1);
   }
   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { brandName };
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
   protected String getSQL()
      throws WrappingException
   {
      return "SELECT brand_pubkey FROM Lexicon.Brand WHERE UPPER(brand_name) = UPPER(?)";
   }
}

class CountryPubkeyFromAbbrQuery
   extends AbstractPersistentStoreSingleResultQuery
{
   private final String countryAbbr;
   public CountryPubkeyFromAbbrQuery(String countryAbbr) {
      this.countryAbbr = countryAbbr;
   }
   protected String getPubkey()
      throws WrappingException
   {
      return (String)execute();
   }
   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return row.getString(1);
   }
   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] {countryAbbr};
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
   protected String getSQL()
      throws WrappingException
   {
      return "SELECT country_pubkey FROM Lexicon.Country WHERE UPPER(country_abbr) = UPPER(?)";
   }
}

class StageTypePubkeyFromAbbrQuery
   extends AbstractPersistentStoreSingleResultQuery
{
   private final String stageAbbr;
   public StageTypePubkeyFromAbbrQuery(String stageAbbr) {
      this.stageAbbr = stageAbbr;
   }
   protected String getPubkey()
      throws WrappingException
   {
      return (String)execute();
   }
   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return row.getString(1);
   }
   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] {stageAbbr};
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
   protected String getSQL()
      throws WrappingException
   {
      return "SELECT stage_pubkey FROM Lexicon.Stage WHERE UPPER(stage_abbr) = UPPER(?)";
   }
}

class StackPubkeyFromAbbrQuery
   extends AbstractPersistentStoreSingleResultQuery
{
   private final String preComlName;
   private final String stackAbbr;
   public StackPubkeyFromAbbrQuery(String preComlName, String stackAbbr) {
      this.preComlName = preComlName;
      this.stackAbbr = stackAbbr;
   }
   protected String getPubkey()
      throws WrappingException
   {
      return (String)execute();
   }

   protected Object createObjectWhenNoRowsFound()
      throws WrappingException
   {
      return "UNKNOWN";
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return row.getString(1);
   }
   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] {stackAbbr, preComlName};
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
   protected String getSQL()
      throws WrappingException
   {
      return "SELECT coml_trait_stack_pubkey FROM Lexicon.Coml_Trait_Stack2 " +
         "WHERE stack_abbr = ? AND crop_id = " +
         "(SELECT crop_id FROM Lexicon.Pre_Coml_Product WHERE pre_coml_name = ?)";
   }
}
