package com.monsanto.tcc.lexiconfixtures.data.midas.allinfo;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Mar 16, 2007
 * Time: 5:18:50 PM
 * To change this template use File | Settings | File Templates.
 */
public class DeleteGermplasmByGermplasmIds
{
   private final String sql = "DELETE FROM Midas.Germplasm GP WHERE GP.germplasm_id = ?";

   public int deleteGermplasm(PersistentStoreConnection conn, Long[] germplasmIds)
      throws WrappingException
   {
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         int numDeleted = 0;
         for (int i = 0; i < germplasmIds.length; i++) {
            stmt.setParam(1, germplasmIds[i]);
            numDeleted += stmt.executeDelete();
         }
         return numDeleted;
      }
      finally {
         stmt.close();
      }
   }
}
