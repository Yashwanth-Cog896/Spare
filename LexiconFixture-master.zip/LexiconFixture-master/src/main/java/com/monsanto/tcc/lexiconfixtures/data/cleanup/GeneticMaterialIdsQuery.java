package com.monsanto.tcc.lexiconfixtures.data.cleanup;

import com.monsanto.tcc.lexiconcommon.db.SqlUtilities;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import java.util.List;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jun 6, 2007
 * Time: 5:33:16 PM
 */
public class GeneticMaterialIdsQuery
   extends AbstractPersistentStoreMultiRowQuery
{
   private List germplasmIds;
   public GeneticMaterialIdsQuery() {
   }
   public GeneticMaterialIdsQuery(final List germplasmIds) {
      this.germplasmIds = germplasmIds;
   }

   public List getIdList() throws WrappingException {
      return super.getList();
   }
   protected Object createObjectFromRow(PersistentStoreResultSetRow row) throws WrappingException {
      return row.getString(1);
   }
   protected Object[] getBindVariables() throws WrappingException {
      return new Object[0];
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MidasConnectionFactoryProperties();
   }

   protected String getSQL()
      throws WrappingException
   {
      if (germplasmIds == null) {
         germplasmIds = new GermplasmIdsQuery().getIdList();
      }
      return "SELECT genetic_material_id " +
         "FROM Midas.Genetic_Material GM " +
         "WHERE " + SqlUtilities.makeInListOfNumerics("GM.germplasm_id", germplasmIds);
   }
}
