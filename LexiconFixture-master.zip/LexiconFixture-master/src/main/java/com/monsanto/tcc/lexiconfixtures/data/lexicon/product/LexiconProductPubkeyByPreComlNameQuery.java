package com.monsanto.tcc.lexiconfixtures.data.lexicon.product;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jun 15, 2007
 * Time: 9:47:02 AM
 */
public class LexiconProductPubkeyByPreComlNameQuery
   extends AbstractPersistentStoreSingleResultQuery
{
   private final String precomlName;
   public LexiconProductPubkeyByPreComlNameQuery(final String precomlName) {
      this.precomlName = precomlName;
   }

   public String getPubkey() throws WrappingException {
      return (String)super.execute();
   }
   protected Object createObjectFromRow(PersistentStoreResultSetRow row) throws WrappingException {
      return row.getString(1);
   }
   protected String getSQL()
      throws WrappingException
   {
      return new SQLPropFile(LexiconProductFixtureSQL.class).
         getSQL(LexiconProductFixtureSQL.SELECT_PRODUCT_PUBKEY);
   }
   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { precomlName };
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
}
