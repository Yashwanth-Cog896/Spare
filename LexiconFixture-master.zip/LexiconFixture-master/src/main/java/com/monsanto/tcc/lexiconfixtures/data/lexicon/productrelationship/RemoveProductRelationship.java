package com.monsanto.tcc.lexiconfixtures.data.lexicon.productrelationship;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.test.LexiconTestTools;
import com.monsanto.tcc.lexiconcommon.db.audit.LexiconAuditor;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 14, 2006
 * Time: 3:02:48 PM
 */
public class RemoveProductRelationship
   extends SymbolAcceptingColumnFixture
{
   public String manufacturingName;

   private SQLPropFile sqlPropFile = new SQLPropFile(ProductRelationshipFixtureSQL.class);

   public boolean removed()
      throws WrappingException
   {
      LexiconConnectionFactory connectionFactory = new LexiconConnectionFactory();
      PersistentStoreConnection conn = connectionFactory.getConnection();
      LexiconAuditor lexiconAuditor = LexiconTestTools.FITNESSE_TEST_AUDITOR;
      lexiconAuditor.initializeStaging(conn);
      try {
         int numDeleted = deleteFakeData(conn);
         return numDeleted == 1;
      }
      finally {
         lexiconAuditor.removeStaging(conn);
         conn.close();
      }
   }

   private int deleteFakeData(PersistentStoreConnection conn)
      throws WrappingException
   {
      String sql = sqlPropFile.getSQL(ProductRelationshipFixtureSQL.DELETE_PRODUCT_RELATIONSHIP);
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, manufacturingName);
         return stmt.executeDelete();
      }
      finally {
         stmt.close();
      }
   }
}