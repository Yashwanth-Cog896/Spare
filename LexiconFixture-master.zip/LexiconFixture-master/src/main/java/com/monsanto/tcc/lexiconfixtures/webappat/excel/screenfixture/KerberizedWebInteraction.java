/*
 KerberizedWebInteraction was created on Dec 11, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.webappat.excel.screenfixture;

import com.monsanto.tcc.lexiconcommon.test.LexiconATBase;
import com.meterware.httpunit.WebConversation;
import java.security.PrivilegedActionException;

/**
 * nbwald Dec 11, 2007 11:52:10 AM
 */
public class KerberizedWebInteraction
{
   private LexiconATBase lexATBase = new LexiconATBase("KerberizedWebInteraction") {
      /* Because LexiconATBase is abstract */
   };

   public WebConversation connect()
      throws Exception
   {
      try {
         // try...
         return tryStartingConversation();
      }
      catch (PrivilegedActionException e) {
         // try again...
         Thread.sleep(5000);
         return tryStartingConversation();
      }
   }

   private WebConversation tryStartingConversation()
      throws Exception
   {
      lexATBase.setUp();
      return lexATBase.getConversation();
   }

   public void disconnect()
      throws Exception
   {
      lexATBase.tearDown();
   }
}