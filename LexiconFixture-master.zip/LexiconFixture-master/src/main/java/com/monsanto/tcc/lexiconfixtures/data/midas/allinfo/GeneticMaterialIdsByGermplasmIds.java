package com.monsanto.tcc.lexiconfixtures.data.midas.allinfo;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSet;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.dataservices.PersistentStoreStatement;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Mar 16, 2007
 * Time: 3:27:58 PM
 * To change this template use File | Settings | File Templates.
 */
public class GeneticMaterialIdsByGermplasmIds
{
   private final String sql = "SELECT gm.genetic_material_id FROM Midas.genetic_material gm where gm.germplasm_id = ?";

   public Long[] getGeneticMaterialIds(PersistentStoreConnection conn, Long[] germplasmIds)
      throws WrappingException
   {
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         Set geneticMaterialIds = new HashSet();
         for (int i = 0; i < germplasmIds.length; i++) {
            Set geneticMaterialIdsForGermplasm = getGeneticMaterialsByGermplasmId(stmt, germplasmIds[i]);
            geneticMaterialIds.addAll( geneticMaterialIdsForGermplasm );
         }
         return (Long[])geneticMaterialIds.toArray(new Long[geneticMaterialIds.size()]);
      }
      finally {
         stmt.close();
      }
   }

   private Set getGeneticMaterialsByGermplasmId(PersistentStoreStatement stmt, Long germplasmId)
      throws WrappingException
   {
      stmt.setParam(1, germplasmId);
      PersistentStoreResultSet resultSet = stmt.executeQuery();
      return getGeneticMaterialIdsFromResults(resultSet);
   }

   private Set getGeneticMaterialIdsFromResults(PersistentStoreResultSet resultSet)
      throws WrappingException
   {
      Set geneticMaterialIds = new HashSet();
      PersistentStoreResultSetFwdIterator iter = resultSet.getForwardIterator();
      while(iter.next()) {
         geneticMaterialIds.add(iter.getLONG(1));
      }
      return geneticMaterialIds;
   }
}
