/*
 UOMFixture was created on Jun 23, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tcc.lexiconfixtures.serviceat.uom;

import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.tcc.lexiconfixtures.serviceat.artemis.client.ClientMethodExecutor;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingRowFixture;
import com.monsanto.tps.lexicon.uom.UnitOfMeasure;
import com.monsanto.tps.lexicon.uom.service.UnitsOfMeasure;
import com.monsanto.tps.lexicon.uom.service.UnitsOfMeasureImpl;
import fit.Fixture;
import fitlibrary.DoFixture;
import org.ietf.jgss.GSSException;

/**
 * @author GGSHIV - Jun 23, 2008 12:40:03 PM
 */
public class UOMFixture extends DoFixture {

   private UnitOfMeasure[] uoms;
   private String errorMessage;

   public boolean findUOMByUOMCode(String codesCSV) throws Exception {
      execute("findByCodes", new Object[]{codesCSV.split(",")});
      return true;
   }

   public boolean findUOMByName(String name) throws Exception {
      execute("findByName", new Object[]{name});
      return true;
   }

   public boolean findUOMByCountryIsoCodeAndDimension(String isoCode, String dimension) throws Exception {
      execute("findByCountryISOcodeAndDimension", new Object[]{isoCode, dimension});
      return true;
   }

   public boolean findUOMBySymbolAndDimension(String symbols, String dimension) throws Exception {
      execute("findBySymbolsAndDimension", new Object[]{symbols.split(","), dimension});
      return true;
   }

   public boolean findUOMByCountryIsoCode(String isoCode) throws Exception {
      execute("findByCountryISOCode", new Object[]{isoCode});
      return true;
   }

   public boolean findUOMByDimension(String dimension) throws Exception {
      execute("findByWildcardableDimension", new Object[]{dimension});
      return true;
   }

   private void execute(String clientMethod, Object[] params) {
      try {
         uoms = new ClientMethodExecutor<UnitOfMeasure>().execute(getClient(), clientMethod, params);
      } catch (IllegalArgumentException e) {
         errorMessage = e.getMessage();
      }
   }

   public String errorMessage() {
      return errorMessage;
   }

   public Fixture checkResults() {
      return new SymbolAcceptingRowFixture() {
         public Class<?> getTargetClass() {
            return UOMResponseAdaptor.class;
         }

         public Object[] query()
                 throws Exception {
            return buildUOMResponseAdaptors();
         }
      };
   }

   public int numberOfUOMRecordsFound() {
      return uoms.length;
   }

   private UOMResponseAdaptor[] buildUOMResponseAdaptors() {
      UOMResponseAdaptor[] responseAdaptors = new UOMResponseAdaptor[uoms.length];
      for (int i = 0; i < uoms.length; i++) {
         responseAdaptors[i] = new UOMResponseAdaptor(uoms[i]);
      }
      return responseAdaptors;
   }

   private UnitsOfMeasure getClient() {
      try {
         return new UnitsOfMeasureImpl(new KerberosStandaloneCredential());
      } catch (GSSException e) {
         e.printStackTrace();
         throw new RuntimeException(e);
      }
   }

}