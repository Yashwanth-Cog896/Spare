/*
	 SubcountryResponseAdaptor was created on Jun 11, 2008 using Monsanto 
	 resources and is the sole property of Monsanto.  Any duplication of the 
	 code and/or logic is a direct infringement of Monsanto's copyright.
	*/
package com.monsanto.tcc.lexiconfixtures.serviceat.geography;

import com.monsanto.tps.lexicon.geography.subcountry.Subcountry;

/**
 * Filename:    $RCSfile: SubcountryResponseAdaptor.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: mmr $    	 On:	$Date: 2008-06-10 20:40:56 $
 *
 * @author MMR
 * @version $Revision: 1.2 $
 */
public class SubcountryResponseAdaptor {

    public String name;
    public String countryIsoCode;
    public String abbreviation;
    public String description;

    public SubcountryResponseAdaptor(Subcountry subCountry) {
        name = subCountry.getName();
        countryIsoCode = subCountry.getCountryISOCode();
        abbreviation = subCountry.getAbbreviation();
        description = subCountry.getDescription();
    }
}
/*
* Revision Log
* : $
*/