/*
 LexiconProductCountryIdsByLexiconProductId was created on Jul 17, 2007 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo.cascadingdelete.query.id;

import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald Jul 17, 2007 12:27:54 PM
 */
public class LexiconProductCountryIdsByLexiconProductId
   extends AbstractLexiconIDQuery
{
   public LexiconProductCountryIdsByLexiconProductId(long productId) {
      super(productId);
   }

   protected String getSQL()
      throws WrappingException
   {
      return "SELECT product_stage_id FROM Lexicon.Product_Stage WHERE product_id = ?";
   }
}