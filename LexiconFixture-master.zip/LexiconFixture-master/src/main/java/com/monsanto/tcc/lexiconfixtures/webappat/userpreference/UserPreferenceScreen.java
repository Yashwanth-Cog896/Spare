package com.monsanto.tcc.lexiconfixtures.webappat.userpreference;

import com.monsanto.tcc.lexiconfixtures.webappat.SeleniumFixture;
import com.monsanto.tcc.lexiconfixtures.webappat.preference.country.CountryPrefsStorageTool;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Apr 3, 2007
 * Time: 2:37:57 PM
 * To change this template use File | Settings | File Templates.
 */
public class UserPreferenceScreen
   extends SeleniumFixture
{
   private CountryPrefsStorageTool countryPrefsTestTool;

   public UserPreferenceScreen() {
      countryPrefsTestTool = new CountryPrefsStorageTool();
   }

   public boolean saveCountryPreferences()
      throws Exception
   {
      countryPrefsTestTool.saveCountryPreferences();
      return true;
   }

   public boolean restoreCountryPreferences()
      throws Exception
   {
      countryPrefsTestTool.restoreCountryPreferences();
      return true;
   }
}
