package com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Mar 19, 2007
 * Time: 10:14:27 AM
 * To change this template use File | Settings | File Templates.
 */
public class DeleteProductRelationshipsByProductRelationshipIds
{
   private final String sql = "DELETE FROM Lexicon.product_relationship PR WHERE PR.product_relationship_id = ?";

   public int deleteProductRelationships(PersistentStoreConnection conn, Long[] productRelationshipIds)
      throws WrappingException
   {
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         int numDeleted = 0;
         for (int i = 0; i < productRelationshipIds.length; i++) {
            stmt.setParam(1, productRelationshipIds[i]);
            numDeleted += stmt.executeDelete();
         }
         return numDeleted;
      }
      finally {
         stmt.close();
      }
   }
}
