package com.monsanto.tcc.lexiconfixtures.data.midas.allinfo;

import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald - Nov 24, 2009 6:46:31 PM
 */
public class DeleteInventoryProductNamesByProductIds
{
   private final String sql = "DELETE FROM Midas.Display_Inventory_Prod_Nm DIPN WHERE DIPN.product_name_id IN (SELECT PN.product_name_id FROM Midas.Product_Name PN WHERE PN.product_id = ?)";

   public int delete(PersistentStoreConnection conn, Long[] productIds)
      throws WrappingException
   {
      PersistentStoreStatement statement = conn.prepareStatement(sql);
      try {
         int numDeleted = 0;
         for (Long productId : productIds) {
            numDeleted += deleteRecord(statement, productId);
         }
         return numDeleted;
      }
      finally {
         statement.close();
      }
   }

   private int deleteRecord(PersistentStoreStatement statement, Long productId)
      throws WrappingException
   {
      statement.setParam(1, productId);
      return statement.executeDelete();
   }
}
