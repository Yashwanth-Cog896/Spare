package com.monsanto.tcc.lexiconfixtures.data.lexicon.country;

import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactory;
import com.monsanto.tcc.lexiconcommon.db.test.LexiconTestTools;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Apr 24, 2007
 * Time: 11:19:00 AM
 * To change this template use File | Settings | File Templates.
 */
public class CreateLexiconCountry
   extends SymbolAcceptingColumnFixture
{
   public long countryID;
   public String countryPubkey;
   public String countryAbbr;
   public String countryName;
   public String isoCode;
   public int unCode;

   public boolean created()
      throws WrappingException {
      PersistentStoreConnection conn = new LexiconConnectionFactory().getConnection();
      LexiconTestTools.FITNESSE_TEST_AUDITOR.initializeStaging(conn);
      try {
         return createCountry(conn) == 1;
      }
      finally {
         LexiconTestTools.FITNESSE_TEST_AUDITOR.removeStaging(conn);
         conn.close();
      }
   }

   private int createCountry(PersistentStoreConnection conn)
      throws WrappingException
   {
      PersistentStoreStatement statement = conn.prepareStatement(getSQL());
      try {
         bindSQLParams(statement);
         return statement.executeInsert();
      }
      finally {
         statement.close();
      }
   }

   private void bindSQLParams(PersistentStoreStatement statement) throws WrappingException {
      statement.setParam(1, countryID);
      statement.setParam(2, countryPubkey);
      statement.setParam(3, countryAbbr);
      statement.setParam(4, countryName);
      statement.setParam(5, isoCode);
      statement.setParam(6, unCode);
   }

   private String getSQL() {
      return "INSERT INTO Lexicon.Country C " +
         "(country_id, country_pubkey, country_abbr, country_name, iso_code, un_code) " +
         "VALUES " +
         "(?, ?, ?, ?, ?, ?)";
   }
}
