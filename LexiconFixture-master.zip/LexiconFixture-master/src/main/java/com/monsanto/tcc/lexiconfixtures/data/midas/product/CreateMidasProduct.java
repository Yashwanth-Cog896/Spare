package com.monsanto.tcc.lexiconfixtures.data.midas.product;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreInsert;
import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.tcc.lexiconfixtures.util.ColumnFixtureResetter;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 7, 2006
 * Time: 11:52:52 AM
 */
public class CreateMidasProduct
   extends SymbolAcceptingColumnFixture
{
   public Long productId;
   public String refActive;
   public String denomination;
   public String crop;

   public void reset()
      throws Exception
   {
      ColumnFixtureResetter.reset(this);
   }

   public boolean created()
      throws WrappingException
   {
      MidasProductInsert dataMod = new MidasProductInsert();
      return dataMod.performInsert() == 1;
   }

   class MidasProductInsert
      extends AbstractPersistentStoreInsert
   {
      protected String getSQL() throws WrappingException {
         return new SQLPropFile(MidasProductFixtureSQL.class).getSQL(MidasProductFixtureSQL.INSERT_PRODUCT);
      }
      protected Object[] getBindVariables() throws WrappingException {
         return new Object[] { productId, crop, denomination, parseRefActive() ? "T" : "F" };
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new MidasConnectionFactoryProperties();
      }
      private boolean parseRefActive() {
         return "t".equalsIgnoreCase(refActive) || "true".equalsIgnoreCase(refActive) || "yes".equalsIgnoreCase(refActive);
      }
   }
}
