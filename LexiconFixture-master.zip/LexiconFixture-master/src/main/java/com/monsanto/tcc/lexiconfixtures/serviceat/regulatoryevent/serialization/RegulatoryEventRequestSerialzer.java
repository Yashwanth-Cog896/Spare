package com.monsanto.tcc.lexiconfixtures.serviceat.regulatoryevent.serialization;

import com.monsanto.tcc.lexiconcommon.service.serialize.BasicSerializer;
import com.monsanto.tcc.lexiconfixtures.serviceat.regulatoryevent.RegulatoryEventRequest;
import com.monsanto.xmlserialization.XmlSerializerBuilder;

/**
 * User: pjberry
 * Date: Aug 2, 2007
 * Time: 3:46:11 PM
 */
public class RegulatoryEventRequestSerialzer
   extends BasicSerializer<RegulatoryEventRequest>
{
   public void registerMappings(XmlSerializerBuilder serializerBuilder) {
      serializerBuilder.registerMapping("http://www.monsanto.com/lexicon/Event", "RegulatoryEventRequest", RegulatoryEventRequest.class);
      serializerBuilder.registerFieldAlias(RegulatoryEventRequest.class, "event", "Event");
      serializerBuilder.registerFieldAlias(RegulatoryEventRequest.class, "crop", "Crop");
   }
}
