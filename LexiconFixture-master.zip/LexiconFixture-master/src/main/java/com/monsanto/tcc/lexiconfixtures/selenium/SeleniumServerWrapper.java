package com.monsanto.tcc.lexiconfixtures.selenium;

import org.openqa.selenium.server.SeleniumServer;
import java.io.IOException;
import java.net.Socket;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: May 8, 2007
 * Time: 6:33:09 PM
 */
public class SeleniumServerWrapper
{
   public static final int SELENIUM_SERVER_PORT = 5555;
   private SeleniumServer server;

   public void startServer()
      throws Exception
   {
     try {
         Socket seleniumSocket = new Socket("localhost", SELENIUM_SERVER_PORT);
         seleniumSocket.close();
      }
      catch (IOException e) {
         server = new SeleniumServer(SELENIUM_SERVER_PORT);
         server.start();
      }
   }

   public void stopServer()
      throws InterruptedException
   {
      if(server != null) server.stop();
   }
}
