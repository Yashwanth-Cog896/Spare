/*
 MenuFixture was created on Feb 12, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.webappat;

import com.monsanto.tcc.lexiconfixtures.selenium.LexiconSelenium;
import com.monsanto.Util.StringUtils;
import fit.Fixture;
import fitlibrary.ArrayFixture;
import java.util.ArrayList;
import java.util.List;

/**
 * nbwald Feb 12, 2007 3:07:37 PM
 */
public class MenuFixture
   extends SeleniumFixture
{
   public Fixture linksIn(String heading) {
      LexiconSelenium selenium = getSelenium();
      String headingLocator = getMenuLocator(heading);
      if(!selenium.isElementPresent(headingLocator)) {
         throw new RuntimeException("Could not find heading locator '" + headingLocator + "'");
      }
      String[] anchorTexts = selenium.getChildAnchorTexts(headingLocator);
      return new MenuItemsFixture(anchorTexts);
   }

   public Fixture headingsIn(String locator) {
      String snippet =
         "{" +
            "var menuElem = this.page().findElement('" + locator + "'); " +
            "var submenuElems = menuElem.childNodes; " +
            "var headerTexts = ''; " +
            "for(i=0; i<submenuElems.length; i++) { " +
            "   var submenuElem = submenuElems[i]; " +
            "   var submenuHeaderElem = submenuElem.firstChild; " +
            "   var submenuHeader = submenuHeaderElem.firstChild.firstChild.nodeValue; " +
            "   headerTexts += submenuHeader + ','; " +
            "}" +
         "headerTexts" +
         "}";
      LexiconSelenium selenium = getSelenium();
      String delimitedValues = selenium.evaluate(snippet);
      String[] values = delimitedValues.split(",");
      return new MenuItemsFixture(values);
   }

   public class MenuItemsFixture
      extends ArrayFixture
   {
      public MenuItemsFixture(String[] menuItemTexts) {
         List menuItems = new ArrayList();
         for (int i = 0; i < menuItemTexts.length; i++) {
            String menuItemText = StringUtils.trimNullable(menuItemTexts[i]);
            menuItems.add(new MenuItem(menuItemText));
         }
         setActualCollection(menuItems);
      }
   }

   public class MenuItem {
      public String link;

      public MenuItem(String link) {
         this.link = link;
      }
   }
}