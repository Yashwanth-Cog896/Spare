package com.monsanto.tcc.lexiconfixtures.util;

import com.monsanto.tcc.lexiconfixtures.selenium.SeleniumServerWrapper;
import com.monsanto.tcc.lexiconfixtures.selenium.LexiconSelenium;

/**
 * nbwald - Jan 23, 2009 1:44:02 PM
 */
public class ConfigureMidasCropMixin
{
   public boolean configureMidasCrop(String cropGenusSpecies)
      throws Exception
   {
      SeleniumServerWrapper serverWrapper = null;
      LexiconSelenium selenium = null;
      try {
         serverWrapper = new SeleniumServerWrapper();
         serverWrapper.startServer();
         selenium = new LexiconSelenium("localhost", SeleniumServerWrapper.SELENIUM_SERVER_PORT, "*iehta", "http://w3d.lexicon.monsanto.com");
         selenium.start();
         Thread.sleep(1000);
         selenium.open("http://w3d.lexicon.monsanto.com/lexicon-app/log/FileLister?fileName=/projects/lexicon/dev/RegulatoryEventServiceMidasCrops%20(6)&content=" + cropGenusSpecies + "&submitBtn=Save");
         selenium.waitForPageToLoad("10000");
         selenium.open("http://w3d.lexicon.monsanto.com/lexicon-app/servlet/LexiconLogout");
         selenium.waitForPageToLoad("10000");
         return true;
      }
      finally {
         if(selenium != null) { selenium.stop(); }
         if(serverWrapper != null) { serverWrapper.stopServer(); }
      }
   }
}
