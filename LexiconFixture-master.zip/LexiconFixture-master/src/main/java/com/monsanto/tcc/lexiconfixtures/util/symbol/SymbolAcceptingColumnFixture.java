package com.monsanto.tcc.lexiconfixtures.util.symbol;

import fit.Binding;
import fit.ColumnFixture;
import fit.Parse;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Apr 13, 2007
 * Time: 3:26:32 PM
 * To change this template use File | Settings | File Templates.
 */
public class SymbolAcceptingColumnFixture
   extends ColumnFixture
{
   protected Binding createBinding(int column, Parse heads)
      throws Throwable
   {
      Binding binding = super.createBinding(column, heads);
      if (binding instanceof Binding.SetBinding) {
         binding = new PotentialRecallBinding((Binding.SetBinding)binding);
      }
      return binding;
   }
}

