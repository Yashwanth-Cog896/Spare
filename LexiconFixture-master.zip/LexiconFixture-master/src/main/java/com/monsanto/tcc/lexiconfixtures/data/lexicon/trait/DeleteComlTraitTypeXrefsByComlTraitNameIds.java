package com.monsanto.tcc.lexiconfixtures.data.lexicon.trait;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * User: pjberry
 * Date: May 25, 2007
 * Time: 9:08:26 AM
 */
public class DeleteComlTraitTypeXrefsByComlTraitNameIds
{
   public int deleteComlTraitTypeXrefs(PersistentStoreConnection conn, Long[] comlTraitNameIds)
      throws WrappingException
   {
      int numDeleted = 0;
      String sql = getSql();
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         for (int i = 0; i < comlTraitNameIds.length; i++) {
            stmt.setParam(1, comlTraitNameIds[i]);
            numDeleted += stmt.executeDelete();
         }
         return numDeleted;
      }
      finally {
         stmt.close();
      }
   }

   private String getSql() {
      return "DELETE FROM Lexicon.Coml_Trait_Type_Xref2 CTTX WHERE CTTX.coml_trait_name_id = ?";
   }

}
