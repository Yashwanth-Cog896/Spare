package com.monsanto.tcc.lexiconfixtures.data.lexicon.trait;

import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactory;
import com.monsanto.tcc.lexiconcommon.db.test.LexiconTestTools;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * User: pjberry
 * Date: May 23, 2007
 * Time: 2:50:05 PM
 */
public class AddTraitToStack
   extends SymbolAcceptingColumnFixture
{
   public Long comlTraitStackXrefId;
   public String comlTraitAbbr;
   public String comlTraitStackAbbr;
   public String crop;

   public boolean added()
      throws WrappingException
   {
      LexiconConnectionFactory connectionFactory = new LexiconConnectionFactory();
      PersistentStoreConnection conn = connectionFactory.getConnection();
      LexiconTestTools.FITNESSE_TEST_AUDITOR.initializeStaging(conn);
      try {
         int numInserted = insertFakeData(conn);
         return numInserted == 1;
      }
      finally {
         LexiconTestTools.FITNESSE_TEST_AUDITOR.removeStaging(conn);
         conn.close();
      }
   }

   private int insertFakeData(PersistentStoreConnection conn)
      throws WrappingException
   {
      String sql = getSql();
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, comlTraitStackXrefId);
         stmt.setParam(2, comlTraitAbbr);
         stmt.setParam(3, crop);
         stmt.setParam(4, comlTraitStackAbbr);
         return stmt.executeInsert();
      }
      finally {
         stmt.close();
      }
   }

   private String getSql() {
      return
         "INSERT INTO Lexicon.Coml_Trait_Stack_Xref2 CTSX " +
            "(coml_trait_stack_xref_id, coml_trait_name_id, coml_trait_stack_id) " +
         "VALUES " +
            "( " +
            "   ?, " +
            "  (SELECT CTN.coml_trait_name_id FROM Lexicon.Coml_Trait_Name2 CTN WHERE CTN.trait_abbr = ?), " +
            "  (SELECT CTS.coml_trait_stack_id FROM Lexicon.Coml_Trait_Stack2 CTS, Lexicon.Crop C WHERE UPPER(C.crop_name) = UPPER(?) AND C.crop_id = CTS.crop_id AND CTS.stack_abbr = ?) " +
            ")";

   }
}
