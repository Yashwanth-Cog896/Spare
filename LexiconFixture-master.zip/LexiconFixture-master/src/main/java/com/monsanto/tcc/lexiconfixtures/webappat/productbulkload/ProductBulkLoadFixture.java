package com.monsanto.tcc.lexiconfixtures.webappat.productbulkload;

import com.monsanto.tcc.lexiconfixtures.util.approle.AppRoleTestToolsFixtureMixin;
import com.monsanto.tcc.lexiconfixtures.webappat.excel.screenfixture.ExcelScreenFixture;
import com.monsanto.tcc.lexiconfixtures.webappat.excel.screenfixture.GenericGatewayBasedHttpUnitPageVisitStrategy;
import com.monsanto.tcc.lexiconfixtures.webappat.excel.screenfixture.HttpUnitPageVisitStrategy;
import fit.Fixture;

/**
 * nbwald - Apr 17, 2008 10:49:48 AM
 */
public class ProductBulkLoadFixture
   extends ExcelScreenFixture
{
   private AppRoleTestToolsFixtureMixin roles = new AppRoleTestToolsFixtureMixin();

   public boolean saveApplicationRoles()
      throws Exception
   {
      return roles.saveApplicationRoles();
   }

   public Fixture setApplicationRole() {
      return roles.setApplicationRole();
   }

   public boolean restoreApplicationRoles()
      throws Exception
   {
      return roles.restoreApplicationRoles();
   }
   
   protected String getMenuHeading() {
      return "Monsanto Product";
   }

   protected String getMenuItem() {
      return "Product Bulk Load";
   }

   protected HttpUnitPageVisitStrategy getInitialPageVisitStrategy() {
      return new GenericGatewayBasedHttpUnitPageVisitStrategy("/ProductBulkLoad.jsp");
   }
}
