/*
 LexiconProductCountryCascadeDelete was created on Jul 17, 2007 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo.cascadingdelete;

import com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo.cascadingdelete.query.delete.LexiconProductCountryDelete;
import com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo.cascadingdelete.query.delete.AbstractLexiconDeleteByIDDataMod;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald Jul 17, 2007 12:32:22 PM
 */
public class LexiconProductCountryCascadeDelete
   extends AbstractCascadingDelete
{
   private final long productCountryId;

   public LexiconProductCountryCascadeDelete(long productCountryId) {
      this.productCountryId = productCountryId;
   }

   protected AbstractLexiconDeleteByIDDataMod getSelfDeleter() {
      return new LexiconProductCountryDelete(productCountryId);
   }

   protected boolean removeDependencies() {
      return true;
   }
}