package com.monsanto.tcc.lexiconfixtures.util.symbol;

import java.util.Map;

/**
 * nbwald - Jul 15, 2008 1:48:03 PM
 */
public abstract class SafeSortSymbolAcceptingRowFixture
   extends SymbolAcceptingRowFixture
{
   protected void bin(Map map, Object key, Object row) {
      if (key == null) {
         key = "null";
      }
      super.bin(map, key, row);
   }
}
