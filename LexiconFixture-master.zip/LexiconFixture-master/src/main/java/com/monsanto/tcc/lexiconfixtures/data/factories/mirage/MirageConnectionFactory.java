package com.monsanto.tcc.lexiconfixtures.data.factories.mirage;

import com.monsanto.tcc.lexiconcommon.db.factories.BasicConnectionFactory;

/**
 * Created by IntelliJ IDEA.
 * User: MAWEAV1
 * Date: Sep 3, 2004
 * Time: 4:33:13 PM
 * To change this template use File | Settings | File Templates.
 */
public class MirageConnectionFactory
   extends BasicConnectionFactory
{
   public MirageConnectionFactory() {
      super(new MirageConnectionFactoryProperties());
   }
}

