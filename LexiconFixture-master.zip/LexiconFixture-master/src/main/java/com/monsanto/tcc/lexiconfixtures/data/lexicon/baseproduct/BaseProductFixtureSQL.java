package com.monsanto.tcc.lexiconfixtures.data.lexicon.baseproduct;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jun 28, 2007
 * Time: 12:29:45 PM
 */
public interface BaseProductFixtureSQL
{
   String INSERT_BASE_PRODUCT = "InsertBaseProduct";
   String DELETE_BASE_PRODUCT = "DeleteBaseProduct";
   String SELECT_BASE_PRODUCT = "SelectBaseProduct";
}
