package com.monsanto.tcc.lexiconfixtures.data.lexicon.baseproduct;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.LexiconDataFixtureInsert;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.dbdataservices.SQLUtil;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jun 27, 2007
 * Time: 4:35:04 PM
 */
public class CreateBaseProduct
   extends SymbolAcceptingColumnFixture
{
   public long baseProductId;
   public String baseManufacturingName;
   public String cropName;
   public boolean parentProduct;

   public boolean created()
      throws WrappingException
   {
      final BaseProductInsert dataMod = new BaseProductInsert();
      return dataMod.performInsert() == 1;
   }

   class BaseProductInsert
      extends LexiconDataFixtureInsert
   {
      protected String getSQL() throws WrappingException {
         return new SQLPropFile(BaseProductFixtureSQL.class).getSQL(BaseProductFixtureSQL.INSERT_BASE_PRODUCT);
      }
      protected Object[] getBindVariables() throws WrappingException {
         return new Object[] {baseProductId, baseManufacturingName, StringUtils.toUpperCaseNull(cropName), SQLUtil.booleanToString(parentProduct) };
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new LexiconConnectionFactoryProperties();
      }
   }
}
