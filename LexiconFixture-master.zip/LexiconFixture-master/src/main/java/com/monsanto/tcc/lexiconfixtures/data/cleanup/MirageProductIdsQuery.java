package com.monsanto.tcc.lexiconfixtures.data.cleanup;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tcc.lexiconfixtures.data.factories.mirage.MirageConnectionFactoryProperties;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import java.util.List;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: May 1, 2007
 * Time: 11:24:24 AM
 */
class MirageProductIdsQuery
   extends AbstractPersistentStoreMultiRowQuery
{
   public List getIdList() throws WrappingException {
      return super.getList();
   }
   protected Object createObjectFromRow(PersistentStoreResultSetRow row) throws WrappingException {
      return row.getString(1);
   }
   protected Object[] getBindVariables()  throws WrappingException {
      return new Object[0];
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MirageConnectionFactoryProperties();
   }

   protected String getSQL() throws WrappingException {
      return "SELECT product_id " +
         "FROM Mirage2.Seed_Products " +
         "WHERE " + DeleteRandomValueData.getNameClause("product_name") +
         " OR " + DeleteRandomValueData.getNumberClause("product_id");
   }
}
