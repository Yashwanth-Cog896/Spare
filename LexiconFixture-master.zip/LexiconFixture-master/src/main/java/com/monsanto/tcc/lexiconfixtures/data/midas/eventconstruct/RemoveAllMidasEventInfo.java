package com.monsanto.tcc.lexiconfixtures.data.midas.eventconstruct;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreDelete;
import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.ColumnFixtureResetter;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald - Mar 24, 2008 12:35:44 PM
 */
public class RemoveAllMidasEventInfo
   extends SymbolAcceptingColumnFixture
{
   public Long eventConstructId;

   public void reset()
      throws Exception
   {
      ColumnFixtureResetter.reset(this);
   }

   public boolean removed()
      throws WrappingException
   {
      return removeAllGermplasmEventConstructs() && removeEventConstruct();
   }

   private boolean removeAllGermplasmEventConstructs()
      throws WrappingException
   {
      return new RemoveGermplasmEventConstructByEventConstructId().performDelete() > 0;
   }

   private boolean removeEventConstruct()
      throws WrappingException
   {
      return new RemoveEventConstructById().performDelete() > 0;
   }

   private class RemoveGermplasmEventConstructByEventConstructId
      extends AbstractPersistentStoreDelete
   {
      protected String getSQL()
         throws WrappingException
      {
         return "DELETE FROM Midas.Germplasm_Event_Construct WHERE event_construct_id = ?";
      }

      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[] { eventConstructId };
      }

      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new MidasConnectionFactoryProperties();
      }
   }

   private class RemoveEventConstructById
      extends AbstractPersistentStoreDelete
   {
      protected String getSQL()
         throws WrappingException
      {
         return "DELETE FROM Midas.Event_Construct WHERE event_construct_id = ?";
      }

      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[] { eventConstructId };
      }

      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new MidasConnectionFactoryProperties();
      }
   }
}
