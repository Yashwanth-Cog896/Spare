package com.monsanto.tcc.lexiconfixtures.util.approle.tpssecurity;

import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreDelete;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.data.factories.spsecurity.SpsecurityConnectionFactoryProperties;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald - Jul 14, 2009 12:32:34 PM
 */
public class RemoveUserFromAllGroupsDataMod
   extends AbstractPersistentStoreDelete
{
   private final String userLoginId;

   public RemoveUserFromAllGroupsDataMod(String userLoginId) {
      this.userLoginId = userLoginId;
   }

   protected String getSQL()
      throws WrappingException
   {
      return 
         " DELETE FROM FBS_Common.SPS_User_Context_Priv_Group" +
         "       WHERE user_id = (" +
         "             SELECT U.user_id" +
         "               FROM FBS_Common.SPS_User U" +
         "         INNER JOIN FBS_Common.SPS_User_Description UD on (U.user_description_id = UD.user_description_id)" +
         "         INNER JOIN FBS_Common.SPS_Environment E on (U.environment_id = E.environment_id)" +
         "              WHERE E.name = 'LEXICON' " +
         "                AND E.active = 'T'" +
         "                AND UD.username = ?" +
         "             )";
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { userLoginId };
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new SpsecurityConnectionFactoryProperties();
   }
}
