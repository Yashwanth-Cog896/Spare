/*
	 CountryResponseAdaptor was created on Jun 11, 2008 using Monsanto 
	 resources and is the sole property of Monsanto.  Any duplication of the 
	 code and/or logic is a direct infringement of Monsanto's copyright.
	*/
package com.monsanto.tcc.lexiconfixtures.serviceat.geography;

import com.monsanto.tps.lexicon.geography.country.Country;

/**
 * Filename:    $RCSfile: CountryResponseAdaptor.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: mmr $    	 On:	$Date: 2008-06-12 12:19:39 $
 *
 * @author MMR
 * @version $Revision: 1.3 $
 */
public class CountryResponseAdaptor {

    public String name;
    public String countryIsoCode;
    public String subcountryDescription;
    public String subsubcountryDescription;
    public String abbreviation;

    public CountryResponseAdaptor(Country country) {
        name = country.getName();
        countryIsoCode = country.getCountryISOcode();
        subcountryDescription = country.getSubCountryDescription();
        subsubcountryDescription = country.getSubSubCountryDescription();
        abbreviation = country.getAbbreviation();
    }
}
/*
* Revision Log
* : $
*/