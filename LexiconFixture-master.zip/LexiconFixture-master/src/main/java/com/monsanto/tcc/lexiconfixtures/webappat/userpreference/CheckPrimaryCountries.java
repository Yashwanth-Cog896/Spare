package com.monsanto.tcc.lexiconfixtures.webappat.userpreference;

import com.monsanto.tcc.lexiconcommon.PreferenceNames;
import com.monsanto.tcc.lexiconfixtures.util.preference.UserPreferencesTestTool;
import fitlibrary.ArrayFixture;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * User: PJBERRY
 * Date: May 19, 2007
 * Time: 7:31:01 AM
 */
public class CheckPrimaryCountries
   extends ArrayFixture
{
   public CheckPrimaryCountries()
      throws Exception
   {
      List countryValues = UserPreferencesTestTool.getCurrentPreferenceValues(
         PreferenceNames.PRIMARY_COUNTRY_PREF_NAME);

      List countries = new ArrayList(countryValues.size());
      for (Iterator iterator = countryValues.iterator(); iterator.hasNext();) {
         String countryValue = (String)iterator.next();
         countries.add(new CountryAdapter(countryValue));
      }
      setActualCollection(countries);
   }
}