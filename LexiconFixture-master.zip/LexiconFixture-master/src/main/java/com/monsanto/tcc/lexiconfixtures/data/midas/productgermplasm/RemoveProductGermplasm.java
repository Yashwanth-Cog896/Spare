package com.monsanto.tcc.lexiconfixtures.data.midas.productgermplasm;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreInsert;
import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 7, 2006
 * Time: 4:48:56 PM
 * To change this template use File | Settings | File Templates.
 */
public class RemoveProductGermplasm
   extends SymbolAcceptingColumnFixture
{
   public Long germplasmId;

   public boolean removed()
      throws WrappingException
   {
      MidasProdGermplasmInsert dataMod = new MidasProdGermplasmInsert();
      return dataMod.performInsert() == 1;
   }

   class MidasProdGermplasmInsert
      extends AbstractPersistentStoreInsert
   {
      protected String getSQL() throws WrappingException {
         return new SQLPropFile(ProductGermplasmFixtureSQL.class).
            getSQL(ProductGermplasmFixtureSQL.DELETE_PRODUCT_GERMPLASM);
      }
      protected Object[] getBindVariables() throws WrappingException {
         return new Object[] { germplasmId };
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new MidasConnectionFactoryProperties();
      }
   }
}