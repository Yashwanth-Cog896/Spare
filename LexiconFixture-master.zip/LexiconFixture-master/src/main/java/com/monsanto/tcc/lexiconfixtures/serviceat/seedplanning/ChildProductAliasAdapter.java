package com.monsanto.tcc.lexiconfixtures.serviceat.seedplanning;

import com.monsanto.tcc.lexiconcommon.service.ProductParentGermplasmDocTags;
import com.monsanto.XMLUtil.DOMUtil;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Feb 14, 2007
 * Time: 8:10:14 AM
 * To change this template use File | Settings | File Templates.
 */
public class ChildProductAliasAdapter
{
   public String productAliasPubkey;
   public String precommercialName;
   public String brand;
   public String country;
   public String commercialName;
   public boolean isDeleted;
   public String commercialMaturity;
   public String traitStack;
   public String trangenicTraits;
   public boolean isActive;
   public String stage;

   public ChildProductAliasAdapter(String precommercialName, Node aliasNode) {
      this.precommercialName = precommercialName;
      this.productAliasPubkey = DOMUtil.getAttribute((Element) aliasNode, ProductParentGermplasmDocTags.PUBKEY_ATTR_NAME);
      this.brand = DOMUtil.getChildValue(aliasNode, ProductParentGermplasmDocTags.BRAND_ELEM_NAME);
      this.country = DOMUtil.getChildValue(aliasNode, ProductParentGermplasmDocTags.COUNTRY_ELEM_NAME);
      this.commercialName = DOMUtil.getChildValue(aliasNode, ProductParentGermplasmDocTags.COMMERCIAL_NAME_ELEM_NAME);
      this.isDeleted = booleanValue(DOMUtil.getChildValue(aliasNode, ProductParentGermplasmDocTags.LOGICALLY_DELETED_ELEM_NAME));
      this.commercialMaturity = DOMUtil.getChildValue(aliasNode, ProductParentGermplasmDocTags.COML_MATURITY_ELEM_NAME);
      this.traitStack = parseTraitStack(aliasNode);
      this.trangenicTraits = parseTransgenicTraits(aliasNode);
      this.isActive = booleanValue(DOMUtil.getChildValue(aliasNode, ProductParentGermplasmDocTags.ACTIVE_ELEM_NAME));
      this.stage = DOMUtil.getChildValue(aliasNode, ProductParentGermplasmDocTags.STAGE_ELEM_NAME);
   }

   private String parseTraitStack(Node aliasNode) {
      Node commercialTraitsNode = getCommercialTraitsNode(aliasNode);
      return DOMUtil.getChildValue(commercialTraitsNode, ProductParentGermplasmDocTags.TRAIT_STACK_ABBR_ELEM_NAME);
   }

   private String parseTransgenicTraits(Node aliasNode) {
      Node commercialTraitsNode = getCommercialTraitsNode(aliasNode);
      return DOMUtil.getChildValue(commercialTraitsNode, ProductParentGermplasmDocTags.TRANSGEN_TRAITS_ELEM_NAME);
   }

   private Node getCommercialTraitsNode(Node aliasNode) {
      return DOMUtil.getChild(aliasNode, ProductParentGermplasmDocTags.COML_TRAIT_ELEM_NAME);
   }

   private boolean booleanValue(String booleanAsString) {
      return Boolean.valueOf(booleanAsString).booleanValue();
   }
}
