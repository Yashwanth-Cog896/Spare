package com.monsanto.tcc.lexiconfixtures.data.lexicon.trait;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.dataservices.PersistentStoreStatement;
import java.util.ArrayList;
import java.util.List;

/**
 * User: pjberry
 * Date: May 23, 2007
 * Time: 4:07:40 PM
 */
public class ComlTraitNameIdsByComlTraitStackIdQuery
{
   public Long[] getTraitNameIds(PersistentStoreConnection conn, Long stackId)
      throws WrappingException
   {
      String sql = getTraitNameIdsSql();
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, stackId);

         List traitNameIds = new ArrayList();
         PersistentStoreResultSetFwdIterator results = stmt.executeQuery().getForwardIterator();
         while(results.next()) {
            traitNameIds.add(results.getLONG(1));
         }
         return (Long[])traitNameIds.toArray(new Long[traitNameIds.size()]);
      }
      finally {
         stmt.close();
      }
   }

   private String getTraitNameIdsSql() {
      return
         "SELECT " +
            "CTSX.coml_trait_name_id " +
          "FROM " +
            "Lexicon.Coml_Trait_Stack_Xref2 CTSX " +
          "WHERE " +
            "CTSX.coml_trait_stack_id = ?";
   }
}
