package com.monsanto.tcc.lexiconfixtures.serviceat.eventagencyalignment;

import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingRowFixture;
import com.monsanto.tps.lexicon.event.EventInfo;

import java.util.ArrayList;
import java.util.List;

/**
 * nbwald - Feb 26, 2009 2:02:18 PM
 */
public class EventResultsRowFixture
   extends SymbolAcceptingRowFixture
{
   private EventInfo[] eventInfos;

   public EventResultsRowFixture(EventInfo[] eventInfos) {
      this.eventInfos = eventInfos;
   }

   @Override
   public Object[] query()
      throws Exception
   {
      return build();
   }

   private EventRowAdaptor[] build() {
      if(eventInfos == null) {
         return new EventRowAdaptor[0];
      }
      else {
         List<EventRowAdaptor> adaptors = new ArrayList<EventRowAdaptor>();
         for (EventInfo eventInfo : eventInfos) {
            adaptors.add(new EventRowAdaptor(eventInfo));
         }
         return adaptors.toArray(new EventRowAdaptor[adaptors.size()]);
      }
   }

   @Override
   public Class<?> getTargetClass() {
      return EventRowAdaptor.class;
   }
}
