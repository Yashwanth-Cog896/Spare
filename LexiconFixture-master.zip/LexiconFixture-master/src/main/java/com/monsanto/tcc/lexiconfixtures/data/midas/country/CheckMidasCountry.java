package com.monsanto.tcc.lexiconfixtures.data.midas.country;

import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.EmptyResultSetException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetSingleResult;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Apr 24, 2007
 * Time: 11:26:54 AM
 * To change this template use File | Settings | File Templates.
 */
public class CheckMidasCountry
   extends SymbolAcceptingColumnFixture
{
   public String countryName;
   public String countryAbbr;
   public String refActive;

   public boolean exists()
      throws WrappingException {
      PersistentStoreConnection conn = new MidasConnectionFactory().getConnection();
      try {
         return matchingCountries(conn) == 1;
      }
      finally {
         conn.close();
      }
   }

   private int matchingCountries(PersistentStoreConnection conn)
      throws WrappingException
   {
      PersistentStoreStatement statement = conn.prepareStatement(getSQL());
      try {
         statement.setParam(1, countryName);
         statement.setParam(2, countryAbbr);
         statement.setParam(3, refActive);
         PersistentStoreResultSetSingleResult result = statement.executeQuery().getSingleResult();
         return result.getInt(1);
      }
      catch (EmptyResultSetException e) {
         return 0;
      } finally {
         statement.close();
      }
   }

   private String getSQL() {
      return
         "     SELECT count(name)" +
         "       FROM Midas.Country C" +
         "      WHERE C.name = ?" +
         "        AND C.country_abbr = ?" +
         "        AND C.ref_active = ?";
   }
}