package com.monsanto.tcc.lexiconfixtures.serviceat.eventagencyalignment;

import com.monsanto.tps.lexicon.event.EventComponent;
import com.monsanto.tps.lexicon.event.EventInfo;
import com.monsanto.tps.lexicon.event.EventAgency;
import com.monsanto.tcc.lexiconfixtures.data.lexicon.eventagencyalignment.DeregulationEffectiveDate;

/**
 * nbwald - Feb 26, 2009 2:30:59 PM
 */
public class AlignmentRowAdaptor
{
   public String eventName;
   public String crop;
   public String eventAgencyPubkey;
   public String country;
   public String agency;
   public boolean regulated;
   public String deregEffectiveDate;
   public String unitOfMeasure;
   public Double maxQuantity;

   public AlignmentRowAdaptor(EventInfo eventInfo, EventAgency eventAgency) {
      StringBuilder eventNameBuilder = new StringBuilder();
      if((eventInfo!=null)&&(eventInfo.getEventComponents()!=null)){
          for(EventComponent component: eventInfo.getEventComponents()){
             if(eventNameBuilder.length()>0){
                 eventNameBuilder.append(",");
             }
             eventNameBuilder.append(component.getEventName());
          }
      }
      this.eventName = eventNameBuilder.toString();

      this.crop = eventInfo.getCrop();
      this.eventAgencyPubkey = eventAgency.getPublicKey();
      this.country = eventAgency.getCountryName();
      this.agency = eventAgency.getAgencyAbbr();
      this.regulated = eventAgency.isRegulated();
      this.deregEffectiveDate = DeregulationEffectiveDate.asString(eventAgency.getDeregulatedEffectiveDate());
      this.unitOfMeasure = eventAgency.getSurfaceAreaUomCode();
      this.maxQuantity = eventAgency.getMaxQuantity();
   }
}
