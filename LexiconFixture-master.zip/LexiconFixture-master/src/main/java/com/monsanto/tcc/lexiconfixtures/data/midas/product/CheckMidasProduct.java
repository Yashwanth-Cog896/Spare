/*
 CheckMidasProduct was created on Aug 14, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.data.midas.product;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreEntityExistsQuery;
import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;

/**
 * nbwald Aug 14, 2007 5:35:10 PM
 */
public class CheckMidasProduct
   extends SymbolAcceptingColumnFixture
{
   public Long productId;
   public String refActive;
   public String denomination;
   public String crop;

   public void reset()
      throws Exception
   {
      super.reset();
      productId = null;
      refActive = null;
      denomination = null;
      crop = null;
   }

   public boolean exists()
      throws WrappingException
   {
      MidasProductExistsQuery query = new MidasProductExistsQuery();
      return query.entityExists();
   }

   private class MidasProductExistsQuery
      extends AbstractPersistentStoreEntityExistsQuery
   {
      protected String getSQL()
         throws WrappingException
      {
         return
            "SELECT P.product_id " +
            "  FROM Midas.Product P," +
            "       Midas.Crop C " +
            " WHERE P.crop_id = C.crop_id " +
            "   AND P.product_id = ? " +
            "   AND P.ref_active = ? " +
            "   AND " + denominationCondition() +
            "   AND UPPER(C.name) = UPPER(?)";
      }

      protected Object[] getBindVariables()
         throws WrappingException
      {
         return StringUtils.isNullOrEmpty(denomination) ?
            new Object[] { productId, refActive, crop } : new Object[] { productId, refActive, denomination, crop };
      }

      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new MidasConnectionFactoryProperties();
      }

      private String denominationCondition() {
         return !StringUtils.isNullOrEmpty(denomination) ? "P.denomination = ? " : "P.denomination IS NULL ";
      }
   }
}