package com.monsanto.tcc.lexiconfixtures.util.symbol;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Mar 29, 2007
 * Time: 6:19:00 PM
 * To change this template use File | Settings | File Templates.
 */
public class SetSymbolTextValue
   extends SymbolAcceptingColumnFixture
{
   public String givenValue;

   public String symbolValue() {
      return givenValue;
   }
}
