package com.monsanto.tcc.lexiconfixtures.data.lexicon.eventagencyalignment;

import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.tcc.lexiconfixtures.util.ColumnFixtureResetter;
import com.monsanto.tcc.lexiconfixtures.util.LexiconDataFixtureDelete;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald - Feb 16, 2009 2:46:04 PM
 */
public class RemoveEventAgencyAlignment
   extends SymbolAcceptingColumnFixture
{
   public String eventAgencyPubkey;

   @Override
   public void reset()
      throws Exception
   {
      ColumnFixtureResetter.reset(this);
   }

   public boolean removed()
      throws WrappingException
   {
      return new EventAgencyAlignmentDelete().performDelete() == 1;
   }

   private class EventAgencyAlignmentDelete
      extends LexiconDataFixtureDelete
   {
      @Override
      protected String getSQL()
         throws WrappingException
      {
         return "DELETE FROM Lexicon.Event_Agency_Alignment WHERE event_agency_alignment_pubkey = ?";
      }

      @Override
      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[] { eventAgencyPubkey };
      }

      @Override
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new LexiconConnectionFactoryProperties();
      }
   }
}
