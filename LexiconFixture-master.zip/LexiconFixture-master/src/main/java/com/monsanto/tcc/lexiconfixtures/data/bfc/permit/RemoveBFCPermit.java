package com.monsanto.tcc.lexiconfixtures.data.bfc.permit;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreDelete;
import com.monsanto.tcc.lexiconfixtures.data.factories.bfc.BFCConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * User: pjberry
 * Date: Aug 3, 2007
 * Time: 9:21:32 AM
 */
public class RemoveBFCPermit
   extends SymbolAcceptingColumnFixture
{
   public Long permitId;

   public boolean removed()
      throws WrappingException
   {
      BFCPermitRemoval removal = new BFCPermitRemoval();
      return removal.performDelete() == 1;
   }

   private class BFCPermitRemoval
      extends AbstractPersistentStoreDelete
   {

      protected String getSQL()
         throws WrappingException
      {
         return "DELETE FROM Regulatory.Permit P WHERE P.permit_id = ?";
      }

      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[]{permitId};
      }

      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new BFCConnectionFactoryProperties();
      }
   }
}
