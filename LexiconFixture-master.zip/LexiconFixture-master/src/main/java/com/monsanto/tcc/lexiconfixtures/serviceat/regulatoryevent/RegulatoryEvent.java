package com.monsanto.tcc.lexiconfixtures.serviceat.regulatoryevent;

/**
 * User: pjberry
 * Date: Aug 2, 2007
 * Time: 10:16:47 AM
 */
public class RegulatoryEvent
{
   public String event;
   public String plasmidPmon;
   public String plasmidPVCode;
   public String transformationBackground;

   public RegulatoryEvent(
      String event,
      String plasmid_pMON,
      String plasmid_PVCode,
      String transformation_Background)
   {
      this.event = event;
      plasmidPmon = plasmid_pMON;
      plasmidPVCode = plasmid_PVCode;
      transformationBackground = transformation_Background;
   }
}
