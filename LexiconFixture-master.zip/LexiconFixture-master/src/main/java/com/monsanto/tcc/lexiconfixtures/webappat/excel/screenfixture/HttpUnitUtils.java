package com.monsanto.tcc.lexiconfixtures.webappat.excel.screenfixture;

import com.meterware.httpunit.WebForm;
import com.meterware.httpunit.WebResponse;
import com.meterware.httpunit.SubmitButton;

/**
 * nbwald - Dec 11, 2008 12:47:13 PM
 */
public class HttpUnitUtils
{
   public static WebResponse submitForm(WebForm form, String idOrName)
      throws Exception
   {
      SubmitButton submitButton = findRealSubmitButtonForForm(form, idOrName);
      if(submitButton == null) {
         System.out.println("Warning: could not find submit button '" + idOrName + "' for form '" + form.getName() + "'.  Letting HttpUnit guess the submit button.");
         return form.submit();
      }
      else {
         return form.submit(submitButton);
      }
   }

   private static SubmitButton findRealSubmitButtonForForm(WebForm form, String idOrName) {
      SubmitButton submitButton = form.getSubmitButtonWithID(idOrName);
      if(submitButton == null) {
         submitButton = form.getSubmitButton(idOrName);
      }
      return submitButton;
   }
}
