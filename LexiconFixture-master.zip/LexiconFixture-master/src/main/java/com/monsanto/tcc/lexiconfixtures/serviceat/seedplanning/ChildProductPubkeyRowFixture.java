package com.monsanto.tcc.lexiconfixtures.serviceat.seedplanning;

import com.monsanto.tcc.lexiconcommon.service.ProductParentGermplasmDocTags;
import com.monsanto.tcc.lexiconcommon.xml.LexiconXPathSelector;
import com.monsanto.tcc.lexiconcommon.xml.SingleNamespaceContext;
import com.monsanto.XMLUtil.DOMUtil;
import fit.RowFixture;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Feb 13, 2007
 * Time: 5:16:57 PM
 * To change this template use File | Settings | File Templates.
 */
public class ChildProductPubkeyRowFixture
   extends AbstractChildProductRowFixture
{
   public ChildProductPubkeyRowFixture(Document responseDocument) {
      super(responseDocument);
   }

   protected Object[] query(List<Node> childProductNodes)
   {
      List<PubkeyAdapter> childProductPubkeys = new ArrayList<PubkeyAdapter>();
      for (Node childProductNode : childProductNodes) {
         childProductPubkeys.add(buildAdapter(childProductNode));
      }
      return childProductPubkeys.toArray();
   }

   private PubkeyAdapter buildAdapter(Node productNode) {
      String productPubkey = DOMUtil.getAttribute((Element)productNode, ProductParentGermplasmDocTags.PUBKEY_ATTR_NAME);
      return new PubkeyAdapter(productPubkey);
   }

   public Class getTargetClass() {
      return PubkeyAdapter.class;
   }
}
