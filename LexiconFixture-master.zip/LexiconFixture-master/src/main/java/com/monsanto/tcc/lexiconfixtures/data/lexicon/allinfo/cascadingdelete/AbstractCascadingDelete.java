/*
 AbstractCascadingDelete was created on Jul 17, 2007 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo.cascadingdelete;

import com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo.cascadingdelete.query.delete.AbstractLexiconDeleteByIDDataMod;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald Jul 17, 2007 2:12:22 PM
 */
public abstract class AbstractCascadingDelete {

   public boolean remove()
      throws WrappingException
   {
      return removeDependencies() && removeSelf();
   }

   protected abstract boolean removeDependencies() throws WrappingException;

   protected boolean removeSelf()
      throws WrappingException
   {
      AbstractLexiconDeleteByIDDataMod deleter = getSelfDeleter();
      return deleter.performDelete() == 1;
   }

   protected abstract AbstractLexiconDeleteByIDDataMod getSelfDeleter();
}