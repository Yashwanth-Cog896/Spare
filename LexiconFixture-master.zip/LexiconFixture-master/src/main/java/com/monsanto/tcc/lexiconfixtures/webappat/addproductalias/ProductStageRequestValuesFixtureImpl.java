package com.monsanto.tcc.lexiconfixtures.webappat.addproductalias;

import com.monsanto.tcc.lexiconcommon.productsync.ProductStageServiceRequestValues;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Dec 19, 2006
 * Time: 3:55:39 PM
 */
public class ProductStageRequestValuesFixtureImpl
   implements ProductStageServiceRequestValues
{
   private int batchId;
   private boolean validationOnly;
   private String productPubkey;
   private String productNamePubkey;
   private String brandPubkey;
   private String countryPubkey;
   private String stageTypePubkey;
   private String traitStackPubkey;
   private String commercialName;
   private String commercialMaturity;
   private boolean verifiedName;
   private boolean primary=false;

   public ProductStageRequestValuesFixtureImpl(
      int batchId,
      boolean validationOnly,
      String productPubkey,
      String productNamePubkey,
      String brandPubkey,
      String countryPubkey,
      String stageTypePubkey,
      String traitStackPubkey,
      String commercialName,
      String commercialMaturity)
   {
      this.batchId = batchId;
      this.validationOnly = validationOnly;
      this.productPubkey = productPubkey;
      this.productNamePubkey = productNamePubkey;
      this.brandPubkey = brandPubkey;
      this.countryPubkey = countryPubkey;
      this.stageTypePubkey = stageTypePubkey;
      this.traitStackPubkey = traitStackPubkey;
      this.commercialName = commercialName;
      this.commercialMaturity = commercialMaturity;
   }

   public int getBatchID() {
      return batchId;
   }

   public boolean isValidationOnly() {
      return validationOnly;
   }

   public String getProductPubkey() {
      return productPubkey;
   }

   public String getProductNamePubkey() {
      return productNamePubkey;
   }

   public String getBrandPubkey() {
      return brandPubkey;
   }

   public String getCountryPubkey() {
      return countryPubkey;
   }

   public String getStageTypePubkey() {
      return stageTypePubkey;
   }

   public String getTraitStackPubkey() {
      return traitStackPubkey;
   }

   public String getCommercialName() {
      return commercialName;
   }

   public String getCommercialMaturity() {
      return commercialMaturity;
   }

   public String getOECDName() {
      return null; // nstub TODO: make part of fixture?
   }

   public boolean isActive() {
      return true; // nstub TODO: make part of fixture?
   }

   public String getUserLoginId() {
      return null; // Not used here
   }

   public String getAuditRequester() {
      return null; // nstub TODO: make part of fixture?
   }

   public String getAuditComment() {
      return null; // nstub TODO: make part of fixture?
   }

   @Override
   public boolean isPreferredName() {
      return false; // nstub TODO: make part of fixture?
   }

    public boolean isPrimary() {
        return primary;
    }

    public void setPrimary(boolean primary) {
        this.primary = primary;
    }

    @Override
    public boolean isVerifiedName() {
        return verifiedName;
    }

    public void setVerifiedName(boolean verifiedName) {
        this.verifiedName = verifiedName;
    }
}
