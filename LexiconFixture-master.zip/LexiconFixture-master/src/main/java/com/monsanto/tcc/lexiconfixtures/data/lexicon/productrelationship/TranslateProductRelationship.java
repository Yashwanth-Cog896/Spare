/*
 TranslateProductRelationship was created on Jul 31, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.data.lexicon.productrelationship;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * nbwald Jul 31, 2007 10:24:59 AM
 */
public class TranslateProductRelationship
   extends SymbolAcceptingColumnFixture
{
   public String manufacturingName;

   public String productRelationshipPubkey()
      throws WrappingException
   {
      ProductRelationshipPubkeyFromManufacturingNameQuery query = new ProductRelationshipPubkeyFromManufacturingNameQuery();
      return query.getPubkey();
   }

   private class ProductRelationshipPubkeyFromManufacturingNameQuery
      extends AbstractPersistentStoreSingleResultQuery
   {
      public String getPubkey()
         throws WrappingException
      {
         return (String) execute();
      }

      protected Object createObjectFromRow(PersistentStoreResultSetRow row)
         throws WrappingException
      {
         return row.getString(1);
      }

      protected String getSQL()
         throws WrappingException
      {
         return new SQLPropFile(ProductRelationshipFixtureSQL.class).getSQL(ProductRelationshipFixtureSQL.PUBKEY_BY_MANF_NAME);
      }

      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[] { manufacturingName };
      }

      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new LexiconConnectionFactoryProperties();
      }
   }
}