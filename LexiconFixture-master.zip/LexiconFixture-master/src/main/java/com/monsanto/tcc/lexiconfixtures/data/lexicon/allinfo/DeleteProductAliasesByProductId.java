package com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Mar 19, 2007
 * Time: 10:05:34 AM
 * To change this template use File | Settings | File Templates.
 */
public class DeleteProductAliasesByProductId
{
   private final String sql = "DELETE FROM Lexicon.product_stage PS WHERE PS.product_id = ?";

   public int deleteProductAliases(PersistentStoreConnection conn, Long productId)
      throws WrappingException
   {
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, productId);
         return stmt.executeDelete();
      }
      finally {
         stmt.close();
      }
   }
}
