/*
 SecondaryCountryListFixture was created on Mar 15, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.webappat.preference.country;

import com.monsanto.tcc.lexiconcommon.PreferenceNames;
import com.monsanto.tcc.lexiconfixtures.util.preference.UserPreferencesTestTool;
import java.util.List;

/**
 * nbwald Mar 15, 2007 10:01:09 AM
 */
public class SetSecondaryCountries
   extends CountryListFixture
{
   protected void setCurrentUsersPreferenceCountries(List countryPreferenceValues)
      throws Exception
   {
      UserPreferencesTestTool.setCurrentUsersPreferenceValues(
         PreferenceNames.SECONDARY_COUNTRY_PREF_NAME, countryPreferenceValues);
   }
}