package com.monsanto.tcc.lexiconfixtures.serviceat.person;

import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import static com.monsanto.Util.StringUtils.getLineSeparator;
import static com.monsanto.tcc.lexiconfixtures.serviceat.person.CsvToLongs.convert;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingRowFixture;
import com.monsanto.tps.lexicon.person.MinimalPersonRecord;
import com.monsanto.tps.lexicon.person.service.People;
import com.monsanto.tps.lexicon.person.service.PeopleImpl;
import fit.Fixture;
import fitlibrary.DoFixture;
import org.ietf.jgss.GSSException;

/**
 * nbwald - May 23, 2008 12:05:04 PM
 */
public class MinimalPersonFixture extends DoFixture {

   private MinimalPersonRecord[] minimalPersonRecords;
   private String errorMessage;

   public boolean findMinimalPeopleWithNetworkIds(String networkIdCSV) throws Exception {
      try {
         minimalPersonRecords = getClient().findMinimalPersonRecordsByNetworkIds(networkIdCSV.split(","));
      } catch (IllegalArgumentException e) {
         errorMessage = e.getMessage();
      }
      return true;
   }

   private People getClient() throws GSSException {
      return new PeopleImpl(new KerberosStandaloneCredential());
   }

   public boolean findMinimalPeopleWithPartyIds(String partyIdsCSV) throws Exception {
      try {
         minimalPersonRecords = getClient().findMinimalPersonRecordsByPartyIds(convert(partyIdsCSV, "Party Ids"));
      } catch (IllegalArgumentException e) {
         errorMessage = e.getMessage();
      }
      return true;
   }

   public boolean findMinimalPeopleWithFirstNameAndLastName(String wildcardableFirstName, String wildcardableLastName) throws Exception {
      try {
         minimalPersonRecords = getClient().findMinimalPersonRecordsByWildcardableFirstAndLastName(wildcardableFirstName, wildcardableLastName);
      } catch (IllegalArgumentException e) {
         errorMessage = e.getMessage();
      }
      return true;
   }

   public String errorMessage() {
      return errorMessage.replaceAll(getLineSeparator(), " ");
   }

   public boolean findMinimalPeopleWithFirstName(String wildcardableFirstName) throws Exception {
      return findMinimalPeopleWithFirstNameAndLastName(wildcardableFirstName, null);
   }

   public boolean findMinimalPeopleWithLastName(String wildcardableLastName) throws Exception {
      return findMinimalPeopleWithFirstNameAndLastName(null, wildcardableLastName);
   }

   public int numberOfMinimalPeopleFound() {
      return minimalPersonRecords.length;
   }

   public Fixture checkResults() {
      return new SymbolAcceptingRowFixture() {
         public Class<?> getTargetClass() {
            return MinimalPersonRecordAdaptor.class;
         }

         public Object[] query()
                 throws Exception {
            return buildMinimalPersonRecordAdaptors();
         }
      };
   }

   private MinimalPersonRecordAdaptor[] buildMinimalPersonRecordAdaptors() {
      MinimalPersonRecordAdaptor[] minimalPersonRecordAdaptors = new MinimalPersonRecordAdaptor[minimalPersonRecords.length];
      for (int i = 0; i < minimalPersonRecords.length; i++) {
         minimalPersonRecordAdaptors[i] = new MinimalPersonRecordAdaptor(minimalPersonRecords[i]);
      }
      return minimalPersonRecordAdaptors;
   }
}
