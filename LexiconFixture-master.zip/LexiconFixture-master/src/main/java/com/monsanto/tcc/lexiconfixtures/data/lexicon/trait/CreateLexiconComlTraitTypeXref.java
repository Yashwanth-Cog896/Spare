package com.monsanto.tcc.lexiconfixtures.data.lexicon.trait;

import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactory;
import com.monsanto.tcc.lexiconcommon.db.test.LexiconTestTools;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * User: pjberry
 * Date: May 25, 2007
 * Time: 9:21:53 AM
 */
public class CreateLexiconComlTraitTypeXref
   extends SymbolAcceptingColumnFixture
{
   public Long comlTraitTypeXrefId;
   public Long comlTraitNameId;
   public Long comlTraitTypeId;

   public boolean created()
      throws WrappingException
   {
      LexiconConnectionFactory connectionFactory = new LexiconConnectionFactory();
      PersistentStoreConnection conn = connectionFactory.getConnection();
      LexiconTestTools.FITNESSE_TEST_AUDITOR.initializeStaging(conn);
      try {
         int numInserted = insertFakeData(conn);
         return numInserted == 1;
      }
      finally {
         LexiconTestTools.FITNESSE_TEST_AUDITOR.removeStaging(conn);
         conn.close();
      }
   }

   private int insertFakeData(PersistentStoreConnection conn)
      throws WrappingException
   {
      String sql = getSql();
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, comlTraitTypeXrefId);
         stmt.setParam(2, comlTraitNameId);
         stmt.setParam(3, comlTraitTypeId);
         return stmt.executeInsert();
      }
      finally {
         stmt.close();
      }
   }

   private String getSql() {
      return
         "INSERT INTO Lexicon.Coml_Trait_Type_Xref2 " +
            "(coml_trait_type_xref_id, coml_trait_name_id, coml_trait_type_id) " +
        "VALUES " +
            "(?, ?, ?)";
   }
}
