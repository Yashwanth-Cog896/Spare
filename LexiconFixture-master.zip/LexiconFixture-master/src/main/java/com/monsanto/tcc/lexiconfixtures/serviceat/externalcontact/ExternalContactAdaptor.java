/*
	 ExternalContactAdaptor was created on May 27, 2008 using Monsanto
	 resources and is the sole property of Monsanto.  Any duplication of the 
	 code and/or logic is a direct infringement of Monsanto's copyright.
	*/
package com.monsanto.tcc.lexiconfixtures.serviceat.externalcontact;

import com.monsanto.tps.lexicon.contact.Address;
import com.monsanto.tps.lexicon.contact.AddressRecord;
import com.monsanto.tps.lexicon.person.ExternalContact;

/**
 * Filename:    $RCSfile: ExternalContactAdaptor.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: nbwald $    	 On:	$Date: 2008-06-30 21:40:56 $
 *
 * @author MMR
 * @version $Revision: 1.4 $
 */
public class ExternalContactAdaptor {

    public String contactId;
    public String accountId;
    public String line1;
    public String line2;
    public String line3;
    public String addressId;
    public String city;
    public String country;
    public String county;
    public String postalCode;
    public String state;
    public String addressType;
    public String contactType;
    public String company;
    public String firstName;
    public String lastName;

    public String phoneNumber;
    public String cellNumber;
    public String email;
    public String faxNumber;
    public String jobTitle;
    public String middleName;
    public String pagerNumber;

    public ExternalContactAdaptor(ExternalContact externalContact, AddressRecord addressRecord, String externalContactType) {
        contactId = externalContact.getContactID();
        accountId = externalContact.getBusinessAccountID();
        contactType = externalContactType;
        company = externalContact.getCompanyName();
        firstName = externalContact.getFirstName();
        lastName = externalContact.getLastName();
        phoneNumber = externalContact.getPhone().getNumber();
        cellNumber = externalContact.getCell().getNumber();
        faxNumber = externalContact.getFax().getNumber();
        pagerNumber = externalContact.getPager().getNumber();
        email = externalContact.getEmail().getEmailAddress();
        jobTitle = externalContact.getJobTitle();
        middleName = externalContact.getMiddleName();
        loadAddressRecord(addressRecord);
    }

    private void loadAddressRecord(AddressRecord addressRecord) {
        if (addressRecord != null) {
            addressId = addressRecord.getAddressId();
            addressType = addressRecord.getAddressType();
            loadAddress(addressRecord.getAddress());
        }
    }

    private void loadAddress(Address address) {
        if (address != null) {
            line1 = address.getLine1();
            line2 = address.getLine2();
            line3 = address.getLine3();
            city = address.getCity();
            country = address.getCountry();
            county = address.getCounty();
            postalCode = address.getPostalCode();
            state = address.getState();
        }
    }
}