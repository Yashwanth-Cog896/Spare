package com.monsanto.tcc.lexiconfixtures.data.lexicon.productrelationship;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreEntityExistsQuery;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * User: pjberry
 * Date: Aug 16, 2007
 * Time: 2:46:59 PM
 */
public class CheckProductRelationship
   extends SymbolAcceptingColumnFixture
{
   public String baseManufacturingName;
   public String manufacturingName;
   public String varietyName; 	

   public boolean exists()
      throws WrappingException
   {
      CheckProductRelationshipExistsQuery query = new CheckProductRelationshipExistsQuery();
      return query.entityExists();
   }

    public void reset()
      throws Exception
   {
      super.reset();
      manufacturingName = null;
      baseManufacturingName = null;
      varietyName = null;
   }
   
   private class CheckProductRelationshipExistsQuery
      extends AbstractPersistentStoreEntityExistsQuery
   {
      protected String getSQL()
         throws WrappingException
      {
         return
            "SELECT " +
               "PR.* " +
            "FROM " +
               "Lexicon.Product_Relationship PR, " +
               "Lexicon.Base_Product BP " +
            "WHERE " +
               "BP.base_manufacturing_name = ? " +
               "AND " +
               "BP.base_product_id = PR.base_product_id " +
               "AND " +
               "PR.manufacturing_name = ? " +
               "AND " +
               "PR.variety_name " + equalsSignNullOrNotNull();
      }

      private String equalsSignNullOrNotNull()
      {
         boolean varietyNameIsNull = varietyName == null; 
         boolean userAskedIfNotNull = !varietyNameIsNull && "not null".equalsIgnoreCase(varietyName);
         if(varietyNameIsNull) {
            return "IS NULL";
         }
         else if(userAskedIfNotNull) {
            return "IS NOT NULL";
         }
         else {
            return  "= '" + varietyName + "'";
         }
      }

      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[] {baseManufacturingName, manufacturingName};
      }

      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new LexiconConnectionFactoryProperties();
      }
   }
}
