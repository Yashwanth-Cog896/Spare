package com.monsanto.tcc.lexiconfixtures.data.cleanup;

import com.monsanto.tcc.lexiconcommon.db.SqlUtilities;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import java.util.List;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Apr 30, 2007
 * Time: 4:56:29 PM
 * To change this template use File | Settings | File Templates.
 */
class RelationshipPubkeysQuery
   extends AbstractPersistentStoreMultiRowQuery
{
   private List prodPubkeys;
   public RelationshipPubkeysQuery() {
   }
   public RelationshipPubkeysQuery(final List prodPubkeys) {
      this.prodPubkeys = prodPubkeys;
   }

   public List getPubkeyList()throws WrappingException {
      return super.getList();
   }
   protected Object createObjectFromRow(PersistentStoreResultSetRow row) throws WrappingException {
      return row.getString(1);
   }
   protected Object[] getBindVariables() throws WrappingException {
      return new Object[0];
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }

   protected String getSQL()
      throws WrappingException
   {
      if (prodPubkeys == null) {
         prodPubkeys = new ProductPubkeysQuery().getPubkeyList();
      }
      return "SELECT product_relationship_pubkey " +
         "FROM Lexicon.Product_Relationship PR, Lexicon.Product_Relationship_Xref PRX, Lexicon.Pre_Coml_Product PCP " +
         "WHERE PR.product_relationship_id = PRX.product_relationship_id " +
         " AND PRX.product_id = PCP.product_id " +
         " AND (" + SqlUtilities.makeInListOfStrings("PCP.product_pubkey", prodPubkeys) +
         " OR " + DeleteRandomValueData.getNameClause("PR.manufacturing_name") +
         " OR " + DeleteRandomValueData.getNameClause("PR.product_relationship_pubkey") +
         " OR " + DeleteRandomValueData.getNumberClause("PR.product_relationship_id") +
         " )";
   }
}
