package com.monsanto.tcc.lexiconfixtures.data.mirage.country;

import com.monsanto.tcc.lexiconfixtures.data.factories.mirage.MirageConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.EmptyResultSetException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetSingleResult;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Apr 24, 2007
 * Time: 2:11:38 PM
 * To change this template use File | Settings | File Templates.
 */
public class CheckMirageCountry
   extends SymbolAcceptingColumnFixture
{
   public String countryName;
   public String countryAbbr;

   public boolean exists()
      throws WrappingException {
      PersistentStoreConnection conn = new MirageConnectionFactory().getConnection();
      try {
         return countriesFound(conn) == 1;
      }
      finally {
         conn.close();
      }
   }

   private int countriesFound(PersistentStoreConnection conn)
      throws WrappingException
   {
      PersistentStoreStatement statement = conn.prepareStatement(getSQL());
      try {
         statement.setParam(1, countryName);
         statement.setParam(2, countryAbbr);
         PersistentStoreResultSetSingleResult result = statement.executeQuery().getSingleResult();
         return result.getInt(1);
      }
      catch (EmptyResultSetException e) {
         return 0;
      } finally {
         statement.close();
      }
   }

   private String getSQL() {
      return
         "SELECT count(country_name)" +
         "  FROM Mirage2.Countries C" +
         " WHERE C.country_name = ?" +
         "   AND C.country_abbrev = ?";
   }
}
