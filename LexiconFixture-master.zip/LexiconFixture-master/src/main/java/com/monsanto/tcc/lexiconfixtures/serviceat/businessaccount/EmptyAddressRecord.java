package com.monsanto.tcc.lexiconfixtures.serviceat.businessaccount;

import com.monsanto.tps.lexicon.contact.AddressRecord;
import com.monsanto.tps.lexicon.contact.Address;

/**
 * nbwald - Jun 30, 2008 3:58:50 PM
 */
public class EmptyAddressRecord
{
   public static AddressRecord[] get() {
      AddressRecord addressRecord = new AddressRecord();
      addressRecord.setAddress(new Address());
      return new AddressRecord[] { addressRecord };
   }
}
