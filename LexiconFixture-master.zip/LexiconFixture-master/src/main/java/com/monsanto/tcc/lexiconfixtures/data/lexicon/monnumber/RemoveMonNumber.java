package com.monsanto.tcc.lexiconfixtures.data.lexicon.monnumber;

import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.tcc.lexiconfixtures.util.ColumnFixtureResetter;
import com.monsanto.tcc.lexiconfixtures.util.LexiconDataFixtureDelete;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald - Jan 26, 2009 1:57:19 PM
 */
public class RemoveMonNumber
   extends SymbolAcceptingColumnFixture
{
   public String monNumber;

   @Override
   public void reset()
      throws Exception
   {
      ColumnFixtureResetter.reset(this);
   }

   public boolean removed()
      throws WrappingException
   {
      return new MonNumberDelete().performDelete() == 1;
   }

   private class MonNumberDelete
      extends LexiconDataFixtureDelete
   {
      @Override
      protected String getSQL()
         throws WrappingException
      {
         return "DELETE FROM Lexicon.Mon_Number WHERE mon_number = ?";
      }

      @Override
      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[] { monNumber };
      }

      @Override
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new LexiconConnectionFactoryProperties();
      }
   }
}
