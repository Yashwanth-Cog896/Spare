package com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Mar 19, 2007
 * Time: 10:09:16 AM
 * To change this template use File | Settings | File Templates.
 */
public class DeleteProductRelationshipXrefsByProductId
{
   private final String sql = "DELETE FROM Lexicon.product_relationship_xref PRX WHERE PRX.product_id = ?";

   public int deleteProductRelationshipXrefs(PersistentStoreConnection conn, Long productId)
      throws WrappingException
   {
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, productId);
         return stmt.executeDelete();
      }
      finally {
         stmt.close();
      }
   }
}
