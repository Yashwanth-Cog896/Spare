/*
 HtmlTableRowParser was created on Apr 18, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.webappat;

import com.monsanto.tcc.lexiconfixtures.selenium.LexiconSelenium;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.testutil.DocumentFromHTMLBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * nbwald Apr 18, 2007 10:43:09 AM
 */
public class HtmlTableRowParser {
   private Document rowDoc;

   public HtmlTableRowParser(LexiconSelenium selenium, String tableRowLocator)
      throws IOException, ParserConfigurationException, SAXException
   {
      String tableHtml = selenium.getEval("{this.page().findElement('"+ tableRowLocator +"').innerHTML}");
      DocumentFromHTMLBuilder docBuilder = new DocumentFromHTMLBuilder();
      this.rowDoc = docBuilder.getWellFormedXMLDocumentFromXMLString(tableHtml);
   }

   public String[] getRow() {
      Node parent = DOMUtil.getChild(rowDoc.getDocumentElement(), "body");
      Node[] cells = getCells(parent);
      String[] cellValues = new String[cells.length];
      for (int i = 0; i < cells.length; i++) {
         cellValues[i] = getCellValue((Element)cells[i]);
      }
      return cellValues;
   }

   private Node[] getCells(Node parent) {
      String nodeName = "td";
      if(parent.hasChildNodes()) {
         nodeName = parent.getFirstChild().getNodeName();
      }
      return DOMUtil.getChildren(parent, nodeName);
   }

   private String getCellValue(Element cell) {
      CellParser[] cellParsers = getCellParsers();
      for (CellParser cellParser : cellParsers) {
         if (cellParser.canParse(cell)) {
            return decode(cellParser.parse(cell));
         }
      }
      return null;
   }

   private String decode(String s) {
      if(s == null) return null;
      StringBuilder decoded = new StringBuilder();
      for(int i = 0; i < s.length(); i++) {
         char c = s.charAt(i);
         if(c == '\u00A0') { // &nbsp;
            decoded.append(' ');
         }
         else {
            decoded.append(c);
         }
      }
      return decoded.toString().trim();
   }

   private CellParser[] getCellParsers() {
      return new CellParser[] {
         new LinkImageListCellParser(),
         new LinkTextCellParser(),
         new TextFieldValueCellParser(),
         new SelectBoxCellParser(),
         new ImageListCellParser(),
         new CheckboxCellParser(),
         new ImageInputCellParser(),
         new SimpleTextCellParser()
      };
   }

   private interface CellParser {
      boolean canParse(Element cell); // It would be cool if we could use a mini schema here.
      String parse(Element cell);
   }

   private class SimpleTextCellParser
      implements CellParser
   {
      public boolean canParse(Element cell) {
         return true;
      }

      public String parse(Element cell) {
         return DOMUtil.getTextValue(cell);
      }
   }

   private class CheckboxCellParser
      implements CellParser
   {
      public boolean canParse(Element cell) {
         if(!cell.hasChildNodes()) return false;
         Node firstChildNode = cell.getFirstChild();
         if(!(firstChildNode instanceof Element)) return false;
         Element firstChild = (Element) firstChildNode;
         return "input".equalsIgnoreCase(firstChild.getNodeName())
            && "checkbox".equalsIgnoreCase(DOMUtil.getAttribute(firstChild, "type"));
      }

      public String parse(Element cell) {
         Element firstChild = (Element) cell.getFirstChild();
         return DOMUtil.getAttribute(firstChild, "checked") == null ? "unchecked" : "checked";
      }
   }

   private class ImageListCellParser
      implements CellParser
   {
      public boolean canParse(Element cell) {
         Node[] images = DOMUtil.getChildren(cell, "img");
         return images != null && images.length > 0;
      }

      public String parse(Element cell) {
         StringBuilder value = new StringBuilder();
         Node[] images = DOMUtil.getChildren(cell, "img");
         for (Node image : images) {
            String src = DOMUtil.getAttribute((Element)image, "src");
            value.append("[");
            value.append(LexiconImages.iconFromImageSource(src));
            value.append("]");
         }
         return value.toString();
      }
   }

   private class ImageInputCellParser
      implements CellParser
   {
      public boolean canParse(Element cell) {
         Node inputNode = DOMUtil.getChild(cell, "input");
         if(inputNode == null || !(inputNode instanceof Element)) return false;
         Element inputElement = (Element) inputNode;
         return "image".equalsIgnoreCase(DOMUtil.getAttribute(inputElement, "type"));
      }

      public String parse(Element cell) {
         Element imageInputElem = (Element) DOMUtil.getChild(cell, "input");
         String source = DOMUtil.getAttribute(imageInputElem, "src");
         return "[" + LexiconImages.iconFromImageSource(source) + "]";
      }
   }

   private class LinkImageListCellParser
      implements CellParser
   {
      public boolean canParse(Element cell) {
         Node[] anchors = DOMUtil.getChildren(cell, "a");
         if(anchors == null || anchors.length == 0) return false;
         for (Node anchor : anchors) {
            Node image = DOMUtil.getChild(anchor, "img");
            if (image == null || !(image instanceof Element)) {
               return false;
            }
         }
         return true;
      }

      public String parse(Element cell) {
         StringBuilder value = new StringBuilder();
         Node[] anchors = DOMUtil.getChildren(cell, "a");
         for (Node anchor : anchors) {
            Node image = DOMUtil.getChild(anchor, "img");
            String src = DOMUtil.getAttribute((Element)image, "src");
            value.append("[");
            value.append(LexiconImages.iconFromImageSource(src));
            value.append("]");
         }
         return value.toString();
      }
   }

   private class SelectBoxCellParser
      implements CellParser
   {
      public boolean canParse(Element cell) {
         Node selectElem = DOMUtil.getChild(cell, "select");
         if(selectElem == null || !(selectElem instanceof Element)) return false;
         Node[] optionElems = DOMUtil.getChildren(selectElem, "option");
         return optionElems != null;
      }

      public String parse(Element cell) {
         Node selectElem = DOMUtil.getChild(cell, "select");
         Node[] optionNodes = DOMUtil.getChildren(selectElem, "option");
         List<String> values = new ArrayList<String>();
         for (Node optionNode : optionNodes) {
            Element optionElem = (Element)optionNode;
            if (DOMUtil.getAttribute(optionElem, "selected") != null) {
               values.add(DOMUtil.getTextValue(optionElem));
            }
         }
         return createCsv(values);
      }

      private String createCsv(List values) {
         StringBuilder result = new StringBuilder();
         for(Iterator i = values.iterator(); i.hasNext(); ) {
            result.append((String) i.next());
            if(i.hasNext()) {
               result.append(", ");
            }
         }
         return result.toString();
      }
   }

   private class TextFieldValueCellParser
      implements CellParser
   {
      public boolean canParse(Element cell) {
         Node textFieldElem = DOMUtil.getChild(cell, "input");
         if(textFieldElem == null || !(textFieldElem instanceof Element)) return false;
         String textFieldType = DOMUtil.getAttribute((Element) textFieldElem, "type");
         return textFieldType == null || "text".equalsIgnoreCase(textFieldType);
      }

      public String parse(Element cell) {
         Element textFieldElem = (Element) DOMUtil.getChild(cell, "input");
         String value = DOMUtil.getAttribute(textFieldElem, "value");
         return value == null ? "" : value;
      }
   }

   private class LinkTextCellParser
      implements CellParser
   {
      public boolean canParse(Element cell) {
         Node anchorElem = DOMUtil.getChild(cell, "a");
         return anchorElem != null;
      }

      public String parse(Element cell) {
         return DOMUtil.getChildValue(cell, "a");
      }
   }
}