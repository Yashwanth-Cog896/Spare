package com.monsanto.tcc.lexiconfixtures.util.symbol;

import fitnesse.fixtures.TableFixture;

/**
 * nbwald - Mar 18, 2008 11:47:10 AM
 */
public abstract class SymbolAcceptingTableFixture
   extends TableFixture
{
   protected String getText(int row, int col) {
      StringParseDelagate parser = new StringParseDelagate();
      return parser.parse(super.getText(row, col));
   }
}
