package com.monsanto.tcc.lexiconfixtures.serviceat.eventagencyalignment;

import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingRowFixture;
import com.monsanto.tps.lexicon.event.EventAgency;
import com.monsanto.tps.lexicon.event.EventInfo;

import java.util.ArrayList;
import java.util.List;

/**
 * nbwald - Feb 26, 2009 2:30:18 PM
 */
public class AlignmentResultsRowFixture
   extends SymbolAcceptingRowFixture
{
   private EventInfo[] eventInfos;

   public AlignmentResultsRowFixture(EventInfo[] eventInfos) {
      this.eventInfos = eventInfos;
   }

   @Override
   public Object[] query()
      throws Exception
   {
      return build();
   }

   private AlignmentRowAdaptor[] build() {
      if(eventInfos == null) {
         return new AlignmentRowAdaptor[0];
      }
      else {
         List<AlignmentRowAdaptor> adaptors = new ArrayList<AlignmentRowAdaptor>();
         for (EventInfo eventInfo : eventInfos) {
            if(eventInfo.getEventAgencies() != null) {
               for (EventAgency eventAgency : eventInfo.getEventAgencies()) {
                  adaptors.add(new AlignmentRowAdaptor(eventInfo, eventAgency));
               }
            }
         }
         return adaptors.toArray(new AlignmentRowAdaptor[adaptors.size()]);
      }
   }

   @Override
   public Class<?> getTargetClass() {
      return AlignmentRowAdaptor.class;
   }
}