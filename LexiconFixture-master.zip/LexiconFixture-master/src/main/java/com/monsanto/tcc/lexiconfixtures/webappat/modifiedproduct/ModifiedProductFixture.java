package com.monsanto.tcc.lexiconfixtures.webappat.modifiedproduct;

import com.monsanto.tcc.lexiconfixtures.util.symbol.SafeSortSymbolAcceptingRowFixture;
import com.monsanto.tcc.lexiconfixtures.webappat.SeleniumFixture;
import com.monsanto.tps.lexiconpos.product.auditsearch.modified.search.model.ModifiedProduct;
import com.monsanto.tps.lexiconpos.product.auditsearch.modified.search.model.ModifiedProductsSearchResults;
import com.monsanto.tps.lexiconpos.product.auditsearch.modified.search.service.ModifiedProductsService;
import fit.Fixture;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * nbwald - Sep 15, 2008 6:14:52 PM
 */
public class ModifiedProductFixture
   extends SeleniumFixture
{
   private final DatabaseDate databaseDate = new DatabaseDate();

   private Date start;
   private Date end;
   private String cropPubkey;
   private ModifiedProductsSearchResults results;
   private String errorMessage;

   public void startTime(String startString)
      throws ParseException
   {
      this.start = databaseDate.parse(startString);
   }

   public void endTime(String endString)
      throws ParseException
   {
      this.end = databaseDate.parse(endString);
   }

   public void crop(String cropPubkey) {
      this.cropPubkey = cropPubkey;
   }

   public void search() {
      try {
         results = getClient().findByTimeModifiedRangeAndCrop(start, end, cropPubkey);
      }
      catch (Exception e) {
         errorMessage = getErrorMessage(e);
      }
   }

   private ModifiedProductsService getClient() {
      String configLocation = "/com/monsanto/tcc/lexiconfixtures/client.xml";
      ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(configLocation);
      return (ModifiedProductsService) context.getBean("modifiedProductsService");
   }

   public int numberOfRecordsFound() {
      List<ModifiedProduct> results = this.results.getModifiedProducts();
      return results == null ? 0 : results.size();
   }

   public Fixture checkResults() {
      return new SafeSortSymbolAcceptingRowFixture() {
         public Class getTargetClass() {
            return ModifiedProductAdapter.class;
         }

         public Object[] query()
            throws Exception
         {
            return buildModifiedProductAdapters();
         }
      };
   }

   public boolean errorMessageContainsIs(String expected) {
      System.out.println("errorMessage = " + errorMessage);
      return errorMessage.contains(expected);
   }

   private String getErrorMessage(Exception e) {
      StringWriter writer = new StringWriter();
      e.printStackTrace(new PrintWriter(writer));
      return writer.toString();
   }

   private ModifiedProductAdapter[] buildModifiedProductAdapters() {
      List<ModifiedProductAdapter> modifiedProductAdapters = new ArrayList<ModifiedProductAdapter>();
      if(results.getModifiedProducts() == null) {
         return new ModifiedProductAdapter[0];
      }
      for (ModifiedProduct modifiedProduct : results.getModifiedProducts()) {
         modifiedProductAdapters.add(createModifiedProductAdapter(modifiedProduct, results.getStart(), results.getEnd()));
      }
      return modifiedProductAdapters.toArray(new ModifiedProductAdapter[modifiedProductAdapters.size()]);
   }

   private ModifiedProductAdapter createModifiedProductAdapter(ModifiedProduct modifiedProduct, Date start, Date end) {
      return new ModifiedProductAdapter(modifiedProduct, start, end);
   }
}
