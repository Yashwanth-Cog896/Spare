/*
 UOMResponseAdaptor was created on Jun 23, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tcc.lexiconfixtures.serviceat.uom;

import com.monsanto.tps.lexicon.uom.UnitOfMeasure;

/**
 * @author GGSHIV - Jun 23, 2008 12:51:26 PM
 */
public class UOMResponseAdaptor {

   public String name;
   public String uOMCode;
   public String symbol;
   public String dimension;
   public String unitType;

   public UOMResponseAdaptor(UnitOfMeasure uom) {
      name      = uom.getName();
      uOMCode   = uom.getCode();
      symbol    = uom.getSymbol();
      unitType  = uom.getUnitType();
      dimension = uom.getDimension();
   }
}
