package com.monsanto.tcc.lexiconfixtures.data.virgo;

import com.monsanto.tcc.lexiconfixtures.data.factories.virgo.VirgoConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.EmptyResultSetException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetSingleResult;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * User: pjberry
 * Date: Aug 1, 2007
 * Time: 5:09:34 PM
 */
public class CheckVirgoGeneticItem
   extends SymbolAcceptingColumnFixture
{
   public String key;
   public String event ;
   public String generation;
   public String construct;
   public String variety;
   public String crop;

   public boolean exists()
      throws WrappingException
   {
      PersistentStoreConnection conn = new VirgoConnectionFactory().getConnection();
      try {
         return geneticItemsFound(conn) == 1;
      }
      finally {
         conn.close();
      }
   }

   private int geneticItemsFound(PersistentStoreConnection conn)
      throws WrappingException
   {
      String sql = getSql();
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, key);
         stmt.setParam(2, event);
         stmt.setParam(3, construct);
         stmt.setParam(4, variety);
         stmt.setParam(5, generation);
         stmt.setParam(6, crop);

         PersistentStoreResultSetSingleResult result = stmt.executeQuery().getSingleResult();
         return result.getInt(1);
      }
      catch (EmptyResultSetException e) {
         return 0;
      }
      finally {
         stmt.close();
      }
   }

   private String getSql() {
      return
         "SELECT " +
            "COUNT(*) " +
         "FROM " +
            "VIRGO_GENETIC_ITEM GI " +
         "WHERE " +
            "GI.it_key = ? " +
            "AND " +
            "GI.it_event = ? " +
            "AND " +
            "GI.it_construct = ? " +
            "AND " +
            "GI.it_variety = ? " +
            "AND " +
            "GI.it_generation = ? " +
            "AND " +
            "GI.it_crop = ?";
   }
}
