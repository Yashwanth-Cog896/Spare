package com.monsanto.tcc.lexiconfixtures.webappat;

import fitlibrary.ArrayFixture;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 17, 2006
 * Time: 1:07:12 PM
 * To change this template use File | Settings | File Templates.
 */
public class IconFixture
   extends ArrayFixture
{
   public IconFixture(String[] imageNames) {
      List imageList = new ArrayList();
      for (int i = 0; i < imageNames.length; i++) {
         String iconName = LexiconImages.iconFromImageSource(imageNames[i]);
         imageList.add(new Icon(iconName));
      }
      setActualCollection(imageList);
   }

   public class Icon
   {
      public String icon;

      public Icon(String iconName) {
         this.icon = iconName;
      }
   }
}
