package com.monsanto.tcc.lexiconfixtures.data.lexicon.trait;

import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactory;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.test.LexiconTestTools;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreDelete;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;

/**
 * User: pjberry
 * Date: May 23, 2007
 * Time: 9:47:18 AM
 */
public class RemoveAllComlTraitStackInfo
   extends SymbolAcceptingColumnFixture
{
   public String crop;
   public String stackAbbr;

   public boolean removed()
      throws WrappingException
   {
      PersistentStoreConnection conn = new LexiconConnectionFactory().getConnection();
      LexiconTestTools.FITNESSE_TEST_AUDITOR.initializeStaging(conn);
      try {
         return removeStackInfo(conn) > 0;
      }
      finally {
         LexiconTestTools.FITNESSE_TEST_AUDITOR.removeStaging(conn);
         conn.close();
      }
   }

   private int removeStackInfo(PersistentStoreConnection conn)
      throws WrappingException
   {

      Long comlTraitStackId = getComlTraitStackId(conn);
      Long[] comlTraitNameIds = getComlTraitNameIds(conn, comlTraitStackId);

      int numDeleted = 0;
      numDeleted += deleteComlTraitStackAltNameCountries(conn, comlTraitStackId);
      numDeleted += deleteComlTraitStackAltNames(conn, comlTraitStackId);
      numDeleted += deleteComlTraitTypeXrefs(conn, comlTraitNameIds);
      numDeleted += deleteComlTraitStackXrefs(conn, comlTraitStackId);
      numDeleted += deleteComlTraitNames(conn, comlTraitNameIds);
      numDeleted += deleteComlTraitStack(conn);
      
      return numDeleted;
   }

   private Long getComlTraitStackId(PersistentStoreConnection conn)
      throws WrappingException
   {
      ComlTraitStackIdByCropAndStackAbbreviationQuery stackIdQuery = new ComlTraitStackIdByCropAndStackAbbreviationQuery();
      return stackIdQuery.getTraitStackId(conn, crop, stackAbbr);
   }

   private Long[] getComlTraitNameIds(PersistentStoreConnection conn, Long comlTraitStackId)
      throws WrappingException
   {
      ComlTraitNameIdsByComlTraitStackIdQuery traitNameIdsQuery = new ComlTraitNameIdsByComlTraitStackIdQuery();
      return traitNameIdsQuery.getTraitNameIds(conn, comlTraitStackId);
   }

   private int deleteComlTraitStackAltNameCountries(PersistentStoreConnection conn, final Long comlTraitStackId)
      throws WrappingException
   {
      return new AbstractPersistentStoreDelete(){
         protected String getSQL()
            throws WrappingException
         {
            return
               " DELETE FROM Lexicon.Coml_Trt_Stk_Cntry_Alt_Name " +
               "       WHERE coml_trait_stack_alt_name_id IN (" +
               "             SELECT coml_trait_stack_alt_name_id" +
               "               FROM Lexicon.Coml_Trait_Stack_Alt_Name" +
               "              WHERE coml_trait_stack_id = ?" +
               "             )";
         }

         protected Object[] getBindVariables()
            throws WrappingException
         {
            return new Object[] { comlTraitStackId };
         }

         protected ConnectionFactoryProperties getConnectionFactoryProperties() {
            return new LexiconConnectionFactoryProperties();
         }
      }.performDelete(conn);
   }

   private int deleteComlTraitStackAltNames(PersistentStoreConnection conn, final Long comlTraitStackId)
      throws WrappingException
   {
      return new AbstractPersistentStoreDelete(){
         protected String getSQL()
            throws WrappingException
         {
            return "DELETE FROM Lexicon.Coml_Trait_Stack_Alt_Name WHERE coml_trait_stack_id = ?";
         }

         protected Object[] getBindVariables()
            throws WrappingException
         {
            return new Object[] { comlTraitStackId };
         }

         protected ConnectionFactoryProperties getConnectionFactoryProperties() {
            return new LexiconConnectionFactoryProperties();
         }
      }.performDelete(conn);
   }

   private int deleteComlTraitTypeXrefs(PersistentStoreConnection conn, Long[] comlTraitNameIds)
      throws WrappingException
   {
      DeleteComlTraitTypeXrefsByComlTraitNameIds traitTypeXrefDelete = new DeleteComlTraitTypeXrefsByComlTraitNameIds();
      return traitTypeXrefDelete.deleteComlTraitTypeXrefs(conn, comlTraitNameIds);
   }

   private int deleteComlTraitStackXrefs(PersistentStoreConnection conn, Long comlTraitStackId)
      throws WrappingException
   {
      DeleteComlTraitStackXrefsByComlTraitStackId traitStackXrefDelete = new DeleteComlTraitStackXrefsByComlTraitStackId();
      return traitStackXrefDelete.delete(conn, comlTraitStackId);
   }

   private int deleteComlTraitNames(PersistentStoreConnection conn, Long[] traitNameIds)
      throws WrappingException
   {
      DeleteComlTraitNamesByComlTraitNameId traitNamesDelete = new DeleteComlTraitNamesByComlTraitNameId();
      return traitNamesDelete.deleteComlTraitNames(conn, traitNameIds);
   }

   private int deleteComlTraitStack(PersistentStoreConnection conn)
      throws WrappingException
   {
      DeleteComlTraitStackByCropAndStackAbbreviation traitStackDelete = new DeleteComlTraitStackByCropAndStackAbbreviation();
      return traitStackDelete.removeStackInfo(conn, crop, stackAbbr);
   }

}
