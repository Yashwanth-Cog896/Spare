package com.monsanto.tcc.lexiconfixtures.data.lexicon.productname;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 13, 2006
 * Time: 9:28:56 AM
 */
public interface LexiconProductNameFixtureSQL
{
   String INSERT_PRODUCT_NAME = "InsertProductName";
   String ADD_STAGE_TO_PRODUCT = "AddStageToProduct";
   String INSERT_COMPETITIVE_PRODUCT_NAME = "InsertCompetitiveProductName";

   String COUNTRY_ID_BY_ABBR = "CountryIdByAbbr";

   String DELETE_PRODUCT_NAME = "DeleteProductName";
   String DELETE_COMPETITIVE_PRODUCT_NAME = "DeleteCompetitiveProductName";

   String SELECT_PRODUCT_NAME_PUBKEY = "SelectProductNamePubkey";

   String SELECT_NUM_OF_MATCHING_PRODUCT_ALIASES = "SelectNumOfMatchingProductAliases";

   String COML_MAT_NULL_CRITERIA = "CommercialMaturityNullCriteria";
   String COML_MAT_NOT_NULL_CRITERIA = "CommercialMaturityNotNullCriteria";

   String COML_NAME_NOT_NULL_CRITERIA = "CommercialNameNotNullCriteria";
   String COML_NAME_NULL_CRITERIA = "CommercialNameNullCriteria";

   String COML_TRAIT_STACK_NOT_NULL_CRITERIA  = "ComlTraitStackNotNullCriteria";
   String COML_TRAIT_STACK_NULL_CRITERIA  = "ComlTraitStackNullCriteria";
   String SELECT_FIRST_N_COUNTRY_ABBRS = "SelectFristNCountryAbbrs";
   String SELECT_COUNTRY_COUNT = "SelectCountryCount";

   String SELECT_PRODUCT_ALIAS_ID_BY_CRITERIA = "SelectProductAliasIdByCriteria";
}
