package com.monsanto.tcc.lexiconfixtures.webappat.excel.screenfixture;

import com.monsanto.tcc.lexiconcommon.test.LexiconApplicationHostHelper;
import com.meterware.httpunit.WebConversation;
import com.meterware.httpunit.WebResponse;

/**
 * nbwald - Apr 17, 2008 11:38:28 AM
 */
public class UrlBasedHttpUnitPageVisitStrategy
   implements HttpUnitPageVisitStrategy
{
   private final String urlPath;

   public UrlBasedHttpUnitPageVisitStrategy(String urlPath) {
      this.urlPath = urlPath;
   }

   public WebResponse visitPage(WebConversation conversation)
      throws Exception
   {
      return conversation.getResponse(getUrl());
   }

   private String getUrl() {
      return "http://" + LexiconApplicationHostHelper.getApplicationHost() + "/lexicon-app" + urlPath;
   }
}
