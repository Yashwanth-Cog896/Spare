package com.monsanto.tcc.lexiconfixtures.data.lexicon.country;

import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactory;
import com.monsanto.tcc.lexiconcommon.db.test.LexiconTestTools;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Apr 23, 2007
 * Time: 4:54:41 PM
 * To change this template use File | Settings | File Templates.
 */
public class RemoveLexiconCountry
   extends SymbolAcceptingColumnFixture
{
   public String countryName;

   public boolean removed()
      throws WrappingException
   {
      PersistentStoreConnection conn = new LexiconConnectionFactory().getConnection();
      LexiconTestTools.FITNESSE_TEST_AUDITOR.initializeStaging(conn);
      try {
         return countriesRemoved(conn) == 1;
      }
      finally {
         LexiconTestTools.FITNESSE_TEST_AUDITOR.removeStaging(conn);
         conn.close();
      }
   }

   private int countriesRemoved(PersistentStoreConnection conn)
      throws WrappingException
   {
      PersistentStoreStatement statement = conn.prepareStatement(getSQL());
      try {
         statement.setParam(1, countryName);
         return statement.executeDelete();
      }
      finally {
         statement.close();
      }
   }

   private String getSQL() {
      return "DELETE FROM Lexicon.Country C WHERE C.country_name = ?";
   }
}