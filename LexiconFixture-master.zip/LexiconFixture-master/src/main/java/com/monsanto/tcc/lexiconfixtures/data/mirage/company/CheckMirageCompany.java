/*
 CheckMirageCompany was created on Apr 16, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.data.mirage.company;

import com.monsanto.tcc.lexiconfixtures.data.factories.mirage.MirageConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.EmptyResultSetException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetSingleResult;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * nbwald Apr 16, 2007 2:40:23 PM
 */
public class CheckMirageCompany
   extends SymbolAcceptingColumnFixture
{
   public String companyName;
   public String companyAbbr;
   public String seedFlag;

   public boolean exists()
      throws WrappingException
   {
      PersistentStoreConnection conn = new MirageConnectionFactory().getConnection();
      try {
         return companiesFound(conn) == 1;
      }
      finally {
         conn.close();
      }
   }

   private int companiesFound(PersistentStoreConnection conn)
      throws WrappingException
   {
      PersistentStoreStatement statement = conn.prepareStatement(getSQL());
      try {
         statement.setParam(1, companyName);
         statement.setParam(2, companyAbbr);
         statement.setParam(3, seedFlag);
         PersistentStoreResultSetSingleResult result = statement.executeQuery().getSingleResult();
         return result.getInt(1);
      }
      catch (EmptyResultSetException e) {
         return 0;
      } finally {
         statement.close();
      }
   }

   private String getSQL() {
      return
         "SELECT count(*)" +
         "  FROM Mirage2.Companies CO" +
         " WHERE CO.company_name = ?" +
         "   AND CO.company_abbrev = ?" +
         "   AND CO.seed_flag = ?";
   }
}