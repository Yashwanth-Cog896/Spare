package com.monsanto.tcc.lexiconfixtures.data.midas.util;

/**
 * nbwald - Mar 24, 2008 12:46:33 PM
 */
public class MidasBoolean
{
   public static String toString(boolean b)
   {
      return b ? "T" : "F";
   }
}
