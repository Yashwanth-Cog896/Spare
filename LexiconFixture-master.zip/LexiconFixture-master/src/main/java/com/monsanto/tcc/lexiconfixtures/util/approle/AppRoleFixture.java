/*
 AppRoleFixture was created on Feb 13, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.util.approle;

import fitnesse.fixtures.TableFixture;

/**
 * nbwald Feb 13, 2007 1:58:21 PM
 */
public class AppRoleFixture
   extends TableFixture
{
   protected void doStaticTable(int numAppRoles)
   {
      String[] appRoles = getAppRoles(numAppRoles);
      try {
         setAppRoles(appRoles);
      } catch (Exception e) {
         e.printStackTrace();
         throw new RuntimeException(e);
      }
   }

   private void setAppRoles(String[] appRoles)
      throws Exception
   {
      AppRoleTestTools.setCurrentUsersRoles(appRoles);
      markFixtureAsRight(appRoles.length);
   }

   private void markFixtureAsRight(int numAppRoles) {
      for(int r=0; r<numAppRoles; r++) {
         right(r, 0);
      }
   }

   private String[] getAppRoles(int numAppRoles) {
      String[] appRoles = new String[numAppRoles];
      for(int r=0; r <numAppRoles; r++) {
         appRoles[r] = getText(r, 0);
      }
      return appRoles;
   }
}