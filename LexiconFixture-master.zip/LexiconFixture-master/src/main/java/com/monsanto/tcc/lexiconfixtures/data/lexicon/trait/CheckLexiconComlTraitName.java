package com.monsanto.tcc.lexiconfixtures.data.lexicon.trait;

import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactory;
import com.monsanto.tcc.lexiconcommon.db.test.LexiconTestTools;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.EmptyResultSetException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetSingleResult;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.dbdataservices.SQLUtil;

/**
 * User: pjberry
 * Date: May 23, 2007
 * Time: 2:17:01 PM
 */
public class CheckLexiconComlTraitName
   extends SymbolAcceptingColumnFixture
{
   public String traitAbbr;
   public String traitDesc;
   public String company;
   public boolean isActive;

   public boolean exists()
      throws WrappingException
   {
      LexiconConnectionFactory connectionFactory = new LexiconConnectionFactory();
      PersistentStoreConnection conn = connectionFactory.getConnection();
      LexiconTestTools.FITNESSE_TEST_AUDITOR.initializeStaging(conn);
      try {
         int numFound = findMatches(conn);
         return numFound == 1;
      }
      finally {
         LexiconTestTools.FITNESSE_TEST_AUDITOR.removeStaging(conn);
         conn.close();
      }
   }

   private int findMatches(PersistentStoreConnection conn)
      throws WrappingException
   {
      String sql = getSql();
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, traitAbbr);
         stmt.setParam(2, traitDesc);
         stmt.setParam(3, company);
         stmt.setParam(4, SQLUtil.booleanToString(isActive));

         PersistentStoreResultSetSingleResult result = stmt.executeQuery().getSingleResult();
         return result.getInt(1);
      }
      catch (EmptyResultSetException e) {
         return 0;
      }
      finally {
         stmt.close();
      }
   }

   private String getSql() {
      return
         "SELECT " +
            "COUNT(*) " +
         "FROM " +
            "Lexicon.Coml_Trait_Name2 CTN " +
         "WHERE " +
            "CTN.trait_abbr = ? " +
            "AND " +
            "CTN.trait_desc = ? " +
            "AND " +
            "CTN.company_id = (SELECT C.company_id FROM Lexicon.Company C WHERE UPPER(C.company_name) = UPPER(?)) " +
            "AND " +
            "CTN.is_active = ? ";
   }
}
