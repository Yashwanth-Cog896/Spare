package com.monsanto.tcc.lexiconfixtures.data.lexicon.productname;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.test.LexiconTestTools;
import com.monsanto.tcc.lexiconcommon.db.audit.LexiconAuditor;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.dbdataservices.SQLUtil;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Feb 16, 2007
 * Time: 3:59:38 PM
 * To change this template use File | Settings | File Templates.
 */
public class CreateLexiconCompetitiveProductName
   extends SymbolAcceptingColumnFixture
{
   public Long productNameId;
   public String productNamePubkey;
   public Long productId;
   public String country;
   public String brand;
   public String productName;
   public String commercialMaturity;
   public boolean active;
   public String commercialTrait;
   public String verifiedSource;
   public String sourceYear;
   public String comments;
   public boolean logicalDelete;

   private SQLPropFile sqlPropFile = new SQLPropFile(LexiconProductNameFixtureSQL.class);

   public boolean created()
      throws WrappingException
   {
      LexiconConnectionFactory connectionFactory = new LexiconConnectionFactory();
      PersistentStoreConnection conn = connectionFactory.getConnection();
      LexiconAuditor lexiconAuditor = LexiconTestTools.FITNESSE_TEST_AUDITOR;
      lexiconAuditor.initializeStaging(conn);
      try {
         int numInserted = insertFakeData(conn);
         return numInserted == 1;
      }
      finally {
         lexiconAuditor.removeStaging(conn);
         conn.close();
      }
   }

   private int insertFakeData(PersistentStoreConnection conn)
      throws WrappingException
   {
      String sql = sqlPropFile.getSQL(LexiconProductNameFixtureSQL.INSERT_COMPETITIVE_PRODUCT_NAME);

      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         bindTheVariables(stmt);
         return stmt.executeInsert();
      }
      finally {
         stmt.close();
      }
   }

   private void bindTheVariables(PersistentStoreStatement stmt)
      throws WrappingException
   {
      stmt.setParam(1, productNameId);
      stmt.setParam(2, productNamePubkey);
      stmt.setParam(3, productId);
      stmt.setParam(4, StringUtils.toUpperCaseNull(country));
      stmt.setParam(5, StringUtils.toUpperCaseNull(brand));
      stmt.setParam(6, StringUtils.toUpperCaseNull(productName));
      stmt.setParam(7, getCommercialMaturity());
      stmt.setParam(8, SQLUtil.booleanToString(active));
      stmt.setParam(9, productId);
      stmt.setParam(10, StringUtils.toUpperCaseNull(commercialTrait));
      stmt.setParam(11, verifiedSource);
      stmt.setParam(12, sourceYear);
      stmt.setParam(13, StringUtils.toUpperCaseNull(comments));
      stmt.setParam(14, SQLUtil.booleanToString(logicalDelete));
   }

   private Double getCommercialMaturity() {
      return commercialMaturity == null ? null : new Double(commercialMaturity);
   }
}
