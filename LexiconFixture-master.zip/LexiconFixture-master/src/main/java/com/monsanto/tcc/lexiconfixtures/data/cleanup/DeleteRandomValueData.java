package com.monsanto.tcc.lexiconfixtures.data.cleanup;

import com.monsanto.tcc.lexiconcommon.db.SqlUtilities;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreDelete;
import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.data.factories.mirage.MirageConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.data.factories.yieldmart.YieldMartConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.LexiconDataFixtureDelete;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import java.util.List;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Apr 30, 2007
 * Time: 10:34:40 AM
 * To change this template use File | Settings | File Templates.
 */
public class DeleteRandomValueData
   extends SymbolAcceptingColumnFixture
{
   public static String getNameClause(String columnName) {
      return "(" + columnName + " LIKE '%FT-_________' OR " + columnName + " LIKE 'FT-%' OR " + columnName + " LIKE '%-FT')";
   }
   public static String getNumberClause(String columnName) {
      return columnName + "<= -1000";
   }

   private List stagePubkeys;
   private List relPubkeys;
   private List prodPubkeys;
   private List mirageProdIds;
   private List midasProdIds;
   private List midasNameIds;
   private List germplasmIds;

   public boolean completed()
      throws WrappingException
   {
      storeXrefValues();
      deleteLexiconData();
      deleteMirageData();
      deleteYieldMartData();
      deleteMidasProductData();
      return true;
   }

   private void storeXrefValues()
      throws WrappingException
   {
      relPubkeys = new RelationshipPubkeysQuery().getPubkeyList();
      stagePubkeys = new StagePubkeysQuery().getPubkeyList();
      prodPubkeys = new ProductPubkeysQuery().getPubkeyList();
      mirageProdIds = new MirageProductIdsQuery().getIdList();
      midasProdIds = new MidasProductIdsQuery().getIdList();
      midasNameIds = new MidasProductNameIdsQuery().getIdList();
      germplasmIds = new GermplasmIdsQuery().getIdList();
   }

   private void deleteLexiconData()
      throws WrappingException
   {
      new DeleteTestLexiconProductRelXrefs().performDelete();
      new DeleteTestLexiconProductRels().performDelete();
      new DeleteTestLexiconProductStages().performDelete();
      new DeleteTestLexiconProducts().performDelete();
   }

   abstract class LexDeleteDataMods
      extends LexiconDataFixtureDelete
   {
      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[0];
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new LexiconConnectionFactoryProperties();
      }
   }

   class DeleteTestLexiconProductRelXrefs
      extends LexDeleteDataMods
   {
      protected String getSQL()
         throws WrappingException
      {
         return "DELETE FROM Lexicon.Product_Relationship_Xref WHERE " +
            "product_relationship_id IN (" +
               "SELECT product_relationship_id FROM Lexicon.Product_Relationship " +
               "WHERE " + SqlUtilities.makeInListOfStrings("product_relationship_pubkey", relPubkeys)
            + ")" +
            " OR " +
            "product_id IN (" +
               "SELECT product_id FROM Lexicon.Pre_Coml_Product " +
               "WHERE " + SqlUtilities.makeInListOfStrings("product_pubkey", prodPubkeys) +
            " )";
      }
   }

   class DeleteTestLexiconProductRels
      extends LexDeleteDataMods
   {
      protected String getSQL()
         throws WrappingException
      {
         return "DELETE FROM Lexicon.Product_Relationship WHERE " +
            SqlUtilities.makeInListOfStrings("product_relationship_pubkey", relPubkeys);
      }
   }

   class DeleteTestLexiconProductStages
      extends LexDeleteDataMods
   {
      protected String getSQL()
         throws WrappingException
      {
         return "DELETE FROM Lexicon.Product_Stage WHERE " +
            SqlUtilities.makeInListOfStrings("product_stage_pubkey", stagePubkeys);
      }
   }

   class DeleteTestLexiconProducts
      extends LexDeleteDataMods
   {
      protected String getSQL()
         throws WrappingException
      {
         return "DELETE FROM Lexicon.Pre_Coml_Product WHERE " +
            SqlUtilities.makeInListOfStrings("product_pubkey", prodPubkeys);
      }
   }

   private void deleteMirageData()
      throws WrappingException
   {
      new DeleteTestMirageMaturities().performDelete();
      new DeleteTestMirageProducts().performDelete();
   }

   abstract class MirageDeleteDataMods
      extends AbstractPersistentStoreDelete
   {
      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[0];
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new MirageConnectionFactoryProperties();
      }
   }

   class DeleteTestMirageMaturities
      extends MirageDeleteDataMods
   {
      protected String getSQL()
         throws WrappingException
      {
         return "DELETE FROM Mirage2.Seed_Products_Maturity WHERE " +
            SqlUtilities.makeInListOfNumerics("product_id", mirageProdIds);
      }
   }

   class DeleteTestMirageProducts
      extends MirageDeleteDataMods
   {
      protected String getSQL()
         throws WrappingException
      {
         return "DELETE FROM Mirage2.Seed_Products WHERE " +
            SqlUtilities.makeInListOfNumerics("product_id", mirageProdIds);
      }
   }

   private void deleteYieldMartData()
      throws WrappingException
   {
      new DeleteTestMapProductMirageEntries().performDelete();
   }

   class DeleteTestMapProductMirageEntries
      extends AbstractPersistentStoreDelete
   {
      protected String getSQL()
         throws WrappingException
      {
         List mapProductMirageIds = new MapProductMirageIdsQuery().getIdList();
         return "DELETE FROM YldStg.Map_Product_Mirage " +
            "WHERE " + SqlUtilities.makeInListOfNumerics("seed_product_id", mirageProdIds) +
            " OR " + SqlUtilities.makeInListOfNumerics("seed_product_id", mapProductMirageIds);
      }
      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[0];
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new YieldMartConnectionFactoryProperties();
      }
   }

   private void deleteMidasProductData()
      throws WrappingException
   {
      new DeleteProductGermplasmEntries().performDelete();
      new DeleteProductNameEntries().performDelete();
      new DeleteProductEntries().performDelete();
      new DeleteParentageEntries().performDelete();
      new DeleteGeneticMaterialEntries().performDelete();
      new DeleteGermplasmEntries().performDelete();
   }

   class DeleteProductGermplasmEntries
      extends AbstractPersistentStoreDelete
   {
      protected String getSQL()
         throws WrappingException
      {
         return "DELETE FROM Midas.Product_Germplasm " +
            "WHERE " + SqlUtilities.makeInListOfNumerics("product_id", midasProdIds) +
            " OR " + SqlUtilities.makeInListOfNumerics("germplasm_id", germplasmIds);
      }
      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[0];
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new MidasConnectionFactoryProperties();
      }
   }

   class DeleteProductNameEntries
      extends AbstractPersistentStoreDelete
   {
      protected String getSQL()
         throws WrappingException
      {
         return "DELETE FROM Midas.Product_Name " +
            "WHERE " + SqlUtilities.makeInListOfNumerics("product_id", midasProdIds);
      }
      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[0];
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new MidasConnectionFactoryProperties();
      }
   }

   class DeleteProductEntries
      extends AbstractPersistentStoreDelete
   {
      protected String getSQL()
         throws WrappingException
      {
         return "DELETE FROM Midas.Product " +
            "WHERE " + SqlUtilities.makeInListOfNumerics("product_id", midasProdIds);
      }
      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[0];
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new YieldMartConnectionFactoryProperties();
      }
   }

   class DeleteParentageEntries
      extends AbstractPersistentStoreDelete
   {
      protected String getSQL()
         throws WrappingException
      {
         List parentageIds = new ParentageIdsQuery().getIdList();
         return "DELETE FROM Midas.Parentage " +
            "WHERE " + SqlUtilities.makeInListOfNumerics("parentage_id", parentageIds);
      }
      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[0];
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new MidasConnectionFactoryProperties();
      }
   }

   class DeleteGeneticMaterialEntries
      extends AbstractPersistentStoreDelete
   {
      protected String getSQL()
         throws WrappingException
      {
         List materialIds = new GeneticMaterialIdsQuery().getIdList();
         return "DELETE FROM Midas.Genetic_Material " +
            "WHERE " + SqlUtilities.makeInListOfNumerics("genetic_material_id", materialIds);
      }
      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[0];
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new MidasConnectionFactoryProperties();
      }
   }

   class DeleteGermplasmEntries
      extends AbstractPersistentStoreDelete
   {
      protected String getSQL()
         throws WrappingException
      {
         return "DELETE FROM Midas.Germplasm " +
            "WHERE " + SqlUtilities.makeInListOfNumerics("germplasm_id", germplasmIds);
      }
      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[0];
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new MidasConnectionFactoryProperties();
      }
   }
}
