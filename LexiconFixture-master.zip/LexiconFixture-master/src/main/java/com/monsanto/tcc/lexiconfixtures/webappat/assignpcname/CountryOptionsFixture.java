/*
 CountryTableFixture was created on Mar 16, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.webappat.assignpcname;

import com.monsanto.Util.StringUtils;
import fitlibrary.ArrayFixture;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * nbwald Mar 16, 2007 3:21:32 PM
 */
public class CountryOptionsFixture
   extends ArrayFixture
{
   private List countryValues = new ArrayList();

   public CountryOptionsFixture(String countryNamesAndAbbrs) {
      String[] nameAndAbbrs = countryNamesAndAbbrs.split("\n");
      for (int i = 0; i < nameAndAbbrs.length; i++) {
         String nameAndAbbr = nameAndAbbrs[i];
         if(!StringUtils.isNullOrEmpty(nameAndAbbr)) {
            countryValues.add(parseCountryValue(nameAndAbbr));
         }
      }
      setActualCollection(countryValues);
   }

   private CountryValue parseCountryValue(String nameAndAbbr) {
      String trimmedNameAndAbbr = nameAndAbbr.trim();
      Pattern p = Pattern.compile(getRegexp());
      Matcher m = p.matcher(trimmedNameAndAbbr);
      if(!m.matches()) {
         throw new RuntimeException("Expected country value '" + trimmedNameAndAbbr + "' to match pattern: " + p.pattern());
      }
      String name = m.group(1);
      String abbr = m.group(2);
      return new CountryValue(abbr, name);
   }

   private String getRegexp() {
      /* e.g. United States of America USA
         group 1: United States of America
         group 2: USA 
       */
      final String anyCharacters = "(.*?)";
      final String someWhitespace = "[\\s]+";
      final String someNonwhitespace = "(\\S+)";
      final String endOfString = "$";
      
      return anyCharacters
         + someWhitespace
         + someNonwhitespace
         + endOfString;
   }
}