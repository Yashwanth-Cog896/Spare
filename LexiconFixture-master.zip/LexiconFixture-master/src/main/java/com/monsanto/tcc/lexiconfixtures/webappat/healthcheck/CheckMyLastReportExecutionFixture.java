/*
 CheckReportExecutionFixture was created on Mar 30, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.webappat.healthcheck;

import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactory;
import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.EmptyResultSetException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetSingleResult;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.user.NoSuchUserException;
import com.monsanto.user.User;
import fit.RowFixture;
import org.ietf.jgss.GSSException;

/**
 * nbwald Mar 30, 2007 12:01:20 PM
 */
public class CheckMyLastReportExecutionFixture
   extends RowFixture
{
   public Object[] query()
      throws Exception
   {
      ReportExecutionAdapter lastReportExecution = getLastReportExecution();
      return new ReportExecutionAdapter[] { lastReportExecution }; 
   }

   private ReportExecutionAdapter getLastReportExecution()
      throws WrappingException, GSSException, NoSuchUserException, EmptyResultSetException
   {
      String sql =
         "select R.report_name As ReportName, RE.report_contents AS ReportContents" +
         "  from Report_Execution RE," +
         "       Report R" +
         " where RE.report_id = R.report_id" +
         "   and RE.report_execution_id = " +
         "       (select max(RE.report_execution_id)" +
         "          from Report_Execution RE," +
         "               Report R" +
         "         where R.report_id = RE.report_id" +
         "           and RE.user_party_id = ?)";

      PersistentStoreConnection conn = new LexiconConnectionFactory().getConnection();
      PersistentStoreStatement statement = conn.prepareStatement(sql);
      try {
         statement.setParam(1, getCurrentUsersPartyID());
         PersistentStoreResultSetSingleResult result = statement.executeQuery().getSingleResult();
         return createReportExecutionAdapterFromResult(result);
      }
      finally {
         statement.close();
      }
   }

   private ReportExecutionAdapter createReportExecutionAdapterFromResult(PersistentStoreResultSetSingleResult result)
      throws WrappingException
   {
      ReportExecutionAdapter adapter = new ReportExecutionAdapter();
      adapter.reportName = result.getString("ReportName");
      adapter.reportContents = result.getString("ReportContents");
      return adapter;
   }

   private int getCurrentUsersPartyID()
      throws GSSException, WrappingException, NoSuchUserException
   {
      KerberosStandaloneCredential credential = new KerberosStandaloneCredential();
      User user = new User(credential.getUserID());
      return user.getPartyID();
   }

   public Class getTargetClass() {
      return ReportExecutionAdapter.class;
   }
}