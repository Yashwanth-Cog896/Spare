package com.monsanto.tcc.lexiconfixtures.data.lexicon.productname;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.util.ColumnFixtureResetter;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.dataservices.EmptyResultSetException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetSingleResult;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.dbdataservices.SQLUtil;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Dec 13, 2006
 * Time: 3:43:51 PM
 */
public class CheckLexiconMonsantoProductAlias
   extends SymbolAcceptingColumnFixture
{
   public String precomlName;
   public String country;
   public String brand;
   public String stage;
   public String commercialName;
   public String commercialMaturity;  // fixture needs this to be a string if it is going to be nullable
   public boolean active;
   public String commercialTrait;
   public boolean logicalDelete;

   private SQLPropFile sqlPropFile = new SQLPropFile(LexiconProductNameFixtureSQL.class);

   public void reset()
      throws Exception
   {
      ColumnFixtureResetter.reset(this);
   }

   public boolean exists()
      throws WrappingException, EmptyResultSetException
   {
      LexiconConnectionFactory connectionFactory = new LexiconConnectionFactory();
      PersistentStoreConnection conn = connectionFactory.getConnection();
      try {
         return getNumOfMatchingAliases(conn) > 0;
      }
      finally {
         conn.close();
      }
   }

   private int getNumOfMatchingAliases(PersistentStoreConnection conn)
      throws WrappingException, EmptyResultSetException
   {
      String sql = getSQL();
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         bindTheVariables(stmt);
         PersistentStoreResultSetSingleResult result = stmt.executeQuery().getSingleResult();
         return result.getInt(1);
      }
      finally {
         stmt.close();
      }
   }

   private String getSQL()
      throws WrappingException
   {
      String baseSQL = sqlPropFile.getSQL(LexiconProductNameFixtureSQL.SELECT_NUM_OF_MATCHING_PRODUCT_ALIASES);
      StringBuffer sql = new StringBuffer(baseSQL);
      sql.append(getCommercialNameClause());
      sql.append(getCommercialMaturityClause());
      sql.append(getCommercialTraitClause());
      return sql.toString();
   }

   private String getCommercialNameClause()
      throws WrappingException
   {
      return commercialName == null ?
         " " + sqlPropFile.getSQL(LexiconProductNameFixtureSQL.COML_NAME_NULL_CRITERIA) + " " :
         " " + sqlPropFile.getSQL(LexiconProductNameFixtureSQL.COML_NAME_NOT_NULL_CRITERIA) + " ";
   }

   private String getCommercialMaturityClause()
      throws WrappingException
   {
      return commercialMaturity == null ?
         " " + sqlPropFile.getSQL(LexiconProductNameFixtureSQL.COML_MAT_NULL_CRITERIA) + " " :
         " " + sqlPropFile.getSQL(LexiconProductNameFixtureSQL.COML_MAT_NOT_NULL_CRITERIA) + " ";
   }

   private String getCommercialTraitClause()
      throws WrappingException {
       return commercialTrait == null ?
         " " + sqlPropFile.getSQL(LexiconProductNameFixtureSQL.COML_TRAIT_STACK_NULL_CRITERIA) + " " :
         " " + sqlPropFile.getSQL(LexiconProductNameFixtureSQL.COML_TRAIT_STACK_NOT_NULL_CRITERIA) + " ";
   }

   private void bindTheVariables(PersistentStoreStatement stmt)
      throws WrappingException
   {
      int columnPosition = 1;
      stmt.setParam(columnPosition++, precomlName);
      stmt.setParam(columnPosition++, StringUtils.toUpperCaseNull(country));
      stmt.setParam(columnPosition++, StringUtils.toUpperCaseNull(brand));
      stmt.setParam(columnPosition++, StringUtils.toUpperCaseNull(stage));
      stmt.setParam(columnPosition++, SQLUtil.booleanToString(active));
      stmt.setParam(columnPosition++, SQLUtil.booleanToString(logicalDelete));
      if(commercialName != null) stmt.setParam(columnPosition++, commercialName);
      if(commercialMaturity != null) stmt.setParam(columnPosition++, Double.valueOf(commercialMaturity));
      if(commercialTrait != null) {
         stmt.setParam(columnPosition++, precomlName);
         stmt.setParam(columnPosition, StringUtils.toUpperCaseNull(commercialTrait));
      }
   }
}
