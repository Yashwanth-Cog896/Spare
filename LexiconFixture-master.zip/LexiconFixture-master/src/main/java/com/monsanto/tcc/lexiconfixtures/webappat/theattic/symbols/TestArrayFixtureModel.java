package com.monsanto.tcc.lexiconfixtures.webappat.theattic.symbols;

/**
 * Created by IntelliJ IXA.
 * User: JASKIDI
 * Date: Apr 4, 2007
 * Time: 1:21:39 AM
 * To change this template use File | Settings | File Templates.
 */
public class TestArrayFixtureModel
{
   public Long id;
   public String name;
   public Long value;

   public TestArrayFixtureModel(Long id, String name, Long value) {
      this.id = id;
      this.name = name;
      this.value = value;
   }

   public Object[] getAsArrayOfValues() {
      return new Object[]  { id, name, value };
   }
}
