package com.monsanto.tcc.lexiconfixtures.data.midas.allinfo;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.dataservices.PersistentStoreStatement;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Mar 16, 2007
 * Time: 3:25:29 PM
 * To change this template use File | Settings | File Templates.
 */
public class AssociatedGermplasmLookup
{
   private final String sql =
      "SELECT PGP.germplasm_id FROM Midas.product_germplasm PGP WHERE PGP.product_id IN (SELECT PGP.product_id FROM Midas.product_germplasm PGP WHERE PGP.germplasm_id = ?)";

   public Long[] getAssociatedGermplasmIds(PersistentStoreConnection conn, Long germplasmId)
      throws WrappingException
   {
      Set germplasmIds = new HashSet();
      germplasmIds.add(germplasmId);
      germplasmIds.addAll( queryAssociatedGermplasmIds(conn, germplasmId) );
      return (Long[])germplasmIds.toArray(new Long[germplasmIds.size()]);
   }

   private Collection queryAssociatedGermplasmIds(PersistentStoreConnection conn, Long germplasmId)
      throws WrappingException
   {
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, germplasmId);
         PersistentStoreResultSetFwdIterator resultSetIter = stmt.executeQuery().getForwardIterator();
         return buildGermplasmIds(resultSetIter);
      }
      finally {
         stmt.close();
      }
   }

   private Collection buildGermplasmIds(PersistentStoreResultSetFwdIterator resultSetIter)
      throws WrappingException
   {
      Set germplasmIds = new HashSet();
      while(resultSetIter.next()) {
         germplasmIds.add(resultSetIter.getLONG(1));
      }
      return germplasmIds;
   }
}
