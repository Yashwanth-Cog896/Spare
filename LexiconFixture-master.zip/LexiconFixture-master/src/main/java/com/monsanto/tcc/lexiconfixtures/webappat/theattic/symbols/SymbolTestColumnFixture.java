package com.monsanto.tcc.lexiconfixtures.webappat.theattic.symbols;

import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;

/**
 * Created by IntelliJ IXA.
* User: jaskidi
* Date: Apr 3, 2007
* Time: 1:11:33 PM
* To change this template use File | Settings | File Templates.
*/
public class SymbolTestColumnFixture
   extends SymbolAcceptingColumnFixture
{
   public Long symbolValue;
   public Long hardCodedValue;

   public boolean doesEqual() {
      return symbolValue.longValue() == hardCodedValue.longValue();
   }
}
