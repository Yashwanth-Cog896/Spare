/*
 RemoveAllBaseProductInfo was created on Jul 17, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo;

import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo.BaseProductIdByBaseManfName;
import com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo.cascadingdelete.BaseProductCascadeDelete;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald Jul 17, 2007 2:31:32 PM
 */
public class RemoveAllBaseProductInfo
   extends SymbolAcceptingColumnFixture
{
   public String baseManufacturingName;

   public boolean removed()
      throws WrappingException
   {
      BaseProductIdByBaseManfName idQuery = new BaseProductIdByBaseManfName(baseManufacturingName);
      Long baseProductId = idQuery.getId();
      return baseProductId != null && cascadedDeletion(baseProductId);
   }

   private boolean cascadedDeletion(Long baseProductId)
      throws WrappingException
   {
      BaseProductCascadeDelete deleter = new BaseProductCascadeDelete(baseProductId);
      return deleter.remove();
   }
}