package com.monsanto.tcc.lexiconfixtures.data.midas.allinfo;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Mar 16, 2007
 * Time: 4:05:40 PM
 * To change this template use File | Settings | File Templates.
 */
public class DeleteGeneticMaterialsByGeneticMaterialIds
{
   private final String sql = "DELETE FROM Midas.genetic_material GM WHERE gm.genetic_material_id = ?";

   public int deleteGeneticMaterial(PersistentStoreConnection conn, Long[] geneticMaterialIds)
      throws WrappingException
   {
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         int numDeleted = 0;
         for (int i = 0; i < geneticMaterialIds.length; i++) {
            Long geneticMaterialId = geneticMaterialIds[i];
            stmt.setParam(1, geneticMaterialId);
            numDeleted += stmt.executeDelete();
         }
         return numDeleted;
      }
      finally {
         stmt.close();
      }
   }
}
