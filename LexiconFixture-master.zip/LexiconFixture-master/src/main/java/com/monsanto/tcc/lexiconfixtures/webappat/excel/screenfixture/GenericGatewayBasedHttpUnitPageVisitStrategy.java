package com.monsanto.tcc.lexiconfixtures.webappat.excel.screenfixture;

import com.meterware.httpunit.WebConversation;
import com.meterware.httpunit.WebResponse;

/**
 * nbwald - Apr 17, 2008 11:40:51 AM
 */
public class GenericGatewayBasedHttpUnitPageVisitStrategy
   implements HttpUnitPageVisitStrategy
{
   private final String destination;

   public GenericGatewayBasedHttpUnitPageVisitStrategy(String destination) {
      this.destination = destination;
   }

   public WebResponse visitPage(WebConversation conversation)
      throws Exception
   {
      UrlBasedHttpUnitPageVisitStrategy delegateStrategy = new UrlBasedHttpUnitPageVisitStrategy("/servlet/GenericGateway?destination=" + destination);
      return delegateStrategy.visitPage(conversation);
   }
}
