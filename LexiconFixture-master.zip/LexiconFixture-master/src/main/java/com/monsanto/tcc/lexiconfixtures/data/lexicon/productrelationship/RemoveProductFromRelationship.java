package com.monsanto.tcc.lexiconfixtures.data.lexicon.productrelationship;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.test.LexiconTestTools;
import com.monsanto.tcc.lexiconcommon.db.audit.LexiconAuditor;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 15, 2006
 * Time: 11:53:12 AM
 * To change this template use File | Settings | File Templates.
 */
public class RemoveProductFromRelationship
  extends SymbolAcceptingColumnFixture
{
   public String manufacturingName;
   public String precomlName;

   private SQLPropFile sqlPropFile = new SQLPropFile(ProductRelationshipFixtureSQL.class);

   public boolean removed()
      throws WrappingException
   {
      LexiconConnectionFactory connectionFactory = new LexiconConnectionFactory();
      PersistentStoreConnection conn = connectionFactory.getConnection();
      LexiconAuditor lexiconAuditor = LexiconTestTools.FITNESSE_TEST_AUDITOR;
      lexiconAuditor.initializeStaging(conn);
      try {
         int numDeleted = deleteFakeData(conn);
         return numDeleted == 1;
      }
      finally {
         lexiconAuditor.removeStaging(conn);
         conn.close();
      }
   }

   private int deleteFakeData(PersistentStoreConnection conn)
      throws WrappingException
   {
      String sql = sqlPropFile.getSQL(ProductRelationshipFixtureSQL.DELETE_PRODUCT_RELATIONSHIP_XREF);
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, manufacturingName);
         stmt.setParam(2, precomlName);
         return stmt.executeDelete();
      }
      finally {
         stmt.close();
      }
   }
}