package com.monsanto.tcc.lexiconfixtures.serviceat.person;

import com.monsanto.tps.lexicon.person.MinimalPersonRecord;

/**
 * nbwald - May 23, 2008 10:57:29 AM
 */
public class MinimalPersonRecordAdaptor
{
   public final long uniqueId;
   public final String firstName;
   public final String middleName;
   public final String lastName;
   public final String networkId;
   public final String orgDesc;

   public MinimalPersonRecordAdaptor(MinimalPersonRecord minimalPersonRecord) {
      this.uniqueId = minimalPersonRecord.getUniqueId();
      this.firstName = minimalPersonRecord.getFirstName();
      this.middleName = minimalPersonRecord.getMiddleName();
      this.lastName = minimalPersonRecord.getLastName();
      this.networkId = minimalPersonRecord.getNetworkId();
      this.orgDesc = minimalPersonRecord.getOrganizationDescription();
   }
}
