package com.monsanto.tcc.lexiconfixtures.data.mirage.allinfo;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.data.factories.mirage.MirageConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import java.util.List;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Mar 19, 2007
 * Time: 3:17:51 PM
 * To change this template use File | Settings | File Templates.
 */
public class MirageSeedProductIdByProductNameQuery
   extends AbstractPersistentStoreMultiRowQuery
{
   private final String productName;

   public MirageSeedProductIdByProductNameQuery(String productName) {
      this.productName = productName;
   }

   public List getIds()
      throws WrappingException
   {
      return getList();
   }
   
   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return row.getLONG(1);
   }
   protected String getSQL()
      throws WrappingException
   {
      return "SELECT SP.Product_Id FROM Mirage2.Seed_Products SP WHERE SP.product_name = ?";
   }
   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { productName };
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MirageConnectionFactoryProperties();
   }
}
