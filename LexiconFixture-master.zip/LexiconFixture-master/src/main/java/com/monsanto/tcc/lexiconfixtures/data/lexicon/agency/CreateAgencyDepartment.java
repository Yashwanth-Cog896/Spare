package com.monsanto.tcc.lexiconfixtures.data.lexicon.agency;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dbdataservices.SQLUtil;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.LexiconDataFixtureInsert;
import com.monsanto.tcc.lexiconfixtures.util.random.GetRandomId;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;

/**
 * nbwald - Dec 1, 2008 6:00:24 PM
 */
public class CreateAgencyDepartment
   extends SymbolAcceptingColumnFixture
{
   public String agencyAbbreviation;
   public String name;
   public String address1;
   public String address2;
   public String city;
   public String subcountryCode;
   public String postalCode;

   public boolean created()
      throws WrappingException
   {
      AgencyDepartmentInsert insert = new AgencyDepartmentInsert();
      return insert.performInsert() == 1;
   }

   private class AgencyDepartmentInsert
      extends LexiconDataFixtureInsert
   {
      protected String getSQL()
         throws WrappingException
      {
         return
            "INSERT INTO Lexicon.Agency_Department " +
            "(agency_dept_id, agency_dept_pubkey, agency_dept_abbr, agency_dept_name, agency_id, address1, address2, city, sub_country_abbr, postal_code, is_active)" +
            "VALUES" +
            "(?, ?, ?, ?, (SELECT agency_id FROM Lexicon.Agency WHERE agency_abbr = ?), ?, ?, ?, ?, ?, ?)";
      }

      protected Object[] getBindVariables()
         throws WrappingException
      {
         long id = new GetRandomId().value();
         String pubkey = String.valueOf(id);
         String agencyDepartmentAbbr = String.valueOf(id);
         String isActive = SQLUtil.booleanToString(true);
         return new Object[] { id, pubkey, agencyDepartmentAbbr, name, agencyAbbreviation, address1, address2, city, subcountryCode, postalCode, isActive};
      }

      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new LexiconConnectionFactoryProperties();
      }
   }
}
