package com.monsanto.tcc.lexiconfixtures.util.approle;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.lexiconfixtures.util.UserHelper;
import com.monsanto.tcc.lexiconfixtures.util.approle.tpssecurity.SecurityGroupsByUserLoginIdQuery;
import com.monsanto.tcc.lexiconfixtures.util.approle.tpssecurity.AddUserToGroupDataMod;
import com.monsanto.tcc.lexiconfixtures.util.approle.tpssecurity.AllLexiconRolesQuery;
import com.monsanto.tcc.lexiconfixtures.util.approle.tpssecurity.NewGroupRoleDataMod;
import com.monsanto.tcc.lexiconfixtures.util.approle.tpssecurity.NewSecurityGroupDataMod;
import com.monsanto.tcc.lexiconfixtures.util.approle.tpssecurity.RemoveGroupDataMod;
import com.monsanto.tcc.lexiconfixtures.util.approle.tpssecurity.RemoveRolesFromGroupDataMod;
import com.monsanto.tcc.lexiconfixtures.util.approle.tpssecurity.RemoveUserFromAllGroupsDataMod;
import com.monsanto.tcc.lexiconfixtures.util.random.GetRandomText;

import java.util.List;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: May 9, 2007
 * Time: 3:05:14 PM
 */
public class AppRoleTestTools
{
   private static final String FITNESSE_GROUP_PREFIX = "FITNESSE_";
   private static final int FITNESSE_GROUP_LENGTH = 20;

   public static void setCurrentUsersRoles(String[] desiredRoles)
      throws Exception
   {
      String userLoginId = UserHelper.getCurrentUserLoginId();
      String groupName = createRandomGroupName();
      createNewGroup(groupName);
      addRolesToGroup(desiredRoles, groupName);
      removeUserFromAllGroups(userLoginId);
      addUserToGroup(userLoginId, groupName);
   }

   public static void setAllRolesForCurrentUser()
      throws Exception
   {
      String[] allRoles = findAllRoles();
      setCurrentUsersRoles(allRoles);
   }

   public static void removeFakeFitnesseGroups(List<String> groupNames)
      throws WrappingException
   {
      for (String groupName : groupNames) {
         removeFakeFitnesseGroup(groupName);
      }
   }

   public static void addUserToGroups(String userLoginId, List<String> groupNames)
      throws WrappingException
   {
      for (String groupName : groupNames) {
         addUserToGroup(userLoginId, groupName);
      }
   }

   public static List<String> findCurrentGroups(String userLoginId)
      throws WrappingException
   {
      SecurityGroupsByUserLoginIdQuery query = new SecurityGroupsByUserLoginIdQuery(userLoginId);
      return query.find();
   }

   public static void removeUserFromAllGroups(String userLoginId)
      throws WrappingException
   {
      RemoveUserFromAllGroupsDataMod dataMod = new RemoveUserFromAllGroupsDataMod(userLoginId);
      dataMod.performDelete();
   }

   private static void removeFakeFitnesseGroup(String groupName)
      throws WrappingException
   {
      if(groupName.startsWith(FITNESSE_GROUP_PREFIX)) {
         removeRolesFromGroup(groupName);
         removeGroup(groupName);
      }
   }

   private static void removeRolesFromGroup(String groupName)
      throws WrappingException
   {
      RemoveRolesFromGroupDataMod dataMod = new RemoveRolesFromGroupDataMod(groupName);
      dataMod.performDelete();
   }

   private static void removeGroup(String groupName)
      throws WrappingException
   {
      RemoveGroupDataMod dataMod = new RemoveGroupDataMod(groupName);
      dataMod.performDelete();
   }

   private static String[] findAllRoles() {
      AllLexiconRolesQuery query = new AllLexiconRolesQuery();
      List<String> allLexiconRoles = query.find();
      return allLexiconRoles.toArray(new String[allLexiconRoles.size()]);
   }

   private static void addUserToGroup(String userLoginId, String groupName)
      throws WrappingException
   {
      AddUserToGroupDataMod dataMod = new AddUserToGroupDataMod(userLoginId, groupName);
      dataMod.performInsert();
   }

   private static void addRolesToGroup(String[] desiredRoles, String groupName)
      throws WrappingException
   {
      for (String desiredRole : desiredRoles) {
         addRoleToGroup(desiredRole, groupName);
      }
   }

   private static void addRoleToGroup(String desiredRole, String groupName)
      throws WrappingException
   {
      NewGroupRoleDataMod dataMod = new NewGroupRoleDataMod(desiredRole, groupName);
      dataMod.performInsert();
   }

   private static void createNewGroup(String groupName)
      throws WrappingException
   {
      NewSecurityGroupDataMod dataMod = new NewSecurityGroupDataMod(groupName);
      dataMod.performInsert();
   }

   private static String createRandomGroupName() {
      GetRandomText randomTextFixture = new GetRandomText();
      randomTextFixture.length = FITNESSE_GROUP_LENGTH;
      randomTextFixture.prefix = FITNESSE_GROUP_PREFIX;
      return randomTextFixture.text();
   }
}
