/*
 CropFixture was created on Jul 7, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tcc.lexiconfixtures.serviceat.crop;

import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import static com.monsanto.Util.StringUtils.getLineSeparator;
import com.monsanto.tcc.lexiconfixtures.serviceat.artemis.client.ClientMethodExecutor;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SafeSortSymbolAcceptingRowFixture;
import com.monsanto.tps.lexicon.crop.BayerCode;
import com.monsanto.tps.lexicon.crop.Crop;
import com.monsanto.tps.lexicon.crop.ScientificName;
import com.monsanto.tps.lexicon.crop.service.Crops;
import com.monsanto.tps.lexicon.crop.service.CropsImpl;
import fit.Fixture;
import fitlibrary.DoFixture;
import org.ietf.jgss.GSSException;

import java.util.ArrayList;
import java.util.List;

/**
 * @author GGSHIV - Jul 7, 2008 9:19:34 AM
 */
public class CropFixture extends DoFixture {

   private Crop[] crops;
   private String errorMessage;
   private int recordsCount;

   public boolean findAllCrops() throws Exception {
      crops = getClient().findAll();
      return true;
   }

   public boolean findCropsByPublicKeys(final String keysCSV) throws Exception {
      execute("findByPublicKeys", new Object[]{keysCSV.split(",")});
      return true;
   }

   public boolean findCropsByBayerCode(final String codesCSV) throws Exception {
      execute("findByBayerCodes", new Object[]{codesCSV.split(",")});
      return true;
   }

   public boolean findCropsByBayerCodePublicKeys(final String keysCSV) throws Exception {
      execute("findByBayerCodePublicKeys", new Object[]{keysCSV.split(",")});
      return true;
   }

   public boolean findCropsByGenusSpeciesPublicKeys(final String keysCSV) throws Exception {
      execute("findByGenusSpeciePublicKeys", new Object[]{keysCSV.split(",")});
      return true;
   }

   public boolean findCropsByAbbreviations(final String abbrCSV) throws Exception {
      execute("findByAbbreviations", new Object[]{abbrCSV.split(",")});
      return true;
   }

   public boolean findCropsByAbbreviationsAndScientificName(final String abbrCSV, final String scientificName) throws Exception {
      execute("findByAbbreviationsAndScientificName", new Object[]{abbrCSV.split(","), scientificName});
      return true;
   }

   public boolean findCropsByName(final String name) throws Exception {
      execute("findByName", new Object[]{name});
      return true;
   }

   public boolean findCropsByScientificName(final String scientificName) throws Exception {
      execute("findByScientificName", new Object[]{scientificName});
      return true;
   }

   public boolean findCropsByPublicKeysAndScientificName(final String keysCSV, final String scientificName) throws Exception {
      execute("findByPubkeysAndScientificName", new Object[]{keysCSV.split(","), scientificName});
      return true;
   }

   public boolean findCropsByNameAndScientificName(final String name, final String scientificName) throws Exception {
      execute("findByNameAndScientificName", new Object[]{name, scientificName});
      return true;
   }

   private void execute(String clientMethod, Object[] params) {
      try {
         crops = new ClientMethodExecutor<Crop>().execute(getClient(), clientMethod, params);
      } catch (IllegalArgumentException e) {
         errorMessage = e.getMessage();
      }
   }

   public int numberOfRecordsFound() {
      return recordsCount;
   }

   public String errorMessage() {
      return errorMessage.replaceAll(getLineSeparator(), " ");
   }

   public Fixture checkResults() {
      return new SafeSortSymbolAcceptingRowFixture() {
         public Class<?> getTargetClass() {
            return CropResponseAdaptor.class;
         }

         public Object[] query() throws Exception {
            return buildCropResponseAdaptors();
         }
      };
   }

   private CropResponseAdaptor[] buildCropResponseAdaptors() {
      List<CropResponseAdaptor> adaptors = new ArrayList<CropResponseAdaptor>();
      for (Crop crop : crops) {
         for (BayerCode bayerCode : crop.getBayerCodes()) {
            for (ScientificName scientificName : bayerCode.getScientificNames()) {
               adaptors.add(new CropResponseAdaptor(crop, bayerCode, scientificName));
            }
         }
      }
      recordsCount = adaptors.size();
      return adaptors.toArray(new CropResponseAdaptor[adaptors.size()]);
   }

   private Crops getClient() {
      try {
         return new CropsImpl(new KerberosStandaloneCredential());
      }
      catch (GSSException e) {
         e.printStackTrace();
         throw new RuntimeException(e);
      }
   }

}
