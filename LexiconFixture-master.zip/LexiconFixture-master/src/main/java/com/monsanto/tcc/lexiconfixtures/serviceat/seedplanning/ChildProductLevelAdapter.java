package com.monsanto.tcc.lexiconfixtures.serviceat.seedplanning;

import com.monsanto.tcc.lexiconcommon.service.ProductParentGermplasmDocTags;
import com.monsanto.XMLUtil.DOMUtil;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Feb 14, 2007
 * Time: 7:35:24 AM
 * To change this template use File | Settings | File Templates.
 */
public class ChildProductLevelAdapter
{
   public String productPubkey;
   public String precommercialName;
   public String crop;
   public boolean isDeleted;
   public String manufacturingName;
   public String traitVersion;
   public String productionStatus;
   public String inbredHybrid;
   public boolean hasFinishedGermplasm;

   public ChildProductLevelAdapter(Node childProductNode) {
      this.productPubkey = DOMUtil.getAttribute((Element) childProductNode, ProductParentGermplasmDocTags.PUBKEY_ATTR_NAME);
      this.precommercialName = DOMUtil.getChildValue(childProductNode, ProductParentGermplasmDocTags.PRE_COML_NAME_ELEM_NAME);
      this.crop = DOMUtil.getChildValue(childProductNode, ProductParentGermplasmDocTags.CROP_ELEM_NAME);
      this.inbredHybrid = DOMUtil.getChildValue(childProductNode, ProductParentGermplasmDocTags.INBRED_HYBRID_ELEM_NAME);
      parseIsDeleted(childProductNode);
      parseProductRelationshipAttributes(childProductNode);
      parseHasFinishedGermplasm(childProductNode);
   }

   private void parseIsDeleted(Node childProductNode) {
      String booleanAsString = DOMUtil.getChildValue(childProductNode, ProductParentGermplasmDocTags.LOGICALLY_DELETED_ELEM_NAME);
      this.isDeleted = getBoolean(booleanAsString);
   }

   private void parseProductRelationshipAttributes(Node childProductNode) {
      Node relationshipAttributes = DOMUtil.getChild(childProductNode, ProductParentGermplasmDocTags.RELATIONSHIP_ATTRIBUTES_ELEM_NAME);
      if(relationshipAttributes != null) {
         this.manufacturingName = DOMUtil.getChildValue(relationshipAttributes, ProductParentGermplasmDocTags.MANF_NAME_ELEM_NAME);
         this.traitVersion = DOMUtil.getChildValue(relationshipAttributes, ProductParentGermplasmDocTags.TRAIT_VERSION_ELEM_NAME);
         this.productionStatus = DOMUtil.getChildValue(relationshipAttributes, ProductParentGermplasmDocTags.PROD_STATUS_ELEM_NAME);
      }
   }

   private void parseHasFinishedGermplasm(Node childProductNode) {
      String booleanAsString = DOMUtil.getChildValue(childProductNode, ProductParentGermplasmDocTags.HAS_FINISHED_GP_ELEM_NAME);
      this.hasFinishedGermplasm =  getBoolean(booleanAsString);
   }

   private boolean getBoolean(String booleanAsString) {
      return Boolean.valueOf(booleanAsString).booleanValue();
   }
}
