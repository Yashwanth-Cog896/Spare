package com.monsanto.tcc.lexiconfixtures.util.approle.tpssecurity;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreInsert;
import com.monsanto.tcc.lexiconfixtures.data.factories.spsecurity.SpsecurityConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.random.GetRandomId;

/**
 * nbwald - Jul 14, 2009 12:48:20 PM
 */
public class AddUserToGroupDataMod
   extends AbstractPersistentStoreInsert
{
   private final long userContextPrivGroupId;
   private final String userLoginId;
   private final String groupName;

   public AddUserToGroupDataMod(String userLoginId, String groupName) {
      this.userContextPrivGroupId = new GetRandomId().value();
      this.userLoginId = userLoginId;
      this.groupName = groupName;
   }

   protected String getSQL()
      throws WrappingException
   {
      return
         " INSERT INTO FBS_Common.SPS_User_Context_Priv_Group (" +
         "   user_context_priv_group_id, " +
         "   user_id, " +
         "   context_priv_group_id, " +
         "   scope_id" +
         " )" +
         " VALUES (" +
         "   ?," +
         "   (    SELECT U.user_id" +
         "          FROM FBS_Common.SPS_User U" +
         "    INNER JOIN FBS_Common.SPS_User_Description UD on (U.user_description_id = UD.user_description_id)" +
         "    INNER JOIN FBS_Common.SPS_Environment E on (U.environment_id = E.environment_id)" +
         "         WHERE E.name = 'LEXICON' " +
         "           AND E.active = 'T'" +
         "           AND UD.username = ?" +
         "   )," +
         "   (    SELECT CPG.context_priv_group_id" +
         "          FROM FBS_Common.SPS_Context_Priv_Group CPG" +
         "    INNER JOIN FBS_Common.SPS_Environment E on (CPG.environment_id = E.environment_id)" +
         "         WHERE E.name = 'LEXICON' " +
         "           AND E.active = 'T'" +
         "           AND CPG.name = ?" +
         "   )," +
         "   (    SELECT S.scope_id" +
         "          FROM FBS_Common.SPS_Scope S" +
         "    INNER JOIN FBS_Common.SPS_Scope_Type ST on (S.scope_type_id = ST.scope_type_id)" +
         "         WHERE S.scope_ref_id = 'Global'" +
         "           AND ST.scope_type_value = 'Global'" +
         "   )" +
         " )";
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { userContextPrivGroupId, userLoginId, groupName };
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new SpsecurityConnectionFactoryProperties();
   }
}
