package com.monsanto.tcc.lexiconfixtures.data.lexicon.trait;

import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactory;
import com.monsanto.tcc.lexiconcommon.db.test.LexiconTestTools;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * User: pjberry
 * Date: May 23, 2007
 * Time: 1:55:13 PM
 */
public class RemoveLexiconComlTraitName
   extends SymbolAcceptingColumnFixture
{
   public String traitAbbr;

   public boolean removed()
      throws WrappingException
   {
      PersistentStoreConnection conn = new LexiconConnectionFactory().getConnection();
      LexiconTestTools.FITNESSE_TEST_AUDITOR.initializeStaging(conn);
      try {
         return removeTraitName(conn) == 1;
      }
      finally {
         LexiconTestTools.FITNESSE_TEST_AUDITOR.removeStaging(conn);
         conn.close();
      }
   }

   private int removeTraitName(PersistentStoreConnection conn)
      throws WrappingException
   {
      String sql = getSql();
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, traitAbbr);
         return stmt.executeDelete();
      }
      finally {
         stmt.close();
      }
   }

   private String getSql() {
      return
         "DELETE FROM Lexicon.Coml_Trait_Name2 CTN WHERE CTN.trait_abbr = ?";
   }
}
