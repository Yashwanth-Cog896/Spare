package com.monsanto.tcc.lexiconfixtures.util.random;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Mar 21, 2007
 * Time: 5:50:50 PM
 * To change this template use File | Settings | File Templates.
 */
public class GetRandomId
   extends RandomValueColumnFixture
{
   public Long value() {
      return new Long(-getIntValue());
   }
}
