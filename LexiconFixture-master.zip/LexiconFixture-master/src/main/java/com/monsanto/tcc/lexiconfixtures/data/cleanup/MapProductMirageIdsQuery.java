package com.monsanto.tcc.lexiconfixtures.data.cleanup;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tcc.lexiconfixtures.data.factories.yieldmart.YieldMartConnectionFactoryProperties;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import java.util.List;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: May 1, 2007
 * Time: 2:59:34 PM
 */
public class MapProductMirageIdsQuery
   extends AbstractPersistentStoreMultiRowQuery
{
   public List getIdList() throws WrappingException {
      return super.getList();
   }
   protected Object createObjectFromRow(PersistentStoreResultSetRow row) throws WrappingException {
      return row.getString(1);
   }
   protected Object[] getBindVariables() throws WrappingException {
      return new Object[0];
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new YieldMartConnectionFactoryProperties();
   }

   protected String getSQL()
      throws WrappingException
   {
      return "SELECT seed_product_id " +
         "FROM YldStg.Map_Product_Mirage " +
         "WHERE " + DeleteRandomValueData.getNameClause("mirage_name") +
         " OR " + DeleteRandomValueData.getNumberClause("seed_product_id") +
         " OR " + DeleteRandomValueData.getNumberClause("genetic_material_pk") +
         " OR " + DeleteRandomValueData.getNumberClause("product_pk");
   }
}
