/*
 RemoveMidasBrand was created on Apr 17, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.data.midas.brand;

import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * nbwald Apr 17, 2007 10:55:31 AM
 */
public class RemoveMidasBrand
   extends SymbolAcceptingColumnFixture
{
   public String brandName;

   public boolean removed()
      throws WrappingException
   {
      PersistentStoreConnection conn = new MidasConnectionFactory().getConnection();
      try {
         return brandsRemoved(conn) == 1;
      }
      finally {
         conn.close();
      }
   }

   public boolean clean()
      throws WrappingException
   {
      PersistentStoreConnection conn = new MidasConnectionFactory().getConnection();
      try {
         brandsRemoved(conn);
         return true;
      }
      finally {
         conn.close();
      }
   }

   private int brandsRemoved(PersistentStoreConnection conn)
      throws WrappingException
   {
      PersistentStoreStatement statement = conn.prepareStatement(getSQL());
      try {
         statement.setParam(1, brandName);
         return statement.executeDelete();
      }
      finally {
         statement.close();
      }
   }

   private String getSQL() {
      return "DELETE FROM Midas.Brand B WHERE B.name = ?";
   }
}