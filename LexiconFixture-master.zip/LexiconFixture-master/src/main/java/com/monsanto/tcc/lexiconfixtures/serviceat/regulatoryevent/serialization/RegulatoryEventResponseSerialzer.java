package com.monsanto.tcc.lexiconfixtures.serviceat.regulatoryevent.serialization;

import com.monsanto.tcc.lexiconcommon.service.serialize.BasicSerializer;
import com.monsanto.tcc.lexiconfixtures.serviceat.regulatoryevent.RegulatoryEvent;
import com.monsanto.tcc.lexiconfixtures.serviceat.regulatoryevent.RegulatoryEventResponse;
import com.monsanto.xmlserialization.XmlSerializerBuilder;

/**
 * User: pjberry
 * Date: Aug 2, 2007
 * Time: 4:48:16 PM
 */
public class RegulatoryEventResponseSerialzer
   extends BasicSerializer<RegulatoryEventResponse>
{
   public void registerMappings(XmlSerializerBuilder serializerBuilder) {
      serializerBuilder.registerMapping("http://www.monsanto.com/lexicon/Event", "RegulatoryEventResponse", RegulatoryEventResponse.class);
      serializerBuilder.registerMapping("http://www.monsanto.com/lexicon/Event", "RegulatoryEvent", RegulatoryEvent.class);

      serializerBuilder.registerFieldAlias(RegulatoryEvent.class, "event", "Event");
      serializerBuilder.registerFieldAlias(RegulatoryEvent.class, "plasmidPmon", "Plasmid_pMON");
      serializerBuilder.registerFieldAlias(RegulatoryEvent.class, "plasmidPVCode", "Plasmid_PVCode");
      serializerBuilder.registerFieldAlias(RegulatoryEvent.class, "transformationBackground", "Transformation_Background");
   }
}
