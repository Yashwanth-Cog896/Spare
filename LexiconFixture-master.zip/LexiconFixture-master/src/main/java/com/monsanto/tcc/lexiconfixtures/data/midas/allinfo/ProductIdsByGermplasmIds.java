package com.monsanto.tcc.lexiconfixtures.data.midas.allinfo;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.dataservices.PersistentStoreStatement;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Mar 16, 2007
 * Time: 4:32:03 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProductIdsByGermplasmIds
{
   private final String sql = "SELECT PGP.product_id FROM Midas.product_germplasm PGP WHERE PGP.germplasm_id = ?";

   public Long[] getProductIds(PersistentStoreConnection conn, Long[] germplasmIds)
      throws WrappingException
   {
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         Set allProductIds = new HashSet();
         for (int i = 0; i < germplasmIds.length; i++) {
            stmt.setParam(1, germplasmIds[i]);
            Set productIds = getUniqueProductIds(stmt);
            allProductIds.addAll(productIds);
         }
         return (Long[])allProductIds.toArray(new Long[allProductIds.size()]);
      }
      finally {
         stmt.close();
      }
   }

   private Set getUniqueProductIds(PersistentStoreStatement stmt)
      throws WrappingException
   {
      PersistentStoreResultSetFwdIterator resultSetIter = stmt.executeQuery().getForwardIterator();
      Set productIds = new HashSet();
      while(resultSetIter.next()) {
         productIds.add(resultSetIter.getLONG(1));
      }
      return productIds;
   }
}
