package com.monsanto.tcc.lexiconfixtures.data.factories.midas;

import com.monsanto.tcc.lexiconcommon.db.factories.BasicConnectionFactory;

/**
 * Created by IntelliJ IDEA.
 * User: MAWEAV1
 * Date: Sep 3, 2004
 * Time: 4:59:56 PM
 * To change this template use File | Settings | File Templates.
 */
public class MidasConnectionFactory
   extends BasicConnectionFactory
{
   public MidasConnectionFactory() {
      super(new MidasConnectionFactoryProperties());
   }
}

