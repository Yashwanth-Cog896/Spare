package com.monsanto.tcc.lexiconfixtures.data.lexicon.brand;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import fit.ColumnFixture;

/**
 * User: pjberry
 * Date: Jul 12, 2007
 * Time: 2:25:18 PM
 */
public class TranslateLexiconBrand
   extends ColumnFixture
{
   public String brandName;

   public String brandPubkey()
      throws WrappingException
   {
      BrandPubkeyFromNameQuery query = new BrandPubkeyFromNameQuery();
      return query.getBrandPubkey();
   }

   private class BrandPubkeyFromNameQuery
      extends AbstractPersistentStoreSingleResultQuery
   {
      private String getBrandPubkey()
         throws WrappingException
      {
         return (String)execute();
      }

      protected Object createObjectFromRow(PersistentStoreResultSetRow row)
         throws WrappingException
      {
         return row.getString(1);
      }

      protected String getSQL()
         throws WrappingException
      {
         return "SELECT B.brand_pubkey FROM Lexicon.brand B WHERE B.brand_name = ?";
      }

      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new String[] {brandName};
      }

      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new LexiconConnectionFactoryProperties();
      }
   }
}
