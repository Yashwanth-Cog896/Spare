package com.monsanto.tcc.lexiconfixtures.data.lexicon.trait;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * User: pjberry
 * Date: May 23, 2007
 * Time: 3:50:16 PM
 */
public class DeleteComlTraitNamesByComlTraitNameId
{
    public int deleteComlTraitNames(PersistentStoreConnection conn, Long[] comlTraitNameIds)
      throws WrappingException
    {
      int numDeleted = 0;
      for (int i = 0; i < comlTraitNameIds.length; i++) {
         Long comlTraitNameId = comlTraitNameIds[i];
         numDeleted += deleteTraitName(comlTraitNameId, conn);
      }
      return numDeleted;
   }

   private int deleteTraitName(Long comlTraitNameId, PersistentStoreConnection conn)
      throws WrappingException
   {
      String sql = getDeleteTraitNameSql();
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, comlTraitNameId);
         return stmt.executeDelete();
      }
      finally {
         stmt.close();
      }
   }

   private String getDeleteTraitNameSql() {
      return "DELETE FROM Lexicon.Coml_Trait_Name2 CTN WHERE CTN.coml_trait_name_id = ?";
   }
}
