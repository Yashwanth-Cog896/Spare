package com.monsanto.tcc.lexiconfixtures.webappat;

import com.monsanto.tcc.lexiconfixtures.selenium.LexiconSelenium;
import fit.Fixture;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 13, 2006
 * Time: 4:36:00 PM
 */
public class ProductEquivalencyScreen
   extends SeleniumFixture
{
   private int notedRelationshipNum = -1;
   private int notedProductNum = -1;

   public boolean clickLink(String link) {
      return clickAndWaitForPageToLoad("link=" + link);
   }

   public boolean clickPopup(String locator) {
      LexiconSelenium selenium = getSelenium();
      selenium.click(locator);
      return true;
   }

   public String rowIsColor(String rowId) {
      LexiconSelenium selenium = getSelenium();
      String attributeLocator = getRowIdentifier(rowId) + "@class";
      String className = selenium.getAttribute(attributeLocator);
      return UIFixtureUtils.colorFromClassName(className);
   }

   private String getRowIdentifier(String identifier) {
      if("for noted product".equals(identifier)) {
         return "productRow" + buildProductIdentifier(notedRelationshipNum, notedProductNum);
      }
      else {
         return identifier;
      }
   }

   public boolean clickPopupForNotedProduct(String partialLocator) {
      String locator = partialLocator + buildProductIdentifier(notedRelationshipNum, notedProductNum);
      return clickPopup(locator);
   }

   public boolean noteProduct(String preComlName) {
      LexiconSelenium selenium = getSelenium();
      int relationshipNum = 0;
      while(selenium.isElementPresent("manufacturingNameField_" + relationshipNum)) {
         int preComlNameNum = getPreComlNameNum(relationshipNum, preComlName);
         if(preComlNameNum > -1) {
            setPreComlNameIndex(relationshipNum, preComlNameNum);
            return true;
         }
         relationshipNum++;
      }
      return false;
   }

   private int getPreComlNameNum(int relationshipNum, String preComlName) {
      int possiblePreComlNameNum = 0;
      String locator = buildPreComlNameFieldLocator(relationshipNum, possiblePreComlNameNum);
      while(getSelenium().isElementPresent(locator)) {
         String currentPreComlName = fieldIs(locator);
         if(currentPreComlName.equals(preComlName)) {
            return parsePreComlNameNum(locator);
         }
         locator = buildPreComlNameFieldLocator(relationshipNum, possiblePreComlNameNum++);
      }
      return -1;
   }

   private int parsePreComlNameNum(String locator) {
      String[] fieldNameAndIndexIdentifier = locator.split("_");
      String indexIdentifier = fieldNameAndIndexIdentifier[1];
      String[] relationshipIndexAndPreComlNameIndex = indexIdentifier.split(":");
      return Integer.parseInt(relationshipIndexAndPreComlNameIndex[1]);
   }

   private void setPreComlNameIndex(int relationshipNum, int productNum) {
      this.notedRelationshipNum = relationshipNum;
      this.notedProductNum = productNum;
   }

   public boolean clickForNotedProduct(String partialLocator) {
      String locator = partialLocator + buildProductIdentifier(notedRelationshipNum, notedProductNum);
      clickAndWaitForPageToLoad(locator);
      return true;
   }

   public Fixture iconsInForNotedProduct(String partialLocator) {
      String locator = partialLocator + buildProductIdentifier(notedRelationshipNum, notedProductNum);
      return iconsIn(locator);
   }

   public boolean enterForForNotedProduct(String value, String partialLocator) {
      String locator = partialLocator + buildProductIdentifier(notedRelationshipNum, notedProductNum);
      enterFor(value, locator);
      return true;
   }

   private String buildPreComlNameFieldLocator(int relationshipNum, int productNum) {
      return "precommercialNameField" + buildProductIdentifier(relationshipNum, productNum);
   }

   private String buildProductIdentifier(int relationshipNum, int productNum) {
      return "_" + relationshipNum + ":" + productNum;
   }
}
