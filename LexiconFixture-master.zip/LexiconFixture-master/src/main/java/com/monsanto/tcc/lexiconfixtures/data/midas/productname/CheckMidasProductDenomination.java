/*
 CheckMidasProductDenomination was created on Aug 15, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.data.midas.productname;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreEntityExistsQuery;
import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald Aug 15, 2007 10:17:42 AM
 */
public class CheckMidasProductDenomination
   extends SymbolAcceptingColumnFixture
{
   public String preComlName;
   public String denomination;

   public void reset()
      throws Exception
   {
      super.reset();
      preComlName = null;
      denomination = null;
   }

   public boolean matches()
      throws WrappingException
   {
      MidasProductDenominationExistsQuery query = new MidasProductDenominationExistsQuery();
      return query.entityExists();
   }

   private class MidasProductDenominationExistsQuery
      extends AbstractPersistentStoreEntityExistsQuery
   {
      protected String getSQL()
         throws WrappingException
      {
         return
            "SELECT P.denomination " +
            "  FROM Midas.Product P, " +
            "       Midas.Product_Name PN " +
            " WHERE P.product_id = PN.product_id " +
            "   AND PN.name = ? " +
            "   AND P.denomination = ?";
      }

      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[] { preComlName, denomination };
      }

      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new MidasConnectionFactoryProperties();
      }
   }
}