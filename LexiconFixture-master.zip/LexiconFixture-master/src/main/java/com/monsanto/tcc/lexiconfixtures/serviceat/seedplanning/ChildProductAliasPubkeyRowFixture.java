package com.monsanto.tcc.lexiconfixtures.serviceat.seedplanning;

import com.monsanto.tcc.lexiconcommon.service.ProductParentGermplasmDocTags;
import com.monsanto.tcc.lexiconcommon.xml.LexiconXPathSelector;
import com.monsanto.tcc.lexiconcommon.xml.SingleNamespaceContext;
import com.monsanto.XMLUtil.DOMUtil;
import fit.RowFixture;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Feb 13, 2007
 * Time: 5:53:42 PM
 * To change this template use File | Settings | File Templates.
 */
public class ChildProductAliasPubkeyRowFixture
   extends AbstractChildProductRowFixture
{
   private String preComlName;

   public ChildProductAliasPubkeyRowFixture(Document responseDocument, String preComlName) {
      super(responseDocument);
      this.preComlName = preComlName;
   }

   protected Object[] query(List<Node> childProductNodes)
   {
      List childProductAliasPubkeys = new ArrayList();
      for (Node childProductNode : childProductNodes) {
         String preComlName = DOMUtil.getChildValue(childProductNode, ProductParentGermplasmDocTags.PRE_COML_NAME_ELEM_NAME);
         if(this.preComlName.equals(preComlName)) {
            List pubkeyAdapters = getPubkeyAdapters(childProductNode);
            childProductAliasPubkeys.addAll(pubkeyAdapters);
         }
      }
      return childProductAliasPubkeys.toArray();
   }

   private List getPubkeyAdapters(Node childProductNode) {
      List pubkeyAdapters = new ArrayList();
      Node aliasesNode = DOMUtil.getChild(childProductNode, ProductParentGermplasmDocTags.PRODUCT_ALIASES_ELEM_NAME);
      Node[] aliasesNodes = DOMUtil.getChildren(aliasesNode, ProductParentGermplasmDocTags.PRODUCT_ALIAS_ELEM_NAME);
      for (int j = 0; j < aliasesNodes.length; j++) {
         PubkeyAdapter adapter = buildPubkeyAdapter(aliasesNodes[j]);
         pubkeyAdapters.add(adapter);
      }
      return pubkeyAdapters;
   }

   private PubkeyAdapter buildPubkeyAdapter(Node node) {
      String pubkey = DOMUtil.getAttribute((Element)node, ProductParentGermplasmDocTags.PUBKEY_ATTR_NAME);
      return new PubkeyAdapter(pubkey);
   }

   public Class getTargetClass() {
      return PubkeyAdapter.class;
   }
}
