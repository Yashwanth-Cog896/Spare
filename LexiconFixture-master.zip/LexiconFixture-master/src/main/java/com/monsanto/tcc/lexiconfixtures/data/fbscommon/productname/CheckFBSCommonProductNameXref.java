package com.monsanto.tcc.lexiconfixtures.data.fbscommon.productname;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreEntityExistsQuery;
import com.monsanto.tcc.lexiconfixtures.data.factories.fbs.FBSCommonConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.data.lexicon.productname.LexiconProductAliasPubkeyLookup;
import com.monsanto.tcc.lexiconfixtures.data.midas.productname.MidasProductNameIdByCriteriaQuery;
import com.monsanto.tcc.lexiconfixtures.data.mirage.product.MirageProductIdByCriteriaQuery;
import com.monsanto.tcc.lexiconfixtures.util.ColumnFixtureResetter;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.dataservices.EmptyResultSetException;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Dec 15, 2006
 * Time: 9:54:27 AM
 */
public class CheckFBSCommonProductNameXref
   extends SymbolAcceptingColumnFixture
{
   public String precomlName;
   public String brand;
   public String country;
   public String lexiconComlName;
   public String midasName;
   public String mirageName;

   public void reset()
      throws Exception
   {
      ColumnFixtureResetter.reset(this);
   }

   public boolean exists()
      throws WrappingException
   {
      try {
         String lexiconPubkey = getLexiconPubkey();
         Long midasProductNameId = getMidasProductNameId();
         Long mirageProductId = getMirageProductId();

         FBSCommonProductNameByIdQuery query =
            new FBSCommonProductNameByIdQuery(
               lexiconPubkey, midasProductNameId, mirageProductId);

         return query.entityExists();
      }
      catch (EmptyResultSetException e) {
         return false;
      }
   }

   private String getLexiconPubkey()
      throws WrappingException
   {
      return new LexiconProductAliasPubkeyLookup(precomlName, lexiconComlName, brand, country).getPubkey();
   }

   private Long getMidasProductNameId()
      throws WrappingException, EmptyResultSetException
   {
      if (StringUtils.isNullOrEmpty(midasName)) {
         return (long)0;
      }
      else {
         Long nameId = new MidasProductNameIdByCriteriaQuery(precomlName, midasName, brand, country).getProductNameId();
         if (nameId == null) {
            throw new EmptyResultSetException("Midas name specified, but matching record was not found");
         }
         return nameId;
      }
   }

   private Long getMirageProductId()
      throws WrappingException, EmptyResultSetException
   {
      if (StringUtils.isNullOrEmpty(mirageName)) {
         return (long)0;
      }
      else {
         Long nameId = new MirageProductIdByCriteriaQuery(mirageName, brand, country).getProductId();
         if (nameId == null) {
            throw new EmptyResultSetException("Mirage name specified, but matching record was not found");
         }
         return nameId;
      }
   }
}

class FBSCommonProductNameByIdQuery
   extends AbstractPersistentStoreEntityExistsQuery
{
   public final String lexiconProductNamePubkey;
   public final Long midasProductNameId;
   public final Long mirageProductId;

   public FBSCommonProductNameByIdQuery(
      final String lexiconProductNamePubkey, final Long midasProductNameId, final Long mirageProductId)
   {
      this.lexiconProductNamePubkey = lexiconProductNamePubkey;
      this.midasProductNameId = midasProductNameId;
      this.mirageProductId = mirageProductId;
   }

   protected String getSQL() throws WrappingException {
      return new SQLPropFile(FBSCommonProductNameFixtureSQL.class).getSQL(
         FBSCommonProductNameFixtureSQL.SELECT_MATCHING_NAME_XREF_BYALLIDS);
   }
   protected Object[] getBindVariables() throws WrappingException {
      return new Object[] { lexiconProductNamePubkey, midasProductNameId, mirageProductId };
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new FBSCommonConnectionFactoryProperties();
   }
}
