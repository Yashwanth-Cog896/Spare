/*
 RemoveSAPLinkageAudit was created on Jul 16, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.data.lexicon.saplinkageaudit;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreDelete;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald Jul 16, 2007 5:06:54 PM
 */
public class RemoveSAPLinkageAudit
   extends SymbolAcceptingColumnFixture
{
   public String pubkey;
   public String requestType;
   public String date;
   public String timeRangeSeconds;

   public boolean removed()
      throws WrappingException
   {
      SAPLinkageAuditDeleteDataMod delete = new SAPLinkageAuditDeleteDataMod();
      return delete.performDelete() > 0;
   }

   private class SAPLinkageAuditDeleteDataMod
      extends AbstractPersistentStoreDelete
   {
      protected String getSQL()
         throws WrappingException
      {
         return
            "DELETE FROM " +
            "  Lexicon.Sap_Linkage_Audit SLA " +
            "WHERE " +
            "  SLA.pubkey = ? " +
            "  AND " +
            "  SLA.request_type = ?" +
            "  AND " +
            "  SLA.timestamp >= TO_DATE(?, 'yyyy/mm/dd:hh24:mi:ss') " +
            "  AND " +
            "  SLA.timestamp <= (SELECT TO_DATE(?, 'yyyy/mm/dd:hh24:mi:ss') + ?/86400 FROM DUAL)";
      }

      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[] { pubkey, requestType, date, date, timeRangeSeconds };
      }

      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new LexiconConnectionFactoryProperties();
      }
   }
}