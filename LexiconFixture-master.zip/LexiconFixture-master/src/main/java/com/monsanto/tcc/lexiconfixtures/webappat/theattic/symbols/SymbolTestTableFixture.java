package com.monsanto.tcc.lexiconfixtures.webappat.theattic.symbols;

import com.monsanto.tcc.lexiconfixtures.util.symbol.StringParseDelagate;
import fit.Parse;
import fitnesse.fixtures.TableFixture;
import java.util.List;

/**
 * Created by IntelliJ IXA.
 * User: JASKIDI
 * Date: Apr 4, 2007
 * Time: 1:33:24 AM
 * To change this template use File | Settings | File Templates.
 */
public class SymbolTestTableFixture
   extends TableFixture
{
   private List rowFixtureModel;

   public SymbolTestTableFixture(List rowFixtureModel) {
      this.rowFixtureModel = rowFixtureModel;
   }

   protected void doStaticTable(int numRows) {
      for(int rowNum = 0; rowNum < numRows; rowNum ++) {
         checkRow(rowNum, (TestRowFixtureModel)rowFixtureModel.get(rowNum));
      }
   }

   private void checkRow(int rowNum, TestRowFixtureModel row) {
      String[] columnValues = row.getAsArrayOfValues();
      for (int columnNum = 0; columnNum < columnValues.length; columnNum++) {
         String modelValue = columnValues[columnNum];
         Parse parse = getCell(rowNum, columnNum);
         checkCell(parse, modelValue);
      }
   }

   private void checkCell(Parse parse, String modelValue) {
      StringParseDelagate parseDel = new StringParseDelagate();
      String cellTextValue = parseDel.parse(parse.text());
      if (cellTextValue == null) {
         if (modelValue == null) {
            right(parse);
         }
         else {
            wrong(parse, parseDel.reverseParse(modelValue));
         }
      }
      else {
         if (cellTextValue.equals(modelValue)) {
            right(parse);
         }
         else {
            wrong(parse, parseDel.reverseParse(modelValue));
         }
      }
   }
}
