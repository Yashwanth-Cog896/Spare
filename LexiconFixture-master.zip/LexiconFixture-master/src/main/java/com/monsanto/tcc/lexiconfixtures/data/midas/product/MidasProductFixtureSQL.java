package com.monsanto.tcc.lexiconfixtures.data.midas.product;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 13, 2006
 * Time: 10:41:00 AM
 * To change this template use File | Settings | File Templates.
 */
public interface MidasProductFixtureSQL
{
   String INSERT_PRODUCT = "InsertProduct";
   String DELETE_PRODUCT = "DeleteProduct";
   String SELECT_PRODUCT_ID_BY_PCNAME = "SelectProductIdByPCName";
}
