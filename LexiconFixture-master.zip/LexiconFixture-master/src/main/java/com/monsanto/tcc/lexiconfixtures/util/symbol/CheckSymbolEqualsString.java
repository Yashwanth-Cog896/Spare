package com.monsanto.tcc.lexiconfixtures.util.symbol;

/**
 * User: pjberry
 * Date: Jul 12, 2007
 * Time: 2:45:56 PM
 */
public class CheckSymbolEqualsString
   extends SymbolAcceptingColumnFixture
{
   public String symbolValue;
   public String stringValue;

   public boolean equal() {
      return stringValue.equals(symbolValue);
   }
}
