package com.monsanto.tcc.lexiconfixtures.data.midas.parentage;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreDelete;
import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Dec 4, 2006
 * Time: 5:32:45 PM
 * To change this template use File | Settings | File Templates.
 */
public class RemoveParentage
   extends SymbolAcceptingColumnFixture
{
   public Long parentageId;

   public boolean removed()
      throws WrappingException
   {
      MaterialParentageDelete dataMod = new MaterialParentageDelete();
      return dataMod.performDelete() == 1;
   }

   class MaterialParentageDelete
      extends AbstractPersistentStoreDelete
   {
      protected String getSQL() throws WrappingException {
         return new SQLPropFile(MidasParentageFixtureSQL.class).getSQL(MidasParentageFixtureSQL.DELETE_PARENTAGE);
      }
      protected Object[] getBindVariables() throws WrappingException {
         return new Object[] { parentageId };
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new MidasConnectionFactoryProperties();
      }
   }
}
