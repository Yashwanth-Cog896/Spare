package com.monsanto.tcc.lexiconfixtures.data.lexicon.country;

import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.EmptyResultSetException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetSingleResult;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Apr 23, 2007
 * Time: 4:54:41 PM
 * To change this template use File | Settings | File Templates.
 */
public class CheckLexiconCountry
   extends SymbolAcceptingColumnFixture
{
   public String countryAbbr;
   public String countryName;
   public String isoCode;
   public String unCode;

   public boolean exists()
      throws WrappingException
   {
      LexiconConnectionFactory connectionFactory = new LexiconConnectionFactory();
      PersistentStoreConnection conn = connectionFactory.getConnection();
      try {
         return matchingCountries(conn) == 1;
      }
      finally {
         conn.close();
      }
   }

   private int matchingCountries(PersistentStoreConnection conn)
      throws WrappingException
   {
      PersistentStoreStatement statement = conn.prepareStatement(getSQL());
      try {
         statement.setParam(1, countryAbbr);
         statement.setParam(2, countryName);
         statement.setParam(3, isoCode);
         statement.setParam(4, unCode);
         PersistentStoreResultSetSingleResult result = statement.executeQuery().getSingleResult();
         return result.getInt(1);
      }
      catch (EmptyResultSetException e) {
         return 0;
      } finally {
         statement.close();
      }
   }

   private String getSQL() {
      return
         "     SELECT count(country_abbr)" +
         "       FROM Lexicon.Country C" +
         "      WHERE C.country_abbr = ?" +
         "        AND C.country_name = ?" +
         "        AND C.iso_code = ?" +
         "        AND c.un_code = ?";
   }
}