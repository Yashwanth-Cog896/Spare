package com.monsanto.tcc.lexiconfixtures.data.lexicon.productflowcriteria;

import com.monsanto.tcc.lexiconcommon.service.artemis.productflow.ProductFlowCriteria;
import com.monsanto.tcc.lexiconcommon.service.artemis.productflow.ProductFlowCriterion;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingRowFixture;

/**
 * nbwald - Mar 17, 2008 6:09:06 PM
 */
public class CheckSapSubscriptionCriteria
   extends SymbolAcceptingRowFixture
{
   public Object[] query()
      throws Exception
   {
      ProductFlowCriteria criteria = ProductFlowCriteriaTestTool.findCriteria();
      return createResults(criteria.getCriterions());
   }

   private Result[] createResults(ProductFlowCriterion[] criterions) {
      Result[] results = new Result[criterions.length];
      for (int i = 0; i < criterions.length; i++) {
         results[i] = new Result(criterions[i]);
      }
      return results;
   }

   public Class getTargetClass() {
      return Result.class;
   }

   public class Result
   {
      public String cropPubkey;
      public String countryPubkey;
      public String stagePubkey;

      public Result(ProductFlowCriterion criterion) {
         this.cropPubkey = criterion.getCropPubkey();
         this.countryPubkey = criterion.getCountryPubkey();
         this.stagePubkey = criterion.getStagePubkey();
      }
   }
}
