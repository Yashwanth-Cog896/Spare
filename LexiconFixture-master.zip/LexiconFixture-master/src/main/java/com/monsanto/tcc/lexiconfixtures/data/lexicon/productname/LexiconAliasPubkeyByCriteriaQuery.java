package com.monsanto.tcc.lexiconfixtures.data.lexicon.productname;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jun 15, 2007
 * Time: 9:52:13 AM
 */
public class LexiconAliasPubkeyByCriteriaQuery
   extends AbstractPersistentStoreSingleResultQuery
{
   private final String precomlName;
   private final String countryName;
   private final String brandName;

   public LexiconAliasPubkeyByCriteriaQuery(final String precomlName, final String countryName,
      final String brandName)
   {
      this.precomlName = precomlName;
      this.countryName = StringUtils.toUpperCaseNull(countryName);
      this.brandName = StringUtils.toUpperCaseNull(brandName);
   }
   public String getPubkey() throws WrappingException {
      return (String)super.execute();
   }
   protected Object createObjectFromRow(PersistentStoreResultSetRow row) throws WrappingException {
      return row.getString(1);
   }
   protected String getSQL()
      throws WrappingException
   {
      return new SQLPropFile(LexiconProductNameFixtureSQL.class).
         getSQL(LexiconProductNameFixtureSQL.SELECT_PRODUCT_NAME_PUBKEY);
   }
   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { precomlName, countryName, brandName };
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
}
