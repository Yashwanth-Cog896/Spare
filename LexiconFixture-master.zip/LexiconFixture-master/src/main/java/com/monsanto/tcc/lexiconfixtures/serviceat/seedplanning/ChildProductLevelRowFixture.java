package com.monsanto.tcc.lexiconfixtures.serviceat.seedplanning;

import com.monsanto.tcc.lexiconcommon.service.ProductParentGermplasmDocTags;
import com.monsanto.tcc.lexiconcommon.xml.LexiconXPathSelector;
import com.monsanto.tcc.lexiconcommon.xml.SingleNamespaceContext;
import fit.RowFixture;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Feb 14, 2007
 * Time: 7:33:37 AM
 * To change this template use File | Settings | File Templates.
 */
public class ChildProductLevelRowFixture
   extends AbstractChildProductRowFixture
{
   public ChildProductLevelRowFixture(Document responseDocument) {
      super(responseDocument);
   }

   protected Object[] query(List<Node> childProductNodes)
   {
      List<ChildProductLevelAdapter> childProductLevels = new ArrayList<ChildProductLevelAdapter>();
      for (Node childProductNode : childProductNodes) {
         childProductLevels.add( new ChildProductLevelAdapter(childProductNode) );
      }
      return childProductLevels.toArray();
   }

   public Class getTargetClass() {
      return ChildProductLevelAdapter.class;
   }
}
