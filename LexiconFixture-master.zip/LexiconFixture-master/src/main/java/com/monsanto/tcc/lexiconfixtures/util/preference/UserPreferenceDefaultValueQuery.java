package com.monsanto.tcc.lexiconfixtures.util.preference;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.tcc.lexiconfixtures.util.UserHelper;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jul 2, 2007
 * Time: 2:36:21 PM
 */
class UserPreferenceDefaultValueQuery
   extends AbstractPersistentStoreSingleResultQuery
{
   private final String prefName;
   public UserPreferenceDefaultValueQuery(String prefName) {
      this.prefName = prefName;
   }
   public String getDefaultValue() throws WrappingException {
      return (String)super.execute();
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row) throws WrappingException {
      return row.getString(1);
   }
   protected Object[] getBindVariables() throws WrappingException {
      return new Object[]  {UserHelper.getCurrentUserLoginId(), prefName };
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
   protected String getSQL()
      throws WrappingException
   {
      return "SELECT default_value " +
             "  FROM Lexicon.User_Preference " +
             " WHERE user_login_id = ? AND  preference_definition_name = ?";
   }
}
