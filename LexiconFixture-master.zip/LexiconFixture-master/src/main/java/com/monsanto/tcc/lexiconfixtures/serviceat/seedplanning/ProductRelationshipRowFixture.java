package com.monsanto.tcc.lexiconfixtures.serviceat.seedplanning;

import com.monsanto.tcc.lexiconcommon.service.ProductParentGermplasmDocTags;
import com.monsanto.XMLUtil.DOMUtil;
import fit.RowFixture;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Feb 13, 2007
 * Time: 5:03:00 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProductRelationshipRowFixture
   extends RowFixture
{
   private Document responseDocument;

   public ProductRelationshipRowFixture(Document responseDocument) {
      this.responseDocument = responseDocument;
   }

   public Object[] query()
      throws Exception
   {
      List productRelationshipList = new ArrayList();
      Node[] nodes = DOMUtil.getChildren(responseDocument.getDocumentElement(), ProductParentGermplasmDocTags.PRODUCT_RELATIONSHIP_ELEM_NAME);
      for (int i = 0; i < nodes.length; i++) {
         productRelationshipList.add(buildAdapter(nodes[i]));
      }
      return productRelationshipList.toArray();
   }

   public Class getTargetClass() {
      return ProductRelationshipAdapter.class;
   }

   private ProductRelationshipAdapter buildAdapter(Node node) {
      Element elem = (Element) node;
      String pubkey = DOMUtil.getAttribute(elem, ProductParentGermplasmDocTags.PUBKEY_ATTR_NAME);
      String manfName = DOMUtil.getChildValue(elem, ProductParentGermplasmDocTags.MANF_NAME_ELEM_NAME);
      return new ProductRelationshipAdapter(pubkey, manfName);
   }

   public class ProductRelationshipAdapter
   {
      public String productRelationshipPubkey;
      public String manufacturingName;

      public ProductRelationshipAdapter(String productPubkey, String manufacturingName) {
         this.productRelationshipPubkey = productPubkey;
         this.manufacturingName = manufacturingName;
      }
   }
}
