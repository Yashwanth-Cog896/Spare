/*
	 BusinessAccountAdaptor was created on Jun 4, 2008 using Monsanto 
	 resources and is the sole property of Monsanto.  Any duplication of the 
	 code and/or logic is a direct infringement of Monsanto's copyright.
	*/
package com.monsanto.tcc.lexiconfixtures.serviceat.businessaccount;

import com.monsanto.tps.lexicon.account.BusinessAccount;
import com.monsanto.tps.lexicon.contact.AddressRecord;

/**
 * Filename:    $RCSfile: BusinessAccountAdaptor.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: nbwald $    	 On:	$Date: 2008-06-30 21:40:55 $
 *
 * @author MMR
 * @version $Revision: 1.2 $
 */
public class BusinessAccountAdaptor {
    public String accountID;
    public String companyName;
    public String phoneNumber;
    public String addressId;
    public String line1;
    public String line2;
    public String line3;
    public String city;
    public String county;
    public String state;
    public String postalCode;
    public String country;
    public String addressType;

    public BusinessAccountAdaptor(BusinessAccount businessAccount, AddressRecord addressRecord) {
        accountID = businessAccount.getAccountID();
        companyName = businessAccount.getCompanyName();
        phoneNumber = businessAccount.getPhone().getNumber();
        loadAddress(addressRecord);
    }

    private void loadAddress(AddressRecord addressRecord) {
        addressId = addressRecord.getAddressId();
        addressType = addressRecord.getAddressType();
        line1 = addressRecord.getAddress().getLine1();
        line2 = addressRecord.getAddress().getLine2();
        line3 = addressRecord.getAddress().getLine3();
        postalCode = addressRecord.getAddress().getPostalCode();
        city = addressRecord.getAddress().getCity();
        county = addressRecord.getAddress().getCounty();
        country = addressRecord.getAddress().getCountry();
        state = addressRecord.getAddress().getState();
    }
}