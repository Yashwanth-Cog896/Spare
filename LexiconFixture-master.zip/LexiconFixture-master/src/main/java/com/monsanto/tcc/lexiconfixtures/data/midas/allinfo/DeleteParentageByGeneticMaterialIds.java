package com.monsanto.tcc.lexiconfixtures.data.midas.allinfo;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Mar 16, 2007
 * Time: 3:30:09 PM
 * To change this template use File | Settings | File Templates.
 */
public class DeleteParentageByGeneticMaterialIds
{
   private final String sql = "DELETE FROM Midas.parentage P WHERE (P.genetic_material_id = ?) OR (P.parent_genetic_material_id = ?)";

   public int deleteParentage(PersistentStoreConnection conn, Long[] geneticMaterialIds)
      throws WrappingException
   {
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         int numDeleted = 0;
         for (int i = 0; i < geneticMaterialIds.length; i++) {
            numDeleted += deleteRecord(stmt,  geneticMaterialIds[i]);
         }
         return numDeleted;
      }
      finally {
         stmt.close();
      }
   }

   private int deleteRecord(PersistentStoreStatement stmt, Long geneticMaterialId)
      throws WrappingException
   {
      stmt.setParam(1, geneticMaterialId);
      stmt.setParam(2, geneticMaterialId);
      return stmt.executeDelete();
   }
}
