package com.monsanto.tcc.lexiconfixtures.data.midas.productname;

import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Dec 14, 2006
 * Time: 3:25:01 PM
 */
public class CheckMidasProductName
   extends SymbolAcceptingColumnFixture
{
   public String precomlName;
   public String name;
   public String brand;
   public String country;
   public boolean refActive;
   public String crop = "VALUE NOT SET";

   public void reset()
      throws Exception
   {
      super.reset();
      precomlName = null;
      name = null;
      brand = null;
      country = null;
      refActive = false;
      crop = "VALUE NOT USED IN CHECKING";
   }

   public boolean exists() throws WrappingException {
      if ("VALUE NOT USED IN CHECKING".equals(crop)) {
         return new MidasProductNameExistsByPCNameNameBrandCountryRefactiveQuery(precomlName, name, brand, country, refActive).entityExists();
      } else {
         return new MidasProductNameExistsByPCNameNameBrandCountryRefactiveCropQuery(precomlName, name, brand, country, refActive, crop).entityExists();
      }
   }
}
