package com.monsanto.tcc.lexiconfixtures.util;

import com.monsanto.tcc.lexiconcommon.exception.RuntimeWrappingException;
import fit.ColumnFixture;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

/**
 * nbwald - Mar 24, 2008 11:59:45 AM
 */
public class ColumnFixtureResetter
{
   public static void reset(ColumnFixture columnFixture) {
      setAllPublicFieldsToNull(columnFixture, columnFixture.getClass().getDeclaredFields());
   }

   private static void setAllPublicFieldsToNull(ColumnFixture columnFixture, Field[] fields) {
      for (Field field : fields) {
         setPublicFieldToNull(columnFixture, field);
      }
   }

   private static void setPublicFieldToNull(ColumnFixture columnFixture, Field field) {
      int fieldModifiers = field.getModifiers();
      if(Modifier.isPublic(fieldModifiers)) {
         setFieldToNull(columnFixture, field);
      }
   }

   private static void setFieldToNull(ColumnFixture columnFixture, Field field) {
      for (TypeResetter typeResetter : getTypeResetters()) {
         if(field.getType().getName().matches(typeResetter.getTypeMatch())) {
            typeResetter.resetSafely(field, columnFixture);
            break;
         }
      }
   }

   private static TypeResetter[] getTypeResetters() {
      return new TypeResetter[] {
         new LongTypeResetter(),
         new BooleanTypeResetter(),
         new ObjectTypeResetter()
      };
   }

   private static abstract class TypeResetter
   {
      abstract String getTypeMatch();

      abstract void reset(Field field, Object instance)
         throws IllegalAccessException;

      void resetSafely(Field field, Object instance) {
         try {
            reset(field, instance);
         }
         catch (IllegalAccessException e) {
            throw new RuntimeWrappingException(e);
         }
      }
   }

   private static class LongTypeResetter
      extends TypeResetter
   {
      String getTypeMatch() {
         return "long";
      }

      void reset(Field field, Object instance)
         throws IllegalAccessException
      {
         field.setLong(instance, 0);
      }
   }

   private static class BooleanTypeResetter
      extends TypeResetter
   {
      public String getTypeMatch() {
         return "boolean";
      }

      void reset(Field field, Object instance)
         throws IllegalAccessException
      {
         field.setBoolean(instance, false);
      }
   }

   private static class ObjectTypeResetter
      extends TypeResetter
   {
      String getTypeMatch() {
         return ".*";
      }

      void reset(Field field, Object instance)
         throws IllegalAccessException
      {
         field.set(instance, null);
      }
   }
}
