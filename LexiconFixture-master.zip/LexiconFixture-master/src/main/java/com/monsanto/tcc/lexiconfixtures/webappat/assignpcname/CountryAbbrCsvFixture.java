/*
 CsvFixture was created on Mar 15, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.webappat.assignpcname;

import com.monsanto.Util.StringUtils;
import fitlibrary.ArrayFixture;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Transformer;
import java.util.Arrays;
import java.util.Collection;

/**
 * nbwald Mar 15, 2007 10:41:43 AM
 */
public class CountryAbbrCsvFixture
   extends ArrayFixture
{
   public CountryAbbrCsvFixture(String csv) {
      String[] values = StringUtils.splitCsv(csv, false);
      Collection countryAbbrs = CollectionUtils.collect(Arrays.asList(values), new AbbrToCountryValueTransformer());
      setActualCollection(countryAbbrs);
   }

   private class AbbrToCountryValueTransformer
      implements Transformer
   {
      public Object transform(Object object) {
         String countryAbbr = (String) object;
         return new CountryValue(countryAbbr);
      }
   }
}