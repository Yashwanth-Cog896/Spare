/*
 CheckExcelFileFixture was created on Oct 12, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.webappat.excel;

import com.monsanto.tcc.lexiconcommon.file.excel.ExcelReader;
import com.monsanto.tcc.lexiconfixtures.webappat.productaliasreport.ExcelSpreadSheetFixture;
import java.io.FileInputStream;
import java.io.IOException;

/**
 * nbwald Oct 12, 2007 11:35:22 AM
 */
public class CheckExcelFileFixture
   extends ExcelSpreadSheetFixture
{
   public CheckExcelFileFixture()
      throws IOException
   {
      super(new ExcelReader(new FileInputStream(TestExcelFile.getTestExcelFile())));
   }
}