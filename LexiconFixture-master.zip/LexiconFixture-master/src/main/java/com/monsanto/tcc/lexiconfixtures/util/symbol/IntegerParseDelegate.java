/*
 IntegerParseDelegate was created on Nov 7, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.util.symbol;

/**
 * nbwald Nov 7, 2007 1:05:06 PM
 */
public class IntegerParseDelegate
   extends SymbolProcessingParseDelagate
{
   public Integer parse(String s) {
      return (Integer)baseParse(s);
   }

   protected Object createObjectFromSymbolValue(Object symbolValue) {
      return new Integer(symbolValue.toString());
   }

   protected Object createObjectFromString(String s) {
      return new Integer(s);
   }
}