package com.monsanto.tcc.lexiconfixtures.data.lexicon.productname;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.test.LexiconTestTools;
import com.monsanto.tcc.lexiconcommon.db.audit.LexiconAuditor;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.dataservices.EmptyResultSetException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.dataservices.PersistentStoreStatement;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Apr 12, 2007
 * Time: 1:29:35 PM
 * To change this template use File | Settings | File Templates.
 */
public class AddStagesToProduct
   extends SymbolAcceptingColumnFixture
{
   public String precomlName;
   public int numberOfStages;

   private SQLPropFile sqlPropFile = new SQLPropFile(LexiconProductNameFixtureSQL.class);
   private CountrySelect countrySelect = new CountrySelect();

   public boolean created() throws WrappingException
   {
      LexiconConnectionFactory connectionFactory = new LexiconConnectionFactory();
      PersistentStoreConnection conn = connectionFactory.getConnection();
      LexiconAuditor lexiconAuditor = LexiconTestTools.FITNESSE_TEST_AUDITOR;
      lexiconAuditor.initializeStaging(conn);
      try {
         return createStages(conn);
      }
      finally {
         lexiconAuditor.removeStaging(conn);
         conn.close();
      }
   }

   private boolean createStages(PersistentStoreConnection conn) throws WrappingException
   {
      int countryCount = countrySelect.getCountryCount(conn);
      if (numberOfStages > countryCount) {
         throw new WrappingException(new IOException("Number of Stages: " + numberOfStages + " exceeds total number of existing countries: " + countryCount));
      }
      else {
         int numInserted = 0;
         String[] countryAbbrs = countrySelect.getFirstNCountryAbbrs(conn, numberOfStages);
         for (int i = 0; i < numberOfStages; i ++) {
            numInserted += insertFakeData(conn, countryAbbrs[i]);
         }
         return numInserted == numberOfStages;
      }
   }

   private int insertFakeData(PersistentStoreConnection conn, String countryAbbr)
      throws WrappingException
   {
      String sql = sqlPropFile.getSQL(LexiconProductNameFixtureSQL.ADD_STAGE_TO_PRODUCT);
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         bindInsertVariables(stmt, countryAbbr);
         return stmt.executeInsert();
      }
      finally {
         stmt.close();
      }
   }

   private void bindInsertVariables(PersistentStoreStatement stmt, String countryAbbr)
      throws WrappingException
   {
      stmt.setParam(1, StringUtils.toUpperCaseNull(StringUtils.trimNullable(precomlName)));
      stmt.setParam(2, countryAbbr);
      stmt.setParam(3, "MONSANTO");
      stmt.setParam(4, "PS1");
   }

   class CountrySelect
   {
      public String[] getFirstNCountryAbbrs(PersistentStoreConnection conn, int count) throws WrappingException
      {
         List abbrs = new LinkedList();
         String sql = sqlPropFile.getSQL(LexiconProductNameFixtureSQL.SELECT_FIRST_N_COUNTRY_ABBRS);
         PersistentStoreStatement stmt = conn.prepareStatement(sql);
         try {
            bindSelectVariables(stmt, count);
            PersistentStoreResultSetFwdIterator iterator = stmt.executeQuery().getForwardIterator();
            while (iterator.next()) {
               abbrs.add(iterator.getString(1));
            }
         }
         finally {
            stmt.close();
         }
         return (String[]) abbrs.toArray(new String[abbrs.size()]);
      }

      private void bindSelectVariables(PersistentStoreStatement stmt, int count) throws WrappingException
      {
         stmt.setParam(1, count);
      }

      public int getCountryCount(PersistentStoreConnection conn) throws WrappingException
      {
         String sql = sqlPropFile.getSQL(LexiconProductNameFixtureSQL.SELECT_COUNTRY_COUNT);
         PersistentStoreStatement stmt = conn.prepareStatement(sql);
         try {
            PersistentStoreResultSetRow row = stmt.executeQuery().getSingleResult();
            return row.getInt(1);
         }
         catch (EmptyResultSetException e) {
            return 0;
         } finally {
            stmt.close();
         }
      }
   }
}
