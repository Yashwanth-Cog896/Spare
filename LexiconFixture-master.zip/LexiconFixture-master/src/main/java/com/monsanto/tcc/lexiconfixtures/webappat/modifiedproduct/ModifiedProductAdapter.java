package com.monsanto.tcc.lexiconfixtures.webappat.modifiedproduct;

import com.monsanto.tps.lexiconpos.product.auditsearch.modified.search.model.ModifiedProduct;

import java.util.Date;

/**
 * nbwald - Sep 15, 2008 6:33:40 PM
 */
public class ModifiedProductAdapter
{
   public String productPubkey;
   public String precomlName;
   public String manfName;
   public String baseManfName;
   public String cropPubkey;
   public boolean logicalDeleteFlag;
   public String startTime;
   public String endTime;

   public ModifiedProductAdapter(ModifiedProduct modifiedProduct, Date start, Date end) {
      this.productPubkey = modifiedProduct.getProductPublicKey();
      this.precomlName = modifiedProduct.getPrecommercialName();
      this.manfName = modifiedProduct.getManufacturingName();
      this.baseManfName = modifiedProduct.getBaseManufacturingName();
      this.cropPubkey = modifiedProduct.getCropPublicKey();
      this.logicalDeleteFlag = modifiedProduct.isLogicallyDeleted();
      DatabaseDate databaseDate = new DatabaseDate();
      this.startTime = databaseDate.render(start);
      this.endTime = databaseDate.render(end);
   }
}
