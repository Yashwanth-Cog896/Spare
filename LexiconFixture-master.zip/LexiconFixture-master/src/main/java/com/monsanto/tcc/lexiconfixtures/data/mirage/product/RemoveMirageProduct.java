package com.monsanto.tcc.lexiconfixtures.data.mirage.product;

import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 7, 2006
 * Time: 5:50:56 PM
 * To change this template use File | Settings | File Templates.
 */
public class RemoveMirageProduct
   extends SymbolAcceptingColumnFixture
{
   public Long productId;
   public String productName;
   public String company;
   public String country;
   public String bayerCode;

   public boolean removed()
      throws WrappingException
   {
      Long productId = getProductId();
      RemoveMirageProductById removeById = new RemoveMirageProductById(productId);
      return removeById.remove() == 1;
   }

   private Long getProductId()
      throws WrappingException
   {
      return productId == null ? getProductIdByAttributes() : productId;
   }

   private Long getProductIdByAttributes()
      throws WrappingException
   {
      MirageProductIdLookup lookup = new MirageProductIdLookup(productName, company, country, bayerCode);
      return lookup.getProductId();
   }
}