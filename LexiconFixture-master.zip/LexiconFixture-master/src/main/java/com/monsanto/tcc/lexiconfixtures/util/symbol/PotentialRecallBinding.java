package com.monsanto.tcc.lexiconfixtures.util.symbol;

import fit.Binding;
import fit.Fixture;
import fit.Parse;
import fit.exception.FitFailureException;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jun 28, 2007
 * Time: 1:52:22 PM
 */
class PotentialRecallBinding
   extends Binding
{
   public final SetBinding fallback;

   public PotentialRecallBinding(SetBinding fallback) {
      this.fallback = fallback;
      this.adapter = fallback.adapter;
   }

   public void doCell(Fixture fixture, Parse cell)
      throws Throwable
   {
      String text = cell.text();
      if (text.startsWith("@")) {
         String value = (String)Fixture.getSymbol(text);
         if(value == null) {
            fixture.exception(cell, new FitFailureException("No such symbol: " + text));
         }
         else {
            adapter.set(adapter.parse(value));
         }
      }
      else {
         fallback.doCell(fixture, cell);
      }
   }
}
