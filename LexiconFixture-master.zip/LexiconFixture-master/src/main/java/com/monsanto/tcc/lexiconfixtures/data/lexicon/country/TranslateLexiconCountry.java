package com.monsanto.tcc.lexiconfixtures.data.lexicon.country;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * nbwald - Mar 17, 2008 5:39:15 PM
 */
public class TranslateLexiconCountry
   extends SymbolAcceptingColumnFixture
{
   public String countryName;

   public String countryPubkey()
      throws WrappingException
   {
      CountryPubkeyFromNameQuery query = new CountryPubkeyFromNameQuery();
      return query.getPubkey();
   }

   private class CountryPubkeyFromNameQuery
      extends AbstractPersistentStoreSingleResultQuery
   {
      private String  getPubkey()
         throws WrappingException
      {
         return (String) execute();
      }

      protected Object createObjectFromRow(PersistentStoreResultSetRow row)
         throws WrappingException
      {
         return row.getString(1);
      }

      protected String getSQL()
         throws WrappingException
      {
         return "SELECT C.country_pubkey FROM Lexicon.Country C WHERE UPPER(C.country_name) = UPPER(?)";
      }

      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[] {countryName};
      }

      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new LexiconConnectionFactoryProperties();
      }
   }
}
