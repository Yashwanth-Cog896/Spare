package com.monsanto.tcc.lexiconfixtures.data.lexicon.eventagencyalignment;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.dbdataservices.SQLUtil;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.ColumnFixtureResetter;
import com.monsanto.tcc.lexiconfixtures.util.LexiconDataFixtureInsert;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;

import java.util.Random;

/**
 * nbwald - Feb 16, 2009 12:54:40 PM
 */
public class CreateEventAgencyAlignment
   extends SymbolAcceptingColumnFixture
{
   public String eventAgencyPubkey;
   public String agencyAbbreviation;
   public String eventName;
   public String crop;
   public boolean regulated;
   public String deregEffectiveDate;
   public Long maxQuantity;

   @Override
   public void reset()
      throws Exception
   {
      ColumnFixtureResetter.reset(this);
   }

   public boolean created()
      throws WrappingException
   {
      return new EventAgencyAlignmentInsert().performInsert() == 1;
   }

   private class EventAgencyAlignmentInsert
      extends LexiconDataFixtureInsert
   {
      @Override
      protected String getSQL()
         throws WrappingException
      {
         return "INSERT INTO Lexicon.Event_Agency_Alignment " +
            "(EVENT_AGENCY_ALIGNMENT_ID, EVENT_AGENCY_ALIGNMENT_PUBKEY, EVENT, CROP_ID, AGENCY_ID, IS_REGULATED, DEREGULATED_EFFECTIVE_DATE, MAX_QUANTITY) " +
            "VALUES " +
            "(?, ?, ?, (SELECT crop_id FROM Lexicon.Crop WHERE UPPER(crop_name) = UPPER(?)), (SELECT agency_id FROM Lexicon.Agency WHERE agency_abbr = ?), ?, ?, ?)";
      }

      @Override
      protected Object[] getBindVariables()
         throws WrappingException
      {
         throw new RuntimeException("Shouldn't be here because we override setBindVariables.");
      }

      @Override
      protected void setBindVariables(PersistentStoreStatement statement)
         throws WrappingException
      {
         statement.setParam(1, -new Random().nextLong());
         statement.setParam(2, eventAgencyPubkey);
         statement.setParam(3, eventName);
         statement.setParam(4, crop);
         statement.setParam(5, agencyAbbreviation);
         statement.setParam(6, SQLUtil.booleanToString(regulated));
         statement.setParam(7, DeregulationEffectiveDate.asDate(deregEffectiveDate));
         statement.setParam(8, maxQuantity);
      }

      @Override
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new LexiconConnectionFactoryProperties();
      }
   }
}
