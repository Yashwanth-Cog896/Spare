package com.monsanto.tcc.lexiconfixtures.data.midas.productname;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreEntityExistsQuery;
import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * User: pjberry
 * Date: Sep 18, 2007
 * Time: 10:25:13 AM
 */
public class MidasProductNameExistsByPCNameNameBrandCountryRefactiveCropQuery
   extends AbstractPersistentStoreEntityExistsQuery
{
    private final String precomlName;
      private final String name;
      private final String brand;
      private final String country;
      private final String refActive;
      private final String crop;

      public MidasProductNameExistsByPCNameNameBrandCountryRefactiveCropQuery(
         String precomlName,
         String name,
         String brand,
         String country,
         boolean refActive,
         String crop)
      {
         this.precomlName = precomlName;
         this.name = name;
         this.brand = brand;
         this.country = country;
         this.refActive = refActive ? "T" : "F";
         this.crop = crop;
      }

      protected String getSQL()
         throws WrappingException
      {
         return new SQLPropFile(MidasProductNameFixtureSQL.class).getSQL(
         MidasProductNameFixtureSQL.CHECK_PRODUCT_NAME_EXISTS_BY_PCNAME_NAME_BRAND_COUNTRY_REF_ACTIVE_CROP_QUERY);
      }

      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[] {precomlName, name, brand, country, refActive, crop};
      }

      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
          return new MidasConnectionFactoryProperties();
      }
}
