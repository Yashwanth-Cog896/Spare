package com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.dataservices.PersistentStoreStatement;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Mar 19, 2007
 * Time: 10:01:38 AM
 * To change this template use File | Settings | File Templates.
 */
public class MonsantoProductRelationshipIdByProductId
{
   private final String sql = "SELECT PRX.product_relationship_id FROM Lexicon.product_relationship_xref PRX WHERE PRX.product_id = ?";

   public Long[] getProductRelationshipIds(PersistentStoreConnection conn, Long productId)
      throws WrappingException
   {
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, productId);
         PersistentStoreResultSetFwdIterator results = stmt.executeQuery().getForwardIterator();
         return buildProductRelationshipIds(results);
      }
      finally {
         stmt.close();
      }
   }

   private Long[] buildProductRelationshipIds(PersistentStoreResultSetFwdIterator results)
      throws WrappingException
   {
      Set productRelationshipIds = new HashSet();
      while (results.next()) {
         productRelationshipIds.add( results.getLONG(1) );
      }
      return (Long[])productRelationshipIds.toArray(new Long[productRelationshipIds.size()]);
   }
}
