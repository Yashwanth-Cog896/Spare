package com.monsanto.tcc.lexiconfixtures.data.mirage.productmaturity;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconfixtures.data.factories.mirage.MirageConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.data.mirage.product.MirageProductIdLookup;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Jan 29, 2007
 * Time: 9:22:33 AM
 * To change this template use File | Settings | File Templates.
 */
public class CreateMirageProductMaturity
   extends SymbolAcceptingColumnFixture
{
   public String productName;
   public String company;
   public String bayerCode;
   public String country;
   public String maturityRating;

   private SQLPropFile sqlPropFile = new SQLPropFile(MirageProductMaturitySQL.class);

   public boolean created()
      throws WrappingException
   {
      MirageConnectionFactory connectionFactory = new MirageConnectionFactory();
      PersistentStoreConnection conn = connectionFactory.getConnection();
      try {
         int numInserted = insertFakeData(conn);
         return numInserted == 1;
      }
      finally {
         conn.close();
      }
   }

   private int insertFakeData(PersistentStoreConnection conn)
      throws WrappingException
   {
      String sql = sqlPropFile.getSQL(MirageProductMaturitySQL.INSERT_MATURITY);

      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, getProductIdByAttributes());
         stmt.setParam(2, new Double(maturityRating));
         return stmt.executeInsert();
      }
      finally {
         stmt.close();
      }
   }

   private Long getProductIdByAttributes()
      throws WrappingException
   {
      MirageProductIdLookup lookup = new MirageProductIdLookup(productName, company, country, bayerCode);
      return lookup.getProductId();
   }
}
