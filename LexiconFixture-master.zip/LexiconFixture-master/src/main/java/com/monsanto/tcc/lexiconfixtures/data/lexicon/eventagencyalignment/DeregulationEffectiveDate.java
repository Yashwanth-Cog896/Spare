package com.monsanto.tcc.lexiconfixtures.data.lexicon.eventagencyalignment;

import com.monsanto.tcc.lexiconcommon.exception.RuntimeWrappingException;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * nbwald - Feb 16, 2009 2:10:18 PM
 */
public class DeregulationEffectiveDate
{
   private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

   public static Date asDate(String textualRepresentation) {
      try {
         return textualRepresentation == null ? null : dateFormat.parse(textualRepresentation);
      }
      catch (ParseException e) {
         throw new RuntimeWrappingException(e);
      }
   }

   public static String asString(Date date) {
      return date == null ? null : dateFormat.format(date);
   }
}
