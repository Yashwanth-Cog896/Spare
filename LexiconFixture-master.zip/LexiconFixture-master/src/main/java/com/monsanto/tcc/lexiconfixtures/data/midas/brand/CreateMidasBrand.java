/*
 CreateMidasBrand was created on Apr 17, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.data.midas.brand;

import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * nbwald Apr 17, 2007 10:51:33 AM
 */
public class CreateMidasBrand
   extends SymbolAcceptingColumnFixture
{
   public long brandID;
   public String brandName;
   public String refActive;
   public String companyName;

   public boolean created()
      throws WrappingException {
      PersistentStoreConnection conn = new MidasConnectionFactory().getConnection();
      try {
         return createBrand(conn) == 1;
      }
      finally {
         conn.close();
      }
   }

   private int createBrand(PersistentStoreConnection conn)
      throws WrappingException
   {
      PersistentStoreStatement statement = conn.prepareStatement(getSQL());
      try {
         bindSQLParams(statement);
         return statement.executeInsert();
      }
      finally {
         statement.close();
      }
   }

   private void bindSQLParams(PersistentStoreStatement statement) throws WrappingException {
      statement.setParam(1, brandID);
      statement.setParam(2, brandName);
      statement.setParam(3, refActive);
      statement.setParam(4, companyName);
   }

   private String getSQL() {
      return "INSERT INTO Midas.Brand B " +
         "(brand_id, name, ref_active, company_id) " +
         "VALUES " +
         "(?, ?, ?, (SELECT CO.company_id FROM Midas.Company CO WHERE CO.name = ? AND rownum = 1))";
   }
}