package com.monsanto.tcc.lexiconfixtures.data.lexicon.productflowcriteria;

import com.monsanto.tcc.constellation.serviceconnection.DefaultXmlServiceConnectionInterpreter;
import com.monsanto.tcc.constellation.serviceconnection.StandaloneKerberosXmlServiceRequest;
import com.monsanto.tcc.constellation.serviceconnection.XmlServiceConnection;
import com.monsanto.tcc.lexiconcommon.pos.test.KerberosServiceTestCaseSetup;
import com.monsanto.tcc.lexiconcommon.service.artemis.LexiconArtemisServiceXmlSerializerProvider;
import com.monsanto.tcc.lexiconcommon.service.artemis.productflow.ProductFlowCriteria;
import com.monsanto.tcc.lexiconfixtures.serviceat.artemis.common.LexiconServiceUrlResolver;
import com.monsanto.services.domain.common.envelope.RequestEnvelope;
import com.monsanto.services.domain.common.envelope.RequestOperation;
import com.monsanto.services.domain.common.envelope.ResponseEnvelope;
import org.ietf.jgss.GSSException;

/**
 * nbwald - Mar 17, 2008 6:00:58 PM
 */
public class ProductFlowCriteriaTestTool
{
   public static ProductFlowCriteria findCriteria()
      throws Exception
   {
      ResponseEnvelope response = callService("FindProductFlowCriteria", null);
      return (ProductFlowCriteria) response.getFirst(ProductFlowCriteria.class);
   }

   public static void setCriteria(ProductFlowCriteria criteria)
      throws Exception
   {
      callService("SaveProductFlowCriteria", criteria);
   }

   public static void clearCriteria()
      throws Exception
   {
      setCriteria(new ProductFlowCriteria());
   }

   private static ResponseEnvelope callService(String operation, Object payload)
      throws Exception
   {
      setupKerberos();
      RequestEnvelope request = new RequestEnvelope(new RequestOperation(operation), payload);
      XmlServiceConnection conn =
         new XmlServiceConnection("Lex_LexiconArtemisServices", new LexiconServiceUrlResolver(),
            new DefaultXmlServiceConnectionInterpreter(new LexiconArtemisServiceXmlSerializerProvider().getXmlSerializer()),
            new StandaloneKerberosXmlServiceRequest());
      return (ResponseEnvelope) conn.call(request);
   }

   private static void setupKerberos()
      throws GSSException
   {
      KerberosServiceTestCaseSetup.setUp();
   }
}
