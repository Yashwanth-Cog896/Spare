/*
 GetCountryByUNCodeFixture was created on Nov 6, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.serviceat.artemis.country;

import com.monsanto.tcc.constellation.serviceconnection.DefaultXmlServiceConnectionInterpreter;
import com.monsanto.tcc.constellation.serviceconnection.ServiceCommunicationException;
import com.monsanto.tcc.constellation.serviceconnection.StandaloneKerberosXmlServiceRequest;
import com.monsanto.tcc.constellation.serviceconnection.XmlServiceConnection;
import com.monsanto.tcc.lexiconcommon.pos.test.KerberosServiceTestCaseSetup;
import com.monsanto.tcc.lexiconfixtures.serviceat.artemis.common.LexiconServiceUrlResolver;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingDoFixture;
import com.monsanto.services.client.geography.GeographyXmlSerializerProvider;
import com.monsanto.services.domain.common.CompositeObject;
import com.monsanto.services.domain.common.envelope.RequestEnvelope;
import com.monsanto.services.domain.common.envelope.RequestOperation;
import com.monsanto.services.domain.common.envelope.ResponseEnvelope;
import com.monsanto.services.domain.common.filter.BinaryExpression;
import com.monsanto.services.domain.common.filter.Filter;
import com.monsanto.services.domain.common.filter.operator.OperatorDirectory;
import com.monsanto.services.domain.geography.Country;
import com.monsanto.xmlserialization.XmlSerializer;
import fit.Fixture;
import fitlibrary.ArrayFixture;
import org.ietf.jgss.GSSException;

/**
 * nbwald Nov 6, 2007 4:15:39 PM
 */
public class GetCountryByUNCodeFixture
   extends SymbolAcceptingDoFixture
{
   private static final String OPERATION = "GetCountryByUNCode";
   private static final String SERVICES_GATEWAY = "Lex_Geography";

   private Country country;

   public void findCountryWith(String unCode)
      throws GSSException, ServiceCommunicationException
   {
      KerberosServiceTestCaseSetup.setUp();
      CompositeObject request = createRequest(unCode);
      ResponseEnvelope response = callService(request);
      this.country = parseResponse(response);
   }

   public boolean countryFound() {
      return country != null;
   }

   private Country parseResponse(ResponseEnvelope response) {
      return (Country) response.getFirst(Country.class);
   }

   public Fixture checkGetCountryByUNCodeServiceResults() {
      return new ArrayFixture(new Object[] {new ResponseAdapter(country)});
   }

   private ResponseEnvelope callService(CompositeObject request)
      throws ServiceCommunicationException
   {
      XmlServiceConnection conn =
         new XmlServiceConnection(SERVICES_GATEWAY, new LexiconServiceUrlResolver(),
         new DefaultXmlServiceConnectionInterpreter(getSerializer()),
         new StandaloneKerberosXmlServiceRequest());
      RequestEnvelope envelope = new RequestEnvelope(new RequestOperation(OPERATION), request);
      return (ResponseEnvelope)conn.call(envelope);
   }

   private CompositeObject createRequest(String unCode) {
      Filter filter = new Filter();
      filter.addExpression(new BinaryExpression(OperatorDirectory.EQUALS_OPERATOR.getRefId(), "UNCode", unCode));
      CompositeObject request = new CompositeObject();
      request.add(filter);
      return request;
   }

   private XmlSerializer getSerializer() {
      return new GeographyXmlSerializerProvider().getXmlSerializer();
   }
}