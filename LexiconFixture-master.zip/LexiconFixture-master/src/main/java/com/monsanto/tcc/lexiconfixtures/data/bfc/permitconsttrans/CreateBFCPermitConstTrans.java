package com.monsanto.tcc.lexiconfixtures.data.bfc.permitconsttrans;

import com.monsanto.tcc.lexiconcommon.db.test.BFCTestTools;
import com.monsanto.tcc.lexiconfixtures.data.factories.bfc.BFCConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;

/**
 * User: PJBERRY
 * Date: Aug 2, 2007
 * Time: 8:53:41 PM
 */
public class CreateBFCPermitConstTrans
   extends SymbolAcceptingColumnFixture
{
   public Long permitId;
   public String transCode;
   public String details;

   public boolean created()
      throws WrappingException
   {
      PersistentStoreConnection conn = new BFCConnectionFactory().getConnection();
      try {
         int numInserted = BFCTestTools.insertFakePermitConstTrans(permitId, transCode, details, conn);
         return numInserted == 1;
      }
      finally {
         conn.close();
      }
   }
}
