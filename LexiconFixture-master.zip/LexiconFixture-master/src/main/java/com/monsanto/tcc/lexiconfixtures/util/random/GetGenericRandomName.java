package com.monsanto.tcc.lexiconfixtures.util.random;

import com.monsanto.Util.StringUtils;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Apr 26, 2007
 * Time: 1:48:49 PM
 * To change this template use File | Settings | File Templates.
 */
public class GetGenericRandomName
   extends RandomValueColumnFixture
{
   public String prefix = "FT-";
   public int suffixLength;

   public String name() {
      return getPrefix() + getSuffix();
   }

   private String getPrefix() {
      return StringUtils.isNullOrEmpty(prefix) ? "" : prefix;
   }

   private int getSuffix() {
      if (suffixLength > 0) {
         redefineMinAndMaxValues();
      }
      return getIntValue();
   }

   private void redefineMinAndMaxValues()
   {
      minValue = (int) Math.pow(10, suffixLength -1);
      maxValue = (int) Math.pow(10, suffixLength) -1;
   }
}
