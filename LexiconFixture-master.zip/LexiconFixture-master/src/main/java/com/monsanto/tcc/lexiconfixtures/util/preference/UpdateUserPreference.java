package com.monsanto.tcc.lexiconfixtures.util.preference;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreUpdate;
import com.monsanto.tcc.lexiconfixtures.util.UserHelper;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jul 2, 2007
 * Time: 2:51:54 PM
 */
class UpdateUserPreference
   extends AbstractPersistentStoreUpdate
{
   private final String prefName;
   private final String defaultValue;

   public UpdateUserPreference(final String prefName, final String defaultValue) {
      this.prefName = prefName;
      this.defaultValue = defaultValue;
   }
   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { defaultValue, UserHelper.getCurrentUserLoginId(), prefName };
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
   protected String getSQL()
      throws WrappingException
   {
      return "UPDATE Lexicon.User_Preference SET default_value = ? " +
         "WHERE user_login_id = ? AND preference_definition_name = ?";
   }
}
