package com.monsanto.tcc.lexiconfixtures.data.mirage.product;

import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 27, 2006
 * Time: 1:00:13 PM
 * To change this template use File | Settings | File Templates.
 */
public class MirageProductTranslator
   extends SymbolAcceptingColumnFixture
{
   public String productName;
   public String company;
   public String country;

   public Long productId() throws WrappingException {
      return new MirageProductIdByCriteriaQuery(productName, company, country).getProductId();
   }
}

