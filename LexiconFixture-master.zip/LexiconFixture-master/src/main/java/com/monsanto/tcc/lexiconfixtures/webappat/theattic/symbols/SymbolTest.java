package com.monsanto.tcc.lexiconfixtures.webappat.theattic.symbols;

import com.monsanto.tcc.lexiconfixtures.util.symbol.LongParseDelagate;
import com.monsanto.tcc.lexiconfixtures.util.symbol.StringParseDelagate;
import fit.Fixture;
import fitlibrary.ArrayFixture;
import fitlibrary.DoFixture;
import fitlibrary.GridFixture;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Mar 29, 2007
 * Time: 6:10:23 PM
 * To change this template use File | Settings | File Templates.
 */
public class SymbolTest
   extends DoFixture
{
   private List rowFixtureModel = new ArrayList();
   private List arrayFixtureModel = new ArrayList();

   public SymbolTest() {
      registerParseDelegate(String.class, new StringParseDelagate());
      registerParseDelegate(Long.class, new LongParseDelagate());
   }

   public Fixture testColumnFixture() {
      return new SymbolTestColumnFixture();
   }

   public Fixture testRowFixture() {
      return new SymbolTestRowFixture(rowFixtureModel);
   }

   public Fixture testTableFixture() {
      return new SymbolTestTableFixture(rowFixtureModel);
   }

   public Fixture testArrayFixture() {
      return new ArrayFixture(arrayFixtureModel);
   }

   public Fixture testGridFixture() {
      return new GridFixture(getArrayFromList(rowFixtureModel));
   }

   private static Object[][] getArrayFromList(List fixtureModel) {
      Object[][] gridModel = new String[fixtureModel.size()][];
      for (int i = 0; i < fixtureModel.size(); i++) {
         TestRowFixtureModel rowModel = (TestRowFixtureModel)fixtureModel.get(i);
         gridModel[i] = rowModel.getAsArrayOfValues();
      }
      return gridModel;
   }

   public void idNameValue(Long id, String name, Long value) {
      rowFixtureModel.add(new TestRowFixtureModel(id, name, value));
      arrayFixtureModel.add(new TestArrayFixtureModel(id, name, value));
   }
}
