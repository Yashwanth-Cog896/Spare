package com.monsanto.tcc.lexiconfixtures.data.lexicon.agency;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.dbdataservices.SQLUtil;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconfixtures.util.LexiconDataFixtureInsert;
import com.monsanto.tcc.lexiconfixtures.util.random.GetRandomId;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.tcc.lexiconfixtures.data.lexicon.productname.LexiconProductNameFixtureSQL;

/**
 * nbwald - Dec 1, 2008 5:22:00 PM
 */
public class CreateAgency
   extends SymbolAcceptingColumnFixture
{
   public String publicKey;
   public String abbreviation;
   public String name;
   public String country;
   public String surfaceAreaUomCode;
   public boolean isActive;

   public boolean created()
      throws WrappingException
   {
      AgencyInsert insert = new AgencyInsert();
      return insert.performInsert() == 1;
   }

   private class AgencyInsert
      extends LexiconDataFixtureInsert
   {
      protected String getSQL()
         throws WrappingException
      {
         return
            "INSERT INTO Lexicon.Agency (agency_id, agency_pubkey, agency_abbr, agency_name, country_id, surface_area_uom_code, is_active) " +
            "VALUES (?, ?, ?, ?, (" + countryIdByAbbreviationSQL() + ") , ?, ?)";
      }

      private String countryIdByAbbreviationSQL()
         throws WrappingException
      {
         return new SQLPropFile(LexiconProductNameFixtureSQL.class).getSQL(LexiconProductNameFixtureSQL.COUNTRY_ID_BY_ABBR);
      }

      protected Object[] getBindVariables()
         throws WrappingException
      {
         long id = -new GetRandomId().value();
         return new Object[] { id , publicKey, abbreviation, name, StringUtils.toUpperCaseNull(country), surfaceAreaUomCode,  SQLUtil.booleanToString(isActive) };
      }

      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new LexiconConnectionFactoryProperties();
      }
   }
}
