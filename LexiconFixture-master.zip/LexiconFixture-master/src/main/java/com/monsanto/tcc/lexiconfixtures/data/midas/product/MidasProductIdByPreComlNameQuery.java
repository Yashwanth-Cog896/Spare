package com.monsanto.tcc.lexiconfixtures.data.midas.product;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Dec 15, 2006
 * Time: 3:01:56 PM
 * To change this template use File | Settings | File Templates.
 */
public class MidasProductIdByPreComlNameQuery
   extends AbstractPersistentStoreSingleResultQuery
{
   private String preComlName;

   public MidasProductIdByPreComlNameQuery(String midasPrecomlName) {
      this.preComlName = midasPrecomlName;
   }

   public Long getProductId() throws WrappingException {
      return (Long)execute();
   }
   protected Object createObjectFromRow(PersistentStoreResultSetRow row) throws WrappingException {
      return row.getLONG(1);
   }
   protected String getSQL() throws WrappingException {
      return new SQLPropFile(MidasProductFixtureSQL.class).getSQL(MidasProductFixtureSQL.SELECT_PRODUCT_ID_BY_PCNAME);
   }
   protected Object[] getBindVariables() throws WrappingException {
      return new Object[] { preComlName };
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MidasConnectionFactoryProperties();
   }
}
