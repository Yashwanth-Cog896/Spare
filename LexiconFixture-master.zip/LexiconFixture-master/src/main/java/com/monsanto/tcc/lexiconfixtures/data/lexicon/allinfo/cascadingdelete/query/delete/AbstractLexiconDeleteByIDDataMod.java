/*
 AbstractLexiconDeleteByIDDataMod was created on Jul 17, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo.cascadingdelete.query.delete;

import com.monsanto.tcc.lexiconfixtures.util.LexiconDataFixtureDelete;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald Jul 17, 2007 6:47:18 PM
 */
public abstract class AbstractLexiconDeleteByIDDataMod
   extends LexiconDataFixtureDelete
{
   private final long id;

   public AbstractLexiconDeleteByIDDataMod(long id) {
      this.id = id;
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { id };
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
}