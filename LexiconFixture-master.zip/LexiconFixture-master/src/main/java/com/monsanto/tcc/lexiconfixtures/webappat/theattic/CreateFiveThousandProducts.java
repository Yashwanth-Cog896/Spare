package com.monsanto.tcc.lexiconfixtures.webappat.theattic;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.lexiconfixtures.data.lexicon.product.CreateLexiconMonsantoProduct;
import com.monsanto.tcc.lexiconfixtures.data.lexicon.productname.CreateLexiconMonsantoProductName;
import fitlibrary.DoFixture;

/**
 * nbwald - Jul 31, 2009 2:34:23 PM
 */
public class CreateFiveThousandProducts
   extends DoFixture
{
   public boolean createLexiconProductStagesStartingWithId(int numberOfStages, long initialId)
      throws WrappingException
   {
      for (int i = 0; i < numberOfStages; i++) {
         long id = initialId - i;
         String sid = String.valueOf(id);
         createProduct(id, sid);
         createStage(id, sid);
      }
      return true;
   }

   private void createProduct(long id, String sid)
      throws WrappingException
   {
      CreateLexiconMonsantoProduct createProduct = new CreateLexiconMonsantoProduct();
      createProduct.productId = id;
      createProduct.productPubkey = sid;
      createProduct.preComlName = sid;
      createProduct.crop = "CORN";
      createProduct.logicalDelete = false;
      createProduct.created();
   }

   private void createStage(long id, String sid)
      throws WrappingException
   {
      CreateLexiconMonsantoProductName createProductStage = new CreateLexiconMonsantoProductName();
      createProductStage.productStageId = id;
      createProductStage.productStagePubkey = sid;
      createProductStage.productId = id;
      createProductStage.country = "USA";
      createProductStage.brand = "MONSANTO";
      createProductStage.stage = "PS1";
      createProductStage.commercialName = null;
      createProductStage.commercialMaturity = "100";  // Do this until I figure out how to get it to handle Double nicely...
      createProductStage.commercialTrait = "RR";
      createProductStage.active = true;
      createProductStage.logicalDelete = false;
      createProductStage.created();
   }
}
