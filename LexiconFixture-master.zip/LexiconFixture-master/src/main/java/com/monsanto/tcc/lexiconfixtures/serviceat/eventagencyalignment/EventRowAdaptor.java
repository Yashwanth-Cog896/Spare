package com.monsanto.tcc.lexiconfixtures.serviceat.eventagencyalignment;

import com.monsanto.Util.StringUtils;
import com.monsanto.tps.lexicon.event.EventComponent;
import com.monsanto.tps.lexicon.event.EventInfo;

/**
 * nbwald - Feb 26, 2009 2:03:28 PM
 */
public class EventRowAdaptor
{
   public String eventName;
   public String monNumber;
   public String crop;

   public EventRowAdaptor(EventInfo eventInfo) {
      StringBuilder monNumberBuilder = new StringBuilder();
      StringBuilder eventNameBuilder = new StringBuilder();
      if((eventInfo!=null)&&(eventInfo.getEventComponents()!=null)){
          for(EventComponent component: eventInfo.getEventComponents()){
             if(eventNameBuilder.length()>0){
                 eventNameBuilder.append(",");

             }
             eventNameBuilder.append(component.getEventName());
             if(!StringUtils.isNullOrEmpty(component.getMonNumber())){
                if(monNumberBuilder.length()>0){
                   monNumberBuilder.append(",");
                }
                monNumberBuilder.append(component.getMonNumber());
             }
          }
      }
      this.eventName = eventNameBuilder.toString();
      this.monNumber = monNumberBuilder.toString();
      this.crop = eventInfo.getCrop();
   }
}
