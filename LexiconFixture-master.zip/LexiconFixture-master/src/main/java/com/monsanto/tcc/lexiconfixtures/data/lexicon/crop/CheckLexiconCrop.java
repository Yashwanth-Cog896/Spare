package com.monsanto.tcc.lexiconfixtures.data.lexicon.crop;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreEntityExistsQuery;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dbdataservices.SQLUtil;

/**
 * User: pjberry
 * Date: Jul 12, 2007
 * Time: 5:57:56 PM
 */
public class CheckLexiconCrop
   extends SymbolAcceptingColumnFixture
{
   public String cropName;
   public boolean majorCrop;
   public boolean regulatoryCrop;


   public boolean exists()
      throws WrappingException
   {
      LexiconCropExistsQuery query = new LexiconCropExistsQuery();
      return query.entityExists();
   }

   private class LexiconCropExistsQuery
      extends AbstractPersistentStoreEntityExistsQuery
   {
      protected String getSQL()
         throws WrappingException
      {
         return "SELECT * FROM Lexicon.crop C WHERE C.crop_name = ? AND C.major_crop = ? and C.regulatory_crop = ?";
      }
      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[]{cropName, SQLUtil.booleanToString(majorCrop), SQLUtil.booleanToString(regulatoryCrop)};
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new LexiconConnectionFactoryProperties();
      }
   }
}
