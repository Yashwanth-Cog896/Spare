package com.monsanto.tcc.lexiconfixtures.webappat;

import fit.Fixture;

/**
 * Created by IntelliJ IDEA.
 * User: PJBERRY
 * Date: Apr 4, 2007
 * Time: 5:47:53 AM
 * To change this template use File | Settings | File Templates.
 */
public interface ScreenInteractionFixture
{
   public boolean connect()
      throws Exception;

   public boolean disconnect()
      throws Exception;

   public String title();

   public boolean clickWaitForPageToLoad(String thingToClick);

   public boolean click(String thingToClick)
      throws Exception;

   public boolean clickIcon(String icon);

   public boolean enterFor(String value, String locator)
      throws Exception;

   public boolean selectFor(String optionLocator, String selectLocator)
      throws Exception;

   public boolean clickFor(String value, String name);

   public String alert()
      throws Exception;

   public String fieldIs(String locator)
      throws Exception;

   public boolean fieldExists(String locator);

   public boolean fieldIsEditable(String locator);

   public void waitForPageToLoad();

   public void pauseSeconds(int seconds)
      throws Exception;

   public Fixture iconsIn(String locator);

   public Fixture optionsIn(String selectLocator);

   public Fixture errorsIn(String unorderedListLocator);

   public String rowIsColor(String htmlTableRowLocator);

   public Fixture notesIn(String unorderedListLocator);

   public boolean linkExists(String linkText);

   public boolean textExists(String text);

   public boolean clickLinkWithHeading(String link, String heading)
      throws Exception;

   public boolean saveApplicationRoles()
      throws Exception;

   public boolean restoreApplicationRoles()
      throws Exception;

   public boolean grantFullAccess()
      throws Exception;

   public Fixture setApplicationRole();
}
