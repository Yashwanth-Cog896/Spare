/*
 GetRandomAbbr was created on Apr 17, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.util.random;

/**
 * nbwald Apr 17, 2007 11:56:13 AM
 */
public class GetRandomAbbr
   extends RandomValueColumnFixture
{
   public String abbr() {
      return "@" + twoRandomDigits();
   }

   private String twoRandomDigits() {
      super.minValue = 10;
      super.maxValue = 99;
      return Integer.toString(getIntValue());
   }
}