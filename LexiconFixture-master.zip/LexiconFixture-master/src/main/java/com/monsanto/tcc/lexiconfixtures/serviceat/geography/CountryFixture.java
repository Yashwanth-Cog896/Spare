/*
	 CountryFixture was created on Jun 11, 2008 using Monsanto
	 resources and is the sole property of Monsanto.  Any duplication of the
	 code and/or logic is a direct infringement of Monsanto's copyright.
	*/
package com.monsanto.tcc.lexiconfixtures.serviceat.geography;

import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingRowFixture;
import com.monsanto.tps.lexicon.geography.country.Country;
import com.monsanto.tps.lexicon.geography.service.Countries;
import com.monsanto.tps.lexicon.geography.service.CountriesImpl;
import fit.Fixture;
import fitlibrary.DoFixture;
import org.ietf.jgss.GSSException;

/**
 * Filename:    $RCSfile: CountryFixture.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ggshiv $    	 On:	$Date: 2008-08-12 06:42:09 $
 *
 * @author MMR
 * @version $Revision: 1.8 $
 */
public class CountryFixture extends DoFixture {

   private Country[] countries;
   private String errorMessage;

   public boolean findCountriesWithCountryName(String countryName) throws Exception {
      try {
         countries = getClient().findCountries(countryName);
      } catch (IllegalArgumentException e) {
         errorMessage = e.getMessage();
      }
      return true;
   }

   public boolean findCountriesWithIsoCodes(String isoCodesCSV) throws Exception {
      try {
         countries = getClient().findCountries(isoCodesCSV.split(","));
      } catch (IllegalArgumentException e) {
         errorMessage = e.getMessage();
      }
      return true;
   }

   private Countries getClient() throws GSSException {
      return new CountriesImpl(new KerberosStandaloneCredential());
   }

   public int numberOfCountriesFound() {
      return countries == null ? 0 : countries.length;
   }

   public String errorMessage() {
      return errorMessage;
   }

   public Fixture checkResults() {
      return new SymbolAcceptingRowFixture() {
         public Class<?> getTargetClass() {
            return CountryResponseAdaptor.class;
         }

         public Object[] query()
                 throws Exception {
            return buildCountryResponseAdaptors();
         }
      };
   }

   private CountryResponseAdaptor[] buildCountryResponseAdaptors() {
      CountryResponseAdaptor[] responseAdaptors = new CountryResponseAdaptor[countries.length];
      for (int i = 0; i < countries.length; i++) {
         responseAdaptors[i] = new CountryResponseAdaptor(countries[i]);
      }
      return responseAdaptors;
   }

}
