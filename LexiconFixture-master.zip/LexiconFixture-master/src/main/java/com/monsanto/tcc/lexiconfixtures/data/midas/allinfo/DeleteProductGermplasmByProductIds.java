package com.monsanto.tcc.lexiconfixtures.data.midas.allinfo;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Mar 16, 2007
 * Time: 4:52:42 PM
 * To change this template use File | Settings | File Templates.
 */
public class DeleteProductGermplasmByProductIds
{
   private final String sql = "DELETE FROM Midas.product_germplasm PGP WHERE PGP.product_id = ?";

   public int deleteProductGermplasm(PersistentStoreConnection conn, Long[] productIds)
      throws WrappingException
   {
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         int numDeleted = 0;
         for (int i = 0; i < productIds.length; i++) {
            stmt.setParam(1, productIds[i]);
            numDeleted += stmt.executeDelete();
         }
         return numDeleted;
      }
      finally {
         stmt.close();
      }
   }
}
