package com.monsanto.tcc.lexiconfixtures.data.mirage.allinfo;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.data.factories.mirage.MirageConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreDelete;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Mar 19, 2007
 * Time: 3:07:02 PM
 * To change this template use File | Settings | File Templates.
 */
class DeleteProductMaturityByProductId
   extends AbstractPersistentStoreDelete
{
   private final Long productId;

   public DeleteProductMaturityByProductId(Long productId) {
      this.productId = productId;
   }

   protected String getSQL()
      throws WrappingException
   {
      return "DELETE FROM Mirage2.Seed_Products_Maturity SPM WHERE SPM.product_id = ? ";
   }
   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { productId };
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MirageConnectionFactoryProperties();
   }
}
