package com.monsanto.tcc.lexiconfixtures.data.mirage;

import com.monsanto.Util.StringUtils;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Dec 19, 2006
 * Time: 11:54:31 AM
 * To change this template use File | Settings | File Templates.
 */
public class MirageSQLUtils
{
   public static String buildBayerCodeForDB(String bayerCode) {
      return (bayerCode == null) ? bayerCode : padBayerCode(bayerCode);
   }

   private static String padBayerCode(String bayerCode) {
     bayerCode = bayerCode.trim();
      if (bayerCode.length() == 5) {
         bayerCode = bayerCode + ' ';
      }
      return StringUtils.toUpperCaseNull(bayerCode);
   }
}
