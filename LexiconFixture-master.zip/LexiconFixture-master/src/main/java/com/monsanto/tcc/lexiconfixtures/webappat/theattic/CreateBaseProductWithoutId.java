/*
 CreateBaseProductWithoutId was created on Dec 4, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.webappat.theattic;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.data.lexicon.baseproduct.BaseProductFixtureSQL;
import com.monsanto.tcc.lexiconfixtures.util.LexiconDataFixtureInsert;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dbdataservices.SQLUtil;
import fit.ColumnFixture;
import java.util.Random;

/**
 * nbwald Dec 4, 2007 2:04:55 PM
 */
public class CreateBaseProductWithoutId
   extends ColumnFixture
{
   public String baseManufacturingName;
   public String cropName;
   public boolean parentProduct;

   private Integer id;

   public void reset()
      throws Exception
   {
      id = generateNewId();
   }

   public boolean created()
      throws WrappingException
   {
      final BaseProductInsert dataMod = new BaseProductInsert();
      return dataMod.performInsert() == 1;
   }

   class BaseProductInsert
      extends LexiconDataFixtureInsert
   {
      protected String getSQL() throws WrappingException {
         return new SQLPropFile(BaseProductFixtureSQL.class).getSQL(BaseProductFixtureSQL.INSERT_BASE_PRODUCT);
      }
      protected Object[] getBindVariables() throws WrappingException {
         return new Object[] {id, baseManufacturingName, cropName, SQLUtil.booleanToString(parentProduct) };
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new LexiconConnectionFactoryProperties();
      }
   }

   public Integer id() {
      return id;
   }

   private Integer generateNewId() {
      return new Integer(-Math.abs(new Random().nextInt()));
   }
}