package com.monsanto.tcc.lexiconfixtures.data.lexicon.crop;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.LexiconDataFixtureDelete;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * User: pjberry
 * Date: Jul 12, 2007
 * Time: 5:28:37 PM
 */
public class RemoveLexiconCrop
   extends SymbolAcceptingColumnFixture
{
   public String cropName;

   public boolean removed()
      throws WrappingException
   {
      LexiconCropDelete delete = new LexiconCropDelete();
      return delete.performDelete() == 1;
   }

   private class LexiconCropDelete
      extends LexiconDataFixtureDelete
   {
      protected String getSQL()
         throws WrappingException
      {
         return "DELETE FROM Lexicon.crop C WHERE C.crop_name = ?";
      }

      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[]{cropName};
      }

      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new LexiconConnectionFactoryProperties();
      }
   }
}
