/*
 CheckLexiconMonsantoProduct was created on Mar 19, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.data.lexicon.product;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreEntityExistsQuery;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.dbdataservices.SQLUtil;

/**
 * nbwald Mar 19, 2007 10:16:51 AM
 */
public class CheckLexiconMonsantoProduct
   extends SymbolAcceptingColumnFixture
{
   public String precomlName;
   public String parentProduct;
   public boolean logicalDelete;
   public String crop;

   public boolean exists()
      throws WrappingException
   {
      return new CheckLexiconMonsantoProductQuery().entityExists();
   }

   class CheckLexiconMonsantoProductQuery
      extends AbstractPersistentStoreEntityExistsQuery
   {
      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[] {
            precomlName, parentProduct,
            SQLUtil.booleanToString(logicalDelete),
            StringUtils.toUpperCaseNull(crop)
         };
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new LexiconConnectionFactoryProperties();
      }
      public String getSQL()
         throws WrappingException
      {
         return new SQLPropFile(LexiconProductFixtureSQL.class).
            getSQL(LexiconProductFixtureSQL.SELECT_BY_MATCHING);
      }
   }

}