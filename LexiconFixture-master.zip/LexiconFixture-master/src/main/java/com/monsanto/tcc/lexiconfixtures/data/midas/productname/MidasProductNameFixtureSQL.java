package com.monsanto.tcc.lexiconfixtures.data.midas.productname;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 13, 2006
 * Time: 10:56:01 AM
 * To change this template use File | Settings | File Templates.
 */
public interface MidasProductNameFixtureSQL
{
   String INSERT_PRODUCT_NAME = "InsertProductName";
   String DELETE_PRODUCT_NAME = "DeleteProductName";
   String SELECT_IDS_BY_NAME_BRAND_COUNTRY = "SelectIdsByNameBrandCountry";
   String SELECT_PRODUCT_NAME_ID_BY_CRITERIA = "SelectProductNameIdByCriteria";
   String CHECK_PRODUCT_NAME_EXISTS_BY_PCNAME_NAME_BRAND_COUNTRY_REF_ACTIVE_QUERY = "CheckProductNameExistsQuery";
   String CHECK_PRODUCT_NAME_EXISTS_BY_PCNAME_NAME_BRAND_COUNTRY_REF_ACTIVE_CROP_QUERY = "CheckProductNameExistsByPCNameNameBrandCountryRefActiveCropQuery";
}
