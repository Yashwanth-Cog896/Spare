package com.monsanto.tcc.lexiconfixtures.data.midas.geneticmaterial;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreEntityExistsQuery;
import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jun 22, 2007
 * Time: 5:28:09 PM
 */
public class CheckGeneticMaterial
   extends SymbolAcceptingColumnFixture
{
   public Long geneticMaterialId;

   public boolean exists()
      throws WrappingException
   {
      GeneticMaterialExistsQuery query = new GeneticMaterialExistsQuery();
      return query.entityExists();
   }

   class GeneticMaterialExistsQuery
      extends AbstractPersistentStoreEntityExistsQuery
   {
      protected String getSQL() throws WrappingException {
         return new SQLPropFile(GeneticMaterialFixtureSQL.class).getSQL(GeneticMaterialFixtureSQL.SELECT_GENETIC_MATERIAL);
      }
      protected Object[] getBindVariables() throws WrappingException {
         return new Object[] {geneticMaterialId};
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new MidasConnectionFactoryProperties();
      }
   }
}
