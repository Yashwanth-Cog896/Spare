package com.monsanto.tcc.lexiconfixtures.data.lexicon.productname;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.test.LexiconTestTools;
import com.monsanto.tcc.lexiconcommon.db.audit.LexiconAuditor;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactory;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Feb 16, 2007
 * Time: 4:53:08 PM
 * To change this template use File | Settings | File Templates.
 */
public class RemoveLexiconCompetitiveProductAliasByAliasPubkey
{
   private String productNamePubkey;
   private SQLPropFile sqlPropFile = new SQLPropFile(LexiconProductNameFixtureSQL.class);

   public RemoveLexiconCompetitiveProductAliasByAliasPubkey(String productStagePubkey) {
      this.productNamePubkey = productStagePubkey;
   }

   public int remove()
      throws WrappingException
   {
      LexiconConnectionFactory connectionFactory = new LexiconConnectionFactory();
      PersistentStoreConnection conn = connectionFactory.getConnection();
      LexiconAuditor lexiconAuditor = LexiconTestTools.FITNESSE_TEST_AUDITOR;
      lexiconAuditor.initializeStaging(conn);
      try {
         return deleteFakeData(conn);
      }
      finally {
         lexiconAuditor.removeStaging(conn);
         conn.close();
      }
   }

   private int deleteFakeData(PersistentStoreConnection conn)
      throws WrappingException
   {
      String sql = sqlPropFile.getSQL(LexiconProductNameFixtureSQL.DELETE_COMPETITIVE_PRODUCT_NAME);
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, productNamePubkey);
         return stmt.executeDelete();
      }
      finally {
         stmt.close();
      }
   }
}
