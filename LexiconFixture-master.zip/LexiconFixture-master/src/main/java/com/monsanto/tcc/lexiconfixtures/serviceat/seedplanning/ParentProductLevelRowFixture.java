package com.monsanto.tcc.lexiconfixtures.serviceat.seedplanning;

import com.monsanto.tcc.lexiconcommon.service.ProductParentGermplasmDocTags;
import com.monsanto.tcc.lexiconcommon.xml.LexiconXPathSelector;
import com.monsanto.tcc.lexiconcommon.xml.SingleNamespaceContext;
import com.monsanto.XMLUtil.DOMUtil;
import fit.RowFixture;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Feb 14, 2007
 * Time: 9:13:46 AM
 * To change this template use File | Settings | File Templates.
 */
public class ParentProductLevelRowFixture
   extends AbstractChildProductRowFixture
{
   public ParentProductLevelRowFixture(Document responseDocument) {
      super(responseDocument);
   }

   protected Object[] query(List<Node> childProductNodes)
   {
      List parentProductLevelAdapters = new ArrayList();
      for (Node childProductNode : childProductNodes) {
         String childProductPubkey = DOMUtil.getAttribute((Element)childProductNode, ProductParentGermplasmDocTags.PUBKEY_ATTR_NAME);
         Node[] parentNodes = getParentNodes(childProductNode);

         for (int j = 0; j < parentNodes.length; j++) {
            Node parentNode = parentNodes[j];
            parentProductLevelAdapters.add(new ParentProductLevelAdapter(childProductPubkey, parentNode));
         }
      }
      return parentProductLevelAdapters.toArray();
   }

   private Node[] getParentNodes(Node childProductNode) {
      Node[] parentsNode = DOMUtil.getChildren(childProductNode, ProductParentGermplasmDocTags.PARENTS_ELEM_NAME);
      List parents = new ArrayList();
      for (int i = 0; i < parentsNode.length; i++) {
         Node[] parentNodes = DOMUtil.getChildren(parentsNode[i], ProductParentGermplasmDocTags.PARENT_ELEM_NAME);
         parents.addAll(Arrays.asList(parentNodes));

      }
      return (Node[])parents.toArray(new Node[parents.size()]);
   }

   public Class getTargetClass() {
      return ParentProductLevelAdapter.class;
   }
}
