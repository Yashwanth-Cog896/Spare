package com.monsanto.tcc.lexiconfixtures.data.mirage.product;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 13, 2006
 * Time: 11:17:40 AM
 * To change this template use File | Settings | File Templates.
 */
public interface MirageProductFixtureSQL
{
   String INSERT_PRODUCT = "InsertProduct";
   String DELETE_PRODUCT = "DeleteProduct";
   String SELECT_PRODUCT = "SelectProduct";
   String SELECT_PRODUCT_ID = "SelectProductId";

   String DELETE_PRODUCT_MATURITY = "DeleteProductMaturityByProductId";

   String ALIAS_PRODUCT_ID = "ProductId";
   String ALIAS_PRODUCT_NAME = "ProductName";
   String ALIAS_ENABLED = "Enabled";
   String ALIAS_BAYER_CODE = "BayerCode";
   String ALIAS_COML_TRAIT = "ComlTrait";
   String ALIAS_COMPANY_NAME = "CompanyName";
   String ALIAS_COUNTRY_ABBR = "CountryAbbr";

   String CHECK_MIRAGE_PROD_EXISTS = "CheckMirageProductExists";
   String SELECT_NUM_OF_PRODUCTS_WITH_GIVEN_NAME = "SelectNumOfProductsWithGivenName";
   String MIRAGE_SELECT_PRODUCT_ID = "MirageSelectProductId";
}
