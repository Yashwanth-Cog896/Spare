package com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo;

import com.monsanto.tcc.lexiconcommon.db.audit.LexiconAuditor;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactory;
import com.monsanto.tcc.lexiconcommon.db.test.LexiconTestTools;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.EmptyResultSetException;
import com.monsanto.dataservices.PersistentStoreConnection;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Mar 19, 2007
 * Time: 9:24:01 AM
 */
public class RemoveAllLexiconMonsantoProductInfo
   extends SymbolAcceptingColumnFixture
{
   public String precomlName;

   public boolean removed()
      throws WrappingException, EmptyResultSetException
   {
      LexiconConnectionFactory connectionFactory = new LexiconConnectionFactory();
      PersistentStoreConnection conn = connectionFactory.getConnection();
      LexiconAuditor lexiconAuditor = LexiconTestTools.FITNESSE_TEST_AUDITOR;
      lexiconAuditor.initializeStaging(conn);
      try {
         return deleteFakeData(conn) > 0;
      }
      finally {
         lexiconAuditor.removeStaging(conn);
         conn.close();
      }
   }

   private int deleteFakeData(PersistentStoreConnection conn)
      throws WrappingException
   {
      Long productId = getProductId(conn);
      Long[] productRelationshipIds = getProductRelationshipIds(conn, productId);

      int numDeleted = 0;
      numDeleted += deleteProductRelationshipXrefs(conn, productId);
      numDeleted += deleteProductRelationships(conn, productRelationshipIds);
      numDeleted += deleteProductAliases(conn, productId);
      numDeleted += deleteProduct(conn, productId);
      return numDeleted;
   }

   private Long getProductId(PersistentStoreConnection conn)
      throws WrappingException
   {
      MonsantoProductIdByPreComlName lookup = new MonsantoProductIdByPreComlName();
      return lookup.getProductId(conn, precomlName);
   }

   private Long[] getProductRelationshipIds(PersistentStoreConnection conn, Long productId)
      throws WrappingException
   {
      MonsantoProductRelationshipIdByProductId lookup = new MonsantoProductRelationshipIdByProductId();
      return lookup.getProductRelationshipIds(conn, productId);
   }

   private int deleteProductRelationshipXrefs(PersistentStoreConnection conn, Long productId)
      throws WrappingException
   {
      DeleteProductRelationshipXrefsByProductId destroyer = new DeleteProductRelationshipXrefsByProductId();
      return destroyer.deleteProductRelationshipXrefs(conn, productId);
   }

   private int deleteProductRelationships(PersistentStoreConnection conn, Long[] productRelationshipIds)
      throws WrappingException
   {
      DeleteProductRelationshipsByProductRelationshipIds destroyer = new DeleteProductRelationshipsByProductRelationshipIds();
      return destroyer.deleteProductRelationships(conn, productRelationshipIds);
   }

   private int deleteProductAliases(PersistentStoreConnection conn, Long productId)
      throws WrappingException
   {
      DeleteProductAliasesByProductId destroyer = new DeleteProductAliasesByProductId();
      return destroyer.deleteProductAliases(conn, productId);
   }

   private int deleteProduct(PersistentStoreConnection conn, Long productId)
      throws WrappingException
   {
      DeleteMonsantoProductByProductId destroyer = new DeleteMonsantoProductByProductId();
      return destroyer.deleteProduct(conn, productId);
   }
}
