package com.monsanto.tcc.lexiconfixtures.webappat.theattic.gridfixtureisms;

import fit.Fixture;
import fitlibrary.DoFixture;
import fitlibrary.GridFixture;

/**
 * nbwald - Apr 22, 2008 6:17:38 PM
 */
public class GridFixtureismsDoFixture
   extends DoFixture
{
   private final String[][] data = new String[][]
      {
         {"A", "B", "C"},
         {"D", "E", "F"}
      };

   public Fixture data() {
      return new GridFixture(data);
   }
}
