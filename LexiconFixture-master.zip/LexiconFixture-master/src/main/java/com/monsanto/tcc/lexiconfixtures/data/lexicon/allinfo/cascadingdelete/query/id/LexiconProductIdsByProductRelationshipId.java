/*
 LexiconProductIdsByProductRelationshipId was created on Jul 17, 2007 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo.cascadingdelete.query.id;

import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald Jul 17, 2007 12:15:46 PM
 */
public class LexiconProductIdsByProductRelationshipId
   extends AbstractLexiconIDQuery
{
   public LexiconProductIdsByProductRelationshipId(long productRelationshipId) {
      super(productRelationshipId);
   }

   protected String getSQL()
      throws WrappingException
   {
      return "SELECT product_id FROM Lexicon.Product_Relationship_Xref WHERE product_relationship_id = ?";
   }
}