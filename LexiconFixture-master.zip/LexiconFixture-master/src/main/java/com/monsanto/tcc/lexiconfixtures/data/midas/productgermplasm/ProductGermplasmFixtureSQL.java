package com.monsanto.tcc.lexiconfixtures.data.midas.productgermplasm;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 13, 2006
 * Time: 10:48:52 AM
 * To change this template use File | Settings | File Templates.
 */
public interface ProductGermplasmFixtureSQL
{
   String INSERT_PRODUCT_GERMPLASM = "InsertProductGermplasm";
   String DELETE_PRODUCT_GERMPLASM = "DeleteProductGermplasm";
   String SELECT_NUM_OF_MATCHING_XREF = "SelectProductGermplasm";
}
