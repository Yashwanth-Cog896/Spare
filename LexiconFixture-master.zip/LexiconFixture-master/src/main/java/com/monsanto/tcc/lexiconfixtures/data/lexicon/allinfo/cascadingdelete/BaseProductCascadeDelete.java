/*
 BaseProductCascadeDelete was created on Jul 17, 2007 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo.cascadingdelete;

import com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo.cascadingdelete.query.id.ProductRelationshipIdsByBaseProductId;
import com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo.cascadingdelete.query.delete.BaseProductDelete;
import com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo.cascadingdelete.query.delete.AbstractLexiconDeleteByIDDataMod;
import com.monsanto.Util.Exceptions.WrappingException;
import java.util.List;

/**
 * nbwald Jul 17, 2007 11:19:03 AM
 */
public class BaseProductCascadeDelete
   extends AbstractCascadingDelete
{
   private final long baseProductId;

   public BaseProductCascadeDelete(long baseProductId) {
      this.baseProductId = baseProductId;
   }

   protected boolean removeDependencies()
      throws WrappingException
   {
      List<Long> productRelationshipIds = getDependentProductRelationships();
      return removeDependentProductRelationships(productRelationshipIds);
   }

   protected AbstractLexiconDeleteByIDDataMod getSelfDeleter() {
      return new BaseProductDelete(baseProductId);
   }

   private List<Long> getDependentProductRelationships()
      throws WrappingException
   {
      ProductRelationshipIdsByBaseProductId query = new ProductRelationshipIdsByBaseProductId(baseProductId);
      return query.getIds();
   }

   private boolean removeDependentProductRelationships(List<Long> productRelationshipIds)
      throws WrappingException
   {
      boolean removed = true;
      for (long productRelationshipId : productRelationshipIds) {
         ProductRelationshipCascadeDelete dependentRemover = new ProductRelationshipCascadeDelete(productRelationshipId);
         removed &= dependentRemover.remove();
      }
      return removed;
   }
}