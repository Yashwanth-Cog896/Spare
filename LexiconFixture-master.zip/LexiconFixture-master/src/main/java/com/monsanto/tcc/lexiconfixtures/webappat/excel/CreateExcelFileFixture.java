/*
 CreateExcelFileFixture was created on Oct 12, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.webappat.excel;

import com.monsanto.tcc.lexiconcommon.file.excel.ExcelFileWriter;
import com.monsanto.tcc.lexiconcommon.file.excel.ExcelSheet;
import com.monsanto.tcc.lexiconcommon.file.excel.ListsExcelSheet;
import com.monsanto.tcc.lexiconfixtures.util.symbol.StringParseDelagate;
import fit.Parse;
import fitnesse.fixtures.TableFixture;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * nbwald Oct 12, 2007 10:01:44 AM
 */
public class CreateExcelFileFixture
   extends TableFixture
{
   protected void doStaticTable(int rows)
   {
      List<List<String>> rowsForExcel = parseWikiRows(rows);
      writeRowsToExcelFile(rowsForExcel);
   }

   private void writeRowsToExcelFile(List<List<String>> rowsForExcel)
   {
      ExcelSheet excelSheet = new ListsExcelSheet((List)rowsForExcel);
      ExcelFileWriter writer = new ExcelFileWriter();
      try {
         writer.writeToFile(TestExcelFile.getTestExcelFile(), excelSheet);
      }
      catch (IOException e) {
         throw new RuntimeException(e);
      }
   }

   private List<List<String>> parseWikiRows(int rows)
   {
      List<List<String>> rowsForExcel = new ArrayList<List<String>>();
      for(int rowNum = 0; rowNum < rows; rowNum++) {
         rowsForExcel.add( parseColumnsForRow(rowNum) );
      }
      return rowsForExcel;
   }

   private List<String> parseColumnsForRow(int rowNum)
   {
      List<String> columnValues = new ArrayList<String>();
      for(int colNum = 0; colNum < columnCount(rowNum); colNum++) {
         String cellValue = new StringParseDelagate().parse(getText(rowNum, colNum));
         columnValues.add(cellValue);
      }
      return columnValues;
   }

   private int columnCount(int row) {
      // Is there a better way to do this?
      Parse currentRow = firstRow;
      for(int r = 0; r != row; r++) {
         currentRow = currentRow.more;
      }
      Parse targetedRowColumns = currentRow.parts;
      return targetedRowColumns.size();
   }
}