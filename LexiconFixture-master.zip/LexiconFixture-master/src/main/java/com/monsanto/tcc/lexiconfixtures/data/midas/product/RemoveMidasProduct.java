package com.monsanto.tcc.lexiconfixtures.data.midas.product;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreDelete;
import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 7, 2006
 * Time: 12:05:41 PM
 * To change this template use File | Settings | File Templates.
 */
public class RemoveMidasProduct
   extends SymbolAcceptingColumnFixture
{
   public Long productId;

   public boolean removed()
      throws WrappingException
   {
      MidasProductDelete dataMod = new MidasProductDelete();
      return dataMod.performDelete() == 1;
   }

   class MidasProductDelete
      extends AbstractPersistentStoreDelete
   {
      protected String getSQL() throws WrappingException {
         return new SQLPropFile(MidasProductFixtureSQL.class).getSQL(MidasProductFixtureSQL.DELETE_PRODUCT);
      }
      protected Object[] getBindVariables() throws WrappingException {
         return new Object[] { productId };
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new MidasConnectionFactoryProperties();
      }
   }
}
