package com.monsanto.tcc.lexiconfixtures.data.lexicon.productrelationship;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreEntityExistsQuery;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Mar 29, 2007
 * Time: 2:38:23 PM
 */
public class CheckLexiconProductIsInRelationship
   extends SymbolAcceptingColumnFixture
{
   public String manufacturingName;
   public String precomlName;
   public String traitVersion;
   public String productionStatus;

   public void reset()
      throws Exception
   {
      super.reset();
      manufacturingName = null;
      precomlName = null;
      traitVersion = null;
      productionStatus = null;
   }

   public boolean exists()
      throws WrappingException
   {
      final ExistingManfToPreComlNameExistsQuery query = new ExistingManfToPreComlNameExistsQuery();
      return query.entityExists();
   }

   class ExistingManfToPreComlNameExistsQuery
      extends AbstractPersistentStoreEntityExistsQuery
   {
      protected String getSQL()
         throws WrappingException
      {
         return
            "SELECT  PRP.product_relationship_id " +
            "  FROM  Lexicon.Product_Relationship PR, " +
            "        Lexicon.Product_Relationship_Xref PRP, " +
            "        Lexicon.Pre_Coml_Product PCP, " +
            "        Lexicon.Production_Status PST " +
            " WHERE  PR.manufacturing_name = ? " +
            "   AND  PCP.pre_coml_name = ? " +
            "   AND  PR.product_relationship_id = PRP.product_relationship_id " +
            "   AND  PRP.product_id = PCP.product_id " +
            "   AND  PRP.trait_version " + nullableValue(traitVersion) +
            "   AND  PRP.production_status_id = PST.production_status_id " +
            "   AND  PST.production_status_name " + nullableValue(productionStatus);
      }

      protected Object[] getBindVariables()
         throws WrappingException
      {
         List<Object> bindVariables = new ArrayList<Object>();
         bindVariables.add(manufacturingName);
         bindVariables.add(precomlName);
         bindNullableVariable(bindVariables, traitVersion);
         bindNullableVariable(bindVariables, productionStatus);
         return bindVariables.toArray(new Object[bindVariables.size()]);
      }

      private String nullableValue(String variable) {
         return variable == null ? " IS NULL " : " = ? ";
      }

      private void bindNullableVariable(List<Object> bindVariables, String variable) {
         if(variable != null) {
            bindVariables.add(variable);
         }
      }

      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new LexiconConnectionFactoryProperties();
      }
   }
}


