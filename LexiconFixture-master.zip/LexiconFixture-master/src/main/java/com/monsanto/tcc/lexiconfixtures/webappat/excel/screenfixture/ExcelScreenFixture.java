/*
 ExcelScreenFixture was created on Dec 11, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.webappat.excel.screenfixture;

import com.monsanto.tcc.lexiconcommon.file.excel.ExcelReader;
import com.monsanto.tcc.lexiconcommon.xml.LexiconXPathSelector;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingDoFixture;
import com.monsanto.tcc.lexiconfixtures.webappat.excel.TestExcelFile;
import com.monsanto.tcc.lexiconfixtures.webappat.productaliasreport.ExcelSpreadSheetFixture;
import com.meterware.httpunit.HTMLElement;
import com.meterware.httpunit.SubmitButton;
import com.meterware.httpunit.UploadFileSpec;
import com.meterware.httpunit.WebConversation;
import com.meterware.httpunit.WebForm;
import com.meterware.httpunit.WebResponse;
import com.monsanto.XMLUtil.DOMUtil;
import fit.Fixture;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;
import javax.xml.xpath.XPathExpressionException;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

/**
 * nbwald Dec 11, 2007 12:00:43 PM
 */
public abstract class ExcelScreenFixture
   extends SymbolAcceptingDoFixture
{
   private KerberizedWebInteraction interaction;
   private WebConversation conversation;
   private WebResponse currentPage;
   private LexiconXPathSelector selector = new LexiconXPathSelector();

   protected abstract String getMenuHeading();

   protected abstract String getMenuItem();

   protected abstract HttpUnitPageVisitStrategy getInitialPageVisitStrategy();

   public boolean connect()
      throws Exception
   {
      interaction = new KerberizedWebInteraction();
      conversation = interaction.connect();
      return true;
   }

   public boolean disconnect()
      throws Exception
   {
      interaction.disconnect();
      return true;
   }

   public boolean clickLinkWithHeading(String link, String heading)
      throws Exception
   {
      if (getMenuHeading().equals(heading) && getMenuItem().equals(link)) {
         HttpUnitPageVisitStrategy pageVisitStrategy = getInitialPageVisitStrategy();
         currentPage = pageVisitStrategy.visitPage(conversation);
         return true;
      }
      else {
         throw new RuntimeException("Cannot Find Requested Link");
      }
   }

   public Fixture checkExcelSpreadsheet()
      throws IOException
   {
      InputStream excelStream = currentPage.getInputStream();
      try {
         ExcelReader excelReader = new ExcelReader(excelStream);
         return new ExcelSpreadSheetFixture(excelReader);
      }
      finally {
         excelStream.close();
      }
   }

   public boolean enterFor(String value, String textInputIdentifier)
      throws Exception
   {
      Element textInputElem = findControl(textInputIdentifier);
      String controlName = DOMUtil.getAttribute(textInputElem, "name");
      return setParameter(controlName, value);
   }

   public boolean selectFor(String optionText, String selectIdentifier)
      throws Exception
   {
      String optionValue = getEffectiveOptionValue(optionText, selectIdentifier);
      return setParameter(selectIdentifier, optionValue);
   }

   private boolean setParameter(String controlName, String value)
      throws Exception
   {
      WebForm form = getFormByControlIdentifier(controlName);
      form.setParameter(controlName, value);
      return true;
   }

   public boolean clickWaitForPageToLoad(String controlIdentifier)
      throws Exception
   {
      WebForm form = getFormByControlIdentifier(controlIdentifier);
      /*
          If you just call form.submit(), sometimes it finds the wrong submit button.  E.g.
          On a search query pane, it finds the product name list chooser instead of the search
          submit button sometimes.
        */
      SubmitButton formSubmitButton = form.getSubmitButton(controlIdentifier);
      currentPage = form.submit(formSubmitButton);
      return true;
   }

   private WebForm getFormByControlIdentifier(String controlIdentifier)
      throws Exception
   {
      String formName = getFormNameByControlIdentifier(controlIdentifier);
      return currentPage.getFormWithName(formName);
   }

   public String fieldIs(String elementId)
      throws SAXException
   {
      HTMLElement element = currentPage.getElementWithID(elementId);
      return element.getText();
   }

   public boolean textExists(String textToFind)
      throws IOException
   {
      String currentPageText = currentPage.getText();
      return currentPageText.contains(textToFind);
   }

   public boolean elementExists(String elementId)
      throws SAXException
   {
      HTMLElement element = currentPage.getElementWithID(elementId);
      return element != null;
   }

   public boolean onFormEnterExcelTestFileForAndSubmit(String formName, String inputName)
      throws SAXException, IOException
   {
      WebForm form = currentPage.getFormWithName(formName);
      UploadFileSpec[] fileSpecs = buildUploadFileSpecs(TestExcelFile.getTestExcelFilePathAndName());
      form.setParameter(inputName, fileSpecs);
      currentPage = form.submit();
      return true;
   }

   private UploadFileSpec[] buildUploadFileSpecs(String fileName) {
      File file = new File(fileName);
      UploadFileSpec[] fileSpecs = new UploadFileSpec[1];
      fileSpecs[0] = new UploadFileSpec(file);
      return fileSpecs;
   }

   private String getFormNameByControlIdentifier(String controlIdentifier)
      throws SAXException, XPathExpressionException
   {
      Node controlNode = findControl(controlIdentifier);
      Element formElement = findControlsForm(controlNode);
      return DOMUtil.getAttribute(formElement, "name");
   }

   private Element findControlsForm(Node controlNode)
      throws XPathExpressionException
   {
      return selector.selectElement(controlNode, "ancestor::form | ancestor::FORM");
   }

   private Element findControl(String controlIdentifier)
      throws XPathExpressionException, SAXException
   {
      return selector.selectElement(currentPage.getDOM(), "//*[@id='" + controlIdentifier + "'] | //*[@name='" + controlIdentifier + "']");
   }

   private String getOptionValue(String displayText, String selectIdentifier)
      throws SAXException, XPathExpressionException
   {
      Element selectElem = findControl(selectIdentifier);
      if(selectElem == null) {
         throw new IllegalArgumentException("Could not find select element identified as '" + selectIdentifier + "'");
      }
      //xpath is case sensitive with no easy way that I could find to case insensitize your search :[
      String optionWithDisplayTextQuery = "//option[text()='" + displayText + "'] | //OPTION[text()='" + displayText + "']";
      Element optionElem = selector.selectElement(selectElem, optionWithDisplayTextQuery);
      if(optionElem == null) {
         throw new IllegalArgumentException("Found select '" + selectIdentifier + "', but could not find option with display text '" + displayText + "'.");
      }
      return DOMUtil.getAttribute(optionElem, "value");
   }

   private String getEffectiveOptionValue(String displayText, String selectIdentifier)
      throws Exception
   {
      String optionValue = getOptionValue(displayText, selectIdentifier);
      return optionValue == null ? displayText : optionValue; 
   }
}