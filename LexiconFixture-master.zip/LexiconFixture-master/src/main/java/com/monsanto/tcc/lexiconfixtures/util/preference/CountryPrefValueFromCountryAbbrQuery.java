package com.monsanto.tcc.lexiconfixtures.util.preference;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jun 28, 2007
 * Time: 12:59:41 PM
 */
class CountryPrefValueFromCountryAbbrQuery
   extends AbstractPersistentStoreSingleResultQuery
{
   private final String countryAbbr;
   public CountryPrefValueFromCountryAbbrQuery(String countryAbbr) {
      this.countryAbbr = countryAbbr;
   }
   public String getValue() throws WrappingException {
      return (String)execute();
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row) throws WrappingException {
      return row.getString(1);
   }
   protected String getSQL() throws WrappingException {
      return "SELECT C.country_abbr || ' - ' || C.country_name " + "FROM Lexicon.Country C WHERE C.country_abbr = ?";
   }
   protected Object[] getBindVariables() throws WrappingException {
      return new Object[] { countryAbbr };
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
}
