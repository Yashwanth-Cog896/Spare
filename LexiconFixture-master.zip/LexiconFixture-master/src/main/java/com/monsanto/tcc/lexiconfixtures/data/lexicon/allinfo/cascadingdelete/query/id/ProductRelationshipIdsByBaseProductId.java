/*
 ProductRelationshipIdsByBaseProductId was created on Jul 17, 2007 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo.cascadingdelete.query.id;

import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald Jul 17, 2007 11:40:56 AM
 */
public class ProductRelationshipIdsByBaseProductId
   extends AbstractLexiconIDQuery
{
   public ProductRelationshipIdsByBaseProductId(long baseProductId) {
      super(baseProductId);
   }

   protected String getSQL()
      throws WrappingException
   {
      return "SELECT product_relationship_id FROM Lexicon.Product_Relationship WHERE base_product_id = ?";
   }
}