package com.monsanto.tcc.lexiconfixtures.data.lexicon.configuration;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.LexiconDataFixtureDelete;

/**
 * nbwald - Sep 22, 2008 12:14:09 PM
 */
public class CropConfigurationDeleteAll
   extends LexiconDataFixtureDelete
{
   private final String cropConfigurationName;

   public CropConfigurationDeleteAll(String cropConfigurationName) {
      this.cropConfigurationName = cropConfigurationName;
   }

   protected String getSQL()
      throws WrappingException
   {
      return "DELETE FROM Lexicon.Configuration_Crop WHERE configuration_type_id = (SELECT CT.configuration_type_id FROM Lexicon.Configuration_Type CT where CT.configuration_type_name = ?)";
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { cropConfigurationName };
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
}
