package com.monsanto.tcc.lexiconfixtures.data.midas.parentage;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreEntityExistsQuery;
import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jun 22, 2007
 * Time: 5:47:24 PM
 */
public class CheckParentage
   extends SymbolAcceptingColumnFixture
{
   public Long parentageId;

   public boolean exists()
      throws WrappingException
   {
      MaterialParentageExistsQuery query = new MaterialParentageExistsQuery();
      return query.entityExists();
   }

   class MaterialParentageExistsQuery
      extends AbstractPersistentStoreEntityExistsQuery
   {
      protected String getSQL() throws WrappingException {
         return new SQLPropFile(MidasParentageFixtureSQL.class).getSQL(MidasParentageFixtureSQL.SELECT_PARENTAGE);
      }
      protected Object[] getBindVariables() throws WrappingException {
         return new Object[] { parentageId };
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new MidasConnectionFactoryProperties();
      }
   }
}
