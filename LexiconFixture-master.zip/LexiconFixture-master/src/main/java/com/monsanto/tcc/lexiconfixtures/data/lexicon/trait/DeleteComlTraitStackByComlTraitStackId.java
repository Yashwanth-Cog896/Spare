package com.monsanto.tcc.lexiconfixtures.data.lexicon.trait;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreDelete;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * User: pjberry
 * Date: Sep 19, 2007
 * Time: 5:53:11 PM
 */
public class DeleteComlTraitStackByComlTraitStackId
   extends AbstractPersistentStoreDelete
{
   private final Long comlTraitStackId;

   public DeleteComlTraitStackByComlTraitStackId(Long comlTraitStackId) {
      this.comlTraitStackId = comlTraitStackId;
   }

   protected String getSQL()
      throws WrappingException
   {
      return "DELETE FROM Lexicon.Coml_Trait_Stack2 CTS WHERE CTS.coml_trait_stack_id = ?";
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] {comlTraitStackId};
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
}
