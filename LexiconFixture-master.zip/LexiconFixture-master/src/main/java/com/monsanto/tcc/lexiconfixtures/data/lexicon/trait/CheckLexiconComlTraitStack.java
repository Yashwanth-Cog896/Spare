package com.monsanto.tcc.lexiconfixtures.data.lexicon.trait;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreEntityExistsQuery;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * User: pjberry
 * Date: May 23, 2007
 * Time: 10:27:05 AM
 */
public class CheckLexiconComlTraitStack
   extends SymbolAcceptingColumnFixture
{
   public String reportingName;
   public String stackDesc;
   public String crop;
   public String tdName;
   public String stackAbbr;
   public String manfTraitCode;

   public boolean exists()
      throws WrappingException
   {
      CheckLexiconComlTraitStackQuery query = new CheckLexiconComlTraitStackQuery();
      return query.entityExists();
   }

   class CheckLexiconComlTraitStackQuery
      extends AbstractPersistentStoreEntityExistsQuery
   {
      protected String getSQL() {
         return
            "SELECT CTS.stack_desc " +
            "  FROM Lexicon.Coml_Trait_Stack2 CTS " +
            " WHERE CTS.stack_desc = ? " +
              " AND CTS.crop_id = (SELECT C.crop_id FROM Lexicon.Crop C WHERE UPPER(C.crop_name) = UPPER(?)) " +
              " AND CTS.stack_abbr = ? " +
              " AND NVL(CTS.td_name, 'NULL') = NVL(?, 'NULL')" +
              " AND NVL(CTS.reporting_name, 'NULL') = NVL(?, 'NULL')" +
              " AND NVL(CTS.manf_trait_code, 'NULL') = NVL(?, 'NULL')";
      }

      protected Object[] getBindVariables() throws WrappingException {
         return new Object[] { stackDesc, crop, stackAbbr, tdName, reportingName, manfTraitCode };
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new LexiconConnectionFactoryProperties();
      }
   }
}

