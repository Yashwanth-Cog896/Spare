package com.monsanto.tcc.lexiconfixtures.data.factories.spsecurity;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryPropertiesLexiconImpl;
import com.monsanto.tcc.lexiconcommon.props.PropertyManager;

import java.util.Properties;
import java.io.IOException;

/**
 * aagosw - Nov 18, 2008 1:45:04 PM
 */
public class SpsecurityConnectionFactoryProperties
 extends ConnectionFactoryPropertiesLexiconImpl
{
   public static final String INSTANCE_NAME = "Spsecurity";
   private static final String PROP_FILENAME = "SpsecurityDB.properties";

   public String getInstanceName() {
      return INSTANCE_NAME;
   }
   public Properties loadProperties() throws IOException {
      return PropertyManager.getInstance().getNonCachedProperties(getClass(), PROP_FILENAME);
   }
}