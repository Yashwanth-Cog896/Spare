/*
 RemoveBaseProductById was created on Dec 4, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.webappat.theattic;

import com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo.cascadingdelete.query.delete.BaseProductDelete;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald Dec 4, 2007 2:13:00 PM
 */
public class RemoveBaseProductById
   extends SymbolAcceptingColumnFixture
{
   public int id;

   public boolean removed()
      throws WrappingException
   {
      return new BaseProductDelete(id).performDelete() == 1;
   }
}