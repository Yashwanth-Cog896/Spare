package com.monsanto.tcc.lexiconfixtures.data.fbscommon.productname;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreDelete;
import com.monsanto.tcc.lexiconfixtures.data.factories.fbs.FBSCommonConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.data.lexicon.productname.LexiconProductAliasPubkeyLookup;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 9, 2006
 * Time: 1:25:51 PM
 * To change this template use File | Settings | File Templates.
 */
public class RemoveFBSCommonProductName
   extends SymbolAcceptingColumnFixture
{
   public String lexiconProductNamePubkey;

   public String lexiconPrecomlName;
   public String lexiconCommercialName;
   public String lexiconBrand;
   public String lexiconCountry;

   public boolean removed()
      throws WrappingException
   {
      RemoveFBSCommonProductNameByPubkey removeByPubkey = new RemoveFBSCommonProductNameByPubkey(getPubkey());
      return removeByPubkey.performDelete() == 1;
   }

   private String getPubkey() throws WrappingException {
      return (lexiconProductNamePubkey != null) ? lexiconProductNamePubkey : getPubkeyByLexCriteria();
   }

   private String getPubkeyByLexCriteria()
      throws WrappingException
   {
      LexiconProductAliasPubkeyLookup lookup =
         new LexiconProductAliasPubkeyLookup(
            lexiconPrecomlName, lexiconCommercialName, lexiconBrand, lexiconCountry);
      return lookup.getPubkey();
   }
}

class RemoveFBSCommonProductNameByPubkey
   extends AbstractPersistentStoreDelete
{
   public String lexiconProductNamePubkey;

   public RemoveFBSCommonProductNameByPubkey(String lexiconProductNamePubkey) {
      this.lexiconProductNamePubkey = lexiconProductNamePubkey;
   }

   protected String getSQL() throws WrappingException {
      return new SQLPropFile(FBSCommonProductNameFixtureSQL.class).
         getSQL(FBSCommonProductNameFixtureSQL.DELETE_PRODUCT_NAME);
   }
   protected Object[] getBindVariables() throws WrappingException {
      return new Object[] { lexiconProductNamePubkey };
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new FBSCommonConnectionFactoryProperties();
   }
}
