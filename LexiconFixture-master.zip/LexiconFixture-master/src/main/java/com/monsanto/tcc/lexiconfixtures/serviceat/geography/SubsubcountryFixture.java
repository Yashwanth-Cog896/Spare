/*
	 SubsubcountryFixture was created on Jun 11, 2008 using Monsanto
	 resources and is the sole property of Monsanto.  Any duplication of the
	 code and/or logic is a direct infringement of Monsanto's copyright.
	*/
package com.monsanto.tcc.lexiconfixtures.serviceat.geography;

import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import static com.monsanto.Util.StringUtils.getLineSeparator;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingRowFixture;
import com.monsanto.tps.lexicon.geography.service.Subsubcountries;
import com.monsanto.tps.lexicon.geography.service.SubsubcountriesImpl;
import com.monsanto.tps.lexicon.geography.subsubcountry.Subsubcountry;
import fit.Fixture;
import fitlibrary.DoFixture;
import org.ietf.jgss.GSSException;

/**
 * Filename:    $RCSfile: SubsubcountryFixture.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ggshiv $    	 On:	$Date: 2008-08-12 06:42:09 $
 *
 * @author MMR
 * @version $Revision: 1.8 $
 */
public class SubsubcountryFixture extends DoFixture {

   private Subsubcountry[] subsubcountries;
   private String errorMessage;

   public boolean findSubsubcountriesWithIsoCodeSubcountryNameAndSubsubcountryName(String isoCode,
                                                                                   String subcountryName,
                                                                                   String subsubcountryName) throws Exception {
      try {
         subsubcountries = getClient().findSubsubcountriesByName(isoCode, subcountryName, subsubcountryName);
      } catch (IllegalArgumentException e) {
         errorMessage = e.getMessage();
      }
      return true;
   }

   private Subsubcountries getClient() throws GSSException {
      return new SubsubcountriesImpl(new KerberosStandaloneCredential());
   }

   public boolean findSubsubcountriesWithIsoCodeSubcountryAbbreviationAndSubsubcountryName(String isoCode,
                                                                                           String abbreviationCSV,
                                                                                           String subsubcountryName) throws Exception {
      try {
         subsubcountries = getClient().findSubsubcountriesBySubcountriesAbbreviation(isoCode, abbreviationCSV.split(","), subsubcountryName);
      } catch (IllegalArgumentException e) {
         errorMessage = e.getMessage();
      }
      return true;
   }

   public int numberOfSubsubcountriesFound() {
      return subsubcountries == null ? 0 : subsubcountries.length;
   }

   public String errorMessage() {
      return errorMessage.replaceAll(getLineSeparator(), " ");
   }

   public Fixture checkResults() {
      return new SymbolAcceptingRowFixture() {
         public Class<?> getTargetClass() { return SubsubcountryResponseAdaptor.class; }

         public Object[] query()
            throws Exception
         {
            return buildSubsubcountryResponseAdaptors();
         }
      };
   }

   private SubsubcountryResponseAdaptor[] buildSubsubcountryResponseAdaptors() {
      SubsubcountryResponseAdaptor[] adaptors = new SubsubcountryResponseAdaptor[subsubcountries.length];
      for (int i = 0; i < subsubcountries.length; i++) {
         adaptors[i] = new SubsubcountryResponseAdaptor(subsubcountries[i]);
      }
      return adaptors;
   }
}
/*
* Revision Log
* : $
*/