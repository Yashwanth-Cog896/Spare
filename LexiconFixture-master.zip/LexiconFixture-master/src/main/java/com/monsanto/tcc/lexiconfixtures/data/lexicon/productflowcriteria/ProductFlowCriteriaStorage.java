package com.monsanto.tcc.lexiconfixtures.data.lexicon.productflowcriteria;

import com.monsanto.tcc.lexiconcommon.service.artemis.productflow.ProductFlowCriteria;

/**
 * nbwald - Mar 17, 2008 4:37:37 PM
 */
public class ProductFlowCriteriaStorage
{
   private ProductFlowCriteria savedCriteria;

   public boolean saveCriteria()
      throws Exception
   {
      this.savedCriteria = ProductFlowCriteriaTestTool.findCriteria();
      return true;
   }

   public boolean restoreCriteria()
      throws Exception
   {
      ProductFlowCriteriaTestTool.setCriteria(this.savedCriteria);
      return true;
   }
}
