package com.monsanto.tcc.lexiconfixtures.data.fbscommon.product;

import com.monsanto.tcc.lexiconfixtures.data.factories.fbs.FBSCommonConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.data.lexicon.product.LexiconMonsantoProductPubkeyPreComlNameQuery;
import com.monsanto.tcc.lexiconfixtures.data.midas.product.MidasProductIdByPreComlNameQuery;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.EmptyResultSetException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetSingleResult;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Apr 3, 2007
 * Time: 8:33:27 AM
 * To change this template use File | Settings | File Templates.
 */
public class CheckFBSCommonProductXref
   extends SymbolAcceptingColumnFixture
{
   public String lexiconPrecomlName;
   public String midasPrecomlName;

   public boolean exists()
      throws WrappingException
   {
      LexiconMonsantoProductPubkeyPreComlNameQuery lexMonProdQuery =
         new LexiconMonsantoProductPubkeyPreComlNameQuery(lexiconPrecomlName);

      MidasProductIdByPreComlNameQuery midasMonProdQuery = new MidasProductIdByPreComlNameQuery(midasPrecomlName);

      String lexiconProductPubkey = lexMonProdQuery.getPubkey();
      Long midasProductId = midasMonProdQuery.getProductId();

      return productLinkageFound(lexiconProductPubkey, midasProductId);
   }

   private boolean productLinkageFound(String lexiconProductPubkey, Long miasProductId)
      throws WrappingException
   {
      FBSCommonConnectionFactory connectionFactory = new FBSCommonConnectionFactory();
      PersistentStoreConnection conn = connectionFactory.getConnection();
      String sql = getSQL();
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, lexiconProductPubkey);
         stmt.setParam(2, miasProductId);
         PersistentStoreResultSetSingleResult resultSet = stmt.executeQuery().getSingleResult();
         return 1 == resultSet.getInt(1);
      }
      catch (EmptyResultSetException e) {
         return false;
      }
      finally {
         stmt.close();
         conn.close();
      }
   }

   private String getSQL() {
      return "SELECT COUNT(*) FROM FBS_Common.product_xref PX WHERE PX.lexicon_product_pubkey = ? AND PX.midas_product_id = ?";
   }
}
