package com.monsanto.tcc.lexiconfixtures.data.fbscommon.allinfo;

import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.data.factories.fbs.FBSCommonConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Mar 19, 2007
 * Time: 11:01:47 AM
 * To change this template use File | Settings | File Templates.
 */
public class RemoveAllFBSCommonProductInfo
   extends SymbolAcceptingColumnFixture
{
   public String precomlName;

   public boolean removed()
      throws WrappingException
   {
      LexiconConnectionFactory lexConnFactory = new LexiconConnectionFactory();
      PersistentStoreConnection lexConn = lexConnFactory.getConnection();
      try {
         String lexiconProductPubkey = getLexiconProductPubkey(lexConn);
         String[] lexiconProductAliasPubkeys = getLexiconProductAliasPubkeys(lexConn, lexiconProductPubkey);
         return deleteAllProductInfo(lexiconProductPubkey, lexiconProductAliasPubkeys) > 0;
      }
      finally {
         lexConn.close();
      }
   }

   private int deleteAllProductInfo(String lexiconProductPubkey, String[] lexiconProductAliasPubkeys)
      throws WrappingException
   {
      FBSCommonConnectionFactory fbsConnFactory = new FBSCommonConnectionFactory();
      PersistentStoreConnection fbsConn = fbsConnFactory.getConnection();
      try {
         int numOfThingsDeleted = 0;
         numOfThingsDeleted += deleteProduct(fbsConn, lexiconProductPubkey);
         numOfThingsDeleted += deleteProductAliases(fbsConn, lexiconProductAliasPubkeys);
         return numOfThingsDeleted;
      }
      finally {
         fbsConn.close();
      }
   }

   private String getLexiconProductPubkey(PersistentStoreConnection lexConn)
      throws WrappingException
   {
      MonsantoProductPubkeyByPreComlName lookup = new MonsantoProductPubkeyByPreComlName();
      return lookup.getMonsantoProductPubkey(lexConn, precomlName);
   }

   private String[] getLexiconProductAliasPubkeys(PersistentStoreConnection lexConn, String lexiconProductPubkey)
      throws WrappingException
   {
      MonsantoProductAliasPubkeysByProductPubkey lookup = new MonsantoProductAliasPubkeysByProductPubkey();
      return lookup.getLexiconProductAliasPubkeys(lexConn, lexiconProductPubkey);
   }

   private int deleteProduct(PersistentStoreConnection fbsConn, String lexiconProductPubkey)
      throws WrappingException
   {
      DeleteFBSCommonProductByLexPubkey destroyer = new DeleteFBSCommonProductByLexPubkey();
      return destroyer.deleteProduct(fbsConn, lexiconProductPubkey);
   }

   private int deleteProductAliases(PersistentStoreConnection fbsConn, String[] lexiconProductAliasPubkeys)
      throws WrappingException
   {
      DeleteFBSCommonProductAliasesByLexProductAliasPubkeys destroyer = new DeleteFBSCommonProductAliasesByLexProductAliasPubkeys();
      return destroyer.deleteProductAliases(fbsConn, lexiconProductAliasPubkeys);
   }
}
