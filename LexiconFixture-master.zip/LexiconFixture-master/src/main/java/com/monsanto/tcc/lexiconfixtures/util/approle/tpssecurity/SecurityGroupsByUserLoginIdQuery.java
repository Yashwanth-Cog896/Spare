package com.monsanto.tcc.lexiconfixtures.util.approle.tpssecurity;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tcc.lexiconcommon.exception.RuntimeWrappingException;
import com.monsanto.tcc.lexiconfixtures.data.factories.spsecurity.SpsecurityConnectionFactoryProperties;

import java.util.List;

/**
 * nbwald - Jul 14, 2009 11:18:13 AM
*/
public class SecurityGroupsByUserLoginIdQuery
   extends AbstractPersistentStoreMultiRowQuery
{
   private final String userLoginId;

   public SecurityGroupsByUserLoginIdQuery(String userLoginId) {
      this.userLoginId = userLoginId;
   }

   public List<String> find() {
      try {
         return getList();
      }
      catch (WrappingException e) {
         throw new RuntimeWrappingException(e);
      }
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return row.getString(1);
   }

   protected String getSQL()
      throws WrappingException
   {
      return
         "     select CPG.name" +
         "       from FBS_Common.SPS_User_Description UD" +
         " inner join FBS_Common.SPS_User U on (UD.user_description_id = U.user_description_id)" +
         " inner join FBS_Common.SPS_User_Context_Priv_Group UCPG on (U.user_id = UCPG.user_id)" +
         " inner join FBS_Common.SPS_Context_Priv_Group CPG on (UCPG.context_priv_group_id = CPG.context_priv_group_id)" +
         " inner join FBS_Common.SPS_Environment E on (CPG.environment_id = E.environment_id)" +
         "      where e.name = 'LEXICON'" +
         "        and UD.username = ?" +
         "   order by CPG.name";
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { userLoginId };
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new SpsecurityConnectionFactoryProperties();
   }
}
