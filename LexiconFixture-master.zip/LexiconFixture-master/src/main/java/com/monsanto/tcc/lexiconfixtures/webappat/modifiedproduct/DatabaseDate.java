package com.monsanto.tcc.lexiconfixtures.webappat.modifiedproduct;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.Date;

/**
 * nbwald - Sep 15, 2008 6:48:11 PM
 */
public class DatabaseDate
{
   public Date parse(String dateString)
      throws ParseException
   {
      DateFormat formatter = new SimpleDateFormat("yy/MM/dd:k:m:s");
      return formatter.parse(dateString);
   }

   public String render(Date date) {
      DateFormat formatter = new SimpleDateFormat("yyyy/MM/dd:kk:mm:ss");
      return formatter.format(date);
   }
}
