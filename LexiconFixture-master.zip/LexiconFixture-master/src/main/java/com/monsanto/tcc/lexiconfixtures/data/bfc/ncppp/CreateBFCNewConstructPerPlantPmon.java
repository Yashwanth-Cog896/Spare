package com.monsanto.tcc.lexiconfixtures.data.bfc.ncppp;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreInsert;
import com.monsanto.tcc.lexiconfixtures.data.factories.bfc.BFCConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * User: pjberry
 * Date: Aug 2, 2007
 * Time: 5:32:25 PM
 */
public class CreateBFCNewConstructPerPlantPmon
   extends SymbolAcceptingColumnFixture
{
   public String pmon;
   public String transcode;
   public String crop;

   public boolean created()
      throws WrappingException
   {
      BFCNewConstructPerPlantPmonDataInsert dataInsert = new BFCNewConstructPerPlantPmonDataInsert();
      return dataInsert.performInsert() == 1;
   }

   private class BFCNewConstructPerPlantPmonDataInsert
      extends AbstractPersistentStoreInsert
   {

      protected String getSQL()
         throws WrappingException
      {
         return
            "INSERT INTO Regulatory.new_construct_per_plant_pmon (pmon, trans_code, crop_id) " +
            "VALUES " +
            "(?, ?, (SELECT C.crop_id FROM Regulatory.crop C WHERE UPPER(C.common_name) = UPPER(?)) )";
      }

      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[] {pmon, transcode, crop};
      }

      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new BFCConnectionFactoryProperties();
      }
   }
}
