/*
 RegulatorySeedMaterialFixture was created on Feb 14, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.serviceat.seedproduct;

import com.monsanto.tcc.lexiconcommon.DocumentCreator;
import com.monsanto.tcc.lexiconcommon.pos.LexiconPOSConnection;
import com.monsanto.tcc.lexiconcommon.pos.SecurityProxyFactory;
import com.monsanto.tcc.lexiconcommon.service.aggregateproduct.AggregateProductSchemaConstants;
import com.monsanto.tcc.lexiconfixtures.util.symbol.LongParseDelagate;
import com.monsanto.tcc.lexiconfixtures.util.symbol.StringParseDelagate;
import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.POSClient.POSCommunicationException;
import com.monsanto.POSClient.POSConnection;
import com.monsanto.POSClient.POSException;
import com.monsanto.POSClient.POSResult;
import com.monsanto.POSClient.POSResultDocumentProcessor;
import com.monsanto.XMLUtil.DOMUtil;
import fit.Fixture;
import fitlibrary.DoFixture;
import org.ietf.jgss.GSSException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * nbwald Feb 14, 2007 4:03:10 PM
 */
public class RegulatorySeedMaterialFixture
   extends DoFixture
{
   private Document responseDocument;

   public RegulatorySeedMaterialFixture() {
      registerParseDelegate(String.class, new StringParseDelagate());
      registerParseDelegate(Long.class, new LongParseDelagate());
   }

   public boolean query(String name)
      throws GSSException, POSException, POSCommunicationException
   {
      SecurityProxyFactory.getInstance().setThreadProxy(new KerberosStandaloneCredential());
      Document requestDoc = buildRequestDocument(name);
      try {
         //try...  
         responseDocument = getResponse(requestDoc);
      }
      catch (POSCommunicationException e) {
         //try again...
         responseDocument = getResponse(requestDoc);
      }
      DOMUtil.outputXML(responseDocument);
      return true;
   }

   public Fixture checkSeedProductData() {
      return new SeedProductRowFixture(responseDocument);
   }

   private Document buildRequestDocument(String name) {
      Document requestDoc = new DocumentCreator()
         .createDocument(AggregateProductSchemaConstants.NAMESPACE, AggregateProductSchemaConstants.REQUEST_ELEM);
      Element rootElem = requestDoc.getDocumentElement();
      DOMUtil.addChildElementWithNS(AggregateProductSchemaConstants.NAMESPACE, rootElem, AggregateProductSchemaConstants.NAME_ELEM_NAME, name);
      return requestDoc;
   }

   private Document getResponse(Document requestDocument)
      throws POSCommunicationException, POSException
   {
      POSConnection conn = new LexiconPOSConnection();
      POSResult result = conn.callService("Lex_GetRegulatorySeedMaterial", requestDocument);
      return new POSResultDocumentProcessor().getDocument(result);
   }
}