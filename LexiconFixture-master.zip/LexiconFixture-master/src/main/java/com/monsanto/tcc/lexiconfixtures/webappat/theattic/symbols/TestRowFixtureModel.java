package com.monsanto.tcc.lexiconfixtures.webappat.theattic.symbols;

/**
 * Created by IntelliJ IXA.
* User: jaskidi
* Date: Apr 3, 2007
* Time: 1:11:15 PM
* To change this template use File | Settings | File Templates.
*/
public class TestRowFixtureModel
{
   public String id;
   public String name;
   public String value;

   public TestRowFixtureModel(Long id, String name, Long value) {
      this.id = Long.toString(id.longValue());
      this.name = name;
      this.value = getNullableLongAsString(value);
   }

   private String getNullableLongAsString(Long l) {
      return (l == null) ? null : Long.toString(l.longValue());
   }

   public String[] getAsArrayOfValues() {
      return new String[] { id, name, value };
   }
}
