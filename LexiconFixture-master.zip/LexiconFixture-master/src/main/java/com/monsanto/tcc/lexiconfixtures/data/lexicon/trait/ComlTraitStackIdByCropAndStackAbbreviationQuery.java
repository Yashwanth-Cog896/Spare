package com.monsanto.tcc.lexiconfixtures.data.lexicon.trait;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.EmptyResultSetException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetSingleResult;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * User: pjberry
 * Date: May 23, 2007
 * Time: 3:52:15 PM
 */
public class ComlTraitStackIdByCropAndStackAbbreviationQuery
{
   public  Long getTraitStackId(PersistentStoreConnection conn, String crop, String stackAbbr)
      throws WrappingException
   {
      String sql = getTraitStackIdSql();
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, crop);
         stmt.setParam(2, stackAbbr);

         PersistentStoreResultSetSingleResult result = stmt.executeQuery().getSingleResult();
         return result.getLONG(1);
      }
      catch (EmptyResultSetException e) {
         return null;
      }
      finally {
         stmt.close();
      }
   }

   private String getTraitStackIdSql() {
      return
         "SELECT " +
            "CTS.coml_trait_stack_id " +
            "FROM " +
            "Lexicon.Coml_Trait_Stack2 CTS " +
            "WHERE " +
            "CTS.crop_id = (SELECT C.crop_id FROM Lexicon.Crop C WHERE UPPER(C.crop_name) = UPPER(?)) " +
            "AND " +
            "CTS.stack_abbr = ?";
   }
}
