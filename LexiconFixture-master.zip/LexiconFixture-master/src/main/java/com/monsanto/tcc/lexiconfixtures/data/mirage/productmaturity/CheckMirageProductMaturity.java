package com.monsanto.tcc.lexiconfixtures.data.mirage.productmaturity;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreEntityExistsQuery;
import com.monsanto.tcc.lexiconfixtures.data.factories.mirage.MirageConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.data.mirage.product.MirageProductIdLookup;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.EmptyResultSetException;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Jan 29, 2007
 * Time: 10:02:37 AM
 * To change this template use File | Settings | File Templates.
 */
public class CheckMirageProductMaturity
   extends SymbolAcceptingColumnFixture
{
   public String productName;
   public String company;
   public String bayerCode;
   public String country;
   public String maturityRating;

   private Long productId;

   public boolean exists()
      throws WrappingException, EmptyResultSetException
   {
      productId = getProductIdByAttributes();
      MirageProductMaturityExistsQuery query = new MirageProductMaturityExistsQuery();
      return query.entityExists();
   }

   private Long getProductIdByAttributes()
      throws WrappingException
   {
      MirageProductIdLookup lookup = new MirageProductIdLookup(productName, company, country, bayerCode);
      return lookup.getProductId();
   }

   class MirageProductMaturityExistsQuery
      extends AbstractPersistentStoreEntityExistsQuery
   {
      protected String getSQL() throws WrappingException {
         return new SQLPropFile(MirageProductMaturitySQL.class).
            getSQL(MirageProductMaturitySQL.PRODUCT_MATURITY_EXISTS);
      }
      protected Object[] getBindVariables() throws WrappingException {
         return new Object[] { productId, maturityRating };
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new MirageConnectionFactoryProperties();
      }
   }

}
