package com.monsanto.tcc.lexiconfixtures.data.mirage.yieldmart;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.tcc.lexiconfixtures.data.factories.yieldmart.YieldMartConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Mar 21, 2007
 * Time: 5:29:25 PM
 * To change this template use File | Settings | File Templates.
 */
public class CheckYieldMartProduct
   extends SymbolAcceptingColumnFixture
{
   public Long seedProductId;

   public boolean exists()
      throws WrappingException
   {
      return new MapProductMirageByMirageIdQuery(seedProductId).recordExists();
   }
}

class MapProductMirageByMirageIdQuery
   extends AbstractPersistentStoreSingleResultQuery
{
   private final Long seedProductId;

   public MapProductMirageByMirageIdQuery(Long seedProductId) {
      this.seedProductId = seedProductId;
   }

   public boolean recordExists()
      throws WrappingException
   {
      return super.execute() != null;
   }
   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return Boolean.TRUE;
   }
   protected String getSQL()
      throws WrappingException
   {
      return "SELECT * FROM YldStg.Map_Product_Mirage WHERE seed_product_id = ?";
   }
   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { seedProductId };
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new YieldMartConnectionFactoryProperties();
   }
}
