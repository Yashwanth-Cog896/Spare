package com.monsanto.tcc.lexiconfixtures.util.symbol;

import fit.Fixture;

/**
 * Created by IntelliJ IXA.
 * User: JASKIDI
 * Date: Apr 4, 2007
 * Time: 1:12:44 AM
 * To change this template use File | Settings | File Templates.
 */
public abstract class SymbolProcessingParseDelagate
{
   public static final String SYMBOL_PREFIX = "@";
   public static final String NULL_STRING = "null";
   public static final String BLANK_STRING = "blank";
   
   protected Object baseParse(String s)
   {
      if (s == null || NULL_STRING.equalsIgnoreCase(s)) {
         return null;
      }
      else if (s.startsWith(SYMBOL_PREFIX)) {
         Object symbolValue = Fixture.getSymbol(s);
         return (symbolValue == null) ? null : createObjectFromSymbolValue(symbolValue);
      }
      else {
         Object processedObject = specificValueHandlingHook(s);
         return (processedObject != null) ? processedObject : createObjectFromString(s);
      }
   }

   protected abstract Object createObjectFromSymbolValue(Object symbolValue);
   protected abstract Object createObjectFromString(String s);
   protected Object specificValueHandlingHook(String s) {
      return null;
   }
}
