package com.monsanto.tcc.lexiconfixtures.data.midas.geneticmaterial;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreInsert;
import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 7, 2006
 * Time: 4:28:32 PM
 */
public class CreateGeneticMaterial
   extends SymbolAcceptingColumnFixture
{
   public Long geneticMaterialId;
   public String source;
   public String lineage;
   public String generation;
   public Long germplasmId;

   public boolean created()
      throws WrappingException
   {
      GeneticMaterialInsert dataMod = new GeneticMaterialInsert();
      return dataMod.performInsert() == 1;
   }

   class GeneticMaterialInsert
      extends AbstractPersistentStoreInsert
   {
      protected String getSQL() throws WrappingException {
         return new SQLPropFile(GeneticMaterialFixtureSQL.class).getSQL(GeneticMaterialFixtureSQL.INSERT_GENETIC_MATERIAL);
      }
      protected Object[] getBindVariables() throws WrappingException {
         return new Object[] { geneticMaterialId, source, lineage, generation, germplasmId};
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new MidasConnectionFactoryProperties();
      }
   }
}

