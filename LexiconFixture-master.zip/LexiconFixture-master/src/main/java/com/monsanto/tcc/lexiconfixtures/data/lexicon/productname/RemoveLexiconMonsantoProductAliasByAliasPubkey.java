package com.monsanto.tcc.lexiconfixtures.data.lexicon.productname;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.test.LexiconTestTools;
import com.monsanto.tcc.lexiconcommon.db.audit.LexiconAuditor;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactory;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Dec 18, 2006
 * Time: 5:52:13 PM
 * To change this template use File | Settings | File Templates.
 */
public class RemoveLexiconMonsantoProductAliasByAliasPubkey
{
   private  String productStagePubkey;

   private SQLPropFile sqlPropFile = new SQLPropFile(LexiconProductNameFixtureSQL.class);

   public RemoveLexiconMonsantoProductAliasByAliasPubkey(String productStagePubkey) {
      this.productStagePubkey = productStagePubkey;
   }

   public int remove()
      throws WrappingException
   {
      LexiconConnectionFactory connectionFactory = new LexiconConnectionFactory();
      PersistentStoreConnection conn = connectionFactory.getConnection();
      LexiconAuditor lexiconAuditor = LexiconTestTools.FITNESSE_TEST_AUDITOR;
      lexiconAuditor.initializeStaging(conn);
      try {
         return deleteFakeData(conn);
      }
      finally {
         lexiconAuditor.removeStaging(conn);
         conn.close();
      }
   }

   private int deleteFakeData(PersistentStoreConnection conn)
      throws WrappingException
   {
      String sql = sqlPropFile.getSQL(LexiconProductNameFixtureSQL.DELETE_PRODUCT_NAME);
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, productStagePubkey);
         return stmt.executeDelete();
      }
      finally {
         stmt.close();
      }
   }
}
