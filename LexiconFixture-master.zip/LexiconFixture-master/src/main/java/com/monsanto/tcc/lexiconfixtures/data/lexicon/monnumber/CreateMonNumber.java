package com.monsanto.tcc.lexiconfixtures.data.lexicon.monnumber;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.ColumnFixtureResetter;
import com.monsanto.tcc.lexiconfixtures.util.LexiconDataFixtureInsert;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.dbdataservices.SQLUtil;

import java.util.Random;

/**
 * nbwald - Jan 26, 2009 1:02:11 PM
 */
public class CreateMonNumber
   extends SymbolAcceptingColumnFixture
{
   public String monNumber;
   public String crop;
   public String event;
   public String plasmidPmon;
   public String plasmidPvcode;
   public String transformationBackground;

   @Override
   public void reset()
      throws Exception
   {
      ColumnFixtureResetter.reset(this);
   }

   public boolean created()
      throws WrappingException
   {
      return new MonNumberInsert().performInsert() == 1;
   }

   private class MonNumberInsert
      extends LexiconDataFixtureInsert
   {
      @Override
      protected String getSQL()
         throws WrappingException
      {
         return
            "INSERT INTO Lexicon.Mon_Number " +
            " (mon_number_id, mon_number, crop, event, plasmid_pmon, plasmid_pvcode, transformation_background, regulatory_trait_description, regulatory_genes_present, active_status)" +
            " VALUES" +
            " (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
      }

      @Override
      protected Object[] getBindVariables()
         throws WrappingException
      {
         long monNumberId = -new Random().nextLong();
         return new Object[] {
            monNumberId,
            monNumber,
            crop,
            event,
            plasmidPmon,
            plasmidPvcode,
            transformationBackground,
            "Insect Resistant",
            "cry1Ab",
            SQLUtil.booleanToString(true)
         };
      }

      @Override
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new LexiconConnectionFactoryProperties();
      }
   }
}
