package com.monsanto.tcc.lexiconfixtures.data.fbscommon.allinfo;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.EmptyResultSetException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetSingleResult;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Mar 19, 2007
 * Time: 11:48:27 AM
 * To change this template use File | Settings | File Templates.
 */
public class MonsantoProductPubkeyByPreComlName
{
   private final String sql = "SELECT PCP.product_pubkey FROM Lexicon.pre_coml_product PCP WHERE PCP.pre_coml_name = ?";

   public String getMonsantoProductPubkey(PersistentStoreConnection lexConn, String precomlName)
      throws WrappingException
   {
      PersistentStoreStatement stmt = lexConn.prepareStatement(sql);
      try {
         stmt.setParam(1, precomlName);
         PersistentStoreResultSetSingleResult result = stmt.executeQuery().getSingleResult();
         return result.getString(1);
      }
      catch (EmptyResultSetException e) {
         return null;
      }
      finally {
         stmt.close();
      }
   }
}
