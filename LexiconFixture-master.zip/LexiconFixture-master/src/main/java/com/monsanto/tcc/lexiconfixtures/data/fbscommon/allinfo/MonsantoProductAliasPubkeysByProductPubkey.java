package com.monsanto.tcc.lexiconfixtures.data.fbscommon.allinfo;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.dataservices.PersistentStoreStatement;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Mar 19, 2007
 * Time: 11:51:57 AM
 * To change this template use File | Settings | File Templates.
 */
public class MonsantoProductAliasPubkeysByProductPubkey
{
   private final String sql = "SELECT PS.product_stage_pubkey FROM Lexicon.product_stage PS, Lexicon.pre_coml_product PCP WHERE PS.product_id = PCP.product_id AND PCP.product_pubkey = ?";

   public String[] getLexiconProductAliasPubkeys(PersistentStoreConnection lexConn, String lexiconProductPubkey)
      throws WrappingException
   {
      PersistentStoreStatement stmt = lexConn.prepareStatement(sql);
      try {
         stmt.setParam(1, lexiconProductPubkey);
         PersistentStoreResultSetFwdIterator result = stmt.executeQuery().getForwardIterator();
         return buildPubkeys(result);
      }
      finally {
         stmt.close();
      }
   }

   private String[] buildPubkeys(PersistentStoreResultSetFwdIterator result)
      throws WrappingException
   {
      Set productAliasPubkeys = new HashSet();
      while (result.next()) {
         productAliasPubkeys.add(result.getString(1));
      }
      return (String[])productAliasPubkeys.toArray(new String[productAliasPubkeys.size()]);
   }
}
