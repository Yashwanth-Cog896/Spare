package com.monsanto.tcc.lexiconfixtures.data.cleanup;

import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Apr 30, 2007
 * Time: 12:10:39 PM
 * To change this template use File | Settings | File Templates.
 */
public class CheckRandomValueData
   extends SymbolAcceptingColumnFixture
{
   public boolean lexStagesExist() throws WrappingException {
      return (new StagePubkeysQuery().getPubkeyList().size() > 0);
   }
   public boolean lexProdsExist() throws WrappingException {
      return (new ProductPubkeysQuery().getPubkeyList().size() > 0);
   }
   public boolean relationshipsExist() throws WrappingException {
      return (new RelationshipPubkeysQuery().getPubkeyList().size() > 0);
   }
   public boolean mirageProdsExist() throws WrappingException {
      return (new MirageProductIdsQuery().getIdList().size() > 0);
   }
   public boolean yieldstageProdsExist() throws WrappingException {
      return (new MapProductMirageIdsQuery().getIdList().size() > 0);
   }
   public boolean parentageExists() throws WrappingException {
      return (new ParentageIdsQuery().getIdList().size() > 0);
   }
   public boolean geneticMaterialExists() throws WrappingException {
      return (new GeneticMaterialIdsQuery().getIdList().size() > 0);
   }
   public boolean germplasmExists() throws WrappingException {
      return (new GermplasmIdsQuery().getIdList().size() > 0);
   }
   public boolean midasProdNamesExist() throws WrappingException {
      return (new MidasProductNameIdsQuery().getIdList().size() > 0);
   }
   public boolean midasProdsExist() throws WrappingException {
      return (new MidasProductIdsQuery().getIdList().size() > 0);
   }
}

