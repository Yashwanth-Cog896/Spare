package com.monsanto.tcc.lexiconfixtures.util.symbol;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Mar 29, 2007
 * Time: 5:09:32 PM
 * To change this template use File | Settings | File Templates.
 */
public class SetSymbolNumericValue
   extends SymbolAcceptingColumnFixture
{
   public Long givenValue;

   public Long symbolValue() {
      return givenValue;
   }
}
