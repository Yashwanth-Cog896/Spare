package com.monsanto.tcc.lexiconfixtures.data.lexicon.productrelationship;

import com.monsanto.tcc.lexiconcommon.db.audit.LexiconAuditor;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactory;
import com.monsanto.tcc.lexiconcommon.db.test.LexiconTestTools;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.EmptyResultSetException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetSingleResult;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 14, 2006
 * Time: 2:54:23 PM
 */
public class CreateProductRelationship
   extends SymbolAcceptingColumnFixture
{
   public Long productRelationshipId;
   public String productRelationshipPubkey;
   public String manufacturingName;
   public boolean logicalDelete;
   public String baseManufacturingName;
   public String varietyName;

   public void reset()
      throws Exception
   {
      super.reset();
      productRelationshipId = null;
      productRelationshipPubkey = null;
      manufacturingName = null;
      logicalDelete = false;
      baseManufacturingName = null;
      varietyName = null;
   }

   public boolean created()
      throws WrappingException
   {
      LexiconConnectionFactory connectionFactory = new LexiconConnectionFactory();
      PersistentStoreConnection conn = connectionFactory.getConnection();
      LexiconAuditor lexiconAuditor = LexiconTestTools.FITNESSE_TEST_AUDITOR;
      lexiconAuditor.initializeStaging(conn);
      try {
         LexiconTestTools.insertFakeProductRelationship(conn, productRelationshipId, productRelationshipPubkey, manufacturingName, logicalDelete, getBaseProductId(conn), varietyName);
         return true;
      }
      finally {
         lexiconAuditor.removeStaging(conn);
         conn.close();
      }
   }

   private Long getBaseProductId(PersistentStoreConnection conn)
      throws WrappingException
   {
      String sql = "SELECT BP.base_product_id FROM Lexicon.base_product BP WHERE BP.base_manufacturing_name = ?";
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, baseManufacturingName);
         PersistentStoreResultSetSingleResult result = stmt.executeQuery().getSingleResult();
         return result.getLONG(1);
      }
      catch (EmptyResultSetException e) {
         return null;
      }
      finally {
         stmt.close();
      }
   }
 }

