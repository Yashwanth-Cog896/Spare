package com.monsanto.tcc.lexiconfixtures.serviceat.externalcontact;

import com.monsanto.tps.lexicon.contact.SearchableLocation;
import com.monsanto.tps.lexicon.contact.service.ExternalContacts;
import com.monsanto.tps.lexicon.contact.service.ExternalContactsImpl;
import com.monsanto.tps.lexicon.person.ExternalContactByBusinessGeographySearchCriteria;
import com.monsanto.tps.lexicon.person.ExternalContactSearchCriteria;
import com.monsanto.tps.lexicon.person.ExternalContact;
import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import fit.Fixture;
import fitlibrary.DoFixture;
import org.ietf.jgss.GSSException;

/**
 * nbwald - Aug 1, 2008 5:57:22 PM
 */
public class ExternalContactByBusinessAccountGeographyFixture
   extends DoFixture
{
   private ExternalContactSearchCriteria criteria = new ExternalContactSearchCriteria();
   private SearchableLocation location = new SearchableLocation();

   private ExternalContact[] externalContacts;
   private String errorMessage;

   public boolean firstName(String firstName) {
      criteria.setFirstName(firstName);
      return true;
   }

   public boolean lastName(String lastName) {
      criteria.setLastName(lastName);
      return true;
   }

   public boolean contactType(String contactType) {
      criteria.setContactType(contactType);
      return true;
   }

   public boolean companyName(String companyName) {
      criteria.setCompanyName(companyName);
      return true;
   }

   public boolean country(String country) {
      location.setCountryName(country);
      return true;
   }

   public boolean subCountry(String subcountry) {
      location.setSubcountryCode(subcountry);
      return true;
   }

   public boolean subSubCountry(String subsubcountry) {
      location.setSubsubcountryName(subsubcountry);
      return true;
   }

   public boolean city(String city) {
      location.setCity(city);
      return true;
   }

   public boolean search()
      throws GSSException
   {
      criteria.setLocation(location);
      ExternalContactByBusinessGeographySearchCriteria criteriaWrapper = new ExternalContactByBusinessGeographySearchCriteria();
      criteriaWrapper.setExternalContactSearchCriteria(criteria);
      ExternalContacts externalContactClient = new ExternalContactsImpl(new KerberosStandaloneCredential());
      try {
         this.externalContacts = externalContactClient.findByCriteria(criteriaWrapper);
      }
      catch(Exception e) {
         errorMessage = e.getMessage();
      }
      return true;
   }

   public int numberOfExternalContactsFound() {
      return externalContacts == null ? 0 : externalContacts.length;
   }

   public String errorMessageIs() {
      return errorMessage;
   }

   public Fixture checkResults() {
      return new ExternalContactAdaptorRowFixture(externalContacts);
   }
}
