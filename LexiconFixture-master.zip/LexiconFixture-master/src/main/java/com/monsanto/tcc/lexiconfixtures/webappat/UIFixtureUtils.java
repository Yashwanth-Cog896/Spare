package com.monsanto.tcc.lexiconfixtures.webappat;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 15, 2006
 * Time: 2:10:44 PM
 * To change this template use File | Settings | File Templates.
 */
public class UIFixtureUtils
{
   public static String colorFromClassName(String className) {
      if("greyback".equals(className) || "ready".equals(className)) return "grey";
      if("cyanback".equals(className) || "editing".equals(className)) return "blue";
      if("yellowback".equals(className) || "validated".equals(className)) return "yellow";
      if("greenback".equals(className) || "committed".equals(className)) return "green";
      if("redback".equals(className) || "erred".equals(className)) return "red";
      return "Error: cannot find color discription for class with name '" +  className + "'";
   }
}
