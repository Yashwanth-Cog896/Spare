/*
 CropFixture was created on Jul 7, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tcc.lexiconfixtures.serviceat.crop;

import com.monsanto.tps.lexicon.crop.Crop;
import com.monsanto.tps.lexicon.crop.BayerCode;
import com.monsanto.tps.lexicon.crop.ScientificName;

/**
 * @author GGSHIV - Jul 7, 2008 9:19:34 AM
 */
public class CropResponseAdaptor
{
   public String publicKey;
   public String name;
   public String abbreviation;
   public String shippingStatement;
   public String bayerCode;
   public String bayerCodePublicKey;
   public String scientificName;
   public String bayerCodeGenusSpeciePubKey;

   public CropResponseAdaptor(Crop crop, BayerCode bayerCode, ScientificName scientificName) {
      saveCropFields(crop);
      saveBayerCodeFields(bayerCode);
      saveScientificNameFields(scientificName);
   }

   private void saveScientificNameFields(ScientificName scientificName) {
      this.scientificName = scientificName.getName();
      this.bayerCodeGenusSpeciePubKey = scientificName.getPublicKey();
   }

   private void saveBayerCodeFields(BayerCode bayerCode) {
      this.bayerCode = bayerCode.getCode();
      this.bayerCodePublicKey = bayerCode.getPublicKey();
   }

   private void saveCropFields(Crop crop) {
      this.publicKey = crop.getPublicKey();
      this.name = crop.getName();
      this.abbreviation = crop.getAbbreviation();
      this.shippingStatement = crop.getShippingStatement();
   }
}