package com.monsanto.tcc.lexiconfixtures.data.lexicon.productflowcriteria;

import com.monsanto.tcc.lexiconcommon.exception.RuntimeWrappingException;
import com.monsanto.tcc.lexiconcommon.service.artemis.productflow.ProductFlowCriteria;
import com.monsanto.tcc.lexiconcommon.service.artemis.productflow.ProductFlowCriterion;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingTableFixture;

/**
 * nbwald - Mar 18, 2008 10:41:57 AM
 */
public class SetSapSubscriptionCriteria
   extends SymbolAcceptingTableFixture
{
   private static final int CROP_PUBKEY_COLUMN = 0;
   private static final int COUNTRY_PUBKEY_COLUMN = 1;
   private static final int STAGE_PUBKEY_COLUMN = 2;

   protected void doStaticTable(int numRows) {
      checkTableHeader();
      ProductFlowCriteria criteria = readCriteriaFromTable(numRows);
      saveCriteria(criteria);
   }

   private void checkTableHeader() {
      assertCellTextIs("crop pubkey", 0, CROP_PUBKEY_COLUMN);
      assertCellTextIs("country pubkey", 0, COUNTRY_PUBKEY_COLUMN);
      assertCellTextIs("stage pubkey", 0, STAGE_PUBKEY_COLUMN);
   }

   private void assertCellTextIs(String expectedText, int row, int column) {
      if(!getText(row, column).equalsIgnoreCase(expectedText)) {
         wrong(row, column);
      }
   }

   private void saveCriteria(ProductFlowCriteria criteria)
   {
      try {
         ProductFlowCriteriaTestTool.setCriteria(criteria);
      }
      catch (Exception e) {
         throw new RuntimeWrappingException(e);
      }
   }

   private ProductFlowCriteria readCriteriaFromTable(int numRows) {
      ProductFlowCriteria criteria = new ProductFlowCriteria();
      for(int row = 1; row < numRows; row++) {
         criteria.add(createCriterionFromRow(row));
      }
      return criteria;
   }

   private ProductFlowCriterion createCriterionFromRow(int row) {
      ProductFlowCriterion criterion = new ProductFlowCriterion();
      criterion.setCropPubkey(read(row, CROP_PUBKEY_COLUMN));
      criterion.setCountryPubkey(read(row, COUNTRY_PUBKEY_COLUMN));
      criterion.setStagePubkey(read(row, STAGE_PUBKEY_COLUMN));
      return criterion;
   }

   private String read(int row, int col) {
      right(row, col);
      return getText(row, col);
   }
}
