/*
 CreateBaseProductWithoutIdDoFixture was created on Dec 4, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.webappat.theattic;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo.cascadingdelete.query.delete.BaseProductDelete;
import com.monsanto.tcc.lexiconfixtures.data.lexicon.baseproduct.BaseProductFixtureSQL;
import com.monsanto.tcc.lexiconfixtures.util.LexiconDataFixtureInsert;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingDoFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dbdataservices.SQLUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * nbwald Dec 4, 2007 3:12:54 PM
 */
public class CreateBaseProductWithoutIdDoFixture
   extends SymbolAcceptingDoFixture
{
   private final List<Long> baseProductIdsToTearDown = new ArrayList<Long>();

   public boolean createABaseProductWithBaseManufacturingNameWithCropNameWithParentProduct(String baseManufacturingName, String cropName, boolean parentProduct)
      throws WrappingException
   {
      Long id = generateNewId();
      baseProductIdsToTearDown.add(id);
      return new BaseProductInsert(id, baseManufacturingName, cropName, parentProduct).performInsert() == 1;
   }

   public boolean removeCreatedBaseProducts()
      throws WrappingException
   {
      boolean success = true;
      for (Long baseProductId : baseProductIdsToTearDown) {
         success &= new BaseProductDelete(baseProductId).performDelete() == 1;
      }
      return success;
   }

   class BaseProductInsert
      extends LexiconDataFixtureInsert
   {
      private final long id;
      private final String baseManufacturingName;
      private final String cropName;
      private final boolean parentProduct;

      BaseProductInsert(long id, String baseManufacturingName, String cropName, boolean parentProduct) {
         this.id = id;
         this.baseManufacturingName = baseManufacturingName;
         this.cropName = cropName;
         this.parentProduct = parentProduct;
      }
      protected String getSQL() throws WrappingException
      {
         return new SQLPropFile(BaseProductFixtureSQL.class).getSQL(BaseProductFixtureSQL.INSERT_BASE_PRODUCT);
      }
      protected Object[] getBindVariables() throws WrappingException {
         return new Object[] {id, baseManufacturingName, cropName, SQLUtil.booleanToString(parentProduct) };
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new LexiconConnectionFactoryProperties();
      }
   }

   private Long generateNewId() {
      return new Long(-Math.abs(new Random().nextLong()));
   }
}