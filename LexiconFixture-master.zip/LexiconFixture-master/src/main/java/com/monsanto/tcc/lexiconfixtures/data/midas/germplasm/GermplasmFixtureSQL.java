package com.monsanto.tcc.lexiconfixtures.data.midas.germplasm;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 13, 2006
 * Time: 10:31:08 AM
 * To change this template use File | Settings | File Templates.
 */
public interface GermplasmFixtureSQL
{
   String INSERT_GERMPLASM = "InsertGermplasm";
   String DELETE_GERMPLASM = "DeleteGermplasm";
   String SELECT_GERMPLASM = "SelectGermplasm";
}
