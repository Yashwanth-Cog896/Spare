package com.monsanto.tcc.lexiconfixtures.serviceat.agency;

import com.monsanto.tps.lexicon.agency.Agency;
import com.monsanto.tps.lexicon.agency.AgencyDepartment;

/**
 * rrchak1 - Oct 23, 2008 4:19:17 PM
 */
public class AgencyAdaptor
{
   public String agencyAbbreviation;
   public String agencyId;
   public String agencyName;
   public String agencyPublickey;
   public String countryIsoCode;
   public String surfaceAreaUomCode;
   public boolean departmentActive;
   public String address1;
   public String address2;
   public String departmentAbbreviation;
   public String departmentId;
   public String departmentName;
   public String departmentPubkey;
   public String city;
   public String postalCode;
   public String subCountryCode;
   public String departmentSubSubCountryName;
   public boolean isActive;


   public AgencyAdaptor(Agency agency, AgencyDepartment department) {
      agencyAbbreviation =agency.getAgencyAbbr();
      agencyId= String.valueOf(agency.getAgencyId());
      agencyName=agency.getAgencyName();
      agencyPublickey =agency.getAgencyPubkey();
      countryIsoCode =agency.getCountryIsoCode();
      surfaceAreaUomCode=agency.getSurfaceAreaUomCode();
      isActive=agency.isActive();
      loadDepartment(department);
   }

   private void loadDepartment(AgencyDepartment department) {
      departmentActive=department.isActive();
      address1 =department.getAddress1();
      address2 =department.getAddress2();
      departmentAbbreviation=department.getAgencyDeptAbbr();
      departmentId= String.valueOf(department.getAgencyDeptId());
      departmentName=department.getAgencyDeptName();
      departmentPubkey=department.getAgencyDeptPubkey();
      city =department.getCity();
      postalCode =department.getPostalCode();
      subCountryCode =department.getSubCountryAbbr();
      departmentSubSubCountryName=department.getSubSubCountryName();
   }
}
