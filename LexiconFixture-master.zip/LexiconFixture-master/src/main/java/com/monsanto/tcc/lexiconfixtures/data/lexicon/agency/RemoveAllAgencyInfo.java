package com.monsanto.tcc.lexiconfixtures.data.lexicon.agency;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.LexiconDataFixtureDelete;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;

/**
 * nbwald - Dec 1, 2008 5:41:30 PM
 */
public class RemoveAllAgencyInfo
   extends SymbolAcceptingColumnFixture
{
   public String publicKey;

   public boolean removed()
      throws WrappingException
   {
      return removedAgencyDepartments() && removedAgency();
   }

   private boolean removedAgency()
      throws WrappingException
   {
      AgencyDelete deleter = new AgencyDelete();
      return deleter.performDelete() == 1;
   }

   private boolean removedAgencyDepartments()
      throws WrappingException
   {
      AgencyDepartmentDelete deleter = new AgencyDepartmentDelete();
      return deleter.performDelete() > 0;
   }


   private class AgencyDelete
      extends LexiconDataFixtureDelete
   {
      protected String getSQL()
         throws WrappingException
      {
         return "DELETE FROM Lexicon.Agency WHERE agency_pubkey = ?";
      }

      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[] { publicKey };
      }

      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new LexiconConnectionFactoryProperties();
      }
   }

   private class AgencyDepartmentDelete
      extends LexiconDataFixtureDelete
   {
      protected String getSQL()
         throws WrappingException
      {
         return "DELETE FROM Lexicon.Agency_Department WHERE agency_id = (SELECT agency_id FROM Lexicon.Agency WHERE agency_pubkey = ?)";
      }

      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[] { publicKey };
      }

      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new LexiconConnectionFactoryProperties();
      }
   }
}
