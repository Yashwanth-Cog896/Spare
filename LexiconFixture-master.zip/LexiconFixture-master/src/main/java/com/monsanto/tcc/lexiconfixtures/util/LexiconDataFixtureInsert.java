package com.monsanto.tcc.lexiconfixtures.util;

import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreInsert;
import com.monsanto.tcc.lexiconcommon.db.test.LexiconTestTools;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jun 29, 2007
 * Time: 10:52:10 AM
 */
public abstract class LexiconDataFixtureInsert
   extends AbstractPersistentStoreInsert
{
   @Override
   protected Object execute(PersistentStoreConnection conn)
      throws WrappingException
   {
      LexiconTestTools.FITNESSE_TEST_AUDITOR.initializeStaging(conn);
      return super.execute(conn);
   }

   @Override
   protected void closeConnection(PersistentStoreConnection conn)
      throws WrappingException
   {
      LexiconTestTools.FITNESSE_TEST_AUDITOR.removeStaging(conn);
      super.closeConnection(conn);
   }
}
