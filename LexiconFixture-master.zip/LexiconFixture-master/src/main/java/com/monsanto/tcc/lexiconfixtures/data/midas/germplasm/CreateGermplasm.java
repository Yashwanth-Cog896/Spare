package com.monsanto.tcc.lexiconfixtures.data.midas.germplasm;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreInsert;
import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 7, 2006
 * Time: 3:48:34 PM
 */
public class CreateGermplasm
   extends SymbolAcceptingColumnFixture
{
   public Long germplasmId;
   public String crop;
   public String pedigree;
   public String origin;
   public String lineCode;
   public String lineType;
   public boolean transgenic;
   public boolean finishedOrFinishedChild;
   public String transformationGenotype;

   public boolean created()
      throws WrappingException
   {
      MidasGermplasmInsert dataMod = new MidasGermplasmInsert();
      return dataMod.performInsert() == 1;
   }

   private class MidasGermplasmInsert
      extends AbstractPersistentStoreInsert
   {
      protected String getSQL() throws WrappingException {
         return new SQLPropFile(GermplasmFixtureSQL.class).getSQL(GermplasmFixtureSQL.INSERT_GERMPLASM);
      }
      protected Object[] getBindVariables() throws WrappingException {
         return new Object[] { germplasmId, crop, pedigree, origin, lineCode, lineType,
            transgenic ? "T" : "F",
            finishedOrFinishedChild ? "T" : "F",
            transformationGenotype,
            crop
         };
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new MidasConnectionFactoryProperties();
      }
   }
}
