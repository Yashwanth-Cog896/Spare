package com.monsanto.tcc.lexiconfixtures.data.lexicon.productname;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Dec 15, 2006
 * Time: 11:22:15 AM
 * To change this template use File | Settings | File Templates.
 */
public class LexiconProductAliasPubkeyLookup
   extends AbstractPersistentStoreSingleResultQuery
{
   private String preComlName;
   private String commercialName;
   private String brandName;
   private String countryName;

   public LexiconProductAliasPubkeyLookup(String precomlName, String commercialName, String brandName, String countryName) {
      this.preComlName = precomlName;
      this.commercialName = StringUtils.isNullOrEmpty(commercialName) ? "NULL" : commercialName;
      this.brandName = StringUtils.toUpperCaseNull(brandName);
      this.countryName = StringUtils.toUpperCaseNull(countryName);
   }

   public String getPubkey() throws WrappingException {
      return (String)execute();
   }
   protected Object createObjectFromRow(PersistentStoreResultSetRow row) throws WrappingException {
      return row.getString(1);
   }
   protected String getSQL()  throws WrappingException {
      return new SQLPropFile(LexiconProductNameFixtureSQL.class).
         getSQL(LexiconProductNameFixtureSQL.SELECT_PRODUCT_ALIAS_ID_BY_CRITERIA);
   }
   protected Object[] getBindVariables() throws WrappingException {
      return new Object[] { preComlName, brandName, countryName, commercialName };
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
}
