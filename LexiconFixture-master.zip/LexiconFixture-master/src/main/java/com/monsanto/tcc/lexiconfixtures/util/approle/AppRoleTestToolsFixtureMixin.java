/*
 AppRoleTestToolsFixtureMixin was created on Dec 11, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.util.approle;

import com.monsanto.tcc.lexiconfixtures.util.UserHelper;
import fit.Fixture;
import static com.monsanto.tcc.lexiconfixtures.util.approle.AppRoleTestTools.*;

import java.util.List;

/**
 * nbwald Dec 11, 2007 12:09:33 PM
 */
public class AppRoleTestToolsFixtureMixin
{
   private List<String> savedGroupNames;

   public Fixture setApplicationRole() {
      return new AppRoleFixture();
   }

   public boolean saveApplicationRoles()
      throws Exception
   {
      String userLoginId = UserHelper.getCurrentUserLoginId();
      savedGroupNames = findCurrentGroups(userLoginId);
      return true;
   }

   public boolean restoreApplicationRoles()
      throws Exception
   {
      String userLoginId = UserHelper.getCurrentUserLoginId();
      List<String> previousGroupNames = findCurrentGroups(userLoginId);
      removeUserFromAllGroups(userLoginId);
      removeFakeFitnesseGroups(previousGroupNames);
      addUserToGroups(userLoginId, savedGroupNames);
      return true;
   }
}
