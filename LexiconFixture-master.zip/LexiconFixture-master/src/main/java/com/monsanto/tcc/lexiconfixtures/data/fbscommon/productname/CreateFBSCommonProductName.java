package com.monsanto.tcc.lexiconfixtures.data.fbscommon.productname;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreInsert;
import com.monsanto.tcc.lexiconfixtures.data.factories.fbs.FBSCommonConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 9, 2006
 * Time: 1:22:34 PM
 * To change this template use File | Settings | File Templates.
 */
public class CreateFBSCommonProductName
   extends SymbolAcceptingColumnFixture
{
   public String lexiconProductNamePubkey;
   public String midasProductNameId;
   public String mirageProductId;   

   public boolean created()
      throws WrappingException
   {
      InsertDataMod dataMod = new InsertDataMod();
      return dataMod.performInsert() == 1;
   }

   class InsertDataMod
      extends AbstractPersistentStoreInsert
   {
      protected String getSQL()
         throws WrappingException
      {
         return new SQLPropFile(FBSCommonProductNameFixtureSQL.class).
            getSQL(FBSCommonProductNameFixtureSQL.INSERT_PRODUCT_NAME);
      }
      protected Object[] getBindVariables()
         throws WrappingException
      {
         long midasId = (midasProductNameId == null) ? 0 : Long.parseLong(midasProductNameId);
         int mirageId = (mirageProductId == null) ? 0 : Integer.parseInt(mirageProductId);
         return new Object[] { lexiconProductNamePubkey, midasId, midasId, mirageId, mirageId };
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new FBSCommonConnectionFactoryProperties();
      }
   }
}
