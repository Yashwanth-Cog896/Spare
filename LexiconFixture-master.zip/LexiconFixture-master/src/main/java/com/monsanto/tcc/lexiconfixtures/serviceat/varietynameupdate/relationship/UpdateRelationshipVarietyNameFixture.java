/*
 UpdateRelationshipVarietyNameFixture was created on Sep 10, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.serviceat.varietynameupdate.relationship;

import com.monsanto.tcc.lexiconcommon.pos.LexiconServiceInvoker;
import com.monsanto.tcc.lexiconcommon.pos.SecurityProxyFactory;
import com.monsanto.tcc.lexiconcommon.pos.ServiceInvoker;
import com.monsanto.tcc.lexiconcommon.pos.batch.ServiceModelBatchSerializer;
import com.monsanto.tcc.lexiconcommon.service.productrelationship.varietynameupdate.dom.UpdateRelationshipVarietyNameRequestSerializer;
import com.monsanto.tcc.lexiconcommon.service.productrelationship.varietynameupdate.dom.UpdateRelationshipVarietyNameResponseSerializer;
import com.monsanto.tcc.lexiconcommon.service.productrelationship.varietynameupdate.model.UpdateRelationshipVarietyNameRequest;
import com.monsanto.tcc.lexiconcommon.service.productrelationship.varietynameupdate.model.UpdateRelationshipVarietyNameResponse;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingDoFixture;
import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.xmlserialization.DeserializationException;
import com.monsanto.xmlserialization.SerializationException;
import fit.Fixture;
import fitlibrary.ArrayFixture;
import org.ietf.jgss.GSSException;
import org.w3c.dom.Document;
import java.util.Arrays;
import java.util.List;

/**
 * nbwald Sep 10, 2007 9:52:05 AM
 */
public class UpdateRelationshipVarietyNameFixture
   extends SymbolAcceptingDoFixture
{
   private UpdateRelationshipVarietyNameResponse response;

   public boolean updateWithVarietyName(String manufacturingName, String varietyName)
      throws WrappingException, GSSException
   {
      Document requestDoc = serializeRequest(manufacturingName, varietyName);
      Document responseDoc = callService(requestDoc);
      this.response = deserializeResponse(responseDoc);
      return true;
   }

   public Fixture checkUpdateRelationshipVarietyNameServiceResults() {
      return new ArrayFixture(new Object[] { new UnencapsulatedUpdateRelationshipVarietyNameServiceResponse(response) });
   }

   private Document serializeRequest(String manufacturingName, String varietyName)
      throws SerializationException
   {
      ServiceModelBatchSerializer<UpdateRelationshipVarietyNameRequest> requestSerializer = new ServiceModelBatchSerializer<UpdateRelationshipVarietyNameRequest>(new UpdateRelationshipVarietyNameRequestSerializer());
      UpdateRelationshipVarietyNameRequest request = new UpdateRelationshipVarietyNameRequest(manufacturingName, varietyName);
      List<UpdateRelationshipVarietyNameRequest> requestBatch = Arrays.asList(request);
      return requestSerializer.toDocument(requestBatch);
   }

   private Document callService(Document requestDoc)
      throws GSSException, WrappingException
   {
      SecurityProxyFactory.getInstance().setThreadProxy(new KerberosStandaloneCredential());
      ServiceInvoker serviceInvoker = new LexiconServiceInvoker("Lex_UpdateRelationshipVarietyName");
      return serviceInvoker.call(requestDoc);
   }

   private UpdateRelationshipVarietyNameResponse deserializeResponse(Document responseDoc)
      throws DeserializationException
   {
      ServiceModelBatchSerializer<UpdateRelationshipVarietyNameResponse> responseSerializer = new ServiceModelBatchSerializer<UpdateRelationshipVarietyNameResponse>(new UpdateRelationshipVarietyNameResponseSerializer());
      return responseSerializer.fromDocument(responseDoc).get(0);
   }
}