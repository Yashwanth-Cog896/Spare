package com.monsanto.tcc.lexiconfixtures.data.mirage.productmaturity;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Jan 29, 2007
 * Time: 9:56:00 AM
 * To change this template use File | Settings | File Templates.
 */
public interface MirageProductMaturitySQL
{
   String INSERT_MATURITY = "InsertMaturity";
   String PRODUCT_MATURITY_EXISTS = "CheckMaturityExists";
   String DELETE_MATURITY_BY_PRODUCT_ID = "DeleteMaturityByProductId";
}
