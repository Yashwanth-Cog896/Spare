/*
 CreateLexiconBrand was created on Apr 16, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.data.lexicon.brand;

import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactory;
import com.monsanto.tcc.lexiconcommon.db.test.LexiconTestTools;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.dbdataservices.SQLUtil;

/**
 * nbwald Apr 16, 2007 1:34:32 PM
 */
public class CreateLexiconBrand
   extends SymbolAcceptingColumnFixture
{
   public long brandID;
   public String brandPubkey;
   public String brandName;
   public String brandAbbr;
   public boolean active;
   public boolean tdRestricted;
   public String companyName;

   public boolean created()
      throws WrappingException
   {
      PersistentStoreConnection conn = new LexiconConnectionFactory().getConnection();
      LexiconTestTools.FITNESSE_TEST_AUDITOR.initializeStaging(conn);
      try {
         return createBrand(conn) == 1;
      }
      finally {
         LexiconTestTools.FITNESSE_TEST_AUDITOR.removeStaging(conn);
         conn.close();
      }
   }

   private int createBrand(PersistentStoreConnection conn)
      throws WrappingException
   {
      PersistentStoreStatement statement = conn.prepareStatement(getSQL());
      try {
         bindSQLParams(statement);
         return statement.executeInsert();
      }
      finally {
         statement.close();
      }
   }

   private void bindSQLParams(PersistentStoreStatement statement) throws WrappingException {
      statement.setParam(1, brandID);
      statement.setParam(2, brandPubkey);
      statement.setParam(3, brandName);
      statement.setParam(4, brandAbbr);
      statement.setParam(5, companyName);
      statement.setParam(6, SQLUtil.booleanToString(active));
      statement.setParam(7, SQLUtil.booleanToString(tdRestricted));
   }

   private String getSQL() {
      return "INSERT INTO Lexicon.Brand B " +
         "(brand_id, brand_pubkey, brand_name, brand_abbr, company_id, is_active, td_restricted) " +
         "VALUES " +
         "(?, ?, ?, ?, (SELECT CO.company_id FROM Lexicon.Company CO WHERE CO.company_name = ?), ?, ?)";
   }
}