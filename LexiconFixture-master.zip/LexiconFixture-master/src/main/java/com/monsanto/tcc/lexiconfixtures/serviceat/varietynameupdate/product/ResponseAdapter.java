package com.monsanto.tcc.lexiconfixtures.serviceat.varietynameupdate.product;

import com.monsanto.tcc.lexiconcommon.service.product.varietyname.model.UpdateProductVarietyNameResponse;
import org.apache.commons.lang.StringUtils;

/**
 * User: pjberry
 * Date: Sep 12, 2007
 * Time: 10:16:42 AM
 */
public class ResponseAdapter
{
   public final String precomlName;
   public final String varietyName;
   public final boolean succeeded;
   public final String messages;

   public ResponseAdapter(UpdateProductVarietyNameResponse response) {
      this.precomlName = response.getPreCommercialName();
      this.varietyName = response.getVarietyName();
      this.succeeded = response.succeeded();
      this.messages = StringUtils.join(response.messages());
   }
}
