/*
 GetRandomText was created on Nov 6, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.util.random;

import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;

/**
 * nbwald Nov 6, 2007 3:35:04 PM
 */
public class GetRandomText
   extends SymbolAcceptingColumnFixture
{
   public int length;
   public String prefix;

   public void reset()
      throws Exception
   {
      length = 9;
      prefix = "";
   }

   public String text() {
      String s = "";
      for (int i = 0; i < (length - prefix.length()); i++) {
         s += (char)((int) (Math.random() * alphabetSize()) + startLetter());
      }
      return prefix + s;
   }

   private char startLetter() {
      return 'A';
   }

   private int alphabetSize() {
      return 'Z' - 'A' + 1;
   }
}