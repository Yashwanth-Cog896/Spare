/*
 CheckScreenRow was created on Apr 19, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.webappat;

import com.monsanto.tcc.lexiconfixtures.selenium.LexiconSelenium;
import com.monsanto.tcc.lexiconfixtures.util.symbol.StringParseDelagate;
import com.monsanto.Util.StringUtils;
import fit.Fixture;
import fit.Parse;
import fitnesse.fixtures.TableFixture;

/**
 * nbwald Apr 19, 2007 5:43:01 PM
 */
public class HtmlTableRowCheckFixture
   extends TableFixture
{
   private final LexiconSelenium selenium;
   private final String[] locator;

   public HtmlTableRowCheckFixture(LexiconSelenium selenium, String[] locators) {
      this.selenium = selenium;
      this.locator = locators;
   }

   protected void doStaticTable(int rows) {
      validateEqualRowsAndLocators(rows);
      for (int r = 0; r < locator.length; r++) {
         processRow(r, locator[r]);
      }
   }

   private void validateEqualRowsAndLocators(int rows) {
      if(locator == null) {
         throw new RuntimeException("You must specify a locator.");
      }
      if(rows != locator.length) {
         throw new RuntimeException("You specified " + locator.length + " locators and " + rows + " rows.  You must specify a locator for each row in a comma separated list.");
      }
   }

   private void validateEqualTestAndActualCells(int row, int numTestValues, int numActualValues) {
      if(numTestValues != numActualValues) {
         throw new RuntimeException("There were " + numTestValues + " expected columns and " + numActualValues + " actual columns on row " + (row + 1) + ".  There must be an equal number of columns.");
      }
   }

   private void processRow(int row, String locator) {
      String[] testValues = getTestValues(row);
      HtmlTableRowParser rowParser = getRowParser(locator);
      String[] rowValues = rowParser.getRow();
      validateEqualTestAndActualCells(row, testValues.length, rowValues.length);
      compareValues(row, testValues, rowValues);
   }

   private HtmlTableRowParser getRowParser(String locator) {
      try {
         return new HtmlTableRowParser(selenium, locator);
      } catch (Exception e) {
         throw new RuntimeException("Error while parsing row.", e);
      }
   }

   private void compareValues(int row, String[] testValues, String[] rowValues) {
      for (int col = 0; col < testValues.length; col++) {
         compareValue(testValues[col], rowValues[col], row, col);
      }
   }

   private void compareValue(String testValue, String rowValue, int row, int col) {
      if(testValue.equals(rowValue)) {
         right(row, col);
      }
      else if("not null".equalsIgnoreCase(testValue) && !StringUtils.isNullOrEmpty(rowValue)) {
         right(row, col, rowValue);
      }
      else {
         wrong(row, col, rowValue == null ? "[null]" : rowValue);
      }
   }

   private void right(int row, int column, String actual) {
      Parse cell = getCell(row, column);
      right(cell);
      cell.addToBody(Fixture.gray(" (" + actual + ")"));
   }

   private String[] getTestValues(int row) {
      int columns = columnCount(row);
      String[] testValues = new String[columns];
      StringParseDelagate parseDelegate = new StringParseDelagate();
      for (int col = 0; col < columns; col++) {
         testValues[col] = parseDelegate.parse(getText(row, col));
      }
      return testValues;
   }

   private int columnCount(int row) {
      // Is there a better way to do this?
      Parse currentRow = firstRow;
      for(int r = 0; r != row; r++) {
         currentRow = currentRow.more;
      }
      Parse targetedRowColumns = currentRow.parts;
      return targetedRowColumns.size();
   }
}