package com.monsanto.tcc.lexiconfixtures.serviceat.varietynameupdate.product;

import com.monsanto.tcc.lexiconcommon.pos.LexiconServiceInvoker;
import com.monsanto.tcc.lexiconcommon.pos.SecurityProxyFactory;
import com.monsanto.tcc.lexiconcommon.pos.ServiceInvoker;
import com.monsanto.tcc.lexiconcommon.service.product.varietyname.model.UpdateProductVarietyNameRequest;
import com.monsanto.tcc.lexiconcommon.service.product.varietyname.model.UpdateProductVarietyNameResponse;
import com.monsanto.tcc.lexiconcommon.service.product.varietyname.xml.UpdateProductVarietyNameRequestSerializer;
import com.monsanto.tcc.lexiconcommon.service.product.varietyname.xml.UpdateProductVarietyNameResponseSerializer;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingDoFixture;
import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.xmlserialization.DeserializationException;
import com.monsanto.xmlserialization.SerializationException;
import fit.Fixture;
import fitlibrary.ArrayFixture;
import org.ietf.jgss.GSSException;
import org.w3c.dom.Document;

/**
 * User: pjberry
 * Date: Sep 12, 2007
 * Time: 9:37:01 AM
 */
public class UpdateProductVarietyNameFixture
   extends SymbolAcceptingDoFixture
{
   private UpdateProductVarietyNameResponse response;

   public boolean updateWithVarietyName(String preCommercialName, String varietyName)
      throws WrappingException, GSSException
   {
      Document requestDoc = serializeRequest(preCommercialName, varietyName);
      Document responseDoc = callService(requestDoc);
      this.response = deserializeResponse(responseDoc);
      return true;
   }

   public Fixture checkUpdateProductVarietyNameServiceResults() {
      return new ArrayFixture(new Object[] {new ResponseAdapter(response)});
   }

   private Document serializeRequest(String preCommercialName, String varietyName)
      throws SerializationException
   {
      UpdateProductVarietyNameRequestSerializer requestSerializer = new UpdateProductVarietyNameRequestSerializer();
      UpdateProductVarietyNameRequest request = new UpdateProductVarietyNameRequest(preCommercialName, varietyName);
      return requestSerializer.toDocument(request);
   }

   private Document callService(Document requestDoc)
      throws GSSException, WrappingException
   {
      SecurityProxyFactory.getInstance().setThreadProxy(new KerberosStandaloneCredential());
      ServiceInvoker serviceInvoker = new LexiconServiceInvoker("Lex_UpdateProductVarietyName");
      return serviceInvoker.call(requestDoc);
   }

   private UpdateProductVarietyNameResponse deserializeResponse(Document responseDoc)
      throws DeserializationException
   {
      UpdateProductVarietyNameResponseSerializer responseSerializer = new UpdateProductVarietyNameResponseSerializer();
      return responseSerializer.fromDocument(responseDoc);
   }
}
