package com.monsanto.tcc.lexiconfixtures.serviceat.eventagencyalignment;

import com.monsanto.tps.lexicon.event.EventInfo;
import fit.Fixture;
import fitlibrary.DoFixture;

/**
 * nbwald - Feb 16, 2009 2:59:34 PM
 */
public class EventSearchServiceFixture
   extends DoFixture
{
   private final EventSearchServiceCaller service = new EventSearchServiceCaller();
   private EventInfo[] eventInfos;

   public boolean findEventAgencyAlignmentWithEventNameAndCrop(String eventName, String crop) {
      EventInfo eventInfo = service.findByEventAndCrop(eventName, crop);
      saveResultsForSingleEventInfo(eventInfo);
      return true;
   }

   public boolean findEventAgencyAlignmentWithEventNamesAndCrop(String eventNameCSV, String crop) {
      this.eventInfos = service.findByEventsAndCrop(eventNameCSV.split(","), crop);
      return true;
   }

   public boolean findEventAgencyAlignmentWithMonNumber(String monNumberValue) {
      EventInfo eventInfo = service.findByMonNumber(monNumberValue);
      saveResultsForSingleEventInfo(eventInfo);
      return true;
   }

   public boolean findEventAgencyAlignmentWithMonNumbers(String monNumberValueCSV) {
      this.eventInfos = service.findByMonNumbers(monNumberValueCSV.split(","));
      return true;
   }

   public boolean findEventAgencyAlignmentWithEventAgencyAlignmentPubkey(String pubkeyCSV) {
      this.eventInfos = service.findByEventAgencyAlignmentPubkey(pubkeyCSV.split(","));
      return true;
   }

   public boolean findEventAgencyAlignmentWithAgencyAbbreviation(String agencyAbbrCSV) {
      this.eventInfos = service.findByAgencyAbbr(agencyAbbrCSV.split(","));
      return true;
   }

   public int numberOfRecordsFound()
      throws Exception
   {
      return new EventResultsRowFixture(eventInfos).query().length;
   }

   public Fixture checkResultEvents() {
      return new EventResultsRowFixture(eventInfos);
   }

   public Fixture checkResultConstructs() {
      return new ConstructResultsRowFixture(eventInfos);
   }

   public Fixture checkResultAlignments() {
      return new AlignmentResultsRowFixture(eventInfos); 
   }

   private void saveResultsForSingleEventInfo(EventInfo eventInfo) {
      this.eventInfos = eventInfo == null ? new EventInfo[0] :  new EventInfo[] {eventInfo};
   }
}
