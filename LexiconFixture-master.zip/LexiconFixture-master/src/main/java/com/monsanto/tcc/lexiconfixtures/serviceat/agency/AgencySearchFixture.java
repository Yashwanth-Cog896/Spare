package com.monsanto.tcc.lexiconfixtures.serviceat.agency;

import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingDoFixture;
import com.monsanto.tps.lexicon.agency.Agency;
import com.monsanto.tps.lexicon.agency.AgencySearchCriteria;
import com.monsanto.tps.lexicon.agency.AgencyService;
import fit.Fixture;
import org.ietf.jgss.GSSException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * rrchak1 - Oct 23, 2008 3:09:08 PM
 */
public class AgencySearchFixture
   extends SymbolAcceptingDoFixture
{
   private AgencySearchCriteria criteria = new AgencySearchCriteria();
   private Agency[] agencies;
   private static final String AGENCY_SERVICE = "agencyService";
   private String errorMessage;

   public boolean agencyPublicKeys(String commaSeparatedAgencyPubkeys){
      criteria.setAgencyPubkey(commaSeparatedAgencyPubkeys.split(",\\s*"));
      return true;
   }

   public boolean agencyAbbreviations(String commaSeparatedAgencyAbbreviations){
      criteria.setAgencyAbbr(commaSeparatedAgencyAbbreviations.split(",\\s*"));
      return true;
   }

   public boolean countryIsoCodes(String commaSeparatedAgencyCountryIsoCodes){
      criteria.setAgencyCountryIsoCode(commaSeparatedAgencyCountryIsoCodes.split(",\\s*"));
      return true;
   }

   public boolean departmentNames(String commaSeparatedDepartmentNames){
      criteria.setDepartmentNames(commaSeparatedDepartmentNames.split(";\\s*"));
      return true;
   }

   public boolean includeInactive(boolean includeInactive){
      criteria.setIncludeInactive(includeInactive);
      return true;
   }

   public boolean search()
      throws GSSException
   {
      try {
         this.agencies = getClient().findBySearchCriteria(criteria);
      }
      catch(Exception e) {
         errorMessage = getErrorMessage(e);
      }
      return true;
   }

   private AgencyService getClient() {
      String configLocation = "/com/monsanto/tcc/lexiconfixtures/client.xml";
      ApplicationContext context = new ClassPathXmlApplicationContext(configLocation);
      return (AgencyService) context.getBean(AGENCY_SERVICE);
   }

   public boolean errorMessageContainsIs(String expected) {
      return errorMessage.contains(expected);
   }

   public Fixture checkResults() {
      return new AgencyAdaptorRowFixture(agencies);
   }

   public int numberOfAgencyDataRecordsFound(){
      if(agencies!=null){
         AgencyAdaptorRowFixture fixture = new AgencyAdaptorRowFixture(agencies);
         try {
            Object[] output = fixture.query();
            return output.length;
         }
         catch (Exception e) {
            errorMessage = getErrorMessage(e);
         }
      }
      return 0;
   }

   public boolean findAgencyDataByAgencyPublicKeys(String commaSeparatedAgencyPubkeys) throws Exception {
      criteria.setAgencyPubkey(commaSeparatedAgencyPubkeys.split(",\\s*"));
      try {
         agencies = getClient().findBySearchCriteria(criteria);
      } catch (Exception e) {
         errorMessage = getErrorMessage(e);
      }
      return true;
   }

   public boolean findAgencyDataByAgencyAbbreviations(String commaSeparatedAgencyAbbreviations) throws Exception {
      criteria.setAgencyAbbr(commaSeparatedAgencyAbbreviations.split(",\\s*"));
      try {
         agencies = getClient().findBySearchCriteria(criteria);
      } catch (Exception e) {
         errorMessage = getErrorMessage(e);
      }
      return true;
   }

   public boolean findAgencyDataByDepartments(String commaSeparatedDepartmentNames) throws Exception {
      criteria.setDepartmentNames(commaSeparatedDepartmentNames.split(";\\s*"));
      try {
         agencies = getClient().findBySearchCriteria(criteria);
      } catch (Exception e) {
         errorMessage = getErrorMessage(e);
      }
      return true;
   }

   public boolean findAgencyDataByCountryIsoCodes(String commaSeparatedAgencyCountryIsoCodes) throws Exception {
      criteria.setAgencyCountryIsoCode(commaSeparatedAgencyCountryIsoCodes.split(",\\s*"));
      try {
         agencies = getClient().findBySearchCriteria(criteria);
      } catch (Exception e) {
         errorMessage = getErrorMessage(e);
      }
      return true;
   }   

   public boolean findAgencyDataByIsActiveStatus(String status) throws Exception {
      //by default active agencies are returned
      try {
         agencies = getClient().findBySearchCriteria(criteria);
      } catch (Exception e) {
         errorMessage = getErrorMessage(e);
      }
      return true;
   }     


   private String getErrorMessage(Exception e) {
      StringWriter writer = new StringWriter();
      e.printStackTrace(new PrintWriter(writer));
      String errorMessage = writer.toString();
      System.out.println("Received error message: '" + errorMessage + "'");
      return errorMessage;
   }
}
