package com.monsanto.tcc.lexiconfixtures.data.midas.country;

import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Apr 24, 2007
 * Time: 11:23:13 AM
 * To change this template use File | Settings | File Templates.
 */
public class CreateMidasCountry
   extends SymbolAcceptingColumnFixture
{
   public long countryID;
   public String countryName;
   public String countryAbbr;
   public String refActive;

   public boolean created()
      throws WrappingException {
      PersistentStoreConnection conn = new MidasConnectionFactory().getConnection();
      try {
         return createCountry(conn) == 1;
      }
      finally {
         conn.close();
      }
   }

   private int createCountry(PersistentStoreConnection conn)
      throws WrappingException
   {
      PersistentStoreStatement statement = conn.prepareStatement(getSQL());
      try {
         bindSQLParams(statement);
         return statement.executeInsert();
      }
      finally {
         statement.close();
      }
   }

   private void bindSQLParams(PersistentStoreStatement statement) throws WrappingException {
      statement.setParam(1, countryID);
      statement.setParam(2, countryName);
      statement.setParam(3, countryAbbr);
      statement.setParam(4, refActive);
   }

   private String getSQL() {
      return "INSERT INTO Midas.Country C " +
         "(country_id, name, country_abbr, ref_active) " +
         "VALUES " +
         "(?, ?, ?, ?)";
   }
}