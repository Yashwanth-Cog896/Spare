package com.monsanto.tcc.lexiconfixtures.webappat.productaliasreport;

import com.monsanto.tcc.lexiconcommon.file.excel.ExcelReader;
import com.monsanto.tcc.lexiconfixtures.util.symbol.StringParseDelagate;
import fit.Parse;
import fitnesse.fixtures.TableFixture;
import java.io.IOException;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Feb 23, 2007
 * Time: 3:33:16 PM
 */
public class ExcelSpreadSheetFixture
   extends TableFixture
{
   private ExcelReader excelReader;
   private int numOfColumns;

   public ExcelSpreadSheetFixture(ExcelReader excelReader)
      throws IOException
   {
      this.excelReader = excelReader;
      printExcel();
      this.numOfColumns = excelReader.getRowValues(0).size();
   }

   private void printExcel()
   {
      System.out.println(getExcelString());
   }

   private String getExcelString()
   {
      try {
         String excelText = "";
         for (int i = 0; i < excelReader.getNumRows(); i++) {
            excelText += "row[" + i + "]=" + excelReader.getRowValues(i) + "\n";
         }
         return excelText;
      }
      catch(IOException e) {
         e.printStackTrace();
         throw new RuntimeException(e);
      }
   }

   protected void doStaticTable(int numOfRows)
   {
      try {
         validateEqualNumberOfRows(numOfRows);
         for(int i = 0; i < numOfRows; i ++) {
            checkRow(i, excelReader.getRowValues(i));
         }
      }
      catch (IOException e) {
         e.printStackTrace();
         throw new RuntimeException(e);
      }
   }

   private void validateEqualNumberOfRows(int numOfTestRows) {
      int numOfExcelRows = excelReader.getNumRows();
      if(numOfTestRows != numOfExcelRows) {
         throw new RuntimeException(
            "Test expects " + numOfTestRows + " row" + plural(numOfTestRows) +
            ".  Excel has " + numOfExcelRows + " row" + plural(numOfExcelRows) + ".\nExcel:\n" + getExcelString());
      }
   }

   private void validateEqualNumberOfColumns(int rowNum) {
      int numOfTestColumns = columnCount(rowNum);
      int numOfExcelColumns = numOfColumns;
      if(numOfTestColumns != numOfExcelColumns) {
         throw new RuntimeException(
            "Test expects " + numOfTestColumns + " column" + plural(numOfTestColumns) +
            ".  Excel has " + numOfExcelColumns + " column" + plural(numOfExcelColumns) + ".\nExcel:\n" + getExcelString());
      }
   }

   private String plural(int i) {
      return i == 1 ? "" : "s";
   }

   private void checkRow(int rowNum, List rowValues) {
      validateEqualNumberOfColumns(rowNum);
      for (int columnNum = 0; columnNum < numOfColumns; columnNum++) {
         String excelCellValue = getCellValue(rowValues, columnNum);
         String testCellValue = getText(rowNum, columnNum);
         String fixtureCellValue = new StringParseDelagate().parse(testCellValue);
         checkCell(fixtureCellValue, excelCellValue, rowNum, columnNum);
      }
   }

   private void checkCell(String fixtureCellValue, String excelCellValue, int rowNum, int columnNum) {
      if(stringsAreEqual(fixtureCellValue, excelCellValue)) {
         right(rowNum, columnNum);
      } else {
         wrong(rowNum, columnNum, getEquivalentText(excelCellValue));
      }
   }

   private String getCellValue(List rowValues, int columnNum) {
      if(columnNum >= rowValues.size()) {
         return "";
      }
      else {
         return (String)rowValues.get(columnNum);
      }
   }

   private boolean stringsAreEqual(String a, String b) {
      String actualA = getStringRealValue(a);
      String actualB = getStringRealValue(b);
      return actualA.equals(actualB);
   }

   private String getStringRealValue(String s) {
      if(s == null || s.equals("null")) {
         return "";
      }
      return s.replaceAll("\n", " ").replaceAll("\r", " ");
   }

   private String getEquivalentText(String excelCellValue) {
      return excelCellValue == null ? "null" : excelCellValue;
   }

   private int columnCount(int row) {
      // Is there a better way to do this?
      Parse currentRow = firstRow;
      for(int r = 0; r != row; r++) {
         currentRow = currentRow.more;
      }
      Parse targetedRowColumns = currentRow.parts;
      return targetedRowColumns.size();
   }
}
