/*
 AbstractLexiconIDQuery was created on Jul 17, 2007 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo.cascadingdelete.query.id;

import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.Util.Exceptions.WrappingException;
import java.util.List;

/**
 * nbwald Jul 17, 2007 6:39:27 PM
 */
public abstract class AbstractLexiconIDQuery
   extends AbstractPersistentStoreMultiRowQuery
{
   private final long id;

   protected AbstractLexiconIDQuery(long id) {
      this.id = id;
   }

   public List<Long> getIds()
      throws WrappingException
   {
      return getList();
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return row.getLONG(1);
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { id };
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties()
   {
      return new LexiconConnectionFactoryProperties();
   }
}