package com.monsanto.tcc.lexiconfixtures.serviceat.seedplanning;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Feb 13, 2007
 * Time: 6:19:45 PM
 * To change this template use File | Settings | File Templates.
 */
public class PubkeyAdapter
{
   public String pubkey;

   public PubkeyAdapter(String pubkey) {
      this.pubkey = pubkey;
   }
}
