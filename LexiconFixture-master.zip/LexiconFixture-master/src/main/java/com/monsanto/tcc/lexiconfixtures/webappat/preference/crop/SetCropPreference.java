package com.monsanto.tcc.lexiconfixtures.webappat.preference.crop;

import com.monsanto.tcc.lexiconcommon.PreferenceNames;
import com.monsanto.tcc.lexiconfixtures.util.preference.UserPreferenceRecordSync;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jul 2, 2007
 * Time: 5:02:41 PM
 */
public class SetCropPreference
   extends SymbolAcceptingColumnFixture
{
   public String cropName;

   public boolean set()
      throws WrappingException
   {
      final UserPreferenceRecordSync dataMod = new UserPreferenceRecordSync(
         PreferenceNames.CROP_NAME_PREF_NAME, StringUtils.toUpperCaseNull(cropName));
      return dataMod.performAction() == 1;
   }
}
