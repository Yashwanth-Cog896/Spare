package com.monsanto.tcc.lexiconfixtures.data.cleanup;

import com.monsanto.tcc.lexiconcommon.db.SqlUtilities;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import java.util.List;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jun 6, 2007
 * Time: 5:35:29 PM
 */
public class ParentageIdsQuery
   extends AbstractPersistentStoreMultiRowQuery
{
   private List materialIds;
   public ParentageIdsQuery() {
   }
   public ParentageIdsQuery(final List materialIds) {
      this.materialIds = materialIds;
   }

   public List getIdList() throws WrappingException {
      return super.getList();
   }
   protected Object createObjectFromRow(PersistentStoreResultSetRow row) throws WrappingException {
      return row.getString(1);
   }
   protected Object[] getBindVariables() throws WrappingException {
      return new Object[0];
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MidasConnectionFactoryProperties();
   }

   protected String getSQL()
      throws WrappingException
   {
      if (materialIds == null) {
         materialIds = new GeneticMaterialIdsQuery().getIdList();
      }
      return "SELECT parentage_id " +
         "FROM Midas.Parentage P " +
         "WHERE " + SqlUtilities.makeInListOfNumerics("P.genetic_material_id", materialIds) +
         " OR " + SqlUtilities.makeInListOfNumerics("P.parent_genetic_material_id", materialIds);
   }
}
