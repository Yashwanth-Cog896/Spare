package com.monsanto.tcc.lexiconfixtures.data.fbscommon.allinfo;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Mar 19, 2007
 * Time: 11:44:21 AM
 * To change this template use File | Settings | File Templates.
 */
public class DeleteFBSCommonProductByLexPubkey
{
   private final String sql = "DELETE FROM FBS_Common.product_xref PX WHERE PX.lexicon_product_pubkey = ?";

   public int deleteProduct(PersistentStoreConnection fbsConn, String lexiconProductPubkey)
      throws WrappingException
   {
      PersistentStoreStatement stmt = fbsConn.prepareStatement(sql);
      try {
         stmt.setParam(1, lexiconProductPubkey);
         return stmt.executeDelete();
      }
      finally {
         stmt.close();
      }
   }
}
