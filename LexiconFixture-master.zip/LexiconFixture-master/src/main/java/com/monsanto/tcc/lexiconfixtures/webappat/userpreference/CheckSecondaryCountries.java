package com.monsanto.tcc.lexiconfixtures.webappat.userpreference;

import com.monsanto.tcc.lexiconcommon.PreferenceNames;
import com.monsanto.tcc.lexiconfixtures.util.preference.UserPreferencesTestTool;
import fitlibrary.ArrayFixture;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Apr 3, 2007
 * Time: 3:26:08 PM
 * To change this template use File | Settings | File Templates.
 */
public class CheckSecondaryCountries
   extends ArrayFixture
{
   public CheckSecondaryCountries()
      throws Exception
   {
      List countryValues = UserPreferencesTestTool.getCurrentPreferenceValues(
         PreferenceNames.SECONDARY_COUNTRY_PREF_NAME);

      List countries = new ArrayList(countryValues.size());
      for (Iterator iterator = countryValues.iterator(); iterator.hasNext();) {
         String countryValue = (String)iterator.next();
         countries.add(new CountryAdapter(countryValue));
      }
      setActualCollection(countries);
   }
}
