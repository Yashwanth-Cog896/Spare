package com.monsanto.tcc.lexiconfixtures.data.lexicon.crop;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.LexiconDataFixtureInsert;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dbdataservices.SQLUtil;

/**
 * User: pjberry
 * Date: Jul 12, 2007
 * Time: 5:17:52 PM
 */
public class CreateLexiconCrop
   extends SymbolAcceptingColumnFixture
{
   public Long cropId;
   public String cropPubkey;
   public String cropName;
   public boolean majorCrop;
   public boolean regulatoryCrop;

   public boolean created()
      throws WrappingException
   {
      LexiconCropInsert insert = new LexiconCropInsert();
      return insert.performInsert() == 1;
   }

   private class LexiconCropInsert
      extends LexiconDataFixtureInsert
   {
      protected String getSQL()
         throws WrappingException
      {
         return "INSERT INTO Lexicon.crop C (C.crop_id, C.crop_pubkey, C.crop_name, C.major_crop, C.regulatory_crop) VALUES (?, ?, ?, ?, ?)";
      }

      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[] {cropId, cropPubkey, cropName, SQLUtil.booleanToString(majorCrop), SQLUtil.booleanToString(regulatoryCrop)};
      }

      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new LexiconConnectionFactoryProperties();
      }
   }
}
