/*
 CreateSAPLinkageAudit was created on Jul 16, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.data.lexicon.saplinkageaudit;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreInsert;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald Jul 16, 2007 5:11:13 PM
 */
public class CreateSAPLinkageAudit
   extends SymbolAcceptingColumnFixture
{
   public Long linkageAuditId;
   public Long auditHeaderId;
   public String pubkey;
   public String requestType;
   public String date;
   public String result; 	

   public boolean created()
      throws WrappingException
   {
      SAPLinkageAuditInsertDataMod insert = new SAPLinkageAuditInsertDataMod();
      return insert.performInsert() == 1;
   }

   private class SAPLinkageAuditInsertDataMod
      extends AbstractPersistentStoreInsert
   {
      protected String getSQL()
         throws WrappingException
      {
         return "INSERT INTO Lexicon.Sap_Linkage_Audit " +
            "(sap_linkage_audit_id, audit_header_id, pubkey, request_type, timestamp, result) " +
            "VALUES " +
            "(?, ?, ?, ?, TO_DATE(?, 'yyyy/mm/dd:hh24:mi:ss'), ?)";
      }

      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[] {linkageAuditId, auditHeaderId,  pubkey, requestType, date, result };
      }

      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new LexiconConnectionFactoryProperties();
      }
   }
}