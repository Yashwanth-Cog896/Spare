package com.monsanto.tcc.lexiconfixtures.util.symbol;

/**
 * Created by IntelliJ IXA.
 * User: JASKIDI
 * Date: Apr 4, 2007
 * Time: 12:47:40 AM
 * To change this template use File | Settings | File Templates.
 */
public class LongParseDelagate
   extends SymbolProcessingParseDelagate
{
   public Long parse(String s) {
      return (Long)baseParse(s);
   }

   protected Object createObjectFromSymbolValue(Object symbolValue) {
      return new Long(symbolValue.toString());
   }

   protected Object createObjectFromString(String s) {
      return new Long(s);
   }

}
