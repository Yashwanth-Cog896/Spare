package com.monsanto.tcc.lexiconfixtures.serviceat.externalcontact;

import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingRowFixture;
import com.monsanto.tcc.lexiconfixtures.serviceat.businessaccount.EmptyAddressRecord;
import com.monsanto.tcc.lexiconcommon.ArrayUtils;
import com.monsanto.tps.lexicon.person.ExternalContact;
import com.monsanto.tps.lexicon.contact.AddressRecord;

import java.util.List;
import java.util.ArrayList;

/**
 * nbwald - Aug 1, 2008 6:07:58 PM
 */
public class ExternalContactAdaptorRowFixture
   extends SymbolAcceptingRowFixture
{
   private final ExternalContact[] externalContacts;

   public ExternalContactAdaptorRowFixture(ExternalContact[] externalContacts) {
      this.externalContacts = externalContacts;
   }

   public Class<?> getTargetClass() {
      return ExternalContactAdaptor.class;
   }

   public Object[] query()
      throws Exception
   {
      return buildExternalContactAdaptors();
   }

   private ExternalContactAdaptor[] buildExternalContactAdaptors() {
      List<ExternalContactAdaptor> adaptors = new ArrayList<ExternalContactAdaptor>();
      for (ExternalContact externalContact : externalContacts) {
         addExternalContactAdaptors(adaptors, externalContact);
      }
      return adaptors.toArray(new ExternalContactAdaptor[adaptors.size()]);
   }

   private void addExternalContactAdaptors(List<ExternalContactAdaptor> adaptors, ExternalContact externalContact) {
      AddressRecord[] addressRecords = getAddressRecords(externalContact);
      String[] externalContactTypes = getExternalContactTypes(externalContact);
      for (AddressRecord addressRecord : addressRecords) {
         for (String externalContactType : externalContactTypes) {
            adaptors.add(new ExternalContactAdaptor(externalContact, addressRecord, externalContactType));
         }
      }
   }

   private AddressRecord[] getAddressRecords(ExternalContact externalContact) {
      AddressRecord[] addressRecords = externalContact.getAddressRecords();
      return ArrayUtils.hasItems(addressRecords) ? addressRecords : EmptyAddressRecord.get();
   }

   private String[] getExternalContactTypes(ExternalContact externalContact) {
      String[] externalContactTypes = externalContact.getContactTypes();
      return ArrayUtils.hasItems(externalContactTypes) ? externalContactTypes : new String[]{""};
   }
}
