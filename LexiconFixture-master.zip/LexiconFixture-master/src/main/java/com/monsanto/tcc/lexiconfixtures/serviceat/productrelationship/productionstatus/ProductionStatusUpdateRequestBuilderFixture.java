package com.monsanto.tcc.lexiconfixtures.serviceat.productrelationship.productionstatus;

import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.tcc.lexiconfixtures.util.ColumnFixtureResetter;
import com.monsanto.tps.lexicon.precommercialproduct.ProductionStatusUpdateRequest;

import java.util.List;
import java.util.ArrayList;

/**
 * nbwald - Sep 12, 2008 4:36:56 PM
 */
public class ProductionStatusUpdateRequestBuilderFixture
   extends SymbolAcceptingColumnFixture
{
   public String productPubkey;
   public String precommercialName;
   public String manufacturingName;
   public String cropPubkey;
   public String productionStatus;

   private List<ProductionStatusUpdateRequest> requests = new ArrayList<ProductionStatusUpdateRequest>();

   public void reset()
      throws Exception
   {
      ColumnFixtureResetter.reset(this);
   }

   public void execute()
      throws Exception
   {
      requests.add(createRequest());
   }

   private ProductionStatusUpdateRequest createRequest() {
      ProductionStatusUpdateRequest request = new ProductionStatusUpdateRequest();
      request.setCropPubKey(cropPubkey);
      request.setManfName(manufacturingName);
      request.setPreCommercialName(precommercialName);
      request.setProductionStatus(productionStatus);
      request.setProductPubkey(productPubkey);
      return request;
   }

   public ProductionStatusUpdateRequest[] getRequests() {
      return requests.toArray(new ProductionStatusUpdateRequest[requests.size()]);
   }
}
