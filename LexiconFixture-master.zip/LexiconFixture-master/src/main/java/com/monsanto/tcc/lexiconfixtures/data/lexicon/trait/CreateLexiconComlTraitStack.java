package com.monsanto.tcc.lexiconfixtures.data.lexicon.trait;

import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactory;
import com.monsanto.tcc.lexiconcommon.db.test.LexiconTestTools;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.dbdataservices.SQLUtil;

/**
 * User: pjberry
 * Date: May 23, 2007
 * Time: 9:13:51 AM
 */
public class CreateLexiconComlTraitStack
   extends SymbolAcceptingColumnFixture
{
   public Long comlTraitStackId;
   public String comlTraitStackPubkey;
   public String reportingName;
   public String stackDesc; 	
   public String crop;
   public String tdName;
   public String stackAbbr;
   public String manfTraitCode;
   public boolean precommercial;

   public boolean created()
      throws WrappingException
   {
      LexiconConnectionFactory connectionFactory = new LexiconConnectionFactory();
      PersistentStoreConnection conn = connectionFactory.getConnection();
      LexiconTestTools.FITNESSE_TEST_AUDITOR.initializeStaging(conn);
      try {
         int numInserted = insertFakeData(conn);
         return numInserted == 1;
      }
      finally {
         LexiconTestTools.FITNESSE_TEST_AUDITOR.removeStaging(conn);
         conn.close();
      }
   }

   private int insertFakeData(PersistentStoreConnection conn)
      throws WrappingException
   {
      String productInsertSQL = getSQL();
      PersistentStoreStatement stmt = conn.prepareStatement(productInsertSQL);
      try {
         stmt.setParam(1, comlTraitStackId);
         stmt.setParam(2, comlTraitStackPubkey);
         stmt.setParam(3, reportingName);
         stmt.setParam(4, stackDesc);
         stmt.setParam(5, crop);
         stmt.setParam(6, tdName);
         stmt.setParam(7, stackAbbr);
         stmt.setParam(8, manfTraitCode);
         stmt.setParam(9, SQLUtil.booleanToString(precommercial));
         return stmt.executeInsert();
      }
      finally {
         stmt.close();
      }
   }

   private String getSQL() {
      return
      "INSERT INTO Lexicon.Coml_Trait_Stack2 CTS " +
      "(coml_trait_stack_id, coml_trait_stack_pubkey, reporting_name, stack_desc, crop_id, td_name, stack_abbr, manf_trait_code, is_pre_commercial_ind) " +
      "VALUES " +
      "(?, ?, ?, ?, (SELECT C.crop_id FROM Lexicon.Crop C WHERE UPPER(C.crop_name) = UPPER(?)), ?, ?, ?, ?)";
   }
}

