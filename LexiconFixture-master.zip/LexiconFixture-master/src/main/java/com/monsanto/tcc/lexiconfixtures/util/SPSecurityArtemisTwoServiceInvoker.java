package com.monsanto.tcc.lexiconfixtures.util;

import com.monsanto.securityinterfaces.SystemSecurityProxy;
import com.monsanto.securityinterfaces.ClientSecurityProxy;
import com.monsanto.xmlserialization.XmlSerializer;
import com.monsanto.services.domain.common.envelope.ResponseEnvelope;
import com.monsanto.services.domain.common.envelope.RequestEnvelope;
import com.monsanto.services.domain.common.envelope.RequestOperation;
import com.monsanto.services.domain.common.activity.ActivityClientException;
import com.monsanto.services.client.common.activity.ActivityClient;
import com.monsanto.POSClient.POSConnection;
import com.monsanto.POSClient.SecureXMLPOSConnection;
import com.monsanto.POSClient.POSCommunicationException;

/**
 * Created by IntelliJ IDEA. User: AAGOSW Date: Oct 22, 2008 Time: 1:55:46 PM To change this template use File |
 * Settings | File Templates.
 */
public class SPSecurityArtemisTwoServiceInvoker {

  public static final String SPSECURITY_DEV_HOST_NAME = "http://w3d.genoweb.monsanto.com";
  private final SystemSecurityProxy systemSecurityProxy;
  private String serviceName;
  private String operationName;
  private XmlSerializer xmlSerializer;

  public SPSecurityArtemisTwoServiceInvoker(SystemSecurityProxy systemSecurityProxy, String serviceName,
                                            String operationName, XmlSerializer xmlSerializer) {
    this.systemSecurityProxy = systemSecurityProxy;
    this.serviceName = serviceName;
    this.operationName = operationName;
    this.xmlSerializer = xmlSerializer;
  }

  public ResponseEnvelope call(Object payload) {
    try {
      ActivityClient client = new ActivityClient(systemSecurityProxy){
         protected POSConnection getSecurePOSConnection(ClientSecurityProxy clientProxy, SystemSecurityProxy systemProxy) {
             return new SecureXMLPOSConnection(clientProxy, systemProxy){
                protected String getURL(String requestName)
                throws POSCommunicationException
                {
                   String url = super.getURL(requestName);
                   if("win".equalsIgnoreCase(System.getProperty("lsi.function"))){
                      url = replaceWinUrlWithDevUrl(url);
                   }
                   return url;
                }
             };
         }
      };
      ResponseEnvelope responseEnvelope = client.perform(buildRequestEnvelope(payload), serviceName, xmlSerializer);
      return responseEnvelope;
    }

    catch (ActivityClientException e) {
      throw new RuntimeException(e);
    }
  }

   private String replaceWinUrlWithDevUrl(String url) {
      StringBuffer buf = new StringBuffer(SPSECURITY_DEV_HOST_NAME);
      buf.append(url.substring(url.indexOf(".com") + 4));
      return buf.toString();
   }

   private RequestEnvelope buildRequestEnvelope(Object payload) {
    RequestOperation operation = new RequestOperation(operationName);
    return new RequestEnvelope(operation, payload);
  }
}
