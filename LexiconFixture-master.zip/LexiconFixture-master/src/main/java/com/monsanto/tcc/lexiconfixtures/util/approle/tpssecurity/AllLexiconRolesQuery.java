package com.monsanto.tcc.lexiconfixtures.util.approle.tpssecurity;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.tcc.lexiconcommon.exception.RuntimeWrappingException;
import com.monsanto.tcc.lexiconfixtures.data.factories.spsecurity.SpsecurityConnectionFactoryProperties;

import java.util.List;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 * nbwald - Jul 14, 2009 3:59:22 PM
 */
public class AllLexiconRolesQuery
   extends AbstractPersistentStoreMultiRowQuery
{
   public List<String> find() {
      try {
         return getList();
      }
      catch (WrappingException e) {
         throw new RuntimeWrappingException(e);
      }
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      Pattern pattern = Pattern.compile("lexicon\\.(.+)");
      String value = row.getString(1);
      Matcher matcher = pattern.matcher(value);
      if(!matcher.matches()) {
         throw new RuntimeException("Expected value to start with 'lexicon.', but was: " + value);
      }
      return matcher.group(1);
   }

   protected String getSQL()
      throws WrappingException
   {
      return 
         " SELECT context" +
         "   FROM FBS_Common.SPS_Context" +
         "  WHERE environment_id = (SELECT environment_id FROM FBS_Common.SPS_Environment WHERE name = 'LEXICON' and active = 'T')";
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[0];
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new SpsecurityConnectionFactoryProperties();
   }
}
