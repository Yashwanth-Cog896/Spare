/*
	 SubsubcountryResponseAdaptor was created on Jun 11, 2008 using Monsanto 
	 resources and is the sole property of Monsanto.  Any duplication of the 
	 code and/or logic is a direct infringement of Monsanto's copyright.
	*/
package com.monsanto.tcc.lexiconfixtures.serviceat.geography;

import com.monsanto.tps.lexicon.geography.subsubcountry.Subsubcountry;

/**
 * Filename:    $RCSfile: SubsubcountryResponseAdaptor.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: mmr $    	 On:	$Date: 2008-06-18 12:28:12 $
 *
 * @author MMR
 * @version $Revision: 1.2 $
 */
public class SubsubcountryResponseAdaptor {

    public String name;
    public String countryIsoCode;
    public String subcountryAbbreviation;
    public String description;

    public SubsubcountryResponseAdaptor(Subsubcountry subsubcountry) {
        name = subsubcountry.getName();
        countryIsoCode = subsubcountry.getCountryISOCode();
        subcountryAbbreviation = subsubcountry.getAbbreviation();
        description = subsubcountry.getDescription();
    }
}
/*
* Revision Log
* : $
*/