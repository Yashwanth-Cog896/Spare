package com.monsanto.tcc.lexiconfixtures.data.mirage.product;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.tcc.lexiconfixtures.data.factories.mirage.MirageConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.data.mirage.MirageSQLUtils;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Dec 15, 2006
 * Time: 1:28:15 PM
 * To change this template use File | Settings | File Templates.
 */
public class MirageProductIdLookup
   extends AbstractPersistentStoreSingleResultQuery
{
   private final String productName;
   private final String companyName;
   private final String countryName;
   private final String bayerCode;

   public MirageProductIdLookup(String productName, String brandName, String countryName, String bayerCode) {
      this.productName = productName;
      this.companyName = StringUtils.toUpperCaseNull(brandName);
      this.countryName = StringUtils.toUpperCaseNull(countryName);
      this.bayerCode = MirageSQLUtils.buildBayerCodeForDB(bayerCode);
   }

   public Long getProductId() throws WrappingException {
      return (Long)execute();
   }
   protected Object createObjectFromRow(PersistentStoreResultSetRow row) throws WrappingException {
      return row.getLONG(1);
   }
   protected String getSQL() throws WrappingException {
      return new SQLPropFile(MirageProductFixtureSQL.class).getSQL(MirageProductFixtureSQL.MIRAGE_SELECT_PRODUCT_ID);
   }
   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { productName, companyName, countryName, bayerCode };
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MirageConnectionFactoryProperties();
   }
}
