package com.monsanto.tcc.lexiconfixtures.data.mirage.product;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconfixtures.data.factories.mirage.MirageConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.EmptyResultSetException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetSingleResult;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Dec 14, 2006
 * Time: 5:42:39 PM
 * To change this template use File | Settings | File Templates.
 */
public class CheckMirageProductName
   extends SymbolAcceptingColumnFixture
{
   public String productName;

   private SQLPropFile sqlPropFile = new SQLPropFile(MirageProductFixtureSQL.class);

   public boolean exists()
      throws WrappingException, EmptyResultSetException
   {
      MirageConnectionFactory connectionFactory = new MirageConnectionFactory();
      PersistentStoreConnection conn = connectionFactory.getConnection();
      try {
         int numFound = getNumOfProductsMatchingName(conn);
         return numFound > 0;
      }
      finally {
         conn.close();
      }
   }

   private int getNumOfProductsMatchingName(PersistentStoreConnection conn)
      throws WrappingException, EmptyResultSetException
   {
      String sql = sqlPropFile.getSQL(MirageProductFixtureSQL.SELECT_NUM_OF_PRODUCTS_WITH_GIVEN_NAME);
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         bindTheVariables(stmt);
         PersistentStoreResultSetSingleResult rs = stmt.executeQuery().getSingleResult();
         return rs.getInt(1);
      }
      finally {
         stmt.close();
      }
   }

   private void bindTheVariables(PersistentStoreStatement stmt)
      throws WrappingException
   {
      stmt.setParam(1, productName);
   }
}
