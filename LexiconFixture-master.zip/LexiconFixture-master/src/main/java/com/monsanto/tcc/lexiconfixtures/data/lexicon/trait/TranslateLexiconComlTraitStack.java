package com.monsanto.tcc.lexiconfixtures.data.lexicon.trait;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import fit.ColumnFixture;

/**
 * User: pjberry
 * Date: Jul 12, 2007
 * Time: 3:51:22 PM
 */
public class TranslateLexiconComlTraitStack
   extends ColumnFixture
{
   public String crop;
   public String stackAbbr;

   public String comlTraitStackPubkey()
      throws WrappingException
   {
      ComlTraitStackPubkeyFromAbbrQuery query = new ComlTraitStackPubkeyFromAbbrQuery();
      return query.getPubkey();
   }

   private class ComlTraitStackPubkeyFromAbbrQuery
      extends AbstractPersistentStoreSingleResultQuery
   {
      public String getPubkey()
         throws WrappingException
      {
         return (String)execute();
      }

      protected Object createObjectFromRow(PersistentStoreResultSetRow row)
         throws WrappingException
      {
         return row.getString(1);
      }

      protected String getSQL()
         throws WrappingException
      {
         return
            "SELECT " +
               "    CTS.coml_trait_stack_pubkey " +
               "FROM " +
               "    Lexicon.coml_trait_stack2 CTS, " +
               "    Lexicon.crop C " +
               "WHERE " +
               "    C.crop_name = ? " +
               "    AND " +
               "    CTS.stack_abbr = ? " +
               "    AND " +
               "    CTS.crop_id = C.crop_id ";
      }

      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new String[] {crop, stackAbbr};
      }

      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new LexiconConnectionFactoryProperties();
      }
   }

}
