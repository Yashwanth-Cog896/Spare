/*
	 BuildBusinessAccountSearchCriteria was created on Jun 4, 2008 using Monsanto 
	 resources and is the sole property of Monsanto.  Any duplication of the 
	 code and/or logic is a direct infringement of Monsanto's copyright.
	*/
package com.monsanto.tcc.lexiconfixtures.serviceat.businessaccount;

import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.tps.lexicon.account.BusinessAccountSearchCriteria;
import com.monsanto.tps.lexicon.contact.SearchableLocation;

/**
 * Filename:    $RCSfile: BuildBusinessAccountSearchCriteria.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: nbwald $    	 On:	$Date: 2008-09-08 19:19:15 $
 *
 * @author MMR
 * @version $Revision: 1.3 $
 */
public class BuildBusinessAccountSearchCriteria extends SymbolAcceptingColumnFixture {

    public String companyName;
    public String country;
    public String state;
    public String county;
    public String city;

    public BusinessAccountSearchCriteria criteria() {
        BusinessAccountSearchCriteria searchCriteria = new BusinessAccountSearchCriteria();
        searchCriteria.setCompanyName(getCompanyName());
        searchCriteria.setLocation(getLocation());
        return searchCriteria;
    }

    private SearchableLocation getLocation() {
        SearchableLocation location = new SearchableLocation();
        location.setCountryName(getCountry());
        location.setSubcountryCode(getState());
        location.setSubsubcountryName(getCounty());
        location.setCity(getCity());
        return location;
    }

    public String getCompanyName() {
        return companyName;
    }

    public String getCountry() {
        return country;
    }

    public String getState() {
        return state;
    }

    public String getCounty() {
        return county;
    }

    public String getCity() {
        return city;
    }

}
/*
* Revision Log
* : $
*/