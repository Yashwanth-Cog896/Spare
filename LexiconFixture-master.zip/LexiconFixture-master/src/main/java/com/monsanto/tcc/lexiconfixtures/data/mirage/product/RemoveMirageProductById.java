package com.monsanto.tcc.lexiconfixtures.data.mirage.product;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconfixtures.data.factories.mirage.MirageConnectionFactory;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Dec 18, 2006
 * Time: 3:34:45 PM
 * To change this template use File | Settings | File Templates.
 */
public class RemoveMirageProductById
{
   private Long productId;

   private SQLPropFile sqlPropFile = new SQLPropFile(MirageProductFixtureSQL.class);

   public RemoveMirageProductById(Long productId) {
      this.productId = productId;
   }

   public int remove()
      throws WrappingException
   {
      MirageConnectionFactory connectionFactory = new MirageConnectionFactory();
      PersistentStoreConnection conn = connectionFactory.getConnection();
      try {
         return deleteFakeData(conn);
      }
      finally {
         conn.close();
      }
   }

   private int deleteFakeData(PersistentStoreConnection conn)
      throws WrappingException
   {
      String sql = sqlPropFile.getSQL(MirageProductFixtureSQL.DELETE_PRODUCT);
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, productId);
         return stmt.executeDelete();
      }
      finally {
         stmt.close();
      }
   }
}
