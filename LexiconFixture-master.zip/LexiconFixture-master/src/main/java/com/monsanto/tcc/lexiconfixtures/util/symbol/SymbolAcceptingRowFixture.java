/*
 SymbolAcceptingRowFixture was created on Jul 16, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.util.symbol;

import fit.RowFixture;
import fit.Fixture;

/**
 * nbwald Jul 16, 2007 4:42:47 PM
 */
public abstract class SymbolAcceptingRowFixture
   extends RowFixture
{
   public Object parse(String expectedStringFromTable, Class type)
      throws Exception
   {
      if(expectedStringFromTable != null && expectedStringFromTable.startsWith("@")) {
         expectedStringFromTable = (String) Fixture.getSymbol(expectedStringFromTable);
      }
      return super.parse(expectedStringFromTable, type);
   }
}