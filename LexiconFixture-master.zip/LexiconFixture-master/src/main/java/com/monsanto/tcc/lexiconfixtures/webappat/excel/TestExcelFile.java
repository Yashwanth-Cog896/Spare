/*
 TestExcelFile was created on Oct 12, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.webappat.excel;

import java.io.File;

/**
 * nbwald Oct 12, 2007 11:53:54 AM
 */
public class TestExcelFile
{
   public static File getTestExcelFile() {
      return new File(getTestExcelFilePathAndName());
   }
   
   public static String getTestExcelFilePathAndName() {
      String fitNesseHome = System.getenv("FITNESSE_HOME");
      if (fitNesseHome == null) {
         throw new RuntimeException("Please set the FITNESSE_HOME environment variable.");
      }
      return fitNesseHome + "\\FitNesseRoot\\files\\acceptancetest\\FitNesseTestExcelFile.xls";
   }
}