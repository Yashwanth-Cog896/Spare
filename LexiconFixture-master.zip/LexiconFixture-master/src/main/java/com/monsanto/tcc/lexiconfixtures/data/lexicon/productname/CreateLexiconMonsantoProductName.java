package com.monsanto.tcc.lexiconfixtures.data.lexicon.productname;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.test.LexiconTestTools;
import com.monsanto.tcc.lexiconcommon.db.audit.LexiconAuditor;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.tcc.lexiconfixtures.util.ColumnFixtureResetter;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.dbdataservices.SQLUtil;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 7, 2006
 * Time: 12:23:20 PM
 * To change this template use File | Settings | File Templates.
 */
public class CreateLexiconMonsantoProductName
   extends SymbolAcceptingColumnFixture
{
   public Long productStageId;
   public String productStagePubkey;
   public Long productId;
   public String country;
   public String brand;
   public String stage;
   public String commercialName;
   public String testName;
   public String oecdName;
   public String commercialMaturity;  // Do this until I figure out how to get it to handle Double nicely...
   public boolean active;
   public String commercialTrait;
   public boolean logicalDelete;

   private SQLPropFile sqlPropFile = new SQLPropFile(LexiconProductNameFixtureSQL.class);

   public void reset()
      throws Exception
   {
      ColumnFixtureResetter.reset(this);
   }

   public boolean created()
      throws WrappingException
   {
      LexiconConnectionFactory connectionFactory = new LexiconConnectionFactory();
      PersistentStoreConnection conn = connectionFactory.getConnection();
      LexiconAuditor lexiconAuditor = LexiconTestTools.FITNESSE_TEST_AUDITOR;
      lexiconAuditor.initializeStaging(conn);
      try {
         int numInserted = insertFakeData(conn);
         return numInserted == 1;
      }
      finally {
         lexiconAuditor.removeStaging(conn);
         conn.close();
      }
   }

   private int insertFakeData(PersistentStoreConnection conn)
      throws WrappingException
   {
      String sql = sqlPropFile.getSQL(LexiconProductNameFixtureSQL.INSERT_PRODUCT_NAME);

      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         bindTheVariables(stmt);
         return stmt.executeInsert();
      }
      finally {
         stmt.close();
      }
   }

   private void bindTheVariables(PersistentStoreStatement stmt)
      throws WrappingException
   {
      stmt.setParam(1, productStageId);
      stmt.setParam(2, productStagePubkey);
      stmt.setParam(3, productId);
      stmt.setParam(4, StringUtils.toUpperCaseNull(country));
      stmt.setParam(5, StringUtils.toUpperCaseNull(brand));
      stmt.setParam(6, StringUtils.toUpperCaseNull(stage));
      stmt.setParam(7, productId);
      stmt.setParam(8, StringUtils.toUpperCaseNull(commercialTrait));
      stmt.setParam(9, StringUtils.toUpperCaseNull(commercialTrait));
      stmt.setParam(10, commercialName);
      stmt.setParam(11, oecdName);
      stmt.setParam(12, getCommercialMaturity());
      stmt.setParam(13, SQLUtil.booleanToString(active));
      stmt.setParam(14, SQLUtil.booleanToString(logicalDelete));
   }

   private Double getCommercialMaturity() {
      return commercialMaturity == null ? null : new Double(commercialMaturity);
   }
}
