/*
 ResponseAdapter was created on Nov 7, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.serviceat.artemis.country;

import com.monsanto.services.domain.geography.Country;

/**
 * nbwald Nov 7, 2007 10:12:28 AM
 */
public class ResponseAdapter
{
   public String countryPubkey;
   public String countryName;
   public String unAbbr;
   public Integer unCode;
   public String isoCode;

   public ResponseAdapter(Country country) {
      if(country != null) {
         this.countryPubkey = country.getPublicKey();
         this.countryName = country.getName();
         this.unAbbr = country.getUnAbbreviation();
         this.unCode = country.getUnCode();
         this.isoCode = country.getIsoCode();
      }
   }
}