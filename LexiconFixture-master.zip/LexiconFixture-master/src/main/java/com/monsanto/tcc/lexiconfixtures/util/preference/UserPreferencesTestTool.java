package com.monsanto.tcc.lexiconfixtures.util.preference;

import com.monsanto.Util.StringUtils;
import java.util.List;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: May 15, 2007
 * Time: 10:55:25 AM
 */
public class UserPreferencesTestTool
{
   public static String getCurrentPreferenceDefaultValue(String preferenceName)
      throws Exception
   {
      return new UserPreferenceDefaultValueQuery(preferenceName).getDefaultValue();
   }

   public static List<String> getCurrentPreferenceValues(String preferenceName)
      throws Exception
   {
      return new UserPreferenceValuesQuery(preferenceName).getList();
   }

   public static void setCurrentUsersDefaultPreferenceValue(String preferenceName, String defaultValue)
      throws Exception
   {
      new DeletePreferenceValues(preferenceName).performDelete();
      new UserPreferenceRecordSync(preferenceName, defaultValue).performAction();
      new InsertPreferenceValue(preferenceName, defaultValue).performInsert();
   }

   public static void setCurrentUsersPreferenceValues(String preferenceName, List<String> preferenceValues)
      throws Exception
   {
      new DeletePreferenceValues(preferenceName).performDelete();
      new UserPreferenceRecordSync(preferenceName, null).performAction();
      for (String preferenceValue : preferenceValues) {
         if (!StringUtils.isNullOrEmpty(preferenceValue)) {
            new InsertPreferenceValue(preferenceName, preferenceValue).performInsert();
         }
      }
   }

   public static String getCountryPreferenceValueFromAbbr(String countryAbbr)
      throws Exception
   {
      return new CountryPrefValueFromCountryAbbrQuery(countryAbbr).getValue();
   }
}
