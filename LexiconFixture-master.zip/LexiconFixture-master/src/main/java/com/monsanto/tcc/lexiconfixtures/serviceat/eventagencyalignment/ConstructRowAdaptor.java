package com.monsanto.tcc.lexiconfixtures.serviceat.eventagencyalignment;

import com.monsanto.tps.lexicon.event.EventComponent;
import com.monsanto.tps.lexicon.event.EventInfo;
import com.monsanto.tps.lexicon.event.Construct;

/**
 * nbwald - Feb 26, 2009 2:12:34 PM
 */
public class ConstructRowAdaptor
{
   public String eventName;
   public String crop;

   public String plasmidPmon;
   public String plasmidPvCode;

   public ConstructRowAdaptor(EventInfo eventInfo, Construct construct) {
      StringBuilder eventNameBuilder = new StringBuilder();
      if((eventInfo!=null)&&(eventInfo.getEventComponents()!=null)){
          for(EventComponent component: eventInfo.getEventComponents()){
             if(eventNameBuilder.length()>0){
                 eventNameBuilder.append(",");
             }
             eventNameBuilder.append(component.getEventName());
          }
      }
      this.eventName = eventNameBuilder.toString();
      this.crop = eventInfo.getCrop();
      this.plasmidPmon = construct.getPlasmidPMon();
      this.plasmidPvCode = construct.getPlasmidPVCode();
   }
}
