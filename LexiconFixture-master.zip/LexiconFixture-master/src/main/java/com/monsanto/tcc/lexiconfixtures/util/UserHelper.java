package com.monsanto.tcc.lexiconfixtures.util;

import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.securityinterfaces.SystemSecurityProxy;
import org.ietf.jgss.GSSException;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: May 15, 2007
 * Time: 10:58:18 AM
 */
public class UserHelper
{
   private static SystemSecurityProxy getSystemSecurityProxy()
      throws GSSException
   {
      return new KerberosStandaloneCredential();
   }

   public static String getCurrentUserLoginId()
      throws WrappingException
   {
      try {
         return getSystemSecurityProxy().getUserID().toUpperCase();
      }
      catch (GSSException e) {
         throw new WrappingException(e);
      }
   }
}
