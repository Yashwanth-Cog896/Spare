package com.monsanto.tcc.lexiconfixtures.data.mirage.allinfo;

import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import java.util.List;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Mar 19, 2007
 * Time: 2:48:06 PM
 * To change this template use File | Settings | File Templates.
 */
public class RemoveAllMirageProductInfo
   extends SymbolAcceptingColumnFixture
{
   public String productName;

   public boolean removed()
      throws WrappingException
   {
      int recordsRemoved = deleteFakeData();
      return recordsRemoved > 0;
   }

   public int removedThisManyRecords()
      throws WrappingException
   {
      int recordsRemoved = deleteFakeData();
      return recordsRemoved;
   }

   private int deleteFakeData()
      throws WrappingException
   {
      int recordsRemoved = 0;
      List productIds = new MirageSeedProductIdByProductNameQuery(productName).getIds();
      for (int i = 0; i < productIds.size(); i++) {
         Long productId = (Long)productIds.get(i);
         recordsRemoved += deleteMaturity(productId);
         recordsRemoved += deleteSeedProduct(productId);
         recordsRemoved += deleteYieldMartProduct(productId);
      }
      return recordsRemoved;
   }

   private int deleteMaturity(Long productId)
      throws WrappingException
   {
      return new DeleteProductMaturityByProductId(productId).performDelete();
   }

   private int deleteSeedProduct(Long productId)
      throws WrappingException
   {
      return new DeleteSeedProductByProductId(productId).performDelete();
   }

   private int deleteYieldMartProduct(Long productId)
      throws WrappingException
   {
      return new DeleteYieldMartProductByMirageId(productId).performDelete();
   }
}
