package com.monsanto.tcc.lexiconfixtures.util.approle.tpssecurity;

import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreDelete;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.data.factories.spsecurity.SpsecurityConnectionFactoryProperties;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald - Jul 14, 2009 3:40:23 PM
 */
public class RemoveRolesFromGroupDataMod
   extends AbstractPersistentStoreDelete
{
   private final String groupName;

   public RemoveRolesFromGroupDataMod(String groupName) {
      this.groupName = groupName;
   }

   protected String getSQL()
      throws WrappingException
   {
      return
         " DELETE" +
         "   FROM FBS_Common.SPS_Context_Priv_Group_Val" +
         "  WHERE context_priv_group_id = (" +
         "        SELECT CPG.context_priv_group_id" +
         "          FROM FBS_Common.SPS_Context_Priv_Group CPG" +
         "    INNER JOIN FBS_Common.SPS_Environment E on (CPG.environment_id = E.environment_id)" +
         "         WHERE E.name = 'LEXICON' " +
         "           AND E.active = 'T'" +
         "           AND CPG.name = ?" +
         " )";
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { groupName };
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new SpsecurityConnectionFactoryProperties();
   }
}
