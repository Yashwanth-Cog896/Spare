/*
 RemoveMirageCompany was created on Apr 17, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.data.mirage.company;

import com.monsanto.tcc.lexiconfixtures.data.factories.mirage.MirageConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * nbwald Apr 17, 2007 11:42:09 AM
 */
public class RemoveMirageCompany
   extends SymbolAcceptingColumnFixture
{
   public String companyName;

   public boolean removed()
      throws WrappingException
   {
      PersistentStoreConnection conn = new MirageConnectionFactory().getConnection();
      try {
         return companiesRemoved(conn) == 1;
      }
      finally {
         conn.close();
      }
   }

   public boolean clean()
      throws WrappingException
   {
      PersistentStoreConnection conn = new MirageConnectionFactory().getConnection();
      try {
         companiesRemoved(conn);
         return true;
      }
      finally {
         conn.close();
      }
   }

   private int companiesRemoved(PersistentStoreConnection conn)
      throws WrappingException
   {
      PersistentStoreStatement statement = conn.prepareStatement(getSQL());
      try {
         statement.setParam(1, companyName);
         return statement.executeDelete();
      }
      finally {
         statement.close();
      }
   }

   private String getSQL() {
      return "DELETE FROM Mirage2.Companies CO WHERE CO.company_name = ?";
   }
}