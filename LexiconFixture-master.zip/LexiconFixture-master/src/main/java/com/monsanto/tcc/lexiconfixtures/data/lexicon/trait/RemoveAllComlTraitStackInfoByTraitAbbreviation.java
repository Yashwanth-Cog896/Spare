package com.monsanto.tcc.lexiconfixtures.data.lexicon.trait;

import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactory;
import com.monsanto.tcc.lexiconcommon.db.test.LexiconTestTools;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;

/**
 * User: pjberry
 * Date: Sep 19, 2007
 * Time: 4:26:04 PM
 */
public class RemoveAllComlTraitStackInfoByTraitAbbreviation
   extends SymbolAcceptingColumnFixture
{
   public String traitAbbr;

   public boolean removed()
      throws WrappingException
   {
      PersistentStoreConnection conn = new LexiconConnectionFactory().getConnection();
      LexiconTestTools.FITNESSE_TEST_AUDITOR.initializeStaging(conn);
      try {
         return removeInfo(conn) > 0;
      }
      finally {
         LexiconTestTools.FITNESSE_TEST_AUDITOR.removeStaging(conn);
         conn.close();
      }
   }

   private int removeInfo(PersistentStoreConnection conn)
      throws WrappingException
   {
      Long comlTraitNameId = getComlTraitNameId(conn);
      Long[] comlTraitStackIds = getComlTraitStackIds(conn, comlTraitNameId);

      int numDeleted = 0;
      numDeleted += deleteComlTraitStackXrefs(conn, comlTraitStackIds);
      numDeleted += deleteComlTraitTypeXrefs(conn, comlTraitNameId);
      numDeleted += deleteComlTraitStacks(conn, comlTraitStackIds);
      numDeleted += deleteComlTraitNames(conn, comlTraitNameId);
      return numDeleted;
   }

   private Long getComlTraitNameId(PersistentStoreConnection conn)
      throws WrappingException
   {
      ComlTraitNameIdByTraitAbbreviationQuery query = new ComlTraitNameIdByTraitAbbreviationQuery(traitAbbr);
      return query.getComlTraitNameId(conn);
   }

   private Long[] getComlTraitStackIds(PersistentStoreConnection conn, Long comlTraitNameId)
      throws WrappingException
   {
      ComlTraitStackIdsByComlTraitNameIdQuery query = new ComlTraitStackIdsByComlTraitNameIdQuery(comlTraitNameId);
      return query.getComlTraitStackIds(conn);
   }

   private int deleteComlTraitStackXrefs(PersistentStoreConnection conn, Long[] comlTraitStackIds)
      throws WrappingException
   {
      DeleteComlTraitStackXrefsByComlTraitStackId deletion = new DeleteComlTraitStackXrefsByComlTraitStackId();
      int numDeleted = 0;
      for (Long comlTraitStackId : comlTraitStackIds) {
         numDeleted += deletion.delete(conn, comlTraitStackId);
      }
      return numDeleted;
   }

   private int deleteComlTraitTypeXrefs(PersistentStoreConnection conn, Long comlTraitNameId)
      throws WrappingException
   {
      DeleteComlTraitTypeXrefsByComlTraitNameIds deletion = new DeleteComlTraitTypeXrefsByComlTraitNameIds();
      return deletion.deleteComlTraitTypeXrefs(conn, new Long[] {comlTraitNameId});
   }

   private int deleteComlTraitNames(PersistentStoreConnection conn, Long comlTraitNameId)
      throws WrappingException
   {
      DeleteComlTraitNamesByComlTraitNameId deletion = new DeleteComlTraitNamesByComlTraitNameId();
      return deletion.deleteComlTraitNames(conn, new Long[]{comlTraitNameId});
   }

   private int deleteComlTraitStacks(PersistentStoreConnection conn, Long[] comlTraitStackIds)
      throws WrappingException
   {
      int numDeleted = 0;
      for (Long comlTraitStackId : comlTraitStackIds) {
         DeleteComlTraitStackByComlTraitStackId deletion = new DeleteComlTraitStackByComlTraitStackId(comlTraitStackId);
         numDeleted += deletion.performDelete(conn);
      }
      return numDeleted;
   }
}
