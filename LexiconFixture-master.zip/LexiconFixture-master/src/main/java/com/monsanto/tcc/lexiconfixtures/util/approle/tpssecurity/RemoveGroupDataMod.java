package com.monsanto.tcc.lexiconfixtures.util.approle.tpssecurity;

import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreDelete;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.data.factories.spsecurity.SpsecurityConnectionFactoryProperties;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald - Jul 14, 2009 3:53:08 PM
 */
public class RemoveGroupDataMod
   extends AbstractPersistentStoreDelete
{
   private final String groupName;

   public RemoveGroupDataMod(String groupName) {
      this.groupName = groupName;
   }

   protected String getSQL()
      throws WrappingException
   {
      return 
         " DELETE" +
         "   FROM FBS_Common.SPS_Context_Priv_Group" +
         "  WHERE name = ?" +
         "    AND environment_id = (SELECT environment_id FROM FBS_Common.SPS_Environment WHERE name = 'LEXICON' and active = 'T')";
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { groupName };
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new SpsecurityConnectionFactoryProperties();
   }
}
