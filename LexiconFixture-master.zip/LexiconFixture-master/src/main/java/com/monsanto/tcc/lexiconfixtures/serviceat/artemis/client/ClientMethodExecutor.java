/*
 ClientMethodExecutor was created on Jul 17, 2008 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the
 code and/or logic is a direct infringement of Monsanto's copyright.
*/

package com.monsanto.tcc.lexiconfixtures.serviceat.artemis.client;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * @author GGSHIV - Jul 17, 2008 3:27:58 PM
 */
public class ClientMethodExecutor<T> {

   public T[] execute(Object client, String clientMethod, Object[] params) {
      T[] resultArray = null;
      try {
         Method method = client.getClass().getMethod(clientMethod, getParamClasses(params));
         resultArray = (T[]) method.invoke(client, params);
      } catch (InvocationTargetException e) {
         if (e.getTargetException() instanceof IllegalArgumentException) {
            throw (IllegalArgumentException) e.getTargetException();
         }
         throwRunTimeException(e);
      } catch (NoSuchMethodException e) {
         throwRunTimeException(e);
      } catch (IllegalAccessException e) {
         throwRunTimeException(e);
      }
      return resultArray;
   }

   private void throwRunTimeException(Throwable e) {
      e.printStackTrace();
      throw new RuntimeException(e);
   }

   private Class<?>[] getParamClasses(Object[] params) {
      Class<?>[] classes = new Class[params.length];
      for (int i = 0; i < params.length; i++) {
         classes[i] = params[i].getClass();
      }
      return classes;
   }
}
