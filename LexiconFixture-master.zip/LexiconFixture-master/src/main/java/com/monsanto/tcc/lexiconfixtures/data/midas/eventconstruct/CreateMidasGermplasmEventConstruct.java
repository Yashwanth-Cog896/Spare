package com.monsanto.tcc.lexiconfixtures.data.midas.eventconstruct;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreInsert;
import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.ColumnFixtureResetter;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald - Mar 24, 2008 11:55:37 AM
 */
public class CreateMidasGermplasmEventConstruct
   extends SymbolAcceptingColumnFixture
{
   public Long germplasmEventConstructId;
   public Long eventConstructId;
   public Long germplasmId;

   public void reset()
      throws Exception
   {
      ColumnFixtureResetter.reset(this);
   }

   public boolean created()
      throws WrappingException
   {
      MidasGermplasmEventConstructInsert insert = new MidasGermplasmEventConstructInsert();
      return insert.performInsert() == 1;
   }

   private class MidasGermplasmEventConstructInsert
      extends AbstractPersistentStoreInsert
   {
      protected String getSQL()
         throws WrappingException
      {
         return "INSERT INTO Midas.Germplasm_Event_Construct (germplasm_event_construct_id, event_construct_id, germplasm_id)" +
            " VALUES (?, ?, ?)";
      }

      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[] { germplasmEventConstructId, eventConstructId, germplasmId };
      }

      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new MidasConnectionFactoryProperties();
      }
   }
}
