package com.monsanto.tcc.lexiconfixtures.data.lexicon.product;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.test.LexiconTestTools;
import com.monsanto.tcc.lexiconcommon.db.audit.LexiconAuditor;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Feb 16, 2007
 * Time: 2:40:45 PM
 */
public class RemoveLexiconCompetitiveProduct
   extends SymbolAcceptingColumnFixture
{
   public String productPubkey;

   private SQLPropFile sqlPropFile = new SQLPropFile(LexiconProductFixtureSQL.class);

   public boolean removed()
      throws WrappingException
   {
      LexiconConnectionFactory connectionFactory = new LexiconConnectionFactory();
      PersistentStoreConnection conn = connectionFactory.getConnection();
      LexiconAuditor lexiconAuditor = LexiconTestTools.FITNESSE_TEST_AUDITOR;
      lexiconAuditor.initializeStaging(conn);
      try {
         int numDeleted = deleteFakeData(conn);
         return numDeleted == 1;
      }
      finally {
         lexiconAuditor.removeStaging(conn);
         conn.close();
      }
   }

   private int deleteFakeData(PersistentStoreConnection conn)
      throws WrappingException
   {
      String productDeleteSQL = sqlPropFile.getSQL(LexiconProductFixtureSQL.DELETE_COMPETITIVE_PRODUCT);
      PersistentStoreStatement stmt = conn.prepareStatement(productDeleteSQL);
      try {
         stmt.setParam(1, productPubkey);
         return stmt.executeDelete();
      }
      finally {
         stmt.close();
      }
   }
}
