package com.monsanto.tcc.lexiconfixtures.data.midas.parentage;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jun 22, 2007
 * Time: 5:00:39 PM
 */
public interface MidasParentageFixtureSQL
{
   String INSERT_PARENTAGE = "InsertParentage";
   String DELETE_PARENTAGE = "DeleteParentage";
   String SELECT_PARENTAGE = "SelectParentage";
}
