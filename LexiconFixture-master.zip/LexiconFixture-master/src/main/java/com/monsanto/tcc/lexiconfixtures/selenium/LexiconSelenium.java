package com.monsanto.tcc.lexiconfixtures.selenium;

import com.monsanto.Util.StringUtils;
import com.thoughtworks.selenium.DefaultSelenium;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: May 8, 2007
 * Time: 5:39:30 PM
 */
public class LexiconSelenium
   extends DefaultSelenium
{
   private final String browserURL;

   public LexiconSelenium(String seleniumServerHost, int seleniumServerPort,
      String browserStartCommand, String browserURL)
   {
      super(seleniumServerHost, seleniumServerPort, browserStartCommand, browserURL);
      this.browserURL = browserURL;
   }

   public void start() {
      super.start();
      open(browserURL + "/lexicon-app");
      waitForLocation("*lexicon-app/servlet/Lexicon*");
   }

   public void waitForLocation(String locator) {
      String[] args = new String[] {locator};
      commandProcessor.doCommand("waitForLocation", args);
   }

   public void waitForElementPresent(String locator) {
      String[] args = new String[] {locator};
      commandProcessor.doCommand("waitForElementPresent", args);
   }

   public void waitForNotElementPresent(String locator) {
      String[] args = new String[] {locator};
      commandProcessor.doCommand("waitForNotElementPresent", args);
   }

   public String[] getChildImageIds(String locator) {
      return getChildValuesByTagName(locator, "IMG", "getAttribute('id')");
   }

   public String[] getChildImageNames(String locator) {
      return getChildValuesByTagName(locator, "IMG", "getAttribute('src')");
   }

   public String[] getChildAnchorTexts(String locator) {
      return getChildValuesByTagName(locator, "A", "firstChild.nodeValue");
   }

   public String[] getChildListItemTexts(String locator) {
      return getChildValuesByTagName(locator, "LI", "firstChild.nodeValue");
   }

   public String getFieldValue(String locator) {
      if (isInputType(locator)) {
         return getDisplayValue(locator);
      }
      else if (!hasChildren(locator)) {
         return getText(locator);
      }
      else {
         String childElementIdentifier = getChildElementIdentifier(locator);
         return getFieldValue(childElementIdentifier);
      }
   }

   public String evaluate(String expression) {
      String result = getEval(expression);
      return "null".equals(result) ? null : result;
   }

   public void toolbarValidate(String maxWaitTimeInMs) {
      click("toolbarValidate");
      waitForPageToLoad(maxWaitTimeInMs);
   }

   public void toolbarCommit(String maxWaitTimeInMs) {
      click("toolbarCommit");
      waitForPageToLoad(maxWaitTimeInMs);
   }

   public void validate(String maxWaitTimeInMs) {
      click("validate");
      waitForPageToLoad(maxWaitTimeInMs);
   }

   public void commit(String maxWaitTimeInMs) {
      click("commit");
      waitForPageToLoad(maxWaitTimeInMs);
   }

   public boolean isFieldEditable(String locator) {
      if(isFormInputTag(getTagName(locator))) {
         return isEditable(locator);
      }
      else if(!hasChildren(locator)) {
         return false;
      }
      else {
         String childElementIdentifier = getChildElementIdentifier(locator);
         return isFieldEditable(childElementIdentifier);
      }
   }

   private String[] getChildValuesByTagName(String locator, String tagName, String nodeAttribute) {
      final String delimiter = ",";
      String escapedLocator = escapeSingleQuoutes(locator);
      String snippetForChildValues =
         " {" +
            " var parentElem = this.page().findElement('" + escapedLocator + "'); " +
            " var children = parentElem.getElementsByTagName('" + tagName + "'); " +
            " var values = ''; " +
            " for(i=0; i < children.length; i++) { " +
            "  if(i > 0) values = values + '" + delimiter + "';   " +
            "  values = values + children[i]." + nodeAttribute + ";" +
            " }; " +
            "values" +
            "}";
      String delimitedValues = evaluate(snippetForChildValues);
      return delimitedValues.split(delimiter);
   }

   private String getChildElementName(String locator) {
      String escapedLocator = escapeSingleQuoutes(locator);
      String snippetForChildElementName = "{this.page().findElement('" + escapedLocator + "').firstChild.name}";
      return evaluate(snippetForChildElementName);
   }

   private String getChildElementId(String locator) {
      String escapedLocator = escapeSingleQuoutes(locator);
      String snippetForChildElementName = "{this.page().findElement('" + escapedLocator + "').firstChild.id}";
      return evaluate(snippetForChildElementName);
   }

   private String getChildElementIdentifier(String parentLocator) {
      String childElementId = getChildElementId(parentLocator);
      if (!StringUtils.isNullOrEmpty(childElementId)) {
         return childElementId;
      }

      String childElementName = getChildElementName(parentLocator);
      if (!StringUtils.isNullOrEmpty(childElementName)) {
         return childElementName;
      }

      return "nofind";
   }

   private boolean hasChildren(String locator) {
      String returnValue = evaluate("{this.page().findElement('" + locator + "').firstChild}");
      if (!"[object]".equals(returnValue)) {
         return false;
      }

      String nodeName = evaluate("{this.page().findElement('" + locator + "').firstChild.nodeName}");
      return !"#text".equals(nodeName);
   }

   private String getDisplayValue(String locator) {
      String tagName = getTagName(locator);
      if ("select".equalsIgnoreCase(tagName)) {
         return getSelectedLabel(locator);
      }
      else if ("input".equalsIgnoreCase(tagName)) {
         String seleniumValue = getValue(locator);
         String inputTypeAttribute = getAttribute(locator + "@type");
         if ("checkbox".equalsIgnoreCase(inputTypeAttribute) || "radio".equalsIgnoreCase(inputTypeAttribute)) {
            return "on".equals(seleniumValue) ? "checked" : "unchecked";
         }
      }
      return getValue(locator);
   }

   private boolean isInputType(String locator) {
      String tagName = getTagName(locator);
      return isFormInputTag(tagName);
   }

   private boolean isFormInputTag(String tagName) {
      return "input".equalsIgnoreCase(tagName)
         || "select".equalsIgnoreCase(tagName)
         || "textarea".equalsIgnoreCase(tagName);
   }

   private String getTagName(String locator) {
      return evaluate("{this.page().findElement('" + locator + "').tagName}");
   }

   private String escapeSingleQuoutes(String locator) {
      return locator.replaceAll("\'", "\\\\'");
   }
}

