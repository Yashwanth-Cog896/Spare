/*
 ProductRelationshipXrefCascadeDelete was created on Jul 17, 2007 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo.cascadingdelete;

import com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo.cascadingdelete.query.delete.ProductRelationshipXrefDelete;
import com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo.cascadingdelete.query.delete.AbstractLexiconDeleteByIDDataMod;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald Jul 17, 2007 12:05:29 PM
 */
public class ProductRelationshipXrefCascadeDelete
   extends AbstractCascadingDelete
{
   private final long xrefId;

   public ProductRelationshipXrefCascadeDelete(long xrefId) {
      this.xrefId = xrefId;
   }

   protected boolean removeDependencies() {
      return true;
   }

   protected AbstractLexiconDeleteByIDDataMod getSelfDeleter() {
      return new ProductRelationshipXrefDelete(xrefId);
   }
}