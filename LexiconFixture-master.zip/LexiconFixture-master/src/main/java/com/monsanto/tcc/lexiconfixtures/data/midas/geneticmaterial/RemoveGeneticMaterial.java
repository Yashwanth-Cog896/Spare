package com.monsanto.tcc.lexiconfixtures.data.midas.geneticmaterial;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreDelete;
import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 7, 2006
 * Time: 4:35:45 PM
 * To change this template use File | Settings | File Templates.
 */
public class RemoveGeneticMaterial
   extends SymbolAcceptingColumnFixture
{
   public Long germplasmId;

   public boolean removed()
      throws WrappingException
   {
      GeneticMaterialDelete dataMod = new GeneticMaterialDelete();
      return dataMod.performDelete() == 1;
   }

   class GeneticMaterialDelete
      extends AbstractPersistentStoreDelete
   {
      protected String getSQL() throws WrappingException {
         return new SQLPropFile(GeneticMaterialFixtureSQL.class).getSQL(GeneticMaterialFixtureSQL.DELETE_GENETIC_MATERIAL);
      }
      protected Object[] getBindVariables() throws WrappingException {
         return new Object[] { germplasmId };
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new MidasConnectionFactoryProperties();
      }
   }
}
