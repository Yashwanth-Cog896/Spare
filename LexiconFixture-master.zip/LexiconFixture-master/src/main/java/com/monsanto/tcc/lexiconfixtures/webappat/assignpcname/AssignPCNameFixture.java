/*
 AssignPCNameFixture was created on Mar 14, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.webappat.assignpcname;

import com.monsanto.tcc.lexiconfixtures.webappat.SeleniumFixture;
import com.monsanto.tcc.lexiconfixtures.webappat.preference.country.CountryPrefsStorageTool;
import com.monsanto.tcc.lexiconfixtures.webappat.preference.country.SetPrimaryCountries;
import com.monsanto.tcc.lexiconfixtures.webappat.preference.country.SetSecondaryCountries;
import fit.Fixture;

/**
 * nbwald Mar 14, 2007 4:53:03 PM
 */
public class AssignPCNameFixture
   extends SeleniumFixture
{
   private CountryPrefsStorageTool countryPrefsTestTool;

   public AssignPCNameFixture() {
      countryPrefsTestTool = new CountryPrefsStorageTool();
   }

   public boolean saveCountryPreferences()
      throws Exception
   {
      countryPrefsTestTool.saveCountryPreferences();
      return true;
   }

   public boolean restoreCountryPreferences()
      throws Exception
   {
      countryPrefsTestTool.restoreCountryPreferences();
      return true;
   }

   public Fixture primaryCountryList() {
      return new SetPrimaryCountries();
   }

   public Fixture secondaryCountryList() {
      return new SetSecondaryCountries();
   }

   public Fixture countriesIn(String locator) {
      String countryAbbrCsv = getSelenium().getFieldValue(locator);
      return new CountryAbbrCsvFixture(countryAbbrCsv);
   }

   public Fixture countryOptionsIn(String locator) {
      String countryNamesAndAbbrs = getSelenium().getText(locator);
      return new CountryOptionsFixture(countryNamesAndAbbrs);
   }

   public Fixture countryOptionsCheckedIn(String locator) {
      String snippet =
         "{"
            + "var tableElem = this.page().findElement('" + locator +"'); "
            + "var trElems = tableElem.getElementsByTagName('TR'); "
            + "var values = ''; "
            + "for(var i = 0; i < trElems.length; i++) { "
            + "   if(values != '') values = values + '\\n'; "
            + "   var tdElems = trElems[i].childNodes; "
            + "   var inputElem = tdElems[0].firstChild; "
            + "   var countryName = tdElems[1].firstChild.nodeValue; "
            + "   var countryAbbr = tdElems[2].firstChild.nodeValue; "
            + "   if(inputElem.checked) { "
            + "      values = values + countryName + ' ' + countryAbbr; "
            + "   }"
            + "}"
            + "values;" +
         "}"
         ;
      String countryNamesAndAbbrs = getSelenium().evaluate(snippet);
      return new CountryOptionsFixture(countryNamesAndAbbrs);
   }

   public boolean isChecked(String checkboxLocator, boolean checked) {
      return getSelenium().isChecked(checkboxLocator) == checked;
   }

   public boolean selectForOn(String optionLocator, String selectName, String areaLocator) {
      // For some reason these xpaths need the td[2] part (it can't be skipped with a //).  I have no idea why. -Nathan
      if ("single query".equals(areaLocator)) {
         return selectFor(optionLocator, "xpath=//form[@name='germPlasmLookup']//td[2]/select[@name='" + selectName + "']");
      }
      else if ("template upload".equals(areaLocator)) {
         return selectFor(optionLocator, "xpath=//form[@name='FileChooser']//td[2]/select[@name='" + selectName + "']");
      }
      else {
         throw new IllegalArgumentException("Area locator '" + areaLocator + "' is invalid.  Expecting 'single query' or 'template upload'.");
      }
   }

   public boolean selectFor(String optionLocator, String selectLocator) {
      if("cropName".equalsIgnoreCase(selectLocator)) {
         throw new IllegalArgumentException("On the AssignPCName screen, you probably want to use:\n|select|SOMECROP|for|cropName|on|single query|\nor\n|select|SOMECROP|for|cropName|on|template upload|.  If not, remove this exception.");
      }
      return super.selectFor(optionLocator, selectLocator);
   }
}