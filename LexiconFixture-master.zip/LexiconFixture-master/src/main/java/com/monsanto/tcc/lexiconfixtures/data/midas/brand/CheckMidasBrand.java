/*
 CheckMidasBrand was created on Apr 17, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.data.midas.brand;

import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.EmptyResultSetException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetSingleResult;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * nbwald Apr 17, 2007 11:00:21 AM
 */
public class CheckMidasBrand
   extends SymbolAcceptingColumnFixture
{
   public String brandName;
   public String refActive;

   public boolean exists()
      throws WrappingException
   {
      PersistentStoreConnection conn = new MidasConnectionFactory().getConnection();
      try {
         return matchingBrands(conn) == 1;
      }
      finally {
         conn.close();
      }
   }

   private int matchingBrands(PersistentStoreConnection conn)
      throws WrappingException
   {
      PersistentStoreStatement statement = conn.prepareStatement(getSQL());
      try {
         statement.setParam(1, brandName);
         statement.setParam(2, refActive);
         PersistentStoreResultSetSingleResult result = statement.executeQuery().getSingleResult();
         return result.getInt(1);
      }
      catch (EmptyResultSetException e) {
         return 0;
      } finally {
         statement.close();
      }
   }

   private String getSQL() {
      return
         "     SELECT count(*)" +
         "       FROM Midas.Brand B" +
         " INNER JOIN Midas.Company CO" +
         "         ON B.company_id = CO.company_id" +
         "      WHERE B.name = ?" +
         "        AND B.ref_active = ?";
   }
}