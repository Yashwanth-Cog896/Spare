package com.monsanto.tcc.lexiconfixtures.util.date;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import fit.ColumnFixture;

/**
 * User: pjberry
 * Date: Jul 19, 2007
 * Time: 10:56:29 AM
 */
public class GetCurrentDatabaseDate
   extends ColumnFixture
{
   public String date()
      throws WrappingException
   {
      CurrentDateQuery query = new CurrentDateQuery();
      return query.getDate();
   }

   private class CurrentDateQuery
      extends AbstractPersistentStoreSingleResultQuery
   {
      public String getDate()
         throws WrappingException
      {
         return (String) execute();
      }

      protected Object createObjectFromRow(PersistentStoreResultSetRow row)
         throws WrappingException
      {
         return row.getString(1);
      }

      protected String getSQL()
         throws WrappingException
      {
         return "SELECT TO_CHAR(current_date, 'yyyy/mm/dd:hh24:mi:ss') FROM dual";
      }

      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[0];
      }

      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return  new LexiconConnectionFactoryProperties();
      }
   }
}
