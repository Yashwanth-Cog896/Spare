package com.monsanto.tcc.lexiconfixtures.serviceat.agency;

import com.monsanto.tps.lexicon.agency.AgencyDepartment;

/**
 * rrchak1 - Oct 23, 2008 4:23:25 PM
 */
public class EmptyAgencyDepartmentRecord
{
   public static AgencyDepartment[] get() {
      AgencyDepartment department = new AgencyDepartment();
      return new AgencyDepartment[] { department };
   }
}
