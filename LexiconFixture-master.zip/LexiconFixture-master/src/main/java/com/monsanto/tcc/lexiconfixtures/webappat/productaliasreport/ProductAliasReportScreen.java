package com.monsanto.tcc.lexiconfixtures.webappat.productaliasreport;

import com.meterware.httpunit.Button;
import com.meterware.httpunit.HTMLElement;
import com.meterware.httpunit.HttpUnitOptions;
import com.meterware.httpunit.WebConversation;
import com.meterware.httpunit.WebForm;
import com.meterware.httpunit.WebLink;
import com.meterware.httpunit.WebResponse;
import com.monsanto.tcc.lexiconcommon.file.excel.ExcelReader;
import com.monsanto.tcc.lexiconcommon.test.LexiconATBase;
import com.monsanto.tcc.lexiconfixtures.util.symbol.LongParseDelagate;
import com.monsanto.tcc.lexiconfixtures.util.symbol.StringParseDelagate;
import com.monsanto.tcc.lexiconfixtures.webappat.excel.screenfixture.HttpUnitUtils;
import fit.Fixture;
import fitlibrary.DoFixture;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.io.InputStream;
import java.security.PrivilegedActionException;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Feb 23, 2007
 * Time: 9:55:40 AM
 */
public class ProductAliasReportScreen
   extends DoFixture
{
   private KerberizedWebInteraction interaction;
   private WebConversation conversation;
   private WebResponse currentPage;

   public ProductAliasReportScreen() {
      registerParseDelegate(String.class, new StringParseDelagate());
      registerParseDelegate(Long.class, new LongParseDelagate());
   }

   public boolean connect()
      throws Exception
   {
      interaction = new KerberizedWebInteraction("ProductAliasReportScreen");
      try {
         // try...
         tryStartingConversation();
      }
      catch (PrivilegedActionException e) {
         // try again...
         Thread.sleep(5000);
         tryStartingConversation();
      }
      return true;
   }

   private void tryStartingConversation()
      throws Exception
   {
      interaction.setUp();
      conversation = interaction.getConversation();
   }

   public boolean clickLinkWithHeading(String link, String heading)
      throws IOException, SAXException
   {
      if(heading.equals("Monsanto Products") && link.equals("Product Report")) {
         currentPage = conversation.getResponse(interaction.getServletURL("ProductAliasGateway"));
      } else {
         throw new RuntimeException("Cannot Find Requested Link");
      }
       return true;
   }

   public boolean clickLink(String linkIdentifier)
      throws SAXException, IOException
   {
      WebLink link = currentPage.getLinkWith(linkIdentifier);
      currentPage = link.click();
      return true;
   }

   public boolean enterFor(String value, String textInputIdentifier)
      throws IOException, SAXException
   {
      WebForm queryPanelForm = getQueryPanelForm();
      queryPanelForm.setParameter(textInputIdentifier, value);
      return true;
   }

   public boolean selectFor(String value, String selectIdentifier)
      throws SAXException
   {
      getQueryPanelForm().setParameter(selectIdentifier, value);
      return true;
   }

   public boolean clickAndWaitForPageToLoad(String thingToClick)
      throws Exception
   {
      if("run".equalsIgnoreCase(thingToClick)) {
         currentPage = HttpUnitUtils.submitForm(getQueryPanelForm(), "runButton");
         return true;
      }
      else if ("Download Excel Report".equalsIgnoreCase(thingToClick)) {
         WebForm excelReportForm = currentPage.getFormWithName("excelReportForm");
         currentPage = excelReportForm.submit();
         return true;
      }
      return false;
   }

   public boolean click(String thingToClick)
      throws IOException, SAXException
   {
      if("reset".equalsIgnoreCase(thingToClick)) {
         HttpUnitOptions.setScriptingEnabled(true);
         HttpUnitOptions.setExceptionsThrownOnScriptError(true);
         Button resetButton = getQueryPanelForm().getButtonWithID("resetButton");
         resetButton.click();
         return true;
      }
      else {
         return false;
      }
   }

   public String fieldIs(String elementId)
      throws SAXException
   {
      HTMLElement element = currentPage.getElementWithID(elementId);
      return element.getText();
   }

   public Fixture checkExcelSpreadsheet()
      throws IOException
   {
      InputStream excelStream = currentPage.getInputStream();
      try {
         ExcelReader excelReader = new ExcelReader(excelStream);
         return new ExcelSpreadSheetFixture(excelReader);
      }
      finally {
         excelStream.close();
      }
   }

   public boolean uncheck(String checkboxName)
      throws SAXException
   {
      getQueryPanelForm().setCheckbox(checkboxName, false);
      return true;
   }

   public boolean setChecked(String checkboxName)
      throws SAXException
   {
      getQueryPanelForm().setCheckbox(checkboxName, true);
      return true;
   }

   public String nameType()
      throws SAXException
   {
      return getQueryPanelForm().getParameterValue("nameType");
   }

   public String activeOnly()
      throws SAXException
   {
      return getQueryPanelForm().getParameterValue("activeOnly");
   }

   public String traitAnd()
      throws SAXException
   {
      return getQueryPanelForm().getParameterValue("traitAnd");
   }

   public String productType()
      throws SAXException
   {
      return getQueryPanelForm().getParameterValue("productType");
   }

   public String comlTraits()
      throws SAXException
   {
      return getQueryPanelForm().getParameterValue("comlTraits");
   }

   public String alert()
      throws SAXException
   {
      HTMLElement userWarningsElem = currentPage.getElementWithID("userWarnings");
      return userWarningsElem.getText();
   }

   public boolean disconnect()
      throws Exception
   {
      interaction.tearDown();
      return true;
   }

   private WebForm getQueryPanelForm()
      throws SAXException
   {
      return currentPage.getFormWithName("monProdStageQuery");
   }

   class KerberizedWebInteraction
      extends LexiconATBase
   {
      public KerberizedWebInteraction(String name) {
         super(name);
      }
   }
}
