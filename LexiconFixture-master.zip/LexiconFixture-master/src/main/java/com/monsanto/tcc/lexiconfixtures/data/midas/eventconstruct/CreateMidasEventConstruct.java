package com.monsanto.tcc.lexiconfixtures.data.midas.eventconstruct;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreInsert;
import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.data.midas.util.MidasBoolean;
import com.monsanto.tcc.lexiconfixtures.util.ColumnFixtureResetter;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald - Mar 24, 2008 11:48:57 AM
 */
public class CreateMidasEventConstruct
   extends SymbolAcceptingColumnFixture
{
   public Long eventConstructId;
   public String crop;
   public String constructName;
   public String eventName;
   public boolean refActive;

   public void reset()
      throws Exception
   {
      ColumnFixtureResetter.reset(this);
   }

   public boolean created()
      throws WrappingException
   {
      MidasEventConstructInsert insert = new MidasEventConstructInsert();
      return insert.performInsert() == 1;
   }

   private class MidasEventConstructInsert
      extends AbstractPersistentStoreInsert
   {
      protected String getSQL()
         throws WrappingException
      {
         return
            "INSERT INTO Midas.Event_Construct (event_construct_id, crop_id, construct_name, event_name, ref_active) " +
            "VALUES (?, (SELECT C.crop_id FROM Midas.Crop C WHERE UPPER(C.name) = UPPER(?) AND C.ref_active = 'T'), ?, ?, ?)";
      }

      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[] { eventConstructId, crop, constructName, eventName, MidasBoolean.toString(refActive) };
      }

      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new MidasConnectionFactoryProperties();
      }
   }
}
