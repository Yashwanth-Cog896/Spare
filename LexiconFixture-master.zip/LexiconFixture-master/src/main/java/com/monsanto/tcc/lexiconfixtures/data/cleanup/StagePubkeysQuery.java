package com.monsanto.tcc.lexiconfixtures.data.cleanup;

import com.monsanto.tcc.lexiconcommon.db.SqlUtilities;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import java.util.List;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Apr 30, 2007
 * Time: 12:24:04 PM
 * To change this template use File | Settings | File Templates.
 */
class StagePubkeysQuery
   extends AbstractPersistentStoreMultiRowQuery
{
   private List prodPubkeys;
   public StagePubkeysQuery() {
   }
   public StagePubkeysQuery(final List prodPubkeys) {
      this.prodPubkeys = prodPubkeys;
   }

   public List getPubkeyList()throws WrappingException {
      return super.getList();
   }
   protected Object createObjectFromRow(PersistentStoreResultSetRow row) throws WrappingException {
      return row.getString(1);
   }
   protected Object[] getBindVariables() throws WrappingException {
      return new Object[0];
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }

   protected String getSQL()
      throws WrappingException
   {
      if (prodPubkeys == null) {
         prodPubkeys = new ProductPubkeysQuery().getPubkeyList();
      }
      return "SELECT product_stage_pubkey " +
         "FROM Lexicon.Product_Stage PS, Lexicon.Pre_Coml_Product PCP " +
         "WHERE PS.product_id = PCP.product_id " +
         "AND ( " + SqlUtilities.makeInListOfStrings("PCP.product_pubkey", prodPubkeys) +
         " OR "   + DeleteRandomValueData.getNameClause("PS.product_stage_pubkey") +
         " OR " + DeleteRandomValueData.getNameClause("PS.commercial_name") +
         " OR " + DeleteRandomValueData.getNumberClause("PS.product_stage_id") +
         ")";
   }
}
