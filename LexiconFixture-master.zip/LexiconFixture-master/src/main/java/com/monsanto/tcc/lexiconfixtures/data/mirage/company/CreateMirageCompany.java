/*
 CreateMirageCompany was created on Apr 17, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.data.mirage.company;

import com.monsanto.tcc.lexiconfixtures.data.factories.mirage.MirageConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * nbwald Apr 17, 2007 11:39:00 AM
 */
public class CreateMirageCompany
   extends SymbolAcceptingColumnFixture
{
   public long companyID;
   public String companyName;
   public String companyAbbr;
   public String seedFlag;

   public boolean created()
      throws WrappingException
   {
      PersistentStoreConnection conn = new MirageConnectionFactory().getConnection();
      try {
         return createCompany(conn) == 1;
      }
      finally {
         conn.close();
      }
   }

   private int createCompany(PersistentStoreConnection conn)
      throws WrappingException
   {
      PersistentStoreStatement statement = conn.prepareStatement(getSQL());
      try {
         bindSQLParams(statement);
         return statement.executeInsert();
      }
      finally {
         statement.close();
      }
   }

   private void bindSQLParams(PersistentStoreStatement statement) throws WrappingException {
      statement.setParam(1, companyID);
      statement.setParam(2, companyName);
      statement.setParam(3, companyAbbr);
      statement.setParam(4, seedFlag);
   }

   private String getSQL() {
      return "INSERT INTO Mirage2.Companies " +
         "(company_id, company_name, company_abbrev, seed_flag) " +
         "VALUES " +
         "(?, ?, ?, ?)";
   }
}