/*
 LexiconServiceUrlResolver was created on Nov 7, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.serviceat.artemis.common;

import com.monsanto.tcc.constellation.serviceconnection.ServiceCommunicationException;
import com.monsanto.tcc.constellation.serviceconnection.ServiceUrlResolver;
import com.monsanto.tcc.lexiconcommon.pos.LexiconURLMap;
import com.monsanto.tcc.lexiconcommon.props.PropertyManager;
import com.monsanto.Util.EnvironmentHelperException;
import org.xml.sax.SAXException;
import javax.xml.transform.TransformerException;
import java.io.IOException;
import java.util.Properties;

/**
 * nbwald Nov 7, 2007 12:34:53 PM
 *
 * WARNING: This class is duplicated from LexiconPOS.  I did not put this class in LexiconCommon because
 * it has constellation dependencies.  If LexiconCommon relied on constellation, all projects that rely on
 * LexiconCommon would also have to have the constellation dependencies. 
 */
public class LexiconServiceUrlResolver
   implements ServiceUrlResolver
{
   public String getServiceUrlString(String serviceName)
      throws ServiceCommunicationException
   {
      try {
         return getUrl(serviceName);
      }
      catch (Exception e) {
         throw new ServiceCommunicationException(e);
      }
   }

   private String getUrl(String serviceName)
      throws EnvironmentHelperException, TransformerException, IOException, SAXException
   {
      return new LexiconURLMap(getOverrideDefinitions()).getURL(serviceName);
   }

   private Properties getOverrideDefinitions()
      throws IOException
   {
      return PropertyManager.getInstance().getProperties(LexiconURLMap.class, "LexiconURLMap.properties");
   }
}