package com.monsanto.tcc.lexiconfixtures.data.fbscommon.productname;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 13, 2006
 * Time: 9:12:24 AM
 * To change this template use File | Settings | File Templates.
 */
public interface FBSCommonProductNameFixtureSQL
{
   String INSERT_PRODUCT_NAME = "InsertProductName";
   String DELETE_PRODUCT_NAME = "DeleteProductName";

   String SELECT_MATCHING_NAME_XREF_BYALLIDS = "SelectMatchingNameXrefByAllIds";
   String SELECT_NUM_OF_PROD_NAME_XREF_MATCHING_MIDAS_ALIAS_ID = "SelectNumFBSProductNameMatchingMidasAliasId";

   String COUNTRY_XREF_QUERY = "SelectCountryXref";
   String COUNTRY_PUBKEY_ALIAS = "Country.Pubkey";
   String MIDAS_COUNTRY_ID_ALIAS = "Country.MidasId";
   String MIRAGE_COUNTRY_CODE_ALIAS = "Country.MirageCode";

   String BRAND_XREF_QUERY = "SelectBrandXref";
   String BRAND_PUBKEY_ALIAS = "Brand.Pubkey";
   String MIDAS_BRAND_ID_ALIAS = "Brand.MidasId";
   String MIRAGE_BRAND_ID_ALIAS = "Brand.MirageId";
}
