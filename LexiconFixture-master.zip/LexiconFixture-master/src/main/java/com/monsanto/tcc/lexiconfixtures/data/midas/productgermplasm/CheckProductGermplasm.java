package com.monsanto.tcc.lexiconfixtures.data.midas.productgermplasm;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.data.midas.product.MidasProductIdByPreComlNameQuery;
import com.monsanto.tcc.lexiconfixtures.util.ColumnFixtureResetter;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.EmptyResultSetException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetSingleResult;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: kinugan
 * Date: Mar 27, 2007
 * Time: 4:37:45 PM
 */
public class CheckProductGermplasm
   extends SymbolAcceptingColumnFixture
{
   public String precomlName;
   public long germplasmId;

   public void reset()
      throws Exception
   {
      ColumnFixtureResetter.reset(this);
   }

   public boolean exists() throws WrappingException, EmptyResultSetException
   {
      MidasConnectionFactory connectionFactory = new MidasConnectionFactory();
      PersistentStoreConnection conn = connectionFactory.getConnection();
      try {
         int numFound = getNumberOfMatches(conn);
         return numFound == 1;
      }
      finally {
         conn.close();
      }
   }

   private int getNumberOfMatches(PersistentStoreConnection conn) throws WrappingException, EmptyResultSetException
   {
      String sql = getSQL();
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         bindTheVariables(stmt);
         PersistentStoreResultSetSingleResult rs = stmt.executeQuery().getSingleResult();
         return rs.getInt(1);
      }
      finally {
         stmt.close();
      }
   }

   private String getSQL() throws WrappingException
   {
      SQLPropFile sqlPropFile = new SQLPropFile(ProductGermplasmFixtureSQL.class);
      return sqlPropFile.getSQL(ProductGermplasmFixtureSQL.SELECT_NUM_OF_MATCHING_XREF);
   }

   private void bindTheVariables(PersistentStoreStatement stmt) throws WrappingException
   {
      stmt.setParam(1, getProductId());
      stmt.setParam(2, germplasmId);
   }

   private Long getProductId() throws WrappingException
   {
      MidasProductIdByPreComlNameQuery productIdQuery = new MidasProductIdByPreComlNameQuery(precomlName);
      return productIdQuery.getProductId();
   }
}
