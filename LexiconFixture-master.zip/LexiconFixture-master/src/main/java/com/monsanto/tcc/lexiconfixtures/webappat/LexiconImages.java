/*
 LexiconImages was created on Apr 19, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.webappat;

import com.monsanto.Util.StringUtils;

/**
 * nbwald Apr 19, 2007 11:16:55 AM
 */
public class LexiconImages
{
   public static String iconFromImageSource(String imageName)
   {
      if(StringUtils.isNullOrEmpty(imageName)) return "";
      if(imageName.endsWith("/lexicon-app/images/question_16.gif")) return "question mark";
      if(imageName.endsWith("/lexicon-app/images/addnew.gif")) return "add";
      if(imageName.endsWith("/lexicon-app/images/undo2.gif")) return "undo";
      if(imageName.endsWith("/lexicon-app/images/checkmark_16.gif")) return "check mark";
      if(imageName.endsWith("/lexicon-app/images/delete.gif")) return "delete";
      if(imageName.endsWith("/lexicon-app/images/edit.gif")) return "edit";
      if(imageName.endsWith("/lexicon-app/images/stopsign_16.gif")) return "stop sign";
      if(imageName.endsWith("/lexicon-app/images/yield_16.gif")) return "yield sign";
      if(imageName.endsWith("/lexicon-app/images/audit.gif")) return "audit";
      return "ERROR: NO IMAGE NAME FOUND FOR " + imageName;
   }
}