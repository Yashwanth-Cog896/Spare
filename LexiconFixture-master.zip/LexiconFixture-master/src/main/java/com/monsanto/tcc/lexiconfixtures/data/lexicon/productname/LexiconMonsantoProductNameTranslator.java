package com.monsanto.tcc.lexiconfixtures.data.lexicon.productname;

import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 27, 2006
 * Time: 11:33:36 AM
 * To change this template use File | Settings | File Templates.
 */
public class LexiconMonsantoProductNameTranslator
    extends SymbolAcceptingColumnFixture
{
   public String precomlName;
   public String country;
   public String brand;

   public String productStagePubkey() throws WrappingException {
      return new LexiconAliasPubkeyByCriteriaQuery(precomlName, country, brand).getPubkey();
   }
}

