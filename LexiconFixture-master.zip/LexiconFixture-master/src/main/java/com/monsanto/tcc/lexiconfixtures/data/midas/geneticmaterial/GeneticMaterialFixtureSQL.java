package com.monsanto.tcc.lexiconfixtures.data.midas.geneticmaterial;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 13, 2006
 * Time: 10:22:48 AM
 * To change this template use File | Settings | File Templates.
 */
public interface GeneticMaterialFixtureSQL
{
   String SELECT_GENETIC_MATERIAL = "SelectGeneticMaterial";
   String INSERT_GENETIC_MATERIAL = "InsertGeneticMaterial";
   String DELETE_GENETIC_MATERIAL = "DeleteGeneticMaterial";
}
