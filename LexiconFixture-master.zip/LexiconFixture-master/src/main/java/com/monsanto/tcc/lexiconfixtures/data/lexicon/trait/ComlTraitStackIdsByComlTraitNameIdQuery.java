package com.monsanto.tcc.lexiconfixtures.data.lexicon.trait;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import java.util.List;

/**
 * User: pjberry
 * Date: Sep 19, 2007
 * Time: 4:49:37 PM
 */
public class ComlTraitStackIdsByComlTraitNameIdQuery
   extends AbstractPersistentStoreMultiRowQuery
{
   private final Long comlTraitNameId;

   public ComlTraitStackIdsByComlTraitNameIdQuery(Long comlTraitNameId) {

      this.comlTraitNameId = comlTraitNameId;
   }

   public Long[] getComlTraitStackIds(PersistentStoreConnection conn)
      throws WrappingException
   {
      List comlTraitStackIds = getList(conn);
      return (Long[])comlTraitStackIds.toArray(new Long[comlTraitStackIds.size()]);
   }

   public Long[] getComlTraitStackIds()
      throws WrappingException
   {
      List comlTraitStackIds = getList();
      return (Long[])comlTraitStackIds.toArray(new Long[comlTraitStackIds.size()]);
   }

   protected Object createObjectFromRow(PersistentStoreResultSetRow row)
      throws WrappingException
   {
      return row.getLONG(1);
   }

   protected String getSQL()
      throws WrappingException
   {
      return "SELECT CTSX.coml_trait_stack_id FROM Lexicon.Coml_Trait_Stack_Xref2 CTSX WHERE CTSX.coml_trait_name_id = ?";
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[]{comlTraitNameId};
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
}
