package com.monsanto.tcc.lexiconfixtures.data.cleanup;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreMultiRowQuery;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import java.util.List;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Apr 30, 2007
 * Time: 12:23:55 PM
 * To change this template use File | Settings | File Templates.
 */
class ProductPubkeysQuery
   extends AbstractPersistentStoreMultiRowQuery
{
   public List getPubkeyList() throws WrappingException {
      return super.getList();
   }
   protected Object createObjectFromRow(PersistentStoreResultSetRow row) throws WrappingException {
      return row.getString(1);
   }
   protected Object[] getBindVariables() throws WrappingException {
      return new Object[0];
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }

   protected String getSQL()
      throws WrappingException
   {
      return "SELECT product_pubkey FROM Lexicon.Pre_Coml_Product " +
         "WHERE " + DeleteRandomValueData.getNameClause("pre_coml_name") +
         " OR " + DeleteRandomValueData.getNameClause("product_pubkey") +
         " OR " + DeleteRandomValueData.getNumberClause("product_id");
   }
}
