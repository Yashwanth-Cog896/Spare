/*
 ProductAssociationExcelFixture was created on Dec 11, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.webappat.productassociation;

import com.monsanto.tcc.lexiconfixtures.util.approle.AppRoleTestToolsFixtureMixin;
import com.monsanto.tcc.lexiconfixtures.webappat.excel.screenfixture.ExcelScreenFixture;
import com.monsanto.tcc.lexiconfixtures.webappat.excel.screenfixture.GenericGatewayBasedHttpUnitPageVisitStrategy;
import com.monsanto.tcc.lexiconfixtures.webappat.excel.screenfixture.HttpUnitPageVisitStrategy;
import fit.Fixture;

/**
 * nbwald Dec 11, 2007 11:19:06 AM
 */
public class ProductAssociationExcelFixture
   extends ExcelScreenFixture
{
   private AppRoleTestToolsFixtureMixin roles = new AppRoleTestToolsFixtureMixin();

   public boolean saveApplicationRoles()
      throws Exception
   {
      return roles.saveApplicationRoles();
   }

   public Fixture setApplicationRole() {
      return roles.setApplicationRole();
   }

   public boolean restoreApplicationRoles()
      throws Exception
   {
      return roles.restoreApplicationRoles();
   }

   protected String getMenuHeading() {
      return "Monsanto Product";
   }

   protected String getMenuItem() {
      return "Product Association";
   }

   protected HttpUnitPageVisitStrategy getInitialPageVisitStrategy() {
      return new GenericGatewayBasedHttpUnitPageVisitStrategy("/GetProductAssociations.jsp");
   }
}