package com.monsanto.tcc.lexiconfixtures.webappat.addproductalias;

import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.POSClient.POSCommunicationException;
import com.monsanto.POSClient.POSConnection;
import com.monsanto.POSClient.POSException;
import com.monsanto.POSClient.POSResult;
import com.monsanto.POSClient.POSResultDocumentProcessor;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tcc.lexiconcommon.DocumentCreator;
import com.monsanto.tcc.lexiconcommon.audit.AuditableServiceRequestValuesRenderer;
import com.monsanto.tcc.lexiconcommon.pos.LexiconPOSConnection;
import com.monsanto.tcc.lexiconcommon.pos.SecurityProxyFactory;
import com.monsanto.tcc.lexiconcommon.productsync.ProductStageServiceRequestBatch;
import com.monsanto.tcc.lexiconcommon.productsync.ProductStageServiceRequestValues;
import com.monsanto.tcc.lexiconcommon.productsync.ProductSyncSchemaConstants;
import com.monsanto.tcc.lexiconcommon.productsync.test.MockAddProductStageRequestBatch;
import com.monsanto.tcc.lexiconcommon.validation.ValidationConditionSeverity;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingTableFixture;
import org.ietf.jgss.GSSException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Dec 19, 2006
 * Time: 10:00:25 AM
 */
public class AddProductAliasService
   extends SymbolAcceptingTableFixture
{
   private static final int PRE_COML_NAME_COLUMN = 0;
   private static final int COUNTRY_COLUMN = 1;
   private static final int BRAND_COLUMN = 2;
   private static final int STAGE_COLUMN = 3;
   private static final int COMMERCIAL_NAME_COLUMN = 4;
   private static final int COMMERCIAL_MATURITY_COLUMN = 5;
   private static final int COMMERCIAL_TRAIT_COLUMN = 6;
   private static final int INFO_COLUMN = 7;
   private static final int ERRORS_COLUMN = 8;

   private AddProductAliasQuerySet querySet = new AddProductAliasQuerySet();

   // BATCH ID = ROW NUM

   protected void doStaticTable(int numOfRows)
   {
      try {
         ProductStageServiceRequestBatch requestBatch = buildRequestBatch(numOfRows);
         AddProductStageRequestBuilder requestBuilder = new AddProductStageRequestBuilder(requestBatch);
         Document response = callService(requestBuilder.build());
         checkResponse(response);
         System.out.println(DOMUtil.getXMLString(response));
      }
      catch (Exception e) {
         e.printStackTrace();
         throw new RuntimeException(e);
      }
   }

   private void checkResponse(Document response) {
      AddProductStageBatchResponseDOMImpl batchResponse = new AddProductStageBatchResponseDOMImpl(response.getDocumentElement());
      ProductStageResponseStatus[] statuses = batchResponse.getResponses();
      for (int i = 0; i < statuses.length; i++) {
         checkInfo(statuses[i]);
         checkErrors(statuses[i]);
      }
   }

   private void checkInfo(ProductStageResponseStatus status)
   {
      String expectedInfo = getText(status.getBatchID(), INFO_COLUMN);
      String[] infoFromResponse = status.getMessages().getMessagesOfSeverity(ValidationConditionSeverity.INFO.getName());
      String infoCSV = convertArrayToCSV(infoFromResponse);
      if(expectedInfo.equals(infoCSV)) {
         right(status.getBatchID(), INFO_COLUMN);
      }
      else {
         wrong(status.getBatchID(), INFO_COLUMN, infoCSV);
      }
   }

   private void checkErrors(ProductStageResponseStatus status)
   {
      String expectedErrors = getText(status.getBatchID(), ERRORS_COLUMN);
      String[] errorsFromResponse = status.getMessages().getMessagesOfSeverity(ValidationConditionSeverity.ERROR.getName());
      String errorsCSV = convertArrayToCSV(errorsFromResponse);
      if(expectedErrors.equals(errorsCSV)) {
         right(status.getBatchID(), ERRORS_COLUMN);
      }
      else {
         wrong(status.getBatchID(), ERRORS_COLUMN, errorsCSV);
      }
   }
   private ProductStageServiceRequestBatch buildRequestBatch(int numOfRows)
      throws WrappingException
   {
      MockAddProductStageRequestBatch batch = new MockAddProductStageRequestBatch();
      batch.setValidationOnly(false);
      for(int rowNum = 1; rowNum < numOfRows; rowNum++) {
         batch.addRequest(buildIndividualRequest(rowNum));
         }
      return batch;
   }

   private ProductStageServiceRequestValues buildIndividualRequest(int rowNum)
      throws WrappingException
   {
      String productPubkey = querySet.getProductPubkey(getText(rowNum, PRE_COML_NAME_COLUMN));
      String brandPubkey = querySet.getBrandPubkey(getText(rowNum, BRAND_COLUMN));
      String countryPubkey = querySet.getCountryPubkey(getText(rowNum, COUNTRY_COLUMN));
      String stageTypePubkey = querySet.getStageTypePubkey(getText(rowNum, STAGE_COLUMN));
      String traitStackPubkey = querySet.getTraitStackPubkey(getText(rowNum, PRE_COML_NAME_COLUMN), getText(rowNum, COMMERCIAL_TRAIT_COLUMN));
      String commercialName = getNullableText(rowNum, COMMERCIAL_NAME_COLUMN);
      String commercialMaturity = getNullableText(rowNum, COMMERCIAL_MATURITY_COLUMN);
      return new ProductStageRequestValuesFixtureImpl(rowNum, false, productPubkey, null, brandPubkey, countryPubkey, stageTypePubkey, traitStackPubkey, commercialName, commercialMaturity);
   }

   private Document callService(Document requestDocument)
      throws GSSException, POSException, POSCommunicationException
   {
      SecurityProxyFactory.getInstance().setThreadProxy(new KerberosStandaloneCredential());
      AddProductStageServiceCall serviceCall = new AddProductStageServiceCall(requestDocument);
      return serviceCall.getResultDocument();
   }

   private String getNullableText(int rowNum, int columnNum) {
      String text = getText(rowNum, columnNum);
      return "null".equalsIgnoreCase(text) ? null : text;
   }

   private String convertArrayToCSV(String[] strings) {
      StringBuffer sb = new StringBuffer();
      for (int i = 0; i < strings.length; i++) {
         if(i > 0) sb.append(",");
         sb.append(strings[i]);
      }
      return sb.toString();
   }
}

class AddProductStageBatchRequestRenderer {
   private final Element batchRequestElem;
   private final ProductStageServiceRequestBatch requestBatch;

   public AddProductStageBatchRequestRenderer(Element batchRequestElem, ProductStageServiceRequestBatch requestBatch) {
      this.batchRequestElem = batchRequestElem;
      this.requestBatch = requestBatch;
   }
   public void render() {
      renderValidateOnly();
      renderAddProductStageRequests();
   }
   private void renderValidateOnly() {
      String sValidateOnly = String.valueOf(requestBatch.isValidationOnly());
      DOMUtil.setAttribute(batchRequestElem, ProductSyncSchemaConstants.VALIDATION_ONLY_ELEM_NAME, sValidateOnly);
   }
   private void renderAddProductStageRequests() {
      ProductStageServiceRequestValues[] requests = requestBatch.getRequests();
      for (int i = 0; i < requests.length; i++) {
         Element addProductStageElement = createAddProductStageElement();
         AddProductStageRequestRenderer renderer = new AddProductStageRequestRenderer(addProductStageElement, requests[i]);
         renderer.render();
      }
   }
   private Element createAddProductStageElement() {
      return DOMUtil.addChildElementWithNS(ProductSyncSchemaConstants.NS_URI, batchRequestElem,
         ProductSyncSchemaConstants.ADD_PROD_STAGE_REQUEST);
   }
}

class AddProductStageRequestBuilder {
   private final ProductStageServiceRequestBatch requestBatch;
   public AddProductStageRequestBuilder(ProductStageServiceRequestBatch requestBatch) {
      this.requestBatch = requestBatch;
   }

   public Document build() {
      Document document = createDocument();
      renderRequestBatch(document);
      return document;
   }
   private Document createDocument() {
      return new DocumentCreator().createDocument(ProductSyncSchemaConstants.NS_URI,
         ProductSyncSchemaConstants.ADD_PROD_STAGE_REQUEST_BATCH);
   }
   private void renderRequestBatch(Document document) {
      AddProductStageBatchRequestRenderer renderer =
         new AddProductStageBatchRequestRenderer(document.getDocumentElement(), requestBatch);
      renderer.render();
   }
}

class ProductStageRequestRenderer
{
   private Element parent;
   private ProductStageServiceRequestValues request;

   public ProductStageRequestRenderer(Element parent, ProductStageServiceRequestValues request) {
      this.parent = parent;
      this.request = request;
   }

   public void render() {
      renderAuditInformation();
      renderBatchId();
      renderBrandPubkey();
      renderCountryPubkey();
      renderStageTypePubkey();
      renderTraitStackPubkey();
      renderComlName();
      renderComlMaturity();
      renderOECDName();
      renderActive();
      renderPreferredName();
   }

   private void renderAuditInformation() {
      AuditableServiceRequestValuesRenderer renderer = new AuditableServiceRequestValuesRenderer(parent, request);
      renderer.render();
   }
   private void renderBatchId() {
      DOMUtil.setAttribute(parent, ProductSyncSchemaConstants.BATCHID_ATTR_NAME, request.getBatchID());
   }
   private void renderBrandPubkey() {
      DOMUtil.addChildElementWithNS(ProductSyncSchemaConstants.NS_URI, parent, ProductSyncSchemaConstants.BRAND_PUBKEY_ELEM_NAME, request.getBrandPubkey());
   }
   private void renderCountryPubkey() {
      DOMUtil.addChildElementWithNS(ProductSyncSchemaConstants.NS_URI, parent, ProductSyncSchemaConstants.COUNTRY_PUBKEY_ELEM_NAME, request.getCountryPubkey());
   }
   private void renderStageTypePubkey() {
      DOMUtil.addChildElementWithNS(ProductSyncSchemaConstants.NS_URI, parent, ProductSyncSchemaConstants.STAGE_TYPE_PUBKEY_ELEM_NAME, request.getStageTypePubkey());
   }
   private void renderTraitStackPubkey() {
      DOMUtil.addChildElementWithNS(ProductSyncSchemaConstants.NS_URI, parent, ProductSyncSchemaConstants.TRAIT_STACK_PUBKEY_ELEM_NAME, request.getTraitStackPubkey());
   }
   private void renderComlName() {
      String comlName = request.getCommercialName();
      if(!StringUtils.isNullOrEmpty(comlName)) {
         DOMUtil.addChildElementWithNS(ProductSyncSchemaConstants.NS_URI, parent, ProductSyncSchemaConstants.COML_NAME_ELEM_NAME, comlName);
      }
   }
   private void renderComlMaturity() {
      String comlMat = request.getCommercialMaturity();
      if(!StringUtils.isNullOrEmpty(comlMat)) {
         DOMUtil.addChildElementWithNS(ProductSyncSchemaConstants.NS_URI, parent, ProductSyncSchemaConstants.COML_MAT_ELEM_NAME, comlMat);
      }
   }
   private void renderOECDName() {
      String oecdName = request.getOECDName();
      if(!StringUtils.isNullOrEmpty(oecdName)) {
         DOMUtil.addChildElementWithNS(ProductSyncSchemaConstants.NS_URI, parent, ProductSyncSchemaConstants.OECD_NAME_ELEM_NAME, oecdName);
      }
   }
   private void renderActive() {
      DOMUtil.addChildElementWithNS(ProductSyncSchemaConstants.NS_URI, parent, ProductSyncSchemaConstants.IS_ACTIVE_ELEM_NAME, request.isActive());
   }
   private void renderPreferredName() {
      DOMUtil.addChildElementWithNS(ProductSyncSchemaConstants.NS_URI, parent, ProductSyncSchemaConstants.IS_PREFERRED_NAME_ELEM_NAME, request.isPreferredName());
   }
}

class AddProductStageRequestRenderer {
   private final Element addProductStageElement;
   private final ProductStageServiceRequestValues request;

   public AddProductStageRequestRenderer(Element addProductStageElement, ProductStageServiceRequestValues request) {
      this.addProductStageElement = addProductStageElement;
      this.request = request;
   }

   public void render() {
      renderProductStageRequestElements();
      renderProductPubkey();
   }

   private void renderProductStageRequestElements() {
      ProductStageRequestRenderer renderer = new ProductStageRequestRenderer(addProductStageElement, request);
      renderer.render();
   }

   private void renderProductPubkey() {
      DOMUtil.addChildElementWithNS(ProductSyncSchemaConstants.NS_URI, addProductStageElement,
         ProductSyncSchemaConstants.PROD_PUBKEY_ELEM_NAME, request.getProductPubkey());
   }
}

class AddProductStageServiceCall {
   private final Document requestDoc;
   public AddProductStageServiceCall(Document requestDoc) {
      this.requestDoc = requestDoc;
   }
   public Document getResultDocument() throws POSCommunicationException, POSException {
      POSConnection conn = new LexiconPOSConnection();
      POSResult result = conn.callService("Lex_AddProductStage", requestDoc);
      return new POSResultDocumentProcessor().getDocument(result);
   }
}

interface Messages {
   public String[] getMessagesOfSeverity(String severity);
}

class MessagesDOMImpl
   implements Messages
{
   private final Element messagesElement;
   public MessagesDOMImpl(Element messagesElement) {
      this.messagesElement = messagesElement;
   }

   public String[] getMessagesOfSeverity(String severity) {
      Node[] messages = DOMUtil.getChildren(messagesElement, severity);
      return getMessagesText(messages);
   }
   private String[] getMessagesText(Node[] messages) {
      List lMessages = new ArrayList();
      for(int i=0; i<messages.length; i++) {
         lMessages.add( getMessageText((Element)messages[i]) );
      }
      return (String[]) lMessages.toArray(new String[] {});
   }
   private String getMessageText(Element messageElement) {
      NodeList childNodes = messageElement.getChildNodes();
      Node textNode = childNodes.item(0);
      return textNode.getNodeValue();
   }
}

interface ResponseStatus {
   int getBatchID();
   String getStatus();
   Messages getMessages();
}

interface ProductStageResponseStatus extends ResponseStatus {
   String getProductPubkey();
   String getProductNamePubkey();
}

interface ProductStageBatchResponse {
   ProductStageResponseStatus[] getResponses();
}

class ProductStageBatchResponseDOMImpl {
   public ProductStageResponseStatus[] getResponses(Element batchResponseElem, String responseElemName) {
      List responses = new ArrayList();
      Node[] responseNodes = DOMUtil.getChildren(batchResponseElem, responseElemName);
      for (int i = 0; i < responseNodes.length; i++) {
         responses.add(new ProductStageResponseStatusDOMImpl((Element) responseNodes[i]));
      }
      return (ProductStageResponseStatus[]) responses.toArray(new ProductStageResponseStatus[responses.size()]);
   }
}

class AddProductStageBatchResponseDOMImpl
   implements ProductStageBatchResponse
{
   private final ProductStageBatchResponseDOMImpl delegate = new ProductStageBatchResponseDOMImpl();
   private final Element batchResponseElem;

   public AddProductStageBatchResponseDOMImpl(Element batchResponseElem) {
      this.batchResponseElem = batchResponseElem;
   }
   public ProductStageResponseStatus[] getResponses() {
      return delegate.getResponses(batchResponseElem, ProductSyncSchemaConstants.ADD_PROD_STAGE_RESPONSE);
   }
}

class ProductStageResponseStatusDOMImpl
   implements ProductStageResponseStatus
{
   private final Element requestElem;

   public ProductStageResponseStatusDOMImpl(Element requestElem) {
      this.requestElem = requestElem;
   }
   public int getBatchID() {
      String batchIDString = DOMUtil.getAttribute(requestElem, ProductSyncSchemaConstants.BATCHID_ATTR_NAME);
      return Integer.parseInt(batchIDString);
   }
   public String getStatus() {
      return DOMUtil.getAttribute(requestElem, ProductSyncSchemaConstants.STATUS_ELEM_NAME);
   }
   public String getProductPubkey() {
      return DOMUtil.getChildValue(requestElem, ProductSyncSchemaConstants.PROD_PUBKEY_ELEM_NAME);
   }
   public String getProductNamePubkey() {
      return DOMUtil.getChildValue(requestElem, ProductSyncSchemaConstants.PROD_NAME_PUBKEY_ELEM_NAME);
   }
   public Messages getMessages() {
      Element messagesElem = (Element) DOMUtil.getChild(requestElem, ProductSyncSchemaConstants.MESSAGES_ELEM_NAME);
      return new MessagesDOMImpl(messagesElem);
   }

}