/*
 UnencapsulatedResponse was created on Sep 11, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.serviceat.varietynameupdate.relationship;

import com.monsanto.tcc.lexiconcommon.service.productrelationship.varietynameupdate.model.UpdateRelationshipVarietyNameResponse;

/**
 * nbwald Sep 11, 2007 3:01:12 PM
 */
public class UnencapsulatedUpdateRelationshipVarietyNameServiceResponse
{
   public final String manufacturingName;
   public final String varietyName;
   public final boolean succeeded;
   public final String messages;

   /*
      If fitNesse broke field encapsulation like xstream does, we wouldn't need this intermediary super-public class.
      Instead we could just say:

      return new ArrayFixture(new Object[] { deserializedResponse });

      D'arg.
    */
   public UnencapsulatedUpdateRelationshipVarietyNameServiceResponse(UpdateRelationshipVarietyNameResponse response) {
      this.manufacturingName = response.getManufacturingName();
      this.varietyName = response.getVarietyName();
      this.succeeded = response.succeeded();
      this.messages = join(response.getMessages());
   }

   private String join(String[] messages) {
      StringBuilder joined = new StringBuilder();
      if(messages.length > 0) {
         joined.append(messages[0]);
         for (int i = 1; i < messages.length; i++) {
            joined.append(", ").append(messages[i]);
         }
      }
      return joined.toString();
   }
}