package com.monsanto.tcc.lexiconfixtures.data.midas.allinfo;

import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Mar 16, 2007
 * Time: 2:10:31 PM
 */
public class RemoveAllMidasProductInfo
   extends SymbolAcceptingColumnFixture
{
   public Long germplasmId;

   public boolean removed()
      throws WrappingException
   {
      MidasConnectionFactory connectionFactory = new MidasConnectionFactory();
      PersistentStoreConnection conn = connectionFactory.getConnection();
      try {
         return deleteFakeData(conn) > 0;
      }
      finally {
         conn.close();
      }
   }

   private int deleteFakeData(PersistentStoreConnection conn)
      throws WrappingException
   {
      Long[] germplasmIds = getAssociatedGermplasmIds(conn);
      Long[] geneticMaterialIds = getAssociatedGeneticMaterialIds(conn, germplasmIds);
      Long[] productIds = getProductsIdsByGermplamsIds(conn, germplasmIds);

      int numOfThingsDeleted = 0;
      numOfThingsDeleted += deleteParentage(conn, geneticMaterialIds);
      numOfThingsDeleted += deleteInventoryProductNames(conn, productIds);
      numOfThingsDeleted += deleteInventories(conn, geneticMaterialIds);
      numOfThingsDeleted += deleteGeneticMaterial(conn, geneticMaterialIds);
      numOfThingsDeleted += deleteProductGermplasm(conn, productIds);
      numOfThingsDeleted += deleteProductNames(conn, productIds);
      numOfThingsDeleted += deleteProducts(conn, productIds);
      numOfThingsDeleted += deleteGermplasm(conn, germplasmIds);
      return numOfThingsDeleted;
   }

   private Long[] getAssociatedGermplasmIds(PersistentStoreConnection conn)
      throws WrappingException
   {
      AssociatedGermplasmLookup lookup = new AssociatedGermplasmLookup();
      return lookup.getAssociatedGermplasmIds(conn, germplasmId);
   }

   private Long[] getProductsIdsByGermplamsIds(PersistentStoreConnection conn, Long[] germplasmIds)
      throws WrappingException
   {
      ProductIdsByGermplasmIds lookup = new ProductIdsByGermplasmIds();
      return lookup.getProductIds(conn, germplasmIds);
   }

   private Long[] getAssociatedGeneticMaterialIds(PersistentStoreConnection conn, Long[] germplasmIds)
      throws WrappingException
   {
      GeneticMaterialIdsByGermplasmIds lookup = new GeneticMaterialIdsByGermplasmIds();
      return lookup.getGeneticMaterialIds(conn, germplasmIds);
   }

   private int deleteParentage(PersistentStoreConnection conn, Long[] geneticMaterialIds)
      throws WrappingException
   {
      DeleteParentageByGeneticMaterialIds destroyer = new DeleteParentageByGeneticMaterialIds();
      return destroyer.deleteParentage(conn, geneticMaterialIds);
   }

   private int deleteInventories(PersistentStoreConnection conn, Long[] geneticMaterialIds)
      throws WrappingException
   {
      DeleteInventoriesByGeneticMaterialIds destroyer = new DeleteInventoriesByGeneticMaterialIds();
      return destroyer.delete(conn, geneticMaterialIds);
   }

   private int deleteGeneticMaterial(PersistentStoreConnection conn, Long[] geneticMaterialIds)
      throws WrappingException
   {
      DeleteGeneticMaterialsByGeneticMaterialIds destroyer = new DeleteGeneticMaterialsByGeneticMaterialIds();
      return destroyer.deleteGeneticMaterial(conn, geneticMaterialIds);
   }

   private int deleteProductGermplasm(PersistentStoreConnection conn, Long[] productIds)
      throws WrappingException
   {
      DeleteProductGermplasmByProductIds destroyer = new DeleteProductGermplasmByProductIds();
      return destroyer.deleteProductGermplasm(conn, productIds);
   }

   private int deleteInventoryProductNames(PersistentStoreConnection conn, Long[] productIds)
      throws WrappingException
   {
      DeleteInventoryProductNamesByProductIds destroyer = new DeleteInventoryProductNamesByProductIds();
      return destroyer.delete(conn, productIds);
   }

   private int deleteProductNames(PersistentStoreConnection conn, Long[] productIds)
      throws WrappingException
   {
      DeleteProductNamesByProductIds destroyer = new DeleteProductNamesByProductIds();
      return destroyer.deleteProductNames(conn, productIds);
   }

   private int deleteProducts(PersistentStoreConnection conn, Long[] productIds)
      throws WrappingException
   {
      DeleteProductsByProductIds destroyer = new DeleteProductsByProductIds();
      return destroyer.deleteProducts(conn, productIds);
   }

   private int deleteGermplasm(PersistentStoreConnection conn, Long[] germplasmIds)
      throws WrappingException
   {
      DeleteGermplasmByGermplasmIds destroyer = new DeleteGermplasmByGermplasmIds();
      return destroyer.deleteGermplasm(conn, germplasmIds);
   }
}
