package com.monsanto.tcc.lexiconfixtures.serviceat.regulatoryevent;

/**
 * User: pjberry
 * Date: Aug 2, 2007
 * Time: 9:55:40 AM
 */
public class RegulatoryEventRequest
{
   public final String event;
   public final String crop;

   public RegulatoryEventRequest(String event, String crop) {
      this.event = event;
      this.crop = crop;
   }
}
