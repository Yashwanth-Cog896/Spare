package com.monsanto.tcc.lexiconfixtures.webappat.theattic.symbols;

import com.monsanto.tcc.lexiconfixtures.util.symbol.StringParseDelagate;
import fit.RowFixture;
import java.util.List;

/**
 * Created by IntelliJ IXA.
* User: jaskidi
* Date: Apr 3, 2007
* Time: 12:59:03 PM
* To change this template use File | Settings | File Templates.
*/
public class SymbolTestRowFixture
   extends RowFixture
{
   private List rows;

   public SymbolTestRowFixture(List rows) {
      this.rows = rows;
   }

   public Object[] query()
      throws Exception
   {
      return rows.toArray(new TestRowFixtureModel[rows.size()]);
   }

   public Class getTargetClass() {
      return TestRowFixtureModel.class;
   }

   public Object parse(String s, Class type)
      throws Exception
   {
      if (!type.equals(String.class)) {
         return super.parse(s, type);
      }
      else {
         return new StringParseDelagate().parse(s);
      }
   }
}
