package com.monsanto.tcc.lexiconfixtures.serviceat.person;

/**
 * nbwald - May 23, 2008 4:04:35 PM
 */
public class CsvToLongs {

   public static long[] convert(String csv, final String ids) {
      String[] strings = csv.split(",");
      long[] longs = new long[strings.length];
      try {
         for (int i = 0; i < strings.length; i++) {
            longs[i] = Long.parseLong(strings[i]);
         }
      } catch (NumberFormatException e) {
         throw new IllegalArgumentException(ids + " must be only numeric characters.");
      }
      return longs;
   }
}
