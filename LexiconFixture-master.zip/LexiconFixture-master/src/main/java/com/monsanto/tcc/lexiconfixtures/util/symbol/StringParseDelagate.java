package com.monsanto.tcc.lexiconfixtures.util.symbol;

import org.apache.commons.lang.text.StrMatcher;
import org.apache.commons.lang.text.StrTokenizer;

/**
 * Created by IntelliJ IXA.
 * User: JASKIDI
 * Date: Apr 4, 2007
 * Time: 12:35:07 AM
 * To change this template use File | Settings | File Templates.
 */
public class StringParseDelagate
   extends SymbolProcessingParseDelagate
{
   public String parse(String s) {
      StrTokenizer stringTokenizer = new StrTokenizer(s, StrMatcher.charSetMatcher(" ,\t\n"));
      String[] tokenArray = stringTokenizer.getTokenArray();
      for (String token : tokenArray) {
         if(token.startsWith(SYMBOL_PREFIX)) {
            String evaluatedSymbol = replaceSymbol(token);
            s = s.replaceAll(token, evaluatedSymbol);
         }
      }
      return s;
   }

   private String replaceSymbol(String symbol) {
      String symbolValue = (String) baseParse(symbol);
      return symbolValue == null ? "null" : symbolValue;
   }

   public String reverseParse(String s) {
      if (s == null) {
         return NULL_STRING;
      }
      else if ("".equals(s)) {
         return BLANK_STRING;
      }
      else {
         return s;
      }
   }

   protected Object createObjectFromSymbolValue(Object symbolValue) {
      return symbolValue.toString();
   }

   protected Object createObjectFromString(String s) {
      return s;
   }

   protected Object specificValueHandlingHook(String s) {
      return BLANK_STRING.equalsIgnoreCase(s) ? "" : null;
   }
}
