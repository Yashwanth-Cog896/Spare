/*
	 ExternalContactFixture was created on May 27, 2008 using Monsanto
	 resources and is the sole property of Monsanto.  Any duplication of the
	 code and/or logic is a direct infringement of Monsanto's copyright.
	*/
package com.monsanto.tcc.lexiconfixtures.serviceat.externalcontact;

import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import static com.monsanto.Util.StringUtils.getLineSeparator;
import static com.monsanto.tcc.lexiconfixtures.serviceat.person.CsvToLongs.convert;
import com.monsanto.tps.lexicon.contact.SearchableLocation;
import com.monsanto.tps.lexicon.contact.service.ExternalContacts;
import com.monsanto.tps.lexicon.contact.service.ExternalContactsImpl;
import com.monsanto.tps.lexicon.person.ExternalContact;
import com.monsanto.tps.lexicon.person.ExternalContactSearchCriteria;
import fit.Fixture;
import fitlibrary.DoFixture;

/**
 * Filename:    $RCSfile: ExternalContactFixture.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: nbwald $    	 On:	$Date: 2008-09-08 19:19:15 $
 *
 * @author MMR
 * @version $Revision: 1.16 $
 */
public class ExternalContactFixture
        extends DoFixture {
   private ExternalContact[] externalContacts;
   private ExternalContactSearchCriteria criteria = new ExternalContactSearchCriteria();
   private SearchableLocation location = new SearchableLocation();
   private boolean exceptionThrown;
   private String errorMessage;

   public int noOfExternalContactsFound() {
      return externalContacts == null ? 0 : externalContacts.length;
   }

   public boolean throwsException() {
      return exceptionThrown;
   }

   public boolean lastName(String lastName) {
      criteria.setLastName(lastName);
      return true;
   }

   public boolean firstName(String firstName) {
      criteria.setFirstName(firstName);
      return true;
   }

   public boolean contactType(String contactType) {
      criteria.setContactType(contactType);
      return true;
   }

   public boolean companyName(String companyName) {
      criteria.setCompanyName(companyName);
      return true;
   }

   public boolean country(String country) {
      location.setCountryName(country);
      return true;
   }

   public boolean state(String state) {
      location.setSubcountryCode(state);
      return true;
   }

   public boolean county(String county) {
      location.setSubsubcountryName(county);
      return true;
   }

   public boolean city(String city) {
      location.setCity(city);
      return true;
   }

   public boolean search() throws Exception {
      criteria.setLocation(location);
      try {
         externalContacts = getClient().findByCriteria(criteria);
      } catch (IllegalArgumentException e) {
         errorMessage = e.getMessage();
      } catch (Exception e) {
         e.printStackTrace();
         exceptionThrown = true;
      }
      return true;
   }

   private ExternalContacts getClient() throws Exception {
      return new ExternalContactsImpl(new KerberosStandaloneCredential());
   }

   public boolean findContactsWithContactIds(String contactIdsCSV) throws Exception {
      try {
         externalContacts = getClient().findByExternalContactIds(convert(contactIdsCSV, "contact Ids"));
      } catch (IllegalArgumentException e) {
         errorMessage = e.getMessage();
      }
      return true;
   }

   public boolean findContactsWithAccountIds(String accountIdsCSV) throws Exception {
      try {
         externalContacts = getClient().findByBusinessAccountIds(convert(accountIdsCSV, "Account Ids"));
      } catch (IllegalArgumentException e) {
         errorMessage = e.getMessage();
      }
      return true;
   }

   public Fixture checkResults() {
      return new ExternalContactAdaptorRowFixture(externalContacts);
   }

   public String errorMessage() {
      return errorMessage.replaceAll(getLineSeparator(), " ");
   }
}