package com.monsanto.tcc.lexiconfixtures.data.factories.bfc;

import com.monsanto.tcc.lexiconcommon.db.factories.BasicConnectionFactory;

/**
 * User: pjberry
 * Date: Aug 2, 2007
 * Time: 5:22:00 PM
 */
public class BFCConnectionFactory
   extends BasicConnectionFactory
{
   public BFCConnectionFactory() {
      super(new BFCConnectionFactoryProperties());
   }
}
