package com.monsanto.tcc.lexiconfixtures.data.mirage.product;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.tcc.lexiconfixtures.data.factories.mirage.MirageConnectionFactoryProperties;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jun 15, 2007
 * Time: 9:58:13 AM
 */
public class MirageProductIdByCriteriaQuery
   extends AbstractPersistentStoreSingleResultQuery
{
   private final String productName;
   private final String companyName;
   private final String countryName;

   public MirageProductIdByCriteriaQuery(final String productName, final String companyName, final String countryName) {
      this.productName = productName;
      this.companyName = StringUtils.toUpperCaseNull(companyName);
      this.countryName = StringUtils.toUpperCaseNull(countryName);
   }

   public Long getProductId() throws WrappingException {
      return (Long)super.execute();
   }
   protected Object createObjectFromRow(PersistentStoreResultSetRow row) throws WrappingException {
      return row.getLONG(1);
   }
   protected String getSQL() throws WrappingException {
      return new SQLPropFile(MirageProductFixtureSQL.class).getSQL(MirageProductFixtureSQL.SELECT_PRODUCT_ID);
   }
   protected Object[] getBindVariables() throws WrappingException {
      return new Object[] { productName, companyName, countryName };
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new MirageConnectionFactoryProperties();
   }
}
