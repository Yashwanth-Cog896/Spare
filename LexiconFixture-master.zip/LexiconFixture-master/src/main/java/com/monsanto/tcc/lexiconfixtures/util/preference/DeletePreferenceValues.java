package com.monsanto.tcc.lexiconfixtures.util.preference;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.LexiconDataFixtureDelete;
import com.monsanto.tcc.lexiconfixtures.util.UserHelper;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jun 28, 2007
 * Time: 12:59:41 PM
 */
class DeletePreferenceValues
   extends LexiconDataFixtureDelete
{
   private final String prefName;
   public DeletePreferenceValues(String prefName) {
      this.prefName = prefName;
   }

   protected Object[] getBindVariables() throws WrappingException {
      return new Object[]  { UserHelper.getCurrentUserLoginId(), prefName };
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
   protected String getSQL()
      throws WrappingException
   {
      return "DELETE FROM Lexicon.User_Preference_Value WHERE user_preference_id = (" +
               "SELECT user_preference_id FROM Lexicon.User_Preference " +
               "WHERE user_login_id = ? AND preference_definition_name = ?" +
             ")";
   }
}
