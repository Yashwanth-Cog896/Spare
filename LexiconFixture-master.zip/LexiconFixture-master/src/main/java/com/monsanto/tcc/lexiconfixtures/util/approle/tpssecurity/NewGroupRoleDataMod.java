package com.monsanto.tcc.lexiconfixtures.util.approle.tpssecurity;

import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreInsert;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.data.factories.spsecurity.SpsecurityConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.random.GetRandomId;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald - Jul 14, 2009 12:01:20 PM
 */
public class NewGroupRoleDataMod
   extends AbstractPersistentStoreInsert
{
   private final long contextPrivilegeGroupValueId;
   private final String contextName;
   private final String groupName;
   private final long privilege;

   public NewGroupRoleDataMod(String desiredRole, String groupName) {
      this.contextPrivilegeGroupValueId = new GetRandomId().value();
      this.contextName = "lexicon." + desiredRole;
      this.groupName = groupName;
      this.privilege = 2; // "Read only" privilege - this flag is not applicable to Lexicon
   }

   protected String getSQL()
      throws WrappingException
   {
      return 
         " insert into FBS_Common.SPS_Context_Priv_Group_Val (" +
         "     context_priv_group_value_id, " +
         "     context_priv_group_id, " +
         "     context_id, " +
         "     priv" +
         " )" +
         " values (" +
         "     ?, " +
         "     (SELECT context_priv_group_id FROM FBS_Common.SPS_Context_Priv_Group WHERE name = ?), " +
         "     (    SELECT C.context_id " +
         "            FROM FBS_Common.SPS_Context C " +
         "      INNER JOIN FBS_Common.SPS_Environment E on (C.environment_id = E.environment_id) " +
         "           WHERE C.context = ? and E.name = 'LEXICON' and E.active = 'T')," +
         "     ?" +
         " )";
   }

   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { contextPrivilegeGroupValueId, groupName, contextName, privilege };
   }

   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new SpsecurityConnectionFactoryProperties();
   }
}
