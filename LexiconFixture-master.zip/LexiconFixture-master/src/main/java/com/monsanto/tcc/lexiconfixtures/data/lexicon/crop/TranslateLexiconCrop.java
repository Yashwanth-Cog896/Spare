package com.monsanto.tcc.lexiconfixtures.data.lexicon.crop;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import fit.ColumnFixture;

/**
 * User: pjberry
 * Date: Jul 12, 2007
 * Time: 5:45:12 PM
 */
public class TranslateLexiconCrop
   extends ColumnFixture
{
   public String cropName;

   public String cropPubkey()
      throws WrappingException
   {
      CropPubkeyFromNameQuery query = new CropPubkeyFromNameQuery();
      return query.getPubkey();
   }

   private class CropPubkeyFromNameQuery
      extends AbstractPersistentStoreSingleResultQuery
   {
      private String  getPubkey()
         throws WrappingException
      {
         return (String) execute();
      }

      protected Object createObjectFromRow(PersistentStoreResultSetRow row)
         throws WrappingException
      {
         return row.getString(1);
      }

      protected String getSQL()
         throws WrappingException
      {
         return "SELECT C.crop_pubkey FROM Lexicon.Crop C WHERE C.crop_name = ?";
      }

      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[] {cropName};
      }

      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new LexiconConnectionFactoryProperties();
      }
   }
}
