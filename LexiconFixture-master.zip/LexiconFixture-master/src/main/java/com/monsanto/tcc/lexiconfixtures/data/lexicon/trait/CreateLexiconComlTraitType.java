package com.monsanto.tcc.lexiconfixtures.data.lexicon.trait;

import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactory;
import com.monsanto.tcc.lexiconcommon.db.test.LexiconTestTools;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * User: pjberry
 * Date: May 25, 2007
 * Time: 9:40:09 AM
 */
public class CreateLexiconComlTraitType
  extends SymbolAcceptingColumnFixture
{
   public Long comlTraitTypeId;
   public String comlTraitTypeAbbr;
   public String comlTraitTypeDesc;
   
   public boolean created()
      throws WrappingException
   {
      LexiconConnectionFactory connectionFactory = new LexiconConnectionFactory();
      PersistentStoreConnection conn = connectionFactory.getConnection();
      LexiconTestTools.FITNESSE_TEST_AUDITOR.initializeStaging(conn);
      try {
         int numInserted = insertFakeData(conn);
         return numInserted == 1;
      }
      finally {
         LexiconTestTools.FITNESSE_TEST_AUDITOR.removeStaging(conn);
         conn.close();
      }
   }

   private int insertFakeData(PersistentStoreConnection conn)
      throws WrappingException
   {
      String sql = getSql();
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, comlTraitTypeId);
         stmt.setParam(2, comlTraitTypeAbbr);
         stmt.setParam(3, comlTraitTypeDesc);
         return stmt.executeInsert();
      }
      finally {
         stmt.close();
      }
   }

   private String getSql() {
      return
         "INSERT INTO Lexicon.Coml_Trait_Type " +
            "(coml_trait_type_id, coml_trait_type_abbr, coml_trait_type_desc) " +
         "VALUES " +
            "(?, ?, ?)";
   }
}
