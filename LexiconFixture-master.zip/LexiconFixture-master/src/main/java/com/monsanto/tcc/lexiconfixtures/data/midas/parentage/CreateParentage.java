package com.monsanto.tcc.lexiconfixtures.data.midas.parentage;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreInsert;
import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Dec 4, 2006
 * Time: 5:30:31 PM
 * To change this template use File | Settings | File Templates.
 */
public class CreateParentage
   extends SymbolAcceptingColumnFixture
{
   public Long parentageId;
   public Long geneticMaterialId;
   public Long parentGeneticMaterialId;
   public String parentRole;
   public boolean isTester;

   public boolean created()
      throws WrappingException
   {
      MaterialParentageInsert dataMod = new MaterialParentageInsert();
      return dataMod.performInsert() == 1;
   }

   class MaterialParentageInsert
      extends AbstractPersistentStoreInsert
   {
      protected String getSQL() throws WrappingException {
         return new SQLPropFile(MidasParentageFixtureSQL.class).getSQL(MidasParentageFixtureSQL.INSERT_PARENTAGE);
      }
      protected Object[] getBindVariables() throws WrappingException {
         return new Object[] { parentageId, geneticMaterialId, parentGeneticMaterialId,
            parentRole, isTester ? "T" : "F"
         };
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new MidasConnectionFactoryProperties();
      }
   }
}
