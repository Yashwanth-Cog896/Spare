package com.monsanto.tcc.lexiconfixtures.data.lexicon.product;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.test.LexiconTestTools;
import com.monsanto.tcc.lexiconcommon.db.audit.LexiconAuditor;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.dbdataservices.SQLUtil;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Feb 16, 2007
 * Time: 2:31:41 PM
 */
public class CreateLexiconCompetitiveProduct
   extends SymbolAcceptingColumnFixture
{
   public Long productId;
   public String productPubkey;
   public String crop;
   public boolean logicalDelete;

   private SQLPropFile sqlPropFile = new SQLPropFile(LexiconProductFixtureSQL.class);

   public boolean created()
      throws WrappingException
   {
      LexiconConnectionFactory connectionFactory = new LexiconConnectionFactory();
      PersistentStoreConnection conn = connectionFactory.getConnection();
      LexiconAuditor lexiconAuditor = LexiconTestTools.FITNESSE_TEST_AUDITOR;
      lexiconAuditor.initializeStaging(conn);
      try {
         int numInserted = insertFakeData(conn);
         return numInserted == 1;
      }
      finally {
         lexiconAuditor.removeStaging(conn);
         conn.close();
      }
   }

   private int insertFakeData(PersistentStoreConnection conn)
      throws WrappingException
   {
      String productInsertSQL = sqlPropFile.getSQL(LexiconProductFixtureSQL.INSERT_COMPETITIVE_PRODUCT);
      PersistentStoreStatement stmt = conn.prepareStatement(productInsertSQL);
      try {
         stmt.setParam(1, productId);
         stmt.setParam(2, productPubkey);
         stmt.setParam(3, StringUtils.toUpperCaseNull(crop));
         stmt.setParam(4, SQLUtil.booleanToString(logicalDelete));
         return stmt.executeInsert();
      }
      finally {
         stmt.close();
      }
   }
}
