package com.monsanto.tcc.lexiconfixtures.data.midas.allinfo;

import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald - Nov 24, 2009 6:41:47 PM
 */
public class DeleteInventoriesByGeneticMaterialIds
{
   private final String sql = "DELETE FROM Midas.Inventory I WHERE I.genetic_material_id = ?";

   public int delete(PersistentStoreConnection conn, Long[] geneticMaterialIds)
      throws WrappingException
   {
      PersistentStoreStatement statement = conn.prepareStatement(sql);
      try {
         int numDeleted = 0;
         for (Long geneticMaterialId : geneticMaterialIds) {
            numDeleted += deleteRecord(statement, geneticMaterialId);
         }
         return numDeleted;
      }
      finally {
         statement.close();
      }
   }

   private int deleteRecord(PersistentStoreStatement stmt, Long geneticMaterialId)
      throws WrappingException
   {
      stmt.setParam(1, geneticMaterialId);
      return stmt.executeDelete();
   }
}
