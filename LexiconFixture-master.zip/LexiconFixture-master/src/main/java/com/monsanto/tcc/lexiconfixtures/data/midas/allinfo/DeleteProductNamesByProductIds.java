package com.monsanto.tcc.lexiconfixtures.data.midas.allinfo;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Mar 16, 2007
 * Time: 4:59:12 PM
 * To change this template use File | Settings | File Templates.
 */
public class DeleteProductNamesByProductIds
{
   private final String sql = "DELETE FROM Midas.product_name PN WHERE PN.product_id = ?";

   public int deleteProductNames(PersistentStoreConnection conn, Long[] productIds)
      throws WrappingException
   {
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         int numDeleted = 0;
         for (int i = 0; i < productIds.length; i++) {
            stmt.setParam(1, productIds[i]);
            numDeleted += stmt.executeDelete();
         }
         return numDeleted;
      }
      finally {
         stmt.close();
      }
   }
}
