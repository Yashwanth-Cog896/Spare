package com.monsanto.tcc.lexiconfixtures.data.midas.productname;

import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 7, 2006
 * Time: 2:31:05 PM
 * To change this template use File | Settings | File Templates.
 */
public class RemoveMidasProductName
   extends SymbolAcceptingColumnFixture
{
   public Long productNameId;
   public String precomlName;
   public String name;
   public String brand;
   public String country;

   public boolean removed()
      throws WrappingException
   {
      Long productNameId = getProductNameId();
      RemoveMidasProductNameById removeById = new RemoveMidasProductNameById(productNameId);
      return removeById.remove() == 1;
   }

   private Long getProductNameId()
      throws WrappingException
   {
      return productNameId == null ? getProductNameIdByAttributes() : productNameId;
   }

   private Long getProductNameIdByAttributes()
      throws WrappingException
   {
      MidasProductNameIdByCriteriaQuery query = new MidasProductNameIdByCriteriaQuery(precomlName, name, brand, country);
      return query.getProductNameId();
   }
}
