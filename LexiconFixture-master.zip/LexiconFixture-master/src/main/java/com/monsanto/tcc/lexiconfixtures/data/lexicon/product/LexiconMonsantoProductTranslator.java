package com.monsanto.tcc.lexiconfixtures.data.lexicon.product;

import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 27, 2006
 * Time: 12:20:15 PM
 * To change this template use File | Settings | File Templates.
 */
public class LexiconMonsantoProductTranslator
   extends SymbolAcceptingColumnFixture
{
   public String precomlName;

   public String productPubkey()
      throws WrappingException
   {
      return new LexiconProductPubkeyByPreComlNameQuery(precomlName).getPubkey();
   }
}

