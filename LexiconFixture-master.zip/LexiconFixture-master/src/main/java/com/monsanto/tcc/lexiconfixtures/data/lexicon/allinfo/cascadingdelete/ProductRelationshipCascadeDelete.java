/*
 ProductRelationshipCascadeDelete was created on Jul 17, 2007 using Monsanto
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo.cascadingdelete;

import com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo.cascadingdelete.query.id.LexiconProductIdsByProductRelationshipId;
import com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo.cascadingdelete.query.id.ProductRelationshipXrefIdsByProductRelationshipId;
import com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo.cascadingdelete.query.delete.ProductRelationshipDelete;
import com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo.cascadingdelete.query.delete.AbstractLexiconDeleteByIDDataMod;
import com.monsanto.Util.Exceptions.WrappingException;
import java.util.List;

/**
 * nbwald Jul 17, 2007 11:48:58 AM
 */
public class ProductRelationshipCascadeDelete
   extends AbstractCascadingDelete
{
   private final long productRelationshipId;

   public ProductRelationshipCascadeDelete(long productRelationshipId) {
      this.productRelationshipId = productRelationshipId;
   }

   protected boolean removeDependencies()
      throws WrappingException
   {
      List<Long> xrefIds = getDependentXrefs();
      List<Long> productIds = getDependentProducts();
      return removeDependentProductXrefs(xrefIds) && removeDependentProducts(productIds);
   }

   protected AbstractLexiconDeleteByIDDataMod getSelfDeleter() {
      return new ProductRelationshipDelete(productRelationshipId);
   }

   private List<Long> getDependentXrefs()
      throws WrappingException
   {
      ProductRelationshipXrefIdsByProductRelationshipId xrefQuery = new ProductRelationshipXrefIdsByProductRelationshipId(productRelationshipId);
      return xrefQuery.getIds();
   }

   private List<Long> getDependentProducts()
      throws WrappingException
   {
      LexiconProductIdsByProductRelationshipId productQuery = new LexiconProductIdsByProductRelationshipId(productRelationshipId);
      return productQuery.getIds();
   }

   private boolean removeDependentProductXrefs(List<Long> xrefIds)
      throws WrappingException
   {
      boolean removed = true;
      for (long xrefId : xrefIds) {
         ProductRelationshipXrefCascadeDelete deleter = new ProductRelationshipXrefCascadeDelete(xrefId);
         removed &= deleter.remove();
      }
      return removed;
   }

   private boolean removeDependentProducts(List<Long> productIds)
      throws WrappingException
   {
      boolean removed = true;
      for (long productId : productIds) {
         LexiconProductCascadeDelete deleter = new LexiconProductCascadeDelete(productId);
         removed &= deleter.remove();
      }
      return removed;
   }
}