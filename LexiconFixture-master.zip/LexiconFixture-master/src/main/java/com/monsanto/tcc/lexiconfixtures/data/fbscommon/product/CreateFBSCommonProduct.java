package com.monsanto.tcc.lexiconfixtures.data.fbscommon.product;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconfixtures.data.factories.fbs.FBSCommonConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 9, 2006
 * Time: 12:56:09 PM
 * To change this template use File | Settings | File Templates.
 */
public class CreateFBSCommonProduct
   extends SymbolAcceptingColumnFixture
{
   public String lexiconProductPubkey;
   public Long midasProductId;

   private SQLPropFile sqlPropFile = new SQLPropFile(FBSCommonProductFixtureSQL.class);

   public boolean created()
      throws WrappingException
   {
      FBSCommonConnectionFactory connectionFactory = new FBSCommonConnectionFactory();
      PersistentStoreConnection conn = connectionFactory.getConnection();
      try {
         int numInserted = insertFakeData(conn);
         return numInserted == 1;
      }
      finally {
         conn.close();
      }
   }

   private int insertFakeData(PersistentStoreConnection conn)
      throws WrappingException
   {
      String sql = sqlPropFile.getSQL(FBSCommonProductFixtureSQL.INSERT_PRODUCT);
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, lexiconProductPubkey);
         stmt.setParam(2, midasProductId);
         return stmt.executeInsert();
      }
      finally {
         stmt.close();
      }
   }
}
