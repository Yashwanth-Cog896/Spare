package com.monsanto.tcc.lexiconfixtures.serviceat.person;

import com.monsanto.tps.lexicon.person.PersonRecord;
import com.monsanto.tps.lexicon.person.Person;
import com.monsanto.tps.lexicon.contact.Address;
import com.monsanto.tps.lexicon.contact.Location;
import com.monsanto.tps.lexicon.contact.Email;
import com.monsanto.tps.lexicon.contact.Organization;
import com.monsanto.tps.lexicon.contact.PhoneNumber;

/**
 * nbwald - May 22, 2008 7:05:14 PM
*/
public class PersonRecordAdapter
{
   public long uniqueId;
   public String firstName;
   public String middleName;
   public String lastName;
   public String userId;
   public String employeeStatus;
   public String title;
   public String orgId;
   public String orgDesc;
   public String divisionId;
   public String divisionDesc;
   public String mailCode;
   public String fullCostCenter;
   public String unitId;
   public String unitDesc;
   public String phoneNumber;
   public String cellNumber;
   public String pager;
   public String fax;
   public String email;
   public String mailZone;
   public String siteName;
   public String siteIndex;
   public String address1;
   public String address2;
   public String address3;
   public String city;
   public String county;
   public String state;
   public String country;
   public String postalCode;

   public PersonRecordAdapter(PersonRecord personRecord) {
      this.uniqueId = personRecord.getUniqueID();
      loadPersonData(personRecord.getPerson());
      loadOrganizationData(personRecord.getOrganization());
      loadTelephoneNumbers(personRecord);
      loadEmailData(personRecord.getEmail());
      loadLocationData(personRecord.getLocation());
      loadAddressData(personRecord.getAddress());
   }

   private void loadAddressData(Address address) {
      if(address != null) {
         this.address1 = address.getLine1();
         this.address2 = address.getLine2();
         this.address3 = address.getLine3();
         this.city = address.getCity();
         this.county = address.getCounty();
         this.state = address.getState();
         this.country = address.getCountry();
         this.postalCode = address.getPostalCode();
      }
   }

   private void loadLocationData(Location location) {
      if(location != null) {
         this.mailZone = location.getMailZone();
         this.siteName = location.getSiteName();
         this.siteIndex = location.getSiteIndex();
      }
   }

   private void loadEmailData(Email emailAddress) {
      if(emailAddress != null) {
         this.email = emailAddress.getEmailAddress();
      }
   }

   private void loadOrganizationData(Organization organization) {
      if(organization != null) {
         this.orgId = organization.getOrgID();
         this.orgDesc = organization.getOrgDesc();
         this.divisionId = organization.getDivisionID();
         this.divisionDesc = organization.getDivisionDesc();
         this.mailCode = organization.getMailCode();
         this.fullCostCenter = organization.getFullCostCenter();
         this.unitId = organization.getUnitID();
         this.unitDesc = organization.getUnitDesc();
      }
   }

   private void loadPersonData(Person person) {
      if(person != null) {
         this.firstName = person.getFirstName();
         this.middleName = person.getMiddleName();
         this.lastName = person.getLastName();
         this.userId = person.getUserID();
         this.employeeStatus = person.getEmployeeStatus();
         this.title = person.getTitle();
      }
   }

   private void loadTelephoneNumbers(PersonRecord personRecord) {
      this.phoneNumber = getPhoneNumber(personRecord.getPhoneNumber());
      this.cellNumber = getPhoneNumber(personRecord.getCellNumber());
      this.pager = getPhoneNumber(personRecord.getPager());
      this.fax = getPhoneNumber(personRecord.getFax());
   }

   private String getPhoneNumber(PhoneNumber phoneNumber) {
      return phoneNumber == null ? null : phoneNumber.getNumber();
   }
}
