package com.monsanto.tcc.lexiconfixtures.data.midas.productname;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreInsert;
import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 7, 2006
 * Time: 2:07:20 PM
 * To change this template use File | Settings | File Templates.
 */
public class CreateMidasProductName
   extends SymbolAcceptingColumnFixture
{
   public Long productNameId;
   public Long productId;
   public String name;
   public String brand;
   public String country;
   public String refActive;

   public boolean created()
      throws WrappingException
   {
      MidasProductNameInsert dataMod = new MidasProductNameInsert();
      return dataMod.performInsert() == 1;
   }

   class MidasProductNameInsert
      extends AbstractPersistentStoreInsert
   {
      protected String getSQL() throws WrappingException {
         return new SQLPropFile(MidasProductNameFixtureSQL.class).getSQL(MidasProductNameFixtureSQL.INSERT_PRODUCT_NAME);
      }
      protected Object[] getBindVariables() throws WrappingException {
         return new Object[] {
            productNameId, productId, name,
            StringUtils.toUpperCaseNull(brand),
            StringUtils.toUpperCaseNull(country),
            parseRefActive() ? "T" : "F"
         };
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new MidasConnectionFactoryProperties();
      }
      private boolean parseRefActive() {
         return "t".equalsIgnoreCase(refActive) || "true".equalsIgnoreCase(refActive) || "yes".equalsIgnoreCase(refActive);
      }
   }

}
