package com.monsanto.tcc.lexiconfixtures.util.preference;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreInsert;
import com.monsanto.tcc.lexiconfixtures.util.UserHelper;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jul 2, 2007
 * Time: 4:12:43 PM
 */
class InsertUserPreference
   extends AbstractPersistentStoreInsert
{
   private final String prefName;
   private final String defaultValue;

   public InsertUserPreference(final String prefName, final String defaultValue) {
      this.prefName = prefName;
      this.defaultValue = defaultValue;
   }
   protected Object[] getBindVariables()
      throws WrappingException
   {
      return new Object[] { UserHelper.getCurrentUserLoginId(), prefName, defaultValue };
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
   protected String getSQL()
      throws WrappingException
   {
      return "INSERT INTO Lexicon.User_Preference (" +
         "user_preference_id, user_login_id, preference_definition_name, default_value)" +
         "VALUES (User_Preference_Id_Seq.NEXTVAL, ?, ?, ?)";
   }
}
