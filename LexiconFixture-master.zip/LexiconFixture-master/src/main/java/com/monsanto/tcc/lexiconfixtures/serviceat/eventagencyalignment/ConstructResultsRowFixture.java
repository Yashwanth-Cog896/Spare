package com.monsanto.tcc.lexiconfixtures.serviceat.eventagencyalignment;

import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingRowFixture;
import com.monsanto.tps.lexicon.event.EventComponent;
import com.monsanto.tps.lexicon.event.EventInfo;
import com.monsanto.tps.lexicon.event.Construct;

import java.util.ArrayList;
import java.util.List;

/**
 * nbwald - Feb 26, 2009 2:12:01 PM
 */
public class ConstructResultsRowFixture
   extends SymbolAcceptingRowFixture
{
   private EventInfo[] eventInfos;

   public ConstructResultsRowFixture(EventInfo[] eventInfos) {
      this.eventInfos = eventInfos;
   }

   @Override
   public Object[] query()
      throws Exception
   {
      return build();
   }

   private ConstructRowAdaptor[] build() {
      if(eventInfos == null) {
         return new ConstructRowAdaptor[0];
      }
      else {
         List<ConstructRowAdaptor> adaptors = new ArrayList<ConstructRowAdaptor>();
         for (EventInfo eventInfo : eventInfos) {
            if(eventInfo.getEventComponents() != null) {
               for(EventComponent eventComponent: eventInfo.getEventComponents()){
                   if(eventComponent.getConstructs()!=null){
                       for (Construct construct : eventComponent.getConstructs()) {
                          adaptors.add(new ConstructRowAdaptor(eventInfo, construct));
                       }
                   }
               }
            }
         }
         return adaptors.toArray(new ConstructRowAdaptor[adaptors.size()]);
      }
   }

   @Override
   public Class<?> getTargetClass() {
      return ConstructRowAdaptor.class;
   }
}