package com.monsanto.tcc.lexiconfixtures.serviceat.regulatoryevent;

import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingRowFixture;

/**
 * User: pjberry
 * Date: Aug 2, 2007
 * Time: 1:59:44 PM
 */
public class RegulatoryEventRowFixture
   extends SymbolAcceptingRowFixture
{
   private RegulatoryEvent[] regulatoryEvents;

   public RegulatoryEventRowFixture(RegulatoryEvent[] regulatoryEvents) {
      this.regulatoryEvents = regulatoryEvents;
   }

   public Object[] query()
      throws Exception
   {
      return regulatoryEvents;
   }

   public Class getTargetClass() {
      return RegulatoryEvent.class;
   }
}
