package com.monsanto.tcc.lexiconfixtures.util.preference;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.LexiconDataFixtureInsert;
import com.monsanto.tcc.lexiconfixtures.util.UserHelper;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IXA.
 * User: jaskidi
 * Date: Jun 28, 2007
 * Time: 12:59:42 PM
 */
class InsertPreferenceValue
   extends LexiconDataFixtureInsert
{
   private final String prefName;
   private final String value;
   public InsertPreferenceValue(String prefName, String value) {
      this.prefName = prefName;
      this.value = value;
   }

   protected Object[] getBindVariables() throws WrappingException {
      return new Object[]  { value, UserHelper.getCurrentUserLoginId(), prefName };
   }
   protected ConnectionFactoryProperties getConnectionFactoryProperties() {
      return new LexiconConnectionFactoryProperties();
   }
   protected String getSQL()
      throws WrappingException
   {
      return "INSERT INTO Lexicon.User_Preference_Value " +
               "(user_preference_value_id, user_preference_id, value) " +
               "( SELECT User_Preference_Value_Id_Seq.NEXTVAL, user_preference_id, ? " +
                  "FROM  Lexicon.User_Preference WHERE user_login_id = ? AND preference_definition_name = ?" +
             ")";
   }
}
