package com.monsanto.tcc.lexiconfixtures.webappat;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 27, 2006
 * Time: 9:11:17 AM
 * To change this template use File | Settings | File Templates.
 */
public class AssignPreComlNameServiceFixture
//   extends TableFixture
{
/*
   private static final int PRE_COML_NAME_COLUMN = 0;
   private static final int MANUFACTURING_NAME_COLUMN = 1;
   private static final int EQUIV_PRE_COML_NAME_COLUMN = 2;
   private static final int CROP_COLUMN = 3;
   private static final int TRAIT_VERSION_COLUMN = 4;
   private static final int GERMPLASM_KEYS_COLUMN = 5;
   private static final int ERRORS_COLUMN = 6;
   private static final int WARNINGS_COLUMN = 7;

   protected void doStaticTable(int numOfRows) {
      AssignPCNameRequestValues[] requestBatch = buildRequestBatch(numOfRows);
      AssignPCNameResponseDOMImpl[] responses = getResponse(requestBatch);
      checkResponse(responses, numOfRows);
   }

   private void checkResponse(AssignPCNameResponseDOMImpl[] responses, int numOfRows) {
      for (int i = 0; i < responses.length; i++) {
         String preComlName =  responses[i].getPreComlName();
         int rowNum = getRowNumFromPreComlName(preComlName, numOfRows);
         checkErrors(responses[i], rowNum);
         checkWarnings(responses[i], rowNum);
      }
   }

   private void checkErrors(AssignPCNameResponseDOMImpl response, int rowNum) {
      String expectedErrors = getText(rowNum, ERRORS_COLUMN);
      String errorsFromResponse = convertArrayToString(response.getErrors());
      if(expectedErrors.equals(errorsFromResponse)) {
         right(rowNum, ERRORS_COLUMN);
      }
      else {
         wrong(rowNum, ERRORS_COLUMN, errorsFromResponse);
      }
   }

   private void checkWarnings(AssignPCNameResponseDOMImpl response, int rowNum) {
      String expectedWarnings = getText(rowNum, WARNINGS_COLUMN);
      String warningssFromResponse = convertArrayToString(response.getNotes());
      if(expectedWarnings.equals(warningssFromResponse)) {
         right(rowNum, WARNINGS_COLUMN);
      }
      else {
         wrong(rowNum, WARNINGS_COLUMN, warningssFromResponse);
      }
   }

   private int getRowNumFromPreComlName(String preComlName, int numOfRows) {
      for(int rowNum = 1; rowNum < numOfRows; rowNum++) {
         String preComlNameToTest = getText(rowNum, PRE_COML_NAME_COLUMN);
         if( preComlName.equalsIgnoreCase(preComlNameToTest) ) return rowNum;
      }
      return -1;
   }

   private AssignPCNameResponseDOMImpl[] getResponse(AssignPCNameRequestValues[] requestBatch) {
      try {
         SecurityProxyFactory.getInstance().setThreadProxy(new KerberosStandaloneCredential());
         AssignPCNameServiceInvoker serviceCall = new AssignPCNameServiceInvoker(requestBatch);
         return serviceCall.callService();
      }
      catch (GSSException e) {
         e.printStackTrace();
      }
      catch (POSException e) {
         e.printStackTrace();
      }
      catch (POSCommunicationException e) {
         e.printStackTrace();
      }
      return new AssignPCNameResponseDOMImpl[0];
   }

   private String convertArrayToString(String[] strings) {
      StringBuffer sb = new StringBuffer();
      for (int i = 0; i < strings.length; i++) {
         if(i > 0) sb.append(";");
         sb.append(strings[i]);
      }
      return sb.toString();
   }

   private AssignPCNameRequestValues[] buildRequestBatch(int numOfRows) {
      List batch = new ArrayList();
      for(int rowNum = 1; rowNum < numOfRows; rowNum++) {
         AssignPCNameRequestValues requestValues = buildIndividualRequestValues(rowNum);
         batch.add(requestValues);
      }
      return (AssignPCNameRequestValues[])batch.toArray(new AssignPCNameRequestValues[batch.size()]);
   }

   private AssignPCNameRequestValues buildIndividualRequestValues(int rowNum) {
      MockAssignPCNameRequestValues requestValues = new MockAssignPCNameRequestValues();
      setPreComlName(requestValues, rowNum);
      setManufacturingName(requestValues, rowNum);
      setEquivalentPCName(requestValues, rowNum);
      setCropName(requestValues, rowNum);
      setTraitVersion(requestValues, rowNum);
      setGermplasmKeys(requestValues, rowNum);
      return requestValues;
   }

   private void setPreComlName(MockAssignPCNameRequestValues requestValues, int rowNum) {
      requestValues.setPreComlName(getText(rowNum, PRE_COML_NAME_COLUMN));
   }

   private void setManufacturingName(MockAssignPCNameRequestValues requestValues, int rowNum) {
      requestValues.setManufacturingName(getText(rowNum, MANUFACTURING_NAME_COLUMN));
   }

   private void setEquivalentPCName(MockAssignPCNameRequestValues requestValues, int rowNum) {
      requestValues.setEquivalentPCName(getText(rowNum, EQUIV_PRE_COML_NAME_COLUMN));
   }

   private void setCropName(MockAssignPCNameRequestValues requestValues, int rowNum) {
      requestValues.setCropName(getText(rowNum, CROP_COLUMN));
   }

   private void setTraitVersion(MockAssignPCNameRequestValues requestValues, int rowNum) {
      requestValues.setTraitVersion(getText(rowNum, TRAIT_VERSION_COLUMN));
   }

   private void setGermplasmKeys(MockAssignPCNameRequestValues requestValues, int rowNum) {
      requestValues.setGermplasmKeys(buildGermplasmkeys(rowNum));
   }

   private long[] buildGermplasmkeys(int rowNum) {
      String[] germplasmKeysAsStrings = StringUtils.splitCsv(getText(rowNum, GERMPLASM_KEYS_COLUMN), false);
      long[] germplasmKeys = new long[germplasmKeysAsStrings.length];
      for (int i = 0; i < germplasmKeysAsStrings.length; i++) {
         germplasmKeys[i] = Long.parseLong(germplasmKeysAsStrings[i]);
      }
      return germplasmKeys;
   }
*/
}
