package com.monsanto.tcc.lexiconfixtures.webappat;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.lexiconcommon.test.LexiconApplicationHostHelper;
import com.monsanto.tcc.lexiconfixtures.data.lexicon.productflowcriteria.ProductFlowCriteriaStorage;
import com.monsanto.tcc.lexiconfixtures.data.lexicon.productflowcriteria.ProductFlowCriteriaTestTool;
import com.monsanto.tcc.lexiconfixtures.selenium.LexiconSelenium;
import com.monsanto.tcc.lexiconfixtures.selenium.SeleniumServerWrapper;
import com.monsanto.tcc.lexiconfixtures.util.ConfigureMidasCropMixin;
import com.monsanto.tcc.lexiconfixtures.util.approle.AppRoleTestTools;
import com.monsanto.tcc.lexiconfixtures.util.approle.AppRoleTestToolsFixtureMixin;
import com.monsanto.tcc.lexiconfixtures.util.symbol.LongParseDelagate;
import com.monsanto.tcc.lexiconfixtures.util.symbol.StringParseDelagate;
import com.monsanto.tcc.lexiconfixtures.webappat.preference.crop.CropPrefStorageTool;
import com.thoughtworks.selenium.SeleniumException;
import fit.Fixture;
import fitlibrary.DoFixture;
import fitlibrary.GridFixture;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Feb 5, 2007
 * Time: 2:49:33 PM
 */
public class SeleniumFixture
   extends DoFixture
{
   private LexiconSelenium selenium;
   private final SeleniumServerWrapper serverWrapper = new SeleniumServerWrapper();

   private final CropPrefStorageTool cropPrefStorage = new CropPrefStorageTool();
   private final ProductFlowCriteriaStorage productFlowCriteriaStorage = new ProductFlowCriteriaStorage();

   private AppRoleTestToolsFixtureMixin roles = new AppRoleTestToolsFixtureMixin();

   public SeleniumFixture() {
      registerParseDelegate(String.class, new StringParseDelagate());
      registerParseDelegate(Long.class, new LongParseDelagate());
   }

   public boolean connect()
      throws Exception
   {
      serverWrapper.startServer();
      selenium = buildLexiconSelenium();
      selenium.start();
      pauseSeconds(1);
      return true;
   }

   public boolean disconnect()
      throws InterruptedException
   {
      final String MAX_WAIT_TIME_IN_MS = "10000";
      String host = LexiconApplicationHostHelper.getApplicationHost();
      selenium.open("http://" + host + "/lexicon-app/servlet/LexiconLogout");
      selenium.waitForPageToLoad(MAX_WAIT_TIME_IN_MS);
      selenium.stop();
      serverWrapper.stopServer();
      return true;
   }

   public String title() {
      return selenium.getTitle();
   }

   // Try to avoid using this guy.  Use clickWaitForPageToLoad.
   public boolean clickAndWaitForPageToLoad(String thingToClick) {
      if(selenium.isElementPresent(thingToClick)) {
         selenium.click(thingToClick);
         waitForPageToLoad();
         return true;
      }
      else {
         throw new SeleniumException("Locator to click, '" + thingToClick + "', is not present.");
      }
   }

   public boolean clickLink(String link) {
      return clickWaitForPageToLoad("link=" + link);
   }

   public boolean clickWaitForPageToLoad(String thingToClick) {
      selenium.click(thingToClick);
      waitForPageToLoad();
      return true;
   }

   public boolean clickLinkWaitForElementToBecomeVisible(String link, String elementName) {
      selenium.click("link=" + link);
      selenium.waitForElementPresent(elementName);
      return true;
   }

   public boolean click(String thingToClick) {
      selenium.click(thingToClick);
      return true;
   }

   public boolean clickIcon(String icon) {
      return clickAndWaitForPageToLoad(icon);
   }

   public boolean enterFor(String value, String locator) {
      selenium.type(locator, value);
      return true;
   }

   public boolean selectFor(String optionLocator, String selectLocator) {
      if(optionLocator.contains(",")) {
         selectMultiple(selectLocator, optionLocator);
      } else {
         selenium.select(selectLocator, optionLocator);
      }
      return true;
   }

   private void selectMultiple(String selectLocator, String optionsToSelectCSV) {
      String[] optionsToSelectArray = StringUtils.splitCsv(optionsToSelectCSV, false);
      for (String option : optionsToSelectArray) {
         selenium.addSelection(selectLocator, option);
      }
   }

   public boolean clickFor(String value, String name) {
      selenium.click("name=" + name + " " + "value=" + value);
      return true;
   }

   public String alert() {
      String alerted = selenium.getAlert();
      return replaceNewlinesWithSpaces(alerted);
   }

   public String fieldIs(String locator) {
      String value = selenium.getFieldValue(locator);
      return replaceNewlinesWithSpaces(value);
   }

   public boolean fieldExists(String locator) {
      return selenium.isElementPresent(locator);
   }

   public boolean fieldIsEditable(String locator) {
      return selenium.isFieldEditable(locator);
   }

   public boolean fieldIsVisible(String locator) {
      return selenium.isVisible(locator);   
   }

   public boolean fieldHasValue(String locator) {
      return !StringUtils.isNullOrEmpty(fieldIs(locator)); 
   }

   public void waitForPageToLoad() {
      selenium.waitForPageToLoad("60000");
   }

   public void pauseSeconds(int seconds)
      throws InterruptedException
   {
      Thread.sleep(seconds * 1000);
   }

   public Fixture iconsIn(String locator) {
      String[] imageNames = selenium.getChildImageNames(locator);
      return new IconFixture(imageNames);
   }

   public Fixture optionsIn(String selectLocator) {
      String[] options = selenium.getSelectOptions(selectLocator);
      return new OptionsFixture(options);
   }

   public Fixture errorsIn(String unorderedListLocator) {
      String[] listItemTexts = getSelenium().getChildListItemTexts(unorderedListLocator);
      return new UnorderedListElementsFixture(listItemTexts);
   }

   public String rowIsColor(String htmlTableRowLocator) {
      String attributeLocator = htmlTableRowLocator + "@class";
      String className = selenium.getAttribute(attributeLocator);
      return UIFixtureUtils.colorFromClassName(className);
   }

   public Fixture notesIn(String unorderedListLocator) {
      return errorsIn(unorderedListLocator);
   }

   public boolean elementExists(String elementLocator) {
      return selenium.isElementPresent(elementLocator);   
   }

   public boolean linkExists(String linkText) {
      return selenium.isElementPresent("link=" + linkText);
   }

   public boolean textExists(String text) {
      return selenium.isTextPresent(text);
   }

   public boolean buttonExists(String buttonLocator) {
      return selenium.isElementPresent(buttonLocator);
   }

   public boolean clickLinkWithHeading(String link, String heading) {
      return clickAndWaitForPageToLoad(getMenuLocator(link, heading));
   }

   private String getMenuLocator(String link, String heading) {
      return getMenuLocator(heading) + "_" + link.replaceAll(" ", "");
   }

   protected String getMenuLocator(String heading) {
      return "id=" + heading.replaceAll(" ", "");
   }

   public Fixture checkScreenTable(String htmlTableLocator)
      throws Exception
   {
      HtmlTableParser parser = new HtmlTableParser(getSelenium(), htmlTableLocator);
      String[][] tableGrid = parser.getTable();
      return new GridFixture(tableGrid);
   }

   public Fixture checkScreenRow(String locatorCsv)
      throws IOException, ParserConfigurationException, SAXException
   {
      String[] locators = StringUtils.splitCsv(locatorCsv, false);
      return new HtmlTableRowCheckFixture(selenium, locators);
   }

   public LexiconSelenium getSelenium() {
      return selenium;
   }

   public boolean saveApplicationRoles()
      throws Exception
   {
      return roles.saveApplicationRoles();
   }

   public boolean restoreApplicationRoles()
      throws Exception
   {
      return roles.restoreApplicationRoles();
   }

   public Fixture setApplicationRole() {
      return roles.setApplicationRole();
   }

   public boolean saveCropPreference()
      throws Exception
   {
      return cropPrefStorage.saveCropPreference();
   }

   public boolean restoreCropPreference()
      throws Exception
   {
      return cropPrefStorage.restoreCropPreference();
   }

   public boolean saveSapSubscriptionCriteria()
      throws Exception
   {
      return productFlowCriteriaStorage.saveCriteria();
   }

   public boolean restoreSapSubscriptionCriteria()
      throws Exception
   {
      return productFlowCriteriaStorage.restoreCriteria();
   }

   public boolean removeAllSapSubscriptionCriteria()
      throws Exception
   {
      ProductFlowCriteriaTestTool.clearCriteria();
      return true;
   }

   public boolean grantFullAccess()
      throws Exception
   {
      AppRoleTestTools.setAllRolesForCurrentUser();
      return true;
   }

   public boolean configureMidasCrop(String cropGenusSpecies)
      throws Exception
   {
      return new ConfigureMidasCropMixin().configureMidasCrop(cropGenusSpecies);
   }

   private LexiconSelenium buildLexiconSelenium() {
      return new LexiconSelenium("localhost", SeleniumServerWrapper.SELENIUM_SERVER_PORT, "*iehta",
         "http://" + LexiconApplicationHostHelper.getApplicationHost());
   }

   private String replaceNewlinesWithSpaces(String s) {
      return s.replaceAll("\n", " ").replaceAll("\r", " ");
   }
}
