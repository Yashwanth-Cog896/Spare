package com.monsanto.tcc.lexiconfixtures.data.factories.virgo;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryPropertiesLexiconImpl;
import com.monsanto.tcc.lexiconcommon.props.PropertyManager;
import java.io.IOException;
import java.util.Properties;

/**
 * User: pjberry
 * Date: Aug 1, 2007
 * Time: 4:38:33 PM
 */
public class VirgoConnectionFactoryProperties
   extends ConnectionFactoryPropertiesLexiconImpl
{
   public static final String INSTANCE_NAME = "Virgo";
   private static final String PROP_FILENAME = "VirgoDB.properties";

   public String getInstanceName() {
      return INSTANCE_NAME;
   }
   public Properties loadProperties() throws IOException {
      return PropertyManager.getInstance().getNonCachedProperties(getClass(), PROP_FILENAME);
   }
}
