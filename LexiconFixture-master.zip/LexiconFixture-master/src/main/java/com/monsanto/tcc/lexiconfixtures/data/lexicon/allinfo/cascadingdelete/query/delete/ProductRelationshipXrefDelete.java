/*
 ProductRelationshipXrefDelete was created on Jul 17, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.data.lexicon.allinfo.cascadingdelete.query.delete;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.LexiconDataFixtureDelete;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * nbwald Jul 17, 2007 12:00:10 PM
 */
public class ProductRelationshipXrefDelete
   extends AbstractLexiconDeleteByIDDataMod
{
   public ProductRelationshipXrefDelete(long productRelationshipXrefID) {
      super(productRelationshipXrefID);
   }

   protected String getSQL()
      throws WrappingException
   {
      return "DELETE FROM Lexicon.Product_Relationship_Xref WHERE product_relationship_xref_id = ?";
   }
}