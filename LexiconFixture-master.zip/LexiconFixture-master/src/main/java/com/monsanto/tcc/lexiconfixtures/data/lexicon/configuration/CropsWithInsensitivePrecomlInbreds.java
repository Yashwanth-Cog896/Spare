package com.monsanto.tcc.lexiconfixtures.data.lexicon.configuration;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.lexiconcommon.exception.RuntimeWrappingException;
import fitnesse.fixtures.TableFixture;

/**
 * nbwald - Sep 19, 2008 3:27:50 PM
 */
public class CropsWithInsensitivePrecomlInbreds
   extends TableFixture
{
   private static final String INSENSITIVE_PRECOML_INBRED_CROPS = "INSENSITIVE_PRECOML_INBRED_CROPS";

   protected void doStaticTable(int rows) {
      try {
         clearAllConfiguredCrops();
         configureEachListedCrop(rows);
      }
      catch (WrappingException e) {
         throw new RuntimeWrappingException(e);
      }
   }

   private void configureEachListedCrop(int rows)
      throws WrappingException
   {
      for(int r = 1; r < rows; r++) {
         if(configureCrop(getText(r, 0))) {
            right(r, 0);
         }
         else {
            wrong(r, 0);
         }
      }
   }

   private void clearAllConfiguredCrops()
      throws WrappingException
   {
      CropConfigurationDeleteAll cropConfigurationDeleteAll = new CropConfigurationDeleteAll(INSENSITIVE_PRECOML_INBRED_CROPS);
      cropConfigurationDeleteAll.performDelete();
   }

   private boolean configureCrop(String cropName)
      throws WrappingException
   {
      CropConfigurationInsert cropConfigurationInsert = new CropConfigurationInsert(INSENSITIVE_PRECOML_INBRED_CROPS, cropName);
      return cropConfigurationInsert.performInsert() == 1;
   }
}
