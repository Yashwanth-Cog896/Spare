package com.monsanto.tcc.lexiconfixtures.data.factories.virgo;

import com.monsanto.tcc.lexiconcommon.db.factories.BasicConnectionFactory;

/**
 * User: pjberry
 * Date: Aug 1, 2007
 * Time: 4:37:36 PM
 */
public class VirgoConnectionFactory
   extends BasicConnectionFactory
{
   public VirgoConnectionFactory() {
      super(new VirgoConnectionFactoryProperties());
   }
}
