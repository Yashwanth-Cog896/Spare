package com.monsanto.tcc.lexiconfixtures.serviceat.regulatoryevent;

/**
 * User: pjberry
 * Date: Aug 2, 2007
 * Time: 10:14:24 AM
 */
public class RegulatoryEventResponse
{
   public RegulatoryEvent[] RegulatoryEventList;

   public RegulatoryEventResponse(RegulatoryEvent[] fixtureRegulatoryEvents) {
      this.RegulatoryEventList = fixtureRegulatoryEvents;
   }
}
