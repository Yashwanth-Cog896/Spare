/*
	 BusinessAccountFixture was created on Jun 4, 2008 using Monsanto
	 resources and is the sole property of Monsanto.  Any duplication of the
	 code and/or logic is a direct infringement of Monsanto's copyright.
	*/
package com.monsanto.tcc.lexiconfixtures.serviceat.businessaccount;

import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import static com.monsanto.Util.StringUtils.getLineSeparator;
import com.monsanto.tcc.lexiconcommon.ArrayUtils;
import static com.monsanto.tcc.lexiconfixtures.serviceat.person.CsvToLongs.convert;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingRowFixture;
import com.monsanto.tps.lexicon.account.BusinessAccount;
import com.monsanto.tps.lexicon.account.BusinessAccountSearchCriteria;
import com.monsanto.tps.lexicon.account.service.BusinessAccounts;
import com.monsanto.tps.lexicon.account.service.BusinessAccountsImpl;
import com.monsanto.tps.lexicon.contact.AddressRecord;
import com.monsanto.tps.lexicon.contact.SearchableLocation;
import fit.Fixture;
import fitlibrary.DoFixture;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: BusinessAccountFixture.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: nbwald $    	 On:	$Date: 2008-12-08 21:34:33 $
 *
 * @author MMR
 * @version $Revision: 1.18 $
 */
public class BusinessAccountFixture
        extends DoFixture {
   private BusinessAccount[] businessAccounts;
   private BusinessAccountSearchCriteria criteria = new BusinessAccountSearchCriteria();
   private SearchableLocation location = new SearchableLocation();
   private boolean exceptionThrown;
   private String errorMessage;

   public int noOfBusinessAccountsFound() {
      return businessAccounts == null ? 0 : businessAccounts.length;
   }

   public boolean throwsException() {
      return exceptionThrown;
   }

   public boolean companyName(String companyName) {
      criteria.setCompanyName(companyName);
      return true;
   }

   public boolean country(String country) {
      location.setCountryName(country);
      return true;
   }

   public boolean state(String state) {
      location.setSubcountryCode(state);
      return true;
   }

   public boolean county(String county) {
      location.setSubsubcountryName(county);
      return true;
   }

   public boolean city(String city) {
      location.setCity(city);
      return true;
   }

   public boolean findBusinessAccountsWithAccountIds(String accountIdsCSV) throws Exception {
      try {
         businessAccounts = getClient().findByIds(convert(accountIdsCSV, "Account Ids"));
      } catch (IllegalArgumentException e) {
         errorMessage = e.getMessage();
      }
      return true;
   }

   private BusinessAccounts getClient() throws Exception {
      return new BusinessAccountsImpl(new KerberosStandaloneCredential());
   }

   public boolean search() {
      criteria.setLocation(location);
      try {
         businessAccounts = getClient().findByCriteria(criteria);
      } catch (IllegalArgumentException e) {
         errorMessage = e.getMessage();
      } catch (Exception e) {
         e.printStackTrace();
         exceptionThrown = true;
      }
      return true;
   }

   public String errorMessage() {
      return errorMessage.replaceAll(getLineSeparator(), " ");
   }


   public Fixture checkResults() {
      return new SymbolAcceptingRowFixture() {
         public Class<?> getTargetClass() {
            return BusinessAccountAdaptor.class;
         }

         public Object[] query()
                 throws Exception {
            return buildBusinessAccountAdaptors();
         }
      };
   }

   private BusinessAccountAdaptor[] buildBusinessAccountAdaptors() {
      List<BusinessAccountAdaptor> adaptors = new ArrayList<BusinessAccountAdaptor>();
      for (BusinessAccount businessAccount : businessAccounts) {
         AddressRecord[] addressRecords = getAddressRecords(businessAccount);
         for (AddressRecord addressRecord : addressRecords) {
            adaptors.add(new BusinessAccountAdaptor(businessAccount, addressRecord));
         }
      }
      return adaptors.toArray(new BusinessAccountAdaptor[adaptors.size()]);
   }

   private AddressRecord[] getAddressRecords(BusinessAccount businessAccount) {
      AddressRecord[] addressRecords = businessAccount.getAddressRecords();
      return ArrayUtils.hasItems(addressRecords) ? addressRecords : EmptyAddressRecord.get();
   }
}