package com.monsanto.tcc.lexiconfixtures.data.lexicon.stage;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetRow;

/**
 * nbwald - Mar 17, 2008 5:46:14 PM
 */
public class TranslateLexiconStage
   extends SymbolAcceptingColumnFixture
{
   public String stageDescription;

   public String stagePubkey()
      throws WrappingException
   {
      StagePubkeyFromDescriptionQuery query = new StagePubkeyFromDescriptionQuery();
      return query.getPubkey();
   }

   private class StagePubkeyFromDescriptionQuery
      extends AbstractPersistentStoreSingleResultQuery
   {
      private String  getPubkey()
         throws WrappingException
      {
         return (String) execute();
      }

      protected Object createObjectFromRow(PersistentStoreResultSetRow row)
         throws WrappingException
      {
         return row.getString(1);
      }

      protected String getSQL()
         throws WrappingException
      {
         return "SELECT S.stage_pubkey FROM Lexicon.Stage S WHERE UPPER(S.stage_desc) = UPPER(?)";
      }

      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[] {stageDescription};
      }

      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new LexiconConnectionFactoryProperties();
      }
   }
}
