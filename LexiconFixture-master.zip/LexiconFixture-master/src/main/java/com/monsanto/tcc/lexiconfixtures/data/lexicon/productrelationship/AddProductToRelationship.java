package com.monsanto.tcc.lexiconfixtures.data.lexicon.productrelationship;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.test.LexiconTestTools;
import com.monsanto.tcc.lexiconcommon.db.audit.LexiconAuditor;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.tcc.lexiconfixtures.util.ColumnFixtureResetter;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 15, 2006
 * Time: 12:07:57 PM
 * To change this template use File | Settings | File Templates.
 */
public class AddProductToRelationship
   extends SymbolAcceptingColumnFixture
{
   public Long productRelationshipXrefId;
   public String manufacturingName;
   public String preComlName;
   public String traitVersion;
   public String productionStatus;

   private SQLPropFile sqlPropFile = new SQLPropFile(ProductRelationshipFixtureSQL.class);

   public void reset()
      throws Exception
   {
      ColumnFixtureResetter.reset(this);
   }

   public boolean added()
      throws WrappingException
   {
      LexiconConnectionFactory connectionFactory = new LexiconConnectionFactory();
      PersistentStoreConnection conn = connectionFactory.getConnection();
      LexiconAuditor lexiconAuditor = LexiconTestTools.FITNESSE_TEST_AUDITOR;
      lexiconAuditor.initializeStaging(conn);
      try {
         int numInserted = insertFakeData(conn);
         return numInserted == 1;
      }
      finally {
         lexiconAuditor.removeStaging(conn);
         conn.close();
      }
   }

   private int insertFakeData(PersistentStoreConnection conn)
      throws WrappingException
   {
      String productInsertSQL = sqlPropFile.getSQL(ProductRelationshipFixtureSQL.INSERT_PRODUCT_RELATIONSHIP_XREF);
      PersistentStoreStatement stmt = conn.prepareStatement(productInsertSQL);
      try {
         stmt.setParam(1, productRelationshipXrefId);
         stmt.setParam(2, manufacturingName);
         stmt.setParam(3, preComlName);
         stmt.setParam(4, traitVersion);
         stmt.setParam(5, productionStatus);
         return stmt.executeInsert();
      }
      finally {
         stmt.close();
      }
   }
}
