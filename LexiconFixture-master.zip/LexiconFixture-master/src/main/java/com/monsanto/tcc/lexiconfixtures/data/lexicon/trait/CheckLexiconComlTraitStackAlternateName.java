package com.monsanto.tcc.lexiconfixtures.data.lexicon.trait;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreEntityExistsQuery;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.tcc.lexiconfixtures.util.ColumnFixtureResetter;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * User: pjberry
 * Date: May 23, 2007
 * Time: 10:27:05 AM
 */
public class CheckLexiconComlTraitStackAlternateName
   extends SymbolAcceptingColumnFixture
{
   public String alternateReportingName;
   public String alternateStackDescription;
   public String country;

   @Override
   public void reset()
      throws Exception
   {
      ColumnFixtureResetter.reset(this);
   }

   public boolean exists()
      throws WrappingException
   {
      CheckLexiconComlTraitStackAlternateNameQuery query = new CheckLexiconComlTraitStackAlternateNameQuery();
      return query.entityExists();
   }

   class CheckLexiconComlTraitStackAlternateNameQuery
      extends AbstractPersistentStoreEntityExistsQuery
   {
      protected String getSQL() {
         return
            "     SELECT * " +
            "       FROM Lexicon.Coml_Trait_Stack_Alt_Name CTSAN" +
            " INNER JOIN Lexicon.Coml_Trt_Stk_Cntry_Alt_Name CTSCAN on CTSAN.coml_trait_stack_alt_name_id = CTSCAN.coml_trait_stack_alt_name_id" +
            " INNER JOIN Lexicon.Country C on CTSCAN.country_id = C.country_id" +
            "      WHERE CTSAN.reporting_name = ?" +
            "        AND CTSAN.stack_desc = ?" +
            "        AND C.country_abbr = ?";
      }

      protected Object[] getBindVariables() throws WrappingException {
         return new Object[] { alternateReportingName, alternateStackDescription, country };
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new LexiconConnectionFactoryProperties();
      }
   }
}