/*
 HealthCheckFixture was created on Mar 29, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.webappat.healthcheck;

import com.monsanto.tcc.lexiconfixtures.selenium.LexiconSelenium;
import com.monsanto.tcc.lexiconfixtures.webappat.SeleniumFixture;
import fit.Fixture;

/**
 * nbwald Mar 29, 2007 2:06:19 PM
 */
public class HealthCheckFixture
   extends SeleniumFixture
{
   private static final int MILLIS_PER_SECOND = 1000;

   private static final int REPORT_NAME_INDEX = 0;
   private static final int COMPLETION_STATUS_INDEX = 2;
   private static final int VIEW_BUTTON_INDEX = 3;
   private static final int DELETE_BUTTON_INDEX = 4;

   private static final String SIMPLE_STRING_NODE = "nodeValue";
   private static final String RICH_STRING_NODE = "innerHTML";
   private static final String BUTTON_NODE = "disabled ? 'disabled' : 'enabled'";

   private int originalReportHeaderCount;

   public void noteExistingReports() {
      this.originalReportHeaderCount = countTableRows("reportHeaders");
   }

   private int countTableRows(String tableLocator) {
      String originalReportHeaderCountString = getSelenium().evaluate(
         "{"
            + " var tableElem = this.page().findElement('" + tableLocator + "'); "
            + " var TRs = tableElem.getElementsByTagName('TR'); "
            + " TRs.length"
            +
         "}"
      );
      return Integer.parseInt(originalReportHeaderCountString);
   }

   public void removeNewlyGeneratedReports() {
      int finalReportHeaderCount = countTableRows("reportHeaders");
      for(int i=originalReportHeaderCount; i<finalReportHeaderCount; i++) {
         deleteLastReportExecution();
      }
   }

   private void deleteLastReportExecution() {
      LexiconSelenium selenium = getSelenium();
      selenium.click("xpath=//TABLE[@id='reportHeaders']//TR[last()]/TD/INPUT[@name='Delete']");
      selenium.getConfirmation();
   }

   public String lastReportExecutionIs(String field) {
      return getLastRowsFieldValue(field);
   }

   private String getLastRowsFieldValue(String field) {
      if("report name".equals(field)) {
         return getValue(REPORT_NAME_INDEX, SIMPLE_STRING_NODE);
      }
      else if("completion status".equals(field)) {
         return getValue(COMPLETION_STATUS_INDEX, RICH_STRING_NODE);
      }
      else if("view".equals(field)) {
         return getValue(VIEW_BUTTON_INDEX, BUTTON_NODE);
      }
      else if("delete".equals(field)) {
         return getValue(DELETE_BUTTON_INDEX, BUTTON_NODE);
      }
      throw new IllegalArgumentException("Unknown field '" + field + "'");
   }

   private String getValue(int tableColumnIndex, String nodeValueExpression) {
      return getSelenium().evaluate(
         "{"
            + " var tableElem = this.page().findElement('reportHeaders'); "
            + " var implicitTBody = tableElem.firstChild; "
            + " var lastTR = implicitTBody.lastChild;"
            + " var tds = lastTR.childNodes;"
            + " var node = tds[" + tableColumnIndex + "];"
            + " node.firstChild." + nodeValueExpression
            +
         "}"
      );
   }

   public boolean reportIsFinished() {
      return !"Report Running".equals(getLastRowsFieldValue("completion status"));
   }

   public Fixture checkReportExecution() {
      return new CheckMyLastReportExecutionFixture();
   }

   public boolean waitForReportToFinishAtMostSeconds(int seconds)
      throws InterruptedException
   {
      int millisToWait = seconds * MILLIS_PER_SECOND;
      long start = System.currentTimeMillis();
      clickLinkWithHeading("Product Reports", "Reports");
      while(System.currentTimeMillis() - start < millisToWait && !reportIsFinished()) {
         clickLinkWithHeading("Product Reports", "Reports");
         Thread.yield();
         Thread.sleep(500);
      }
      return reportIsFinished();
   }
}