package com.monsanto.tcc.lexiconfixtures.serviceat.seedplanning;

import com.monsanto.tcc.lexiconcommon.DocumentCreator;
import com.monsanto.tcc.lexiconcommon.pos.LexiconPOSConnection;
import com.monsanto.tcc.lexiconcommon.pos.SecurityProxyFactory;
import com.monsanto.tcc.lexiconcommon.service.ProductParentGermplasmDocTags;
import com.monsanto.tcc.lexiconfixtures.util.symbol.LongParseDelagate;
import com.monsanto.tcc.lexiconfixtures.util.symbol.StringParseDelagate;
import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.POSClient.POSCommunicationException;
import com.monsanto.POSClient.POSConnection;
import com.monsanto.POSClient.POSException;
import com.monsanto.POSClient.POSResult;
import com.monsanto.POSClient.POSResultDocumentProcessor;
import com.monsanto.XMLUtil.DOMUtil;
import fit.Fixture;
import fitlibrary.DoFixture;
import org.ietf.jgss.GSSException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Feb 13, 2007
 * Time: 2:08:44 PM
 */
public class SeedPlanningToolFixture
   extends DoFixture
{
   private Document responseDocument;

   public SeedPlanningToolFixture() {
      registerParseDelegate(String.class, new StringParseDelagate());
      registerParseDelegate(Long.class, new LongParseDelagate());
   }

   public boolean query(String name)
      throws POSCommunicationException, POSException, GSSException
   {
      SecurityProxyFactory.getInstance().setThreadProxy(new KerberosStandaloneCredential());
      Document requestDoc = buildRequestDocument(name);
      responseDocument = getResponse(requestDoc);
      DOMUtil.outputXML(responseDocument);
      return true;
   }

   public Fixture checkProductRelationshipPubkeyAndManufacturingName() {
      return new ProductRelationshipRowFixture(responseDocument);
   }

   public Fixture checkChildProductPubkeys() {
      return new ChildProductPubkeyRowFixture(responseDocument);
   }

   public Fixture childProductAliasPubkeysIn(String preComlName) {
      return new ChildProductAliasPubkeyRowFixture(responseDocument, preComlName);
   }

   public Fixture parentProductPubkeysIn(String preComlName) {
      return new ParentProductPubkeyRowFixture(responseDocument, preComlName);
   }

   public Fixture checkChildProductLevel() {
      return new ChildProductLevelRowFixture(responseDocument);
   }

   public Fixture checkChildProductAliasLevel() {
      return new ChildProductAliasRowFixture(responseDocument);
   }

   public Fixture checkParentProductLevel() {
      return new ParentProductLevelRowFixture(responseDocument);
   }

   private Document buildRequestDocument(String name) {
      Document requestDocument =
         new DocumentCreator().createDocument(ProductParentGermplasmDocTags.PRODUCT_PARENT_NAMESPACE, ProductParentGermplasmDocTags.REQUEST_ELEM_NAME);
      Element docElement = requestDocument.getDocumentElement();
      DOMUtil.addChildElementWithNS(ProductParentGermplasmDocTags.PRODUCT_PARENT_NAMESPACE, docElement, ProductParentGermplasmDocTags.NAME_ELEM_NAME, name);
      return requestDocument;
   }

   private Document getResponse(Document requestDocument)
      throws POSCommunicationException, POSException
   {
      POSConnection conn = new LexiconPOSConnection();
      POSResult result = conn.callService("Lex_ProductParentsByName", requestDocument);
      return new POSResultDocumentProcessor().getDocument(result);
   }
}
