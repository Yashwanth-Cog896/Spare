package com.monsanto.tcc.lexiconfixtures.webappat.excel.screenfixture;

import com.meterware.httpunit.WebConversation;
import com.meterware.httpunit.WebResponse;

/**
 * nbwald - Apr 17, 2008 11:36:49 AM
 */
public interface HttpUnitPageVisitStrategy
{
   public WebResponse visitPage(WebConversation conversation)
      throws Exception;
}
