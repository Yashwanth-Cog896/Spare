package com.monsanto.tcc.lexiconfixtures.data.midas.productname;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreDelete;
import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Dec 18, 2006
 * Time: 4:02:41 PM
 * To change this template use File | Settings | File Templates.
 */
public class RemoveMidasProductNameById
{
   public Long productNameId;

   public RemoveMidasProductNameById(Long productNameId) {
      this.productNameId = productNameId;
   }

   public int remove()
      throws WrappingException
   {
      MidasProductNameDelete dataMod = new MidasProductNameDelete();
      return dataMod.performDelete();
   }

   class MidasProductNameDelete
      extends AbstractPersistentStoreDelete
   {
      protected String getSQL() throws WrappingException {
         return new SQLPropFile(MidasProductNameFixtureSQL.class).getSQL(MidasProductNameFixtureSQL.DELETE_PRODUCT_NAME);
      }
      protected Object[] getBindVariables() throws WrappingException {
         return new Object[] { productNameId };
      }
      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new MidasConnectionFactoryProperties();
      }
   }
}
