package com.monsanto.tcc.lexiconfixtures.data.fbscommon.product;

import com.monsanto.tcc.lexiconcommon.db.SQLPropFile;
import com.monsanto.tcc.lexiconfixtures.data.factories.fbs.FBSCommonConnectionFactory;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 9, 2006
 * Time: 1:07:03 PM
 * To change this template use File | Settings | File Templates.
 */
public class RemoveFBSCommonProduct
   extends SymbolAcceptingColumnFixture
{
   public String lexiconProductPubkey;

   private SQLPropFile sqlPropFile = new SQLPropFile(FBSCommonProductFixtureSQL.class);

   public boolean removed()
      throws WrappingException
   {
      FBSCommonConnectionFactory connectionFactory = new FBSCommonConnectionFactory();
      PersistentStoreConnection conn = connectionFactory.getConnection();
      try {
         int numDeleted = deleteFakeData(conn);
         return numDeleted == 1;
      }
      finally {
         conn.close();
      }
   }

   private int deleteFakeData(PersistentStoreConnection conn)
      throws WrappingException
   {
      String productDeleteSQL = sqlPropFile.getSQL(FBSCommonProductFixtureSQL.DELETE_PRODUCT);
      PersistentStoreStatement stmt = conn.prepareStatement(productDeleteSQL);
      try {
         stmt.setParam(1, lexiconProductPubkey);
         return stmt.executeDelete();
      }
      finally {
         stmt.close();
      }
   }
}
