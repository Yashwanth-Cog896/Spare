package com.monsanto.tcc.lexiconfixtures.serviceat.seedplanning;

import com.monsanto.tcc.lexiconcommon.service.ProductParentGermplasmDocTags;
import com.monsanto.tcc.lexiconcommon.xml.LexiconXPathSelector;
import com.monsanto.tcc.lexiconcommon.xml.SingleNamespaceContext;
import com.monsanto.XMLUtil.DOMUtil;
import fit.RowFixture;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Feb 14, 2007
 * Time: 8:09:06 AM
 * To change this template use File | Settings | File Templates.
 */
public class ChildProductAliasRowFixture
   extends AbstractChildProductRowFixture
{
   public ChildProductAliasRowFixture(Document responseDocument) {
      super(responseDocument);
   }

   protected Object[] query(List<Node> childProductNodes)
   {
      List childProductAliasAdapters = new ArrayList();
      for (Node childProductNode : childProductNodes) {
         List adpatersForCurrentNode = getChildProductAliasAdapters(childProductNode);
         childProductAliasAdapters.addAll(adpatersForCurrentNode);
      }
      return childProductAliasAdapters.toArray();
   }

   private List getChildProductAliasAdapters(Node childProductNode) {
      Node[] aliasNodes = getAliasNodesForChildProduct(childProductNode);
      String precommercialName = DOMUtil.getChildValue(childProductNode, ProductParentGermplasmDocTags.PRE_COML_NAME_ELEM_NAME);
      List childProductAliasAdapters = new ArrayList();
      for (int j = 0; j < aliasNodes.length; j++) {
         childProductAliasAdapters.add(new ChildProductAliasAdapter(precommercialName, aliasNodes[j]));
      }
      return childProductAliasAdapters;
   }

   private Node[] getAliasNodesForChildProduct(Node childProductNode) {
      Node aliasesNode = DOMUtil.getChild(childProductNode, ProductParentGermplasmDocTags.PRODUCT_ALIASES_ELEM_NAME);
      return DOMUtil.getChildren(aliasesNode, ProductParentGermplasmDocTags.PRODUCT_ALIAS_ELEM_NAME);
   }

   public Class getTargetClass() {
      return ChildProductAliasAdapter.class;
   }
}
