package com.monsanto.tcc.lexiconfixtures.data.lexicon.productname;

import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 7, 2006
 * Time: 1:47:36 PM
 * To change this template use File | Settings | File Templates.
 */
public class RemoveLexiconMonsantoProductName
   extends SymbolAcceptingColumnFixture
{
   public String productStagePubkey;
   public String precomlName;
   public String commercialName;
   public String brand;
   public String country;

   public boolean removed()
      throws WrappingException
   {
      String productStagePubkey = getProductStagePubkey();
      RemoveLexiconMonsantoProductAliasByAliasPubkey removeByAliasPubkey =
         new RemoveLexiconMonsantoProductAliasByAliasPubkey(productStagePubkey);
      return removeByAliasPubkey.remove() == 1;
   }

   private String getProductStagePubkey()
      throws WrappingException
   {
      return productStagePubkey == null ? getProductStagePubkeyByAttributes() : productStagePubkey;
   }

   private String getProductStagePubkeyByAttributes()
      throws WrappingException
   {
      LexiconProductAliasPubkeyLookup lookup =
         new LexiconProductAliasPubkeyLookup(precomlName, commercialName, brand, country);
      return lookup.getPubkey();
   }
}

