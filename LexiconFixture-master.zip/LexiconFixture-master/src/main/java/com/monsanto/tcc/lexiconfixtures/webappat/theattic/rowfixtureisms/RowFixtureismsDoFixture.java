package com.monsanto.tcc.lexiconfixtures.webappat.theattic.rowfixtureisms;

import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingRowFixture;
import fit.Fixture;
import fitlibrary.ArrayFixture;
import fitlibrary.DoFixture;
import fitlibrary.SetFixture;

/**
 * nbwald - Jun 11, 2008 5:11:24 PM
 */
public class RowFixtureismsDoFixture
   extends DoFixture
{
   public Fixture twoValues() {
      return new MyRowFixture(new RowType[] {
         new RowType("a value", "b value") 
      });
   }

   public Fixture secondValueIsNull() {
      return new MyRowFixture(new RowType[] {
         new RowType("a value", null)
      });
   }

   public Fixture secondValueIsBlank() {
      return new MyRowFixture(new RowType[] {
         new RowType("a value", "") 
      });
   }

   public Fixture usingSetFixtureSecondValueIsNull() {
      return new SetFixture(new RowType[] {
         new RowType("a value", null)
      });
   }

   public Fixture usingArrayFixtureSecondValueIsNull() {
      return new ArrayFixture(new RowType[] {
         new RowType("a value", null)
      });
   }

   private class MyRowFixture
      extends SymbolAcceptingRowFixture
   {
      private RowType[] rowTypes;

      public MyRowFixture(RowType[] rowTypes) {
         this.rowTypes = rowTypes;
      }

      public Object[] query()
         throws Exception
      {
         return rowTypes;
      }

      public Class getTargetClass() {
         return RowType.class;
      }
   }

   public class RowType {
      public String a;
      public String b;

      public RowType(String a, String b) {
         this.a = a;
         this.b = b;
      }
   }
}