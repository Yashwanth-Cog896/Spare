package com.monsanto.tcc.lexiconfixtures.serviceat.productrelationship.productionstatus;

/**
 * nbwald - Sep 15, 2008 3:08:34 PM
 */
public class Pubkey
{
   public String publicKey;

   public Pubkey(String publicKey) {
      this.publicKey = publicKey;
   }
}
