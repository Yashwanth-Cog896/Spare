/*
 CountryValue was created on Mar 16, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.webappat.assignpcname;

/**
 * nbwald Mar 16, 2007 3:19:40 PM
 */
public class CountryValue {
   public String countryAbbr;
   public String countryName;

   public CountryValue(String countryAbbr) {
      this(countryAbbr, null);
   }

   public CountryValue(String countryAbbr, String countryName) {
      this.countryAbbr = countryAbbr;
      this.countryName = countryName;
   }
}