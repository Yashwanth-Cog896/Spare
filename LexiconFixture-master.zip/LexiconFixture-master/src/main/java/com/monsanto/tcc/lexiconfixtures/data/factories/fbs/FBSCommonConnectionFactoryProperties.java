package com.monsanto.tcc.lexiconfixtures.data.factories.fbs;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.data.factories.midas.MidasConnectionFactoryProperties;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * Created by IntelliJ IDEA.
 * User: jaskidi
 * Date: Oct 18, 2005
 * Time: 3:27:55 PM
 * To change this template use File | Settings | File Templates.
 */
public class FBSCommonConnectionFactoryProperties
   implements ConnectionFactoryProperties
{
   private MidasConnectionFactoryProperties midasProps = new MidasConnectionFactoryProperties();

   public String getInstanceName() {
      return midasProps.getInstanceName();
   }
   public String getUserName()
      throws WrappingException
   {
      return midasProps.getUserName();
   }
   public String getPassword()
      throws WrappingException
   {
      return midasProps.getPassword();
   }
   public String getDataSource()
      throws WrappingException
   {
      return midasProps.getDataSource();
   }
   public String getSequenceName()
      throws WrappingException
   {
      return midasProps.getSequenceName();
   }
   public int getMinPoolSize()
      throws WrappingException
   {
      return midasProps.getMinPoolSize();
   }
   public int getMaxPoolSize()
      throws WrappingException
   {
      return midasProps.getMaxPoolSize();
   }

   public String getJndiName()
      throws WrappingException
   {
      return midasProps.getJndiName();
   }

    @Override
    public String getConnectionString() throws WrappingException {
        return midasProps.getConnectionString();
    }
}
