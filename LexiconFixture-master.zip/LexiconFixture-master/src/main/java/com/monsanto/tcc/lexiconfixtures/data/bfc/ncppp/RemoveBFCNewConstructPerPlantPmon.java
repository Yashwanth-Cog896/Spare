package com.monsanto.tcc.lexiconfixtures.data.bfc.ncppp;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreDelete;
import com.monsanto.tcc.lexiconfixtures.data.factories.bfc.BFCConnectionFactoryProperties;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;

/**
 * User: pjberry
 * Date: Aug 2, 2007
 * Time: 6:04:18 PM
 */
public class RemoveBFCNewConstructPerPlantPmon
   extends SymbolAcceptingColumnFixture
{
   public String pmon;
   public String transcode;
   public String crop;

   public boolean removed()
      throws WrappingException
   {
      BFCNewConstructPerPlantPmonDelete ncppDelete = new BFCNewConstructPerPlantPmonDelete();
      return ncppDelete.performDelete() == 1;
   }

   private class BFCNewConstructPerPlantPmonDelete
      extends AbstractPersistentStoreDelete
   {
      protected String getSQL()
         throws WrappingException
      {
         return
            "DELETE FROM " +
               "Regulatory.new_construct_per_plant_pmon NCPPP " +
            "WHERE " +
               "NCPPP.pmon = ? " +
               "AND " +
               "NCPPP.trans_code = ? " +
               "AND " +
               "NCPPP.crop_id = (SELECT C.crop_id FROM Regulatory.crop C WHERE UPPER(C.common_name) = UPPER(?))";
      }

      protected Object[] getBindVariables()
         throws WrappingException
      {
         return new Object[]{pmon, transcode, crop};
      }

      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new BFCConnectionFactoryProperties();
      }
   }
}
