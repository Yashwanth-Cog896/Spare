package com.monsanto.tcc.lexiconfixtures.serviceat.regulatoryevent;

import com.monsanto.KerberosPOSSecurity.KerberosStandaloneCredential;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.tcc.lexiconcommon.pos.LexiconServiceInvoker;
import com.monsanto.tcc.lexiconcommon.pos.SecurityProxyFactory;
import com.monsanto.tcc.lexiconcommon.pos.ServiceInvoker;
import com.monsanto.tcc.lexiconfixtures.serviceat.regulatoryevent.serialization.RegulatoryEventRequestSerialzer;
import com.monsanto.tcc.lexiconfixtures.util.ConfigureMidasCropMixin;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingDoFixture;
import com.monsanto.xmlserialization.DeserializationException;
import com.monsanto.xmlserialization.SerializationException;
import com.monsanto.xmlserialization.XmlSerializer;
import com.monsanto.xmlserialization.XmlSerializerBuilder;
import fit.Fixture;
import org.ietf.jgss.GSSException;
import org.w3c.dom.Document;

/**
 * User: pjberry
 * Date: Aug 1, 2007
 * Time: 5:36:59 PM
 */
public class RegulatoryEventServiceFixture
   extends SymbolAcceptingDoFixture
{
   private RegulatoryEventResponse response;
   private static final int ONE_SECOND = 1000;

   public boolean sendForEventForCrop(String event, String crop)
      throws WrappingException, GSSException
   {
      Document eventRequestDoc = buildRequest(event, crop);
      Document responseDoc = getResponse(eventRequestDoc);
      DOMUtil.outputXML(responseDoc);
      response = parseResponse(responseDoc);
      return true;
   }

   public Fixture checkEventServiceResults() {
      return new RegulatoryEventRowFixture(response.RegulatoryEventList);
   }

   public int numberOfRegulatoryEventsFoundIs() {
      return response.RegulatoryEventList.length;
   }

   public boolean configureMidasCrop(String cropGenusSpecies)
      throws Exception
   {
      return new ConfigureMidasCropMixin().configureMidasCrop(cropGenusSpecies);
   }

   private Document buildRequest(String event, String crop)
      throws SerializationException
   {
      RegulatoryEventRequest request = new RegulatoryEventRequest(event, crop);
      RegulatoryEventRequestSerialzer requestSerializer = new RegulatoryEventRequestSerialzer();
      return requestSerializer.toDocument(request);
   }


   private Document getResponse(Document requestDoc)
      throws WrappingException, GSSException
   {
      SecurityProxyFactory.getInstance().setThreadProxy(new KerberosStandaloneCredential());
      ServiceInvoker serviceInvoker = new LexiconServiceInvoker("Lex_GetEventData");
      return serviceInvoker.call(requestDoc);
   }

   private RegulatoryEventResponse parseResponse(Document responseDoc)
      throws DeserializationException
   {
      XmlSerializerBuilder responseSerializerBuilder = new XmlSerializerBuilder();
      responseSerializerBuilder.registerMapping("http://www.monsanto.com/lexicon/Event", "RegulatoryEventResponse", RegulatoryEventResponse.class);
      responseSerializerBuilder.registerMapping("http://www.monsanto.com/lexicon/Event", "RegulatoryEvent", RegulatoryEvent.class);

      responseSerializerBuilder.registerFieldAlias(RegulatoryEvent.class, "event", "Event");
      responseSerializerBuilder.registerFieldAlias(RegulatoryEvent.class, "plasmidPmon", "Plasmid_pMON");
      responseSerializerBuilder.registerFieldAlias(RegulatoryEvent.class, "plasmidPVCode", "Plasmid_PVCode");
      responseSerializerBuilder.registerFieldAlias(RegulatoryEvent.class, "transformationBackground", "Transformation_Background");

      XmlSerializer responseSerializer = responseSerializerBuilder.createSerializer();

      return (RegulatoryEventResponse)responseSerializer.fromDocument(responseDoc);
   }
}
