package com.monsanto.tcc.lexiconfixtures.webappat;

import fitlibrary.ArrayFixture;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Nov 15, 2006
 * Time: 2:20:09 PM
 * To change this template use File | Settings | File Templates.
 */
public class OptionsFixture
   extends ArrayFixture
{
   public OptionsFixture(String[] options) {
      List optionList = new ArrayList();
      for (int i = 0; i < options.length; i++) {
         optionList.add(new Option(options[i]));
      }
      setActualCollection(optionList);
   }

   public class Option
   {
      public String option;

      public Option(String option) {
         this.option = option;
      }
   }
}
