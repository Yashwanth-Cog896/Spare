/*
 TranslateLexiconMonsantoProductName was created on Jul 31, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.data.lexicon.productname;

import com.monsanto.tcc.lexiconcommon.db.factories.ConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactoryProperties;
import com.monsanto.tcc.lexiconcommon.db.psaction.AbstractPersistentStoreSingleResultQuery;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.Util.StringUtils;
import com.monsanto.dataservices.PersistentStoreResultSetRow;
import java.util.ArrayList;
import java.util.List;

/**
 * nbwald Jul 31, 2007 2:43:25 PM
 */
public class TranslateLexiconMonsantoProductName
    extends SymbolAcceptingColumnFixture
{
   public String precomlName;
   public String commercialName;
   public String country;
   public String brand;

   public String productStagePubkey()
      throws WrappingException
   {
      ProductStagePubkeyByStageIdentifiersQuery query = new ProductStagePubkeyByStageIdentifiersQuery();
      return query.getPubkey();
   }

   private class ProductStagePubkeyByStageIdentifiersQuery
      extends AbstractPersistentStoreSingleResultQuery
   {
      public String getPubkey()
         throws WrappingException
      {
         return (String) execute();
      }

      protected Object createObjectFromRow(PersistentStoreResultSetRow row)
         throws WrappingException
      {
         return row.getString(1);
      }

      protected String getSQL()
         throws WrappingException
      {

         String comlNameCriteria = comlNameSupplied() ? "= ?" : "IS NULL";

         return
            "SELECT PS.product_stage_pubkey " +
               " FROM Lexicon.Product_Stage PS," +
               "      Lexicon.Pre_Coml_Product PCP," +
               "      Lexicon.Country CO, " +
               "      Lexicon.Brand BR " +
               "WHERE PS.product_id = PCP.product_id " +
               "  AND PS.country_id = CO.country_id " +
               "  AND PS.commercial_name " + comlNameCriteria +
               "  AND PCP.pre_coml_name = ? " +
               "  AND CO.country_abbr = ? " +
               "  AND BR.brand_name = ? ";
      }

      protected Object[] getBindVariables()
         throws WrappingException
      {
         List<Object> bindVariables = new ArrayList<Object>();
         if(comlNameSupplied()) {
            bindVariables.add(commercialName);
         }
         bindVariables.add(precomlName);
         bindVariables.add(StringUtils.toUpperCaseNull(country));
         bindVariables.add(StringUtils.toUpperCaseNull(brand));
         return bindVariables.toArray(new Object[bindVariables.size()]);
      }

      protected ConnectionFactoryProperties getConnectionFactoryProperties() {
         return new LexiconConnectionFactoryProperties();
      }

      private boolean comlNameSupplied() {
         return !StringUtils.isNullOrEmpty(commercialName);
      }
   }
}