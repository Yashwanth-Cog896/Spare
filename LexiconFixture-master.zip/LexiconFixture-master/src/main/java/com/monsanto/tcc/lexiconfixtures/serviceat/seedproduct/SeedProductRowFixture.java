/*
 SeedProductRowFixture was created on Feb 14, 2007 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.tcc.lexiconfixtures.serviceat.seedproduct;

import com.monsanto.tcc.lexiconcommon.service.aggregateproduct.AggregateProductSchemaConstants;
import com.monsanto.XMLUtil.DOMUtil;
import fit.RowFixture;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import java.util.ArrayList;
import java.util.List;

/**
 * nbwald Feb 14, 2007 4:25:04 PM
 */
public class SeedProductRowFixture
   extends RowFixture
{
   private final Document responseDocument;

   public SeedProductRowFixture(Document responseDocument) {
      this.responseDocument = responseDocument;
   }

   public Object[] query()
      throws Exception
   {
      List seedProducts = new ArrayList();
      Element productsElem = (Element) DOMUtil.getChild(responseDocument.getDocumentElement(), AggregateProductSchemaConstants.NAMES_ELEM_NAME);
      Node[] productElems = DOMUtil.getChildren(productsElem, AggregateProductSchemaConstants.PRODUCT_ELEM_NAME);
      for(int i = 0; i < productElems.length; i++) {
         Element productElem = (Element) productElems[i];
         seedProducts.add(new SeedProductAdapter(productElem));
      }
      return seedProducts.toArray();
   }

   public Class getTargetClass() {
      return SeedProductAdapter.class;
   }
}