package com.monsanto.tcc.lexiconfixtures.data.lexicon.trait;

import com.monsanto.tcc.lexiconcommon.db.factories.lexicon.LexiconConnectionFactory;
import com.monsanto.tcc.lexiconcommon.db.test.LexiconTestTools;
import com.monsanto.tcc.lexiconfixtures.util.symbol.SymbolAcceptingColumnFixture;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.dbdataservices.SQLUtil;

/**
 * User: pjberry
 * Date: May 23, 2007
 * Time: 1:40:12 PM
 */
public class CreateLexiconComlTraitName
   extends SymbolAcceptingColumnFixture
{
   public Long comlTraitNameId;
   public String traitAbbr;
   public String traitDesc;
   public String company;
   public boolean isActive;

   public boolean created()
      throws WrappingException
   {
      LexiconConnectionFactory connectionFactory = new LexiconConnectionFactory();
      PersistentStoreConnection conn = connectionFactory.getConnection();
      LexiconTestTools.FITNESSE_TEST_AUDITOR.initializeStaging(conn);
      try {
         int numInserted = insertFakeData(conn);
         return numInserted == 1;
      }
      finally {
         LexiconTestTools.FITNESSE_TEST_AUDITOR.removeStaging(conn);
         conn.close();
      }
   }

   private int insertFakeData(PersistentStoreConnection conn)
      throws WrappingException
   {
      String sql = getSql();
      PersistentStoreStatement stmt = conn.prepareStatement(sql);
      try {
         stmt.setParam(1, comlTraitNameId);
         stmt.setParam(2, traitAbbr);
         stmt.setParam(3, traitDesc);
         stmt.setParam(4, company);
         stmt.setParam(5, SQLUtil.booleanToString(isActive));

         return stmt.executeInsert();
      }
      finally {
         stmt.close();
      }
   }

   private String getSql() {
      return
         "INSERT INTO Lexicon.Coml_Trait_Name2 CTN " +
            "(coml_trait_name_id, trait_abbr, trait_desc, company_id, is_active) " +
         "VALUES " +
            "(?, ?, ?, (SELECT C.company_id FROM Lexicon.Company C WHERE UPPER(C.company_name) = UPPER(?)), ?)";
   }
}
