package com.monsanto.tcc.lexiconfixtures.data.fbscommon.allinfo;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreStatement;

/**
 * Created by IntelliJ IDEA.
 * User: pjberry
 * Date: Mar 19, 2007
 * Time: 11:46:29 AM
 * To change this template use File | Settings | File Templates.
 */
public class DeleteFBSCommonProductAliasesByLexProductAliasPubkeys
{
   private final String sql = "DELETE FROM FBS_Common.product_name_xref PNX WHERE PNX.lexicon_product_name_pubkey = ?";

   public int deleteProductAliases(PersistentStoreConnection fbsConn, String[] lexiconProductAliasPubkeys)
      throws WrappingException
   {
      PersistentStoreStatement stmt = fbsConn.prepareStatement(sql);
      try {
         int numDeleted = 0;
         for (int i = 0; i < lexiconProductAliasPubkeys.length; i++) {
            stmt.setParam(1, lexiconProductAliasPubkeys[i]);
            numDeleted += stmt.executeDelete();
         }
         return numDeleted;
      }
      finally {
         stmt.close();
      }
   }
}
