package com.monsanto.tps.lexiconpos.product.relationship.service;

import com.monsanto.tps.lexicon.precommercialproduct.ProductionStatusUpdateRequest;
import com.monsanto.tps.lexicon.precommercialproduct.ProductionStatusUpdateResponse;

import javax.jws.WebService;
import javax.jws.WebParam;
import javax.jws.soap.SOAPBinding;

/**
 * rrchak1 - Sep 12, 2008 3:01:41 PM
 */
@WebService
@SOAPBinding(parameterStyle = SOAPBinding.ParameterStyle.BARE)
public interface ProductRelationshipService
{
   public ProductionStatusUpdateResponse updateProductionStatus(@WebParam(name = "products")ProductionStatusUpdateRequest[] productionStatusUpdateRequests);
}

