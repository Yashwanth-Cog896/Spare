package com.monsanto.tps.lexiconpos.product.auditsearch.modified.search.model;

/**
 * nbwald - Aug 25, 2008 5:16:14 PM
 */
public class ModifiedProduct
{
   private String productPublicKey;
   private String precommercialName;
   private boolean logicallyDeleted;
   private String cropPublicKey;
   private String baseManufacturingName;
   private String manufacturingName;

   public String getProductPublicKey() {
      return productPublicKey;
   }

   public void setProductPublicKey(String productPublicKey) {
      this.productPublicKey = productPublicKey;
   }

   public String getPrecommercialName() {
      return precommercialName;
   }

   public void setPrecommercialName(String precommercialName) {
      this.precommercialName = precommercialName;
   }

   public String getManufacturingName() {
      return manufacturingName;
   }

   public void setManufacturingName(String manufacturingName) {
      this.manufacturingName = manufacturingName;
   }

   public String getBaseManufacturingName() {
      return baseManufacturingName;
   }

   public void setBaseManufacturingName(String baseManufacturingName) {
      this.baseManufacturingName = baseManufacturingName;
   }

   public String getCropPublicKey() {
      return cropPublicKey;
   }

   public void setCropPublicKey(String cropPublicKey) {
      this.cropPublicKey = cropPublicKey;
   }

   public boolean isLogicallyDeleted() {
      return logicallyDeleted;
   }

   public void setLogicallyDeleted(boolean logicallyDeleted) {
      this.logicallyDeleted = logicallyDeleted;
   }
}
