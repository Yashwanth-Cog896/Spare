package com.monsanto.tps.lexiconpos.product.auditsearch.modified.search.model;

import java.util.Date;
import java.util.List;

/**
 * nbwald - Aug 25, 2008 5:43:05 PM
 */
public class ModifiedProductsSearchResults
{
   private Date start;
   private Date end;
   private List<ModifiedProduct> modifiedProducts;

   public List<ModifiedProduct> getModifiedProducts() {
      return modifiedProducts;
   }

   public void setModifiedProducts(List<ModifiedProduct> modifiedProducts) {
      this.modifiedProducts = modifiedProducts;
   }

   public Date getStart() {
      return start;
   }

   public void setStart(Date start) {
      this.start = start;
   }

   public Date getEnd() {
      return end;
   }

   public void setEnd(Date end) {
      this.end = end;
   }
}
