package com.monsanto.tps.lexiconpos.product.auditsearch.modified.search.service;

import com.monsanto.tps.lexiconpos.product.auditsearch.modified.search.model.ModifiedProductsSearchResults;

import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import java.util.Date;

/**
 * nbwald - Sep 4, 2008 6:11:57 PM
 */
@WebService
@SOAPBinding(parameterStyle = SOAPBinding.ParameterStyle.BARE)
public interface ModifiedProductsService
{
   ModifiedProductsSearchResults findByTimeModifiedRangeAndCrop(
      @WebParam(name = "start") Date start,
      @WebParam(name = "end") Date end,
      @WebParam(name = "cropPublicKey") String cropPublicKey);
}
